"""Phase 7: Fiddler monitors for model canaries (candidate vs incumbent), rendered from the gateway canary manifest."""

from __future__ import annotations

import shutil

import pytest
import yaml
from aig_fiddler.endpoints import load_endpoints
from aig_fiddler.client import FiddlerAdmin
from aig_fiddler.loader import load_repo
from aig_fiddler.plan import format_plan, sync
from aig_fiddler.registry import Agent
from aig_fiddler.render import canary_thresholds, load_canaries, render
from aig_fiddler.validate import validate
from conftest import BASE, REGISTRY, ROOT, SLACK_URL, TOKEN

CANARY = {"tier": "premium", "state": "canary", "share": 10, "incumbent": ["opus"],
          "model": {"alias": "claude-opus-next", "integration": "anthropic-prod", "model": "claude-opus-next-2026-10"}}
ENV_SECRETS = {v: SLACK_URL for v in ("AIG_ALERT_SLACK_WEBHOOK_PLATFORM", "AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING",
                                      "AIG_ALERT_SLACK_WEBHOOK_CLAIMS")}
AGENT = Agent("uw-quote", "jane@aig.example.com", "underwriting-ai")


def canary_rules(r):
    return [a for a in r.objects["alert_rules"] if a["application"] == "aig-model-canary"]


def test_no_canary_no_rules():
    r = render(load_repo(ROOT), "dev", [AGENT], fiddler_url=BASE, canaries=[])
    assert not canary_rules(r) and not any(a["application"] == "aig-model-canary" for a in r.objects["applications"])


def test_canary_rules_compare_candidate_with_incumbent():
    r = render(load_repo(ROOT), "prod", [AGENT], fiddler_url=BASE, canaries=[CANARY])
    apps = [a for a in r.objects["applications"] if a["application"] == "aig-model-canary"]
    assert [a["project"] for a in apps] == ["aig-prod"]
    rules = {a["name"]: a for a in canary_rules(r)}
    assert set(rules) == {f"canary-premium-claude-opus-next-{m}" for m in ("quality", "cost", "error-rate", "latency-p95")}
    q = rules["canary-premium-claude-opus-next-quality"]
    assert q["condition"] == "lesser" and q["warning_threshold"] == pytest.approx(0.833) and q["critical_threshold"] == pytest.approx(0.8075)
    assert q["segment"]["definition"] == "\"gen_ai.response.model\" == 'claude-opus-next-2026-10'"
    assert q["canary"] == {"tier": "premium", "state": "canary", "model": "claude-opus-next-2026-10", "share": 10,
                           "incumbent": ["opus"], "incumbent_value": 0.85}
    cost = rules["canary-premium-claude-opus-next-cost"]
    assert cost["condition"] == "greater" and cost["warning_threshold"] == pytest.approx(0.0115) and cost["critical_threshold"] == pytest.approx(0.013)
    err = rules["canary-premium-claude-opus-next-error-rate"]
    assert err["priority"] == "HIGH" and "aig-ai-platform" in err["notification"]["pagerduty_services"]  # pages in prod
    assert err["warning_threshold"] <= err["critical_threshold"]


def test_canaries_are_read_from_the_gateway_manifest(tmp_path):
    repo = load_repo(ROOT)
    assert load_canaries(repo) == yaml.safe_load(
        (ROOT.parent / "gateway" / "manifests" / "canaries.yaml").read_text())["spec"]["canaries"]
    f = tmp_path / "canaries.yaml"
    f.write_text(yaml.safe_dump({"apiVersion": "aig.gateway/v1", "kind": "Canaries",
                                 "spec": {"config": "pc-aig-router", "canaries": [CANARY]}}))
    assert load_canaries(repo, f) == [CANARY]
    assert load_canaries(repo, tmp_path / "missing.yaml") == []
    f.write_text(yaml.safe_dump({"spec": {"canaries": [{"tier": "premium"}]}}))
    with pytest.raises(Exception, match="malformed canary entry"):
        load_canaries(repo, f)


def _copy(tmp_path):
    dst = tmp_path / "fiddler"
    for d in ("manifests", "envs", "schemas"):
        shutil.copytree(ROOT / d, dst / d)
    local = dst / "envs" / "local.yaml"
    doc = yaml.safe_load(local.read_text())
    doc["registry"] = {"file": str(REGISTRY)}
    local.write_text(yaml.safe_dump(doc))
    return dst


@pytest.mark.parametrize("mutate,needle", [
    (lambda s: s["monitors"].pop(0), "'quality' is required"),
    (lambda s: s["monitors"][1].update(warning_tolerance=0.9), "warning_tolerance must not exceed"),
    (lambda s: s["monitors"][0].update(critical_tolerance=1.5, warning_tolerance=0.1), "'lesser' tolerance must be < 1"),
    (lambda s: s.update(application="ide.vscode"), "built-in agent"),
])
def test_canary_monitor_validation(tmp_path, mutate, needle):
    root = _copy(tmp_path)
    p = root / "manifests" / "canary-monitors.yaml"
    doc = yaml.safe_load(p.read_text())
    mutate(doc["spec"])
    p.write_text(yaml.safe_dump(doc))
    rep = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert not rep.ok and any(needle in e for e in rep.errors), rep.errors


def test_missing_canaries_file_only_warns(tmp_path):
    root = _copy(tmp_path)  # outside the monorepo: ../gateway does not exist
    rep = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert rep.ok and any("canaries_file" in w for w in rep.warnings)


def test_thresholds_formula():
    assert canary_thresholds({"incumbent_value": 100, "condition": "greater", "warning_tolerance": 0.1,
                              "critical_tolerance": 0.25}) == (110.0, 125.0)
    assert canary_thresholds({"incumbent_value": 1, "condition": "lesser", "warning_tolerance": 0.1,
                              "critical_tolerance": 0.2}) == (0.9, 0.8)


def test_sync_creates_canary_application_and_segmented_rules(fake):
    r = render(load_repo(ROOT), "dev", [AGENT], fiddler_url=BASE, canaries=[CANARY])
    plan = sync(FiddlerAdmin(BASE, TOKEN), r, load_endpoints(), apply=True, environ=ENV_SECRETS)
    assert not plan.failed, format_plan(plan)
    apps = [a for a in fake.apps.values() if a["name"] == "aig-model-canary"]
    assert len(apps) == 3  # dev hosts aig-local, aig-workspace, aig-dev
    rules = [a for a in fake.alerts.values() if a["name"].startswith("canary-premium-")]
    assert len(rules) == 3 * 4
    assert all(a["segment"]["definition"].endswith("'claude-opus-next-2026-10'") for a in rules)
    assert {a["application_id"] for a in rules} == {a["id"] for a in apps}
    again = sync(FiddlerAdmin(BASE, TOKEN), r, load_endpoints(), apply=False, environ=ENV_SECRETS)
    assert set(again.counts()) == {"noop"}, format_plan(again)
    # Rolled back in the gateway -> nothing new is rendered (existing rules are left alone, never deleted).
    r2 = render(load_repo(ROOT), "dev", [AGENT], fiddler_url=BASE, canaries=[])
    assert not canary_rules(r2)
