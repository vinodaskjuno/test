"""In-memory fake of the Fiddler REST endpoints aig-fiddler uses, mounted on respx."""

from __future__ import annotations

import json
import re
import uuid

import httpx

BASE = "https://fiddler.test.example.com"
TOKEN = "fdl-SUPERSECRET-token-0123456789"


def _page(items):
    return {"data": {"items": items, "total": len(items), "page_index": 1, "page_count": 1, "offset": 0}}


def _filter(request) -> dict:
    raw = request.url.params.get("filter")
    if not raw:
        return {}
    return {r["field"]: r["value"] for r in json.loads(raw)["rules"]}


class FakeFiddler:
    def __init__(self):
        self.projects: dict[str, dict] = {}
        self.apps: dict[str, dict] = {}
        self.webhooks: dict[str, dict] = {}
        self.evaluators: dict[str, dict] = {}
        self.alerts: dict[str, dict] = {}
        self.notifications: dict[str, dict] = {}
        self.writes: list[tuple[str, str]] = []
        self.auth_ok = True

    def _auth(self, request):
        if request.headers.get("authorization") != f"Bearer {TOKEN}":
            self.auth_ok = False
            return httpx.Response(401, json={"error": "bad token"})
        return None

    def handler(self, request: httpx.Request) -> httpx.Response:
        if (bad := self._auth(request)) is not None:
            return bad
        m, path = request.method, request.url.path
        body = json.loads(request.content) if request.content else {}
        if m != "GET":
            self.writes.append((m, path))
        f = _filter(request)
        if path == "/v3/projects":
            if m == "GET":
                return httpx.Response(200, json=_page(list(self.projects.values())))
            obj = {"id": str(uuid.uuid4()), **body}
            self.projects[obj["id"]] = obj
            return httpx.Response(200, json={"data": obj})
        if path == "/v3/applications":
            if m == "GET":
                items = [a for a in self.apps.values() if all(str(a.get(k)) == v for k, v in f.items())]
                return httpx.Response(200, json=_page(items))
            obj = {"id": str(uuid.uuid4()), **body}
            self.apps[obj["id"]] = obj
            return httpx.Response(200, json={"data": obj})
        if path == "/v2/webhooks":
            if m == "GET":
                return httpx.Response(200, json=_page([{k: v for k, v in w.items() if k != "url"} | {"url": "***"} for w in self.webhooks.values()]))
            obj = {"uuid": str(uuid.uuid4()), **body}
            self.webhooks[obj["uuid"]] = obj
            return httpx.Response(200, json={"data": obj})
        if mo := re.fullmatch(r"/v2/webhooks/([^/]+)", path):
            self.webhooks[mo.group(1)].update(body)
            return httpx.Response(200, json={"data": self.webhooks[mo.group(1)]})
        if mo := re.fullmatch(r"/v3/applications/([^/]+)/evaluator-rules(?:/([^/]+))?", path):
            app_id, rid = mo.groups()
            if m == "GET":
                return httpx.Response(200, json=_page([e for e in self.evaluators.values() if e["application_id"] == app_id]))
            if rid:
                self.evaluators[rid].update(body)
                return httpx.Response(200, json={"data": self.evaluators[rid]})
            obj = {"id": str(uuid.uuid4()), "application_id": app_id, **body}
            self.evaluators[obj["id"]] = obj
            return httpx.Response(200, json={"data": obj})
        if path == "/v3/alert-rules":
            if m == "GET":
                items = [a for a in self.alerts.values() if all(str(a.get(k)) == v for k, v in f.items())]
                return httpx.Response(200, json=_page(items))
            # Mimic the server response shape: metric object, columns alias.
            obj = {"id": str(uuid.uuid4()), **body, "metric": {"id": body["metric_id"]}}
            obj.pop("metric_id")
            self.alerts[obj["id"]] = obj
            return httpx.Response(200, json={"data": obj})
        if mo := re.fullmatch(r"/v3/alert-rules/([^/]+)/notification", path):
            rid = mo.group(1)
            if m == "GET":
                return httpx.Response(200, json={"data": self.notifications.get(rid, {})})
            self.notifications[rid] = body
            return httpx.Response(200, json={"data": body})
        if mo := re.fullmatch(r"/v3/alert-rules/([^/]+)", path):
            rid = mo.group(1)
            if m == "DELETE":
                self.alerts.pop(rid)
                self.notifications.pop(rid, None)
                return httpx.Response(204)
            self.alerts[rid].update(body)
            return httpx.Response(200, json={"data": self.alerts[rid]})
        return httpx.Response(404, json={"error": f"no route {m} {path}"})

    def mount(self, router) -> None:
        router.route(host="fiddler.test.example.com").mock(side_effect=self.handler)
