from __future__ import annotations

import json

import httpx
import respx
from aig_fiddler.cli import main
from conftest import REGISTRY, ROOT

ARGS = ["--root", str(ROOT)]


def test_validate_cli(capsys):
    assert main([*ARGS, "validate", "--allow-placeholders"]) == 0
    assert "validate: OK" in capsys.readouterr().out
    assert main([*ARGS, "validate", "--env", "prod"]) == 1


def test_render_cli_with_registry_file(capsys):
    assert main([*ARGS, "render", "--env", "dev", "--registry-file", str(REGISTRY), "--kind", "applications"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert set(out["objects"]) == {"applications"}
    assert any(a["agent_id"] == "uw-quote-assistant" for a in out["objects"]["applications"])


def test_render_local_uses_overlay_registry_file(capsys):
    assert main([*ARGS, "render", "--env", "local", "--kind", "projects"]) == 0
    assert json.loads(capsys.readouterr().out)["objects"]["projects"] == [{"name": "aig-local", "asset_type": "GEN_AI_APP"}]


def test_apply_is_dry_run_by_default_then_applies(fake, env_vars, capsys):
    assert main([*ARGS, "apply", "--env", "local"]) == 0
    out = capsys.readouterr().out
    assert "DRY RUN" in out and "+ create" in out
    assert fake.writes == []
    assert main([*ARGS, "apply", "--env", "local", "--yes", "--json"]) == 0
    report = json.loads(capsys.readouterr().out)
    assert report["applied"] is True and report["counts"]["create"] > 0
    assert main([*ARGS, "diff", "--env", "local", "--exit-code"]) == 0
    assert "SUPERSECRET" not in capsys.readouterr().out


def test_diff_exit_code_when_changes(fake, env_vars):
    assert main([*ARGS, "diff", "--env", "local", "--exit-code"]) == 2


def test_registry_url_needs_service_token(env_vars, monkeypatch, capsys):
    monkeypatch.delenv("AIG_PLATFORM_SERVICE_TOKEN", raising=False)
    assert main([*ARGS, "render", "--env", "dev", "--registry-url", "https://platform.test"]) == 1
    assert "AIG_PLATFORM_SERVICE_TOKEN" in capsys.readouterr().err
    monkeypatch.setenv("AIG_PLATFORM_SERVICE_TOKEN", "svc-token-SUPERSECRET")
    with respx.mock() as router:
        route = router.get("https://platform.test/api/v1/agents").mock(return_value=httpx.Response(
            200, json={"agents": [{"agent_id": "uw-a", "owner": "a@example.com", "team": "underwriting-ai", "status": "active"}]}))
        assert main([*ARGS, "render", "--env", "dev", "--registry-url", "https://platform.test", "--kind", "applications"]) == 0
        assert route.calls[0].request.headers["x-aig-service-token"] == "svc-token-SUPERSECRET"
    apps = json.loads(capsys.readouterr().out)["objects"]["applications"]
    assert {a["agent_id"] for a in apps} == {"uw-a", "ide.vscode", "ide.eclipse", "web.portal"}


def test_provision_agent_cli_dry_run(fake, env_vars, capsys):
    assert main([*ARGS, "provision-agent", "--env", "dev", "--agent-id", "uw-z", "--team", "underwriting-ai", "--owner", "j@example.com"]) == 0
    assert json.loads(capsys.readouterr().out)["applied"] is False
    assert fake.writes == []
