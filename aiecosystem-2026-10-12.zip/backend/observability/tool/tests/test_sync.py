from __future__ import annotations

import pytest
from aig_fiddler.client import FiddlerAdmin, FiddlerError
from aig_fiddler.endpoints import load_endpoints
from aig_fiddler.hooks import on_agent_registered, provision_agent
from aig_fiddler.loader import load_repo
from aig_fiddler.plan import format_plan, sync
from aig_fiddler.registry import Agent, load_agents_file
from aig_fiddler.render import render
from conftest import BASE, REGISTRY, ROOT, SLACK_URL, TOKEN

ENV_SECRETS = {
    "AIG_ALERT_SLACK_WEBHOOK_PLATFORM": SLACK_URL,
    "AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING": SLACK_URL,
    "AIG_ALERT_SLACK_WEBHOOK_CLAIMS": SLACK_URL,
}


def rendered(env="dev", agents=None):
    return render(load_repo(ROOT), env, agents if agents is not None else load_agents_file(REGISTRY), fiddler_url=BASE)


def client():
    return FiddlerAdmin(BASE, TOKEN)


def test_dry_run_plans_creates_and_writes_nothing(fake):
    plan = sync(client(), rendered(), load_endpoints(), apply=False, environ=ENV_SECRETS)
    assert fake.writes == []
    counts = plan.counts()
    assert set(counts) == {"create"}
    # projects, apps, webhooks, evaluators, alerts, invocation alerts (3 registry agents x 3 projects x
    # (error rate + latency + cost for 3 caller teams))
    assert counts["create"] == 3 + 18 + 3 + 18 * 4 + 18 * 4 + 45


def test_apply_then_noop_then_drift(fake):
    r = rendered()
    plan = sync(client(), r, load_endpoints(), apply=True, environ=ENV_SECRETS)
    assert not plan.failed, format_plan(plan)
    assert fake.auth_ok
    assert len(fake.projects) == 3 and len(fake.apps) == 18 and len(fake.alerts) == 72 + 45 and len(fake.evaluators) == 72
    assert {p["asset_type"] for p in fake.projects.values()} == {"GEN_AI_APP"}
    # notification config is set with webhook UUIDs, not names
    some = next(iter(fake.notifications.values()))
    assert all(len(w) == 36 for w in some.get("webhooks", []))

    again = sync(client(), r, load_endpoints(), apply=False, environ=ENV_SECRETS)
    assert set(again.counts()) == {"noop"}, format_plan(again)

    # drift: a threshold changed by hand -> update; a metric changed -> recreate
    rule = next(a for a in fake.alerts.values() if a["name"] == "uw-quote-assistant-error-rate" and True)
    rule["critical_threshold"] = 0.9
    other = next(a for a in fake.alerts.values() if a["name"] == "uw-quote-assistant-drift")
    other["metric"] = {"id": "psi"}
    ev = next(e for e in fake.evaluators.values() if e["name"] == "aig-trust-jailbreak")
    ev["threshold"] = 0.99
    drift = sync(client(), r, load_endpoints(), apply=True, environ=ENV_SECRETS)
    actions = {(i.kind, i.action) for i in drift.items if i.action != "noop"}
    assert ("alert_rule", "update") in actions and ("alert_rule", "recreate") in actions and ("evaluator_rule", "update") in actions
    assert rule["critical_threshold"] == 0.05
    assert set(sync(client(), r, load_endpoints(), apply=False, environ=ENV_SECRETS).counts()) == {"noop"}


def test_missing_slack_secret_blocks_webhook_and_never_prints_urls(fake):
    plan = sync(client(), rendered(), load_endpoints(), apply=True, environ={})
    assert plan.failed
    blocked = [i for i in plan.items if i.action == "blocked"]
    assert {i.key for i in blocked} == {"aig-slack-platform", "aig-slack-underwriting", "aig-slack-claims"}
    text = format_plan(plan, show_noop=True)
    assert "SUPERSECRET" not in text and TOKEN not in text
    # alert rules still created; notifications reference no webhooks yet
    assert fake.alerts and all(not n.get("webhooks") for n in fake.notifications.values())


def test_kind_filter_reports_requested_kinds_and_parents(fake):
    plan = sync(client(), rendered(), load_endpoints(), apply=False, kinds=["projects"], environ=ENV_SECRETS)
    assert {i.kind for i in plan.items} == {"project"}


def test_errors_are_scrubbed_and_placeholders_refused(fake):
    with pytest.raises(FiddlerError):
        FiddlerAdmin("https://<fiddler-host-dev>", TOKEN)
    with pytest.raises(FiddlerError):
        FiddlerAdmin(BASE, "__REPLACE_ME_FIDDLER_API_KEY_DEV__")
    bad = FiddlerAdmin(BASE, "wrong-token-SUPERSECRET")
    with pytest.raises(FiddlerError) as e:
        bad.list("/v3/projects")
    assert "SUPERSECRET" not in str(e.value) and "HTTP 401" in str(e.value)


def test_registration_hook_provisions_only_that_agent_idempotently(fake):
    agent = {"agent_id": "uw-new", "owner": "jane@example.com", "team": "underwriting-ai", "status": "active"}
    out = provision_agent(Agent.from_mapping(agent), env="dev", fiddler_url=BASE, fiddler_api_key=TOKEN, root=ROOT, environ=ENV_SECRETS)
    assert not out["failed"]
    assert sorted(a["name"] for a in fake.apps.values()) == ["uw-new"] * 3
    assert len(fake.alerts) == 12 + 3 * 5 and len(fake.evaluators) == 12  # + invocation monitors
    again = provision_agent(Agent.from_mapping(agent), env="dev", fiddler_url=BASE, fiddler_api_key=TOKEN, root=ROOT, environ=ENV_SECRETS)
    assert again["items"] == []


def test_platform_api_hook_signature(fake, env_vars, monkeypatch):
    monkeypatch.setenv("AIG_FIDDLER_ROOT", str(ROOT))
    out = on_agent_registered({"agent_id": "claims-x", "owner": "bob@example.com", "team": "claims-ai"},
                              env="prod", fiddler_url=BASE, fiddler_api_key=TOKEN)
    assert out["applied"] and not out["failed"]
    assert [a["name"] for a in fake.apps.values()] == ["claims-x"]
