from __future__ import annotations

import shutil

import pytest
import yaml
from aig_fiddler.loader import ManifestError, load_repo
from aig_fiddler.registry import Agent, load_agents_file
from aig_fiddler.render import render, route_channels
from aig_fiddler.validate import validate
from conftest import REGISTRY, ROOT


@pytest.fixture
def repo():
    return load_repo(ROOT)


def copy_repo(tmp_path):
    dst = tmp_path / "fiddler"
    for d in ("manifests", "envs", "schemas"):
        shutil.copytree(ROOT / d, dst / d)
    # local overlay points at platform-api relative to the real repo
    local = dst / "envs" / "local.yaml"
    doc = yaml.safe_load(local.read_text())
    doc["registry"] = {"file": str(REGISTRY)}
    local.write_text(yaml.safe_dump(doc))
    return dst


def edit(path, fn):
    doc = yaml.safe_load(path.read_text())
    fn(doc)
    path.write_text(yaml.safe_dump(doc))


def test_repo_validates_with_placeholders_allowed(repo):
    rep = validate(repo, allow_placeholders=True)
    assert rep.ok, rep.errors
    assert set(rep.rendered) == {"local", "dev", "stage", "prod"}


def test_stage_and_prod_placeholders_are_errors(repo):
    rep = validate(repo)
    assert any("stage.yaml: fiddler_url" in e for e in rep.errors)
    assert any("prod.yaml: fiddler_url" in e for e in rep.errors)
    assert not any("dev.yaml" in e for e in rep.errors)


def test_schema_error_is_reported(tmp_path):
    root = copy_repo(tmp_path)
    edit(root / "manifests" / "trust.yaml", lambda d: d["spec"]["scores"][0].update(threshold=2))
    rep = validate(load_repo(root), allow_placeholders=True)
    assert any("trust.yaml" in e and "threshold" in e for e in rep.errors)


@pytest.mark.parametrize("mutate,needle", [
    (lambda d: d["spec"]["routes"][0]["channels"].append("nope"), "unknown channel 'nope'"),
    (lambda d: d["spec"]["routes"].pop(3), "agent_suspended"),
])
def test_alert_routing_cross_references(tmp_path, mutate, needle):
    root = copy_repo(tmp_path)
    edit(root / "manifests" / "alerts.yaml", mutate)
    rep = validate(load_repo(root), allow_placeholders=True)
    assert any(needle in e for e in rep.errors), rep.errors


def test_required_scores_and_monitors(tmp_path):
    root = copy_repo(tmp_path)
    edit(root / "manifests" / "trust.yaml", lambda d: d["spec"]["scores"].pop(2))  # pii
    edit(root / "manifests" / "monitors.yaml", lambda d: d["spec"]["monitors"].pop(1))  # latency-p95
    errors = validate(load_repo(root), allow_placeholders=True).errors
    assert any("'pii' is required" in e for e in errors)
    assert any("'latency-p95' is required" in e for e in errors)
    assert any("agent_overrides" not in e for e in errors)


def test_threshold_order_is_checked(tmp_path):
    root = copy_repo(tmp_path)
    edit(root / "envs" / "dev.yaml", lambda d: d.update(monitor_overrides={"error-rate": {"warning": 0.5, "critical": 0.1}}))
    errors = validate(load_repo(root), ["dev"], allow_placeholders=True).errors
    assert any("warning threshold" in e for e in errors)


def test_env_must_host_its_project(tmp_path):
    root = copy_repo(tmp_path)
    edit(root / "envs" / "prod.yaml", lambda d: d.update(projects=["aig-stage"]))
    errors = validate(load_repo(root), ["prod"], allow_placeholders=True).errors
    assert any("must host its own project 'aig-prod'" in e for e in errors)


def test_bad_yaml_and_unknown_kind(tmp_path):
    root = copy_repo(tmp_path)
    (root / "manifests" / "x.yaml").write_text("apiVersion: aig.fiddler/v1\nkind: Nope\nspec: {}\n")
    with pytest.raises(ManifestError):
        load_repo(root)


def test_render_one_application_per_agent_per_project(repo):
    agents = load_agents_file(REGISTRY)
    r = render(repo, "dev", agents)
    agent_ids = {a.agent_id for a in agents} | {"ide.vscode", "ide.eclipse", "web.portal"}
    apps = r.objects["applications"]
    assert {(a["project"], a["agent_id"]) for a in apps} == {(p, aid) for p in ("aig-local", "aig-workspace", "aig-dev") for aid in agent_ids}
    assert len(r.objects["evaluator_rules"]) == len(apps) * 4
    assert len([o for o in r.objects["alert_rules"] if "invocation" not in o]) == len(apps) * 4
    assert {o["name"] for o in r.objects["evaluator_rules"]} == {"aig-trust-hallucination", "aig-trust-toxicity", "aig-trust-pii", "aig-trust-jailbreak"}
    # suspended agents keep their application (include_suspended: true)
    assert any(a["agent_id"] == "legacy-claims-bot" for a in apps)


def test_threshold_precedence_and_env_overrides(repo):
    agent = Agent("uw-x", "jane@example.com", "underwriting-ai")
    prod = render(repo, "prod", [agent])
    err = next(o for o in prod.objects["alert_rules"] if o["name"] == "uw-x-error-rate")
    assert (err["warning_threshold"], err["critical_threshold"]) == (0.01, 0.03)
    jb = next(o for o in prod.objects["evaluator_rules"] if o["agent_id"] == "uw-x" and o["name"] == "aig-trust-jailbreak")
    assert jb["threshold"] == 0.4
    local = render(repo, "local", [agent])
    hall = next(o for o in local.objects["evaluator_rules"] if o["agent_id"] == "uw-x" and o["name"] == "aig-trust-hallucination")
    assert hall["enabled"] is False
    vs = next(o for o in local.objects["alert_rules"] if o["name"] == "ide.vscode-cost-per-day")
    assert vs["critical_threshold"] == 1000


def test_notification_routing(repo):
    agent = Agent("uw-x", "jane@example.com", "underwriting-ai")
    dev = render(repo, "dev", [agent])
    err = next(o for o in dev.objects["alert_rules"] if o["name"] == "uw-x-error-rate")  # HIGH
    assert err["notification"]["emails"] == ["jane@example.com"]
    assert err["notification"]["webhooks"] == ["aig-slack-platform", "aig-slack-underwriting"]
    assert err["notification"]["pagerduty_services"] == []  # disabled in dev
    prod = render(repo, "prod", [agent])
    err = next(o for o in prod.objects["alert_rules"] if o["name"] == "uw-x-error-rate")
    assert err["notification"]["pagerduty_services"] == ["aig-ai-platform"]
    assert err["notification"]["pagerduty_severity"] == "critical"
    assert "/traces?status=failing" in err["links"]["failing_traces"]
    assert route_channels(repo, "prod", event="agent_suspended", team="claims-ai") == ["slack-platform", "email-platform", "owner", "slack-claims"]
    assert route_channels(repo, "local", event="agent_suspended") == ["email-platform", "owner"]


def test_webhook_urls_are_secret_references(repo):
    r = render(repo, "prod", [])
    assert all(w["url"].startswith("<secret:AIG_ALERT_SLACK_WEBHOOK_") for w in r.objects["webhooks"])
