"""Per-agent invocation monitors (agent registry v2): error rate, latency p95, cost per caller team."""

from __future__ import annotations

import shutil

import pytest
import yaml
from aig_fiddler.client import FiddlerAdmin
from aig_fiddler.endpoints import load_endpoints
from aig_fiddler.hooks import provision_agent
from aig_fiddler.loader import load_repo
from aig_fiddler.plan import format_plan, sync
from aig_fiddler.registry import Agent, load_agents_file
from aig_fiddler.render import render
from aig_fiddler.validate import validate
from conftest import BASE, REGISTRY, ROOT, SLACK_URL, TOKEN

ENV_SECRETS = {v: SLACK_URL for v in ("AIG_ALERT_SLACK_WEBHOOK_PLATFORM", "AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING",
                                      "AIG_ALERT_SLACK_WEBHOOK_CLAIMS")}
AGENT = Agent("uw-quote", "jane@aig.example.com", "underwriting-ai")
TEAMS = ["aig-platform", "claims-ai", "underwriting-ai"]


def inv_rules(r, agent_id=None):
    return [a for a in r.objects["alert_rules"] if "invocation" in a and (agent_id is None or a["agent_id"] == agent_id)]


def test_rendered_per_agent_with_invocation_segment():
    r = render(load_repo(ROOT), "dev", [AGENT], fiddler_url=BASE, canaries=[])
    rules = {(a["project"], a["name"]): a for a in inv_rules(r)}
    names = {"uw-quote-invocation-error-rate", "uw-quote-invocation-latency-p95",
             *(f"uw-quote-invocation-cost-per-caller-team-{t}" for t in TEAMS)}
    assert set(rules) == {(p, n) for p in ("aig-local", "aig-workspace", "aig-dev") for n in names}
    err = rules[("aig-dev", "uw-quote-invocation-error-rate")]
    assert err["application"] == "uw-quote" and err["metric_id"] == "error_rate" and err["priority"] == "HIGH"
    assert err["segment"] == {"name": "invocation-error-rate", "definition": "\"aig.event_kind\" == 'invocation'"}
    assert err["invocation"]["error_statuses"] == ["failed", "timeout"]
    lat = rules[("aig-dev", "uw-quote-invocation-latency-p95")]
    assert lat["feature_names"] == ["aig.invocation.duration_ms"]
    assert lat["segment"]["definition"] == "\"aig.event_kind\" == 'invocation' and (\"aig.invocation.mode\" != 'background')"
    cost = rules[("aig-dev", "uw-quote-invocation-cost-per-caller-team-claims-ai")]
    assert cost["metric_id"] == "sum" and cost["feature_names"] == ["aig.cost_usd"] and cost["bin_size"] == "Day"
    assert cost["segment"] == {"name": "invocation-cost-per-caller-team-claims-ai",
                               "definition": "\"aig.event_kind\" == 'gateway' and \"aig.caller_team\" == 'claims-ai'"}
    assert cost["invocation"]["group"] == "claims-ai" and cost["invocation"]["event_kind"] == "gateway"
    assert err["invocation"]["event_kind"] == "invocation"
    # the calling team's channel is added to the owning team's routing (dev: Slack enabled)
    assert set(cost["notification"]["webhooks"]) == {"aig-slack-platform", "aig-slack-underwriting", "aig-slack-claims"}
    own = rules[("aig-dev", "uw-quote-invocation-cost-per-caller-team-underwriting-ai")]
    assert set(own["notification"]["webhooks"]) == {"aig-slack-platform", "aig-slack-underwriting"}
    assert "jane@aig.example.com" in cost["notification"]["emails"]


def test_builtin_agents_get_none_and_registry_teams_become_groups():
    agents = load_agents_file(REGISTRY) + [Agent("fin-bot", "f@x.com", "finance-ai")]
    r = render(load_repo(ROOT), "local", agents, fiddler_url=BASE, canaries=[])
    ids = {a["agent_id"] for a in inv_rules(r)}
    assert ids == {"uw-quote-assistant", "claims-triage.v2", "legacy-claims-bot", "fin-bot"}
    groups = {a["invocation"]["group"] for a in inv_rules(r, "uw-quote-assistant") if a["invocation"]["group"]}
    assert groups == {*TEAMS, "finance-ai"}


def test_threshold_precedence():
    repo = load_repo(ROOT)
    prod = {a["name"]: a for a in inv_rules(render(repo, "prod", [AGENT], fiddler_url=BASE, canaries=[]))}
    err = prod["uw-quote-invocation-error-rate"]
    assert (err["warning_threshold"], err["critical_threshold"]) == (0.02, 0.05)
    assert "aig-ai-platform" in err["notification"]["pagerduty_services"]  # HIGH pages in prod
    assert prod["uw-quote-invocation-cost-per-caller-team-claims-ai"]["critical_threshold"] == 250
    assert prod["uw-quote-invocation-latency-p95"]["critical_threshold"] == 90000  # manifest default
    local = {a["name"]: a for a in inv_rules(render(repo, "local", [Agent("uw-quote-assistant", "j@x.com", "underwriting-ai")],
                                                    fiddler_url=BASE, canaries=[]))}
    # agent override beats the env overlay
    assert local["uw-quote-assistant-invocation-latency-p95"]["critical_threshold"] == 120000
    assert local["uw-quote-assistant-invocation-latency-p95"]["warning_threshold"] == 45000
    assert local["uw-quote-assistant-invocation-error-rate"]["critical_threshold"] == 0.5


def test_manifest_is_optional(tmp_path):
    root = _copy(tmp_path)
    (root / "manifests" / "invocation-monitors.yaml").unlink()
    edit = root / "envs" / "local.yaml"
    doc = yaml.safe_load(edit.read_text())
    doc.pop("invocation_monitor_overrides")
    edit.write_text(yaml.safe_dump(doc))
    repo = load_repo(root)
    assert validate(repo, ["local", "dev"], allow_placeholders=True).ok
    assert not inv_rules(render(repo, "dev", [AGENT], fiddler_url=BASE, canaries=[]))


def _copy(tmp_path):
    dst = tmp_path / "fiddler"
    for d in ("manifests", "envs", "schemas"):
        shutil.copytree(ROOT / d, dst / d)
    local = dst / "envs" / "local.yaml"
    doc = yaml.safe_load(local.read_text())
    doc["registry"] = {"file": str(REGISTRY)}
    local.write_text(yaml.safe_dump(doc))
    return dst


def _mon(name):
    return lambda s: next(m for m in s["monitors"] if m["name"] == name)


@pytest.mark.parametrize("mutate,needle", [
    (lambda s: s["monitors"].pop(0), "'error-rate' is required"),
    (lambda s: _mon("cost-per-caller-team")(s).pop("group_by"), "must group_by aig.caller_team"),
    (lambda s: _mon("cost-per-caller-team")(s).update(group_by="aig.caller_user"), "only aig.caller_team"),
    (lambda s: _mon("latency-p95")(s).update(columns=["aig.latency_ms"]), "undeclared attribute 'aig.latency_ms'"),
    (lambda s: _mon("latency-p95")(s).update(filter="\"aig.mode\" == 'sync'"), "undeclared attribute 'aig.mode'"),
    (lambda s: s["attributes"].remove("aig.cost_usd"), "undeclared attribute 'aig.cost_usd'"),
    (lambda s: s["attributes"].remove("aig.event_kind"), "'aig.event_kind' is not a declared attribute"),
    (lambda s: s["error_statuses"].append("exploded"), "unknown status 'exploded'"),
    (lambda s: _mon("error-rate")(s).update(warning=5, critical=10), "thresholds are fractions"),
    (lambda s: _mon("latency-p95")(s).update(warning=100000), "warning threshold must not be past the critical one"),
    (lambda s: _mon("cost-per-caller-team")(s).update(columns=[]), "needs a column"),
    (lambda s: _mon("cost-per-caller-team")(s).pop("event_kind"), "invocation events carry no aig.cost_usd"),
    (lambda s: _mon("cost-per-caller-team")(s).update(event_kind="Gateway!"), "invocation-monitors.yaml"),  # schema
    (lambda s: s["monitors"].append(dict(s["monitors"][0])), "duplicate monitor names"),
    (lambda s: s.update(agent_overrides={"uw-quote-assistant": {"nope": {"warning": 1}}}), "agent_overrides.uw-quote-assistant.nope"),
    (lambda s: s.update(name_template="{agent_id}-{monitor}"), "name_template must differ"),
    (lambda s: _mon("error-rate")(s).update(warning=-1), "invocation-monitors.yaml"),  # schema: minimum 0
])
def test_invocation_monitor_validation(tmp_path, mutate, needle):
    root = _copy(tmp_path)
    p = root / "manifests" / "invocation-monitors.yaml"
    doc = yaml.safe_load(p.read_text())
    mutate(doc["spec"])
    p.write_text(yaml.safe_dump(doc))
    rep = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert not rep.ok and any(needle in e for e in rep.errors), rep.errors


@pytest.mark.parametrize("override,needle", [
    ({"nope": {"warning": 1}}, "invocation_monitor_overrides.nope: unknown invocation monitor"),
    ({"error-rate": {"warning": 0.5, "critical": 2}}, "thresholds are fractions"),
    ({"error-rate": {"warning": 0.5, "critical": 0.1}}, "warning threshold must not be past the critical one"),
])
def test_env_override_validation(tmp_path, override, needle):
    root = _copy(tmp_path)
    p = root / "envs" / "dev.yaml"
    doc = yaml.safe_load(p.read_text())
    doc["invocation_monitor_overrides"] = override
    p.write_text(yaml.safe_dump(doc))
    rep = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert not rep.ok and any(needle in e for e in rep.errors), rep.errors


def test_sync_creates_segmented_invocation_rules_idempotently(fake):
    r = render(load_repo(ROOT), "prod", [AGENT], fiddler_url=BASE, canaries=[])
    plan = sync(FiddlerAdmin(BASE, TOKEN), r, load_endpoints(), apply=True, environ=ENV_SECRETS)
    assert not plan.failed, format_plan(plan)
    app = next(a for a in fake.apps.values() if a["name"] == "uw-quote")
    rules = {a["name"]: a for a in fake.alerts.values() if "-invocation-" in a["name"]}
    assert len(rules) == 2 + len(TEAMS)
    assert {a["application_id"] for a in rules.values()} == {app["id"]}
    assert rules["uw-quote-invocation-cost-per-caller-team-aig-platform"]["segment"]["definition"].endswith(
        "\"aig.caller_team\" == 'aig-platform'")
    assert rules["uw-quote-invocation-error-rate"]["metric"] == {"id": "error_rate"}
    again = sync(FiddlerAdmin(BASE, TOKEN), r, load_endpoints(), apply=False, environ=ENV_SECRETS)
    assert set(again.counts()) == {"noop"}, format_plan(again)
    # a threshold edited by hand in Fiddler drifts back on the next apply
    rules["uw-quote-invocation-latency-p95"]["critical_threshold"] = 1
    drift = sync(FiddlerAdmin(BASE, TOKEN), r, load_endpoints(), apply=True, environ=ENV_SECRETS)
    assert [(i.kind, i.action, i.key) for i in drift.items if i.action != "noop"] == [
        ("alert_rule", "update", "aig-prod/uw-quote/uw-quote-invocation-latency-p95")]
    assert rules["uw-quote-invocation-latency-p95"]["critical_threshold"] == 90000


def test_registration_hook_includes_invocation_monitors(fake):
    out = provision_agent(AGENT, env="prod", fiddler_url=BASE, fiddler_api_key=TOKEN, root=ROOT, environ=ENV_SECRETS)
    assert not out["failed"]
    assert sum(1 for a in fake.alerts.values() if "-invocation-" in a["name"]) == 2 + len(TEAMS)
