from __future__ import annotations

import sys
from pathlib import Path

import pytest
import respx

sys.path.insert(0, str(Path(__file__).parent))

from fake_fiddler import BASE, TOKEN, FakeFiddler  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]  # backend/observability
REGISTRY = Path(__file__).resolve().parents[4] / "backend" / "platform-api" / "config" / "agents.example.yaml"
SLACK_URL = "https://hooks.slack.test/services/SUPERSECRET-slack-path"


@pytest.fixture
def fake():
    f = FakeFiddler()
    with respx.mock(assert_all_called=False) as router:
        f.mount(router)
        yield f


@pytest.fixture
def env_vars(monkeypatch):
    monkeypatch.setenv("FIDDLER_URL", BASE)
    monkeypatch.setenv("FIDDLER_API_KEY", TOKEN)
    for var in ("AIG_ALERT_SLACK_WEBHOOK_PLATFORM", "AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING", "AIG_ALERT_SLACK_WEBHOOK_CLAIMS"):
        monkeypatch.setenv(var, SLACK_URL)
