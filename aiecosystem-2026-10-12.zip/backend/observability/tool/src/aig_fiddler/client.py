"""Thin Fiddler REST client (Bearer token, held privately and scrubbed from errors)."""

from __future__ import annotations

import json
import os
from typing import Any

import httpx

URL_ENV = "FIDDLER_URL"
KEY_ENV = "FIDDLER_API_KEY"
PAGE_SIZE = 100
MAX_PAGES = 50


class FiddlerError(RuntimeError):
    pass


def is_placeholder(v: str | None) -> bool:
    return not v or "<" in v or "__" in v or "REPLACE_ME" in v.upper()


def eq_filter(**fields: str) -> str:
    """Fiddler's JSON filter query parameter (fiddler-evals QueryCondition)."""
    rules = [{"field": k, "operator": "equal", "value": str(v)} for k, v in fields.items()]
    return json.dumps({"condition": "AND", "rules": rules}, separators=(",", ":"))


class FiddlerAdmin:
    def __init__(self, base_url: str, token: str, *, timeout: float = 30.0,
                 transport: httpx.BaseTransport | None = None):
        if is_placeholder(base_url):
            raise FiddlerError(f"{URL_ENV} / fiddler_url is missing or a placeholder")
        if is_placeholder(token):
            raise FiddlerError(f"{KEY_ENV} is missing or a placeholder")
        self._token = token
        self._redact = [token]
        self._http = httpx.Client(
            base_url=base_url.rstrip("/"), timeout=timeout, transport=transport,
            headers={"authorization": f"Bearer {token}", "accept": "application/json", "content-type": "application/json"},
        )

    @classmethod
    def from_env(cls, fiddler_url: str | None = None, environ: dict | None = None, **kw) -> "FiddlerAdmin":
        environ = os.environ if environ is None else environ
        url = environ.get(URL_ENV) or fiddler_url or ""
        return cls(url.strip(), environ.get(KEY_ENV, "").strip(), **kw)

    def add_redaction(self, *values: str) -> None:
        self._redact += [v for v in values if v]

    def __repr__(self) -> str:
        return f"FiddlerAdmin(base_url={str(self._http.base_url)!r})"

    def close(self) -> None:
        self._http.close()

    def _scrub(self, text: str) -> str:
        for s in self._redact:
            text = text.replace(s, "***")
        return text

    def request(self, method: str, path: str, *, body: Any = None, params: dict | None = None) -> Any:
        try:
            r = self._http.request(method, path, json=body, params=params)
        except httpx.HTTPError as exc:
            raise FiddlerError(f"{method} {path}: {type(exc).__name__}") from None
        if r.status_code >= 400:
            raise FiddlerError(f"{method} {path}: HTTP {r.status_code}: {self._scrub(r.text[:300])}")
        if not r.content:
            return None
        try:
            data = r.json()
        except ValueError:
            return None
        return data.get("data", data) if isinstance(data, dict) else data

    def list(self, path: str, *, filter: str | None = None) -> list[dict]:
        """Every item across offset pages (``data.items`` / ``data`` list / bare list)."""
        out: list[dict] = []
        offset = 0
        for _ in range(MAX_PAGES):
            params: dict[str, Any] = {"limit": PAGE_SIZE, "offset": offset}
            if filter:
                params["filter"] = filter
            data = self.request("GET", path, params=params)
            if isinstance(data, dict) and "items" in data:
                items = data.get("items") or []
                out += [i for i in items if isinstance(i, dict)]
                page_index, page_count = data.get("page_index"), data.get("page_count")
                if not items or page_index is None or page_count is None or page_index >= page_count:
                    return out
                offset = int(data.get("offset", offset)) + PAGE_SIZE
                continue
            if isinstance(data, list):
                return out + [i for i in data if isinstance(i, dict)]
            return out
        return out

    def create(self, path: str, body: dict) -> dict:
        data = self.request("POST", path, body=body)
        return data if isinstance(data, dict) else {}

    def update(self, path: str, body: dict, method: str = "PATCH") -> dict:
        data = self.request(method, path, body=body)
        return data if isinstance(data, dict) else {}

    def delete(self, path: str) -> None:
        self.request("DELETE", path)
