"""Fiddler REST API paths: the ONE place to adjust for AIG's Fiddler version.

Verified against the installed Fiddler packages (fiddler-client 3.14.1, fiddler-evals 0.6.0,
fiddler-otel 1.4.1, inspected Oct 2026):

- Auth header ``Authorization: Bearer <token>`` (fiddler-evals Connection).
- ``GET/POST /v3/projects``; create body ``{"name", "asset_type": "GEN_AI_APP"}``; list
  responses ``{"data": {"items": [...], "total", "page_index", "page_count", "offset"}}`` with
  ``limit``/``offset`` paging and a JSON ``filter`` query parameter
  (``{"condition": "AND", "rules": [{"field", "operator": "equal", "value"}]}``).
- ``GET/POST /v3/applications``; create body ``{"name", "project_id"}``; filter on
  ``project_id`` / ``name``.
- ``POST /v3/spans/fields`` ``{"application_id", "start_time", "end_time", "filter"?}`` ->
  ``data.total_spans``, ``data.sampled`` (used by telemetry-bridge reconciliation).
- ``/v2/webhooks`` (``name``, ``url``, ``provider`` SLACK|MS_TEAMS|OTHER; response id field
  ``uuid``).
- ``/v3/alert-rules`` create/patch fields and ``PATCH /v3/alert-rules/{id}/notification``
  ``{"emails", "pagerduty_services", "pagerduty_severity", "webhooks": [uuid]}``.
- OTLP/HTTP ingestion ``{url}/v1/traces`` with ``authorization: Bearer`` and
  ``fiddler-application-id`` headers (fiddler-otel FiddlerClient).

ASSUMED (not in any installed package; confirm with AIG's Fiddler team):

- Alert rules for GenAI applications are keyed by ``application_id`` (fiddler-client only
  shows ``model_id`` for ML models) and the metric ids in manifests/monitors.yaml exist.
- Online evaluator (trust score) rules live at ``/v3/applications/{application_id}/evaluator-rules``
  with body ``{"name", "evaluator", "outputs", "threshold", "direction", "enabled", "sampling_rate"}``.

Override any path without code changes: ``AIG_FIDDLER_ENDPOINTS_FILE`` = YAML such as
``evaluator_rules: {list: /v3/evaluator-rules, create: /v3/evaluator-rules}``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, replace
from pathlib import Path

import yaml


@dataclass(frozen=True)
class Endpoint:
    list: str
    create: str
    update: str
    delete: str
    id_field: str = "id"
    update_method: str = "PATCH"


DEFAULT_ENDPOINTS: dict[str, Endpoint] = {
    "projects": Endpoint("/v3/projects", "/v3/projects", "/v3/projects/{id}", "/v3/projects/{id}"),
    "applications": Endpoint("/v3/applications", "/v3/applications", "/v3/applications/{id}", "/v3/applications/{id}"),
    "webhooks": Endpoint("/v2/webhooks", "/v2/webhooks", "/v2/webhooks/{id}", "/v2/webhooks/{id}", id_field="uuid"),
    "evaluator_rules": Endpoint(
        "/v3/applications/{application_id}/evaluator-rules",
        "/v3/applications/{application_id}/evaluator-rules",
        "/v3/applications/{application_id}/evaluator-rules/{id}",
        "/v3/applications/{application_id}/evaluator-rules/{id}",
    ),
    "alert_rules": Endpoint("/v3/alert-rules", "/v3/alert-rules", "/v3/alert-rules/{id}", "/v3/alert-rules/{id}"),
    "alert_notification": Endpoint(
        "/v3/alert-rules/{id}/notification", "/v3/alert-rules/{id}/notification",
        "/v3/alert-rules/{id}/notification", "/v3/alert-rules/{id}/notification",
    ),
    "span_fields": Endpoint("/v3/spans/fields", "/v3/spans/fields", "", ""),
}


def load_endpoints(path: str | os.PathLike | None = None) -> dict[str, Endpoint]:
    path = path or os.environ.get("AIG_FIDDLER_ENDPOINTS_FILE")
    endpoints = dict(DEFAULT_ENDPOINTS)
    if not path:
        return endpoints
    overrides = yaml.safe_load(Path(path).read_text()) or {}
    for kind, values in overrides.items():
        if kind not in endpoints:
            raise ValueError(f"{path}: unknown endpoint kind {kind!r}")
        endpoints[kind] = replace(endpoints[kind], **(values or {}))
    return endpoints
