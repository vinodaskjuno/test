"""Hook platform-api calls when an agent registers (``AIG_FIDDLER_AUTOPROVISION=true``).

    from aig_fiddler.hooks import on_agent_registered
    on_agent_registered({"agent_id": "uw-quote", "owner": "a@x.com", "team": "underwriting-ai"},
                        env="dev", fiddler_url=..., fiddler_api_key=...)

Creates (idempotently) the agent's application in every project of the env overlay, plus its
trust-score evaluator rules, monitors and their notification routing, i.e. exactly what
``fiddler-sync apply`` would create for that one agent. Manifests are read from
``AIG_FIDDLER_ROOT`` (default: the repo checkout this package was installed from).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

import httpx

from .client import FiddlerAdmin
from .endpoints import load_endpoints
from .loader import load_repo
from .plan import sync
from .registry import Agent
from .render import render


def provision_agent(agent: Agent, *, env: str, fiddler_url: str | None = None, fiddler_api_key: str | None = None,
                    root: Path | None = None, apply: bool = True, transport: httpx.BaseTransport | None = None,
                    environ: Mapping[str, str] | None = None) -> dict[str, Any]:
    import os

    environ = os.environ if environ is None else environ
    repo = load_repo(root)
    url = fiddler_url or environ.get("FIDDLER_URL") or repo.env(env)["fiddler_url"]
    key = fiddler_api_key or environ.get("FIDDLER_API_KEY", "")
    client = FiddlerAdmin(url, key, transport=transport)
    try:
        rendered = render(repo, env, [agent], fiddler_url=url).only_agent(agent.agent_id)
        plan = sync(client, rendered, load_endpoints(), apply=apply, environ=environ)
    finally:
        client.close()
    return {"agent_id": agent.agent_id, "env": env, "applied": apply, "counts": plan.counts(),
            "failed": plan.failed, "items": [i.as_dict() for i in plan.items if i.action != "noop"]}


def on_agent_registered(agent: Mapping[str, Any], *, env: str, fiddler_url: str | None = None,
                        fiddler_api_key: str | None = None, **_: Any) -> dict[str, Any]:
    """platform-api hook signature (see backend/platform-api/src/platform_api/agent_hooks.py)."""
    return provision_agent(Agent.from_mapping(agent), env=env, fiddler_url=fiddler_url, fiddler_api_key=fiddler_api_key)
