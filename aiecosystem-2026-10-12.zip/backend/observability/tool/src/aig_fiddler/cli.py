"""fiddler-sync: validate, render, diff and apply backend/observability against Fiddler.

  fiddler-sync validate [--env ENV ...] [--allow-placeholders]
  fiddler-sync render   --env ENV [--registry-file F | --registry-url U] [--kind KIND ...]
  fiddler-sync diff     --env ENV [registry] [--kind KIND ...] [--json] [--exit-code]
  fiddler-sync apply    --env ENV [registry] [--kind KIND ...] [--yes] [--json]
  fiddler-sync provision-agent --env ENV --agent-id ID --team TEAM --owner EMAIL [--yes]

apply/provision-agent are DRY RUNS unless --yes. Nothing is deleted (an alert rule whose
immutable fields changed is recreated). diff/apply read FIDDLER_URL (else the overlay's
fiddler_url) and FIDDLER_API_KEY; a platform-api registry needs AIG_PLATFORM_SERVICE_TOKEN.
Secret values are never printed.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .client import FiddlerAdmin, FiddlerError
from .endpoints import load_endpoints
from .loader import ENVS, ManifestError, load_repo
from .plan import format_plan, sync
from .registry import Agent, RegistryError, load_agents_file, load_agents_url
from .render import KINDS, render
from .validate import validate


def _repo(args):
    return load_repo(Path(args.root) if args.root else None)


def _agents(repo, args) -> list[Agent]:
    if args.registry_file:
        return load_agents_file(Path(args.registry_file))
    if args.registry_url:
        return load_agents_url(args.registry_url)
    reg = repo.env(args.env)["registry"]
    if "file" in reg:
        return load_agents_file((repo.root / "envs" / reg["file"]).resolve())
    return load_agents_url(reg["url"])


def cmd_validate(args) -> int:
    repo = _repo(args)
    rep = validate(repo, args.env or None, allow_placeholders=args.allow_placeholders)
    for w in rep.warnings:
        print(f"warning: {w}")
    for e in rep.errors:
        print(f"error: {e}", file=sys.stderr)
    if rep.ok:
        print(f"validate: OK ({len(repo.manifests)} manifests, envs: {', '.join(rep.rendered)})")
        return 0
    print(f"validate: FAILED ({len(rep.errors)} error(s))", file=sys.stderr)
    return 1


def _rendered(args):
    repo = _repo(args)
    rep = validate(repo, [args.env], allow_placeholders=True)
    if not rep.ok:
        for e in rep.errors:
            print(f"error: {e}", file=sys.stderr)
        raise SystemExit(1)
    import os
    return repo, render(repo, args.env, _agents(repo, args), fiddler_url=os.environ.get("FIDDLER_URL") or None)


def cmd_render(args) -> int:
    _, r = _rendered(args)
    objects = {k: v for k, v in r.objects.items() if not args.kind or k in args.kind}
    print(json.dumps({"env": r.env, "fiddler_url": r.fiddler_url, "objects": objects}, indent=2))
    return 0


def _run(args, apply: bool) -> int:
    _, r = _rendered(args)
    client = FiddlerAdmin.from_env(r.fiddler_url)
    try:
        plan = sync(client, r, load_endpoints(), apply=apply, kinds=args.kind)
    finally:
        client.close()
    print(json.dumps(plan.as_dict(), indent=2) if args.json else format_plan(plan))
    if plan.failed:
        return 1
    if getattr(args, "exit_code", False) and plan.has_changes:
        return 2
    return 0


def cmd_diff(args) -> int:
    return _run(args, apply=False)


def cmd_apply(args) -> int:
    if not args.yes and not args.json:
        print("DRY RUN (pass --yes to apply)")
    return _run(args, apply=args.yes)


def cmd_provision(args) -> int:
    from .hooks import provision_agent

    agent = Agent(args.agent_id, args.owner, args.team)
    result = provision_agent(agent, env=args.env, root=Path(args.root) if args.root else None, apply=args.yes)
    print(json.dumps(result, indent=2))
    return 1 if result["failed"] else 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="fiddler-sync", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--root", help="path to backend/observability (default: auto / AIG_FIDDLER_ROOT)")
    sub = p.add_subparsers(dest="cmd", required=True)

    v = sub.add_parser("validate")
    v.add_argument("--env", action="append", choices=ENVS)
    v.add_argument("--allow-placeholders", action="store_true")
    v.set_defaults(fn=cmd_validate)

    def common(sp, kinds=True):
        sp.add_argument("--env", required=True, choices=ENVS)
        g = sp.add_mutually_exclusive_group()
        g.add_argument("--registry-file", help="agent registry YAML (platform-api format)")
        g.add_argument("--registry-url", help="platform-api base URL (GET /api/v1/agents)")
        if kinds:
            sp.add_argument("--kind", action="append", choices=KINDS)

    r = sub.add_parser("render")
    common(r)
    r.set_defaults(fn=cmd_render)
    d = sub.add_parser("diff")
    common(d)
    d.add_argument("--json", action="store_true")
    d.add_argument("--exit-code", action="store_true", help="exit 2 when there are changes")
    d.set_defaults(fn=cmd_diff)
    a = sub.add_parser("apply")
    common(a)
    a.add_argument("--yes", action="store_true", help="really write (default: dry run)")
    a.add_argument("--json", action="store_true")
    a.set_defaults(fn=cmd_apply)
    pa = sub.add_parser("provision-agent", help="what the platform-api registration hook does, for one agent")
    pa.add_argument("--env", required=True, choices=ENVS)
    pa.add_argument("--agent-id", required=True)
    pa.add_argument("--team", required=True)
    pa.add_argument("--owner", required=True)
    pa.add_argument("--yes", action="store_true")
    pa.set_defaults(fn=cmd_provision)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args)
    except (ManifestError, RegistryError, FiddlerError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
