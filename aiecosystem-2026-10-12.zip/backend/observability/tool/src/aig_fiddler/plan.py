"""diff / apply: walk the rendered objects in dependency order against the live Fiddler.

Order: projects -> applications -> webhooks -> evaluator rules (trust scores) -> alert rules
(+ notification config). Diff and apply share one walk: in a dry run, children of objects that
do not exist yet are all ``create``. Only fields the manifests declare are compared, so
server-side fields never show as drift. Nothing is ever deleted except an alert rule whose
immutable fields changed (``recreate``). Secrets (Slack webhook URLs) are read from the env
only when sent and are never printed; without them a webhook create is ``blocked``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any

from .client import FiddlerAdmin, eq_filter
from .endpoints import Endpoint
from .render import Rendered

ALERT_MUTABLE = ("warning_threshold", "critical_threshold", "evaluation_delay")
ALERT_IMMUTABLE = ("metric_id", "feature_names", "condition", "bin_size", "compare_to", "compare_bin_delta", "priority")
EVAL_FIELDS = ("evaluator", "outputs", "threshold", "direction", "enabled", "sampling_rate")
NOTIFY_FIELDS = ("emails", "pagerduty_services", "pagerduty_severity", "webhooks")


@dataclass
class Item:
    kind: str
    action: str  # create | update | recreate | noop | blocked | error
    key: str
    changes: dict[str, Any] = field(default_factory=dict)
    detail: str = ""

    def as_dict(self) -> dict:
        return {"kind": self.kind, "action": self.action, "key": self.key, "changes": self.changes, "detail": self.detail}


@dataclass
class Plan:
    env: str
    applied: bool
    items: list[Item] = field(default_factory=list)

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for i in self.items:
            out[i.action] = out.get(i.action, 0) + 1
        return out

    @property
    def has_changes(self) -> bool:
        return any(i.action not in ("noop",) for i in self.items)

    @property
    def failed(self) -> bool:
        return any(i.action in ("blocked", "error") for i in self.items)

    def as_dict(self) -> dict:
        return {"env": self.env, "applied": self.applied, "counts": self.counts(), "items": [i.as_dict() for i in self.items]}


SYMBOL = {"create": "+", "update": "~", "recreate": "-/+", "noop": "=", "blocked": "!", "error": "!"}


def format_plan(plan: Plan, *, show_noop: bool = False) -> str:
    lines = [f"Fiddler plan for env={plan.env} ({'APPLIED' if plan.applied else 'DRY RUN'})"]
    for i in plan.items:
        if i.action == "noop" and not show_noop:
            continue
        line = f"  {SYMBOL.get(i.action, '?'):>3} {i.action:<8} {i.kind:<16} {i.key}"
        if i.changes:
            line += "  " + ", ".join(f"{k}: {v.get('from')!r} -> {v.get('to')!r}" for k, v in i.changes.items())
        if i.detail:
            line += f"  ({i.detail})"
        lines.append(line)
    counts = plan.counts()
    lines.append("  summary: " + (", ".join(f"{k}={v}" for k, v in sorted(counts.items())) or "nothing to do"))
    return "\n".join(lines)


def _norm(v: Any) -> Any:
    if isinstance(v, list):
        return sorted(_norm(x) for x in v) if all(isinstance(x, str) for x in v) else [_norm(x) for x in v]
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def _empty(v: Any) -> bool:
    return v is None or v == [] or v == ""


def _changes(desired: dict, remote: dict, fields: tuple[str, ...]) -> dict:
    out = {}
    for f in fields:
        d, r = desired.get(f), remote.get(f)
        if f == "feature_names" and r is None:
            r = remote.get("columns")
        if f == "metric_id" and r is None and isinstance(remote.get("metric"), dict):
            r = remote["metric"].get("id")
        if _empty(d) and _empty(r):
            continue
        if _norm(d) != _norm(r):
            out[f] = {"from": r, "to": d}
    return out


class Syncer:
    def __init__(self, client: FiddlerAdmin, endpoints: dict[str, Endpoint], *, apply: bool, environ=None):
        self.c = client
        self.ep = endpoints
        self.apply = apply
        self.environ = os.environ if environ is None else environ
        self.project_ids: dict[str, str] = {}
        self.app_ids: dict[tuple[str, str], str] = {}
        self.webhook_ids: dict[str, str] = {}

    def _id(self, obj: dict, ep: Endpoint) -> str:
        return str(obj.get(ep.id_field) or obj.get("id") or obj.get("uuid") or "")

    # -- kinds -----------------------------------------------------------------------------

    def projects(self, desired: list[dict], plan: Plan) -> None:
        ep = self.ep["projects"]
        remote = {p.get("name"): p for p in self.c.list(ep.list)}
        for d in desired:
            r = remote.get(d["name"])
            if r:
                self.project_ids[d["name"]] = self._id(r, ep)
                plan.items.append(Item("project", "noop", d["name"]))
                continue
            plan.items.append(Item("project", "create", d["name"]))
            if self.apply:
                created = self.c.create(ep.create, {"name": d["name"], "asset_type": d["asset_type"]})
                self.project_ids[d["name"]] = self._id(created, ep)

    def applications(self, desired: list[dict], plan: Plan) -> None:
        ep = self.ep["applications"]
        remote: dict[str, dict[str, dict]] = {}
        for project, pid in self.project_ids.items():
            if pid:
                remote[project] = {a.get("name"): a for a in self.c.list(ep.list, filter=eq_filter(project_id=pid))}
        for d in desired:
            key = f"{d['project']}/{d['application']}"
            r = remote.get(d["project"], {}).get(d["application"])
            if r:
                self.app_ids[(d["project"], d["application"])] = self._id(r, ep)
                plan.items.append(Item("application", "noop", key))
                continue
            plan.items.append(Item("application", "create", key, detail=f"agent {d['agent_id']} team {d['team']}"))
            if self.apply:
                pid = self.project_ids.get(d["project"])
                if not pid:
                    plan.items[-1].action, plan.items[-1].detail = "error", "project id unknown"
                    continue
                created = self.c.create(ep.create, {"name": d["application"], "project_id": pid})
                self.app_ids[(d["project"], d["application"])] = self._id(created, ep)

    def webhooks(self, desired: list[dict], plan: Plan) -> None:
        ep = self.ep["webhooks"]
        remote = {w.get("name"): w for w in self.c.list(ep.list)}
        for d in desired:
            r = remote.get(d["name"])
            if r:
                self.webhook_ids[d["name"]] = self._id(r, ep)
                changes = _changes(d, r, ("provider",))
                if not changes:
                    plan.items.append(Item("webhook", "noop", d["name"]))
                    continue
                action = "update"
            else:
                changes, action = {}, "create"
            url = (self.environ.get(d["url_env"]) or "").strip()
            if not url or "<" in url or "__" in url:
                plan.items.append(Item("webhook", "blocked", d["name"], changes, f"set {d['url_env']} to send the Slack URL"))
                continue
            plan.items.append(Item("webhook", action, d["name"], changes))
            if self.apply:
                self.c.add_redaction(url)
                body = {"name": d["name"], "url": url, "provider": d["provider"]}
                if action == "create":
                    self.webhook_ids[d["name"]] = self._id(self.c.create(ep.create, body), ep)
                else:
                    self.c.update(ep.update.format(id=self.webhook_ids[d["name"]]), body, ep.update_method)

    def evaluator_rules(self, desired: list[dict], plan: Plan) -> None:
        ep = self.ep["evaluator_rules"]
        cache: dict[str, dict[str, dict]] = {}
        for d in desired:
            key = f"{d['project']}/{d['application']}/{d['name']}"
            app_id = self.app_ids.get((d["project"], d["application"]))
            remote = {}
            if app_id:
                if app_id not in cache:
                    cache[app_id] = {r.get("name"): r for r in self.c.list(ep.list.format(application_id=app_id))}
                remote = cache[app_id]
            body = {k: d[k] for k in ("name", *EVAL_FIELDS, "aggregate")}
            r = remote.get(d["name"])
            if r:
                changes = _changes(d, r, EVAL_FIELDS)
                if not changes:
                    plan.items.append(Item("evaluator_rule", "noop", key))
                    continue
                plan.items.append(Item("evaluator_rule", "update", key, changes))
                if self.apply:
                    self.c.update(ep.update.format(application_id=app_id, id=self._id(r, ep)), body, ep.update_method)
                continue
            plan.items.append(Item("evaluator_rule", "create", key))
            if self.apply:
                if not app_id:
                    plan.items[-1].action, plan.items[-1].detail = "error", "application id unknown"
                    continue
                self.c.create(ep.create.format(application_id=app_id), body)

    def _notification_body(self, d: dict) -> tuple[dict, list[str]]:
        n = dict(d["notification"])
        missing = [w for w in n.get("webhooks", []) if w not in self.webhook_ids]
        n["webhooks"] = sorted(self.webhook_ids[w] for w in n.get("webhooks", []) if w in self.webhook_ids)
        return {k: v for k, v in n.items() if v not in (None, [])}, missing

    def alert_rules(self, desired: list[dict], plan: Plan) -> None:
        ep = self.ep["alert_rules"]
        nep = self.ep["alert_notification"]
        cache: dict[str, dict[str, dict]] = {}
        for d in desired:
            key = f"{d['project']}/{d['application']}/{d['name']}"
            app_id = self.app_ids.get((d["project"], d["application"]))
            remote = {}
            if app_id:
                if app_id not in cache:
                    cache[app_id] = {r.get("name"): r for r in self.c.list(ep.list, filter=eq_filter(application_id=app_id))}
                remote = cache[app_id]
            create_body = {k: d[k] for k in ("name", "metric_id", "priority", "compare_to", "condition", "bin_size",
                                             "threshold_type", "critical_threshold", "warning_threshold",
                                             "feature_names", "evaluation_delay")}
            if d.get("compare_bin_delta"):
                create_body["compare_bin_delta"] = d["compare_bin_delta"]
            if d.get("segment"):
                # Canary (candidate) and invocation monitors: segment (ASSUMED inline segment definition).
                create_body["segment"] = d["segment"]
            create_body["category"] = "aig"
            notify, missing_hooks = self._notification_body(d)
            detail = f"webhooks not yet created: {', '.join(missing_hooks)}" if missing_hooks and self.apply else ""
            r = remote.get(d["name"])
            if r is None:
                plan.items.append(Item("alert_rule", "create", key, detail=detail))
                if self.apply:
                    if not app_id:
                        plan.items[-1].action, plan.items[-1].detail = "error", "application id unknown"
                        continue
                    created = self.c.create(ep.create, {**create_body, "application_id": app_id})
                    self.c.update(nep.update.format(id=self._id(created, ep)), notify, nep.update_method)
                continue
            rid = self._id(r, ep)
            immutable = _changes(d, r, ALERT_IMMUTABLE)
            if immutable:
                plan.items.append(Item("alert_rule", "recreate", key, immutable, detail))
                if self.apply:
                    self.c.delete(ep.delete.format(id=rid))
                    created = self.c.create(ep.create, {**create_body, "application_id": app_id})
                    self.c.update(nep.update.format(id=self._id(created, ep)), notify, nep.update_method)
                continue
            changes = _changes(d, r, ALERT_MUTABLE)
            remote_notify = self.c.request("GET", nep.list.format(id=rid)) or {}
            n_changes = _changes(notify, remote_notify if isinstance(remote_notify, dict) else {}, NOTIFY_FIELDS)
            changes.update({f"notification.{k}": v for k, v in n_changes.items()})
            if not changes:
                plan.items.append(Item("alert_rule", "noop", key))
                continue
            plan.items.append(Item("alert_rule", "update", key, changes, detail))
            if self.apply:
                if any(not k.startswith("notification.") for k in changes):
                    self.c.update(ep.update.format(id=rid), {k: d[k] for k in ALERT_MUTABLE}, ep.update_method)
                if n_changes:
                    self.c.update(nep.update.format(id=rid), notify, nep.update_method)


def sync(client: FiddlerAdmin, rendered: Rendered, endpoints: dict[str, Endpoint], *, apply: bool,
         kinds: list[str] | None = None, environ=None) -> Plan:
    plan = Plan(rendered.env, apply)
    s = Syncer(client, endpoints, apply=apply, environ=environ)
    o = rendered.objects
    want = set(kinds or ["projects", "applications", "webhooks", "evaluator_rules", "alert_rules"])
    # Parents of a requested kind are always walked (and created on apply): their ids are needed.
    for kind, fn in (("projects", s.projects), ("applications", s.applications), ("webhooks", s.webhooks),
                     ("evaluator_rules", s.evaluator_rules), ("alert_rules", s.alert_rules)):
        parent = kind in ("projects", "applications") and bool(want & {"applications", "evaluator_rules", "alert_rules"})
        if kind == "webhooks" and "alert_rules" in want:
            parent = True
        if kind in want or parent:
            fn(o[kind], plan)
    return plan
