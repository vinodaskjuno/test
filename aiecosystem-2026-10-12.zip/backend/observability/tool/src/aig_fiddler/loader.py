"""Load and schema-check backend/observability (manifests/, envs/, schemas/)."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator, FormatChecker

ENVS: tuple[str, ...] = ("local", "dev", "stage", "prod")
KIND_SCHEMAS = {
    "Projects": "projects.schema.json",
    "Applications": "applications.schema.json",
    "TrustScores": "trust.schema.json",
    "Monitors": "monitors.schema.json",
    "AlertRouting": "alerts.schema.json",
    "CanaryMonitors": "canary-monitors.schema.json",
    "InvocationMonitors": "invocation-monitors.schema.json",
}
ROOT_ENV = "AIG_FIDDLER_ROOT"


class ManifestError(RuntimeError):
    pass


def default_root() -> Path:
    env = os.environ.get(ROOT_ENV)
    if env:
        return Path(env)
    # src/aig_fiddler/loader.py -> backend/observability (editable install / repo checkout)
    return Path(__file__).resolve().parents[3]


@dataclass
class Repo:
    root: Path
    manifests: dict[str, dict] = field(default_factory=dict)  # kind -> document
    envs: dict[str, dict] = field(default_factory=dict)
    schemas: dict[str, dict] = field(default_factory=dict)
    sources: dict[str, Path] = field(default_factory=dict)

    def spec(self, kind: str) -> dict:
        try:
            return self.manifests[kind]["spec"]
        except KeyError:
            raise ManifestError(f"no {kind} manifest under {self.root / 'manifests'}") from None

    def env(self, name: str) -> dict:
        try:
            return self.envs[name]
        except KeyError:
            raise ManifestError(f"no env overlay envs/{name}.yaml") from None

    def schema_errors(self) -> list[str]:
        errors: list[str] = []
        for kind, doc in self.manifests.items():
            errors += _errors(self.schemas[KIND_SCHEMAS[kind]], doc, self.sources[kind].name)
        for name, doc in self.envs.items():
            errors += _errors(self.schemas["env.schema.json"], doc, f"envs/{name}.yaml")
        return errors


def _errors(schema: dict, doc: dict, label: str) -> list[str]:
    v = Draft202012Validator(schema, format_checker=FormatChecker())
    return [f"{label}: {'/'.join(map(str, e.absolute_path)) or '<root>'}: {e.message}" for e in v.iter_errors(doc)]


def _yaml(path: Path) -> dict:
    try:
        data = yaml.safe_load(path.read_text())
    except yaml.YAMLError as exc:
        raise ManifestError(f"{path.name}: invalid YAML: {exc}") from None
    if not isinstance(data, dict):
        raise ManifestError(f"{path.name}: must be a mapping")
    return data


def load_repo(root: Path | None = None) -> Repo:
    root = Path(root) if root else default_root()
    if not (root / "manifests").is_dir():
        raise ManifestError(f"{root} has no manifests/ (set {ROOT_ENV} to backend/observability)")
    repo = Repo(root=root)
    for p in sorted((root / "schemas").glob("*.schema.json")):
        repo.schemas[p.name] = json.loads(p.read_text())
    for p in sorted((root / "manifests").glob("*.yaml")):
        doc = _yaml(p)
        kind = doc.get("kind")
        if kind not in KIND_SCHEMAS:
            raise ManifestError(f"{p.name}: unknown kind {kind!r}")
        if kind in repo.manifests:
            raise ManifestError(f"{p.name}: second {kind} manifest")
        repo.manifests[kind] = doc
        repo.sources[kind] = p
    for p in sorted((root / "envs").glob("*.yaml")):
        repo.envs[p.stem] = _yaml(p)
    return repo
