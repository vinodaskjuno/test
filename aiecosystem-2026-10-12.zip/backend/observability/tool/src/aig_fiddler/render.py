"""Render the desired Fiddler objects for one env and a list of registered agents.

Precedence for thresholds: manifest < env overlay (``trust_overrides`` / ``monitor_overrides`` /
``invocation_monitor_overrides``) < per-agent ``agent_overrides`` (monitors, invocation monitors). Secrets are never resolved here: webhook URLs are
rendered as ``<secret:ENV_VAR>`` and read from the environment only by ``apply``.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import yaml

from .loader import ManifestError, Repo
from .registry import BUILTIN_OWNER, BUILTIN_TEAM, Agent, with_builtins

KINDS: tuple[str, ...] = ("projects", "applications", "webhooks", "evaluator_rules", "alert_rules")


@dataclass
class Rendered:
    env: str
    fiddler_url: str
    objects: dict[str, list[dict]] = field(default_factory=dict)

    def only_agent(self, agent_id: str) -> "Rendered":
        """Objects needed for one agent (shared objects included)."""
        out = Rendered(self.env, self.fiddler_url, {k: list(v) for k, v in self.objects.items()})
        for kind in ("applications", "evaluator_rules", "alert_rules"):
            out.objects[kind] = [o for o in self.objects[kind] if o["agent_id"] == agent_id]
        return out


def secret_ref(env_var: str) -> str:
    return f"<secret:{env_var}>"


def effective_trust(repo: Repo, env: str) -> list[dict]:
    overrides = repo.env(env).get("trust_overrides") or {}
    scores = []
    for s in repo.spec("TrustScores")["scores"]:
        s = {**copy.deepcopy(s), **overrides.get(s["name"], {})}
        scores.append(s)
    return scores


def effective_monitors(repo: Repo, env: str, agent_id: str) -> list[dict]:
    spec = repo.spec("Monitors")
    env_over = repo.env(env).get("monitor_overrides") or {}
    agent_over = (spec.get("agent_overrides") or {}).get(agent_id, {})
    return [{**copy.deepcopy(m), **env_over.get(m["name"], {}), **agent_over.get(m["name"], {})} for m in spec["monitors"]]


def route_channels(repo: Repo, env: str, *, priority: str | None = None, event: str | None = None,
                   team: str | None = None, extra_teams: Iterable[str] = ()) -> list[str]:
    """Channel names for an alert, minus the env's disabled channels, plus the team's channels
    (and those of ``extra_teams``, e.g. the calling team of a cost-per-caller-team rule)."""
    spec = repo.spec("AlertRouting")
    disabled = set(repo.env(env).get("disabled_channels") or [])
    chosen: list[str] = []
    for route in spec["routes"]:
        m = route["match"]
        if ("priority" in m and m["priority"] != priority) or ("event" in m and m["event"] != event):
            continue
        chosen += route["channels"]
        break
    if chosen:
        for t in (team, *extra_teams):
            if t:
                chosen += (spec.get("team_channels") or {}).get(t, [])
    return [c for c in dict.fromkeys(chosen) if c not in disabled]


def webhook_name(channel: str) -> str:
    return f"aig-{channel}"


def notification(repo: Repo, env: str, priority: str, agent: Agent, extra_teams: Iterable[str] = ()) -> dict:
    spec = repo.spec("AlertRouting")
    emails: list[str] = []
    pd: list[str] = []
    hooks: list[str] = []
    for name in route_channels(repo, env, priority=priority, team=agent.team, extra_teams=extra_teams):
        ch = spec["channels"][name]
        if ch["type"] == "email":
            emails += ch.get("to", [])
            if ch.get("to_owner") and agent.owner:
                emails.append(agent.owner)
        elif ch["type"] == "pagerduty":
            pd.append(ch["service"])
        elif ch["type"] == "slack":
            hooks.append(webhook_name(name))
    out = {"emails": sorted(set(emails)), "pagerduty_services": sorted(set(pd)), "webhooks": sorted(set(hooks))}
    if pd:
        out["pagerduty_severity"] = spec.get("pagerduty_severity", "critical")
    return out


def links(repo: Repo, env: str, *, project: str, application: str, application_id: str = "{application_id}",
          trace_id: str = "{trace_id}", fiddler_url: str | None = None) -> dict[str, str]:
    url = (fiddler_url or repo.env(env)["fiddler_url"]).rstrip("/")
    values = {"fiddler_url": url, "project": project, "application": application, "application_id": application_id,
              "trace_id": trace_id, "agent_id": application}
    return {k: v.format(**values) for k, v in repo.spec("AlertRouting")["links"].items()}


def load_canaries(repo: Repo, path: Path | None = None) -> list[dict]:
    """Active model canaries from the gateway manifest (``aigw canary ...``); [] when none."""
    spec = (repo.manifests.get("CanaryMonitors") or {}).get("spec")
    if spec is None:
        return []
    path = Path(path) if path else (repo.root / spec["canaries_file"]).resolve()
    if not path.is_file():
        return []
    try:
        doc = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError as exc:
        raise ManifestError(f"{path.name}: invalid YAML: {exc}") from None
    entries = ((doc.get("spec") or {}).get("canaries")) or []
    for e in entries:
        if not isinstance(e, dict) or not {"tier", "state", "model"} <= set(e) or "model" not in (e.get("model") or {}):
            raise ManifestError(f"{path.name}: malformed canary entry {e!r}")
    return entries


def canary_thresholds(m: dict) -> tuple[float, float]:
    base = float(m["incumbent_value"])
    sign = 1 if m["condition"] == "greater" else -1
    return (round(base * (1 + sign * m["warning_tolerance"]), 6), round(base * (1 + sign * m["critical_tolerance"]), 6))


def render_canaries(repo: Repo, env: str, out: "Rendered", projects: list[str], canaries: list[dict]) -> None:
    spec = (repo.manifests.get("CanaryMonitors") or {}).get("spec")
    if not spec or not canaries:
        return
    app = spec["application"]
    owner = Agent(app, BUILTIN_OWNER, BUILTIN_TEAM)
    for project in projects:
        scope = {"project": project, "application": app, "agent_id": app}
        out.objects["applications"].append({**scope, "team": owner.team, "owner": owner.owner, "status": "active"})
        for c in canaries:
            model_id = str(c["model"]["model"])
            alias = str(c["model"].get("alias") or model_id)
            for m in spec["monitors"]:
                warning, critical = canary_thresholds(m)
                out.objects["alert_rules"].append({
                    **scope,
                    "name": spec["name_template"].format(tier=c["tier"], model=alias, monitor=m["name"]),
                    "metric_id": m["metric_id"], "feature_names": list(m.get("columns") or []),
                    "condition": m["condition"], "bin_size": m["bin_size"], "compare_to": "raw_value",
                    "compare_bin_delta": None, "warning_threshold": warning, "critical_threshold": critical,
                    "priority": m["priority"], "evaluation_delay": m.get("evaluation_delay", 0),
                    "threshold_type": "manual",
                    "segment": {"name": f"canary-{c['tier']}-{alias}",
                                "definition": f"\"{spec['segment_column']}\" == '{model_id}'"},
                    "canary": {"tier": c["tier"], "state": c["state"], "model": model_id, "share": c.get("share"),
                               "incumbent": list(c.get("incumbent") or []),
                               "incumbent_value": m["incumbent_value"]},
                    "notification": notification(repo, env, m["priority"], owner),
                    "links": links(repo, env, project=project, application=app, fiddler_url=out.fiddler_url),
                })


def effective_invocation_monitors(repo: Repo, env: str, agent_id: str) -> list[dict]:
    spec = (repo.manifests.get("InvocationMonitors") or {}).get("spec")
    if not spec:
        return []
    env_over = repo.env(env).get("invocation_monitor_overrides") or {}
    agent_over = (spec.get("agent_overrides") or {}).get(agent_id, {})
    return [{**copy.deepcopy(m), **env_over.get(m["name"], {}), **agent_over.get(m["name"], {})} for m in spec["monitors"]]


def invocation_group_values(repo: Repo, column: str, agents: Iterable[Agent]) -> list[str]:
    """Values a ``group_by`` monitor is rendered for. ``aig.caller_team``: every registry team,
    every team with alert channels and the manifest's ``caller_teams``."""
    spec = repo.spec("InvocationMonitors")
    if column != "aig.caller_team":
        raise ManifestError(f"invocation-monitors.yaml: group_by {column!r} is not supported (only aig.caller_team)")
    teams = {a.team for a in agents} | set(spec.get("caller_teams") or [])
    teams |= set((repo.spec("AlertRouting").get("team_channels") or {}))
    return sorted(t for t in teams if t)


def _quote(v: str) -> str:
    return v.replace("'", "\\'")


def render_invocations(repo: Repo, env: str, out: Rendered, projects: list[str], agents: list[Agent],
                       group_agents: list[Agent]) -> None:
    """Per-agent invocation monitors (invocation-monitors.yaml) in each agent's application."""
    spec = (repo.manifests.get("InvocationMonitors") or {}).get("spec")
    if not spec:
        return
    builtins = set(repo.spec("Applications").get("builtin_agents") or [])
    targets = [a for a in agents if spec.get("include_builtin_agents", False) or a.agent_id not in builtins]
    groups = {m["group_by"]: invocation_group_values(repo, m["group_by"], group_agents)
              for m in spec["monitors"] if m.get("group_by")}
    app_tpl = repo.spec("Applications")["name_template"]
    for project in projects:
        for agent in targets:
            app = app_tpl.format(agent_id=agent.agent_id)
            scope = {"project": project, "application": app, "agent_id": agent.agent_id}
            for m in effective_invocation_monitors(repo, env, agent.agent_id):
                name = spec["name_template"].format(agent_id=agent.agent_id, monitor=m["name"])
                kind = m.get("event_kind") or spec["event_kind"]
                definition = f"\"{spec['event_kind_column']}\" == '{_quote(kind)}'"
                definition += f" and ({m['filter']})" if m.get("filter") else ""
                col = m.get("group_by")
                for value in (groups[col] if col else [None]):
                    seg_name, seg_def, rule_name = f"invocation-{m['name']}", definition, name
                    if value is not None:
                        seg_name, rule_name = f"{seg_name}-{value}", f"{name}-{value}"
                        seg_def = f"{definition} and \"{col}\" == '{_quote(value)}'"
                    out.objects["alert_rules"].append({
                        **scope,
                        "name": rule_name,
                        "metric_id": m["metric_id"], "feature_names": list(m.get("columns") or []),
                        "condition": m["condition"], "bin_size": m["bin_size"], "compare_to": "raw_value",
                        "compare_bin_delta": None, "warning_threshold": m["warning"], "critical_threshold": m["critical"],
                        "priority": m["priority"], "evaluation_delay": m.get("evaluation_delay", 0),
                        "threshold_type": "manual",
                        "segment": {"name": seg_name, "definition": seg_def},
                        "invocation": {"monitor": m["name"], "event_kind": kind,
                                       "error_statuses": list(spec["error_statuses"]),
                                       "group_by": col, "group": value},
                        "notification": notification(repo, env, m["priority"], agent,
                                                     extra_teams=[value] if col == "aig.caller_team" and value else ()),
                        "links": links(repo, env, project=project, application=app, fiddler_url=out.fiddler_url),
                    })


def render(repo: Repo, env: str, agents: Iterable[Agent], *, fiddler_url: str | None = None,
           canaries: list[dict] | None = None) -> Rendered:
    envdoc = repo.env(env)
    apps_spec = repo.spec("Applications")
    mon_spec = repo.spec("Monitors")
    trust = effective_trust(repo, env)
    sampling = repo.spec("TrustScores").get("sampling_rate", 1.0)
    agents = with_builtins(agents, apps_spec.get("builtin_agents", []))
    all_agents = list(agents)  # suspended agents' teams still call other agents
    if not apps_spec.get("include_suspended", True):
        agents = [a for a in agents if a.status == "active"]
    out = Rendered(env, (fiddler_url or envdoc["fiddler_url"]).rstrip("/"), {k: [] for k in KINDS})
    projects = list(envdoc["projects"])
    asset_type = repo.spec("Projects")["asset_type"]
    out.objects["projects"] = [{"name": p, "asset_type": asset_type} for p in projects]

    disabled = set(envdoc.get("disabled_channels") or [])
    for name, ch in repo.spec("AlertRouting")["channels"].items():
        if ch["type"] == "slack" and name not in disabled:
            out.objects["webhooks"].append(
                {"name": webhook_name(name), "provider": "SLACK", "url": secret_ref(ch["webhook_env"]), "url_env": ch["webhook_env"]}
            )

    for project in projects:
        for agent in agents:
            app = apps_spec["name_template"].format(agent_id=agent.agent_id)
            scope = {"project": project, "application": app, "agent_id": agent.agent_id}
            out.objects["applications"].append({**scope, "team": agent.team, "owner": agent.owner, "status": agent.status})
            for s in trust:
                out.objects["evaluator_rules"].append({
                    **scope, "name": f"aig-trust-{s['name']}", "evaluator": s["evaluator"], "outputs": list(s["outputs"]),
                    "aggregate": s["aggregate"], "direction": s["direction"], "threshold": s["threshold"],
                    "enabled": bool(s["enabled"]), "sampling_rate": sampling,
                })
            for m in effective_monitors(repo, env, agent.agent_id):
                rule = {
                    **scope,
                    "name": mon_spec["name_template"].format(agent_id=agent.agent_id, monitor=m["name"]),
                    "metric_id": m["metric_id"], "feature_names": list(m.get("columns") or []),
                    "condition": m["condition"], "bin_size": m["bin_size"], "compare_to": m["compare_to"],
                    "compare_bin_delta": m.get("compare_bin_delta") if m["compare_to"] == "time_period" else None,
                    "warning_threshold": m["warning"], "critical_threshold": m["critical"],
                    "priority": m["priority"], "evaluation_delay": m.get("evaluation_delay", 0),
                    "threshold_type": "manual",
                    "notification": notification(repo, env, m["priority"], agent),
                    "links": links(repo, env, project=project, application=app, fiddler_url=out.fiddler_url),
                }
                out.objects["alert_rules"].append(rule)
    render_invocations(repo, env, out, projects, agents, all_agents)
    render_canaries(repo, env, out, projects, load_canaries(repo) if canaries is None else canaries)
    return out
