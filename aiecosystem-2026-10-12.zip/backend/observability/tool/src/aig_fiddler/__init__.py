"""AIG Fiddler provisioning as code (backend/observability)."""

__version__ = "0.1.0"
