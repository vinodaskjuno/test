"""Registered agents, read from platform-api (GET /api/v1/agents) or a registry YAML file.

The YAML format is platform-api's (backend/platform-api/config/agents.example.yaml). Like
platform-api, the built-in interactive agents are always present.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import httpx
import yaml

AGENT_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
SERVICE_TOKEN_ENV = "AIG_PLATFORM_SERVICE_TOKEN"
SERVICE_HEADER = "x-aig-service-token"
BUILTIN_OWNER = "platform-team@aig.example.com"
BUILTIN_TEAM = "aig-platform"


class RegistryError(RuntimeError):
    pass


@dataclass(frozen=True)
class Agent:
    agent_id: str
    owner: str
    team: str
    status: str = "active"
    shared: bool = False

    @classmethod
    def from_mapping(cls, m: Mapping[str, Any], agent_id: str | None = None) -> "Agent":
        aid = str(agent_id or m.get("agent_id") or "")
        if not AGENT_ID_RE.match(aid):
            raise RegistryError(f"invalid agent id {aid!r}")
        return cls(aid, str(m.get("owner") or ""), str(m.get("team") or ""), str(m.get("status") or "active"),
                   bool(m.get("shared", False)))


def with_builtins(agents: Iterable[Agent], builtin_ids: Iterable[str]) -> list[Agent]:
    out = {a.agent_id: a for a in agents}
    for aid in builtin_ids:
        out.setdefault(aid, Agent(aid, BUILTIN_OWNER, BUILTIN_TEAM, "active", True))
    return sorted(out.values(), key=lambda a: a.agent_id)


def load_agents_file(path: Path) -> list[Agent]:
    try:
        data = yaml.safe_load(Path(path).read_text()) or {}
    except OSError as exc:
        raise RegistryError(f"cannot read registry file {path}: {exc.strerror}") from None
    entries = data.get("agents") or {}
    if not isinstance(entries, dict):
        raise RegistryError(f"{path}: 'agents' must be a mapping")
    return [Agent.from_mapping(v or {}, k) for k, v in entries.items()]


def _is_placeholder(v: str | None) -> bool:
    return not v or "<" in v or "__" in v


def load_agents_url(url: str, token: str | None = None, *, transport: httpx.BaseTransport | None = None) -> list[Agent]:
    token = token if token is not None else os.environ.get(SERVICE_TOKEN_ENV, "")
    if _is_placeholder(url):
        raise RegistryError("registry url is a placeholder; pass --registry-file or set registry.url")
    if _is_placeholder(token):
        raise RegistryError(f"{SERVICE_TOKEN_ENV} is missing or a placeholder")
    try:
        with httpx.Client(transport=transport, timeout=30.0) as http:
            r = http.get(url.rstrip("/") + "/api/v1/agents", headers={SERVICE_HEADER: token, "accept": "application/json"})
    except httpx.HTTPError as exc:
        raise RegistryError(f"platform-api unreachable: {type(exc).__name__}") from None
    if r.status_code != 200:
        raise RegistryError(f"platform-api GET /api/v1/agents: HTTP {r.status_code}")
    return [Agent.from_mapping(a) for a in r.json().get("agents", [])]
