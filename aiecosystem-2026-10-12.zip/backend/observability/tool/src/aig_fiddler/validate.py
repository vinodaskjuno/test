"""validate: schemas, cross references, threshold sanity, rendering and the placeholder rule."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .loader import ENVS, Repo
from .registry import Agent
from .render import Rendered, canary_thresholds, effective_invocation_monitors, render

SAMPLE_AGENT = Agent("sample-agent", "owner@aig.example.com", "underwriting-ai")
SAMPLE_CANARY = {"tier": "standard", "state": "canary", "share": 10,
                 "model": {"alias": "sample-candidate", "integration": "anthropic-prod", "model": "sample-candidate-1"}}
STRICT_ENVS = ("stage", "prod")
RATE_METRICS = ("error_rate",)
INVOCATION_REQUIRED = {"error-rate": None, "latency-p95": None, "cost-per-caller-team": "aig.caller_team"}
# Invocation events carry no cost (platform-api does not know it): cost comes from the gateway
# events the agent makes while serving an invocation (caller tags from x-portkey-metadata).
COST_COLUMN = "aig.cost_usd"
QUOTED_COLUMN = re.compile(r'"([^"]+)"')


@dataclass
class Report:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    rendered: dict[str, Rendered] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors


def _has_placeholder(v: object) -> bool:
    return isinstance(v, str) and ("<" in v or "__" in v)


def validate(repo: Repo, envs: list[str] | None = None, *, allow_placeholders: bool = False) -> Report:
    rep = Report()
    rep.errors += repo.schema_errors()
    if rep.errors:
        return rep
    envs = envs or [e for e in ENVS if e in repo.envs]
    for e in envs:
        if e not in repo.envs:
            rep.errors.append(f"envs/{e}.yaml is missing")
    if rep.errors:
        return rep

    trust = repo.spec("TrustScores")["scores"]
    names = [s["name"] for s in trust]
    if len(names) != len(set(names)):
        rep.errors.append("trust.yaml: duplicate score names")
    for required in ("hallucination", "toxicity", "pii", "jailbreak"):
        if required not in names:
            rep.errors.append(f"trust.yaml: score {required!r} is required (Phase 3)")

    mons = repo.spec("Monitors")
    mon_names = [m["name"] for m in mons["monitors"]]
    if len(mon_names) != len(set(mon_names)):
        rep.errors.append("monitors.yaml: duplicate monitor names")
    for required in ("drift", "latency-p95", "error-rate", "cost-per-day"):
        if required not in mon_names:
            rep.errors.append(f"monitors.yaml: monitor {required!r} is required (Phase 3)")
    for aid, over in (mons.get("agent_overrides") or {}).items():
        for m in over:
            if m not in mon_names:
                rep.errors.append(f"monitors.yaml: agent_overrides.{aid}.{m}: unknown monitor")

    alerts = repo.spec("AlertRouting")
    channels = alerts["channels"]
    for i, r in enumerate(alerts["routes"]):
        for c in r["channels"]:
            if c not in channels:
                rep.errors.append(f"alerts.yaml: routes[{i}]: unknown channel {c!r}")
    for team, chs in (alerts.get("team_channels") or {}).items():
        for c in chs:
            if c not in channels:
                rep.errors.append(f"alerts.yaml: team_channels.{team}: unknown channel {c!r}")
    for prio in ("HIGH", "MEDIUM", "LOW"):
        if not any(r["match"].get("priority") == prio for r in alerts["routes"]):
            rep.errors.append(f"alerts.yaml: no route for priority {prio}")
    if not any(r["match"].get("event") == "agent_suspended" for r in alerts["routes"]):
        rep.errors.append("alerts.yaml: no route for event agent_suspended (reconciliation alerts)")

    canary = (repo.manifests.get("CanaryMonitors") or {}).get("spec")
    if canary:
        cnames = [m["name"] for m in canary["monitors"]]
        if len(cnames) != len(set(cnames)):
            rep.errors.append("canary-monitors.yaml: duplicate monitor names")
        for required in ("quality", "cost", "error-rate"):
            if required not in cnames:
                rep.errors.append(f"canary-monitors.yaml: monitor {required!r} is required (Phase 7 canary comparison)")
        for m in canary["monitors"]:
            if m["warning_tolerance"] > m["critical_tolerance"]:
                rep.errors.append(f"canary-monitors.yaml: {m['name']}: warning_tolerance must not exceed critical_tolerance")
            if m["condition"] == "lesser" and m["critical_tolerance"] >= 1:
                rep.errors.append(f"canary-monitors.yaml: {m['name']}: a 'lesser' tolerance must be < 1")
            canary_thresholds(m)
        if canary["application"] in (repo.spec("Applications").get("builtin_agents") or []):
            rep.errors.append("canary-monitors.yaml: application must not be a built-in agent application")
        if not (repo.root / canary["canaries_file"]).resolve().is_file():
            rep.warnings.append(f"canary-monitors.yaml: canaries_file {canary['canaries_file']} not found (no canary rules rendered)")

    inv = (repo.manifests.get("InvocationMonitors") or {}).get("spec")
    inv_names: list[str] = []
    if inv:
        _validate_invocations(repo, inv, rep)
        inv_names = [m["name"] for m in inv["monitors"]]

    template = repo.spec("Projects")["name_template"]
    for e in envs:
        doc = repo.env(e)
        label = f"envs/{e}.yaml"
        if doc["env"] != e:
            rep.errors.append(f"{label}: env must be {e!r}")
        if template.format(env=e) not in doc["projects"]:
            rep.errors.append(f"{label}: must host its own project {template.format(env=e)!r}")
        for c in doc.get("disabled_channels") or []:
            if c not in channels:
                rep.errors.append(f"{label}: disabled_channels: unknown channel {c!r}")
        for k in doc.get("trust_overrides") or {}:
            if k not in names:
                rep.errors.append(f"{label}: trust_overrides.{k}: unknown score")
        for k in doc.get("monitor_overrides") or {}:
            if k not in mon_names:
                rep.errors.append(f"{label}: monitor_overrides.{k}: unknown monitor")
        for k in doc.get("invocation_monitor_overrides") or {}:
            if k not in inv_names:
                rep.errors.append(f"{label}: invocation_monitor_overrides.{k}: unknown invocation monitor")
        if inv:
            for m in effective_invocation_monitors(repo, e, SAMPLE_AGENT.agent_id):
                if m["metric_id"] in RATE_METRICS and max(m["warning"], m["critical"]) > 1:
                    rep.errors.append(f"{label}: invocation monitor {m['name']}: {m['metric_id']} thresholds are fractions (<= 1)")
        placeholders = [k for k in ("fiddler_url",) if _has_placeholder(doc.get(k))]
        placeholders += [f"registry.{k}" for k, v in doc["registry"].items() if k == "url" and _has_placeholder(v)]
        for p in placeholders:
            msg = f"{label}: {p} is still a placeholder"
            if e in STRICT_ENVS and not allow_placeholders:
                rep.errors.append(msg)
            else:
                rep.warnings.append(msg)
        reg_file = doc["registry"].get("file")
        if reg_file and not (repo.root / "envs" / reg_file).is_file():
            rep.errors.append(f"{label}: registry.file {reg_file} does not exist")
        try:
            rendered = render(repo, e, [SAMPLE_AGENT], canaries=[SAMPLE_CANARY] if canary else [])
        except Exception as exc:  # template errors
            rep.errors.append(f"{label}: render failed: {type(exc).__name__}: {exc}")
            continue
        for rule in rendered.objects["alert_rules"]:
            w, c = rule["warning_threshold"], rule["critical_threshold"]
            bad = w > c if rule["condition"] == "greater" else w < c
            if bad:
                rep.errors.append(f"{label}: {rule['name']}: warning threshold must not be past the critical one")
            if rule["compare_to"] == "time_period" and not rule["compare_bin_delta"]:
                rep.errors.append(f"{label}: {rule['name']}: compare_to time_period needs compare_bin_delta")
        rep.rendered[e] = rendered
    # Duplicates in rendering (two monitors with the same rendered name) are always a bug.
    for e, r in rep.rendered.items():
        keys = [(o["project"], o["application"], o["name"]) for o in r.objects["alert_rules"]]
        if len(keys) != len(set(keys)):
            rep.errors.append(f"envs/{e}.yaml: rendered alert rule names collide")
    return rep


def _validate_invocations(repo: Repo, inv: dict, rep: Report) -> None:
    """invocation-monitors.yaml: names, referenced attributes, statuses, thresholds, overrides."""
    label = "invocation-monitors.yaml"
    names = [m["name"] for m in inv["monitors"]]
    if len(names) != len(set(names)):
        rep.errors.append(f"{label}: duplicate monitor names")
    attrs = set(inv["attributes"])
    for col in (inv["event_kind_column"], inv["status_column"]):
        if col not in attrs:
            rep.errors.append(f"{label}: {col!r} is not a declared attribute")
    for s in inv["error_statuses"]:
        if s not in inv["statuses"]:
            rep.errors.append(f"{label}: error_statuses: unknown status {s!r}")
    by_name = {m["name"]: m for m in inv["monitors"]}
    for required, group in INVOCATION_REQUIRED.items():
        if required not in by_name:
            rep.errors.append(f"{label}: monitor {required!r} is required (agent invocation monitoring)")
        elif group and by_name[required].get("group_by") != group:
            rep.errors.append(f"{label}: {required}: must group_by {group}")
    for m in inv["monitors"]:
        refs = list(m.get("columns") or []) + QUOTED_COLUMN.findall(m.get("filter") or "")
        if m.get("group_by"):
            refs.append(m["group_by"])
            if m["group_by"] != "aig.caller_team":
                rep.errors.append(f"{label}: {m['name']}: group_by {m['group_by']!r} is not supported (only aig.caller_team)")
        for col in refs:
            if col not in attrs:
                rep.errors.append(f"{label}: {m['name']}: references undeclared attribute {col!r}")
        if COST_COLUMN in (m.get("columns") or []) and (m.get("event_kind") or inv["event_kind"]) == inv["event_kind"]:
            rep.errors.append(f"{label}: {m['name']}: {inv['event_kind']} events carry no {COST_COLUMN}; "
                              f"set event_kind (e.g. gateway) on this monitor")
        if m.get("filter") and not QUOTED_COLUMN.search(m["filter"]):
            rep.errors.append(f"{label}: {m['name']}: filter must reference a quoted column")
        if m["metric_id"] in RATE_METRICS and max(m["warning"], m["critical"]) > 1:
            rep.errors.append(f"{label}: {m['name']}: {m['metric_id']} thresholds are fractions (<= 1)")
        if m["metric_id"] not in RATE_METRICS and not m.get("columns"):
            rep.errors.append(f"{label}: {m['name']}: metric {m['metric_id']!r} needs a column")
    for aid, over in (inv.get("agent_overrides") or {}).items():
        for m in over:
            if m not in by_name:
                rep.errors.append(f"{label}: agent_overrides.{aid}.{m}: unknown monitor")
    builtins = repo.spec("Applications").get("builtin_agents") or []
    if not inv.get("include_builtin_agents", False):
        for aid in inv.get("agent_overrides") or {}:
            if aid in builtins:
                rep.warnings.append(f"{label}: agent_overrides.{aid}: built-in agents get no invocation monitors")
    mon_tpl = repo.spec("Monitors")["name_template"]
    if inv["name_template"] == mon_tpl:
        rep.errors.append(f"{label}: name_template must differ from monitors.yaml's ({mon_tpl!r})")
