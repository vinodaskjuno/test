# backend/observability: Fiddler provisioning as code (Phase 3)

Everything AIG configures in Fiddler is declared here and applied with `fiddler-sync`
(package `aig-fiddler` in [`tool/`](tool/)), the same way `backend/gateway` and `aigw` manage
Portkey. Nobody creates applications, monitors or alert routes by hand; `fiddler-sync diff`
shows drift.

| Path | What it is |
|---|---|
| `manifests/projects.yaml` | One Fiddler project per AIG environment (`aig-{env}`, asset type `GEN_AI_APP`) |
| `manifests/applications.yaml` | One application per registered agent (platform-api registry), in every project the env hosts; built-in IDE/web agents included; suspended agents kept |
| `manifests/trust.yaml` | Trust scores on every LLM span: hallucination (`ftl_response_faithfulness`), toxicity and jailbreak (`ftl_prompt_safety`), PII (`pii`), with thresholds and direction |
| `manifests/monitors.yaml` | Monitors (alert rules) per agent: drift, latency p95, error rate, cost per day; warning/critical thresholds, priority, per-agent overrides |
| `manifests/canary-monitors.yaml` | Phase 7: alert-rule templates rendered for every active model canary in `backend/gateway/manifests/canaries.yaml` (application `aig-model-canary`, candidate segment, thresholds from the incumbent's level: quality, cost, error rate, latency) |
| `manifests/invocation-monitors.yaml` | Per-agent invocation monitors (agent registry v2): error rate, invocation latency p95, cost per caller team, on the segment of platform-api invocation records (`aig.event_kind = "invocation"`); see below |
| `manifests/alerts.yaml` | Alert routing: Slack, PagerDuty and email channels, routes by priority and by platform event (`agent_suspended`, `failing_traces_exported`), team channels, links to the application / failing traces |
| `envs/{local,dev,stage,prod}.yaml` | Fiddler URL, the projects that instance hosts (dev also hosts `aig-local` and `aig-workspace`), where the registry is read, disabled channels, trust/monitor/invocation-monitor overrides |
| `schemas/*.schema.json` | JSON Schema (2020-12) for every manifest kind and the env overlay |

Secrets are never in these files: Slack webhook URLs and the PagerDuty routing key are named
by env var (`webhook_env`, `routing_key_env`) and read only when sent.

## Using `fiddler-sync`

```bash
cd backend/observability/tool
python3 -m venv .venv && .venv/bin/pip install -e '.[dev]'     # or: make setup (repo root)

.venv/bin/fiddler-sync validate --allow-placeholders     # what CI runs (stage/prod hold placeholders)
.venv/bin/fiddler-sync validate --env prod               # strict
.venv/bin/fiddler-sync render --env local                 # agents from the overlay's registry file
.venv/bin/fiddler-sync render --env dev --registry-file ../../platform-api/config/agents.example.yaml

export FIDDLER_URL=https://<fiddler-host-dev> FIDDLER_API_KEY=...        # never commit
export AIG_PLATFORM_SERVICE_TOKEN=...                                     # registry.url envs
export AIG_ALERT_SLACK_WEBHOOK_PLATFORM=... AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING=... AIG_ALERT_SLACK_WEBHOOK_CLAIMS=...
.venv/bin/fiddler-sync diff --env dev [--json] [--exit-code]
.venv/bin/fiddler-sync apply --env dev            # DRY RUN: prints the plan, writes nothing
.venv/bin/fiddler-sync apply --env dev --yes      # create / update; idempotent
.venv/bin/fiddler-sync provision-agent --env dev --agent-id uw-quote --team underwriting-ai --owner jane@x.com --yes
```

- `validate`: schemas, cross references (routes and team channels name existing channels,
  overrides name existing scores/monitors, every priority and the `agent_suspended` event have
  a route, each env hosts its own project, the local registry file exists), the four required
  trust scores and monitors, threshold order (warning not past critical), rendering of every
  env, and the placeholder rule (error for stage/prod unless `--allow-placeholders`).
- `diff`/`apply` walk projects -> applications -> Slack webhooks -> evaluator rules (trust
  scores) -> alert rules (+ notification config) and compare only declared fields. Mutable
  alert-rule fields (thresholds, evaluation delay) are patched; changes to immutable ones
  (metric, columns, condition, bin size, compare_to, priority) recreate the rule. Nothing else
  is ever deleted. A Slack webhook whose env var is unset is `blocked` (exit 1); the alert
  rules are still created and pick the webhook up on the next apply.
- Precedence: manifest < env overlay (`trust_overrides`, `monitor_overrides`,
  `invocation_monitor_overrides`) < per-agent `agent_overrides` (monitors, invocation monitors).
- Notification routing per alert rule: the route for its priority, minus the env's
  `disabled_channels`, plus the owning team's channels -> Fiddler `emails` (fixed lists and the
  agent owner), `pagerduty_services` + `pagerduty_severity`, and `webhooks` (Slack webhook
  UUIDs created from the channels).

## Invocation monitors (agent registry v2)

`manifests/invocation-monitors.yaml` adds alert rules for agents invoked through
`POST /api/v1/agents/{id}/invoke` (`aig-http/1` and AgentCore transports,
[`backend/contracts/agent-invocation.md`](../contracts/agent-invocation.md)). telemetry-bridge
forwards each platform-api invocation record as an event with `aig.event_kind = "invocation"`
and `aig.invocation_id`, `aig.caller_user`, `aig.caller_team`, `aig.session_id`,
`aig.invocation.status|duration_ms|mode`, `aig.error_code`, `gen_ai.usage.*` (no cost:
platform-api does not know it). Cost comes from the gateway events the agent makes while
serving an invocation (`aig.event_kind = "gateway"`, `aig.cost_usd`, plus `aig.caller_team`,
`aig.caller_user`, `aig.invocation_id` copied from x-portkey-metadata). For every registered
agent (built-in IDE/web agents excluded, `include_builtin_agents`) and every project of the env,
in the agent's application, segment `"aig.event_kind" == 'invocation'` unless a monitor sets its
own `event_kind`:

| Rule | Metric | Notes |
|---|---|---|
| `{agent}-invocation-error-rate` | `error_rate`, Hour, HIGH | failed + timeout invocations (`error_statuses`); cancelled is not an error |
| `{agent}-invocation-latency-p95` | `p95_latency` of `aig.invocation.duration_ms`, Hour | `filter` excludes `background` mode (up to 1 h by design) |
| `{agent}-invocation-cost-per-caller-team-{team}` | `sum` of `aig.cost_usd`, Day | `event_kind: gateway`, segment `"aig.event_kind" == 'gateway' and "aig.caller_team" == '<team>'` (a caller team implies an invocation); `group_by: aig.caller_team`: one rule (segment) per team: registry teams, teams with `team_channels` in `alerts.yaml`, and `caller_teams`; the calling team's channels are added to the routing |

Thresholds: manifest < `invocation_monitor_overrides` in the env overlay (local looser, prod
tighter) < `agent_overrides`. `validate` checks the required three monitors, that every column,
filter column and `group_by` is a declared `attribute`, `error_statuses` are known statuses,
`error_rate` thresholds are fractions, no `aig.cost_usd` monitor on invocation events, warning not past critical, overrides name existing
monitors, and that rendered names do not collide with `monitors.yaml`. ASSUMED like the other
monitors: inline segment definitions on alert rules. telemetry-bridge sets an ERROR span status
only on failed/timeout invocation events (cancelled is OK), which is what `error_rate` counts. A team
that first appears after a sync gets its cost rules on the next `apply`; the registration hook
renders teams from that agent and the manifests only. Segment definitions are not compared in
`diff` (as for canary rules): to change one, rename the monitor or delete the rule.

## Automatic provisioning on registration

platform-api calls `aig_fiddler.hooks:on_agent_registered` after `POST /api/v1/agents` when
`AIG_FIDDLER_AUTOPROVISION=true` (needs this package installed next to platform-api,
`AIG_FIDDLER_ROOT` pointing at this directory when not run from a repo checkout, and
`FIDDLER_API_KEY` in platform-api's secrets). It creates exactly what `fiddler-sync apply`
would create for that one agent; failures are logged and the next scheduled
`fiddler-sync apply --yes` catches up. Without the flag, run `fiddler-sync apply` on a schedule
(for example hourly) or after registrations.

## How the rest of the platform uses this

- SDKs send spans to project `AIG_FIDDLER_PROJECT` (`aig-<env>`) and the agent's application.
- `backend/telemetry-bridge` forwards gateway events and IDE usage into the same project and
  application (by the event's `env` and `agent` tags), uses `trust.yaml` thresholds for
  `export-failing`, and `alerts.yaml` routing for reconciliation alerts.

## Verification status

Verified against installed `fiddler-client` 3.14.1 / `fiddler-evals` 0.6.0 / `fiddler-otel`
1.4.1: auth header, `/v3/projects` (create body with `asset_type: GEN_AI_APP`),
`/v3/applications` (create `{name, project_id}`), list paging and the JSON `filter` parameter,
`/v2/webhooks` (`name`, `url`, `provider` SLACK; id field `uuid`), alert-rule fields and enums,
`PATCH /v3/alert-rules/{id}` (thresholds, evaluation delay) and
`PATCH /v3/alert-rules/{id}/notification` (`emails`, `pagerduty_services`,
`pagerduty_severity`, `webhooks`), trust evaluator ids/outputs for `ftl_*`.

Assumed (see [`tool/src/aig_fiddler/endpoints.py`](tool/src/aig_fiddler/endpoints.py);
override with `AIG_FIDDLER_ENDPOINTS_FILE`): alert rules for GenAI applications keyed by
`application_id`; the metric ids `jsd`, `p95_latency`, `error_rate`, `sum` on application span
columns; evaluator (trust score) rules at `/v3/applications/{id}/evaluator-rules`; the `pii`
evaluator id and its `pii_detected` output; the UI link routes in `alerts.yaml`.
