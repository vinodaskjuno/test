"""Orchestrator configuration (backend/contracts/env-vars.md, "workspace-orchestrator").

Values that are empty or contain ``__REPLACE_ME`` / ``<...>`` count as unset (same rule as the
other services). Secrets (``AIG_PLATFORM_SERVICE_TOKEN``, ``AIG_WS_RELAY_SECRET``,
``AIG_WS_NOTIFY_SECRET``) are never logged or put into a task definition override.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import socket
from collections.abc import Mapping
from dataclasses import dataclass, field

ENVS = ("local", "dev", "stage", "prod")
RUNNERS = ("local", "ecs")
TEAM_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")

DEFAULT_IDLE_TIMEOUT_MINUTES = 30.0  # open item: confirm with the platform owner
DEFAULT_MAX_RUNTIME_MINUTES = 120.0

# Non-secret variables forwarded from the orchestrator's environment to every job (when set).
JOB_PASSTHROUGH = (
    "AIG_PORTKEY_BASE_URL", "AIG_PORTKEY_CONFIG", "AIG_FIDDLER_URL", "AIG_FIDDLER_PROJECT",
    "AIG_FIDDLER_APPLICATION_ID", "AIG_OTLP_ENDPOINT", "AIG_LOG_LEVEL", "AIG_TIMEOUT_SECONDS",
    "GITHUB_API_URL", "GITHUB_APP_ID", "GITHUB_APP_INSTALLATION_ID",
    "AIG_WS_CODE_AGENT", "AIG_WS_CLAUDE_MODEL", "AIG_WS_CLAUDE_PERMISSION_MODE", "AIG_WS_CLAUDE_MAX_BUDGET_USD",
    "AIG_WS_AGENT_TIMEOUT_MINUTES", "AIG_WS_SETUP_COMMAND", "AIG_WS_TEST_COMMAND", "AIG_WS_FUNCTIONAL_TEST_COMMAND",
    "AIG_WS_TEST_TIMEOUT_MINUTES", "AIG_WS_FIX_ATTEMPTS", "AIG_WS_EVAL", "AIG_WS_COMMIT_EMAIL", "AIG_WS_PR_DRAFT",
    "AIG_WS_HEARTBEAT_SECONDS", "PIP_INDEX_URL", "NPM_CONFIG_REGISTRY", "HTTPS_PROXY", "NO_PROXY",
)


def unset(value: str | None) -> bool:
    if value is None:
        return True
    v = str(value).strip()
    return not v or "__REPLACE_ME" in v or bool(re.search(r"<[^>]*>", v))


def clean(value: str | None) -> str | None:
    return None if unset(value) else str(value).strip()


def _float(env: Mapping[str, str], name: str, default: float, minimum: float = 0.0) -> float:
    raw = clean(env.get(name))
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be a number") from exc
    if value < minimum:
        raise ConfigError(f"{name} must be >= {minimum}")
    return value


def _list(env: Mapping[str, str], name: str) -> list[str]:
    raw = clean(env.get(name)) or ""
    return [p.strip() for p in raw.split(",") if p.strip()]


class ConfigError(ValueError):
    pass


@dataclass(frozen=True)
class EcsConfig:
    cluster: str
    task_definition: str
    container_name: str = "workspace"
    subnets: tuple[str, ...] = ()
    security_groups: tuple[str, ...] = ()
    assign_public_ip: bool = False
    platform_version: str = "LATEST"
    capacity_provider: str | None = None  # e.g. FARGATE_SPOT; None = launchType FARGATE
    team_task_definitions: Mapping[str, str] = field(default_factory=dict)
    portkey_secret_arn_template: str | None = None  # "{team}" / "{env}" placeholders
    log_group: str | None = None
    log_stream_prefix: str = "workspace"
    region: str | None = None
    env: str = "dev"

    @classmethod
    def from_env(cls, env: Mapping[str, str], aig_env: str) -> EcsConfig:
        cluster = clean(env.get("AIG_WS_ECS_CLUSTER"))
        task_def = clean(env.get("AIG_WS_ECS_TASK_DEFINITION"))
        if not cluster or not task_def:
            raise ConfigError("AIG_WS_RUNNER=ecs needs AIG_WS_ECS_CLUSTER and AIG_WS_ECS_TASK_DEFINITION")
        subnets = tuple(_list(env, "AIG_WS_ECS_SUBNETS"))
        sgs = tuple(_list(env, "AIG_WS_ECS_SECURITY_GROUPS"))
        if not subnets or not sgs:
            raise ConfigError("AIG_WS_RUNNER=ecs needs AIG_WS_ECS_SUBNETS and AIG_WS_ECS_SECURITY_GROUPS "
                              "(private subnets with the restricted-egress security group)")
        raw_map = clean(env.get("AIG_WS_ECS_TEAM_TASK_DEFINITIONS"))
        try:
            team_map = json.loads(raw_map) if raw_map else {}
        except json.JSONDecodeError as exc:
            raise ConfigError("AIG_WS_ECS_TEAM_TASK_DEFINITIONS must be a JSON object") from exc
        if not isinstance(team_map, dict) or not all(isinstance(v, str) for v in team_map.values()):
            raise ConfigError("AIG_WS_ECS_TEAM_TASK_DEFINITIONS must map team -> task definition")
        return cls(
            cluster=cluster,
            task_definition=task_def,
            container_name=clean(env.get("AIG_WS_ECS_CONTAINER_NAME")) or "workspace",
            subnets=subnets,
            security_groups=sgs,
            assign_public_ip=(clean(env.get("AIG_WS_ECS_ASSIGN_PUBLIC_IP")) or "false").lower() == "true",
            platform_version=clean(env.get("AIG_WS_ECS_PLATFORM_VERSION")) or "LATEST",
            capacity_provider=clean(env.get("AIG_WS_ECS_CAPACITY_PROVIDER")),
            team_task_definitions=team_map,
            portkey_secret_arn_template=clean(env.get("AIG_WS_ECS_PORTKEY_SECRET_ARN_TEMPLATE")),
            log_group=clean(env.get("AIG_WS_ECS_LOG_GROUP")),
            log_stream_prefix=clean(env.get("AIG_WS_ECS_LOG_STREAM_PREFIX")) or "workspace",
            region=clean(env.get("AWS_REGION")) or clean(env.get("AWS_DEFAULT_REGION")),
            env=aig_env,
        )


@dataclass(frozen=True)
class OrchestratorConfig:
    env: str
    platform_api_url: str
    service_token: str
    runner: str
    relay_secret: str
    relay_public_url: str
    relay_host: str = "127.0.0.1"
    relay_port: int = 8090
    poll_interval_seconds: float = 10.0
    max_concurrent: int = 5
    idle_timeout_seconds: float = DEFAULT_IDLE_TIMEOUT_MINUTES * 60
    max_runtime_seconds: float = DEFAULT_MAX_RUNTIME_MINUTES * 60
    worker_id: str = "orchestrator"
    user_tier: str = "standard"
    agent_owner: str | None = None
    notify_urls: tuple[str, ...] = ()
    notify_secret: str | None = None
    job_env: Mapping[str, str] = field(default_factory=dict)
    ecs: EcsConfig | None = None
    local_workdir: str | None = None
    local_job_env_file: str | None = None
    log_level: str = "INFO"
    recover: bool = True

    def __repr__(self) -> str:  # never show secrets
        return (f"OrchestratorConfig(env={self.env!r}, runner={self.runner!r}, platform_api_url={self.platform_api_url!r}, "
                f"idle_timeout_seconds={self.idle_timeout_seconds}, max_runtime_seconds={self.max_runtime_seconds})")

    __str__ = __repr__

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> OrchestratorConfig:
        env = dict(os.environ if env is None else env)
        aig_env = clean(env.get("AIG_ENV")) or "local"
        if aig_env not in ENVS:
            raise ConfigError(f"AIG_ENV must be one of {', '.join(ENVS)}")
        api = clean(env.get("AIG_PLATFORM_API_URL"))
        if not api:
            raise ConfigError("AIG_PLATFORM_API_URL is required")
        token = clean(env.get("AIG_PLATFORM_SERVICE_TOKEN"))
        if not token:
            raise ConfigError("AIG_PLATFORM_SERVICE_TOKEN is required (= platform-api PLATFORM_SERVICE_TOKEN)")
        runner = clean(env.get("AIG_WS_RUNNER")) or ("local" if aig_env == "local" else "ecs")
        if runner not in RUNNERS:
            raise ConfigError(f"AIG_WS_RUNNER must be one of {', '.join(RUNNERS)}")
        if runner == "local" and aig_env != "local":
            raise ConfigError("AIG_WS_RUNNER=local is only allowed with AIG_ENV=local (no isolation)")
        relay_secret = clean(env.get("AIG_WS_RELAY_SECRET"))
        if not relay_secret:
            if aig_env != "local":
                raise ConfigError("AIG_WS_RELAY_SECRET is required outside local")
            relay_secret = secrets.token_hex(32)  # local: per-process, tokens die with the process
        relay_host = clean(env.get("AIG_WS_RELAY_HOST")) or ("127.0.0.1" if aig_env == "local" else "0.0.0.0")
        relay_port = int(clean(env.get("AIG_WS_RELAY_PORT")) or 8090)
        relay_public = clean(env.get("AIG_WS_RELAY_PUBLIC_URL"))
        if not relay_public:
            if aig_env != "local":
                raise ConfigError("AIG_WS_RELAY_PUBLIC_URL is required outside local (how workspace tasks reach the relay)")
            relay_public = f"http://127.0.0.1:{relay_port}"
        tier = clean(env.get("AIG_WS_USER_TIER")) or "standard"
        if tier not in ("premium", "standard", "free"):
            raise ConfigError("AIG_WS_USER_TIER must be premium, standard or free")
        notify_urls = tuple(_list(env, "AIG_WS_NOTIFY_URLS"))
        notify_secret = clean(env.get("AIG_WS_NOTIFY_SECRET"))
        if notify_urls and not notify_secret:
            raise ConfigError("AIG_WS_NOTIFY_URLS needs AIG_WS_NOTIFY_SECRET (notifications are always signed)")
        job_env = {n: v for n in JOB_PASSTHROUGH if (v := clean(env.get(n)))}
        return cls(
            env=aig_env,
            platform_api_url=api.rstrip("/"),
            service_token=token,
            runner=runner,
            relay_secret=relay_secret,
            relay_public_url=relay_public.rstrip("/"),
            relay_host=relay_host,
            relay_port=relay_port,
            poll_interval_seconds=_float(env, "AIG_WS_POLL_INTERVAL_SECONDS", 10.0, 0.05),
            max_concurrent=int(_float(env, "AIG_WS_MAX_CONCURRENT", 5, 1)),
            idle_timeout_seconds=_float(env, "AIG_WS_IDLE_TIMEOUT_MINUTES", DEFAULT_IDLE_TIMEOUT_MINUTES, 0.01) * 60,
            max_runtime_seconds=_float(env, "AIG_WS_MAX_RUNTIME_MINUTES", DEFAULT_MAX_RUNTIME_MINUTES, 0.01) * 60,
            worker_id=clean(env.get("AIG_WS_WORKER_ID")) or socket.gethostname()[:64] or "orchestrator",
            user_tier=tier,
            agent_owner=clean(env.get("AIG_WS_AGENT_OWNER")),
            notify_urls=notify_urls,
            notify_secret=notify_secret,
            job_env=job_env,
            ecs=EcsConfig.from_env(env, aig_env) if runner == "ecs" else None,
            local_workdir=clean(env.get("AIG_WS_LOCAL_WORKDIR")),
            local_job_env_file=clean(env.get("AIG_WS_LOCAL_JOB_ENV_FILE")),
            log_level=clean(env.get("AIG_LOG_LEVEL")) or "INFO",
            recover=(clean(env.get("AIG_WS_RECOVER")) or "true").lower() != "false",
        )


def workspace_agent_id(team: str) -> str:
    """Registered agent id of a team's workspaces: ``workspace.<team>`` (<= 64 chars)."""
    return f"workspace.{team}"[:64]
