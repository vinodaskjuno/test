"""Signed status-change notifications (the Teams bot's ``POST /api/notify``).

Body: ``{"event": "workspace.status", "workspace": {...}, "sent_at": "<iso>"}`` (compact JSON).
Headers: ``x-aig-timestamp: <unix seconds>`` and
``x-aig-signature: sha256=<hex HMAC-SHA256(AIG_WS_NOTIFY_SECRET, "<timestamp>.<body>")>``.
Receivers reject signatures older than 5 minutes. Delivery is best effort (a failure is logged and
never blocks the worker); the bot can always fall back to ``status <id>``.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
from collections.abc import Iterable
from datetime import UTC, datetime

import httpx

log = logging.getLogger("workspace_orchestrator.notify")

# Fields sent to receivers (no description: it can be long and is not needed for a status card).
FIELDS = ("id", "status", "title", "repo_url", "work_item", "job_profile", "requested_by", "team",
          "pr_url", "log_url", "error", "updated_at")


def sign(secret: str, timestamp: str, body: bytes) -> str:
    mac = hmac.new(secret.encode(), timestamp.encode() + b"." + body, hashlib.sha256).hexdigest()
    return f"sha256={mac}"


def verify(secret: str, timestamp: str, body: bytes, signature: str, *, now: float | None = None,
           tolerance: float = 300.0) -> bool:
    try:
        ts = float(timestamp)
    except (TypeError, ValueError):
        return False
    if abs((time.time() if now is None else now) - ts) > tolerance:
        return False
    return hmac.compare_digest(sign(secret, timestamp, body), signature or "")


class Notifier:
    def __init__(self, urls: Iterable[str], secret: str | None, *, client: httpx.Client | None = None,
                 timeout: float = 5.0) -> None:
        self.urls = tuple(urls)
        self._secret = secret
        self._client = client or httpx.Client(timeout=timeout)

    @property
    def enabled(self) -> bool:
        return bool(self.urls and self._secret)

    def workspace_changed(self, workspace: dict) -> None:
        if not self.enabled:
            return
        payload = {
            "event": "workspace.status",
            "workspace": {k: workspace.get(k) for k in FIELDS},
            "sent_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        }
        body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
        ts = str(int(time.time()))
        headers = {"content-type": "application/json", "x-aig-timestamp": ts,
                   "x-aig-signature": sign(self._secret or "", ts, body)}
        for url in self.urls:
            try:
                resp = self._client.post(url, content=body, headers=headers)
                if resp.status_code >= 400:
                    log.warning("notify %s answered %s for workspace %s", url, resp.status_code, workspace.get("id"))
            except httpx.HTTPError as exc:
                log.warning("notify %s failed for workspace %s: %s", url, workspace.get("id"), type(exc).__name__)
