"""The orchestrator worker loop.

Every tick:

1. **Reconcile** tracked tasks: a workspace cancelled in platform-api is stopped; a task that
   exited is finalised (``pr_opened`` -> ``completed``, anything else -> ``failed``); a task past
   the idle timeout (no job activity through the relay for ``AIG_WS_IDLE_TIMEOUT_MINUTES``,
   default 30) or the max runtime is stopped and marked ``failed``.
2. **Dispatch**: while below ``AIG_WS_MAX_CONCURRENT``, claim the oldest ``queued`` request
   (atomic ``POST /claim``; a 409 means another worker won), register ``workspace.<team>`` if
   needed, start the job on the runner and record the log URL.

Every status change the orchestrator makes or sees is sent to the notifier (Teams bot).
"""

from __future__ import annotations

import logging
import re
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field

from .config import OrchestratorConfig, workspace_agent_id
from .notify import Notifier
from .platform import ACTIVE_STATUSES, FINAL_STATUSES, ClaimConflict, PlatformClient, PlatformError
from .relay import mint_token
from .runners.base import JobSpec, Runner, TaskHandle
from .scrub import Scrubber

log = logging.getLogger("workspace_orchestrator.worker")

EMAIL_OK = re.compile(r"^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")


@dataclass
class Tracked:
    workspace: dict
    handle: TaskHandle
    dispatched_at: float
    last_activity: float
    last_status: str
    stopping: bool = False
    extra: dict = field(default_factory=dict)


class Worker:
    def __init__(self, cfg: OrchestratorConfig, platform: PlatformClient, runner: Runner, *,
                 notifier: Notifier | None = None, scrubber: Scrubber | None = None,
                 secret_env: dict[str, str] | None = None, clock: Callable[[], float] = time.time) -> None:
        self.cfg = cfg
        self.platform = platform
        self.runner = runner
        self.notifier = notifier or Notifier((), None)
        self.scrub = scrubber or Scrubber([cfg.service_token, cfg.relay_secret, cfg.notify_secret or ""])
        self.secret_env = dict(secret_env or {})
        self.clock = clock
        self.tracked: dict[str, Tracked] = {}
        self._agents: set[str] = set()
        self._lock = threading.RLock()
        self._stop = threading.Event()

    # -- shared with the relay -------------------------------------------------------------
    def record_activity(self, workspace_id: str, status: str | None = None, workspace: dict | None = None) -> None:
        with self._lock:
            t = self.tracked.get(workspace_id)
            if t is None:
                return
            t.last_activity = self.clock()
            if workspace is not None:
                t.workspace = workspace
            if status:
                t.last_status = status

    def is_tracked(self, workspace_id: str) -> bool:
        with self._lock:
            return workspace_id in self.tracked

    # -- loop --------------------------------------------------------------------------------
    def run_forever(self) -> None:
        log.info("worker %s started (runner=%s, idle timeout %.0fs, max runtime %.0fs)", self.cfg.worker_id,
                 self.runner.name, self.cfg.idle_timeout_seconds, self.cfg.max_runtime_seconds)
        if self.cfg.recover:
            self.recover()
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception:  # keep polling; one bad tick must not kill the worker
                log.exception("worker tick failed")
            self._stop.wait(self.cfg.poll_interval_seconds)

    def stop(self) -> None:
        self._stop.set()

    def tick(self) -> None:
        self.reconcile()
        self.dispatch()

    # -- recovery ----------------------------------------------------------------------------
    def recover(self) -> None:
        """After a restart: adopt tasks that still run, fail the ones that were lost."""
        for status in sorted(ACTIVE_STATUSES):
            for ws in self.platform.list_workspaces(status):
                wid = ws["id"]
                if self.is_tracked(wid):
                    continue
                handle = self.runner.find(wid)
                now = self.clock()
                if handle is not None:
                    with self._lock:
                        self.tracked[wid] = Tracked(ws, handle, now, now, ws["status"])
                    log.info("recovered workspace %s (task %s)", wid, handle.id)
                elif ws["status"] == "pr_opened":
                    self._set(ws, "completed")
                else:
                    self._set(ws, "failed", error="workspace task lost (orchestrator restarted and the task is gone)")

    # -- reconcile ---------------------------------------------------------------------------
    def reconcile(self) -> None:
        with self._lock:
            items = list(self.tracked.items())
        for wid, t in items:
            try:
                self._reconcile_one(wid, t)
            except PlatformError as exc:
                log.warning("reconcile %s: %s", wid, self.scrub(exc))

    def _drop(self, wid: str) -> None:
        with self._lock:
            self.tracked.pop(wid, None)

    def _reconcile_one(self, wid: str, t: Tracked) -> None:
        ws = self.platform.get_workspace(wid)
        if ws is None:
            self.runner.stop(t.handle, "workspace no longer exists")
            self._drop(wid)
            return
        if ws["status"] != t.last_status:
            t.last_status = ws["status"]
            t.workspace = ws
            self.notifier.workspace_changed(ws)
        if ws["status"] == "cancelled":
            self.runner.stop(t.handle, "workspace cancelled by the requester")
            self._drop(wid)
            return
        state = self.runner.poll(t.handle)
        now = self.clock()
        if not state.running:
            self._drop(wid)
            if ws["status"] == "pr_opened":
                self._set(ws, "completed")
            elif ws["status"] not in FINAL_STATUSES:
                detail = f"exit code {state.exit_code}" if state.exit_code is not None else (state.reason or "stopped")
                self._set(ws, "failed", error=f"workspace task ended without opening a PR ({detail})")
            return
        if ws["status"] in FINAL_STATUSES:  # failed/completed reported, task still shutting down
            self.runner.stop(t.handle, f"workspace is {ws['status']}")
            self._drop(wid)
            return
        if now - t.dispatched_at > self.cfg.max_runtime_seconds:
            self.runner.stop(t.handle, "max runtime exceeded")
            self._drop(wid)
            self._set(ws, "failed", error=f"max runtime exceeded ({self.cfg.max_runtime_seconds / 60:.0f} min); workspace stopped")
            return
        if now - t.last_activity > self.cfg.idle_timeout_seconds:
            self.runner.stop(t.handle, "idle timeout")
            self._drop(wid)
            if ws["status"] == "pr_opened":
                self._set(ws, "completed")
            else:
                self._set(ws, "failed",
                          error=f"idle timeout: no activity for {self.cfg.idle_timeout_seconds / 60:.0f} min; workspace stopped")

    def _set(self, ws: dict, status: str, *, error: str | None = None, log_url: str | None = None,
             notify: bool = True) -> dict | None:
        try:
            updated = self.platform.update_status(ws["id"], status, error=self.scrub(error) if error else None,
                                                  log_url=log_url)
        except PlatformError as exc:
            log.warning("status %s -> %s failed: %s", ws["id"], status, self.scrub(exc))
            return None
        log.info("workspace %s -> %s%s", ws["id"], status, f" ({self.scrub(error)})" if error else "")
        if notify:
            self.notifier.workspace_changed(updated)
        return updated

    # -- dispatch ----------------------------------------------------------------------------
    def capacity(self) -> int:
        with self._lock:
            return self.cfg.max_concurrent - len(self.tracked)

    def dispatch(self) -> None:
        if self.capacity() <= 0:
            return
        for ws in self.platform.list_queued():
            if self.capacity() <= 0:
                return
            try:
                claimed = self.platform.claim(ws["id"], self.cfg.worker_id)
            except ClaimConflict:
                continue  # another worker won the race, or the requester cancelled
            self.notifier.workspace_changed(claimed)
            self._start(claimed)

    def job_env(self, ws: dict) -> dict[str, str]:
        team = ws.get("team") or "unassigned"
        env = dict(self.cfg.job_env)
        env.update({
            "WORKSPACE_ID": ws["id"],
            "REPO_URL": ws["repo_url"],
            "WORK_ITEM": ws["work_item"],
            "JOB_PROFILE": ws.get("job_profile") or "general",
            "WORKSPACE_TEAM": team,
            "AIG_WS_STATUS_URL": f"{self.cfg.relay_public_url}/relay/v1/workspaces/{ws['id']}",
            # Starter-pack settings: the job is a registered AIG agent on host ecs, env workspace.
            "AIG_AGENT_ID": workspace_agent_id(team),
            "AIG_TEAM": team,
            "AIG_ENV": "workspace",
            "AIG_HOST": "ecs",
            "AIG_USER_TIER": self.cfg.user_tier,
            "AIG_JOB_PROFILE": ws.get("job_profile") or "general",
        })
        if EMAIL_OK.match(ws.get("requested_by") or ""):
            env["AIG_USER"] = ws["requested_by"]
        return env

    def _start(self, ws: dict) -> None:
        wid, team = ws["id"], ws.get("team") or "unassigned"
        try:
            agent_id = workspace_agent_id(team)
            if agent_id not in self._agents:
                owner = self.cfg.agent_owner or ws.get("requested_by") or "aig-platform@example.com"
                self.platform.ensure_agent(agent_id, team=team, owner=owner,
                                           description=f"AIG team workspace code agent for {team}")
                self._agents.add(agent_id)
            # The relay token is per workspace and only valid while it is tracked and not final.
            secret_env = {**self.secret_env, "AIG_WS_STATUS_TOKEN": mint_token(self.cfg.relay_secret, wid)}
            if self.runner.name == "ecs":
                # ECS overrides are visible to DescribeTasks; the relay token is scoped to one
                # workspace and dies with it, everything else secret comes from Secrets Manager.
                env, secret_env = {**self.job_env(ws), "AIG_WS_STATUS_TOKEN": secret_env["AIG_WS_STATUS_TOKEN"]}, {}
            else:
                env = self.job_env(ws)
            handle = self.runner.start(JobSpec(workspace_id=wid, team=team, env=env, secret_env=secret_env))
        except Exception as exc:  # runner/platform failure: the request fails visibly
            log.warning("could not start workspace %s: %s", wid, self.scrub(exc))
            self._set(ws, "failed", error=f"could not start the workspace: {exc}")
            return
        now = self.clock()
        with self._lock:
            self.tracked[wid] = Tracked(ws, handle, now, now, ws["status"])
        if handle.log_url:
            updated = self._set(ws, ws["status"], log_url=handle.log_url, notify=False)
            if updated:
                with self._lock:
                    if wid in self.tracked:
                        self.tracked[wid].workspace = updated
