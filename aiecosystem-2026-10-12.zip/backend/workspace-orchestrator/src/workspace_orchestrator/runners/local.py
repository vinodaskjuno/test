"""LocalProcessRunner: runs ``workspace-job`` as a subprocess in a temp dir (local dev and tests).

No Docker and no isolation beyond a fresh directory and a minimal environment, so it is refused
outside ``AIG_ENV=local`` (config.py). The job's output goes to ``<dir>/job.log``.
"""

from __future__ import annotations

import logging
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from collections.abc import Sequence
from pathlib import Path

from .base import JobSpec, TaskHandle, TaskState

log = logging.getLogger("workspace_orchestrator.runners.local")

# Inherited from the orchestrator's environment (nothing else is, so no secret leaks in).
BASE_ENV = ("PATH", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE",
            "PIP_INDEX_URL", "NPM_CONFIG_REGISTRY", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY")


def read_env_file(path: str | os.PathLike[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in Path(path).read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:]
        k, _, v = line.partition("=")
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        out[k.strip()] = v.replace("\\n", "\n")
    return out


class LocalProcessRunner:
    name = "local"

    def __init__(self, *, base_dir: str | None = None, command: Sequence[str] | None = None,
                 extra_env: dict[str, str] | None = None, keep_dirs: bool = False, stop_grace_seconds: float = 10.0) -> None:
        self.base_dir = Path(base_dir) if base_dir else Path(tempfile.gettempdir()) / "aig-workspaces"
        self.command = list(command or [sys.executable, "-m", "workspace_orchestrator.job"])
        self.extra_env = dict(extra_env or {})
        self.keep_dirs = keep_dirs
        self.stop_grace_seconds = stop_grace_seconds
        self._procs: dict[str, subprocess.Popen] = {}
        self._lock = threading.Lock()

    def start(self, spec: JobSpec) -> TaskHandle:
        self.base_dir.mkdir(parents=True, exist_ok=True)
        root = Path(tempfile.mkdtemp(prefix=f"ws-{spec.workspace_id[:8]}-", dir=self.base_dir))
        home = root / "home"
        home.mkdir()
        env = {k: os.environ[k] for k in BASE_ENV if k in os.environ}
        env.update({"HOME": str(home), "AIG_WS_WORKDIR": str(root / "work"), "PYTHONUNBUFFERED": "1"})
        env.update(spec.env)
        env.update(spec.secret_env)
        env.update(self.extra_env)
        log_path = root / "job.log"
        with open(log_path, "wb") as out:
            proc = subprocess.Popen(self.command, cwd=root, env=env, stdout=out, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, start_new_session=True)
        handle = TaskHandle(id=f"local-{proc.pid}", log_url=None,
                            data={"pid": proc.pid, "dir": str(root), "log": str(log_path), "workspace_id": spec.workspace_id})
        with self._lock:
            self._procs[handle.id] = proc
        log.info("started local workspace job %s for %s in %s", handle.id, spec.workspace_id, root)
        return handle

    def _proc(self, handle: TaskHandle) -> subprocess.Popen | None:
        with self._lock:
            return self._procs.get(handle.id)

    def poll(self, handle: TaskHandle) -> TaskState:
        proc = self._proc(handle)
        if proc is None:
            return TaskState(running=False, reason="process not found")
        code = proc.poll()
        if code is None:
            return TaskState(running=True)
        self._cleanup(handle)
        return TaskState(running=False, exit_code=code, reason="exited" if code >= 0 else f"signal {-code}")

    def stop(self, handle: TaskHandle, reason: str) -> None:
        proc = self._proc(handle)
        if proc is None or proc.poll() is not None:
            self._cleanup(handle)
            return
        log.info("stopping local workspace job %s: %s", handle.id, reason)
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + self.stop_grace_seconds
        while proc.poll() is None and time.monotonic() < deadline:
            time.sleep(0.05)
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.wait(5)
        self._cleanup(handle)

    def find(self, workspace_id: str) -> TaskHandle | None:
        return None  # processes do not survive an orchestrator restart

    def _cleanup(self, handle: TaskHandle) -> None:
        with self._lock:
            self._procs.pop(handle.id, None)
        if not self.keep_dirs:
            work = Path(handle.data.get("dir", "")) / "work"
            shutil.rmtree(work, ignore_errors=True)  # keep job.log for debugging
