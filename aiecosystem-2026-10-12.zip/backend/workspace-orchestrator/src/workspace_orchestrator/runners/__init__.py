"""Pluggable runners: ``EcsRunner`` (dev/stage/prod) and ``LocalProcessRunner`` (local only)."""

from __future__ import annotations

from ..config import OrchestratorConfig
from .base import JobSpec, Runner, TaskHandle, TaskState
from .ecs import EcsRunner
from .local import LocalProcessRunner, read_env_file


def build_runner(cfg: OrchestratorConfig) -> Runner:
    if cfg.runner == "ecs":
        assert cfg.ecs is not None
        return EcsRunner(cfg.ecs)
    return LocalProcessRunner(base_dir=cfg.local_workdir)


def local_secret_env(cfg: OrchestratorConfig) -> dict[str, str]:
    """Secrets for local jobs (``AIG_WS_LOCAL_JOB_ENV_FILE``); ECS jobs get them from Secrets Manager."""
    if cfg.runner != "local" or not cfg.local_job_env_file:
        return {}
    return read_env_file(cfg.local_job_env_file)


__all__ = ["EcsRunner", "JobSpec", "LocalProcessRunner", "Runner", "TaskHandle", "TaskState", "build_runner",
           "local_secret_env"]
