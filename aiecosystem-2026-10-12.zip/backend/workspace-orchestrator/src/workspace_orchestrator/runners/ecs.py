"""EcsRunner: one ECS Fargate task per workspace (``ecs.run_task`` / ``describe_tasks`` / ``stop_task``).

- Network: ``awsvpc`` in private subnets with the restricted-egress security group (Portkey,
  Fiddler, platform-api relay, the Git host and the package mirror only), no public IP.
- Non-secret job settings go into the container override environment (``WORKSPACE_ID``,
  ``REPO_URL``, ``WORK_ITEM``, ``JOB_PROFILE``, ``AIG_*``). ECS overrides cannot carry ``secrets``,
  so secrets come from Secrets Manager through the task definition: the shared ones
  (``AIG_FIDDLER_API_KEY``, ``GITHUB_APP_PRIVATE_KEY``) in the base definition, the team's Portkey
  key either from an explicit per-team task definition (``AIG_WS_ECS_TEAM_TASK_DEFINITIONS``) or
  from a derived ``<family>-<team>`` revision whose ``AIG_PORTKEY_API_KEY`` secret points at
  ``AIG_WS_ECS_PORTKEY_SECRET_ARN_TEMPLATE`` (registered once per team and reused).
- ``clientToken`` = workspace id, so a retried ``run_task`` never starts a second task;
  ``startedBy`` = ``aig-ws/<id>`` lets a restarted orchestrator find its tasks again.
"""

from __future__ import annotations

import logging
import threading
from typing import Any
from urllib.parse import quote

from ..config import EcsConfig
from .base import JobSpec, TaskHandle, TaskState

log = logging.getLogger("workspace_orchestrator.runners.ecs")

PORTKEY_SECRET_NAME = "AIG_PORTKEY_API_KEY"
# Fields of describe_task_definition that register_task_definition accepts back.
REGISTER_FIELDS = ("taskRoleArn", "executionRoleArn", "networkMode", "volumes", "placementConstraints",
                   "requiresCompatibilities", "cpu", "memory", "pidMode", "ipcMode", "proxyConfiguration",
                   "inferenceAccelerators", "ephemeralStorage", "runtimePlatform")
OVERRIDE_ENV_LIMIT = 8192  # ECS limit for the whole overrides structure (bytes)


class EcsRunnerError(RuntimeError):
    pass


def started_by(workspace_id: str) -> str:
    return f"aig-ws/{workspace_id}"[:128]


def cloudwatch_url(region: str, group: str, stream: str) -> str:
    """Console deep link to one log stream (the console double-encodes: '%' -> '$25')."""
    def enc(s: str) -> str:
        return quote(quote(s, safe=""), safe="").replace("%", "$")
    return (f"https://{region}.console.aws.amazon.com/cloudwatch/home?region={region}"
            f"#logsV2:log-groups/log-group/{enc(group)}/log-events/{enc(stream)}")


class EcsRunner:
    name = "ecs"

    def __init__(self, config: EcsConfig, *, client: Any = None) -> None:
        self.cfg = config
        if client is None:
            import boto3  # lazy: tests pass a stubbed client

            client = boto3.client("ecs", region_name=config.region)
        self.ecs = client
        self.region = config.region or getattr(getattr(client, "meta", None), "region_name", None) or "us-east-1"
        self._team_defs: dict[str, str] = {}
        self._lock = threading.Lock()

    # -- task definitions ------------------------------------------------------------------
    def task_definition_for(self, team: str) -> str:
        if team in self.cfg.team_task_definitions:
            return self.cfg.team_task_definitions[team]
        if not self.cfg.portkey_secret_arn_template:
            return self.cfg.task_definition
        with self._lock:
            if team not in self._team_defs:
                self._team_defs[team] = self._derive(team)
            return self._team_defs[team]

    def portkey_secret_arn(self, team: str) -> str:
        assert self.cfg.portkey_secret_arn_template
        return self.cfg.portkey_secret_arn_template.format(team=team, env=self.cfg.env)

    def _container(self, td: dict) -> dict:
        for c in td.get("containerDefinitions", []):
            if c.get("name") == self.cfg.container_name:
                return c
        raise EcsRunnerError(f"task definition {td.get('family')} has no container {self.cfg.container_name!r}")

    def _derive(self, team: str) -> str:
        """``<base family>-<team>``: the base definition with the team's Portkey key secret."""
        arn = self.portkey_secret_arn(team)
        base = self.ecs.describe_task_definition(taskDefinition=self.cfg.task_definition)["taskDefinition"]
        family = f"{base['family']}-{team}"[:255]
        try:
            existing = self.ecs.describe_task_definition(taskDefinition=family)["taskDefinition"]
            secrets = {s["name"]: s["valueFrom"] for s in self._container(existing).get("secrets", [])}
            image = self._container(existing).get("image")
            if secrets.get(PORTKEY_SECRET_NAME) == arn and image == self._container(base).get("image"):
                return existing["taskDefinitionArn"]
        except self.ecs.exceptions.ClientException:
            pass  # family not registered yet
        containers = []
        for c in base["containerDefinitions"]:
            c = dict(c)
            if c.get("name") == self.cfg.container_name:
                secrets = [s for s in c.get("secrets", []) if s["name"] != PORTKEY_SECRET_NAME]
                c["secrets"] = [*secrets, {"name": PORTKEY_SECRET_NAME, "valueFrom": arn}]
            containers.append(c)
        kwargs = {k: base[k] for k in REGISTER_FIELDS if base.get(k) not in (None, [], {})}
        resp = self.ecs.register_task_definition(
            family=family, containerDefinitions=containers,
            tags=[{"key": "aig:team", "value": team}, {"key": "aig:component", "value": "workspace"}], **kwargs)
        out = resp["taskDefinition"]["taskDefinitionArn"]
        log.info("registered workspace task definition %s for team %s", out, team)
        return out

    # -- tasks -------------------------------------------------------------------------------
    def start(self, spec: JobSpec) -> TaskHandle:
        environment = [{"name": k, "value": v} for k, v in sorted(spec.env.items())]
        if sum(len(e["name"]) + len(e["value"]) + 32 for e in environment) > OVERRIDE_ENV_LIMIT:
            raise EcsRunnerError("container override environment exceeds the ECS 8 KiB limit")
        kwargs: dict[str, Any] = {
            "cluster": self.cfg.cluster,
            "taskDefinition": self.task_definition_for(spec.team),
            "count": 1,
            "platformVersion": self.cfg.platform_version,
            "networkConfiguration": {"awsvpcConfiguration": {
                "subnets": list(self.cfg.subnets),
                "securityGroups": list(self.cfg.security_groups),
                "assignPublicIp": "ENABLED" if self.cfg.assign_public_ip else "DISABLED",
            }},
            "overrides": {"containerOverrides": [{"name": self.cfg.container_name, "environment": environment}]},
            "startedBy": started_by(spec.workspace_id),
            "clientToken": spec.workspace_id[:64],
            "enableExecuteCommand": False,
            "propagateTags": "TASK_DEFINITION",
            "tags": [{"key": "aig:workspace-id", "value": spec.workspace_id},
                     {"key": "aig:team", "value": spec.team},
                     {"key": "aig:env", "value": self.cfg.env}],
        }
        if self.cfg.capacity_provider:
            kwargs["capacityProviderStrategy"] = [{"capacityProvider": self.cfg.capacity_provider, "weight": 1}]
        else:
            kwargs["launchType"] = "FARGATE"
        resp = self.ecs.run_task(**kwargs)
        tasks = resp.get("tasks") or []
        if not tasks:
            failures = "; ".join(f"{f.get('arn', '')} {f.get('reason', '')} {f.get('detail', '')}".strip()
                                 for f in resp.get("failures") or []) or "no task started"
            raise EcsRunnerError(f"ecs run_task failed: {failures}"[:500])
        arn = tasks[0]["taskArn"]
        log.info("started ECS task %s for workspace %s", arn, spec.workspace_id)
        return TaskHandle(id=arn, log_url=self.log_url(arn), data={"workspace_id": spec.workspace_id})

    def log_url(self, task_arn: str) -> str | None:
        if not self.cfg.log_group:
            return None
        task_id = task_arn.rsplit("/", 1)[-1]
        stream = f"{self.cfg.log_stream_prefix}/{self.cfg.container_name}/{task_id}"
        return cloudwatch_url(self.region, self.cfg.log_group, stream)

    def poll(self, handle: TaskHandle) -> TaskState:
        resp = self.ecs.describe_tasks(cluster=self.cfg.cluster, tasks=[handle.id])
        tasks = resp.get("tasks") or []
        if not tasks:
            return TaskState(running=False, reason="task not found")
        task = tasks[0]
        if task.get("lastStatus") != "STOPPED":
            return TaskState(running=True)
        code = None
        for c in task.get("containers", []):
            if c.get("name") == self.cfg.container_name:
                code = c.get("exitCode")
                if code is None and c.get("reason"):
                    return TaskState(running=False, reason=str(c["reason"])[:300])
        return TaskState(running=False, exit_code=code, reason=str(task.get("stoppedReason") or "stopped")[:300])

    def stop(self, handle: TaskHandle, reason: str) -> None:
        try:
            self.ecs.stop_task(cluster=self.cfg.cluster, task=handle.id, reason=reason[:255])
            log.info("stopped ECS task %s: %s", handle.id, reason)
        except self.ecs.exceptions.InvalidParameterException:
            log.info("ECS task %s already gone", handle.id)

    def find(self, workspace_id: str) -> TaskHandle | None:
        arns = self.ecs.list_tasks(cluster=self.cfg.cluster, startedBy=started_by(workspace_id),
                                   desiredStatus="RUNNING").get("taskArns") or []
        if not arns:
            return None
        return TaskHandle(id=arns[0], log_url=self.log_url(arns[0]), data={"workspace_id": workspace_id})
