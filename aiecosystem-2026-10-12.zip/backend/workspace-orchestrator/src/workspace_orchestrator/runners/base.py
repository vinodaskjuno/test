"""Runner interface: where a workspace job runs (ECS Fargate task or a local process)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass(frozen=True)
class JobSpec:
    """One workspace job.

    ``env`` is non-secret (it may end up in ECS task overrides, visible to DescribeTasks).
    ``secret_env`` is only used by runners that have no secret store (LocalProcessRunner); the
    ECS runner ignores it and takes secrets from Secrets Manager via the task definition.
    """

    workspace_id: str
    team: str
    env: dict[str, str]
    secret_env: dict[str, str] = field(default_factory=dict)


@dataclass
class TaskHandle:
    id: str  # ECS task ARN or local-<pid>
    log_url: str | None = None
    data: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TaskState:
    running: bool
    exit_code: int | None = None
    reason: str | None = None


class Runner(Protocol):
    name: str

    def start(self, spec: JobSpec) -> TaskHandle: ...

    def poll(self, handle: TaskHandle) -> TaskState: ...

    def stop(self, handle: TaskHandle, reason: str) -> None: ...

    def find(self, workspace_id: str) -> TaskHandle | None:
        """A still-running task for this workspace (orchestrator restart recovery), if any."""
        ...
