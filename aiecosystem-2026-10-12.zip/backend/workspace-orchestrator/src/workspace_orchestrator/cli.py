"""``workspace-orchestrator`` CLI.

    workspace-orchestrator serve     relay (HTTP) + worker loop (default)
    workspace-orchestrator once      one worker tick (claim/dispatch/reconcile) and exit
    workspace-orchestrator config    validate the configuration (prints no secret)
"""

from __future__ import annotations

import argparse
import logging
import sys
import threading

from .config import ConfigError, OrchestratorConfig
from .notify import Notifier
from .platform import PlatformClient
from .relay import create_relay_app
from .runners import build_runner, local_secret_env
from .scrub import Scrubber, configure_logging
from .worker import Worker

log = logging.getLogger("workspace_orchestrator")


def build(cfg: OrchestratorConfig) -> tuple[Worker, object]:
    secret_env = local_secret_env(cfg)
    scrubber = Scrubber([cfg.service_token, cfg.relay_secret, cfg.notify_secret or "", *secret_env.values()])
    configure_logging(scrubber, cfg.log_level)
    platform = PlatformClient(cfg.platform_api_url, cfg.service_token)
    notifier = Notifier(cfg.notify_urls, cfg.notify_secret)
    worker = Worker(cfg, platform, build_runner(cfg), notifier=notifier, scrubber=scrubber, secret_env=secret_env)
    app = create_relay_app(secret=cfg.relay_secret, platform=platform, worker=worker, notifier=notifier, scrubber=scrubber)
    return worker, app


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="workspace-orchestrator", description="AIG team workspace orchestrator")
    parser.add_argument("command", nargs="?", default="serve", choices=("serve", "once", "config"))
    args = parser.parse_args(argv)
    try:
        cfg = OrchestratorConfig.from_env()
    except ConfigError as exc:
        print(f"workspace-orchestrator: {exc}", file=sys.stderr)
        return 2
    if args.command == "config":
        print(cfg)
        return 0
    worker, app = build(cfg)
    if args.command == "once":
        worker.tick()
        return 0
    import uvicorn

    thread = threading.Thread(target=worker.run_forever, name="worker", daemon=True)
    thread.start()
    log.info("relay listening on %s:%s (public %s)", cfg.relay_host, cfg.relay_port, cfg.relay_public_url)
    try:
        uvicorn.run(app, host=cfg.relay_host, port=cfg.relay_port, log_level="warning", access_log=False)
    finally:
        worker.stop()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
