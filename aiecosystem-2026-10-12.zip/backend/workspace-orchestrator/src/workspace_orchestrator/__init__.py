"""AIG team workspaces (Phase 6): ``workspace-orchestrator`` (worker + relay) and ``workspace-job``.

    request (Web UI / Teams) -> platform-api ``queued``
      -> orchestrator claims it (``provisioning``) and starts an isolated task (ECS Fargate or a
         local process) running ``workspace-job``
      -> job: clone, branch, code agent through Portkey (traced to Fiddler), tests + evals,
         commit, push, PR (``running`` -> ``testing`` -> ``pr_opened``)
      -> orchestrator spins the task down (``completed``), or stops it on cancel / idle timeout /
         max runtime (``cancelled`` / ``failed``).
"""

__version__ = "0.1.0"
