"""platform-api client for the orchestrator (service token, ``x-aig-service-token``)."""

from __future__ import annotations

import logging
from typing import Any

import httpx

log = logging.getLogger("workspace_orchestrator.platform")

SERVICE_HEADER = "x-aig-service-token"
FINAL_STATUSES = frozenset({"completed", "failed", "cancelled"})
ACTIVE_STATUSES = frozenset({"provisioning", "running", "testing", "pr_opened"})


class PlatformError(RuntimeError):
    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(f"platform-api {status} {code}: {message}")
        self.status = status
        self.code = code


class ClaimConflict(PlatformError):
    pass


def _error(resp: httpx.Response) -> PlatformError:
    try:
        err = resp.json().get("error") or {}
    except ValueError:
        err = {}
    cls = ClaimConflict if resp.status_code == 409 else PlatformError
    return cls(resp.status_code, str(err.get("code") or "http_error"), str(err.get("message") or resp.reason_phrase)[:300])


class PlatformClient:
    def __init__(self, base_url: str, service_token: str, *, client: httpx.Client | None = None, timeout: float = 15.0) -> None:
        self._base = base_url.rstrip("/")
        self._token = service_token
        self._client = client or httpx.Client(timeout=timeout)

    def _request(self, method: str, path: str, **kw: Any) -> httpx.Response:
        headers = {SERVICE_HEADER: self._token, **kw.pop("headers", {})}
        return self._client.request(method, f"{self._base}{path}", headers=headers, **kw)

    def _json(self, method: str, path: str, ok: tuple[int, ...] = (200,), **kw: Any) -> dict:
        resp = self._request(method, path, **kw)
        if resp.status_code not in ok:
            raise _error(resp)
        return resp.json()

    # -- workspaces ----------------------------------------------------------------------
    def list_workspaces(self, status: str | None = None) -> list[dict]:
        params = {"status": status} if status else None
        return list(self._json("GET", "/api/v1/workspaces", params=params).get("items") or [])

    def list_queued(self) -> list[dict]:
        """Queued requests, oldest first (the API lists newest first)."""
        items = self.list_workspaces("queued")
        return sorted(items, key=lambda w: (w.get("created_at") or "", w.get("id") or ""))

    def get_workspace(self, workspace_id: str) -> dict | None:
        resp = self._request("GET", f"/api/v1/workspaces/{workspace_id}")
        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            raise _error(resp)
        return resp.json()

    def claim(self, workspace_id: str, worker: str) -> dict:
        """Atomic queued -> provisioning. Raises ``ClaimConflict`` when another worker won."""
        return self._json("POST", f"/api/v1/workspaces/{workspace_id}/claim", json={"worker": worker})

    def update_status(self, workspace_id: str, status: str, *, pr_url: str | None = None,
                      log_url: str | None = None, error: str | None = None) -> dict:
        body: dict[str, Any] = {"status": status}
        if pr_url:
            body["pr_url"] = pr_url
        if log_url:
            body["log_url"] = log_url
        if error:
            body["error"] = error[:4000]
        return self._json("PATCH", f"/api/v1/workspaces/{workspace_id}/status", json=body)

    # -- agents (workspace.<team> registration, relay reads) ------------------------------
    def get_agent(self, agent_id: str) -> dict | None:
        resp = self._request("GET", f"/api/v1/agents/{agent_id}")
        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            raise _error(resp)
        return resp.json().get("agent")

    def ensure_agent(self, agent_id: str, *, team: str, owner: str, description: str) -> bool:
        """Register the agent if it does not exist. Returns True when it was created."""
        resp = self._request("POST", "/api/v1/agents", json={
            "agent_id": agent_id, "name": agent_id, "team": team, "owner": owner, "description": description[:500],
        })
        if resp.status_code == 201:
            log.info("registered agent %s for team %s", agent_id, team)
            return True
        if resp.status_code == 409:
            return False
        raise _error(resp)

    # -- raw proxy (the relay forwards a narrow allow-list) --------------------------------
    def forward(self, method: str, path: str, *, params: Any = None, content: bytes | None = None,
                content_type: str | None = None) -> httpx.Response:
        headers = {"content-type": content_type} if content_type else {}
        return self._request(method, path, params=params, content=content, headers=headers)
