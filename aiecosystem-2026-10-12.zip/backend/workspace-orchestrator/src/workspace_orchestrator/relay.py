"""Workspace relay: the only platform-api access a workspace task has.

Workspace tasks never hold ``PLATFORM_SERVICE_TOKEN`` (it can suspend agents and edit the model
catalog). Each task gets a token scoped to its own workspace,
``aigws1.<hex HMAC-SHA256(AIG_WS_RELAY_SECRET, "ws:<id>")>``, and calls the orchestrator's relay,
which forwards a narrow allow-list with the service token:

| Method | Path (under ``/relay/v1/workspaces/{id}``) | Forwards to |
|---|---|---|
| GET  | ``""`` | ``GET /api/v1/workspaces/{id}`` |
| POST | ``/status`` ``{status, pr_url?, error?}`` (running, testing, pr_opened, failed) | ``PATCH /api/v1/workspaces/{id}/status`` |
| POST | ``/heartbeat`` | nothing (idle-timeout activity) |
| GET  | ``/platform/api/v1/agents/{agent_id}`` (``workspace.<team>`` or an agent of the same team) | same path |
| GET  | ``/platform/api/v1/evals?agent_id=`` | same path |
| POST | ``/platform/api/v1/evals`` (agent of the workspace's team) | same path (``aig eval run --post``) |

The job points ``AIG_PLATFORM_API_URL`` at ``.../platform`` and uses its token as
``AIG_PLATFORM_API_TOKEN``, so the unmodified starter pack (``aig_sdk.init()``, ``aig eval``)
works through it. The token is accepted as ``x-aig-workspace-token``, ``x-aig-service-token`` or
``Authorization: Bearer``. Calls for a final (completed/failed/cancelled) workspace answer 409.
Every accepted call counts as activity for the idle timeout.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import re
from typing import TYPE_CHECKING

from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from .config import workspace_agent_id
from .platform import FINAL_STATUSES, PlatformClient, PlatformError
from .scrub import Scrubber

if TYPE_CHECKING:  # pragma: no cover
    from .notify import Notifier
    from .worker import Worker

log = logging.getLogger("workspace_orchestrator.relay")

TOKEN_PREFIX = "aigws1."
JOB_STATUSES = frozenset({"running", "testing", "pr_opened", "failed"})
AGENT_PATH = re.compile(r"^api/v1/agents/([A-Za-z0-9._-]{1,64})$")
MAX_BODY = 256 * 1024


def mint_token(secret: str, workspace_id: str) -> str:
    return TOKEN_PREFIX + hmac.new(secret.encode(), f"ws:{workspace_id}".encode(), hashlib.sha256).hexdigest()


def verify_token(secret: str, workspace_id: str, token: str | None) -> bool:
    return bool(token) and hmac.compare_digest(mint_token(secret, workspace_id), token or "")


def _token(request: Request) -> str | None:
    for name in ("x-aig-workspace-token", "x-aig-service-token"):
        if request.headers.get(name):
            return request.headers[name].strip()
    auth = request.headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return None


def _err(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "message": message}}, status_code=status)


def create_relay_app(*, secret: str, platform: PlatformClient, worker: Worker | None = None,
                     notifier: Notifier | None = None, scrubber: Scrubber | None = None) -> Starlette:
    scrub = scrubber or Scrubber([secret])
    scrub.add(secret)
    scrub.add(getattr(platform, "_token", None))

    def authorize(request: Request) -> tuple[str, dict] | Response:
        wid = request.path_params["wid"]
        if not verify_token(secret, wid, _token(request)):
            return _err(401, "workspace_unauthenticated", "missing or invalid workspace token")
        try:
            ws = platform.get_workspace(wid)
        except PlatformError as exc:
            return _err(502, "platform_unavailable", scrub(exc))
        if ws is None:
            return _err(404, "workspace_not_found", "workspace not found")
        if ws["status"] in FINAL_STATUSES:
            return _err(409, "workspace_closed", f"workspace is {ws['status']}")
        if worker is not None:
            worker.record_activity(wid)
        return wid, ws

    async def get_workspace(request: Request) -> Response:
        auth = await run_in_threadpool(authorize, request)
        if isinstance(auth, Response):
            return auth
        return JSONResponse(auth[1])

    async def heartbeat(request: Request) -> Response:
        auth = await run_in_threadpool(authorize, request)
        return auth if isinstance(auth, Response) else Response(status_code=204)

    async def status(request: Request) -> Response:
        auth = await run_in_threadpool(authorize, request)
        if isinstance(auth, Response):
            return auth
        wid, ws = auth
        try:
            body = json.loads(await request.body() or b"{}")
        except ValueError:
            return _err(400, "invalid_json", "body is not JSON")
        if not isinstance(body, dict) or body.get("status") not in JOB_STATUSES:
            return _err(400, "invalid_request", f"status must be one of {sorted(JOB_STATUSES)}")
        if body["status"] == "pr_opened" and not body.get("pr_url"):
            return _err(400, "invalid_request", "pr_opened needs pr_url")
        try:
            updated = await run_in_threadpool(
                lambda: platform.update_status(wid, body["status"], pr_url=body.get("pr_url"),
                                               error=scrub(body["error"]) if body.get("error") else None))
        except PlatformError as exc:
            return _err(exc.status if exc.status < 500 else 502, exc.code, scrub(exc))
        log.info("workspace %s reported %s", wid, body["status"])
        if worker is not None:
            worker.record_activity(wid, status=updated["status"], workspace=updated)
        if notifier is not None and updated["status"] != ws["status"]:
            await run_in_threadpool(notifier.workspace_changed, updated)
        return JSONResponse(updated)

    def agent_allowed(ws: dict, agent_id: str) -> bool:
        team = ws.get("team") or "unassigned"
        if agent_id == workspace_agent_id(team):
            return True
        try:
            agent = platform.get_agent(agent_id)
        except PlatformError:
            return False
        return bool(agent) and agent.get("team") == team

    async def platform_proxy(request: Request) -> Response:
        auth = await run_in_threadpool(authorize, request)
        if isinstance(auth, Response):
            return auth
        _, ws = auth
        path = request.path_params["path"].strip("/")
        method = request.method
        body = await request.body()
        if len(body) > MAX_BODY:
            return _err(413, "payload_too_large", "body too large")
        allowed = False
        if method == "GET" and (m := AGENT_PATH.match(path)):
            allowed = await run_in_threadpool(agent_allowed, ws, m.group(1))
        elif path == "api/v1/evals" and method == "GET":
            allowed = True
        elif path == "api/v1/evals" and method == "POST":
            try:
                agent_id = str(json.loads(body or b"{}").get("agent_id") or "")
            except (ValueError, AttributeError):
                return _err(400, "invalid_json", "body is not a JSON object")
            allowed = bool(agent_id) and await run_in_threadpool(agent_allowed, ws, agent_id)
        if not allowed:
            return _err(403, "forbidden", f"{method} /{path} is not available to workspaces")
        try:
            resp = await run_in_threadpool(
                lambda: platform.forward(method, f"/{path}", params=list(request.query_params.multi_items()),
                                         content=body or None, content_type=request.headers.get("content-type")))
        except Exception as exc:  # network error to platform-api
            return _err(502, "platform_unavailable", scrub(type(exc).__name__))
        return Response(resp.content, status_code=resp.status_code,
                        media_type=resp.headers.get("content-type", "application/json"))

    async def healthz(request: Request) -> Response:
        tracked = len(worker.tracked) if worker is not None else 0
        return JSONResponse({"status": "ok", "tracked": tracked})

    base = "/relay/v1/workspaces/{wid}"
    return Starlette(routes=[
        Route("/healthz", healthz),
        Route(base, get_workspace, methods=["GET"]),
        Route(f"{base}/heartbeat", heartbeat, methods=["POST"]),
        Route(f"{base}/status", status, methods=["POST"]),
        Route(base + "/platform/{path:path}", platform_proxy, methods=["GET", "POST"]),
    ])
