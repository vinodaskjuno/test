"""Secret scrubbing for logs, status errors and PR bodies.

Every secret value the process knows (env vars named like keys/tokens, tokens minted at runtime)
is registered here and replaced by ``***``. Token-shaped strings (GitHub tokens, bearer tokens,
URL credentials, PEM blocks) are masked even when their value was never registered.
"""

from __future__ import annotations

import logging
import re
import threading
from collections.abc import Iterable, Mapping

MASK = "***"

# Env var names whose values are always treated as secrets.
SECRET_NAME_RE = re.compile(r"(KEY|TOKEN|SECRET|PASSWORD|PRIVATE|CREDENTIAL|AUTH)", re.IGNORECASE)
# Names that match the pattern above but are not secret.
NOT_SECRET_NAMES = frozenset({
    "AIG_PLATFORM_API_AUTH", "AIG_WS_CLAUDE_PERMISSION_MODE", "GITHUB_APP_ID", "GITHUB_APP_INSTALLATION_ID",
    "ANTHROPIC_BASE_URL", "AIG_WS_ECS_PORTKEY_SECRET_ARN_TEMPLATE",
})
# Shorter values are never registered (would mask ordinary words).
MIN_SECRET_LEN = 8

PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S), MASK),
    (re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"), MASK),
    (re.compile(r"(?i)\b(bearer|basic|token)\s+[A-Za-z0-9._~+/=-]{12,}"), r"\1 " + MASK),
    (re.compile(r"(?i)(x-access-token|oauth2):[^@\s/]+@"), r"\1:" + MASK + "@"),
    (re.compile(r"(?i)(https?://)[^/\s:@]+:[^/\s@]+@"), r"\1" + MASK + "@"),
    (re.compile(r"(?i)(x-portkey-api-key|x-aig-service-token|x-aig-workspace-token|authorization)(\s*[:=]\s*)[^\s,;\"']+"),
     r"\1\2" + MASK),
    (re.compile(r"\baigws1\.[0-9a-f]{16,}\b"), MASK),
    (re.compile(r"(?i)\b([a-z0-9_-]*(?:token|secret|password|passwd|api[_-]?key))(\s*[=:]\s*)(?!\*\*\*)[^\s,;\"']{6,}"),
     r"\1\2" + MASK),
)


class Scrubber:
    def __init__(self, secrets: Iterable[str] = ()) -> None:
        self._lock = threading.Lock()
        self._values: set[str] = set()
        for s in secrets:
            self.add(s)

    def add(self, value: str | None) -> None:
        if not value:
            return
        value = str(value).strip()
        if len(value) < MIN_SECRET_LEN:
            return
        with self._lock:
            self._values.add(value)
            # PEM keys also appear with escaped newlines (env files, JSON).
            if "\n" in value:
                self._values.add(value.replace("\n", "\\n"))

    def add_env(self, env: Mapping[str, str]) -> None:
        for name, value in env.items():
            if is_secret_name(name):
                self.add(value)

    def __call__(self, text: object) -> str:
        out = "" if text is None else str(text)
        with self._lock:
            values = sorted(self._values, key=len, reverse=True)
        for v in values:
            if v in out:
                out = out.replace(v, MASK)
        for pattern, repl in PATTERNS:
            out = pattern.sub(repl, out)
        return out


def is_secret_name(name: str) -> bool:
    if name in NOT_SECRET_NAMES or name.startswith("GIT_CONFIG_"):  # git's env config (KEY_n/VALUE_n pairs)
        return False
    return bool(SECRET_NAME_RE.search(name))


class ScrubFilter(logging.Filter):
    """Logging filter: scrubs the formatted message (args included) of every record."""

    def __init__(self, scrubber: Scrubber) -> None:
        super().__init__()
        self.scrubber = scrubber

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # pragma: no cover - malformed record
            return True
        record.msg, record.args = self.scrubber(msg), ()
        if record.exc_info and not record.exc_text:
            record.exc_text = logging.Formatter().formatException(record.exc_info)
        if record.exc_text:
            record.exc_text = self.scrubber(record.exc_text)
        return True


def configure_logging(scrubber: Scrubber, level: str = "INFO") -> None:
    root = logging.getLogger()
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        root.addHandler(handler)
    for h in root.handlers:
        if not any(isinstance(f, ScrubFilter) for f in h.filters):
            h.addFilter(ScrubFilter(scrubber))
    root.setLevel(getattr(logging, (level or "INFO").upper(), logging.INFO))
    # httpx logs full request URLs at INFO; keep it at WARNING.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("botocore").setLevel(logging.WARNING)
