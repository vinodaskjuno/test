"""git for the workspace job.

The GitHub token is passed per command as an ``http.extraHeader`` through ``GIT_CONFIG_COUNT`` /
``GIT_CONFIG_KEY_n`` / ``GIT_CONFIG_VALUE_n`` (git >= 2.31): it is never part of a command line,
a remote URL or ``.git/config``, so neither ``ps`` nor the repository (which the code agent and
the tests can read) ever contains it. Extra git config from the environment (``GIT_CONFIG_*`` set
by the orchestrator, e.g. ``url.<base>.insteadOf`` for mirrors) is kept.
"""

from __future__ import annotations

import base64
import os
import subprocess
from collections.abc import Mapping, Sequence

from ..scrub import Scrubber


class GitError(RuntimeError):
    pass


def _existing_config(env: Mapping[str, str]) -> list[tuple[str, str]]:
    try:
        count = int(env.get("GIT_CONFIG_COUNT", "0"))
    except ValueError:
        count = 0
    return [(env.get(f"GIT_CONFIG_KEY_{i}", ""), env.get(f"GIT_CONFIG_VALUE_{i}", "")) for i in range(count)]


def git_env(base: Mapping[str, str], *, token: str | None = None, extra: Sequence[tuple[str, str]] = ()) -> dict[str, str]:
    env = dict(base)
    pairs = _existing_config(env) + list(extra)
    if token:
        basic = base64.b64encode(f"x-access-token:{token}".encode()).decode()
        pairs.append(("http.extraHeader", f"Authorization: Basic {basic}"))
    for k in [k for k in env if k.startswith("GIT_CONFIG_KEY_") or k.startswith("GIT_CONFIG_VALUE_")]:
        del env[k]
    env["GIT_CONFIG_COUNT"] = str(len(pairs))
    for i, (k, v) in enumerate(pairs):
        env[f"GIT_CONFIG_KEY_{i}"] = k
        env[f"GIT_CONFIG_VALUE_{i}"] = v
    env["GIT_TERMINAL_PROMPT"] = "0"
    env.setdefault("GIT_ASKPASS", "/bin/false")
    return env


class Git:
    def __init__(self, cwd: str, *, env: Mapping[str, str], scrub: Scrubber, timeout: float = 600.0) -> None:
        self.cwd = cwd
        self.env = dict(env)
        self.scrub = scrub
        self.timeout = timeout

    def run(self, *args: str, token: str | None = None, cwd: str | None = None, check: bool = True) -> str:
        env = git_env(self.env, token=token)
        try:
            p = subprocess.run(["git", *args], cwd=cwd or self.cwd, env=env, capture_output=True, text=True,
                               timeout=self.timeout, stdin=subprocess.DEVNULL)
        except subprocess.TimeoutExpired as exc:
            raise GitError(f"git {args[0]} timed out") from exc
        if check and p.returncode != 0:
            raise GitError(self.scrub(f"git {args[0]} failed ({p.returncode}): {(p.stderr or p.stdout).strip()[-800:]}"))
        return p.stdout.strip()

    def clone(self, url: str, dest: str, *, token: str | None = None, depth: int = 1) -> None:
        os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
        self.run("clone", "--depth", str(depth), "--no-tags", url, dest, token=token, cwd=os.path.dirname(dest) or ".")

    def default_branch(self) -> str:
        return self.run("rev-parse", "--abbrev-ref", "HEAD")

    def changed_files(self) -> list[str]:
        out = self.run("status", "--porcelain", "--untracked-files=all")
        return [line[3:] for line in out.splitlines() if line.strip()]
