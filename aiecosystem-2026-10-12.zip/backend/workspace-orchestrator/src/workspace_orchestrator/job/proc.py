"""Subprocess helper: streams output (activity heartbeats), keeps a scrubbed tail, enforces a timeout."""

from __future__ import annotations

import os
import signal
import subprocess
import threading
import time
from collections import deque
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass

from ..scrub import Scrubber


@dataclass
class ProcResult:
    code: int
    output: str  # scrubbed tail
    timed_out: bool = False
    lines: list[str] | None = None  # full (scrubbed) output when keep_lines=True

    @property
    def ok(self) -> bool:
        return self.code == 0 and not self.timed_out


def run(cmd: Sequence[str] | str, *, cwd: str, env: Mapping[str, str], timeout: float, scrub: Scrubber,
        on_line: Callable[[str], None] | None = None, tail_lines: int = 80, keep_lines: bool = False,
        echo: Callable[[str], None] | None = print) -> ProcResult:
    """Run ``cmd`` (a list, or a shell string) and stream its combined output line by line."""
    shell = isinstance(cmd, str)
    proc = subprocess.Popen(cmd, cwd=cwd, env=dict(env), shell=shell, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True, errors="replace",
                            bufsize=1, start_new_session=True)
    tail: deque[str] = deque(maxlen=tail_lines)
    lines: list[str] = []
    timed_out = threading.Event()

    def kill() -> None:
        timed_out.set()
        try:
            os.killpg(proc.pid, signal.SIGTERM)
            time.sleep(3)
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    timer = threading.Timer(timeout, kill)
    timer.daemon = True
    timer.start()
    try:
        assert proc.stdout is not None
        for raw in proc.stdout:
            line = raw.rstrip("\n")
            clean = scrub(line)
            tail.append(clean)
            if keep_lines:
                lines.append(clean)
            if echo:
                echo(clean)
            if on_line:
                on_line(line)
        code = proc.wait()
    finally:
        timer.cancel()
    return ProcResult(code=code, output="\n".join(tail), timed_out=timed_out.is_set(), lines=lines if keep_lines else None)
