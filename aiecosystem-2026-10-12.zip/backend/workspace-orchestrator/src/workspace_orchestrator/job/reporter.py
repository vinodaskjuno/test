"""The job's channel to the orchestrator relay (status, heartbeats, workspace details)."""

from __future__ import annotations

import logging
import time

import httpx

log = logging.getLogger("workspace_job.reporter")


class ReporterError(RuntimeError):
    pass


class RelayReporter:
    def __init__(self, base_url: str, token: str, *, client: httpx.Client | None = None,
                 heartbeat_seconds: float = 60.0, clock=time.monotonic) -> None:
        self.base = base_url.rstrip("/")
        self._headers = {"x-aig-workspace-token": token}
        self._client = client or httpx.Client(timeout=20.0)
        self.heartbeat_seconds = heartbeat_seconds
        self._clock = clock
        self._last_beat = 0.0
        self.status: str | None = None
        self.closed = False  # the workspace became final (e.g. cancelled) while the job ran

    @property
    def platform_url(self) -> str:
        """``AIG_PLATFORM_API_URL`` for the starter pack inside the workspace."""
        return f"{self.base}/platform"

    def _call(self, method: str, path: str = "", **kw) -> httpx.Response:
        last: Exception | None = None
        for attempt in range(4):
            try:
                resp = self._client.request(method, f"{self.base}{path}", headers=self._headers, **kw)
                if resp.status_code < 500:
                    return resp
                last = ReporterError(f"relay answered {resp.status_code}")
            except httpx.HTTPError as exc:
                last = exc
            time.sleep(min(0.5 * 2 ** attempt, 4))
        raise ReporterError(f"relay unreachable: {type(last).__name__}")

    def workspace(self) -> dict:
        resp = self._call("GET")
        if resp.status_code != 200:
            raise ReporterError(f"could not read the workspace ({resp.status_code})")
        return resp.json()

    def report(self, status: str, *, pr_url: str | None = None, error: str | None = None) -> dict:
        body: dict = {"status": status}
        if pr_url:
            body["pr_url"] = pr_url
        if error:
            body["error"] = error[:4000]
        resp = self._call("POST", "/status", json=body)
        if resp.status_code != 200:
            code = ""
            try:
                code = resp.json()["error"]["code"]
            except Exception:  # noqa: BLE001
                pass
            raise ReporterError(f"status {status} refused ({resp.status_code} {code})".strip())
        self.status = status
        self._last_beat = self._clock()
        return resp.json()

    def heartbeat(self, force: bool = False) -> None:
        """Activity signal for the idle timeout (throttled to one call per ``heartbeat_seconds``)."""
        now = self._clock()
        if not force and now - self._last_beat < self.heartbeat_seconds:
            return
        self._last_beat = now
        try:  # one attempt, never raises: called from output callbacks
            resp = self._client.post(f"{self.base}/heartbeat", headers=self._headers)
            if resp.status_code == 409:
                self.closed = True
        except httpx.HTTPError as exc:
            log.warning("heartbeat failed: %s", type(exc).__name__)
