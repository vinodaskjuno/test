"""``workspace-job``: the code inside the workspace container (one run per workspace).

    running:  read the workspace (relay) -> aig_sdk.init() (fail-closed: Portkey, Fiddler,
              registered agent workspace.<team>) -> GitHub token -> shallow clone -> branch
              aig/ws-<id> -> setup -> code agent (Claude Code through Portkey, traced)
    testing:  unit + functional tests (up to AIG_WS_FIX_ATTEMPTS agent rounds on failure)
              -> commit (author "AIG Code Agent") -> evals (aig eval run --post) if aig-eval.yaml
    pr_opened: push -> pull request linked to the work item, with the test/eval summary
    failed:   any step failed: error + scrubbed summary, no PR

It always exits (0 = PR opened, 1 = failed), so the task spins down; the orchestrator then marks
the workspace ``completed`` (or stops it on idle timeout / max runtime / cancel). Secrets (Portkey
key, Fiddler key, GitHub token, relay token) never reach logs, the PR body, the error text, the
test processes or the repository.
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import time
import traceback
from collections.abc import Mapping
from contextlib import nullcontext
from dataclasses import dataclass, field

from ..scrub import Scrubber, configure_logging, is_secret_name
from .agents import AgentContext, AgentResult, CodeAgent, build_agent, claude_env
from .checks import Checks, StepResult
from .git import Git
from .github import GitHubAuth, GitHubClient, GitHubError, RepoRef, api_base, parse_repo, work_item_link
from .reporter import RelayReporter, ReporterError

log = logging.getLogger("workspace_job")

COMMIT_NAME = "AIG Code Agent"
DEFAULT_COMMIT_EMAIL = "aig-code-agent@users.noreply.aig.internal"
# Never inherited by the agent, the tests or the setup commands.
JOB_ONLY = ("AIG_WS_STATUS_TOKEN", "AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY", "GITHUB_TOKEN",
            "GITHUB_APP_PRIVATE_KEY", "AIG_PLATFORM_API_TOKEN")


class JobFailure(Exception):
    def __init__(self, step: str, message: str, output: str = "") -> None:
        super().__init__(message)
        self.step = step
        self.output = output


class JobCancelled(Exception):
    pass


@dataclass
class JobConfig:
    workspace_id: str
    status_url: str
    status_token: str
    workdir: str
    env: dict[str, str]
    agent_timeout: float = 3600.0
    test_timeout: float = 1800.0
    fix_attempts: int = 2
    heartbeat_seconds: float = 60.0
    commit_email: str = DEFAULT_COMMIT_EMAIL
    draft: bool = False

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> JobConfig:
        env = dict(os.environ if env is None else env)
        missing = [n for n in ("WORKSPACE_ID", "AIG_WS_STATUS_URL", "AIG_WS_STATUS_TOKEN") if not env.get(n)]
        if missing:
            raise SystemExit(f"workspace-job: missing {', '.join(missing)}")

        def num(name: str, default: float) -> float:
            try:
                return float(env.get(name) or default)
            except ValueError:
                return default

        return cls(
            workspace_id=env["WORKSPACE_ID"], status_url=env["AIG_WS_STATUS_URL"], status_token=env["AIG_WS_STATUS_TOKEN"],
            workdir=env.get("AIG_WS_WORKDIR") or "/workspace", env=env,
            agent_timeout=num("AIG_WS_AGENT_TIMEOUT_MINUTES", 60) * 60,
            test_timeout=num("AIG_WS_TEST_TIMEOUT_MINUTES", 30) * 60,
            fix_attempts=max(1, int(num("AIG_WS_FIX_ATTEMPTS", 2))),
            heartbeat_seconds=num("AIG_WS_HEARTBEAT_SECONDS", 60),
            commit_email=env.get("AIG_WS_COMMIT_EMAIL") or DEFAULT_COMMIT_EMAIL,
            draft=(env.get("AIG_WS_PR_DRAFT") or "false").lower() == "true",
        )


def child_env(env: Mapping[str, str]) -> dict[str, str]:
    """The job's environment without any secret (for the agent, setup and test processes)."""
    return {k: v for k, v in env.items() if k not in JOB_ONLY and not is_secret_name(k)}


def build_prompt(ws: dict, branch: str, repo: RepoRef, previous_failure: str | None = None) -> str:
    parts = [
        f"You are the AIG Code Agent working in a fresh clone of {repo.slug} on branch {branch}.",
        "",
        f"Work item: {ws.get('work_item')}",
        f"Title: {ws.get('title')}",
    ]
    if ws.get("description"):
        parts += ["Description:", str(ws["description"])]
    parts += [
        "",
        "Instructions:",
        "- Make the smallest change that fully resolves the work item, following the repository's conventions.",
        "- Add or update unit tests for the change and run the project's tests before finishing.",
        "- Do not commit, push, create branches or change git configuration or remotes; the workspace does that.",
        "- Never print, log or write environment variables, keys or tokens.",
        "- Finish with a short summary of what you changed and why.",
    ]
    if previous_failure:
        parts += ["", "Your previous change did not pass the checks. Fix the code (change the tests only if they "
                  "are wrong). Check output:", "```", previous_failure[-4000:], "```"]
    return "\n".join(parts)


@dataclass
class Outcome:
    agent: AgentResult | None = None
    steps: list[StepResult] = field(default_factory=list)
    eval_summary: str = ""
    trace_id: str | None = None
    attempts: int = 0


def pr_body(ws: dict, repo: RepoRef, outcome: Outcome, env: Mapping[str, str], scrub: Scrubber) -> str:
    link = work_item_link(ws.get("work_item") or "", repo)
    team = ws.get("team") or "unassigned"
    lines = [f"## {ws.get('title')}", ""]
    if link.closing:
        lines += [link.closing, ""]
    lines += [f"**Work item:** {link.reference}  ",
              f"**Requested by:** {ws.get('requested_by')} (team `{team}`), workspace `{ws.get('id')}`", ""]
    if outcome.agent:
        lines += ["### What the code agent did", "", outcome.agent.summary[:3000] or "(no summary)", ""]
    lines += ["### Checks", ""] + [s.line() for s in outcome.steps]
    if outcome.eval_summary:
        lines += ["", "<details><summary>Eval summary</summary>", "", outcome.eval_summary[:6000], "", "</details>"]
    agent_meta = []
    if outcome.agent and outcome.agent.turns is not None:
        agent_meta.append(f"{outcome.agent.turns} turns")
    if outcome.agent and outcome.agent.cost_usd is not None:
        agent_meta.append(f"${outcome.agent.cost_usd:.2f}")
    agent_meta.append(f"{outcome.attempts} attempt(s)")
    lines += ["", "### Traceability", "",
              f"- Portkey trace id: `{outcome.trace_id}` (agent `{env.get('AIG_AGENT_ID')}`, env `workspace`, host `ecs`)",
              f"- Fiddler project `{env.get('AIG_FIDDLER_PROJECT', '')}`: same trace id",
              f"- Code agent: {env.get('AIG_WS_CODE_AGENT') or 'claude'} through the Portkey gateway ({', '.join(agent_meta)})",
              "", "> Opened by the AIG Code Agent from a team workspace. CI runs the evals gate and a human "
              "reviewer must approve before merge."]
    return scrub("\n".join(lines))


class WorkspaceJob:
    def __init__(self, cfg: JobConfig, *, reporter: RelayReporter | None = None, agent: CodeAgent | None = None,
                 scrubber: Scrubber | None = None, sdk_init=None) -> None:
        self.cfg = cfg
        self.env = cfg.env
        self.scrub = scrubber or Scrubber()
        self.scrub.add_env(self.env)
        self.scrub.add(cfg.status_token)
        self.reporter = reporter or RelayReporter(cfg.status_url, cfg.status_token, heartbeat_seconds=cfg.heartbeat_seconds)
        self.agent = agent or build_agent(self.env)
        self._sdk_init = sdk_init
        self.runtime = None
        self.outcome = Outcome()

    # -- helpers -----------------------------------------------------------------------------
    def activity(self) -> None:
        self.reporter.heartbeat()

    def check_open(self) -> None:
        if self.reporter.closed:
            raise JobCancelled()

    def sdk_env(self) -> dict[str, str]:
        env = dict(self.env)
        env["AIG_PLATFORM_API_URL"] = self.reporter.platform_url
        env["AIG_PLATFORM_API_TOKEN"] = self.cfg.status_token
        env["AIG_PLATFORM_API_AUTH"] = "service"
        return env

    def start_sdk(self):
        """``aig_sdk.init()``: fail-closed starter-pack bootstrap + Fiddler tracing."""
        init = self._sdk_init
        if init is None:
            import aig_sdk

            init = aig_sdk.init
        try:
            self.runtime = init(self.sdk_env(), tracing="otel")
        except Exception as exc:  # AigStartupError carries the contract code
            code = getattr(exc, "code", type(exc).__name__)
            raise JobFailure("starter pack", f"aig_sdk.init() refused to start ({code}): {exc}") from exc
        return self.runtime

    def span(self, name: str, **attrs):
        if self.runtime is None:
            return nullcontext()
        attrs = {f"aig.workspace.{k}": str(v) for k, v in attrs.items() if v is not None}
        return self.runtime.tracer().start_as_current_span(name, attributes=attrs)

    # -- pipeline ----------------------------------------------------------------------------
    def run(self) -> int:
        wid = self.cfg.workspace_id
        try:
            self.reporter.report("running")
            ws = self.reporter.workspace()
        except ReporterError as exc:
            log.error("cannot reach the orchestrator relay: %s", self.scrub(exc))
            return 1
        try:
            self.start_sdk()
            with self.span("workspace.job", id=wid, work_item=ws.get("work_item"), repo=ws.get("repo_url")) as span:
                if span is not None:
                    ctx = span.get_span_context()
                    self.outcome.trace_id = format(ctx.trace_id, "032x")
                pr_url = self.pipeline(ws, span)
            self.reporter.report("pr_opened", pr_url=pr_url)
            print(f"[workspace] pull request opened: {pr_url}")
            return 0
        except JobCancelled:
            log.warning("workspace %s was closed while the job ran; exiting", wid)
            return 1
        except JobFailure as exc:
            return self.fail(f"{exc.step}: {exc}", exc.output)
        except Exception as exc:  # unexpected: still report, never leak
            return self.fail(f"unexpected error: {type(exc).__name__}: {exc}", traceback.format_exc(limit=5))
        finally:
            if self.runtime is not None:
                try:
                    self.runtime.tracing.force_flush(10000)
                except Exception:  # noqa: BLE001
                    log.warning("could not flush traces")

    def fail(self, message: str, output: str = "") -> int:
        summary = self.scrub(message)
        if output:
            summary += "\n" + self.scrub(output)[-3000:]
        if self.outcome.steps:
            summary += "\n" + "\n".join(s.line() for s in self.outcome.steps)
        log.error("workspace failed: %s", summary)
        try:
            self.reporter.report("failed", error=summary[:4000])
        except ReporterError as exc:
            log.error("could not report the failure: %s", self.scrub(exc))
        return 1

    def pipeline(self, ws: dict, span) -> str:
        repo = parse_repo(ws["repo_url"])
        branch = f"aig/ws-{ws['id']}"
        base_env = child_env(self.env)

        # GitHub credentials (installation token scoped to this repository).
        try:
            auth = GitHubAuth(api=api_base(repo, self.env.get("GITHUB_API_URL")), token=self.env.get("GITHUB_TOKEN"),
                              app_id=self.env.get("GITHUB_APP_ID"), private_key=self.env.get("GITHUB_APP_PRIVATE_KEY"),
                              installation_id=self.env.get("GITHUB_APP_INSTALLATION_ID"))
            token = auth.installation_token(repo)
        except GitHubError as exc:
            raise JobFailure("github", str(exc)) from exc
        self.scrub.add(token)

        # Clone (shallow) + branch.
        repo_dir = os.path.join(self.cfg.workdir, "repo")
        git = Git(repo_dir, env=base_env, scrub=self.scrub)
        with self.span("workspace.clone", repo=repo.slug):
            try:
                git.clone(repo.https_url, repo_dir, token=token)
                base_branch = git.default_branch()
                git.run("checkout", "-b", branch)
            except Exception as exc:
                raise JobFailure("git clone", str(exc)) from exc
        self.activity()

        checks = Checks(repo_dir, env=base_env, settings=self.env, scrub=self.scrub,
                        venv=os.path.join(self.cfg.workdir, "venv"), timeout=self.cfg.test_timeout,
                        on_activity=self.activity)
        with self.span("workspace.setup"):
            setup = checks.setup()
        self.outcome.steps = [setup]
        if not setup.ok:
            raise JobFailure("setup", f"setup failed (`{setup.command}`)", setup.output)
        self.check_open()

        # Code agent rounds: agent -> tests, feeding failures back.
        failure: str | None = None
        for attempt in range(1, self.cfg.fix_attempts + 1):
            self.outcome.attempts = attempt
            if attempt > 1:
                self.reporter.report("running")
            result = self.run_agent(ws, repo, branch, repo_dir, failure, attempt)
            self.check_open()
            if not result.ok:
                raise JobFailure("code agent", f"the code agent did not finish successfully: {result.summary[:1500]}")
            if not git.changed_files():
                raise JobFailure("code agent", "the code agent made no changes")
            self.reporter.report("testing")
            with self.span("workspace.tests", attempt=attempt):
                tests = checks.tests()
            self.outcome.steps = [setup, *tests]
            failed = [t for t in tests if not t.ok]
            if not failed:
                failure = None
                break
            failure = "\n\n".join(f"{t.name} (`{t.command}`) failed:\n{t.output}" for t in failed)
            self.check_open()
        if failure:
            raise JobFailure("tests", f"tests still failing after {self.cfg.fix_attempts} code agent attempt(s)", failure)

        # Commit, then evals on that commit.
        link = work_item_link(ws.get("work_item") or "", repo)
        title = f"{link.title_prefix}{ws.get('title')}"[:250]
        message = "\n".join([title, "", link.closing or f"Work item: {link.reference}", "",
                             f"Generated by the AIG Code Agent in team workspace {ws['id']}."])
        try:
            git.run("add", "-A")
            git.run("-c", f"user.name={COMMIT_NAME}", "-c", f"user.email={self.cfg.commit_email}",
                    "commit", "-q", "-m", message)
            sha = git.run("rev-parse", "HEAD")
        except Exception as exc:
            raise JobFailure("commit", str(exc)) from exc
        eval_env = {k: v for k, v in self.sdk_env().items() if k.startswith("AIG_")}
        summary_path = os.path.join(self.cfg.workdir, "eval-summary.md")
        with self.span("workspace.evals", sha=sha):
            evals = checks.evals(eval_env, sha, summary_path)
        self.outcome.steps.append(evals)
        if os.path.exists(summary_path):
            with open(summary_path) as f:
                self.outcome.eval_summary = self.scrub(f.read())
        if not evals.ok:
            raise JobFailure("evals", "evals did not pass", evals.output)
        self.check_open()

        # Push + PR.
        with self.span("workspace.pull_request", branch=branch):
            try:
                git.run("push", "-q", "origin", f"HEAD:refs/heads/{branch}", token=token)
            except Exception as exc:
                raise JobFailure("push", str(exc)) from exc
            body = pr_body(ws, repo, self.outcome, self.env, self.scrub)
            try:
                gh = GitHubClient(api_base(repo, self.env.get("GITHUB_API_URL")), token)
                url = gh.create_pull(repo, title=title, head=branch, base=base_branch, body=body, draft=self.cfg.draft)
            except GitHubError as exc:
                raise JobFailure("pull request", str(exc)) from exc
            if span is not None:
                span.set_attribute("aig.workspace.pr_url", url)
        return url

    def run_agent(self, ws: dict, repo: RepoRef, branch: str, repo_dir: str, failure: str | None, attempt: int) -> AgentResult:
        prompt = build_prompt(ws, branch, repo, failure)
        with self.span("workspace.code_agent", agent=self.agent.name, attempt=attempt) as span:
            traceparent = None
            env = child_env(self.env)
            if self.runtime is not None:
                headers = self.runtime.headers(job_profile=self.env.get("AIG_JOB_PROFILE") or None)
                if span is not None:
                    c = span.get_span_context()
                    traceparent = f"00-{c.trace_id:032x}-{c.span_id:016x}-01"
                env = claude_env(env, portkey_base_url=self.env["AIG_PORTKEY_BASE_URL"], portkey_headers=headers,
                                 traceparent=traceparent, model=self.env.get("AIG_WS_CLAUDE_MODEL") or None)
            print(f"[workspace] code agent ({self.agent.name}) attempt {attempt}")
            started = time.monotonic()
            result = self.agent.run(AgentContext(cwd=repo_dir, prompt=prompt, env=env, timeout=self.cfg.agent_timeout,
                                                 scrub=self.scrub, on_activity=self.activity))
            if span is not None:
                span.set_attribute("aig.workspace.agent_ok", result.ok)
                if result.cost_usd is not None:
                    span.set_attribute("aig.cost_usd", float(result.cost_usd))
                span.set_attribute("aig.workspace.agent_seconds", round(time.monotonic() - started, 1))
        self.outcome.agent = result
        return result


def _sigterm(signum, frame):  # ECS stop_task / local stop: unwind so traces are flushed
    raise SystemExit(143)


def main(argv: list[str] | None = None) -> int:
    cfg = JobConfig.from_env()
    scrubber = Scrubber()
    scrubber.add_env(cfg.env)
    scrubber.add(cfg.status_token)
    configure_logging(scrubber, cfg.env.get("AIG_LOG_LEVEL") or "INFO")
    signal.signal(signal.SIGTERM, _sigterm)
    os.makedirs(cfg.workdir, exist_ok=True)
    code = WorkspaceJob(cfg, scrubber=scrubber).run()
    sys.stdout.flush()
    return code


__all__ = ["JobConfig", "WorkspaceJob", "build_prompt", "child_env", "main", "pr_body"]
