"""Pluggable code agents. The default is Claude Code, headless, calling Claude THROUGH Portkey.

How Claude Code is pointed at the gateway (verified against @anthropic-ai/claude-code 2.1.x,
whose Anthropic client reads ``ANTHROPIC_CUSTOM_HEADERS``, splits it on newlines and each line on
the first ``:`` into a default header):

- ``ANTHROPIC_BASE_URL`` = the Portkey gateway root (``AIG_PORTKEY_BASE_URL`` without the trailing
  ``/v1``; the client appends ``/v1/messages``). Portkey serves the Anthropic Messages API there.
- ``ANTHROPIC_AUTH_TOKEN`` = the Portkey API key (sent as ``Authorization: Bearer``; the header
  contract allows only the Portkey key there). ``ANTHROPIC_API_KEY`` is never set (raw-key guard).
- ``ANTHROPIC_CUSTOM_HEADERS`` = the four contract headers from ``aig_sdk`` (``x-portkey-api-key``,
  ``x-portkey-config``, ``x-portkey-metadata`` with agent ``workspace.<team>``, env
  ``workspace``, host ``ecs``, and ``x-portkey-trace-id`` = the job's OTel trace id), one per line.
- ``TRACEPARENT`` = the job span, ``CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1`` and
  ``DISABLE_AUTOUPDATER=1`` (no traffic outside the egress allow-list).

The CLI runs as ``claude -p <prompt> --output-format stream-json --verbose --permission-mode
<mode>``; every streamed event is activity for the idle timeout, the final ``result`` event gives
cost, turns and the summary. ``--bare`` is not used: in bare mode Claude Code accepts only
``ANTHROPIC_API_KEY``.

Alternatives: ``claude-sdk`` (the Python ``claude-agent-sdk``, which spawns the same CLI; it
always merges the parent environment, so the job blanks its secrets in ``options.env``) and
``command`` (any shell command, for other agents and tests).
"""

from __future__ import annotations

import json
import os
import shlex
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Protocol

from ..scrub import Scrubber
from . import proc


@dataclass
class AgentResult:
    ok: bool
    summary: str
    cost_usd: float | None = None
    turns: int | None = None
    details: dict = field(default_factory=dict)


@dataclass
class AgentContext:
    cwd: str
    prompt: str
    env: dict[str, str]  # complete environment for the agent process (already secret-filtered)
    timeout: float
    scrub: Scrubber
    on_activity: Callable[[], None] = lambda: None


class CodeAgent(Protocol):
    name: str

    def run(self, ctx: AgentContext) -> AgentResult: ...


def gateway_root(portkey_base_url: str) -> str:
    url = portkey_base_url.rstrip("/")
    return url[:-3] if url.endswith("/v1") else url


def claude_env(base: Mapping[str, str], *, portkey_base_url: str, portkey_headers: Mapping[str, str],
               traceparent: str | None = None, model: str | None = None) -> dict[str, str]:
    env = dict(base)
    env.pop("ANTHROPIC_API_KEY", None)
    env.update({
        "ANTHROPIC_BASE_URL": gateway_root(portkey_base_url),
        "ANTHROPIC_AUTH_TOKEN": portkey_headers["x-portkey-api-key"],
        "ANTHROPIC_CUSTOM_HEADERS": "\n".join(f"{k}: {v}" for k, v in portkey_headers.items()),
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
        "DISABLE_AUTOUPDATER": "1",
        "DISABLE_TELEMETRY": "1",
        "DISABLE_ERROR_REPORTING": "1",
        "CLAUDE_CODE_ENTRYPOINT": "aig-workspace",
    })
    if traceparent:
        env["TRACEPARENT"] = traceparent
    if model:
        env["ANTHROPIC_MODEL"] = model
    return env


def parse_stream_result(lines: list[str]) -> dict | None:
    """The final ``{"type": "result", ...}`` event of ``--output-format stream-json`` (or json)."""
    for line in reversed(lines):
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            obj = json.loads(line)
        except ValueError:
            continue
        if isinstance(obj, dict) and obj.get("type") == "result":
            return obj
    return None


class ClaudeCodeAgent:
    name = "claude"

    def __init__(self, *, binary: str = "claude", permission_mode: str = "bypassPermissions",
                 max_budget_usd: str | None = None, model: str | None = None) -> None:
        self.binary = binary
        self.permission_mode = permission_mode
        self.max_budget_usd = max_budget_usd
        self.model = model

    def command(self, prompt: str) -> list[str]:
        cmd = [self.binary, "-p", prompt, "--output-format", "stream-json", "--verbose",
               "--permission-mode", self.permission_mode]
        if self.model:
            cmd += ["--model", self.model]
        if self.max_budget_usd:
            cmd += ["--max-budget-usd", self.max_budget_usd]
        # Variadic flag last so it cannot swallow the prompt. Egress is restricted anyway.
        cmd += ["--disallowedTools", "WebFetch", "WebSearch"]
        return cmd

    def run(self, ctx: AgentContext) -> AgentResult:
        res = proc.run(self.command(ctx.prompt), cwd=ctx.cwd, env=ctx.env, timeout=ctx.timeout, scrub=ctx.scrub,
                       on_line=lambda _l: ctx.on_activity(), keep_lines=True, echo=_echo_event)
        result = parse_stream_result(res.lines or [])
        if res.timed_out:
            return AgentResult(False, "code agent timed out")
        if result is None:
            return AgentResult(False, f"code agent exited {res.code} without a result: {res.output[-600:]}")
        ok = res.code == 0 and not result.get("is_error") and result.get("subtype") == "success"
        return AgentResult(ok, ctx.scrub(str(result.get("result") or result.get("subtype") or ""))[:4000],
                           cost_usd=result.get("total_cost_usd"), turns=result.get("num_turns"),
                           details={"session_id": result.get("session_id"), "subtype": result.get("subtype")})


def _echo_event(line: str) -> None:
    """Log a compact view of stream-json events (never the full transcript)."""
    try:
        obj = json.loads(line)
    except ValueError:
        print(line[:500])
        return
    kind = obj.get("type")
    if kind == "result":
        print(f"[agent] result {obj.get('subtype')} turns={obj.get('num_turns')} cost={obj.get('total_cost_usd')}")
    elif kind == "assistant":
        for block in (obj.get("message") or {}).get("content") or []:
            if block.get("type") == "tool_use":
                print(f"[agent] tool {block.get('name')}")
            elif block.get("type") == "text":
                print(f"[agent] {str(block.get('text'))[:300]}")


class ClaudeAgentSdkAgent:
    """Same CLI through the Python ``claude-agent-sdk`` (``pip install 'aig-workspace-orchestrator[agent-sdk]'``)."""

    name = "claude-sdk"

    def __init__(self, *, permission_mode: str = "bypassPermissions", model: str | None = None,
                 cli_path: str | None = None, max_budget_usd: str | None = None) -> None:
        self.permission_mode = permission_mode
        self.model = model
        self.cli_path = cli_path
        self.max_budget_usd = max_budget_usd

    def run(self, ctx: AgentContext) -> AgentResult:
        import anyio
        from claude_agent_sdk import ClaudeAgentOptions, ResultMessage, query

        # The SDK merges os.environ into the CLI env; blank every secret the agent must not see.
        env = dict(ctx.env)
        for name in os.environ:
            if name not in env:
                env[name] = ""
        options = ClaudeAgentOptions(
            cwd=ctx.cwd, env=env, permission_mode=self.permission_mode, model=self.model,
            cli_path=self.cli_path, disallowed_tools=["WebFetch", "WebSearch"],
            max_budget_usd=float(self.max_budget_usd) if self.max_budget_usd else None,
        )
        final: dict = {}

        async def go() -> None:
            async for message in query(prompt=ctx.prompt, options=options):
                ctx.on_activity()
                if isinstance(message, ResultMessage):
                    final.update(subtype=message.subtype, is_error=message.is_error, result=message.result,
                                 cost=message.total_cost_usd, turns=message.num_turns)

        try:
            anyio.run(_with_timeout, go, ctx.timeout)
        except TimeoutError:
            return AgentResult(False, "code agent timed out")
        if not final:
            return AgentResult(False, "code agent ended without a result")
        ok = not final["is_error"] and final["subtype"] == "success"
        return AgentResult(ok, ctx.scrub(str(final.get("result") or final["subtype"]))[:4000],
                           cost_usd=final.get("cost"), turns=final.get("turns"))


async def _with_timeout(fn, timeout: float) -> None:
    import anyio

    with anyio.fail_after(timeout):
        await fn()


class CommandAgent:
    """Runs ``AIG_WS_AGENT_COMMAND`` (shell) in the repo; the prompt is in ``AIG_WS_PROMPT_FILE``."""

    name = "command"

    def __init__(self, command: str) -> None:
        self.command_line = command

    def run(self, ctx: AgentContext) -> AgentResult:
        prompt_file = os.path.join(os.path.dirname(ctx.cwd.rstrip("/")), "agent-prompt.md")
        with open(prompt_file, "w") as f:
            f.write(ctx.prompt)
        env = {**ctx.env, "AIG_WS_PROMPT_FILE": prompt_file}
        res = proc.run(self.command_line, cwd=ctx.cwd, env=env, timeout=ctx.timeout, scrub=ctx.scrub,
                       on_line=lambda _l: ctx.on_activity(), keep_lines=True)
        result = parse_stream_result(res.lines or [])
        summary = str((result or {}).get("result") or res.output[-1500:])
        return AgentResult(res.ok, ctx.scrub(summary)[:4000],
                           cost_usd=(result or {}).get("total_cost_usd"), turns=(result or {}).get("num_turns"))


def build_agent(env: Mapping[str, str]) -> CodeAgent:
    kind = (env.get("AIG_WS_CODE_AGENT") or "claude").strip()
    mode = env.get("AIG_WS_CLAUDE_PERMISSION_MODE") or "bypassPermissions"
    model = env.get("AIG_WS_CLAUDE_MODEL") or None
    budget = env.get("AIG_WS_CLAUDE_MAX_BUDGET_USD") or None
    if kind == "claude":
        return ClaudeCodeAgent(binary=env.get("AIG_WS_CLAUDE_BIN") or "claude", permission_mode=mode,
                               max_budget_usd=budget, model=model)
    if kind == "claude-sdk":
        return ClaudeAgentSdkAgent(permission_mode=mode, model=model, cli_path=env.get("AIG_WS_CLAUDE_BIN") or None,
                                   max_budget_usd=budget)
    if kind == "command":
        cmd = env.get("AIG_WS_AGENT_COMMAND")
        if not cmd:
            raise ValueError("AIG_WS_CODE_AGENT=command needs AIG_WS_AGENT_COMMAND")
        return CommandAgent(cmd)
    raise ValueError(f"unknown AIG_WS_CODE_AGENT {kind!r} (claude, claude-sdk, command)")


def shell_quote(cmd: list[str]) -> str:
    return " ".join(shlex.quote(c) for c in cmd)
