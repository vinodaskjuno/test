"""GitHub access for the workspace job: App installation tokens, pull requests, work-item links.

Auth, in order:
1. ``GITHUB_TOKEN`` (a pre-issued token, e.g. local dev).
2. GitHub App: ``GITHUB_APP_ID`` + ``GITHUB_APP_PRIVATE_KEY`` (PEM, from Secrets Manager) ->
   app JWT (RS256, 9 min) -> installation (``GITHUB_APP_INSTALLATION_ID``, else
   ``GET /repos/{owner}/{repo}/installation``) -> ``POST /app/installations/{id}/access_tokens``
   scoped to this one repository with ``contents: write``, ``pull_requests: write`` and
   ``issues: read``. The token lives one hour and never leaves the job (never in a remote URL).

``GITHUB_API_URL`` overrides the API base (GitHub Enterprise Server: ``https://<host>/api/v3``).
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from urllib.parse import urlsplit

import httpx
import jwt

API_VERSION = "2022-11-28"
_HTTPS = re.compile(r"^https?://(?P<host>[^/]+)/(?P<owner>[^/]+)/(?P<name>[^/]+?)(?:\.git)?/?$")
_SSH = re.compile(r"^[A-Za-z0-9._-]+@(?P<host>[A-Za-z0-9.-]+):(?P<owner>[^/]+)/(?P<name>[^/]+?)(?:\.git)?$")
_ISSUE_URL = re.compile(r"^https?://(?P<host>[^/]+)/(?P<owner>[^/]+)/(?P<name>[^/]+)/issues/(?P<num>\d+)/?$")


class GitHubError(RuntimeError):
    pass


@dataclass(frozen=True)
class RepoRef:
    host: str
    owner: str
    name: str

    @property
    def https_url(self) -> str:
        return f"https://{self.host}/{self.owner}/{self.name}.git"

    @property
    def slug(self) -> str:
        return f"{self.owner}/{self.name}"


def parse_repo(url: str) -> RepoRef:
    url = url.strip()
    m = _HTTPS.match(url) or _SSH.match(url)
    if not m:
        raise GitHubError("repo_url must look like https://host/owner/repo or git@host:owner/repo")
    host = m.group("host").split("@")[-1]
    return RepoRef(host=host, owner=m.group("owner"), name=m.group("name"))


def api_base(repo: RepoRef, configured: str | None = None) -> str:
    if configured:
        return configured.rstrip("/")
    if repo.host.lower() in ("github.com", "www.github.com"):
        return "https://api.github.com"
    return f"https://{repo.host}/api/v3"


@dataclass(frozen=True)
class WorkItemLink:
    closing: str | None  # "Fixes #12" (GitHub closes the issue on merge)
    reference: str  # human-readable reference for the PR body
    title_prefix: str  # "[CLAIMS-1234] " for tracker keys, "" otherwise


def work_item_link(work_item: str, repo: RepoRef) -> WorkItemLink:
    item = work_item.strip()
    if re.fullmatch(r"#?\d+", item):
        num = item.lstrip("#")
        return WorkItemLink(f"Fixes #{num}", f"#{num}", "")
    m = _ISSUE_URL.match(item)
    if m:
        num = m.group("num")
        if m.group("host").lower() == repo.host.lower():
            same = m.group("owner").lower() == repo.owner.lower() and m.group("name").lower() == repo.name.lower()
            ref = f"#{num}" if same else f"{m.group('owner')}/{m.group('name')}#{num}"
            return WorkItemLink(f"Fixes {ref}", item, "")
        return WorkItemLink(None, item, "")
    if re.fullmatch(r"[A-Z][A-Z0-9]+-\d+", item):  # Jira / ADO style key
        return WorkItemLink(None, item, f"[{item}] ")
    if urlsplit(item).scheme in ("http", "https"):
        return WorkItemLink(None, item, "")
    return WorkItemLink(None, item, "")


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": API_VERSION, "User-Agent": "aig-workspace-job"}


def app_jwt(app_id: str, private_key: str, *, now: float | None = None) -> str:
    now = int(time.time() if now is None else now)
    return jwt.encode({"iat": now - 60, "exp": now + 540, "iss": str(app_id)}, private_key, algorithm="RS256")


class GitHubAuth:
    def __init__(self, *, api: str, token: str | None = None, app_id: str | None = None,
                 private_key: str | None = None, installation_id: str | None = None,
                 client: httpx.Client | None = None) -> None:
        if not token and not (app_id and private_key):
            raise GitHubError("GitHub credentials missing: set GITHUB_TOKEN or GITHUB_APP_ID + GITHUB_APP_PRIVATE_KEY")
        self.api = api.rstrip("/")
        self._token = token
        self.app_id = app_id
        self._key = private_key
        self.installation_id = installation_id
        self._client = client or httpx.Client(timeout=30.0)

    @property
    def mode(self) -> str:
        return "token" if self._token else "app"

    def installation_token(self, repo: RepoRef) -> str:
        if self._token:
            return self._token
        assert self.app_id and self._key
        bearer = app_jwt(self.app_id, self._key)
        inst = self.installation_id
        if not inst:
            r = self._client.get(f"{self.api}/repos/{repo.owner}/{repo.name}/installation", headers=_headers(bearer))
            if r.status_code != 200:
                raise GitHubError(f"GitHub App is not installed on {repo.slug} ({r.status_code})")
            inst = str(r.json()["id"])
        r = self._client.post(
            f"{self.api}/app/installations/{inst}/access_tokens", headers=_headers(bearer),
            json={"repositories": [repo.name],
                  "permissions": {"contents": "write", "pull_requests": "write", "issues": "read"}})
        if r.status_code != 201:
            raise GitHubError(f"could not create an installation token ({r.status_code})")
        self._token = r.json()["token"]
        return self._token


class GitHubClient:
    def __init__(self, api: str, token: str, *, client: httpx.Client | None = None) -> None:
        self.api = api.rstrip("/")
        self._token = token
        self._client = client or httpx.Client(timeout=30.0)

    def create_pull(self, repo: RepoRef, *, title: str, head: str, base: str, body: str, draft: bool = False) -> str:
        r = self._client.post(f"{self.api}/repos/{repo.owner}/{repo.name}/pulls", headers=_headers(self._token),
                              json={"title": title, "head": head, "base": base, "body": body, "draft": draft,
                                    "maintainer_can_modify": True})
        if r.status_code == 201:
            return r.json()["html_url"]
        if r.status_code == 422 and "already exists" in r.text:
            existing = self._client.get(f"{self.api}/repos/{repo.owner}/{repo.name}/pulls",
                                        headers=_headers(self._token),
                                        params={"head": f"{repo.owner}:{head}", "state": "open"})
            if existing.status_code == 200 and existing.json():
                return existing.json()[0]["html_url"]
        raise GitHubError(f"could not open the pull request ({r.status_code})")
