"""Setup, unit/functional tests and evals inside the workspace.

Detection (each step is overridable with an env var, a shell command run in the repo root):

| Step | Override | Auto-detected |
|---|---|---|
| setup | ``AIG_WS_SETUP_COMMAND`` | ``npm ci`` (lockfile) / ``npm install``; Python: a venv *outside* the repo + ``pip install -e '.[dev]'`` (fallback ``.``) or ``-r requirements.txt`` |
| unit tests | ``AIG_WS_TEST_COMMAND`` | ``mvn -B -q test`` (pom.xml), ``./gradlew test``, ``npm test`` (package.json with a real test script), ``python -m pytest -q`` (pyproject/setup.py/pytest.ini/tests/) |
| functional tests | ``AIG_WS_FUNCTIONAL_TEST_COMMAND`` | none |
| evals | ``AIG_WS_EVAL=off`` disables | ``aig eval run --post`` when ``aig-eval.yaml`` exists (Fiddler evals, recorded in platform-api through the relay) |
"""

from __future__ import annotations

import json
import os
import shlex
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from ..scrub import Scrubber
from . import proc

NPM_DEFAULT_TEST = "no test specified"


@dataclass
class StepResult:
    name: str
    command: str | None
    ok: bool
    skipped: bool = False
    output: str = ""
    code: int | None = None

    def line(self) -> str:
        if self.skipped:
            return f"- {self.name}: skipped ({self.output or 'not detected'})"
        return f"- {self.name}: {'passed' if self.ok else 'FAILED'} (`{self.command}`)"


def _exists(repo: str, *names: str) -> bool:
    return any(os.path.exists(os.path.join(repo, n)) for n in names)


def _package_json(repo: str) -> dict:
    try:
        with open(os.path.join(repo, "package.json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def is_python(repo: str) -> bool:
    return _exists(repo, "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "pytest.ini")


def detect_setup(repo: str, venv: str) -> str | None:
    if _exists(repo, "package.json"):
        return "npm ci --no-audit --no-fund" if _exists(repo, "package-lock.json") else "npm install --no-audit --no-fund"
    if is_python(repo):
        v = shlex.quote(venv)
        if _exists(repo, "pyproject.toml", "setup.py"):
            return (f"python3 -m venv {v} && {v}/bin/pip install -q -e '.[dev]' "
                    f"|| {v}/bin/pip install -q -e . ; {v}/bin/pip install -q pytest")
        return f"python3 -m venv {v} && {v}/bin/pip install -q -r requirements.txt pytest"
    return None


def detect_tests(repo: str) -> str | None:
    if _exists(repo, "pom.xml"):
        return "mvn -B -q test"
    if _exists(repo, "gradlew"):
        return "./gradlew test --no-daemon"
    pkg = _package_json(repo)
    test = (pkg.get("scripts") or {}).get("test")
    if test and NPM_DEFAULT_TEST not in test:
        return "npm test --silent"
    if is_python(repo) or _exists(repo, "tests", "test"):
        return "python -m pytest -q"
    return None


class Checks:
    def __init__(self, repo: str, *, env: Mapping[str, str], settings: Mapping[str, str], scrub: Scrubber,
                 venv: str, timeout: float, on_activity: Callable[[], None]) -> None:
        self.repo = repo
        self.settings = settings
        self.scrub = scrub
        self.venv = venv
        self.timeout = timeout
        self.on_activity = on_activity
        path = env.get("PATH", os.defpath)
        self.env = {**env, "PATH": f"{venv}/bin{os.pathsep}{path}", "CI": "true", "PYTHONDONTWRITEBYTECODE": "1"}

    def _run(self, name: str, cmd: str, env: Mapping[str, str] | None = None) -> StepResult:
        print(f"[workspace] {name}: {cmd}")
        res = proc.run(cmd, cwd=self.repo, env=env or self.env, timeout=self.timeout, scrub=self.scrub,
                       on_line=lambda _l: self.on_activity())
        out = res.output if not res.timed_out else res.output + "\n(timed out)"
        return StepResult(name, cmd, res.ok, output=out[-3000:], code=res.code)

    def setup(self) -> StepResult:
        cmd = self.settings.get("AIG_WS_SETUP_COMMAND") or detect_setup(self.repo, self.venv)
        if not cmd:
            return StepResult("setup", None, True, skipped=True)
        return self._run("setup", cmd)

    def tests(self) -> list[StepResult]:
        results = []
        unit = self.settings.get("AIG_WS_TEST_COMMAND") or detect_tests(self.repo)
        results.append(self._run("unit tests", unit) if unit else StepResult("unit tests", None, True, skipped=True,
                                                                             output="no test command detected"))
        functional = self.settings.get("AIG_WS_FUNCTIONAL_TEST_COMMAND")
        results.append(self._run("functional tests", functional) if functional
                       else StepResult("functional tests", None, True, skipped=True, output="AIG_WS_FUNCTIONAL_TEST_COMMAND unset"))
        return results

    def evals(self, eval_env: Mapping[str, str], git_sha: str, summary_path: str) -> StepResult:
        if (self.settings.get("AIG_WS_EVAL") or "auto").lower() == "off":
            return StepResult("evals", None, True, skipped=True, output="AIG_WS_EVAL=off")
        if not _exists(self.repo, "aig-eval.yaml"):
            return StepResult("evals", None, True, skipped=True, output="no aig-eval.yaml")
        aig = os.path.join(self.venv, "bin", "aig")
        aig = aig if os.path.exists(aig) else "aig"
        cmd = f"{shlex.quote(aig)} eval run --post --git-sha {shlex.quote(git_sha)} --md {shlex.quote(summary_path)}"
        env = {**self.env, **eval_env}
        env.pop("AIG_AGENT_ID", None)  # the agent under evaluation comes from aig-eval.yaml
        result = self._run("evals", cmd, env)
        if result.code == 1:
            result.output = "eval scores below threshold or regressed against the baseline\n" + result.output
        elif result.code == 2:
            result.output = "evals could not run (configuration or infrastructure error)\n" + result.output
        return result
