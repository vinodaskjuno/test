#!/usr/bin/env bash
# Run the workspace orchestrator locally (AIG_ENV=local, LocalProcessRunner: jobs run as
# subprocesses in temp dirs, no Docker). Needs a running platform-api (backend/platform-api/run-local.sh)
# whose PLATFORM_SERVICE_TOKEN equals AIG_PLATFORM_SERVICE_TOKEN in .env.
#   ./run-local.sh            start in the foreground (relay on :8090 + worker loop)
#   ./run-local.sh once       one worker tick (claim + dispatch + reconcile) and exit
#   ./run-local.sh config     validate the configuration
# Settings: .env (copy .env.example). Job secrets (Portkey key, Fiddler key, GITHUB_TOKEN):
# AIG_WS_LOCAL_JOB_ENV_FILE (default job.env, copy job.env.example). Both files are gitignored.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -x .venv/bin/workspace-orchestrator ]; then
  PY="$(command -v python3.12 || command -v python3)"
  "$PY" -m venv .venv
  .venv/bin/pip install -q -e ../../sdk/python
  .venv/bin/pip install -q -e '.[dev,job]'
fi
if [ -f .env ]; then set -a; . ./.env; set +a; fi
export AIG_ENV="${AIG_ENV:-local}" AIG_WS_RUNNER="${AIG_WS_RUNNER:-local}"
export AIG_WS_LOCAL_JOB_ENV_FILE="${AIG_WS_LOCAL_JOB_ENV_FILE:-$PWD/job.env}"
[ -f "$AIG_WS_LOCAL_JOB_ENV_FILE" ] || echo "note: $AIG_WS_LOCAL_JOB_ENV_FILE missing; jobs start without Portkey/Fiddler/GitHub secrets and fail closed" >&2
exec .venv/bin/workspace-orchestrator "${1:-serve}"
