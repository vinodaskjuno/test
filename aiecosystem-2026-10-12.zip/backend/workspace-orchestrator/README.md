# workspace-orchestrator

Phase 6 team workspaces (docs/IMPLEMENTATION_PLAN.md, blueprint "Team workspace (UI or Teams)"): a
request from the Web UI or the Teams bot becomes an isolated ECS Fargate task in which a code agent
fixes the work item through the Portkey gateway (traced to Fiddler), runs the tests and evals, and
opens a pull request linked to the issue. The task then spins down.

Two programs in one Python package (Python 3.12, own `.venv`):

| Program | Runs | Does |
|---|---|---|
| `workspace-orchestrator serve` | one ECS service (or `./run-local.sh`) | worker loop (claim, dispatch, reconcile, idle timeout, max runtime, cancel) + the **relay** HTTP API the workspace tasks call |
| `workspace-job` | inside each workspace task (`infra/ci/docker/workspace.Dockerfile`) | clone, branch, code agent, tests, evals, commit, push, PR |

See [docs/workspaces.md](../../docs/workspaces.md) for the end-to-end flow, the statuses and the
security model.

## Flow

```
Web UI / Teams bot --POST /api/v1/workspaces (user token)--> platform-api: queued
orchestrator  --GET ?status=queued, POST /{id}/claim (service token)--> provisioning
orchestrator  --register workspace.<team> agent, ecs.run_task (or a local subprocess)-->
workspace-job --relay: status running--> aig_sdk.init() (Portkey, Fiddler, registered agent)
              --> GitHub App token --> git clone --depth 1 --> branch aig/ws-<id> --> setup
              --> Claude Code (headless) through Portkey  --relay: testing--> unit + functional tests
              (failures go back to the agent, up to AIG_WS_FIX_ATTEMPTS rounds)
              --> commit "AIG Code Agent" --> aig eval run --post (if aig-eval.yaml)
              --> push --> PR "Fixes #N" + test/eval summary --relay: pr_opened (pr_url)--> exit 0
orchestrator  --task stopped--> completed      (exit without PR -> failed; cancel -> stop_task;
                                                idle 30 min / max runtime 120 min -> stop, failed)
every change  --POST /api/notify (HMAC signed)--> Teams bot --> proactive message in the chat
```

Statuses (platform-api): `queued -> provisioning -> running -> testing (-> running -> testing) ->
pr_opened -> completed`, or `failed` / `cancelled` (final). `completed` means "PR opened and the
workspace has spun down".

## platform-api endpoints used

| Call | Who | Notes |
|---|---|---|
| `GET /api/v1/workspaces?status=queued` | orchestrator (service token) | lists all users' requests |
| `POST /api/v1/workspaces/{id}/claim` | orchestrator (service token) | **added in this phase**: atomic `queued -> provisioning`, `409 invalid_transition` if another worker won |
| `PATCH /api/v1/workspaces/{id}/status` | orchestrator, and the job through the relay | `{status, pr_url?, log_url?, error?}` |
| `GET /api/v1/workspaces/{id}` | orchestrator (reconcile, cancel detection), job through the relay | |
| `POST /api/v1/agents` | orchestrator (service token) | registers `workspace.<team>` (409 = exists) so `aig_sdk.init()` and the gateway's `aig-agent-check` accept the job |
| `GET /api/v1/agents/{id}`, `GET/POST /api/v1/evals` | job through the relay | starter-pack checks and `aig eval run --post` |

## The relay (workspace tasks never hold the service token)

`PLATFORM_SERVICE_TOKEN` can suspend agents and change the model catalog, so it never enters a
workspace. Each task gets `AIG_WS_STATUS_TOKEN = aigws1.<HMAC-SHA256(AIG_WS_RELAY_SECRET, "ws:<id>")>`,
valid only for its own workspace and only while that workspace is not final, and talks to the
orchestrator relay (`AIG_WS_STATUS_URL = <AIG_WS_RELAY_PUBLIC_URL>/relay/v1/workspaces/<id>`):

| Relay path | Forwarded to |
|---|---|
| `GET ""` | `GET /api/v1/workspaces/{id}` |
| `POST /status` (`running`, `testing`, `pr_opened` + `pr_url`, `failed` + `error`) | `PATCH .../status` (+ notification) |
| `POST /heartbeat` | nothing; counts as activity for the idle timeout |
| `GET /platform/api/v1/agents/{agent}` | only `workspace.<team>` or an agent of the same team |
| `GET /platform/api/v1/evals`, `POST /platform/api/v1/evals` | POST only for an agent of the workspace's team |

Everything else is `403`. The job sets `AIG_PLATFORM_API_URL=<status url>/platform` and
`AIG_PLATFORM_API_TOKEN=<its token>`, so the unmodified starter pack (`aig_sdk.init()`, `aig eval`)
works through the relay (the token is accepted as `x-aig-workspace-token`, `x-aig-service-token` or
`Authorization: Bearer`).

## Code agent: Claude Code through Portkey (verified mechanism)

Default `AIG_WS_CODE_AGENT=claude`: the Claude Code CLI (`@anthropic-ai/claude-code`, pinned in the
image; verified against 2.1.247 and the `claude-agent-sdk` 0.2.165 bundled CLI 2.1.294) runs headless:

```
claude -p "<prompt>" --output-format stream-json --verbose --permission-mode bypassPermissions \
       [--model M] [--max-budget-usd N] --disallowedTools WebFetch WebSearch
```

with this environment (and nothing secret beyond the Portkey key it needs):

| Variable | Value | Why |
|---|---|---|
| `ANTHROPIC_BASE_URL` | `AIG_PORTKEY_BASE_URL` without the trailing `/v1` | Claude Code's Anthropic client appends `/v1/messages`; Portkey serves the Anthropic Messages API there |
| `ANTHROPIC_AUTH_TOKEN` | the team's Portkey API key | sent as `Authorization: Bearer` (the header contract allows only the Portkey key there); `ANTHROPIC_API_KEY` is never set (raw-key guard) |
| `ANTHROPIC_CUSTOM_HEADERS` | `x-portkey-api-key: ...` / `x-portkey-config: pc-aig-router` / `x-portkey-metadata: {...}` / `x-portkey-trace-id: <otel trace id>`, one per line | from `aig_sdk.AigRuntime.headers()`, so the metadata is the contract's (`agent_id=workspace.<team>`, `team`, `env=workspace`, `host=ecs`, `user_tier`, `job_profile`, `user`) |
| `TRACEPARENT` | the job's `workspace.code_agent` span | W3C context for anything in the agent that traces |
| `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC`, `DISABLE_AUTOUPDATER`, `DISABLE_TELEMETRY`, `DISABLE_ERROR_REPORTING` | `1` | no traffic outside the egress allow-list |

How it was verified: the installed CLI's bundled Anthropic client contains
`let c=A("ANTHROPIC_CUSTOM_HEADERS");if(c){...for(let m of c.split("\n")){let y=m.indexOf(":");if(y>=0)h[m.substring(0,y).trim()]=m.substring(y+1).trim()}i.defaultHeaders={...h,...i.defaultHeaders}}`
(newline-separated `Name: Value`, merged into every request). `claude --help` (2.1.247) confirms
`-p/--print`, `--output-format text|json|stream-json`, `--permission-mode
acceptEdits|auto|bypassPermissions|manual|dontAsk|plan`, `--max-budget-usd`, `--disallowedTools`.
`--bare` is not used: in bare mode Claude Code accepts only `ANTHROPIC_API_KEY`. The end-to-end
test runs a fake `claude` that makes the gateway call the same way and asserts what "Portkey" received.

Alternatives: `AIG_WS_CODE_AGENT=claude-sdk` uses the Python `claude-agent-sdk`
(`ClaudeAgentOptions(cwd, env, permission_mode, model, cli_path, disallowed_tools, max_budget_usd)`,
`query()`, `ResultMessage`). Its transport always merges the parent `os.environ` into the CLI
environment, so the job blanks every variable the agent must not see in `options.env`.
`AIG_WS_CODE_AGENT=command` runs `AIG_WS_AGENT_COMMAND` (shell, prompt in `$AIG_WS_PROMPT_FILE`).

Gateway notes: the workspace sends `user_tier=AIG_WS_USER_TIER` (default `standard`, which
`pc-aig-router` routes to Claude Sonnet). If the gateway's default route can answer with a
non-Anthropic model for some tier, point the job at a Claude-only config with
`AIG_PORTKEY_CONFIG` (open item, see docs/workspaces.md).

## Tracing (Fiddler)

The job is a registered AIG agent: `aig_sdk.init(tracing="otel")` runs the fail-closed checks
(Portkey reachable, Fiddler reachable, `workspace.<team>` registered and active) and installs the
OTLP exporter to Fiddler (`fiddler-application-id` = `AIG_FIDDLER_APPLICATION_ID` or the registry's
id). Spans: `workspace.job` > `workspace.clone`, `workspace.setup`, `workspace.code_agent`
(`aig.cost_usd`), `workspace.tests`, `workspace.evals`, `workspace.pull_request`, all with the AIG
tags (`env=workspace`, `host=ecs`). The Portkey trace id of every Claude call is the
`workspace.job` trace id, so the gateway logs and the Fiddler trace join on one id; the id is also
in the PR body.

## Configuration

Orchestrator (`workspace-orchestrator`). Values that are empty or contain `__REPLACE_ME`/`<...>` count as unset.

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local`, `dev`, `stage`, `prod` |
| `AIG_PLATFORM_API_URL` | required | platform-api base URL |
| `AIG_PLATFORM_SERVICE_TOKEN` (secret) | required | = platform-api `PLATFORM_SERVICE_TOKEN` |
| `AIG_WS_RUNNER` | `local` in local, else `ecs` | `local` is refused outside `AIG_ENV=local` |
| `AIG_WS_RELAY_SECRET` (secret) | random per process in local; required elsewhere | HMAC key of the per-workspace tokens |
| `AIG_WS_RELAY_PUBLIC_URL` | `http://127.0.0.1:<port>` in local; required elsewhere | how workspace tasks reach the relay (internal ALB / Cloud Map name) |
| `AIG_WS_RELAY_HOST`, `AIG_WS_RELAY_PORT` | `127.0.0.1` (local) / `0.0.0.0`, `8090` | relay bind address |
| `AIG_WS_POLL_INTERVAL_SECONDS` | `10` | worker tick |
| `AIG_WS_MAX_CONCURRENT` | `5` | workspaces per orchestrator |
| `AIG_WS_IDLE_TIMEOUT_MINUTES` | `30` (open item) | no relay activity (status, heartbeat, platform call) for this long -> stop, `failed` |
| `AIG_WS_MAX_RUNTIME_MINUTES` | `120` | hard limit per workspace -> stop, `failed` |
| `AIG_WS_WORKER_ID` | hostname | recorded with the claim (audit) |
| `AIG_WS_USER_TIER` | `standard` | `user_tier` metadata of the job's gateway calls |
| `AIG_WS_AGENT_OWNER` | the first requester of the team | owner of the auto-registered `workspace.<team>` agent |
| `AIG_WS_NOTIFY_URLS`, `AIG_WS_NOTIFY_SECRET` (secret) | none | status notifications (Teams bot `POST /api/notify`), HMAC signed |
| `AIG_WS_RECOVER` | `true` | on start, adopt still-running tasks (`ecs:ListTasks startedBy=aig-ws/<id>`) and fail lost ones |
| `AIG_WS_LOCAL_WORKDIR`, `AIG_WS_LOCAL_JOB_ENV_FILE` | temp dir, none | LocalProcessRunner: base dir; dotenv with the job secrets |
| `AIG_WS_ECS_CLUSTER`, `AIG_WS_ECS_TASK_DEFINITION` | required for `ecs` | cluster and base task definition (family or ARN) |
| `AIG_WS_ECS_SUBNETS`, `AIG_WS_ECS_SECURITY_GROUPS` | required for `ecs` | private subnets, restricted-egress SG (comma-separated) |
| `AIG_WS_ECS_CONTAINER_NAME` | `workspace` | container in the task definition |
| `AIG_WS_ECS_ASSIGN_PUBLIC_IP` | `false` | |
| `AIG_WS_ECS_PLATFORM_VERSION` | `LATEST` | |
| `AIG_WS_ECS_CAPACITY_PROVIDER` | none (`launchType=FARGATE`) | e.g. `FARGATE_SPOT` |
| `AIG_WS_ECS_TEAM_TASK_DEFINITIONS` | `{}` | JSON `{team: task definition}` (each with that team's Portkey key secret) |
| `AIG_WS_ECS_PORTKEY_SECRET_ARN_TEMPLATE` | none | e.g. `arn:aws:secretsmanager:<region>:<acct>:secret:aig/{env}/workspaces/{team}:portkey_api_key::`; the orchestrator registers `<family>-<team>` with that secret as `AIG_PORTKEY_API_KEY` (once, reused) |
| `AIG_WS_ECS_LOG_GROUP`, `AIG_WS_ECS_LOG_STREAM_PREFIX` | none, `workspace` | CloudWatch deep link written to `log_url` |
| `AWS_REGION` | SDK default | |

Forwarded to every job when set (non-secret): `AIG_PORTKEY_BASE_URL`, `AIG_PORTKEY_CONFIG`,
`AIG_FIDDLER_URL`, `AIG_FIDDLER_PROJECT`, `AIG_FIDDLER_APPLICATION_ID`, `AIG_OTLP_ENDPOINT`,
`AIG_LOG_LEVEL`, `AIG_TIMEOUT_SECONDS`, `GITHUB_API_URL`, `GITHUB_APP_ID`,
`GITHUB_APP_INSTALLATION_ID`, the `AIG_WS_*` job settings below, `PIP_INDEX_URL`,
`NPM_CONFIG_REGISTRY`, `HTTPS_PROXY`, `NO_PROXY`. The orchestrator adds `WORKSPACE_ID`,
`REPO_URL`, `WORK_ITEM`, `JOB_PROFILE`, `WORKSPACE_TEAM`, `AIG_WS_STATUS_URL`,
`AIG_WS_STATUS_TOKEN`, `AIG_AGENT_ID=workspace.<team>`, `AIG_TEAM`, `AIG_ENV=workspace`,
`AIG_HOST=ecs`, `AIG_USER_TIER`, `AIG_JOB_PROFILE`, `AIG_USER` (requester).

Job (`workspace-job`):

| Variable | Default | Meaning |
|---|---|---|
| `AIG_PORTKEY_API_KEY`, `AIG_FIDDLER_API_KEY` (secrets) | Secrets Manager | team Portkey key, Fiddler token |
| `GITHUB_TOKEN` (secret) or `GITHUB_APP_ID` + `GITHUB_APP_PRIVATE_KEY` (secret) [+ `GITHUB_APP_INSTALLATION_ID`] | | GitHub auth; the App token is scoped to the one repo (`contents`/`pull_requests: write`, `issues: read`) |
| `GITHUB_API_URL` | `https://api.github.com` (GHES: `https://<host>/api/v3`) | |
| `AIG_WS_CODE_AGENT` | `claude` | `claude`, `claude-sdk`, `command` |
| `AIG_WS_CLAUDE_BIN`, `AIG_WS_CLAUDE_MODEL`, `AIG_WS_CLAUDE_PERMISSION_MODE`, `AIG_WS_CLAUDE_MAX_BUDGET_USD` | `claude`, none, `bypassPermissions`, none | Claude Code options (the container is the sandbox) |
| `AIG_WS_AGENT_COMMAND` | none | for `command` |
| `AIG_WS_AGENT_TIMEOUT_MINUTES`, `AIG_WS_TEST_TIMEOUT_MINUTES` | `60`, `30` | |
| `AIG_WS_FIX_ATTEMPTS` | `2` | agent rounds when tests fail |
| `AIG_WS_SETUP_COMMAND`, `AIG_WS_TEST_COMMAND`, `AIG_WS_FUNCTIONAL_TEST_COMMAND` | auto-detected (npm / venv+pip; mvn, gradle, npm test, pytest) | shell commands run in the repo |
| `AIG_WS_EVAL` | `auto` | `off` skips `aig eval run --post` |
| `AIG_WS_COMMIT_EMAIL` | `aig-code-agent@users.noreply.aig.internal` | commit author email (name: "AIG Code Agent") |
| `AIG_WS_PR_DRAFT` | `false` | open PRs as drafts |
| `AIG_WS_HEARTBEAT_SECONDS` | `60` | heartbeat throttle (any agent/test output is activity) |
| `AIG_WS_WORKDIR` | `/workspace` | clone + venv |

## Secrets and logging

- Secret values (every env var named like a key/token/secret/password, minted tokens, the GitHub
  installation token) are registered with a scrubber; logs, the status `error`, the PR body and
  notifications pass through it. Token shapes (GitHub tokens, bearer/basic credentials, URL
  credentials, PEM keys, `x-portkey-api-key: ...`, `aigws1.*`) are masked even when unknown.
- The code agent, setup and test processes get the job environment **without** secrets (the agent
  additionally gets the Portkey key it needs, inside the Anthropic variables).
- git authenticates with a per-command `http.extraHeader` passed via `GIT_CONFIG_COUNT`/`KEY`/`VALUE`
  env variables: the token is never on a command line, in a remote URL or in `.git/config`.
- ECS task overrides contain only non-secret values plus the per-workspace relay token (useless for
  any other workspace and dead once the workspace is final). The Portkey, Fiddler and GitHub App
  keys come from Secrets Manager through the task definition.

## Local run

```bash
backend/platform-api/run-local.sh                    # PLATFORM_SERVICE_TOKEN in its secrets/.env.local
cp backend/workspace-orchestrator/.env.example backend/workspace-orchestrator/.env      # edit
cp backend/workspace-orchestrator/job.env.example backend/workspace-orchestrator/job.env  # secrets
backend/workspace-orchestrator/run-local.sh          # relay :8090 + worker; jobs run as subprocesses
```

`LocalProcessRunner` starts `python -m workspace_orchestrator.job` in a temp dir with a minimal
environment (`PATH`, `LANG`, proxies) plus the job settings and the `job.env` secrets; the job log
is `<dir>/job.log`. It needs `git`, and `claude` on `PATH` (or `AIG_WS_CLAUDE_BIN`).

## Tests

```bash
make workspace-orchestrator-setup && make workspace-orchestrator-test
```

- `test_worker.py`: claim (oldest first, 409 skipped), dispatch env, capacity, agent registration,
  start failure, exit -> completed/failed, cancel -> stop, idle timeout, max runtime, recovery.
- `test_ecs_runner.py`: `run_task`/`describe_tasks`/`stop_task`/`list_tasks`/
  `describe_task_definition`/`register_task_definition` with botocore `Stubber`; CloudWatch links.
- `test_relay.py`: token scoping, status forwarding, allow-list, final workspaces.
- `test_github.py`: App JWT -> installation token, PR creation (respx), work-item links.
- `test_agents_and_checks.py`: Claude Code argv/env with a fake CLI, Portkey header wiring,
  installed `claude-agent-sdk` options, test detection, scrubbing.
- `test_job.py`: job failure paths (tests still failing, no changes, starter pack refusal, clone,
  push).
- `test_e2e_local.py`: the real platform-api (subprocess, temp SQLite), relay, Worker +
  LocalProcessRunner, the real job with the real `aig_sdk`, a bare git repo, a fake `claude` and a
  fake Portkey/Fiddler/GitHub/bot server: `queued -> provisioning -> running -> testing -> running
  -> testing -> pr_opened -> completed`, Portkey metadata, OTLP trace id join, PR, signed
  notifications, no secret anywhere; plus cancel of a running job. Skipped when
  `backend/platform-api/.venv` is missing.

## Infrastructure (provided: `infra/terraform/modules/workspaces`)

The Terraform module `infra/terraform/modules/workspaces` provides this service's AWS
infrastructure. The environment module wires it in (`workspaces` and `workspace_images` in
`envs/<env>/terraform.tfvars`). `deploy-platform.yml` builds and rolls out the images. Details are
in [infra/terraform/README.md](../../infra/terraform/README.md#workspaces) and
[docs/deploy.md](../../docs/deploy.md). Validated offline only: nothing has been applied yet.

| Need | What the module does |
|---|---|
| ECR | `aig/workspace` (infra/ci/docker/workspace.Dockerfile, linux/amd64), `aig/workspace-orchestrator`, `aig/teams-bot` (both linux/arm64). Immutable tags, scan on push, KMS, lifecycle policy (environment module, `modules/ecr`) |
| ECS cluster | `aig-<env>-workspaces`: Fargate + `FARGATE_SPOT` (`use_fargate_spot` sets `AIG_WS_ECS_CAPACITY_PROVIDER`), Container Insights (enhanced) |
| Workspace task definitions | Base family `aig-<env>-workspace` (no Portkey key, so an unmapped team fails closed in `aig_sdk.init`), plus **one family per team**, `aig-<env>-workspace-<team>`, passed as `AIG_WS_ECS_TEAM_TASK_DEFINITIONS` (family names, so the latest Terraform revision is used). `awsvpc`, X86_64, 2 vCPU / 8 GiB and 50 GiB ephemeral storage by default (variables, sizing is still open), container `workspace`, user `10001`, `readonlyRootFilesystem=true` with task volumes `/workspace`, `/home/aig` and `/tmp` (a `prepare` init container makes them writable), all capabilities dropped, `stopTimeout=30`. Logs go to `/aig/<env>/workspaces` with stream prefix `workspace` (= `AIG_WS_ECS_LOG_GROUP` / `AIG_WS_ECS_LOG_STREAM_PREFIX`, so `log_url` deep links resolve). Secrets: `AIG_PORTKEY_API_KEY` (team only), `AIG_FIDDLER_API_KEY` and `GITHUB_APP_PRIVATE_KEY`. No `AIG_WS_ECS_PORTKEY_SECRET_ARN_TEMPLATE`, so the orchestrator needs no `ecs:RegisterTaskDefinition` |
| Secrets Manager (placeholders only) | `aig/<env>/workspaces/<team>` (`portkey_api_key`), `aig/<env>/workspaces/shared` (`fiddler_api_key`, `github_app_private_key`), `aig/<env>/workspace-orchestrator` (`AIG_PLATFORM_SERVICE_TOKEN`, `AIG_WS_RELAY_SECRET`, `AIG_WS_NOTIFY_SECRET`) and `aig/<env>/teams-bot` (`MicrosoftAppId`, `MicrosoftAppPassword`, `AIG_BOT_NOTIFY_SECRET`). The env KMS key encrypts them all. Who rotates them is still open |
| IAM | Workspace task role: deny-all. Workspace **execution role per team**: pull `aig/workspace`, write the workspace log group, read only that team's secret plus `workspaces/shared`. Orchestrator task role: `ecs:RunTask` on the workspace families only (condition `ecs:cluster`), `ecs:StopTask`/`DescribeTasks`/`TagResource` (on RunTask) on tasks in that cluster, `ecs:ListTasks` (cluster condition), `iam:PassRole` on the workspace roles only (to `ecs-tasks`). Orchestrator and bot execution roles: their image, their log group, their own secret |
| Networking | Private subnets, no public IP. The workspace SG has **no ingress**. Its egress is HTTPS only to the Portkey/Fiddler prefix list, the workspace prefix list (GitHub / GHES and the package mirror: `github_egress_cidrs`, `package_mirror_egress_cidrs`), the VPC endpoints (an `ecs` endpoint is added for the orchestrator), S3 (ECR layers) and the relay ALB. There is no `0.0.0.0/0` rule. In firewall mode `github.com` and `api.github.com` are added to the Network Firewall domain allow-list |
| Orchestrator service | ECS service `workspace-orchestrator`: desired count 1, deployment max 100 % / min 0 %, so two orchestrators never run at once (`AIG_WS_RECOVER=true` adopts running tasks after a restart). The relay sits behind an **internal HTTPS ALB** (`relay_hostname`, ACM certificate) with ingress from the workspace SG only (`AIG_WS_RELAY_PUBLIC_URL=https://<relay_hostname>`). Egress goes to platform-api (portal/API ALB), the ECS endpoint and the bot |
| Teams bot | ECS service `teams-bot` (1 replica), behind the portal/API ALB on `teams_bot_hostname`. Only `/api/messages` and `/healthz` are forwarded, and `/api/notify` answers 403 there. The orchestrator posts to `http://teams-bot.workspaces.aig-<env>.internal:3978/api/notify` (Cloud Map, `AIG_WS_NOTIFY_URLS`). The bot SG allows only the ALB and the orchestrator, and every request is HMAC-signed |
| Alarms | `aig-<env>-workspace-orchestrator-down` / `-teams-bot-down` (Container Insights `RunningTaskCount` < 1 for 3 min). `aig-<env>-workspaces-failed` (log metric filter on the orchestrator log, `-> failed` / `reported failed`, more than `failed_alarm_per_hour` per hour) |

Still outside Terraform:
- the GitHub App (contents and pull requests write, issues read, installed on the allowed repos)
- the per-team Portkey workspace keys and their budgets
- the Fiddler project `aig-workspace` and the `workspace.<team>` applications
- DNS records for `relay_hostname` and `teams_bot_hostname`
- the Azure Bot / Entra setup (backend/teams-bot README)
- uploading the secret values (docs/deploy.md)
- `ecs:RunTask` throttling and cost-per-team alarms

## Not done / unverified

- No real ECS, GitHub, Portkey or Fiddler call has been made (all mocked/faked in tests); the
  Docker images were not built here (no Docker on the build machine).
- Claude Code through a real self-hosted Portkey `/v1/messages` route with `pc-aig-router`
  (whether the router config and guardrails accept Anthropic-format requests) needs a live check.
- One active orchestrator replica is assumed (enforced by the ECS deployment settings above).
