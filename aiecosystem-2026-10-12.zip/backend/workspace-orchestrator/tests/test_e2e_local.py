"""End to end, no Docker and no cloud:

- the real platform-api (its own .venv, uvicorn subprocess, temp SQLite, dev auth),
- the orchestrator relay (uvicorn thread) + Worker + LocalProcessRunner,
- the real ``workspace-job`` subprocess with the real starter pack (``aig_sdk.init()``),
- a local bare git repository (``url.<base>.insteadOf`` maps the https repo URL onto it),
- a fake Claude Code CLI that calls the "gateway" the way Claude Code does
  (``ANTHROPIC_BASE_URL`` + ``ANTHROPIC_CUSTOM_HEADERS``) and edits the code,
- one fake HTTP server for Portkey, Fiddler (OTLP), GitHub and the Teams bot notify endpoint.

Drives queued -> provisioning -> running -> testing -> running -> testing -> pr_opened -> completed
(the first agent attempt leaves a failing test, the second fixes it).
"""

from __future__ import annotations

import json
import os
import socket
import stat
import subprocess
import sys
import textwrap
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import httpx
import pytest
import uvicorn

from workspace_orchestrator.config import OrchestratorConfig
from workspace_orchestrator.notify import Notifier, verify
from workspace_orchestrator.platform import PlatformClient
from workspace_orchestrator.relay import create_relay_app
from workspace_orchestrator.runners.local import LocalProcessRunner
from workspace_orchestrator.scrub import Scrubber
from workspace_orchestrator.worker import Worker

ROOT = Path(__file__).resolve().parents[3]
PLATFORM_DIR = ROOT / "backend" / "platform-api"
PLATFORM_PY = PLATFORM_DIR / ".venv" / "bin" / "python"
SERVICE_TOKEN = "svc-e2e-SUPERSECRET-5566778899"
PORTKEY_KEY = "pk-e2e-SUPERSECRET-claims-team-key"
FIDDLER_KEY = "fdl-e2e-SUPERSECRET-0099"
GITHUB_TOKEN = "ghs_e2eSUPERSECRETinstallationtoken000"
NOTIFY_SECRET = "notify-e2e-SUPERSECRET-1"
APP_ID = str(uuid.uuid4())

pytestmark = pytest.mark.skipif(not PLATFORM_PY.exists(), reason="backend/platform-api/.venv missing (make setup)")


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class Fake:
    """Records every request; answers like Portkey, Fiddler, GitHub and the bot's notify endpoint."""

    def __init__(self) -> None:
        self.requests: list[dict] = []
        fake = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, obj=None):
                body = json.dumps(obj or {}).encode()
                self.send_response(code)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def _record(self, method):
                n = int(self.headers.get("content-length") or 0)
                body = self.rfile.read(n) if n else b""
                fake.requests.append({"method": method, "path": self.path, "headers": {k.lower(): v for k, v in self.headers.items()},
                                      "body": body})
                return body

            def do_GET(self):
                self._record("GET")
                if self.path.startswith("/portkey"):
                    return self._send(200, {"status": "ok"})
                if self.path.startswith("/fiddler/v3/server-info"):
                    return self._send(200, {"server_version": "25.0"})
                return self._send(404)

            def do_POST(self):
                body = self._record("POST")
                if self.path == "/portkey/v1/messages":
                    return self._send(200, {"id": "msg_1", "type": "message", "role": "assistant",
                                            "content": [{"type": "text", "text": "ok"}], "model": "claude-sonnet"})
                if self.path == "/fiddler/v1/traces":
                    return self._send(200)
                if self.path == "/github/repos/aig/demo/pulls":
                    return self._send(201, {"html_url": "https://github.example.com/aig/demo/pull/1", "number": 1})
                if self.path == "/notify":
                    return self._send(202)
                return self._send(404, {"path": self.path, "len": len(body)})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def find(self, method, path):
        return [r for r in self.requests if r["method"] == method and r["path"].startswith(path)]


FAKE_CLAUDE = textwrap.dedent("""\
    #!{python}
    # Behaves like `claude -p ... --output-format stream-json`: one gateway call, then edits.
    import json, os, sys, urllib.request
    assert sys.argv[1] == "-p" and "--output-format" in sys.argv and "ANTHROPIC_API_KEY" not in os.environ
    assert not any(k in ("GITHUB_TOKEN", "GITHUB_APP_PRIVATE_KEY", "AIG_WS_STATUS_TOKEN", "AIG_FIDDLER_API_KEY", "AIG_PORTKEY_API_KEY") for k in os.environ)
    headers = dict(line.split(":", 1) for line in os.environ["ANTHROPIC_CUSTOM_HEADERS"].split("\\n"))
    headers = {{k.strip(): v.strip() for k, v in headers.items()}}
    headers["authorization"] = "Bearer " + os.environ["ANTHROPIC_AUTH_TOKEN"]
    headers["content-type"] = "application/json"
    body = json.dumps({{"model": "claude-sonnet", "max_tokens": 64, "messages": [{{"role": "user", "content": sys.argv[2][:200]}}]}})
    urllib.request.urlopen(urllib.request.Request(os.environ["ANTHROPIC_BASE_URL"] + "/v1/messages", body.encode(), headers)).read()
    state = os.path.join(os.environ["HOME"], "attempts")
    n = int(open(state).read()) + 1 if os.path.exists(state) else 1
    open(state, "w").write(str(n))
    fix = "return a * b" if n == 1 else "return a + b"   # first attempt is wrong on purpose
    src = open("calc.py").read().replace("return a - b", fix).replace("return a * b", fix)
    open("calc.py", "w").write(src)
    print(json.dumps({{"type": "system", "subtype": "init"}}))
    print(json.dumps({{"type": "result", "subtype": "success", "is_error": False, "num_turns": 3,
                      "total_cost_usd": 0.02, "result": "Changed add() in calc.py (attempt %d)" % n}}))
""")


def make_remote(tmp: Path) -> Path:
    work = tmp / "seed"
    work.mkdir()
    (work / "calc.py").write_text("def add(a, b):\n    return a - b\n")
    (work / "tests").mkdir()
    (work / "tests" / "test_calc.py").write_text("from calc import add\n\n\ndef test_add():\n    assert add(2, 3) == 5\n")
    (work / ".gitignore").write_text("__pycache__/\n.pytest_cache/\n")
    (work / "pytest.ini").write_text("[pytest]\npythonpath = .\n")
    git = ["git", "-c", "user.name=seed", "-c", "user.email=seed@example.com"]
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=work, check=True)
    subprocess.run(["git", "add", "-A"], cwd=work, check=True)
    subprocess.run([*git, "commit", "-q", "-m", "seed"], cwd=work, check=True)
    bare = tmp / "remotes" / "aig" / "demo.git"
    bare.parent.mkdir(parents=True)
    subprocess.run(["git", "clone", "-q", "--bare", str(work), str(bare)], check=True)
    return bare


@pytest.fixture
def platform_api(tmp_path):
    port = free_port()
    users = tmp_path / "users.yaml"
    users.write_text("default_team: unassigned\nusers:\n  jane@example.com: {name: Jane, team: claims-ai, tier: standard}\n"
                     "  admin@example.com: {name: Ada, team: aig-platform, tier: standard, roles: [user, admin]}\n")
    env = {"PATH": os.environ["PATH"], "HOME": str(tmp_path), "AIG_ENV": "local", "AIG_AUTH_MODE": "dev",
           "AIG_DATABASE_URL": f"sqlite:///{tmp_path / 'platform.db'}", "AIG_USERS_FILE": str(users),
           "AIG_SECRETS_DIR": str(tmp_path / "no-secrets"), "PLATFORM_SERVICE_TOKEN": SERVICE_TOKEN}
    log = open(tmp_path / "platform.log", "wb")
    proc = subprocess.Popen([str(PLATFORM_PY), "-m", "uvicorn", "platform_api.main:create_app", "--factory",
                             "--host", "127.0.0.1", "--port", str(port)], cwd=PLATFORM_DIR, env=env, stdout=log, stderr=log)
    url = f"http://127.0.0.1:{port}"
    try:
        for _ in range(200):
            try:
                if httpx.get(f"{url}/healthz", timeout=1).status_code < 500:
                    break
            except httpx.HTTPError:
                time.sleep(0.1)
        else:
            raise RuntimeError("platform-api did not start: " + (tmp_path / "platform.log").read_text()[-2000:])
        yield url
    finally:
        proc.terminate()
        proc.wait(10)


def test_workspace_end_to_end(tmp_path, platform_api):
    fake = Fake()
    bare = make_remote(tmp_path)
    claude = tmp_path / "bin" / "claude"
    claude.parent.mkdir()
    claude.write_text(FAKE_CLAUDE.format(python=sys.executable))
    claude.chmod(claude.stat().st_mode | stat.S_IEXEC)

    relay_port = free_port()
    cfg = OrchestratorConfig.from_env({
        "AIG_ENV": "local", "AIG_PLATFORM_API_URL": platform_api, "AIG_PLATFORM_SERVICE_TOKEN": SERVICE_TOKEN,
        "AIG_WS_RELAY_PORT": str(relay_port), "AIG_WS_IDLE_TIMEOUT_MINUTES": "5",
        "AIG_WS_NOTIFY_URLS": f"{fake.url}/notify", "AIG_WS_NOTIFY_SECRET": NOTIFY_SECRET,
        # non-secret job settings (passed through)
        "AIG_PORTKEY_BASE_URL": f"{fake.url}/portkey/v1", "AIG_PORTKEY_CONFIG": "pc-aig-router",
        "AIG_FIDDLER_URL": f"{fake.url}/fiddler", "AIG_FIDDLER_PROJECT": "aig-workspace",
        "AIG_FIDDLER_APPLICATION_ID": APP_ID, "GITHUB_API_URL": f"{fake.url}/github",
        "AIG_WS_SETUP_COMMAND": "true", "AIG_WS_TEST_COMMAND": f"{sys.executable} -m pytest -q -p no:cacheprovider",
        "AIG_WS_HEARTBEAT_SECONDS": "0",
    })
    secret_env = {"AIG_PORTKEY_API_KEY": PORTKEY_KEY, "AIG_FIDDLER_API_KEY": FIDDLER_KEY, "GITHUB_TOKEN": GITHUB_TOKEN}
    runner = LocalProcessRunner(base_dir=str(tmp_path / "ws"), extra_env={
        "AIG_WS_CLAUDE_BIN": str(claude),
        "GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "url.file://" + str(bare.parent.parent) + "/.insteadOf",
        "GIT_CONFIG_VALUE_0": "https://github.example.com/",
    }, keep_dirs=True)
    platform = PlatformClient(cfg.platform_api_url, cfg.service_token)
    notifier = Notifier(cfg.notify_urls, cfg.notify_secret)
    scrubber = Scrubber([SERVICE_TOKEN, *secret_env.values()])
    worker = Worker(cfg, platform, runner, notifier=notifier, scrubber=scrubber, secret_env=secret_env)
    app = create_relay_app(secret=cfg.relay_secret, platform=platform, worker=worker, notifier=notifier, scrubber=scrubber)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=relay_port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.02)

    try:
        jane = {"Authorization": "Bearer dev:jane@example.com"}
        created = httpx.post(f"{platform_api}/api/v1/workspaces", headers=jane, json={
            "repo_url": "https://github.example.com/aig/demo", "work_item": "#7", "title": "Fix add()",
            "description": "add(2, 3) returns -1", "job_profile": "claims"}).json()
        wid = created["id"]
        assert created["status"] == "queued"

        deadline = time.time() + 120
        status = "queued"
        while time.time() < deadline:
            worker.tick()
            status = httpx.get(f"{platform_api}/api/v1/workspaces/{wid}", headers=jane).json()["status"]
            if status in ("completed", "failed", "cancelled"):
                break
            time.sleep(0.2)
        ws = httpx.get(f"{platform_api}/api/v1/workspaces/{wid}", headers=jane).json()
        job_log = "".join(p.read_text() for p in (tmp_path / "ws").glob("*/job.log"))
        assert ws["status"] == "completed", f"{ws}\n--- job log ---\n{job_log[-6000:]}"
        assert ws["pr_url"] == "https://github.example.com/aig/demo/pull/1" and ws["error"] is None

        # Status history from the audit log (newest first).
        admin = {"Authorization": "Bearer dev:admin@example.com"}
        audit = httpx.get(f"{platform_api}/api/v1/audit", headers=admin, params={"entity_id": wid, "limit": 100}).json()["items"]
        history = [a["details"].get("to") for a in reversed(audit) if a["action"] in ("workspace.claim", "workspace.status")]
        assert history == ["provisioning", "running", "testing", "running", "testing", "pr_opened", "completed"]

        # The registered agent workspace.<team> exists (orchestrator registered it with the service token).
        agent = httpx.get(f"{platform_api}/api/v1/agents/workspace.claims-ai", headers=jane).json()["agent"]
        assert agent["team"] == "claims-ai"

        # Claude Code went through "Portkey" with the contract headers.
        calls = fake.find("POST", "/portkey/v1/messages")
        assert len(calls) == 2
        h = calls[0]["headers"]
        assert h["x-portkey-api-key"] == PORTKEY_KEY and h["authorization"] == f"Bearer {PORTKEY_KEY}"
        assert h["x-portkey-config"] == "pc-aig-router"
        meta = json.loads(h["x-portkey-metadata"])
        assert meta == {"agent_id": "workspace.claims-ai", "team": "claims-ai", "env": "workspace", "host": "ecs",
                        "job_profile": "claims", "user_tier": "standard", "user": "jane@example.com", "_user": "jane@example.com"}
        trace_id = h["x-portkey-trace-id"]
        assert len(trace_id) == 32

        # ... and the job's spans reached "Fiddler" over OTLP with the same trace id.
        traces = fake.find("POST", "/fiddler/v1/traces")
        assert traces, "no spans exported"
        assert any(bytes.fromhex(trace_id) in t["body"] for t in traces)
        assert traces[0]["headers"]["fiddler-application-id"] == APP_ID
        assert traces[0]["headers"]["authorization"] == f"Bearer {FIDDLER_KEY}"
        assert any(b"workspace.code_agent" in t["body"] for t in traces)

        # The PR: branch pushed to the remote, body linked to the issue, author "AIG Code Agent".
        pr = json.loads(fake.find("POST", "/github/repos/aig/demo/pulls")[0]["body"])
        assert pr["head"] == f"aig/ws-{wid}" and pr["base"] == "main" and pr["title"] == "Fix add()"
        assert "Fixes #7" in pr["body"] and "unit tests: passed" in pr["body"] and trace_id in pr["body"]
        assert fake.find("POST", "/github/repos")[0]["headers"]["authorization"] == f"Bearer {GITHUB_TOKEN}"
        log = subprocess.run(["git", "--git-dir", str(bare), "log", "-1", "--format=%an|%s|%b", f"aig/ws-{wid}"],
                             capture_output=True, text=True, check=True).stdout
        assert log.startswith("AIG Code Agent|Fix add()|Fixes #7")
        show = subprocess.run(["git", "--git-dir", str(bare), "show", f"aig/ws-{wid}:calc.py"],
                              capture_output=True, text=True, check=True).stdout
        assert "return a + b" in show
        files = subprocess.run(["git", "--git-dir", str(bare), "show", "--name-only", "--format=", f"aig/ws-{wid}"],
                               capture_output=True, text=True, check=True).stdout.split()
        assert files == ["calc.py"]

        # Signed notifications for the Teams bot, in order.
        notes = fake.find("POST", "/notify")
        for n in notes:
            assert verify(NOTIFY_SECRET, n["headers"]["x-aig-timestamp"], n["body"], n["headers"]["x-aig-signature"])
        seen = [json.loads(n["body"])["workspace"]["status"] for n in notes]
        assert seen[0] == "provisioning" and seen[-1] == "completed" and "pr_opened" in seen and "testing" in seen

        # No secret anywhere: job log, PR body, platform-api record, notifications.
        everything = job_log + json.dumps(pr) + json.dumps(ws) + "".join(n["body"].decode() for n in notes)
        for secret in (SERVICE_TOKEN, PORTKEY_KEY, FIDDLER_KEY, GITHUB_TOKEN, cfg.relay_secret):
            assert secret not in everything
        assert not worker.tracked
    finally:
        server.should_exit = True
        fake.server.shutdown()


def test_cancel_stops_a_running_job(tmp_path, platform_api):
    """A job that hangs in the code agent is stopped when the requester cancels."""
    hang = tmp_path / "claude"
    hang.write_text(f"#!{sys.executable}\nimport time\ntime.sleep(120)\n")
    hang.chmod(hang.stat().st_mode | stat.S_IEXEC)
    fake = Fake()
    make_remote(tmp_path)
    relay_port = free_port()
    cfg = OrchestratorConfig.from_env({
        "AIG_ENV": "local", "AIG_PLATFORM_API_URL": platform_api, "AIG_PLATFORM_SERVICE_TOKEN": SERVICE_TOKEN,
        "AIG_WS_RELAY_PORT": str(relay_port), "AIG_PORTKEY_BASE_URL": f"{fake.url}/portkey/v1",
        "AIG_FIDDLER_URL": f"{fake.url}/fiddler", "AIG_FIDDLER_PROJECT": "aig-workspace",
        "AIG_FIDDLER_APPLICATION_ID": APP_ID, "GITHUB_API_URL": f"{fake.url}/github", "AIG_WS_SETUP_COMMAND": "true",
    })
    runner = LocalProcessRunner(base_dir=str(tmp_path / "ws"), stop_grace_seconds=3, extra_env={
        "AIG_WS_CLAUDE_BIN": str(hang), "GIT_CONFIG_COUNT": "1",
        "GIT_CONFIG_KEY_0": f"url.file://{tmp_path / 'remotes'}/.insteadOf", "GIT_CONFIG_VALUE_0": "https://github.example.com/"})
    platform = PlatformClient(cfg.platform_api_url, cfg.service_token)
    worker = Worker(cfg, platform, runner, secret_env={"AIG_PORTKEY_API_KEY": PORTKEY_KEY, "AIG_FIDDLER_API_KEY": FIDDLER_KEY,
                                                       "GITHUB_TOKEN": GITHUB_TOKEN})
    server = uvicorn.Server(uvicorn.Config(create_relay_app(secret=cfg.relay_secret, platform=platform, worker=worker),
                                           host="127.0.0.1", port=relay_port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.02)
    try:
        jane = {"Authorization": "Bearer dev:jane@example.com"}
        wid = httpx.post(f"{platform_api}/api/v1/workspaces", headers=jane, json={
            "repo_url": "https://github.example.com/aig/demo", "work_item": "#8", "title": "Hang"}).json()["id"]
        deadline = time.time() + 60
        while time.time() < deadline:
            worker.tick()
            if httpx.get(f"{platform_api}/api/v1/workspaces/{wid}", headers=jane).json()["status"] == "running":
                break
            time.sleep(0.2)
        handle = worker.tracked[wid].handle
        assert httpx.post(f"{platform_api}/api/v1/workspaces/{wid}/cancel", headers=jane).json()["status"] == "cancelled"
        worker.tick()
        assert wid not in worker.tracked and not runner.poll(handle).running
        assert httpx.get(f"{platform_api}/api/v1/workspaces/{wid}", headers=jane).json()["status"] == "cancelled"
    finally:
        server.should_exit = True
        fake.server.shutdown()
