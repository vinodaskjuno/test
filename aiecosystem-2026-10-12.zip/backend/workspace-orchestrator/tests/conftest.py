from __future__ import annotations

import itertools
import uuid
from dataclasses import replace

import pytest

from workspace_orchestrator.config import OrchestratorConfig
from workspace_orchestrator.platform import ClaimConflict, PlatformError
from workspace_orchestrator.runners.base import TaskHandle, TaskState

SERVICE_TOKEN = "svc-SUPERSECRET-0011223344556677"
RELAY_SECRET = "relay-SUPERSECRET-8899aabbccddeeff"
NOTIFY_SECRET = "notify-SUPERSECRET-0123456789"


def base_env(**kw) -> dict[str, str]:
    env = {
        "AIG_ENV": "local",
        "AIG_PLATFORM_API_URL": "http://platform.test",
        "AIG_PLATFORM_SERVICE_TOKEN": SERVICE_TOKEN,
        "AIG_WS_RELAY_SECRET": RELAY_SECRET,
        "AIG_WS_POLL_INTERVAL_SECONDS": "0.05",
    }
    env.update(kw)
    return env


@pytest.fixture
def cfg() -> OrchestratorConfig:
    return OrchestratorConfig.from_env(base_env())


def workspace(**kw) -> dict:
    ws = {
        "id": str(uuid.uuid4()), "repo_url": "https://github.example.com/aig/claims-triage", "work_item": "#12",
        "title": "Fix rounding", "description": "Totals are off by a cent", "job_profile": "claims",
        "status": "queued", "requested_by": "jane@example.com", "team": "claims-ai", "pr_url": None,
        "log_url": None, "error": None, "created_at": "2026-10-09T10:00:00Z", "updated_at": "2026-10-09T10:00:00Z",
    }
    ws.update(kw)
    return ws


class FakePlatform:
    """In-memory platform-api with the orchestrator client's interface."""

    def __init__(self, *workspaces: dict) -> None:
        self.ws = {w["id"]: dict(w) for w in workspaces}
        self.agents: dict[str, dict] = {}
        self.calls: list[tuple] = []
        self.steal: set[str] = set()  # ids another worker claims first

    def add(self, w: dict) -> dict:
        self.ws[w["id"]] = dict(w)
        return w

    def list_workspaces(self, status=None):
        return [dict(w) for w in self.ws.values() if status in (None, w["status"])]

    def list_queued(self):
        return sorted(self.list_workspaces("queued"), key=lambda w: w["created_at"])

    def get_workspace(self, wid):
        w = self.ws.get(wid)
        return dict(w) if w else None

    def claim(self, wid, worker):
        self.calls.append(("claim", wid, worker))
        if wid in self.steal:
            self.ws[wid]["status"] = "provisioning"
            raise ClaimConflict(409, "invalid_transition", "already claimed")
        w = self.ws[wid]
        if w["status"] != "queued":
            raise ClaimConflict(409, "invalid_transition", "not queued")
        w["status"] = "provisioning"
        return dict(w)

    def update_status(self, wid, status, *, pr_url=None, log_url=None, error=None):
        self.calls.append(("status", wid, status, error))
        w = self.ws[wid]
        if w["status"] in ("completed", "failed", "cancelled") and status != w["status"]:
            raise PlatformError(409, "invalid_transition", "final")
        w["status"] = status
        for k, v in (("pr_url", pr_url), ("log_url", log_url), ("error", error)):
            if v is not None:
                w[k] = v
        return dict(w)

    def get_agent(self, agent_id):
        return self.agents.get(agent_id)

    def ensure_agent(self, agent_id, *, team, owner, description):
        self.calls.append(("ensure_agent", agent_id, team, owner))
        if agent_id in self.agents:
            return False
        self.agents[agent_id] = {"agent_id": agent_id, "team": team, "owner": owner, "status": "active"}
        return True

    def statuses(self, wid):
        return [c[2] for c in self.calls if c[0] == "status" and c[1] == wid]


class FakeRunner:
    name = "fake"

    def __init__(self) -> None:
        self.started: list = []
        self.stopped: list[tuple[str, str]] = []
        self.states: dict[str, TaskState] = {}
        self.found: dict[str, TaskHandle] = {}
        self.fail_start = False
        self._ids = itertools.count(1)

    def start(self, spec):
        if self.fail_start:
            raise RuntimeError(f"capacity unavailable token={SERVICE_TOKEN}")
        self.started.append(spec)
        h = TaskHandle(id=f"task-{next(self._ids)}", log_url="https://logs.example.com/ws/" + spec.workspace_id)
        self.states[h.id] = TaskState(running=True)
        return h

    def poll(self, handle):
        return self.states[handle.id]

    def stop(self, handle, reason):
        self.stopped.append((handle.id, reason))
        self.states[handle.id] = TaskState(running=False, exit_code=143, reason=reason)

    def find(self, wid):
        return self.found.get(wid)

    def exit(self, handle_id, code=0):
        self.states[handle_id] = TaskState(running=False, exit_code=code, reason="exited")


class Clock:
    def __init__(self, t: float = 1000.0) -> None:
        self.t = t

    def __call__(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t += seconds


class RecordingNotifier:
    def __init__(self) -> None:
        self.events: list[tuple[str, str]] = []

    def workspace_changed(self, ws):
        self.events.append((ws["id"], ws["status"]))


def with_cfg(cfg: OrchestratorConfig, **kw) -> OrchestratorConfig:
    return replace(cfg, **kw)
