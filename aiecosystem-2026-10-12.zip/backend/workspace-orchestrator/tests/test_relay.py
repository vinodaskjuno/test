"""The workspace relay: per-workspace tokens and the platform-api allow-list."""

from __future__ import annotations

import httpx
import pytest
from conftest import RELAY_SECRET, SERVICE_TOKEN, Clock, FakePlatform, FakeRunner, RecordingNotifier, workspace
from starlette.testclient import TestClient

from workspace_orchestrator.relay import create_relay_app, mint_token, verify_token
from workspace_orchestrator.worker import Tracked, Worker


class ForwardingPlatform(FakePlatform):
    def __init__(self, *wss):
        super().__init__(*wss)
        self.forwarded: list[tuple] = []

    def forward(self, method, path, *, params=None, content=None, content_type=None):
        self.forwarded.append((method, path, params, content))
        return httpx.Response(200, json={"ok": True, "path": path})


@pytest.fixture
def env(cfg):
    ws = workspace(status="provisioning")
    other = workspace(status="running", team="uw-ai")
    platform = ForwardingPlatform(ws, other)
    platform.agents["claims-bot"] = {"agent_id": "claims-bot", "team": "claims-ai"}
    platform.agents["uw-bot"] = {"agent_id": "uw-bot", "team": "uw-ai"}
    clock = Clock()
    worker = Worker(cfg, platform, FakeRunner(), clock=clock)
    worker.tracked[ws["id"]] = Tracked(ws, None, 0.0, 0.0, "provisioning")
    notifier = RecordingNotifier()
    app = create_relay_app(secret=RELAY_SECRET, platform=platform, worker=worker, notifier=notifier)
    client = TestClient(app)
    tok = {"x-aig-workspace-token": mint_token(RELAY_SECRET, ws["id"])}
    return client, ws, other, platform, worker, clock, notifier, tok


def base(ws):
    return f"/relay/v1/workspaces/{ws['id']}"


def test_token_scoped_to_one_workspace(env):
    client, ws, other, *_, tok = env
    assert verify_token(RELAY_SECRET, ws["id"], tok["x-aig-workspace-token"])
    assert not verify_token(RELAY_SECRET, other["id"], tok["x-aig-workspace-token"])
    assert client.get(base(ws)).status_code == 401
    assert client.get(base(ws), headers={"x-aig-workspace-token": "aigws1.00"}).json()["error"]["code"] == "workspace_unauthenticated"
    assert client.get(base(other), headers=tok).status_code == 401  # someone else's workspace
    assert client.get(base(ws), headers={"x-aig-service-token": SERVICE_TOKEN}).status_code == 401
    assert client.get(base(ws), headers=tok).json()["id"] == ws["id"]
    bearer = {"Authorization": f"Bearer {tok['x-aig-workspace-token']}"}
    assert client.get(base(ws), headers=bearer).status_code == 200
    assert client.get("/healthz").json()["status"] == "ok"


def test_status_forwarding_activity_and_notify(env):
    client, ws, _, platform, worker, clock, notifier, tok = env
    clock.advance(100)
    r = client.post(f"{base(ws)}/status", headers=tok, json={"status": "running"})
    assert r.status_code == 200 and platform.ws[ws["id"]]["status"] == "running"
    assert worker.tracked[ws["id"]].last_activity == clock() and worker.tracked[ws["id"]].last_status == "running"
    assert notifier.events == [(ws["id"], "running")]
    assert client.post(f"{base(ws)}/status", headers=tok, json={"status": "completed"}).status_code == 400
    assert client.post(f"{base(ws)}/status", headers=tok, json={"status": "pr_opened"}).status_code == 400
    assert client.post(f"{base(ws)}/status", headers=tok, content=b"nope").json()["error"]["code"] == "invalid_json"
    r = client.post(f"{base(ws)}/status", headers=tok,
                    json={"status": "failed", "error": f"boom ghp_{'a' * 36} token={SERVICE_TOKEN}"})
    assert r.status_code == 200
    err = platform.ws[ws["id"]]["error"]
    assert "ghp_" not in err and SERVICE_TOKEN not in err
    # final: nothing more is accepted
    assert client.post(f"{base(ws)}/heartbeat", headers=tok).json()["error"]["code"] == "workspace_closed"


def test_heartbeat_counts_as_activity(env):
    client, ws, _, _, worker, clock, _, tok = env
    clock.advance(50)
    assert client.post(f"{base(ws)}/heartbeat", headers=tok).status_code == 204
    assert worker.tracked[ws["id"]].last_activity == clock()


def test_platform_allow_list(env):
    client, ws, _, platform, _, _, _, tok = env
    p = f"{base(ws)}/platform"
    svc = {"x-aig-service-token": tok["x-aig-workspace-token"]}  # how `aig eval` sends it
    assert client.get(f"{p}/api/v1/agents/workspace.claims-ai", headers=tok).status_code == 200
    assert client.get(f"{p}/api/v1/agents/claims-bot", headers=tok).status_code == 200  # same team
    assert client.get(f"{p}/api/v1/agents/uw-bot", headers=tok).status_code == 403  # other team
    assert client.get(f"{p}/api/v1/evals?agent_id=claims-bot&limit=5", headers=svc).status_code == 200
    assert platform.forwarded[-1][2] == [("agent_id", "claims-bot"), ("limit", "5")]
    assert client.post(f"{p}/api/v1/evals", headers=svc, json={"agent_id": "claims-bot", "dataset": "d"}).status_code == 200
    assert client.post(f"{p}/api/v1/evals", headers=svc, json={"agent_id": "uw-bot"}).status_code == 403
    assert client.post(f"{p}/api/v1/evals", headers=svc, content=b"[1]").status_code == 400
    for method, path in (("GET", "api/v1/workspaces"), ("POST", "api/v1/agents/claims-bot/suspend"),
                         ("GET", "api/v1/models"), ("POST", "api/v1/agents")):
        assert client.request(method, f"{p}/{path}", headers=tok).status_code == 403, path
    assert all(f[1] in ("/api/v1/agents/workspace.claims-ai", "/api/v1/agents/claims-bot", "/api/v1/evals")
               for f in platform.forwarded)


def test_unknown_workspace(cfg):
    platform = ForwardingPlatform()
    client = TestClient(create_relay_app(secret=RELAY_SECRET, platform=platform))
    assert client.get("/relay/v1/workspaces/x", headers={"x-aig-workspace-token": mint_token(RELAY_SECRET, "x")}).status_code == 404
