"""GitHub App installation tokens and pull requests (respx), repo + work-item parsing."""

from __future__ import annotations

import json

import httpx
import jwt
import pytest
import respx
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from workspace_orchestrator.job.github import (
    GitHubAuth,
    GitHubClient,
    GitHubError,
    RepoRef,
    api_base,
    app_jwt,
    parse_repo,
    work_item_link,
)

API = "https://api.github.com"
REPO = RepoRef("github.com", "aig", "claims-triage")


@pytest.fixture(scope="module")
def key_pair():
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption()).decode()
    return pem, key.public_key()


def test_app_jwt_claims(key_pair):
    pem, pub = key_pair
    token = app_jwt("12345", pem, now=1_700_000_000)
    claims = jwt.decode(token, pub, algorithms=["RS256"], options={"verify_exp": False})
    assert claims == {"iat": 1_700_000_000 - 60, "exp": 1_700_000_000 + 540, "iss": "12345"}


@respx.mock
def test_installation_token_via_repo_lookup(key_pair):
    pem, pub = key_pair
    lookup = respx.get(f"{API}/repos/aig/claims-triage/installation").mock(return_value=httpx.Response(200, json={"id": 42}))
    create = respx.post(f"{API}/app/installations/42/access_tokens").mock(
        return_value=httpx.Response(201, json={"token": "ghs_installationtoken0123456789abcd", "expires_at": "x"}))
    auth = GitHubAuth(api=API, app_id="12345", private_key=pem)
    assert auth.mode == "app"
    assert auth.installation_token(REPO) == "ghs_installationtoken0123456789abcd"
    bearer = lookup.calls[0].request.headers["authorization"].split(" ", 1)[1]
    assert jwt.decode(bearer, pub, algorithms=["RS256"])["iss"] == "12345"
    body = json.loads(create.calls[0].request.content)
    assert body == {"repositories": ["claims-triage"],
                    "permissions": {"contents": "write", "pull_requests": "write", "issues": "read"}}
    assert create.calls[0].request.headers["x-github-api-version"] == "2022-11-28"
    auth.installation_token(REPO)  # cached
    assert create.call_count == 1


@respx.mock
def test_installation_token_with_configured_installation_and_errors(key_pair):
    pem, _ = key_pair
    respx.post(f"{API}/app/installations/7/access_tokens").mock(return_value=httpx.Response(201, json={"token": "ghs_x" * 8}))
    assert GitHubAuth(api=API, app_id="1", private_key=pem, installation_id="7").installation_token(REPO).startswith("ghs_")
    respx.get(f"{API}/repos/aig/claims-triage/installation").mock(return_value=httpx.Response(404))
    with pytest.raises(GitHubError, match="not installed"):
        GitHubAuth(api=API, app_id="1", private_key=pem).installation_token(REPO)
    with pytest.raises(GitHubError, match="credentials missing"):
        GitHubAuth(api=API)


def test_plain_token_mode():
    auth = GitHubAuth(api=API, token="ghp_preissued")
    assert auth.mode == "token" and auth.installation_token(REPO) == "ghp_preissued"


@respx.mock
def test_create_pull_and_existing():
    route = respx.post(f"{API}/repos/aig/claims-triage/pulls").mock(
        return_value=httpx.Response(201, json={"html_url": "https://github.com/aig/claims-triage/pull/9"}))
    gh = GitHubClient(API, "ghs_tok")
    url = gh.create_pull(REPO, title="Fix", head="aig/ws-1", base="main", body="Fixes #12")
    assert url.endswith("/pull/9")
    sent = json.loads(route.calls[0].request.content)
    assert sent["head"] == "aig/ws-1" and sent["base"] == "main" and sent["body"] == "Fixes #12" and sent["draft"] is False
    route.mock(return_value=httpx.Response(422, json={"message": "Validation Failed",
                                                      "errors": [{"message": "A pull request already exists for aig:aig/ws-1."}]}))
    respx.get(f"{API}/repos/aig/claims-triage/pulls").mock(
        return_value=httpx.Response(200, json=[{"html_url": "https://github.com/aig/claims-triage/pull/8"}]))
    assert gh.create_pull(REPO, title="Fix", head="aig/ws-1", base="main", body="").endswith("/pull/8")
    route.mock(return_value=httpx.Response(403))
    with pytest.raises(GitHubError, match="403"):
        gh.create_pull(REPO, title="Fix", head="aig/ws-1", base="main", body="")


def test_parse_repo_and_api_base():
    assert parse_repo("https://github.com/aig/claims-triage.git") == REPO
    assert parse_repo("git@github.com:aig/claims-triage.git") == REPO
    ghes = parse_repo("https://github.example.com/aig/x/")
    assert ghes.https_url == "https://github.example.com/aig/x.git"
    assert api_base(REPO) == API and api_base(ghes) == "https://github.example.com/api/v3"
    assert api_base(ghes, "http://127.0.0.1:9/github/") == "http://127.0.0.1:9/github"
    with pytest.raises(GitHubError):
        parse_repo("file:///etc/passwd")


@pytest.mark.parametrize("item,closing,prefix", [
    ("#12", "Fixes #12", ""),
    ("12", "Fixes #12", ""),
    ("https://github.com/aig/claims-triage/issues/5", "Fixes #5", ""),
    ("https://github.com/aig/other/issues/5", "Fixes aig/other#5", ""),
    ("https://gitlab.example.com/aig/x/issues/5", None, ""),
    ("CLAIMS-1234", None, "[CLAIMS-1234] "),
    ("https://jira.example.com/browse/CLAIMS-1", None, ""),
])
def test_work_item_links(item, closing, prefix):
    link = work_item_link(item, REPO)
    assert link.closing == closing and link.title_prefix == prefix
