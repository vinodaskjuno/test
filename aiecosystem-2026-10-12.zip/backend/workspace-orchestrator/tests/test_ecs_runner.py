"""EcsRunner against a botocore Stubber (no AWS calls)."""

from __future__ import annotations

import boto3
import pytest
from botocore.stub import ANY, Stubber
from conftest import base_env

from workspace_orchestrator.config import ConfigError, EcsConfig, OrchestratorConfig
from workspace_orchestrator.runners.base import JobSpec, TaskHandle
from workspace_orchestrator.runners.ecs import EcsRunner, EcsRunnerError, cloudwatch_url, started_by

CLUSTER = "aig-dev-workspaces"
TASK_ARN = "arn:aws:ecs:us-east-1:123456789012:task/aig-dev-workspaces/0123456789abcdef"
BASE_TD = "arn:aws:ecs:us-east-1:123456789012:task-definition/aig-workspace:7"
PORTKEY_TEMPLATE = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/{env}/workspace/{team}:portkey_api_key::"


def ecs_cfg(**kw) -> EcsConfig:
    values = dict(cluster=CLUSTER, task_definition="aig-workspace", subnets=("subnet-a", "subnet-b"),
                  security_groups=("sg-egress",), log_group="/aig/dev/workspaces", region="us-east-1", env="dev")
    values.update(kw)
    return EcsConfig(**values)


@pytest.fixture
def ecs():
    client = boto3.client("ecs", region_name="us-east-1", aws_access_key_id="x", aws_secret_access_key="y")
    with Stubber(client) as stub:
        yield client, stub
        stub.assert_no_pending_responses()


SPEC = JobSpec(workspace_id="3f2b8a52-1111-4222-8333-444455556666", team="claims-ai",
               env={"WORKSPACE_ID": "3f2b8a52-1111-4222-8333-444455556666", "REPO_URL": "https://github.example.com/a/b",
                    "WORK_ITEM": "#12", "JOB_PROFILE": "claims", "AIG_ENV": "workspace", "AIG_HOST": "ecs"},
               secret_env={"AIG_PORTKEY_API_KEY": "never-sent"})


def test_run_task_request_shape(ecs):
    client, stub = ecs
    stub.add_response("run_task", {"tasks": [{"taskArn": TASK_ARN}], "failures": []}, {
        "cluster": CLUSTER, "taskDefinition": "aig-workspace", "count": 1, "platformVersion": "LATEST",
        "launchType": "FARGATE",
        "networkConfiguration": {"awsvpcConfiguration": {"subnets": ["subnet-a", "subnet-b"],
                                                         "securityGroups": ["sg-egress"], "assignPublicIp": "DISABLED"}},
        "overrides": {"containerOverrides": [{"name": "workspace", "environment": [
            {"name": k, "value": v} for k, v in sorted(SPEC.env.items())]}]},
        "startedBy": f"aig-ws/{SPEC.workspace_id}", "clientToken": SPEC.workspace_id,
        "enableExecuteCommand": False, "propagateTags": "TASK_DEFINITION",
        "tags": [{"key": "aig:workspace-id", "value": SPEC.workspace_id}, {"key": "aig:team", "value": "claims-ai"},
                 {"key": "aig:env", "value": "dev"}],
    })
    handle = EcsRunner(ecs_cfg(), client=client).start(SPEC)
    assert handle.id == TASK_ARN
    assert handle.log_url == cloudwatch_url("us-east-1", "/aig/dev/workspaces", "workspace/workspace/0123456789abcdef")
    # The Stubber matched the exact overrides above: secret_env (never-sent) is not in them.


def test_capacity_provider_and_failures(ecs):
    client, stub = ecs
    stub.add_response("run_task", {"tasks": [], "failures": [{"arn": "x", "reason": "RESOURCE:ENI"}]},
                      {"cluster": CLUSTER, "taskDefinition": "aig-workspace", "count": 1, "platformVersion": "LATEST",
                       "capacityProviderStrategy": [{"capacityProvider": "FARGATE_SPOT", "weight": 1}],
                       "networkConfiguration": ANY, "overrides": ANY, "startedBy": ANY, "clientToken": ANY,
                       "enableExecuteCommand": False, "propagateTags": "TASK_DEFINITION", "tags": ANY})
    with pytest.raises(EcsRunnerError, match="RESOURCE:ENI"):
        EcsRunner(ecs_cfg(capacity_provider="FARGATE_SPOT"), client=client).start(SPEC)


def test_team_task_definition_map(ecs):
    client, stub = ecs
    stub.add_response("run_task", {"tasks": [{"taskArn": TASK_ARN}]},
                      {"cluster": CLUSTER, "taskDefinition": "aig-workspace-claims", "count": 1, "platformVersion": "LATEST",
                       "launchType": "FARGATE", "networkConfiguration": ANY, "overrides": ANY, "startedBy": ANY,
                       "clientToken": ANY, "enableExecuteCommand": False, "propagateTags": "TASK_DEFINITION", "tags": ANY})
    EcsRunner(ecs_cfg(team_task_definitions={"claims-ai": "aig-workspace-claims"}), client=client).start(SPEC)


def _td(family: str, arn: str, secrets: list[dict], image: str = "123.dkr.ecr.us-east-1.amazonaws.com/aig-workspace:1.0.0"):
    return {"taskDefinition": {
        "taskDefinitionArn": arn, "family": family, "networkMode": "awsvpc", "requiresCompatibilities": ["FARGATE"],
        "cpu": "2048", "memory": "8192", "taskRoleArn": "arn:aws:iam::123456789012:role/aig-workspace-task",
        "executionRoleArn": "arn:aws:iam::123456789012:role/aig-workspace-exec",
        "containerDefinitions": [{"name": "workspace", "image": image, "secrets": secrets, "essential": True}],
    }}


def test_derived_team_task_definition_registered_once_and_reused(ecs):
    client, stub = ecs
    shared = [{"name": "AIG_FIDDLER_API_KEY", "valueFrom": "arn:aws:secretsmanager:us-east-1:1:secret:aig/dev/fiddler"},
              {"name": "AIG_PORTKEY_API_KEY", "valueFrom": "arn:base-team-key"}]
    portkey = PORTKEY_TEMPLATE.format(env="dev", team="claims-ai")
    stub.add_response("describe_task_definition", _td("aig-workspace", BASE_TD, shared), {"taskDefinition": "aig-workspace"})
    stub.add_client_error("describe_task_definition", "ClientException", "Unable to describe task definition.",
                          expected_params={"taskDefinition": "aig-workspace-claims-ai"})
    stub.add_response("register_task_definition",
                      {"taskDefinition": {"taskDefinitionArn": "arn:td/aig-workspace-claims-ai:1"}},
                      {"family": "aig-workspace-claims-ai", "containerDefinitions": [{
                          "name": "workspace", "image": ANY, "essential": True,
                          "secrets": [shared[0], {"name": "AIG_PORTKEY_API_KEY", "valueFrom": portkey}]}],
                       "taskRoleArn": ANY, "executionRoleArn": ANY, "networkMode": "awsvpc",
                       "requiresCompatibilities": ["FARGATE"], "cpu": "2048", "memory": "8192",
                       "tags": [{"key": "aig:team", "value": "claims-ai"}, {"key": "aig:component", "value": "workspace"}]})
    runner = EcsRunner(ecs_cfg(portkey_secret_arn_template=PORTKEY_TEMPLATE), client=client)
    assert runner.task_definition_for("claims-ai") == "arn:td/aig-workspace-claims-ai:1"
    assert runner.task_definition_for("claims-ai") == "arn:td/aig-workspace-claims-ai:1"  # cached, no API call


def test_existing_derived_definition_is_reused(ecs):
    client, stub = ecs
    portkey = PORTKEY_TEMPLATE.format(env="dev", team="uw-ai")
    stub.add_response("describe_task_definition", _td("aig-workspace", BASE_TD, []), {"taskDefinition": "aig-workspace"})
    stub.add_response("describe_task_definition",
                      _td("aig-workspace-uw-ai", "arn:td/aig-workspace-uw-ai:4", [{"name": "AIG_PORTKEY_API_KEY", "valueFrom": portkey}]),
                      {"taskDefinition": "aig-workspace-uw-ai"})
    runner = EcsRunner(ecs_cfg(portkey_secret_arn_template=PORTKEY_TEMPLATE), client=client)
    assert runner.task_definition_for("uw-ai") == "arn:td/aig-workspace-uw-ai:4"


def test_poll_stop_find(ecs):
    client, stub = ecs
    runner = EcsRunner(ecs_cfg(), client=client)
    h = TaskHandle(id=TASK_ARN)
    stub.add_response("describe_tasks", {"tasks": [{"taskArn": TASK_ARN, "lastStatus": "RUNNING"}]},
                      {"cluster": CLUSTER, "tasks": [TASK_ARN]})
    assert runner.poll(h).running
    stub.add_response("describe_tasks", {"tasks": [{"taskArn": TASK_ARN, "lastStatus": "STOPPED",
                                                    "stoppedReason": "Essential container in task exited",
                                                    "containers": [{"name": "workspace", "exitCode": 0}]}]},
                      {"cluster": CLUSTER, "tasks": [TASK_ARN]})
    state = runner.poll(h)
    assert not state.running and state.exit_code == 0 and "exited" in state.reason
    stub.add_response("describe_tasks", {"tasks": [{"taskArn": TASK_ARN, "lastStatus": "STOPPED",
                                                    "containers": [{"name": "workspace",
                                                                    "reason": "CannotPullContainerError"}]}]},
                      {"cluster": CLUSTER, "tasks": [TASK_ARN]})
    assert runner.poll(h).reason == "CannotPullContainerError"
    stub.add_response("describe_tasks", {"tasks": [], "failures": [{"arn": TASK_ARN, "reason": "MISSING"}]},
                      {"cluster": CLUSTER, "tasks": [TASK_ARN]})
    assert runner.poll(h).reason == "task not found"
    stub.add_response("stop_task", {"task": {"taskArn": TASK_ARN}},
                      {"cluster": CLUSTER, "task": TASK_ARN, "reason": "idle timeout"})
    runner.stop(h, "idle timeout")
    stub.add_client_error("stop_task", "InvalidParameterException", "gone")
    runner.stop(h, "again")  # already gone: no error
    wid = "3f2b8a52-1111-4222-8333-444455556666"
    stub.add_response("list_tasks", {"taskArns": [TASK_ARN]},
                      {"cluster": CLUSTER, "startedBy": started_by(wid), "desiredStatus": "RUNNING"})
    assert runner.find(wid).id == TASK_ARN
    stub.add_response("list_tasks", {"taskArns": []},
                      {"cluster": CLUSTER, "startedBy": started_by(wid), "desiredStatus": "RUNNING"})
    assert runner.find(wid) is None


def test_override_env_limit(ecs):
    client, _ = ecs
    big = JobSpec(workspace_id="w", team="t", env={"X": "y" * 9000})
    with pytest.raises(EcsRunnerError, match="8 KiB"):
        EcsRunner(ecs_cfg(), client=client).start(big)


def test_cloudwatch_url_encoding():
    url = cloudwatch_url("eu-west-1", "/aig/dev/workspaces", "workspace/workspace/abc")
    assert url == ("https://eu-west-1.console.aws.amazon.com/cloudwatch/home?region=eu-west-1#logsV2:log-groups/"
                   "log-group/$252Faig$252Fdev$252Fworkspaces/log-events/workspace$252Fworkspace$252Fabc")


def test_ecs_config_from_env():
    env = base_env(AIG_ENV="dev", AIG_WS_RELAY_PUBLIC_URL="http://orchestrator.aig.internal:8090",
                   AIG_WS_ECS_CLUSTER=CLUSTER, AIG_WS_ECS_TASK_DEFINITION="aig-workspace",
                   AIG_WS_ECS_SUBNETS="subnet-a, subnet-b", AIG_WS_ECS_SECURITY_GROUPS="sg-1",
                   AIG_WS_ECS_TEAM_TASK_DEFINITIONS='{"claims-ai": "td-claims"}', AWS_REGION="us-east-1")
    cfg = OrchestratorConfig.from_env(env)
    assert cfg.runner == "ecs" and cfg.ecs.subnets == ("subnet-a", "subnet-b")
    assert cfg.ecs.team_task_definitions == {"claims-ai": "td-claims"} and not cfg.ecs.assign_public_ip
    with pytest.raises(ConfigError, match="SUBNETS"):
        OrchestratorConfig.from_env({**env, "AIG_WS_ECS_SUBNETS": ""})
    with pytest.raises(ConfigError, match="JSON"):
        OrchestratorConfig.from_env({**env, "AIG_WS_ECS_TEAM_TASK_DEFINITIONS": "nope"})
