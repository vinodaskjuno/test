"""workspace-job failure paths (in process, fake relay, local bare repo)."""

from __future__ import annotations

import os
import subprocess
import sys

import pytest

from workspace_orchestrator.job import JobConfig, WorkspaceJob
from workspace_orchestrator.job.agents import AgentResult


class FakeReporter:
    platform_url = "http://relay.test/platform"

    def __init__(self, ws):
        self.ws = ws
        self.reports: list[tuple] = []
        self.closed = False
        self.beats = 0

    def report(self, status, *, pr_url=None, error=None):
        self.reports.append((status, pr_url, error))
        return {}

    def workspace(self):
        return self.ws

    def heartbeat(self, force=False):
        self.beats += 1


class EditAgent:
    name = "fake"

    def __init__(self, content: str | None, ok: bool = True):
        self.content, self.ok, self.prompts = content, ok, []

    def run(self, ctx):
        self.prompts.append(ctx.prompt)
        assert "GITHUB_TOKEN" not in ctx.env and "AIG_WS_STATUS_TOKEN" not in ctx.env
        if self.content is not None:
            with open(os.path.join(ctx.cwd, "calc.py"), "w") as f:
                f.write(self.content)
        return AgentResult(self.ok, "did something")


@pytest.fixture
def remote(tmp_path):
    seed = tmp_path / "seed"
    seed.mkdir()
    (seed / "calc.py").write_text("def add(a, b):\n    return a - b\n")
    (seed / "test_calc.py").write_text("from calc import add\n\ndef test_add():\n    assert add(2, 3) == 5\n")
    (seed / ".gitignore").write_text("__pycache__/\n")
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=seed, check=True)
    subprocess.run(["git", "add", "-A"], cwd=seed, check=True)
    subprocess.run(["git", "-c", "user.name=s", "-c", "user.email=s@x.com", "commit", "-q", "-m", "s"], cwd=seed, check=True)
    bare = tmp_path / "remotes" / "aig" / "demo.git"
    bare.parent.mkdir(parents=True)
    subprocess.run(["git", "clone", "-q", "--bare", str(seed), str(bare)], check=True)
    return tmp_path / "remotes"


def job(tmp_path, remote, agent, **env):
    base = {"WORKSPACE_ID": "w1", "AIG_WS_STATUS_URL": "http://relay.test", "AIG_WS_STATUS_TOKEN": "aigws1.deadbeefdeadbeef00",
            "AIG_WS_WORKDIR": str(tmp_path / "work"), "PATH": os.environ["PATH"], "HOME": str(tmp_path),
            "GITHUB_TOKEN": "ghp_jobtestSUPERSECRET000000000000000", "GITHUB_API_URL": "http://gh.invalid",
            "GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": f"url.file://{remote}/.insteadOf",
            "GIT_CONFIG_VALUE_0": "https://github.example.com/", "AIG_WS_SETUP_COMMAND": "true",
            "AIG_WS_TEST_COMMAND": f"{sys.executable} -m pytest -q -p no:cacheprovider", "AIG_WS_FIX_ATTEMPTS": "2"}
    base.update(env)
    ws = {"id": "w1", "repo_url": "https://github.example.com/aig/demo", "work_item": "#3", "title": "Fix add",
          "description": "", "team": "claims-ai", "requested_by": "jane@example.com"}
    reporter = FakeReporter(ws)
    j = WorkspaceJob(JobConfig.from_env(base), reporter=reporter, agent=agent, sdk_init=lambda env, tracing: None)
    return j, reporter


def test_tests_still_failing_after_attempts(tmp_path, remote):
    agent = EditAgent("def add(a, b):\n    return a * b\n")
    j, rep = job(tmp_path, remote, agent)
    assert j.run() == 1
    statuses = [r[0] for r in rep.reports]
    assert statuses == ["running", "testing", "running", "testing", "failed"]
    err = rep.reports[-1][2]
    assert err.startswith("tests: tests still failing after 2 code agent attempt(s)") and "assert" in err
    assert "ghp_jobtest" not in err
    assert "did not pass the checks" in agent.prompts[1]  # failure fed back to the agent
    assert rep.beats > 0


def test_no_changes_fails(tmp_path, remote):
    j, rep = job(tmp_path, remote, EditAgent(None))
    assert j.run() == 1
    assert rep.reports[-1][0] == "failed" and "made no changes" in rep.reports[-1][2]


def test_agent_error_fails(tmp_path, remote):
    j, rep = job(tmp_path, remote, EditAgent(None, ok=False))
    assert j.run() == 1 and "did not finish successfully" in rep.reports[-1][2]


def test_starter_pack_refusal_fails_closed(tmp_path, remote):
    class Refused(Exception):
        code = "AIG_E_FIDDLER_UNCONFIGURED"

    def init(env, tracing):
        assert env["AIG_PLATFORM_API_URL"] == "http://relay.test/platform"
        assert env["AIG_PLATFORM_API_TOKEN"].startswith("aigws1.")
        raise Refused("AIG_FIDDLER_URL missing")

    j, rep = job(tmp_path, remote, EditAgent("x"))
    j._sdk_init = init
    assert j.run() == 1
    assert "AIG_E_FIDDLER_UNCONFIGURED" in rep.reports[-1][2]


def test_clone_failure(tmp_path, remote):
    j, rep = job(tmp_path, remote, EditAgent("x"), GIT_CONFIG_VALUE_0="https://nowhere.example.com/")
    assert j.run() == 1 and rep.reports[-1][2].startswith("git clone:")


def test_push_failure_after_tests_pass(tmp_path, remote):
    os.chmod(remote / "aig" / "demo.git" / "refs" / "heads", 0o500)  # read-only remote
    try:
        j, rep = job(tmp_path, remote, EditAgent("def add(a, b):\n    return a + b\n"))
        assert j.run() == 1
        assert [r[0] for r in rep.reports] == ["running", "testing", "failed"]
        assert rep.reports[-1][2].startswith("push:")
    finally:
        os.chmod(remote / "aig" / "demo.git" / "refs" / "heads", 0o755)


def test_missing_env_exits():
    with pytest.raises(SystemExit):
        JobConfig.from_env({})
