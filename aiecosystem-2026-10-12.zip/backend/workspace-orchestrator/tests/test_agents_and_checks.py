"""Code agents (fake Claude Code CLI), Portkey env wiring, test detection, scrubbing."""

from __future__ import annotations

import json
import os
import stat
import sys
import textwrap

import pytest

from workspace_orchestrator.job import build_prompt, child_env, pr_body
from workspace_orchestrator.job import Outcome
from workspace_orchestrator.job.agents import (
    AgentContext,
    ClaudeAgentSdkAgent,
    ClaudeCodeAgent,
    CommandAgent,
    build_agent,
    claude_env,
    gateway_root,
    parse_stream_result,
)
from workspace_orchestrator.job.checks import StepResult, detect_setup, detect_tests
from workspace_orchestrator.job.github import RepoRef
from workspace_orchestrator.scrub import Scrubber

PK = "pk-team-SUPERSECRET-abcdef0123"
HEADERS = {"x-portkey-api-key": PK, "x-portkey-config": "pc-aig-router",
           "x-portkey-metadata": '{"agent_id":"workspace.claims-ai","env":"workspace","host":"ecs","job_profile":"claims","team":"claims-ai","user_tier":"standard"}',
           "x-portkey-trace-id": "0af7651916cd43dd8448eb211c80319c"}

FAKE_CLAUDE = textwrap.dedent("""\
    #!{python}
    import json, os, sys
    out = os.environ["FAKE_OUT"]
    json.dump({{"argv": sys.argv[1:], "env": {{k: v for k, v in os.environ.items()
               if k.startswith(("ANTHROPIC", "CLAUDE", "DISABLE", "TRACEPARENT", "GITHUB", "AIG"))}}}}, open(out, "w"))
    open("fixed.txt", "w").write("ok")
    print(json.dumps({{"type": "system", "subtype": "init"}}))
    print(json.dumps({{"type": "assistant", "message": {{"content": [{{"type": "tool_use", "name": "Edit"}}]}}}}))
    print(json.dumps({{"type": "result", "subtype": os.environ.get("FAKE_SUBTYPE", "success"), "is_error": False,
                      "result": "Fixed it. key=" + os.environ.get("ANTHROPIC_AUTH_TOKEN", ""), "num_turns": 4,
                      "total_cost_usd": 0.12, "session_id": "s1"}}))
""")


@pytest.fixture
def fake_claude(tmp_path):
    path = tmp_path / "claude"
    path.write_text(FAKE_CLAUDE.format(python=sys.executable))
    path.chmod(path.stat().st_mode | stat.S_IEXEC)
    return path


def test_gateway_root():
    assert gateway_root("https://portkey.corp/v1") == "https://portkey.corp"
    assert gateway_root("https://portkey.corp/v1/") == "https://portkey.corp"
    assert gateway_root("https://portkey.corp/gw") == "https://portkey.corp/gw"


def test_claude_env_points_claude_code_at_portkey():
    env = claude_env({"PATH": "/bin", "ANTHROPIC_API_KEY": "sk-ant-raw"}, portkey_base_url="https://portkey.corp/v1",
                     portkey_headers=HEADERS, traceparent="00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01")
    assert "ANTHROPIC_API_KEY" not in env  # never a provider key
    assert env["ANTHROPIC_BASE_URL"] == "https://portkey.corp"
    assert env["ANTHROPIC_AUTH_TOKEN"] == PK
    # Claude Code splits ANTHROPIC_CUSTOM_HEADERS on "\n" and each line on the first ":".
    parsed = dict(line.split(":", 1) for line in env["ANTHROPIC_CUSTOM_HEADERS"].split("\n"))
    assert {k.strip(): v.strip() for k, v in parsed.items()} == HEADERS
    assert env["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] == "1" and env["TRACEPARENT"].startswith("00-0af76519")


def test_claude_code_agent_runs_cli_headless(tmp_path, fake_claude):
    repo = tmp_path / "repo"
    repo.mkdir()
    out = tmp_path / "seen.json"
    beats = []
    env = claude_env({"PATH": os.environ["PATH"], "FAKE_OUT": str(out)}, portkey_base_url="https://portkey.corp/v1",
                     portkey_headers=HEADERS)
    agent = ClaudeCodeAgent(binary=str(fake_claude), max_budget_usd="5")
    scrub = Scrubber([PK])
    res = agent.run(AgentContext(cwd=str(repo), prompt="Fix #12", env=env, timeout=30, scrub=scrub,
                                 on_activity=lambda: beats.append(1)))
    assert res.ok and res.turns == 4 and res.cost_usd == 0.12
    assert PK not in res.summary and "***" in res.summary
    seen = json.load(open(out))
    argv = seen["argv"]
    assert argv[:2] == ["-p", "Fix #12"]
    assert argv[argv.index("--output-format") + 1] == "stream-json" and "--verbose" in argv
    assert argv[argv.index("--permission-mode") + 1] == "bypassPermissions"
    assert argv[argv.index("--max-budget-usd") + 1] == "5"
    assert argv[-3:] == ["--disallowedTools", "WebFetch", "WebSearch"]
    assert seen["env"]["ANTHROPIC_BASE_URL"] == "https://portkey.corp"
    assert not any(k.startswith("GITHUB") for k in seen["env"])
    assert len(beats) == 3 and (repo / "fixed.txt").exists()


def test_claude_code_agent_error_result(tmp_path, fake_claude):
    (tmp_path / "r").mkdir()
    env = {"PATH": os.environ["PATH"], "FAKE_OUT": str(tmp_path / "o"), "FAKE_SUBTYPE": "error_max_turns"}
    res = ClaudeCodeAgent(binary=str(fake_claude)).run(AgentContext(str(tmp_path / "r"), "x", env, 30, Scrubber()))
    assert not res.ok


def test_claude_code_agent_without_result(tmp_path):
    (tmp_path / "r").mkdir()
    res = ClaudeCodeAgent(binary="false").run(AgentContext(str(tmp_path / "r"), "x", {"PATH": os.environ["PATH"]}, 30, Scrubber()))
    assert not res.ok and "without a result" in res.summary


def test_command_agent_and_builder(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    agent = build_agent({"AIG_WS_CODE_AGENT": "command", "AIG_WS_AGENT_COMMAND": "cat \"$AIG_WS_PROMPT_FILE\" > p.txt"})
    assert isinstance(agent, CommandAgent)
    res = agent.run(AgentContext(str(repo), "do it", {"PATH": os.environ["PATH"]}, 30, Scrubber()))
    assert res.ok and (repo / "p.txt").read_text() == "do it"
    assert isinstance(build_agent({}), ClaudeCodeAgent)
    assert isinstance(build_agent({"AIG_WS_CODE_AGENT": "claude-sdk"}), ClaudeAgentSdkAgent)
    with pytest.raises(ValueError):
        build_agent({"AIG_WS_CODE_AGENT": "command"})
    with pytest.raises(ValueError):
        build_agent({"AIG_WS_CODE_AGENT": "gpt"})


def test_claude_agent_sdk_options_match_installed_package():
    """The SDK agent only uses options the installed claude-agent-sdk declares."""
    import dataclasses

    from claude_agent_sdk import ClaudeAgentOptions

    names = {f.name for f in dataclasses.fields(ClaudeAgentOptions)}
    assert {"cwd", "env", "permission_mode", "model", "cli_path", "disallowed_tools", "max_budget_usd"} <= names


def test_parse_stream_result():
    assert parse_stream_result(["noise", '{"type":"assistant"}', '{"type":"result","subtype":"success"}'])["subtype"] == "success"
    assert parse_stream_result(["{bad", "x"]) is None


def test_child_env_drops_secrets():
    env = child_env({"PATH": "/bin", "AIG_PORTKEY_API_KEY": "k", "GITHUB_TOKEN": "t", "AIG_WS_STATUS_TOKEN": "s",
                     "GITHUB_APP_PRIVATE_KEY": "p", "AIG_FIDDLER_API_KEY": "f", "AIG_TEAM": "claims-ai",
                     "SOME_PASSWORD": "x", "GIT_CONFIG_COUNT": "1"})
    assert env == {"PATH": "/bin", "AIG_TEAM": "claims-ai", "GIT_CONFIG_COUNT": "1"}


def test_prompt_and_pr_body():
    ws = {"id": "w1", "work_item": "#12", "title": "Fix rounding", "description": "off by a cent",
          "requested_by": "jane@example.com", "team": "claims-ai"}
    repo = RepoRef("github.com", "aig", "claims")
    prompt = build_prompt(ws, "aig/ws-w1", repo, previous_failure="assert 1 == 2")
    assert "Fix rounding" in prompt and "off by a cent" in prompt and "assert 1 == 2" in prompt
    assert "Do not commit" in prompt
    from workspace_orchestrator.job.agents import AgentResult

    outcome = Outcome(agent=AgentResult(True, f"done ghp_{'x' * 36}", 0.5, 3),
                      steps=[StepResult("unit tests", "pytest", True), StepResult("evals", None, True, skipped=True, output="no aig-eval.yaml")],
                      trace_id="abc123", attempts=1)
    body = pr_body(ws, repo, outcome, {"AIG_AGENT_ID": "workspace.claims-ai", "AIG_FIDDLER_PROJECT": "aig-dev"}, Scrubber())
    assert body.startswith("## Fix rounding") and "Fixes #12" in body
    assert "- unit tests: passed (`pytest`)" in body and "evals: skipped (no aig-eval.yaml)" in body
    assert "`abc123`" in body and "ghp_" not in body and "human" in body


def test_detection(tmp_path):
    assert detect_tests(str(tmp_path)) is None and detect_setup(str(tmp_path), "/v") is None
    (tmp_path / "package.json").write_text(json.dumps({"scripts": {"test": "echo \"Error: no test specified\" && exit 1"}}))
    assert detect_tests(str(tmp_path)) is None
    assert detect_setup(str(tmp_path), "/v").startswith("npm install")
    (tmp_path / "package-lock.json").write_text("{}")
    (tmp_path / "package.json").write_text(json.dumps({"scripts": {"test": "vitest run"}}))
    assert detect_tests(str(tmp_path)) == "npm test --silent" and detect_setup(str(tmp_path), "/v").startswith("npm ci")
    py = tmp_path / "py"
    py.mkdir()
    (py / "pyproject.toml").write_text("[project]\nname='x'\n")
    assert detect_tests(str(py)) == "python -m pytest -q" and "pip install -q -e '.[dev]'" in detect_setup(str(py), "/v")
    (py / "pom.xml").write_text("<project/>")
    assert detect_tests(str(py)) == "mvn -B -q test"


def test_scrubber_patterns():
    s = Scrubber(["my-registered-secret-value"])
    pk = "pk" + "-123456789"
    text = ("x my-registered-secret-value ghs_abcdefghijklmnopqrstuvwxyz0123 Bearer abcdefghijklmnop "
            f"https://user:pass@github.com/a x-portkey-api-key: {pk} aigws1.0123456789abcdef0123 "
            "-----BEGIN RSA PRIVATE KEY-----\nMIIE\n-----END RSA PRIVATE KEY----- api_key=abcdef123")
    out = s(text)
    for leaked in ("my-registered", "ghs_", "abcdefghijklmnop", "user:pass", "pk-123456789", "aigws1.0", "MIIE", "abcdef123"):
        assert leaked not in out, leaked
    assert s("short ok") == "short ok"
