"""The workspace image pins the starter pack at infra/ci/image-check/pins.json and runs non-root."""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
WS = (ROOT / "infra" / "ci" / "docker" / "workspace.Dockerfile").read_text()
ORCH = (ROOT / "backend" / "workspace-orchestrator" / "Dockerfile").read_text()


def test_workspace_image_pins_starter_pack():
    pins = json.loads((ROOT / "infra" / "ci" / "image-check" / "pins.json").read_text())["sdk"]
    versions = set(re.findall(r"ARG AIG_SDK_VERSION=(\S+)", WS))
    assert versions == {pins["aig-sdk"]} == {pins["@aig/sdk"]}
    assert re.search(r"ARG CLAUDE_CODE_VERSION=\d+\.\d+\.\d+", WS)  # exact version, never "latest"


def test_workspace_image_hardening():
    assert "USER 10001" in WS and 'ENTRYPOINT ["/usr/bin/tini", "--", "workspace-job"]' in WS
    assert "AIG_ENV=workspace" in WS and "AIG_HOST=ecs" in WS
    for forbidden in ("ANTHROPIC_API_KEY", "AIG_PORTKEY_API_KEY=", "GITHUB_TOKEN="):
        assert forbidden not in WS.split("LABEL")[0] + WS.split("ENV PATH")[1]
    assert "USER 10001" in ORCH and "workspace-orchestrator" in ORCH
