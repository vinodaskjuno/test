"""Config rules, signed notifications, LocalProcessRunner, platform client."""

from __future__ import annotations

import json
import sys
import time

import httpx
import pytest
import respx
from conftest import NOTIFY_SECRET, SERVICE_TOKEN, base_env

from workspace_orchestrator.config import ConfigError, OrchestratorConfig, workspace_agent_id
from workspace_orchestrator.notify import Notifier, sign, verify
from workspace_orchestrator.platform import ClaimConflict, PlatformClient, PlatformError
from workspace_orchestrator.runners.base import JobSpec
from workspace_orchestrator.runners.local import LocalProcessRunner, read_env_file


def test_defaults_and_rules():
    cfg = OrchestratorConfig.from_env(base_env())
    assert cfg.idle_timeout_seconds == 30 * 60 and cfg.max_runtime_seconds == 120 * 60
    assert cfg.runner == "local" and cfg.relay_public_url == "http://127.0.0.1:8090"
    assert SERVICE_TOKEN not in repr(cfg)
    assert OrchestratorConfig.from_env(base_env(AIG_WS_IDLE_TIMEOUT_MINUTES="5")).idle_timeout_seconds == 300
    with pytest.raises(ConfigError, match="only allowed with AIG_ENV=local"):
        OrchestratorConfig.from_env(base_env(AIG_ENV="prod", AIG_WS_RUNNER="local"))
    with pytest.raises(ConfigError, match="RELAY_SECRET"):
        OrchestratorConfig.from_env(base_env(AIG_ENV="dev", AIG_WS_RELAY_SECRET="__REPLACE_ME__"))
    with pytest.raises(ConfigError, match="SERVICE_TOKEN"):
        OrchestratorConfig.from_env(base_env(AIG_PLATFORM_SERVICE_TOKEN="__REPLACE_ME_TOKEN__"))
    with pytest.raises(ConfigError, match="NOTIFY_SECRET"):
        OrchestratorConfig.from_env(base_env(AIG_WS_NOTIFY_URLS="http://bot/api/notify"))
    with pytest.raises(ConfigError, match="number"):
        OrchestratorConfig.from_env(base_env(AIG_WS_IDLE_TIMEOUT_MINUTES="soon"))
    local = OrchestratorConfig.from_env({k: v for k, v in base_env().items() if k != "AIG_WS_RELAY_SECRET"})
    assert len(local.relay_secret) == 64  # random per process in local
    passthrough = OrchestratorConfig.from_env(base_env(AIG_PORTKEY_BASE_URL="https://pk/v1", AIG_PORTKEY_API_KEY="pk-x"))
    assert passthrough.job_env == {"AIG_PORTKEY_BASE_URL": "https://pk/v1"}  # keys are never passed through
    assert workspace_agent_id("claims-ai") == "workspace.claims-ai" and len(workspace_agent_id("t" * 64)) == 64


def test_sign_verify():
    body = b'{"a":1}'
    sig = sign(NOTIFY_SECRET, "1700000000", body)
    assert verify(NOTIFY_SECRET, "1700000000", body, sig, now=1700000100)
    assert not verify(NOTIFY_SECRET, "1700000000", body, sig, now=1700001000)  # too old
    assert not verify(NOTIFY_SECRET, "1700000000", b'{"a":2}', sig, now=1700000000)
    assert not verify("other", "1700000000", body, sig, now=1700000000)
    assert not verify(NOTIFY_SECRET, "x", body, sig)


@respx.mock
def test_notifier_posts_signed_payload():
    route = respx.post("http://bot.test/api/notify").mock(return_value=httpx.Response(202))
    respx.post("http://down.test/api/notify").mock(side_effect=httpx.ConnectError("down"))
    n = Notifier(["http://bot.test/api/notify", "http://down.test/api/notify"], NOTIFY_SECRET)
    n.workspace_changed({"id": "w1", "status": "pr_opened", "pr_url": "https://x/pull/1", "description": "long"})
    req = route.calls[0].request
    payload = json.loads(req.content)
    assert payload["event"] == "workspace.status" and payload["workspace"]["status"] == "pr_opened"
    assert "description" not in payload["workspace"]
    assert verify(NOTIFY_SECRET, req.headers["x-aig-timestamp"], req.content, req.headers["x-aig-signature"])
    Notifier([], None).workspace_changed({"id": "x"})  # disabled: no-op


@respx.mock
def test_platform_client():
    base = "http://platform.test"
    c = PlatformClient(base, SERVICE_TOKEN)
    lst = respx.get(f"{base}/api/v1/workspaces").mock(return_value=httpx.Response(200, json={"items": [
        {"id": "b", "created_at": "2"}, {"id": "a", "created_at": "1"}], "total": 2}))
    assert [w["id"] for w in c.list_queued()] == ["a", "b"]
    assert lst.calls[0].request.headers["x-aig-service-token"] == SERVICE_TOKEN
    assert lst.calls[0].request.url.params["status"] == "queued"
    respx.post(f"{base}/api/v1/workspaces/a/claim").mock(return_value=httpx.Response(
        409, json={"error": {"code": "invalid_transition", "message": "workspace is provisioning"}}))
    with pytest.raises(ClaimConflict):
        c.claim("a", "w1")
    respx.get(f"{base}/api/v1/workspaces/z").mock(return_value=httpx.Response(404))
    assert c.get_workspace("z") is None
    patch = respx.patch(f"{base}/api/v1/workspaces/a/status").mock(return_value=httpx.Response(200, json={"id": "a"}))
    c.update_status("a", "failed", error="x" * 5000, log_url="https://logs")
    sent = json.loads(patch.calls[0].request.content)
    assert len(sent["error"]) == 4000 and sent["log_url"] == "https://logs" and "pr_url" not in sent
    agents = respx.post(f"{base}/api/v1/agents").mock(side_effect=[httpx.Response(201, json={}), httpx.Response(409, json={}),
                                                                   httpx.Response(403, json={"error": {"code": "forbidden"}})])
    assert c.ensure_agent("workspace.t", team="t", owner="o@example.com", description="d") is True
    assert c.ensure_agent("workspace.t", team="t", owner="o@example.com", description="d") is False
    with pytest.raises(PlatformError, match="forbidden"):
        c.ensure_agent("workspace.t", team="t", owner="o@example.com", description="d")
    assert json.loads(agents.calls[0].request.content)["owner"] == "o@example.com"


def test_local_runner_lifecycle(tmp_path):
    runner = LocalProcessRunner(base_dir=str(tmp_path), command=[sys.executable, "-c",
        "import os,time; print(os.environ['WORKSPACE_ID'], os.environ.get('SECRET_X'), 'HOME' in os.environ);"
        "time.sleep(float(os.environ.get('SLEEP', '0')))"], stop_grace_seconds=2)
    h = runner.start(JobSpec("w1", "t", env={"WORKSPACE_ID": "w1"}, secret_env={"SECRET_X": "s3cr3t"}))
    for _ in range(100):
        if not runner.poll(h).running:
            break
        time.sleep(0.05)
    log = open(h.data["log"]).read()
    assert "w1 s3cr3t True" in log
    assert runner.find("w1") is None
    slow = runner.start(JobSpec("w2", "t", env={"WORKSPACE_ID": "w2", "SLEEP": "60"}))
    assert runner.poll(slow).running
    runner.stop(slow, "test")
    assert not runner.poll(slow).running


def test_local_runner_does_not_inherit_orchestrator_secrets(tmp_path, monkeypatch):
    monkeypatch.setenv("AIG_PLATFORM_SERVICE_TOKEN", SERVICE_TOKEN)
    runner = LocalProcessRunner(base_dir=str(tmp_path), command=[sys.executable, "-c",
        "import os; print(sorted(k for k in os.environ if 'TOKEN' in k))"])
    h = runner.start(JobSpec("w3", "t", env={}))
    while runner.poll(h).running:
        time.sleep(0.05)
    assert "AIG_PLATFORM_SERVICE_TOKEN" not in open(h.data["log"]).read()


def test_read_env_file(tmp_path):
    p = tmp_path / ".env"
    p.write_text('# c\nexport A="1"\nB=two\nKEY=line1\\nline2\n\nbad\n')
    assert read_env_file(p) == {"A": "1", "B": "two", "KEY": "line1\nline2"}
