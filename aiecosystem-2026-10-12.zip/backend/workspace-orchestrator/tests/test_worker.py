"""Worker loop: claim/dispatch, idle timeout, max runtime, cancel, exits, recovery, notifications."""

from __future__ import annotations

from conftest import SERVICE_TOKEN, Clock, FakePlatform, FakeRunner, RecordingNotifier, with_cfg, workspace

from workspace_orchestrator.relay import verify_token
from workspace_orchestrator.runners.base import TaskHandle, TaskState
from workspace_orchestrator.worker import Worker


LOCAL_PK = "pk-local-SECRET-123456"


def make(cfg, *wss, **kw):
    platform, runner, clock, notifier = FakePlatform(*wss), FakeRunner(), Clock(), RecordingNotifier()
    worker = Worker(with_cfg(cfg, **kw), platform, runner, notifier=notifier, clock=clock,
                    secret_env={"AIG_PORTKEY_API_KEY": LOCAL_PK})
    return worker, platform, runner, clock, notifier


def test_claims_oldest_first_and_dispatches_with_job_env(cfg):
    old = workspace(created_at="2026-10-09T09:00:00Z")
    new = workspace(created_at="2026-10-09T11:00:00Z", requested_by="bob@example.com", team="uw-ai")
    w, p, r, clock, n = make(cfg, new, old, max_concurrent=1)
    w.tick()
    assert [c[1] for c in p.calls if c[0] == "claim"] == [old["id"]]
    assert p.ws[old["id"]]["status"] == "provisioning" and p.ws[new["id"]]["status"] == "queued"
    spec = r.started[0]
    assert spec.env["WORKSPACE_ID"] == old["id"] and spec.env["REPO_URL"] == old["repo_url"]
    assert spec.env["WORK_ITEM"] == "#12" and spec.env["JOB_PROFILE"] == "claims"
    assert spec.env["AIG_AGENT_ID"] == "workspace.claims-ai" and spec.env["AIG_ENV"] == "workspace"
    assert spec.env["AIG_HOST"] == "ecs" and spec.env["AIG_USER"] == "jane@example.com"
    assert spec.env["AIG_WS_STATUS_URL"].endswith(f"/relay/v1/workspaces/{old['id']}")
    assert verify_token(cfg.relay_secret, old["id"], spec.secret_env["AIG_WS_STATUS_TOKEN"])
    assert spec.secret_env["AIG_PORTKEY_API_KEY"].startswith("pk-local")
    assert SERVICE_TOKEN not in str(spec.env) + str(spec.secret_env)  # the service token never reaches a job
    assert p.agents["workspace.claims-ai"]["owner"] == "jane@example.com"
    assert p.ws[old["id"]]["log_url"] == f"https://logs.example.com/ws/{old['id']}"
    assert (old["id"], "provisioning") in n.events
    # capacity reached: the second request waits
    w.tick()
    assert len(r.started) == 1
    r.exit(w.tracked[old["id"]].handle.id, 1)
    w.tick()
    assert [s.workspace_id for s in r.started] == [old["id"], new["id"]]


def test_claim_conflict_is_skipped(cfg):
    a, b = workspace(created_at="1"), workspace(created_at="2")
    w, p, r, *_ = make(cfg, a, b)
    p.steal.add(a["id"])
    w.tick()
    assert [s.workspace_id for s in r.started] == [b["id"]]
    assert a["id"] not in w.tracked


def test_agent_registration_uses_configured_owner_once(cfg):
    a, b = workspace(), workspace()
    w, p, *_ = make(cfg, a, b, agent_owner="aig-platform@example.com")
    w.tick()
    ensures = [c for c in p.calls if c[0] == "ensure_agent"]
    assert ensures == [("ensure_agent", "workspace.claims-ai", "claims-ai", "aig-platform@example.com")]


def test_start_failure_marks_failed_and_scrubs(cfg):
    a = workspace()
    w, p, r, _, n = make(cfg, a)
    r.fail_start = True
    w.tick()
    assert p.ws[a["id"]]["status"] == "failed"
    assert "could not start" in p.ws[a["id"]]["error"] and SERVICE_TOKEN not in p.ws[a["id"]]["error"]
    assert (a["id"], "failed") in n.events and not w.tracked


def test_exit_after_pr_opened_completes(cfg):
    a = workspace()
    w, p, r, _, n = make(cfg, a)
    w.tick()
    p.update_status(a["id"], "running")
    w.tick()  # sees the change made through another path -> notifies
    assert (a["id"], "running") in n.events
    p.update_status(a["id"], "pr_opened", pr_url="https://github.example.com/aig/claims-triage/pull/3")
    r.exit(w.tracked[a["id"]].handle.id, 0)
    w.tick()
    assert p.ws[a["id"]]["status"] == "completed" and not w.tracked
    assert n.events[-1] == (a["id"], "completed")


def test_exit_without_pr_fails(cfg):
    a = workspace()
    w, p, r, *_ = make(cfg, a)
    w.tick()
    r.exit(w.tracked[a["id"]].handle.id, 137)
    w.tick()
    assert p.ws[a["id"]]["status"] == "failed" and "exit code 137" in p.ws[a["id"]]["error"]


def test_job_reported_failure_is_kept_and_task_stopped(cfg):
    a = workspace()
    w, p, r, *_ = make(cfg, a)
    w.tick()
    p.update_status(a["id"], "failed", error="tests: still failing")
    w.tick()
    assert r.stopped and p.ws[a["id"]]["error"] == "tests: still failing" and not w.tracked


def test_idle_timeout_stops_and_fails(cfg):
    a = workspace()
    w, p, r, clock, _ = make(cfg, a, idle_timeout_seconds=1800)
    w.tick()
    clock.advance(1700)
    w.record_activity(a["id"])  # relay call (heartbeat) resets the idle clock
    clock.advance(1700)
    w.tick()
    assert not r.stopped
    clock.advance(200)
    w.tick()
    assert r.stopped[0][1] == "idle timeout"
    assert p.ws[a["id"]]["status"] == "failed" and "idle timeout" in p.ws[a["id"]]["error"]
    assert "30 min" in p.ws[a["id"]]["error"]


def test_idle_after_pr_opened_completes(cfg):
    a = workspace()
    w, p, r, clock, _ = make(cfg, a, idle_timeout_seconds=60)
    w.tick()
    p.update_status(a["id"], "pr_opened", pr_url="https://x.example.com/pull/1")
    clock.advance(61)
    w.tick()
    assert r.stopped and p.ws[a["id"]]["status"] == "completed"


def test_max_runtime_stops_even_when_active(cfg):
    a = workspace()
    w, p, r, clock, _ = make(cfg, a, idle_timeout_seconds=600, max_runtime_seconds=3600)
    w.tick()
    for _ in range(8):
        clock.advance(500)
        w.record_activity(a["id"])
        w.tick()
    assert r.stopped[0][1] == "max runtime exceeded"
    assert p.ws[a["id"]]["status"] == "failed" and "max runtime" in p.ws[a["id"]]["error"]


def test_cancel_stops_the_task(cfg):
    a = workspace()
    w, p, r, _, n = make(cfg, a)
    w.tick()
    p.ws[a["id"]]["status"] = "cancelled"  # requester cancelled in platform-api
    w.tick()
    assert r.stopped[0][1] == "workspace cancelled by the requester"
    assert p.ws[a["id"]]["status"] == "cancelled" and not w.tracked
    assert (a["id"], "cancelled") in n.events


def test_deleted_workspace_stops_the_task(cfg):
    a = workspace()
    w, p, r, *_ = make(cfg, a)
    w.tick()
    del p.ws[a["id"]]
    w.tick()
    assert r.stopped and not w.tracked


def test_recover_adopts_running_tasks_and_fails_lost_ones(cfg):
    running = workspace(status="running")
    lost = workspace(status="testing")
    opened = workspace(status="pr_opened")
    w, p, r, *_ = make(cfg, running, lost, opened)
    r.found[running["id"]] = TaskHandle(id="task-x")
    r.states["task-x"] = TaskState(running=True)
    w.recover()
    assert running["id"] in w.tracked
    assert p.ws[lost["id"]]["status"] == "failed" and "lost" in p.ws[lost["id"]]["error"]
    assert p.ws[opened["id"]]["status"] == "completed"


def test_record_activity_updates_status(cfg):
    a = workspace()
    w, p, *_ = make(cfg, a)
    w.tick()
    w.record_activity(a["id"], status="testing")
    assert w.tracked[a["id"]].last_status == "testing"
    w.record_activity("unknown")  # ignored


def test_run_forever_stops(cfg):
    import threading

    w, *_ = make(cfg, recover=False)
    t = threading.Thread(target=w.run_forever)
    t.start()
    w.stop()
    t.join(5)
    assert not t.is_alive()
