# Error-code contract

## SDK fail-closed codes (`AIG_E_*`)

Both SDKs raise these codes (Python `AigStartupError` / `AigCallError` with `.code` and
`.field`; TypeScript `AigError` with `code` and `field`). Messages may differ, codes and fields
may not. `field` names the offending variable or metadata field, as in the fixtures. Error
messages never contain key values.

| Code | Raised by | Meaning | Remediation |
|---|---|---|---|
| `AIG_E_RAW_PROVIDER_KEY` | `init()`, every call | A provider key (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, ...) is set in the environment. `field` = the variable | Remove it. Provider keys live only in Portkey virtual keys; call models through the gateway |
| `AIG_E_PORTKEY_UNCONFIGURED` | `init()`, every call | `AIG_PORTKEY_BASE_URL` or `AIG_PORTKEY_API_KEY` missing, empty or a placeholder, or `AIG_PORTKEY_CONFIG` malformed | Set the variables (see env-vars.md); ask the platform team for a scoped workspace key |
| `AIG_E_PORTKEY_UNREACHABLE` | `init()`, `aig doctor` | Gateway did not answer (DNS, TLS, timeout, 5xx on the health probe) | Check VPN / device proxy / VPC egress allow-list and the base URL |
| `AIG_E_FIDDLER_UNCONFIGURED` | `init()`, every call | `AIG_FIDDLER_URL`, `AIG_FIDDLER_API_KEY` or `AIG_FIDDLER_PROJECT` missing or a placeholder | Set them. There is no way to run without Fiddler |
| `AIG_E_FIDDLER_UNREACHABLE` | `init()`, `aig doctor` | Fiddler (or the OTLP endpoint) did not answer or rejected the token | Check network egress and the token's scope |
| `AIG_E_PLATFORM_API_UNCONFIGURED` | `init()` | `AIG_PLATFORM_API_URL` missing or a placeholder, so registration cannot be verified | Set it to the environment's platform-api URL |
| `AIG_E_PLATFORM_API_UNREACHABLE` | `init()`, `aig doctor`, `aig init` | platform-api did not answer, answered 5xx, refused `AIG_PLATFORM_API_TOKEN` (401/403, `field` = `AIG_PLATFORM_API_TOKEN`) or has no registration endpoint: registration cannot be verified, so the agent does not start | Check network access to platform-api and the token |
| `AIG_E_AGENT_ID_MISSING` | `init()`, every call | `AIG_AGENT_ID` not set | Register the agent (`aig init`) and set `AIG_AGENT_ID` |
| `AIG_E_AGENT_UNREGISTERED` | `init()`, gateway (webhook guardrail) | The agent id is unknown to the platform-api registry, or suspended (for example by the daily reconciliation) | Register it with `aig init`, or ask the owner / platform team to reinstate it |
| `AIG_E_METADATA_INVALID` | `init()`, every call | A metadata field is missing or outside its enum/pattern (`field` = `user_tier`, `job_profile`, `agent_id`, `team`, `env`, `host` or `user`). `init()` also uses `field` = `team` when the registry says a non-shared agent belongs to another team (the gateway would deny it as `team_mismatch`) | Fix the variable or call option; see metadata.schema.json |
| `AIG_E_MCP_UNREGISTERED` | MCP client | The MCP server is not registered in the Portkey MCP gateway (or its registry cannot be read), a direct server URL was given, or `AIG_PORTKEY_MCP_URL` is unset (`field` = `AIG_PORTKEY_MCP_URL`; otherwise no field) | Request the server in the MCP registry; connect only via the MCP gateway |
| `AIG_E_GATEWAY_REJECTED` | every call | Portkey refused the call (required metadata missing, guardrail deny, budget or rate limit). Carries the upstream status and trace id | Read the Portkey log for the trace id; fix metadata or ask for budget |

Precedence of the offline checks: `AIG_E_RAW_PROVIDER_KEY`, `AIG_E_PORTKEY_UNCONFIGURED`,
`AIG_E_FIDDLER_UNCONFIGURED`, `AIG_E_PLATFORM_API_UNCONFIGURED`, `AIG_E_AGENT_ID_MISSING`,
`AIG_E_METADATA_INVALID`. Network checks follow: `AIG_E_PORTKEY_UNREACHABLE`, `AIG_E_FIDDLER_UNREACHABLE`,
`AIG_E_PLATFORM_API_UNREACHABLE` / `AIG_E_AGENT_UNREGISTERED`, then `AIG_E_FIDDLER_UNCONFIGURED`
(`field` = `AIG_FIDDLER_APPLICATION_ID`) when no Fiddler application is known.

## platform-api codes (already in use)

HTTP errors use `{"error": {"code": "...", "message": "..."}}`. The LLM proxy also returns
`x-aig-trace-id`.

| Code | HTTP | Where | Meaning |
|---|---|---|---|
| `unauthenticated` | 401 | all Bearer endpoints; WS close 4401 | Missing or invalid bearer token (WS: `Authorization` header or the `aig.bearer` subprotocol token) |
| `forbidden` | 403 | Phase 4 portal endpoints (agents PATCH/suspend/reinstate, MCP approve/reject, model transitions/scorecard, audit, workspace status, evals POST) | The caller lacks the role (`admin`, `approver` or `service`) or is not the agent's owner |
| `forbidden_origin` | WS close 4403 | `/api/v1/ws` | Browser `Origin` not in `cors_allowed_origins` / `web_allowed_origins` |
| `portkey_key_not_configured` | 503 | LLM proxy, WS chat | `PORTKEY_API_KEY` missing or placeholder (only possible in `local`) |
| `portkey_gateway_not_configured` | 503 | LLM proxy, WS chat | Gateway URL still a placeholder |
| `invalid_job_profile` | 400 | LLM proxy, WS chat, `POST /api/v1/workspaces` | Job profile not in `allowed_job_profiles` |
| `invalid_user_tier` | 400 | `POST /api/v1/routing/test` | Tier override is not premium, standard or free |
| `invalid_cost_mode` | 400 | `POST /api/v1/routing/test` | Cost-mode override is not economy, balanced or quality |
| `invalid_usage_state` | 400 | `POST /api/v1/routing/test` | Usage-state override is not normal, soft or hard |
| `invalid_agent_id` | 400 | LLM proxy, WS chat, `POST /api/v1/agents`, `POST /api/v1/evals` | Agent id does not match `[A-Za-z0-9._-]{1,64}` |
| `invalid_json` | 400 | LLM proxy, every JSON body endpoint | Body is not JSON |
| `invalid_request` | 400 | LLM proxy, every endpoint with a body or query parameters | Body is not a JSON object, or a field / query parameter is missing or outside its type, enum or range (FastAPI validation is mapped to this code; there are no 422 responses) |
| `upstream_error` | upstream status | WS chat (`status` field) | Portkey answered with an error status (HTTP relays the upstream status and body unchanged) |
| `upstream_timeout` | 504 | LLM proxy, usage, WS | Portkey timed out (also sent in-band in a stream) |
| `upstream_unavailable` | 502 | LLM proxy, usage, WS | Portkey unreachable |
| `upstream_interrupted` | in-band | LLM proxy stream, WS chat | Upstream stream broke mid-way |
| `usage_forbidden` | 502 | `/api/v1/usage/*`, WS `usage` | Portkey refused the analytics request (the admin key lacks analytics read permission) |
| `usage_not_configured` | 501 | `/api/v1/usage/*` (incl. `by-team`), WS `usage.error` | No `PORTKEY_ADMIN_API_KEY` (there is never sample data) |
| `usage_upstream_error` | 502 | `/api/v1/usage/*`, WS `usage.error` | Portkey analytics returned an error or unparseable data |
| `webhook_unauthenticated` | 401 | `/api/v1/guardrails/agent-check` | Missing or wrong `x-aig-webhook-secret` (compared in constant time) |
| `webhook_not_configured` | 503 | `/api/v1/guardrails/agent-check` | `PORTKEY_WEBHOOK_SECRET` missing or placeholder outside `local` |
| `service_unauthenticated` | 401 | `/api/v1/agents*` | Missing or wrong `x-aig-service-token` (compared in constant time) |
| `service_token_not_configured` | 503 | `/api/v1/agents*` | `PLATFORM_SERVICE_TOKEN` missing or placeholder (any env; service calls never run unauthenticated) |
| `agent_not_found` | 404 | `/api/v1/agents/{id}`, `.../suspend`, `.../reinstate` | Unknown agent id |
| `agent_exists` | 409 | `POST /api/v1/agents` | The agent id is already registered |
| `invalid_agent` | 400 | `POST /api/v1/agents` | Owner, team or status outside the contract |
| `registry_read_only` | 501 | `POST/PATCH /api/v1/agents*` | The configured registry implementation does not support changes |
| `mcp_server_not_found` | 404 | `/api/v1/mcp-servers/{id}/*` | Unknown MCP registry id |
| `mcp_server_exists` | 409 | `POST /api/v1/mcp-servers` | A pending or approved server already has this URL |
| `model_not_found` | 404 | `/api/v1/models/{id}*` | Unknown model catalog id |
| `model_exists` | 409 | `POST /api/v1/models` | Same provider, name and version already in the catalog |
| `invalid_transition` | 409 | MCP approve/reject, model transition/scorecard, workspace cancel/claim/status | The object's current status does not allow this change (e.g. approving a non-pending MCP server, `requested -> approved`, changing a final workspace, claiming a workspace that is no longer `queued`) |
| `approval_gate_failed` | 409 | `POST /api/v1/models/{id}/transition` with `to=approved` | Phase 7 approval gate: no scorecard, `passed=false`, an offline scorecard, or a requested tier misses its thresholds (`config/model-gate-thresholds.yaml`: accuracy/faithfulness delta vs the tier's current model, zero critical safety failures, latency limit, cost budget). The message lists every failure; the refusal is audit-logged (`model.approval_refused`). Nobody can bypass it, admins included |
| `dataset_classification_refused` | 400 | `PUT /api/v1/models/{id}/scorecard`; `aig-model eval` (exit 2, same code in the message) | Sandbox data policy: an eval dataset is not declared `synthetic` or `masked` (dataset sidecar `<file>.meta.yaml` or first-line header `# aig-data-classification: ...`) |
| `offline_scorecard_refused` | 400 | `PUT /api/v1/models/{id}/scorecard` | The scorecard comes from an `aig-model eval --offline` run (no Fiddler, no Portkey); offline results are never recorded |
| `workspace_not_found` | 404 | `/api/v1/workspaces/{id}*` | Unknown id, or a workspace of another user (existence is not revealed) |
| `routing_not_available` | 404 | `GET /api/v1/routing` | `AIG_ROUTING_CONFIG_FILE` unset, missing or unreadable |
| `method_not_allowed` | 405 | any path | HTTP method not supported on this path |
| `not_found` | 404 | `/auth/local/signin`, unknown paths | Local sign-in disabled (not `local` + `dev` auth), or no such route |
| `invalid_redirect_uri` | 400 | `/auth/local/signin` | Redirect is neither this extension's callback URI nor `<origin>/auth/callback` for an origin in `web_allowed_origins` |
| `invalid_state` | 400 | `/auth/local/signin` | Missing or malformed state |
| `form_too_large` | 413 | `/auth/local/signin` | Form body over the limit |
| `bad_request` | WS frame | `/api/v1/ws` | Malformed frame (binary, invalid JSON, unknown type, over 64 KiB, bad chat fields) |
| `duplicate_id` | WS `chat.error` | `/api/v1/ws` | A chat with this id is still running |
| `too_many_requests` | WS `chat.error` | `/api/v1/ws` | More than 4 concurrent chats on one socket |
| `cancelled` | WS `chat.error` | `/api/v1/ws` | Client cancelled the chat |
| `unknown_id` | WS `chat.error` | `/api/v1/ws` | Cancel for an id that is not running |
| `internal_error` | WS `chat.error` / `usage.error` | `/api/v1/ws` | Unexpected server failure (details only in server logs) |

Mapping for SDK users of platform-api (Phase 6 clients): `portkey_key_not_configured` and
`portkey_gateway_not_configured` correspond to `AIG_E_PORTKEY_UNCONFIGURED`;
`invalid_job_profile` and `invalid_agent_id` to `AIG_E_METADATA_INVALID`;
`upstream_unavailable` to `AIG_E_PORTKEY_UNREACHABLE`.

## Agent registry v2 and invocation codes (`agent-invocation.md`)

Same `{"error": {"code", "message"}}` envelope. In an SSE stream (`POST /api/v1/agents/{id}/invoke?mode=stream`)
the code arrives in an `error` event; on the WebSocket in an `agent.error` frame; on an invocation
record in `error_code`.

| Code | HTTP | Where | Meaning |
|---|---|---|---|
| `agent_not_invocable` | 409 | invoke, WS `agent.invoke` | The agent cannot run now: suspended, `draft` (only its owner/team, non-prod), `retired`, built-in, or no usable version (prod needs a verified, active version) |
| `agent_forbidden` | 403 | invoke, catalog detail, `GET /api/v1/invocations/{id}` | The caller is not allowed to run (or see) this agent: not the owner, not in its team, not in an allowed group, and the agent is not approved org-wide; also non-team callers asking for a dev/stage/local version |
| `org_approval_required` | 403 | invoke | The agent is shared org-wide but the platform-admin approval is `pending` or `rejected`, and the caller qualifies only through the org-wide visibility |
| `agent_unavailable` | 502 / 503 | invoke, verify | The agent server could not be reached or refused platform-api: connection error, DNS/TLS failure, HTTP 401/403/404 from the agent, 429 (503), AgentCore `ResourceNotFound`/`AccessDenied`/`Throttling`, or its auth secret cannot be resolved |
| `agent_error` | 502 | invoke (also in-band) | The agent answered 5xx (or another unexpected status), an `error` stream event, a 2xx body without `output`, or a stream that ended without `output`/`done` |
| `input_invalid` | 400 | invoke, verify, WS | The body has both or neither of `input`/`messages`, carries `aig_context` or an unknown key, an invalid `session_id`, or `input` does not validate against the version's `input_schema` (message names the first offending path); also an agent answering 400/422 |
| `invocation_timeout` | 504 | invoke (also in-band) | Sync call over `AIG_AGENT_SYNC_TIMEOUT_SECONDS` (120), stream over `AIG_AGENT_STREAM_TIMEOUT_SECONDS` (900), background over `AIG_AGENT_BACKGROUND_TIMEOUT_SECONDS` (3600), or the agent answered 408/504 |
| `invocation_cancelled` | in-band | stream `error` event, WS `agent.error`, record `error_code` | Cancelled by the caller (`POST /api/v1/invocations/{id}/cancel`, WS `agent.cancel`, closed connection) or by a platform-api restart (background runs) |
| `invocation_not_found` | 404 | `/api/v1/invocations/{id}*` | Unknown id, or an invocation the caller may not see (existence is not revealed) |
| `invocation_finished` | 409 | `POST /api/v1/invocations/{id}/cancel` | The invocation already ended |
| `version_not_found` | 404 | invoke (`version=`), verify, version routes | No such version of the agent in that environment (or it is retired) |
| `version_invalid` | 400 | `POST /api/v1/agents/{id}/versions` | Endpoint not `https://` (`http://localhost` only in `AIG_ENV=local`), env `local` outside `AIG_ENV=local`, malformed AgentCore runtime ARN or secret reference, `input_schema` / `output_schema` not a valid JSON Schema, or a kind/field combination outside the contract |
| `env_required` | 400 | verify, retire | The version exists in more than one environment; pass `env=` |
| `verification_required` | 409 | `POST /api/v1/agents/{id}/lifecycle` (`to=active`) | Activation needs at least one active version whose verification passed (or a deploy registration with `verified=true`) |
| `verification_failed` | (verify result) | `POST .../versions/{v}/verify` body `code`, version `verification.code` | Verification did not pass: health check, test invocation, gateway agent-check (`last_seen_at` not within `AIG_AGENT_VERIFY_SEEN_WINDOW_SECONDS`) or trace check failed. The endpoint answers 200 with `passed: false` and every check |
| `agent_invocation_disabled` | 503 | invoke, verify, WS | Agent invocation is off: `AGENT_CALLER_SIGNING_KEY` is not configured outside `local` (no unsigned invocations, ever) or `AIG_AGENT_INVOCATION=false` |
| `output_encryption_not_configured` | 503 | `mode=background` | `AGENT_OUTPUT_ENCRYPTION_KEY` missing or not a Fernet key outside `local` (background output is only ever stored encrypted) |
| `too_many_requests` | 429 | `mode=background`, WS `agent.error` | More than `AIG_AGENT_MAX_BACKGROUND_PER_USER` running background invocations, or more than 4 concurrent chats + agent runs on one socket |
| `caller_unauthenticated` | 401 (agent server) | an agent's `POST /invocations` | Agent side (serve helpers): `x-aig-caller` missing or invalid (signature, `iss`, `aud`, expiry). platform-api maps it to `agent_unavailable` |
| `invalid_transition` | 409 | lifecycle, access approve/reject | Lifecycle change not allowed (`draft -> active/retired`, `active <-> deprecated`, `active/deprecated -> retired`; `retired` is final), or approving/rejecting an agent whose org-wide approval is not `pending` |

Gateway impact (agent-check webhook): a `retired` agent is denied (`agent_retired`); a `draft`
agent passes only when platform-api runs with `AIG_ENV=local` or `dev` (developers run it before
the first deploy) and is denied elsewhere (`agent_draft`); `deprecated` agents still pass.

## Team workspace relay and Teams bot codes (Phase 6)

Same `{"error": {"code", "message"}}` shape.

| Code | HTTP | Where | Meaning |
|---|---|---|---|
| `workspace_unauthenticated` | 401 | orchestrator relay `/relay/v1/workspaces/{id}*` | Missing token, or a token of another workspace |
| `workspace_not_found` | 404 | relay | The workspace does not exist in platform-api |
| `workspace_closed` | 409 | relay | The workspace is final (completed, failed, cancelled); the job must exit |
| `forbidden` | 403 | relay `/platform/*` | Path outside the allow-list, or an agent of another team |
| `platform_unavailable` | 502 | relay | platform-api unreachable or 5xx |
| `invalid_request`, `invalid_json` | 400 | relay `/status` | Status outside `running`, `testing`, `pr_opened` (needs `pr_url`), `failed` |
| `notify_unauthenticated` | 401 | Teams bot `POST /api/notify` | Missing, stale (> 5 min) or wrong `x-aig-signature` |
| `notify_not_configured` | 503 | Teams bot `POST /api/notify` | `AIG_BOT_NOTIFY_SECRET` unset |

A failed workspace carries a human-readable `error` (`<step>: <message>` plus a scrubbed output
tail), e.g. `tests: tests still failing after 2 code agent attempt(s)`, `starter pack:
aig_sdk.init() refused to start (AIG_E_FIDDLER_UNCONFIGURED)`, `idle timeout: no activity for 30
min; workspace stopped`, `max runtime exceeded (120 min); workspace stopped`.

## Gateway guardrail verdicts (`POST /api/v1/guardrails/agent-check`)

Once authenticated the endpoint always answers HTTP 200 with Portkey's webhook shape
`{"verdict": true|false, "data": {"reason": "...", "message": "...", ...}}`. `verdict: false`
makes Portkey deny the call; SDKs then see `AIG_E_GATEWAY_REJECTED` (and `data.error` names
`AIG_E_AGENT_UNREGISTERED` for unknown or suspended agents).

| `data.reason` | Verdict | Meaning |
|---|---|---|
| `agent_active` | true | Agent registered, active and used by its team (or shared) |
| `metadata_missing` | false | No `x-portkey-metadata` in the webhook payload |
| `required_metadata_missing` | false | One of `user_tier`, `job_profile`, `agent_id`, `team` is missing (`data.missing`) |
| `invalid_agent_id` | false | `agent_id` outside `[A-Za-z0-9._-]{1,64}` |
| `agent_unregistered` | false | Unknown agent id (`AIG_E_AGENT_UNREGISTERED`) |
| `agent_suspended` | false | Agent suspended, e.g. by the daily reconciliation (`AIG_E_AGENT_UNREGISTERED`) |
| `team_mismatch` | false | A non-shared agent called with another team's metadata |
| `agent_retired` | false | Agent lifecycle is `retired` (`AIG_E_AGENT_UNREGISTERED`) |
| `agent_draft` | false | Agent lifecycle is `draft` and platform-api runs in `stage` or `prod` (drafts pass only in `local` and `dev`) (`AIG_E_AGENT_UNREGISTERED`) |
| `invalid_payload`, `payload_too_large`, `internal_error` | false | Fail-closed on malformed input or unexpected failure |

## `aig-model eval` exit codes (Phase 7, `backend/model-harness`)

| Exit | Meaning |
|---|---|
| `0` | Scorecard computed and every requested tier meets its gate thresholds (and, without `--offline`, the scorecard was recorded in platform-api) |
| `1` | Scorecard computed but the gate fails for at least one tier (still recorded unless `--offline`; approval will be refused with `approval_gate_failed`) |
| `2` | Nothing was judged: bad arguments or thresholds, `dataset_classification_refused`, `--offline` with `--post`, a model not in `sandbox`/`evaluating`, the sandbox key not created, Portkey / Fiddler / platform-api unconfigured or unreachable, a non-sandbox Portkey config requested |

## `aig eval` exit codes (Phase 5)

`aig eval run` (and the `@aig/sdk` `aig-eval` bin, which forwards it) exits with:

| Exit | Meaning | Evals gate |
|---|---|---|
| `0` | Every dataset passed its thresholds and the regression check against the baseline | passes |
| `1` | A score is below `min` / above `max`, regressed more than `max_regression` against the baseline, or has no successful value although a threshold or the baseline expects it | fails (blocks the merge when required) |
| `2` | Nothing was judged: invalid `aig-eval.yaml` / dataset / task / evaluator, `--offline` together with `--post`, `aig_sdk.init()` refused to start (the message carries its `AIG_E_*` code), Fiddler or platform-api unconfigured (`AIG_E_FIDDLER_UNCONFIGURED`, `AIG_E_PLATFORM_API_UNCONFIGURED`), unreachable or refusing, pinned baseline not found, `aig-sdk[evals]` not installed | fails |
| `127` | `aig-eval` (TypeScript bin) found no Python `aig` CLI | fails |

