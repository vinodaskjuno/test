"""Executable reference model of the AIG contract.

This is the normative behaviour that both SDKs (Python aig_sdk, TypeScript @aig/sdk) and
platform-api must reproduce. check_contracts.py runs every fixture in ../fixtures through it
and requires the result to equal the fixture's `expected` block exactly.

Pure, offline and dependency-free: network checks done by `init()` (Portkey/Fiddler
reachability, agent registration) are not modelled here; see errors.md for their codes.
"""

from __future__ import annotations

import json
import re
from typing import Any

GENERATED_UUID4 = "<generated:uuid4>"
SERVER_SECRET = "<server-secret:PORTKEY_API_KEY>"
DEFAULT_CONFIG_ID = "pc-aig-router"
DEFAULT_JOB_PROFILE = "general"
DEFAULT_MODEL_TAG = "auto"
PLATFORM_API_HOST = "vscode"
# Interactive host -> pre-registered agent platform-api sends when the client sends no agent id.
PLATFORM_API_DEFAULT_AGENTS = {"vscode": "ide.vscode", "eclipse": "ide.eclipse", "web": "web.portal"}

USER_TIERS = ("premium", "standard", "free")
JOB_PROFILES = ("underwriting", "claims", "operations", "general")
ENVS = ("local", "workspace", "dev", "stage", "prod")
HOSTS = ("laptop", "vdi", "ecs", "agentcore", "vscode", "eclipse", "web", "ci")
SDK_HOSTS = ("laptop", "vdi", "ecs", "agentcore", "ci")

AGENT_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
TEAM_RE = AGENT_ID_RE
TRACE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")
CONFIG_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")

# Provider keys that must not be present where an SDK runs (keys live only in Portkey).
RAW_PROVIDER_KEYS = (
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "AZURE_OPENAI_API_KEY",
    "GOOGLE_API_KEY",
    "GEMINI_API_KEY",
    "MISTRAL_API_KEY",
    "COHERE_API_KEY",
    "AWS_BEARER_TOKEN_BEDROCK",
)


class ContractError(Exception):
    def __init__(self, code: str, field: str | None = None, http_status: int | None = None):
        super().__init__(code)
        self.code = code
        self.field = field
        self.http_status = http_status

    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"code": self.code}
        if self.field is not None:
            out["field"] = self.field
        if self.http_status is not None:
            out["http_status"] = self.http_status
        return out


def canonical_json(value: Any) -> str:
    """x-portkey-metadata encoding: compact, keys sorted, ASCII (values are ASCII by schema)."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _blank(v: str | None) -> bool:
    return v is None or not str(v).strip()


def _secret_unset(v: str | None) -> bool:
    # Same rule as platform-api: empty or a committed __REPLACE_ME_* placeholder.
    return _blank(v) or str(v).strip().startswith("__REPLACE_ME")


def _url_unset(v: str | None) -> bool:
    # Same rule as platform-api config: empty or still containing a __PLACEHOLDER__ token.
    return _blank(v) or "__" in str(v)


def resolve_trace_id(explicit: str | None, otel: str | None = None) -> str:
    """Explicit call option > active OTel trace id > new uuid4. Invalid values are ignored."""
    for candidate in (explicit, otel):
        if candidate and TRACE_ID_RE.match(candidate):
            return candidate
    return GENERATED_UUID4


def _check_enum(field: str, value: str | None, allowed: tuple[str, ...]) -> str:
    if value is None or value not in allowed:
        raise ContractError("AIG_E_METADATA_INVALID", field)
    return value


def sdk_call(env: dict[str, str], call: dict[str, Any]) -> dict[str, Any]:
    """What an SDK emits for one model call through Portkey (fail-closed checks in order)."""
    # 1. Raw provider keys: refuse before anything else.
    for name in RAW_PROVIDER_KEYS:
        if not _blank(env.get(name)):
            raise ContractError("AIG_E_RAW_PROVIDER_KEY", name)
    # 2. Portkey.
    if _url_unset(env.get("AIG_PORTKEY_BASE_URL")):
        raise ContractError("AIG_E_PORTKEY_UNCONFIGURED", "AIG_PORTKEY_BASE_URL")
    if _secret_unset(env.get("AIG_PORTKEY_API_KEY")):
        raise ContractError("AIG_E_PORTKEY_UNCONFIGURED", "AIG_PORTKEY_API_KEY")
    config_id = (env.get("AIG_PORTKEY_CONFIG") or "").strip() or DEFAULT_CONFIG_ID
    if not CONFIG_ID_RE.match(config_id):
        raise ContractError("AIG_E_PORTKEY_UNCONFIGURED", "AIG_PORTKEY_CONFIG")
    # 3. Fiddler.
    if _url_unset(env.get("AIG_FIDDLER_URL")):
        raise ContractError("AIG_E_FIDDLER_UNCONFIGURED", "AIG_FIDDLER_URL")
    if _secret_unset(env.get("AIG_FIDDLER_API_KEY")):
        raise ContractError("AIG_E_FIDDLER_UNCONFIGURED", "AIG_FIDDLER_API_KEY")
    if _blank(env.get("AIG_FIDDLER_PROJECT")):
        raise ContractError("AIG_E_FIDDLER_UNCONFIGURED", "AIG_FIDDLER_PROJECT")
    # 4. Platform API (agent registration lookup).
    if _url_unset(env.get("AIG_PLATFORM_API_URL")):
        raise ContractError("AIG_E_PLATFORM_API_UNCONFIGURED", "AIG_PLATFORM_API_URL")
    # 5. Agent id.
    agent_id = (env.get("AIG_AGENT_ID") or "").strip()
    if not agent_id:
        raise ContractError("AIG_E_AGENT_ID_MISSING", "AIG_AGENT_ID")
    if not AGENT_ID_RE.match(agent_id):
        raise ContractError("AIG_E_METADATA_INVALID", "agent_id")
    # 6. Metadata: tier and job_profile from the caller (env as default), the rest from config.
    tier = _check_enum("user_tier", call.get("user_tier") or env.get("AIG_USER_TIER") or None, USER_TIERS)
    job = _check_enum(
        "job_profile", call.get("job_profile") or env.get("AIG_JOB_PROFILE") or DEFAULT_JOB_PROFILE, JOB_PROFILES
    )
    team = (env.get("AIG_TEAM") or "").strip()
    if not TEAM_RE.match(team):
        raise ContractError("AIG_E_METADATA_INVALID", "team")
    run_env = _check_enum("env", env.get("AIG_ENV"), ENVS)
    host = _check_enum("host", env.get("AIG_HOST"), SDK_HOSTS)
    user = (env.get("AIG_USER") or "").strip() or None
    if user is not None and not EMAIL_RE.match(user):
        raise ContractError("AIG_E_METADATA_INVALID", "user")
    model = call.get("model") or DEFAULT_MODEL_TAG

    metadata: dict[str, str] = {
        "user_tier": tier,
        "job_profile": job,
        "agent_id": agent_id,
        "team": team,
        "env": run_env,
        "host": host,
    }
    if user:
        metadata["user"] = user
        metadata["_user"] = user
    trace_id = resolve_trace_id(call.get("trace_id"), call.get("otel_trace_id"))
    tags: dict[str, str] = {
        "agent": agent_id,
        "team": team,
        "tier": tier,
        "model": model,
        "env": run_env,
        "host": host,
        "aig.trace_id": trace_id,
    }
    if user:
        tags["aig.user"] = user
    return {
        "portkey_headers": {
            "x-portkey-api-key": env["AIG_PORTKEY_API_KEY"].strip(),
            "x-portkey-config": config_id,
            "x-portkey-metadata": canonical_json(metadata),
            "x-portkey-trace-id": trace_id,
        },
        "span_tags": tags,
    }


def backend_client(call: dict[str, Any]) -> dict[str, Any]:
    """Routing-hint headers an IDE/web client sends to platform-api (it never sends Portkey headers)."""
    job = _check_enum("job_profile", call.get("job_profile") or DEFAULT_JOB_PROFILE, JOB_PROFILES)
    headers = {"x-aig-job-profile": job, "x-aig-trace-id": resolve_trace_id(call.get("trace_id"))}
    agent_id = call.get("agent_id")
    if agent_id is not None:
        if not AGENT_ID_RE.match(agent_id):
            raise ContractError("AIG_E_METADATA_INVALID", "agent_id")
        headers["x-aig-agent-id"] = agent_id
    return {"backend_headers": headers}


def platform_api(server: dict[str, Any], request_headers: dict[str, str]) -> dict[str, Any]:
    """What platform-api forwards to Portkey for one proxied call (HTTP or WebSocket)."""
    allowed = server.get("allowed_job_profiles") or list(JOB_PROFILES)
    job = (request_headers.get("x-aig-job-profile") or "").strip() or (
        DEFAULT_JOB_PROFILE if DEFAULT_JOB_PROFILE in allowed else allowed[0]
    )
    if job not in allowed:
        raise ContractError("invalid_job_profile", http_status=400)
    agent_id = (request_headers.get("x-aig-agent-id") or "").strip() or None
    if agent_id is not None and not AGENT_ID_RE.match(agent_id):
        raise ContractError("invalid_agent_id", http_status=400)
    user = server["user"]
    metadata = {
        "user_tier": user["tier"],
        # Cost-based routing input from the server-side directory (default balanced), never the client.
        "cost_mode": user.get("cost_mode", "balanced"),
        # Usage-based routing: "normal" when the user has no limits (the fixtures configure none).
        "usage_state": user.get("usage_state", "normal"),
        "job_profile": job,
        # Always present: the gateway requires agent_id for every host.
        "agent_id": agent_id or PLATFORM_API_DEFAULT_AGENTS[PLATFORM_API_HOST],
        "team": user["team"],
        "env": server["env"],
        "host": PLATFORM_API_HOST,
        "user": user["email"],
        "_user": user["email"],
    }
    trace_id = resolve_trace_id(request_headers.get("x-aig-trace-id"))
    return {
        "portkey_headers": {
            "x-portkey-api-key": SERVER_SECRET,
            "x-portkey-config": server.get("config_id") or DEFAULT_CONFIG_ID,
            "x-portkey-metadata": canonical_json(metadata),
            "x-portkey-trace-id": trace_id,
        }
    }


# --- agent invocation (protocol aig-http/1, agent-invocation.md) ---------------------------------

SIGNED_CALLER_TOKEN = "<signed:caller-token>"
SIGNING_KEY_KID = "<signing-key:kid>"
PROTOCOL = "aig-http/1"
DEFAULT_CALLER_TOKEN_TTL = 300
SESSION_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
MESSAGE_ROLES = ("system", "user", "assistant", "tool", "developer")
CLIENT_BODY_KEYS = ("input", "messages", "session_id", "stream")
MAX_ERROR_MESSAGE = 500
_JSON_TYPES = {
    "object": dict, "array": list, "string": str, "boolean": bool,
    "integer": int, "number": (int, float), "null": type(None),
}


def _type_ok(value: Any, expected: str) -> bool:
    if expected in ("integer", "number") and isinstance(value, bool):
        return False
    return isinstance(value, _JSON_TYPES[expected])


def schema_errors(schema: dict, value: Any, path: str) -> list[str]:
    """Minimal JSON Schema subset (type, required, properties, additionalProperties: false, enum,
    items) giving the offending field paths in document order. platform-api uses a full Draft
    2020-12 validator; for the fixtures both agree on the first field."""
    out: list[str] = []
    t = schema.get("type")
    if isinstance(t, str) and not _type_ok(value, t):
        return [path]
    if "enum" in schema and value not in schema["enum"]:
        return [path]
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for name in schema.get("required", []):
            if name not in value:
                out.append(f"{path}.{name}")
        for name, sub in props.items():
            if name in value:
                out += schema_errors(sub, value[name], f"{path}.{name}")
        if schema.get("additionalProperties") is False:
            out += [f"{path}.{k}" for k in value if k not in props]
    if isinstance(value, list) and isinstance(schema.get("items"), dict):
        for i, item in enumerate(value):
            out += schema_errors(schema["items"], item, f"{path}.{i}")
    return out


def validate_client_body(body: Any, input_schema: dict | None) -> dict[str, Any]:
    """The agent request body for a client invoke body (fail with input_invalid / 400)."""
    if not isinstance(body, dict):
        raise ContractError("input_invalid", "body", 400)
    for key in body:
        if key not in CLIENT_BODY_KEYS:  # aig_context and anything else are refused
            raise ContractError("input_invalid", key, 400)
    has_input, has_messages = "input" in body, "messages" in body
    if has_input == has_messages:
        raise ContractError("input_invalid", "input", 400)
    out: dict[str, Any] = {}
    if has_input:
        if not isinstance(body["input"], dict):
            raise ContractError("input_invalid", "input", 400)
        if input_schema:
            problems = schema_errors(input_schema, body["input"], "input")
            if problems:
                raise ContractError("input_invalid", problems[0], 400)
        out["input"] = body["input"]
    else:
        msgs = body["messages"]
        if not isinstance(msgs, list) or not 1 <= len(msgs) <= 200:
            raise ContractError("input_invalid", "messages", 400)
        for i, m in enumerate(msgs):
            if not isinstance(m, dict) or m.get("role") not in MESSAGE_ROLES or not isinstance(m.get("content"), (str, list)):
                raise ContractError("input_invalid", f"messages.{i}", 400)
        out["messages"] = [{"role": m["role"], "content": m["content"]} for m in msgs]
    if "session_id" in body:
        if not isinstance(body["session_id"], str) or not SESSION_ID_RE.match(body["session_id"]):
            raise ContractError("input_invalid", "session_id", 400)
        out["session_id"] = body["session_id"]
    if "stream" in body and not isinstance(body["stream"], bool):
        raise ContractError("input_invalid", "stream", 400)
    return out


def runtime_session_id(agent_id: str, user: str, session_id: str | None, invocation_id: str) -> str:
    """AgentCore runtimeSessionId (33..256 chars): scoped per agent and caller, so one user can
    never reach another user's AgentCore session by guessing a session id."""
    import hashlib

    if session_id is None:
        return f"aig-inv-{invocation_id}"
    return "aig-" + hashlib.sha256(f"{agent_id}\n{user}\n{session_id}".encode()).hexdigest()


def agent_request(inv: dict[str, Any]) -> dict[str, Any]:
    """What platform-api sends to the agent for one invoke (headers, body, caller token claims)."""
    agent, caller = inv["agent"], inv["caller"]
    body = validate_client_body(inv.get("client_body"), agent.get("input_schema"))
    mode = inv.get("mode") or "sync"
    invocation_id = inv["invocation_id"]
    trace_id = (inv.get("request_headers") or {}).get("x-aig-trace-id")
    trace_id = trace_id if trace_id and TRACE_ID_RE.match(trace_id) else invocation_id
    stream = mode == "stream"
    body["stream"] = stream
    now = int(inv["now"])
    claims = {
        "iss": f"aig-platform-api/{inv['env']}",
        "aud": agent["agent_id"],
        "sub": caller["email"],
        "iat": now,
        "nbf": now,
        "exp": now + int(inv.get("ttl_seconds") or DEFAULT_CALLER_TOKEN_TTL),
        "jti": invocation_id,
        "user": caller["email"],
        "name": caller["name"],
        "team": caller["team"],
        "tier": caller["tier"],
        "groups": sorted(set(caller.get("groups") or [])),
        "agent_id": agent["agent_id"],
        "version": agent["version"],
        "env": agent["env"],
        "invocation_id": invocation_id,
        "trace_id": trace_id,
    }
    request: dict[str, Any] = {
        "transport": agent["kind"],
        "method": "POST",
        "path": "/invocations",
        "headers": {
            "content-type": "application/json",
            "accept": "text/event-stream" if stream else "application/json",
            "x-aig-caller": SIGNED_CALLER_TOKEN,
            "x-aig-invocation-id": invocation_id,
            "x-aig-trace-id": trace_id,
        },
        "body": body,
    }
    if agent["kind"] == "agentcore":
        body["aig_context"] = {"caller": SIGNED_CALLER_TOKEN, "invocation_id": invocation_id, "trace_id": trace_id}
        request["runtime_session_id"] = runtime_session_id(
            agent["agent_id"], caller["email"], body.get("session_id"), invocation_id
        )
    return {
        "agent_request": request,
        "caller_token": {"header": {"alg": "ES256", "typ": "aig-caller+jwt", "kid": SIGNING_KEY_KID}, "claims": claims},
    }


def parse_sse(raw: str) -> list[dict[str, Any]]:
    """SSE framing: 'event:' / 'data:' lines, blank line dispatches, ':' comments ignored, data
    lines joined with newlines, events without a name default to 'message' (then ignored)."""
    events: list[dict[str, Any]] = []
    name, data = None, []
    for line in raw.replace("\r\n", "\n").split("\n") + [""]:
        if line == "":
            if data:
                try:
                    payload = json.loads("\n".join(data))
                except ValueError:
                    payload = None
                if (name or "message") in ("delta", "output", "error", "done") and isinstance(payload, dict):
                    events.append({"event": name, "data": payload})
            name, data = None, []
            continue
        if line.startswith(":"):
            continue
        field, _, value = line.partition(":")
        value = value[1:] if value.startswith(" ") else value
        if field == "event":
            name = value
        elif field == "data":
            data.append(value)
    return events


def _usage(obj: Any) -> dict[str, int] | None:
    if not isinstance(obj, dict):
        return None
    out = {k: obj[k] for k in ("prompt_tokens", "completion_tokens", "total_tokens")
           if isinstance(obj.get(k), int) and not isinstance(obj.get(k), bool)}
    return out or None


def stream_result(events: list[dict[str, Any]]) -> dict[str, Any]:
    text, output, usage, error, done = "", None, None, None, False
    has_output = False
    for e in events:
        if done:
            break
        if e["event"] == "delta" and isinstance(e["data"].get("text"), str):
            text += e["data"]["text"]
        elif e["event"] == "output" and "output" in e["data"]:
            output, has_output = e["data"]["output"], True
            usage = _usage(e["data"].get("usage")) or usage
        elif e["event"] == "error":
            error = {"code": "agent_error", "message": str(e["data"].get("message") or "agent error")[:MAX_ERROR_MESSAGE]}
        elif e["event"] == "done":
            done = True
    if error:
        return {"status": "failed", "error": error, "text": text}
    if not done and not has_output:
        return {"status": "failed", "error": {"code": "agent_error", "message": "agent stream ended unexpectedly"}, "text": text}
    result: dict[str, Any] = {"status": "succeeded", "output": output if has_output else text, "text": text}
    if usage:
        result["usage"] = usage
    return result


# Agent HTTP status -> platform-api error code and the status platform-api answers with.
AGENT_STATUS_ERRORS = (
    ((400, 400), "input_invalid", 400),
    ((422, 422), "input_invalid", 400),
    ((408, 408), "invocation_timeout", 504),
    ((504, 504), "invocation_timeout", 504),
    ((401, 404), "agent_unavailable", 502),
    ((429, 429), "agent_unavailable", 503),
    ((405, 499), "agent_error", 502),
    ((500, 599), "agent_error", 502),
)


def response_result(status: int, body: Any) -> dict[str, Any]:
    if 200 <= status < 300:
        if not isinstance(body, dict) or "output" not in body:
            return {"status": "failed", "error": {"code": "agent_error", "http_status": 502,
                                                   "message": "agent response has no output"}}
        result: dict[str, Any] = {"status": "succeeded", "output": body["output"]}
        usage = _usage(body.get("usage"))
        if usage:
            result["usage"] = usage
        return result
    code, http_status = "agent_error", 502
    for (lo, hi), c, h in AGENT_STATUS_ERRORS:
        if lo <= status <= hi:
            code, http_status = c, h
            break
    err = body.get("error") if isinstance(body, dict) else None
    message = err.get("message") if isinstance(err, dict) and isinstance(err.get("message"), str) else None
    return {"status": "failed", "error": {"code": code, "http_status": http_status,
                                         "message": (message or f"agent answered HTTP {status}")[:MAX_ERROR_MESSAGE]}}


def agent_invocation(inv: dict[str, Any]) -> dict[str, Any]:
    case = inv["case"]
    if case == "request":
        return agent_request(inv)
    if case == "stream":
        events = parse_sse(inv["sse"])
        return {"events": events, "result": stream_result(events)}
    if case == "response":
        return {"result": response_result(int(inv["http_status"]), inv.get("body"))}
    raise ValueError(f"unknown agent_invocation case {case!r}")


def run_fixture(fixture: dict[str, Any]) -> dict[str, Any]:
    kind, inp = fixture["kind"], fixture["input"]
    try:
        if kind == "agent_invocation":
            return agent_invocation(inp["invocation"])
        if kind == "sdk":
            return sdk_call(inp.get("env", {}), inp.get("call", {}))
        if kind == "backend_client":
            return backend_client(inp.get("call", {}))
        if kind == "platform_api":
            return platform_api(inp["server"], inp.get("request_headers", {}))
    except ContractError as exc:
        return {"error": exc.as_dict()}
    raise ValueError(f"unknown fixture kind {kind!r}")
