#!/usr/bin/env python3
"""Validate the AIG contracts.

Checks:
  1. every *.schema.json is a valid JSON Schema 2020-12;
  2. every fixture validates against fixture.schema.json;
  3. expected headers / span tags validate against headers.schema.json / tags.schema.json, and the
     decoded x-portkey-metadata validates against metadata.schema.json;
  4. x-portkey-metadata is canonical (compact JSON, keys sorted) and agrees with the span tags;
  5. the executable reference model (reference.py) reproduces every fixture's expected block;
  6. every error code and AIG_* variable used by fixtures is documented (errors.md, env-vars.md);
  7. agent_invocation fixtures: the agent request headers/body and caller-token claims validate
     against agent-invocation.schema.json, stream events against its sse_event definition, and
     every error code they produce is documented.

Usage: python backend/contracts/scripts/check_contracts.py   (needs only `jsonschema`)
"""

from __future__ import annotations

import json
import re
import sys
import uuid
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))

import reference  # noqa: E402

MARKERS = {reference.GENERATED_UUID4, reference.SERVER_SECRET, reference.SIGNED_CALLER_TOKEN,
           reference.SIGNING_KEY_KID}
FAKE_CALLER_TOKEN = "eyJhbGciOiJFUzI1NiJ9.e30.c2lnbmF0dXJl"  # gitleaks:allow (schema-shaped dummy, not a token)


def load_schemas() -> tuple[dict[str, dict], Registry]:
    schemas = {p.name: json.loads(p.read_text()) for p in sorted(ROOT.glob("*.schema.json"))}
    registry = Registry().with_resources(
        (s["$id"], Resource.from_contents(s)) for s in schemas.values()
    )
    return schemas, registry


def validator(schema: dict, registry: Registry) -> Draft202012Validator:
    return Draft202012Validator(schema, registry=registry, format_checker=FormatChecker())


def substitute(value, fake_uuid: str):
    """Replace fixture markers with concrete values that satisfy the schemas."""
    if value == reference.GENERATED_UUID4:
        return fake_uuid
    if value == reference.SERVER_SECRET:
        return "server-side-portkey-key"
    if value == reference.SIGNED_CALLER_TOKEN:
        return FAKE_CALLER_TOKEN
    if value == reference.SIGNING_KEY_KID:
        return "kid-thumbprint-placeholder"
    if isinstance(value, dict):
        return {k: substitute(v, fake_uuid) for k, v in value.items()}
    if isinstance(value, list):
        return [substitute(v, fake_uuid) for v in value]
    return value


def check_agent_invocation(tag: str, exp: dict, inv_ref: str, registry: Registry, errors_md: str) -> list[str]:
    """Rule 7: an agent_invocation fixture's expected block agrees with agent-invocation.schema.json."""
    out: list[str] = []

    def v(defn: str) -> Draft202012Validator:
        return validator({"$ref": f"{inv_ref}#/$defs/{defn}"}, registry)

    def check(defn: str, value, where: str) -> None:
        for e in v(defn).iter_errors(substitute(value, "")):
            out.append(f"{tag}: {where}{e.json_path[1:]}: {e.message}")

    if "agent_request" in exp:
        req = exp["agent_request"]
        check("headers", req.get("headers", {}), "agent_request.headers")
        check("request", req.get("body", {}), "agent_request.body")
        if req.get("transport") == "agentcore":
            rsid = req.get("runtime_session_id", "")
            if not 33 <= len(rsid) <= 256:
                out.append(f"{tag}: runtime_session_id must be 33..256 characters (AgentCore SessionType)")
        token = exp["caller_token"]
        check("caller_token_header", token.get("header", {}), "caller_token.header")
        check("caller_token_claims", token.get("claims", {}), "caller_token.claims")
        claims = token.get("claims", {})
        if claims.get("aud") != claims.get("agent_id") or claims.get("jti") != claims.get("invocation_id"):
            out.append(f"{tag}: caller token aud must equal agent_id and jti must equal invocation_id")
        if claims.get("trace_id") != req.get("headers", {}).get("x-aig-trace-id"):
            out.append(f"{tag}: caller token trace_id must equal x-aig-trace-id")
    for i, event in enumerate(exp.get("events", [])):
        check("sse_event", event, f"events[{i}]")
    err = (exp.get("result") or {}).get("error")
    if isinstance(err, dict) and f"`{err.get('code')}`" not in errors_md:
        out.append(f"{tag}: result error code {err.get('code')} is not documented in errors.md")
    return out


def main() -> int:
    errors: list[str] = []
    schemas, registry = load_schemas()

    for name, schema in schemas.items():
        try:
            Draft202012Validator.check_schema(schema)
        except Exception as exc:  # pragma: no cover - reported below
            errors.append(f"{name}: invalid JSON Schema: {exc}")
        if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            errors.append(f"{name}: $schema must be JSON Schema 2020-12")
    if errors:
        print("\n".join(errors))
        return 1

    fixture_v = validator(schemas["fixture.schema.json"], registry)
    meta_v = validator(schemas["metadata.schema.json"], registry)
    tags_v = validator(schemas["tags.schema.json"], registry)
    hdrs = schemas["headers.schema.json"]
    portkey_v = validator({"$ref": hdrs["$id"] + "#/$defs/portkey"}, registry)
    backend_v = validator({"$ref": hdrs["$id"] + "#/$defs/backend"}, registry)
    forbidden = set(hdrs["$defs"]["forbidden"]["const"])

    # Agent-mode span tags (aig-http/1 invocations): accepted, paired, nothing else added.
    base_tags = {"agent": "claims-triage", "team": "claims-ai", "tier": "standard", "model": "auto", "env": "prod",
                 "host": "agentcore"}
    inv_tags = {**base_tags, "aig.caller_user": "bob@example.com", "aig.caller_team": "uw-platform",
                "aig.invocation_id": "0b6f1d2e-6c1a-4a8e-9c7d-1f2e3d4c5b6a", "aig.session_id": "s-1"}
    if not tags_v.is_valid(inv_tags):
        errors.append("tags.schema.json: agent-mode caller tags must validate")
    if tags_v.is_valid({k: v for k, v in inv_tags.items() if k != "aig.caller_team"}):
        errors.append("tags.schema.json: aig.caller_user without aig.caller_team must be refused")
    if tags_v.is_valid({**base_tags, "aig.prompt": "x"}):
        errors.append("tags.schema.json: unknown aig.* tags must be refused (additionalProperties false)")

    # Invocation events (platform-api -> telemetry-bridge): metadata only, content refused.
    inv_v = validator(schemas["invocation-event.schema.json"], registry)
    inv_event = {"invocation_id": inv_tags["aig.invocation_id"], "timestamp": "2026-10-09T10:00:03+00:00",
                 "agent_id": "claims-triage", "team": "claims-ai", "version": "1.4.0", "env": "prod",
                 "agent_host": "agentcore", "kind": "agentcore", "mode": "sync", "purpose": "invoke",
                 "status": "succeeded", "trace_id": inv_tags["aig.invocation_id"], "caller_user": "bob@example.com",
                 "caller_team": "uw-platform", "caller_tier": "standard", "duration_ms": 3200,
                 "prompt_tokens": 412, "completion_tokens": 168, "total_tokens": 580}
    for e in inv_v.iter_errors(inv_event):
        errors.append(f"invocation-event.schema.json: sample event: {e.message}")
    for leak in ("output", "input", "messages", "caller_token"):
        if inv_v.is_valid({**inv_event, leak: "x"}):
            errors.append(f"invocation-event.schema.json: must refuse content field {leak!r}")

    errors_md = (ROOT / "errors.md").read_text()
    env_md = (ROOT / "env-vars.md").read_text()

    fixtures = sorted((ROOT / "fixtures").glob("*.json"))
    if len(fixtures) < 8:
        errors.append(f"fixtures/: expected at least 8 golden cases, found {len(fixtures)}")
    kinds: dict[str, int] = {}

    for path in fixtures:
        tag = f"fixtures/{path.name}"
        raw = path.read_text()
        try:
            fx = json.loads(raw)
        except json.JSONDecodeError as exc:
            errors.append(f"{tag}: invalid JSON: {exc}")
            continue
        for e in fixture_v.iter_errors(fx):
            errors.append(f"{tag}: {e.json_path}: {e.message}")
        if fixture_v.is_valid(fx) is False:
            continue
        if fx["name"] != path.stem:
            errors.append(f"{tag}: name {fx['name']!r} must match the file name")
        kinds[fx["kind"]] = kinds.get(fx["kind"], 0) + 1
        exp = fx["expected"]
        fake = str(uuid.uuid4())

        # 6. documented names
        for var in fx["input"].get("env", {}):
            if var.startswith("AIG_") and f"`{var}`" not in env_md:
                errors.append(f"{tag}: {var} is not documented in env-vars.md")
        if "error" in exp and f"`{exp['error']['code']}`" not in errors_md:
            errors.append(f"{tag}: error code {exp['error']['code']} is not documented in errors.md")

        # 3/4. schemas, canonical metadata, consistency
        if "portkey_headers" in exp:
            ph = {k: substitute(v, fake) for k, v in exp["portkey_headers"].items()}
            for e in portkey_v.iter_errors(ph):
                errors.append(f"{tag}: portkey_headers{e.json_path[1:]}: {e.message}")
            if forbidden & set(ph):
                errors.append(f"{tag}: forbidden headers present: {sorted(forbidden & set(ph))}")
            meta_raw = ph.get("x-portkey-metadata", "")
            try:
                meta = json.loads(meta_raw)
            except json.JSONDecodeError as exc:
                errors.append(f"{tag}: x-portkey-metadata is not JSON: {exc}")
                meta = None
            if meta is not None:
                for e in meta_v.iter_errors(meta):
                    errors.append(f"{tag}: metadata{e.json_path[1:]}: {e.message}")
                if meta_raw != reference.canonical_json(meta):
                    errors.append(f"{tag}: x-portkey-metadata is not canonical (compact, sorted keys)")
                if "span_tags" in exp:
                    st = {k: substitute(v, fake) for k, v in exp["span_tags"].items()}
                    for e in tags_v.iter_errors(st):
                        errors.append(f"{tag}: span_tags{e.json_path[1:]}: {e.message}")
                    pairs = [("agent", "agent_id"), ("team", "team"), ("tier", "user_tier"),
                             ("env", "env"), ("host", "host"), ("aig.user", "user"),
                             ("aig.caller_user", "caller_user"), ("aig.caller_team", "caller_team"),
                             ("aig.invocation_id", "invocation_id")]
                    for t, m in pairs:
                        if st.get(t) != meta.get(m):
                            errors.append(f"{tag}: span tag {t}={st.get(t)!r} != metadata {m}={meta.get(m)!r}")
                    if st.get("aig.trace_id") != ph.get("x-portkey-trace-id"):
                        errors.append(f"{tag}: aig.trace_id must equal x-portkey-trace-id")
                elif fx["kind"] == "sdk":
                    errors.append(f"{tag}: sdk fixtures must include span_tags")
        if "backend_headers" in exp:
            bh = {k: substitute(v, fake) for k, v in exp["backend_headers"].items()}
            for e in backend_v.iter_errors(bh):
                errors.append(f"{tag}: backend_headers{e.json_path[1:]}: {e.message}")

        if fx["kind"] == "agent_invocation":
            errors.extend(check_agent_invocation(tag, exp, schemas["agent-invocation.schema.json"]["$id"],
                                                 registry, errors_md))

        # Markers must be whole values only.
        for m in re.findall(r"<[a-z-]+:[^>]*>", raw):
            if m not in MARKERS:
                errors.append(f"{tag}: unknown marker {m}")

        # 5. reference model
        got = reference.run_fixture(fx)
        if got != exp:
            errors.append(f"{tag}: reference model disagrees\n  expected {json.dumps(exp)}\n  got      {json.dumps(got)}")

    for kind in ("sdk", "backend_client", "platform_api", "agent_invocation"):
        if not kinds.get(kind):
            errors.append(f"fixtures/: no fixture of kind {kind}")

    if errors:
        print("contracts: FAILED")
        print("\n".join(f"  - {e}" for e in errors))
        return 1
    summary = ", ".join(f"{k}={v}" for k, v in sorted(kinds.items()))
    print(f"contracts: OK ({len(schemas)} schemas, {len(fixtures)} fixtures: {summary})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
