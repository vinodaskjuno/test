# Agent invocation contract (`aig-http/1`)

How platform-api runs a registered agent on behalf of a signed-in user, and what an agent server
must implement. Machine-readable: [`agent-invocation.schema.json`](agent-invocation.schema.json)
(request, headers, caller token, response, stream events, `/ping`, `/schema`) and
[`agent-record.schema.json`](agent-record.schema.json) (registry record, versions, invocation
record). Golden cases: `fixtures/agent-invocation-*.json` (`kind: agent_invocation`), reproduced by
[`scripts/reference.py`](scripts/reference.py) and checked by `make contracts`.

```
client (portal, VS Code, Eclipse, Teams)                   agent server (AgentCore runtime or HTTPS)
   │  POST /api/v1/agents/{id}/invoke  (user token)            ▲
   │  or WS frame agent.invoke                                 │ POST /invocations  (aig-http/1)
   ▼                                                           │ x-aig-caller: <ES256 caller token>
platform-api ── access + lifecycle + version + input schema ───┘ x-aig-invocation-id, x-aig-trace-id
                                                                 agent calls Portkey with ITS OWN key
                                                                 (agent mode), adds caller_user/caller_team
```

Principles:

- Clients never talk to an agent directly and never hold agent credentials. platform-api checks
  access, lifecycle and version, validates the input, signs the caller token and records the
  invocation (metadata only).
- The agent keeps calling models through Portkey **with its own team key** (agent mode, budgets on
  the agent's team). It adds `caller_user`, `caller_team` and `invocation_id` from the verified caller
  token to `x-portkey-metadata` (optional fields of [`metadata.schema.json`](metadata.schema.json))
  so cost is attributable to the caller, and the same values to its Fiddler spans.
- "No gateway, no Fiddler, no agent" still holds: an agent becomes invocable only after a
  verification (health + test invocation seen by the gateway agent-check + trace check) or a deploy
  registration from the pipeline.

## Agent server endpoints

Paths are relative to the version's `endpoint` (kind `https`) or the AgentCore runtime (kind
`agentcore`, where AgentCore itself requires `/invocations` and `/ping` on port 8080).

| Method | Path | Required | Purpose |
|---|---|---|---|
| `POST` | `/invocations` | yes | Run the agent once (JSON or SSE answer) |
| `GET` | `/ping` | yes | Health: any 2xx is healthy (AgentCore body `{"status": "Healthy"}`) |
| `GET` | `/schema` | no | Self-description `{protocol: "aig-http/1", name, description, tags, input_schema, output_schema, examples}` (same fields as `aig-agent.yaml`) |

### Request

```json
POST /invocations
content-type: application/json
accept: application/json            (text/event-stream when stream=true)
x-aig-caller: eyJhbGciOiJFUzI1NiIs...  (caller token, below)
x-aig-invocation-id: 7d3f2c1e-9a4b-4c5d-8e6f-0a1b2c3d4e5f
x-aig-trace-id: trace-claims-0001

{"input": {"claim_id": "CLM-4411", "line_of_business": "property"}, "session_id": "case-4411", "stream": false}
```

- Exactly one of `input` (an object; validated by platform-api against the version's
  `input_schema` before the agent is called) or `messages` (chat mode, OpenAI-style roles
  `system|user|assistant|tool|developer`, 1..200 messages).
- `session_id` (optional, `[A-Za-z0-9._:-]{1,128}`): the agent owns conversation memory. Agents
  **must** key memory by (caller `user`, `session_id`), never by `session_id` alone.
- `stream`: `true` only when platform-api wants SSE (client `mode=stream`). Sync and background
  invocations use `false`.
- `x-aig-trace-id` is the client's valid `x-aig-trace-id` if it sent one, otherwise the invocation
  id. The agent uses it as its trace id (Portkey `x-portkey-trace-id`, Fiddler `aig.trace_id`).
- Unknown top-level keys are refused by platform-api (`input_invalid`); a client can never send
  `aig_context`.
- Backward compatibility: the AgentCore shims keep accepting the legacy body `{"prompt": "..."}`
  (W3); platform-api never sends it.

**HTTPS transport.** platform-api adds the version's credentials: `auth.type = api_key` sends the
key in `x-api-key` (or the header named in the secret, below); `oauth_client_credentials` fetches a
token from the secret's `token_url` (cached until 60 s before expiry) and sends
`Authorization: Bearer <token>`; `none` sends nothing. Redirects are not followed.

**AgentCore transport.** platform-api calls `bedrock-agentcore:InvokeAgentRuntime` with its IAM
role (SigV4): `agentRuntimeArn` = the version's `runtime_arn`, `qualifier` (default endpoint when
unset), `contentType: application/json`, `accept` as above, `payload` = the body, and
`runtimeSessionId`:

- with a `session_id`: `"aig-" + sha256("<agent_id>\n<caller email>\n<session_id>")` (hex), so one
  user can never reach another user's AgentCore session by guessing an id;
- without: `"aig-inv-<invocation_id>"`.

AgentCore only forwards custom headers named `X-Amzn-Bedrock-AgentCore-Runtime-Custom-*` that are
allow-listed on the runtime, so platform-api sends the three headers as
`X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller`, `...-Aig-Invocation-Id`, `...-Aig-Trace-Id`
**and** mirrors them in the body as `aig_context: {caller, invocation_id, trace_id}`. Agents read
the header first and fall back to `aig_context`. The AgentCore streaming body is parsed exactly
like an HTTPS answer (by its content type).

### Caller token (`x-aig-caller`)

A compact JWS signed by platform-api, **ES256** (ECDSA P-256 / SHA-256), header
`{"alg": "ES256", "typ": "aig-caller+jwt", "kid": "<RFC 7638 thumbprint>"}`.

ES256 rather than HS256: agents only ever hold the **public** key, so a compromised agent cannot
mint tokens for other agents or users. Public keys: `GET /api/v1/caller-token/jwks` on
platform-api (no auth, `{"keys": [{"kty": "EC", "crv": "P-256", "kid", "x", "y", "alg": "ES256", "use": "sig"}]}`,
cacheable for 1 hour).

| Claim | Value |
|---|---|
| `iss` | `aig-platform-api/<AIG_ENV of platform-api>` |
| `aud` | the agent id (an agent must reject tokens for other audiences) |
| `sub`, `user` | caller email (from the identity provider, never the client body) |
| `name`, `team`, `tier` | from the platform-api user directory |
| `groups` | caller's Entra group claims (sorted, de-duplicated; local dev: `users.yaml` `groups`) |
| `agent_id`, `version`, `env` | the version being invoked (`env` = `local|dev|stage|prod`) |
| `invocation_id`, `jti` | the invocation id |
| `trace_id` | equals `x-aig-trace-id` |
| `iat`, `nbf`, `exp` | signing time; `exp = iat + AIG_AGENT_CALLER_TOKEN_TTL_SECONDS` (default 300) |

Agents verify (W3 serve helpers do this): signature with a JWKS key whose `kid` matches,
`alg == ES256`, `iss`, `aud == own agent id`, `agent_id == aud`, `exp`/`nbf` with 60 s leeway (once,
when the request arrives; a stream may outlive `exp`). A missing or invalid token is answered with
401 `{"error": {"code": "caller_unauthenticated", ...}}`. The token is identity only: it is never
forwarded to other services, never logged and grants nothing else.

Signing key: platform-api secret `AGENT_CALLER_SIGNING_KEY` (PEM PKCS#8 or SEC1 EC P-256 private
key; in an env file either base64 of the PEM or the PEM with `\n` escapes). Outside `local`,
invocation is disabled (503 `agent_invocation_disabled`) without it; `AIG_AGENT_INVOCATION=true`
then stops startup. In `local` an ephemeral key is generated at startup (logged as a warning).

### Response (stream = false)

`200` with `{"output": <object|string>, "usage"?: {"prompt_tokens", "completion_tokens", "total_tokens"}, "trace_id": "...", "session_id"?: "..."}`.
`output` should match the version's `output_schema` when one is declared (not enforced by
platform-api). Errors: any non-2xx with the shared envelope `{"error": {"code", "message"}}`.

### Stream (stream = true)

`200 text/event-stream`, events `event: <name>\ndata: <compact JSON>\n\n`:

| Event | `data` | When |
|---|---|---|
| `delta` | `{"text": "..."}` | Zero or more partial text chunks |
| `output` | `{"output": ..., "usage"?: {...}, "trace_id"?: "..."}` | Exactly once on success |
| `error` | `{"code": "...", "message": "..."}` | Instead of `output` on failure |
| `done` | `{}` | Always last |

Comment lines (`: keepalive`) may appear at any time (send one at least every 30 s on long
silent runs) and unknown events are ignored. A stream with `done` but no `output` succeeds with the
concatenated deltas as output; a stream that ends without `output` or `done` fails (`agent_error`).
An agent that ignores `stream: true` and answers JSON is accepted.

### Mapping agent answers to platform-api errors

| Agent answer | Code | platform-api HTTP |
|---|---|---|
| 400, 422 | `input_invalid` | 400 |
| 401, 403, 404, connection/TLS/DNS failure | `agent_unavailable` | 502 |
| 429 | `agent_unavailable` | 503 |
| 408, 504, or platform-api's own timeout | `invocation_timeout` | 504 |
| other 4xx, 5xx, `error` event, 2xx without `output` | `agent_error` | 502 |

Messages from the agent are kept (redacted of platform secrets, at most 500 characters); input and
output are never logged.

## Timeouts, modes and records

| Mode (`POST /api/v1/agents/{id}/invoke?mode=`) | Answer | Limit |
|---|---|---|
| `sync` (default) | `200` JSON `{invocation_id, agent_id, version, env, status, output, usage, trace_id, duration_ms}` | `AIG_AGENT_SYNC_TIMEOUT_SECONDS` = 120 |
| `stream` (or body `stream: true`, or `Accept: text/event-stream`) | `200 text/event-stream`, same events as above; platform-api adds `invocation_id` to every event and `status`, `duration_ms` to `done` | `AIG_AGENT_STREAM_TIMEOUT_SECONDS` = 900 |
| `background` | `202` `{invocation_id, status: "queued"}` + `Location: /api/v1/invocations/{id}`; WebSocket `agent.invocation.status` pushes; output stored encrypted (Fernet, `AGENT_OUTPUT_ENCRYPTION_KEY`) for 30 days | `AIG_AGENT_BACKGROUND_TIMEOUT_SECONDS` = 3600 |

Invocation records (`agent_invocations`) keep metadata only (who, agent, version, env, mode,
status, start/finish, duration, token usage, trace id, error code) for 90 days. Output is stored
only for background runs, encrypted, readable only by the caller and the agent's owner.

## Registry concepts used by the contract

- **Lifecycle** `draft -> active -> deprecated -> retired` (+ the orthogonal gateway `status`
  `active|suspended`). New agents start as `draft`; built-ins are `active`.
- **Versions** per environment (`local|dev|stage|prod`): kind `agentcore` (`runtime_arn` +
  `qualifier`) or `https` (`endpoint`), `protocol: aig-http/1`, `input_schema`, `output_schema`,
  `auth {type, secret_arn}` (reference only), verification result.
- **Access**: owner and owner's team always; `visibility: groups` adds Entra `allowed_groups`;
  `visibility: org` (after platform-admin approval) adds everyone.
- Users invoke `prod`; the owner and team may also pick `dev`, `stage` and (in `AIG_ENV=local`)
  `local` versions, verified or not.

## HTTPS agent credentials (Secrets Manager)

`auth.secret_arn` names a secret (convention `aig/<env>/agents/<agent_id>/invoke-auth`) that
platform-api's task role may read. Formats of its `SecretString`:

- `api_key`: the key itself, or JSON `{"api_key": "...", "header": "x-api-key"}`.
- `oauth_client_credentials`: JSON `{"token_url": "https://...", "client_id": "...", "client_secret": "...", "scope": "..."}`
  (`scope`, `audience` optional).

In `AIG_ENV=local` only, `secret_arn` may be `local:<NAME>`: the value of `<NAME>` from the process
environment or `secrets/.env.local`.

## Agent-side variables (serve helpers, W3)

| Variable | Default | Meaning |
|---|---|---|
| `AIG_CALLER_JWKS_URL` | `{AIG_PLATFORM_API_URL}/api/v1/caller-token/jwks` | Where the agent fetches platform-api's public keys |
| `AIG_CALLER_PUBLIC_KEY` | none | PEM public key instead of the JWKS URL (offline / tests) |
| `AIG_CALLER_ISSUER` | `aig-platform-api/<AIG_ENV>` (`workspace` maps to `dev`) | Expected `iss` |
| `AIG_SERVE_PORT` | `8080` | Port of `/invocations` + `/ping` + `/schema` (AgentCore requires 8080) |

Behaviour of the serve helpers (`aig_sdk.serve`, `@aig/sdk/serve`), identical in both SDKs:

- **Bind address**: `0.0.0.0` when `AIG_HOST` is `agentcore` or `ecs` (inside a container), else
  loopback (`127.0.0.1`) only, so a laptop never exposes an agent on the network.
- **Model calls inside an invocation** route with the caller token's `tier` as `user_tier` (and the
  invocation's trace id); an explicit per-call option (`call_context(user_tier=...)` /
  `callContext({user_tier})`) still wins. Portkey metadata gains `caller_user`, `caller_team`,
  `invocation_id`; spans gain the matching `aig.caller_user`, `aig.caller_team`,
  `aig.invocation_id` tags (and `aig.session_id` when the request carries a `session_id`), see
  `tags.schema.json`.
- **Agent-side refusals** (error envelope `{"error": {"code", "message", "field"?}}`):

  | Status | Code | When |
  |---|---|---|
  | 400 | `input_invalid` | body not JSON / not an object, unknown key, both or neither of `input`/`messages`, invalid `session_id`, `input` fails the descriptor's `input_schema`; `error.field` names the offending key or path |
  | 413 | `input_invalid` | request body larger than 1 MiB (`error.field` = `body`) |
  | 401 | `caller_unauthenticated` | `x-aig-caller` missing or invalid (signature, `iss`, `aud`, `agent_id`, expiry, claim shapes) or `x-aig-invocation-id` differs from the token |

There is no switch that disables caller-token verification outside `AIG_ENV=local`.
