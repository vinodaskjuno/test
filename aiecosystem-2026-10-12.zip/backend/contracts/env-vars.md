# Environment-variable contract

## SDKs (`aig_sdk`, `@aig/sdk`, the `aig` CLI)

Both SDKs read exactly these variables, with the same names, defaults and validation.
"Required" means `init()` raises `AigStartupError` (Python) / throws (TypeScript) with the
listed error code when the variable is missing, empty or a placeholder.

| Variable | Required | Default | Meaning | Error when bad |
|---|---|---|---|---|
| `AIG_PORTKEY_BASE_URL` | yes | none | Self-hosted Portkey AI gateway base URL, e.g. `https://portkey.<corp>/v1`. A value containing `__` counts as a placeholder | `AIG_E_PORTKEY_UNCONFIGURED` |
| `AIG_PORTKEY_API_KEY` | yes | none | Scoped Portkey workspace API key (never a provider key). Empty or `__REPLACE_ME*` counts as missing | `AIG_E_PORTKEY_UNCONFIGURED` |
| `AIG_PORTKEY_CONFIG` | no | `pc-aig-router` | Portkey config id sent as `x-portkey-config` (`^[A-Za-z0-9._-]{1,128}$`) | `AIG_E_PORTKEY_UNCONFIGURED` |
| `AIG_PORTKEY_MCP_URL` | no | none | Portkey MCP gateway URL. MCP clients connect only through it | `AIG_E_MCP_UNREGISTERED` on use |
| `AIG_FIDDLER_URL` | yes | none | Fiddler instance URL | `AIG_E_FIDDLER_UNCONFIGURED` |
| `AIG_FIDDLER_API_KEY` | yes | none | Fiddler access token / API key | `AIG_E_FIDDLER_UNCONFIGURED` |
| `AIG_FIDDLER_PROJECT` | yes | none | Fiddler project (one per environment, e.g. `aig-dev`) | `AIG_E_FIDDLER_UNCONFIGURED` |
| `AIG_FIDDLER_APPLICATION_ID` | yes, unless the registry returns one or `AIG_OTLP_ENDPOINT` is set | none | Fiddler application (UUID4, one per registered agent). Fiddler's OTLP ingestion and `fiddler-langgraph` route on it. Falls back to the platform-api registry record's `fiddler_application_id` | `AIG_E_FIDDLER_UNCONFIGURED` |
| `AIG_OTLP_ENDPOINT` | no | Fiddler's OTLP endpoint | OTLP exporter endpoint for generic OTel tracing (Strands, custom agents) | none |
| `AIG_PLATFORM_API_URL` | yes | none | platform-api base URL, used to verify the agent is registered and active | `AIG_E_PLATFORM_API_UNCONFIGURED` |
| `AIG_PLATFORM_API_TOKEN` | no | none | Bearer token for the platform-api agent lookup / registration (`GET`/`POST /api/v1/agents`). `aig eval` sends it as the service token `x-aig-service-token` instead (see below). A `__REPLACE_ME*` value counts as unset | `AIG_E_PLATFORM_API_UNREACHABLE` when refused |
| `AIG_AGENT_ID` | yes | none | Registered agent id, `^[A-Za-z0-9._-]{1,64}$` | `AIG_E_AGENT_ID_MISSING` / `AIG_E_METADATA_INVALID` |
| `AIG_TEAM` | yes | none | Owning team slug, `^[A-Za-z0-9._-]{1,64}$` | `AIG_E_METADATA_INVALID` |
| `AIG_ENV` | yes | none | `local`, `workspace`, `dev`, `stage` or `prod` | `AIG_E_METADATA_INVALID` |
| `AIG_HOST` | yes | none | `laptop`, `vdi`, `ecs`, `agentcore` or `ci` | `AIG_E_METADATA_INVALID` |
| `AIG_USER_TIER` | yes, unless every call passes a tier | none | `premium`, `standard` or `free` | `AIG_E_METADATA_INVALID` |
| `AIG_JOB_PROFILE` | no | `general` | `underwriting`, `claims`, `operations` or `general` (a call option overrides it) | `AIG_E_METADATA_INVALID` |
| `AIG_USER` | no | none | Email of the human the agent acts for; adds `user` and `_user` to the metadata and `aig.user` to spans | `AIG_E_METADATA_INVALID` |
| `AIG_TIMEOUT_SECONDS` | no | `120` | Gateway request timeout | none |
| `AIG_LOG_LEVEL` | no | `INFO` | SDK log level. Keys are never logged at any level | none |

The `aig` CLI also reads:

| Variable | Default | Meaning |
|---|---|---|
| `AIG_TEMPLATES_DIR` | templates packaged in the `aig-sdk` wheel | Where `aig init` finds the starter templates. Lookup order: `--templates-dir`, then `AIG_TEMPLATES_DIR`, then the templates shipped inside the installed `aig-sdk` wheel, then the repo's `sdk/templates/` (monorepo checkout) |
| `AIG_SDK_SOURCE` | `registry` | How `aig init` installs the SDK into the new project: `registry` (the pinned `aig-sdk` / `@aig/sdk` version from the internal package index) or `monorepo` (the platform repo's local SDK sources; development only, also implied by `--dev-sdk-path`). `--sdk-source` overrides it |

### Agent serve helpers (agent invocation, `agent-invocation.md`)

An agent that serves the AIG invocation contract (`aig-http/1`) verifies the platform-signed
caller token. There is no variable that switches verification off outside `AIG_ENV=local`.

| Variable | Default | Meaning |
|---|---|---|
| `AIG_CALLER_JWKS_URL` | `{AIG_PLATFORM_API_URL}/api/v1/caller-token/jwks` | platform-api public keys for `x-aig-caller` (ES256) |
| `AIG_CALLER_PUBLIC_KEY` | none | PEM public key instead of the JWKS URL (offline / tests) |
| `AIG_CALLER_ISSUER` | `aig-platform-api/<AIG_ENV>` (`workspace` maps to `dev`) | Expected `iss` of the caller token |
| `AIG_SERVE_PORT` | `8080` | Port of `POST /invocations`, `GET /ping` and `GET /schema` (AgentCore requires 8080). The helpers bind `0.0.0.0` when `AIG_HOST` is `agentcore`/`ecs`, else loopback only (see `agent-invocation.md`, Agent-side variables) |

### `aig eval` (Phase 5, `docs/evals.md`)

`aig eval run` reads the SDK variables above (Python tasks start `init()` with them; the
fail-closed rules are unchanged, including `--offline`) plus:

| Variable | Default | Meaning |
|---|---|---|
| `AIG_FIDDLER_URL`, `AIG_FIDDLER_API_KEY`, `AIG_FIDDLER_PROJECT` | none | Required for online runs (`fiddler_evals.init`, the project of the agent's application); missing = exit 2 `AIG_E_FIDDLER_UNCONFIGURED`. Not read with `--offline` |
| `AIG_FIDDLER_APPLICATION_ID` | registry record | The agent's Fiddler application for experiments; without it the application is `Project.get_or_create(AIG_FIDDLER_PROJECT)` + `Application.get_or_create(agent_id)` |
| `AIG_PLATFORM_API_URL` | none | Baselines (`GET /api/v1/evals`) and `--post` (`POST /api/v1/evals`). Unset: no `auto` baseline from platform-api; `--post` = exit 2 |
| `AIG_PLATFORM_API_TOKEN` | none | Sent as `x-aig-service-token` (platform-api `PLATFORM_SERVICE_TOKEN`); required by `--post` |
| `AIG_PLATFORM_API_AUTH` | `service` | `bearer` sends `AIG_PLATFORM_API_TOKEN` as `Authorization: Bearer` (a developer token, to read baselines locally; `--post` needs the service token) |
| `AIG_AGENT_ID` | `agent_id` in aig-eval.yaml | Must equal the config's `agent_id` when set (exit 2 otherwise) |
| `AIG_EVAL_GIT_SHA`, `GITHUB_SHA` | none | Commit recorded with the run (`--git-sha` wins) |
| `AIG_EVAL_PR`, `GITHUB_REF` (`refs/pull/<n>/...`) | none | PR recorded with the run (`--pr` wins). Runs without a PR are `auto` baseline candidates |

`aig-eval.yaml` may reference any variable as `${VAR}` / `${VAR:-default}` (the templates use
`AIG_EVAL_AGENT_URL` for the TypeScript agent's eval endpoint; `npm run serve` listens on
`AIG_EVAL_PORT`, default `8787`). The `@aig/sdk` `aig-eval` bin reads `AIG_PYTHON_CLI` (the Python
CLI command, e.g. `/path/.venv/bin/aig`) and `AIG_PYTHON` (interpreter for
`python -m aig_sdk.cli`, default `python3`). None of these switch a check off.

Check order (the first failure wins, and the fixtures depend on it): raw provider keys, Portkey,
Fiddler, platform-api URL, agent id, then metadata fields in the order `user_tier`,
`job_profile`, `team`, `env`, `host`, `user`. Network checks run after these in `init()` and `aig doctor`, in the order Portkey reachable
(`GET AIG_PORTKEY_BASE_URL`, any answer below 500), Fiddler reachable and token accepted
(`GET {AIG_FIDDLER_URL}/v3/server-info`, plus `AIG_OTLP_ENDPOINT` when set), agent registered,
active and owned by `AIG_TEAM` or shared (`GET {AIG_PLATFORM_API_URL}/api/v1/agents/{id}`),
Fiddler application resolved.

### Variables that must NOT be set

- Provider keys: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `AZURE_OPENAI_API_KEY`,
  `GOOGLE_API_KEY`, `GEMINI_API_KEY`, `MISTRAL_API_KEY`, `COHERE_API_KEY`,
  `AWS_BEARER_TOKEN_BEDROCK`. Any non-empty value fails with `AIG_E_RAW_PROVIDER_KEY`.
  Provider keys live only in Portkey virtual keys.

### There is no fail-open switch

The SDKs are **fail-closed**. There is deliberately no `AIG_FAIL_OPEN`, `AIG_SKIP_CHECKS`,
`AIG_DISABLE_FIDDLER` or similar variable: "no gateway, no Fiddler, no agent". SDKs never read
such variables; setting one changes nothing (see fixture
`sdk-error-fail-open-is-not-a-thing`). Adding one is a contract change that needs platform
owner approval.

## Backend (`backend/platform-api`)

Process settings (non-secret). Secrets come from `secrets/.env.<env>` or AWS Secrets Manager
`aig/<env>/platform-api`; see `backend/platform-api/README.md`.

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local`, `dev`, `stage` or `prod` (sent as metadata `env`) |
| `AIG_SECRET_PROVIDER` | `env` | `env` or `aws` |
| `AIG_AUTH_MODE` | `oidc` | `dev` (accepts `Bearer dev:<email>`) is allowed only with `AIG_ENV=local` |
| `AIG_PUBLIC_BASE_URL` | none | Public `https://` URL; required outside `local` |
| `AIG_CONFIG_DIR` | `./config` | Non-secret config directory |
| `AIG_SECRETS_DIR` | `./secrets` | Secret env-file directory |
| `AIG_USERS_FILE` | `config/users.yaml` | User directory (tier and team per user). Validated on load: tier `premium\|standard\|free`, slug-shaped team; invalid entries stop startup outside `local` |
| `AIG_AGENTS_FILE` | `config/agents.yaml` | One-time seed of the (database) agent registry when it is empty; later imports with `aig-platform-api agents import FILE` (`config/agents.example.yaml` only in `local`; built-in `ide.vscode`, `ide.eclipse`, `web.portal` always registered) |
| `AIG_DATABASE_URL` | local: `sqlite:///.run/platform.db` | Phase 4 database. **Required** outside `local`: a Postgres URL (`postgresql+psycopg://...`); startup fails without it, with a placeholder, or with a non-Postgres URL. Its password is never logged |
| `AIG_DB_AUTO_MIGRATE` | `true` in `local`, else `false` | Run Alembic migrations at startup; otherwise startup fails unless the schema is at head (`aig-platform-api db upgrade`) |
| `AIG_MIGRATIONS_DIR` | `./migrations` | Alembic scripts (`/app/migrations` in the image) |
| `AIG_MCP_SYNC` | `false` | Push approved MCP servers to the Portkey MCP gateway (admin API, `PORTKEY_ADMIN_API_KEY`) |
| `AIG_PORTKEY_ADMIN_URL` | env config `portkey_admin_api_url` | Portkey admin API base for the MCP registry sync |
| `AIG_TELEMETRY_BRIDGE_URL` | none | telemetry-bridge base URL; IDE usage events are posted to `{url}/ingest/ide-usage` and finished agent invocations (metadata only) to `{url}/ingest/invocation` (with `TELEMETRY_BRIDGE_TOKEN`) |
| `AIG_TELEMETRY_BRIDGE_TIMEOUT_SECONDS` | `5` | Timeout of one fire-and-forget usage-event post |
| `AIG_ROUTING_CONFIG_FILE` | none | Rendered Portkey config (`aigw render --env <env> --kind configs`) served by `GET /api/v1/routing` |
| `AIG_UPSTREAM_TIMEOUT_SECONDS` | `120` | Portkey request timeout |
| `AIG_WS_USAGE_INTERVAL` | `15` | Seconds between WebSocket usage pushes (minimum 5) |
| `AIG_WS_PING_INTERVAL_SECONDS` | `25` | WebSocket keepalive interval |
| `AIG_FIDDLER_AUTOPROVISION` | `false` | Phase 3: after `POST /api/v1/agents`, call `aig_fiddler.hooks:on_agent_registered` (backend/observability/tool) to create the agent's Fiddler application, trust scores and monitors. Set but not importable: startup fails outside `local` |
| `AIG_AGENT_HOOKS` | none | Extra agent-registered hooks, comma-separated `module:function` (same signature) |
| `AIG_MODEL_SANDBOX_SYNC` | `false` | Phase 7: on `requested -> sandbox`, create a sandbox-only Portkey provider (virtual key) for the model in the `model-sandbox` workspace (`PORTKEY_ADMIN_API_KEY`, `AIG_PORTKEY_ADMIN_URL`; env config `portkey_sandbox_providers_path`, `model_sandbox_workspace`, `model_sandbox_integrations`). Outcome recorded on the model; never blocks the transition |
| `AIG_CANARY_DISPATCH` | `false` | Phase 7: on `-> canary / promoted / rolled_back`, send a GitHub `repository_dispatch` (`model_canary` / `model_promote` / `model_rollback`) with `GITHUB_DISPATCH_TOKEN` |
| `AIG_GITHUB_REPO` | none | `owner/repo` that receives the dispatch (runs `.github/workflows/model-canary.yml`) |
| `AIG_GITHUB_API_URL` | `https://api.github.com` | GitHub (Enterprise) API base for the dispatch |
| `AIG_AGENT_INVOCATION` | unset | Registry v2 agent invocation. Unset: on in `local`, elsewhere on when `AGENT_CALLER_SIGNING_KEY` is configured (else invoke answers 503 `agent_invocation_disabled`). `true` without the key stops startup outside `local`; `false` turns it off |
| `AIG_AGENT_SYNC_TIMEOUT_SECONDS` | `120` | `mode=sync` limit (`invocation_timeout`) |
| `AIG_AGENT_STREAM_TIMEOUT_SECONDS` | `900` | `mode=stream` and WebSocket `agent.invoke` limit |
| `AIG_AGENT_BACKGROUND_TIMEOUT_SECONDS` | `3600` | `mode=background` limit |
| `AIG_AGENT_CONNECT_TIMEOUT_SECONDS` | `10` | Connect timeout to agent servers, `GET /ping` and OAuth token endpoints |
| `AIG_AGENT_CALLER_TOKEN_TTL_SECONDS` | `300` | Lifetime of the caller token (`exp - iat`, minimum 30) |
| `AIG_AGENT_MAX_BACKGROUND_PER_USER` | `10` | Running background invocations per user (`too_many_requests`) |
| `AIG_AGENT_MAX_RESPONSE_BYTES` | `4194304` | Largest agent JSON answer or single SSE event accepted |
| `AIG_AGENT_VERIFY_SEEN_WINDOW_SECONDS` | `300` | Verification: the gateway agent-check must have seen the agent (`last_seen_at`) within this window |
| `AIG_AGENT_TRACE_CHECK` | none | Verification trace check `module:function` (signature in `backend/platform-api/src/platform_api/verification.py`). Set but not importable: startup fails outside `local` |
| `AIG_AGENT_VERIFY_REQUIRE_TRACE` | `false` in `local`/`dev`, else `true` | Without a configured trace check, verification fails (`not_configured`) when this is true |
| `AIG_AGENT_INVOCATION_RETENTION_DAYS` | `90` | Invocation records (metadata only) are deleted after this (by `aig-platform-api invocations purge`, scheduled daily, and opportunistically by the API) |
| `AIG_AGENT_OUTPUT_RETENTION_DAYS` | `30` | Encrypted background outputs are dropped after this (same purge; must not exceed the invocation retention) |
| `AIG_AGENTCORE_REGION` | the AWS SDK default (`AWS_REGION`) | Region of the `bedrock-agentcore` client (AgentCore versions) |
| `AIG_MODEL_GATE_THRESHOLDS_FILE` | `config/model-gate-thresholds.yaml` | Approval-gate thresholds per tier; missing or invalid: startup fails outside `local` (in `local` approvals are refused) |
| `FORWARDED_ALLOW_IPS` | `127.0.0.1` | Docker image: trusted reverse-proxy IPs/CIDRs |

Backend secrets (never in the repo, never returned or logged):

| Secret | Required | Used for |
|---|---|---|
| `PORTKEY_API_KEY` | yes (startup fails outside `local`) | `x-portkey-api-key` on proxied calls |
| `PORTKEY_ADMIN_API_KEY` | no | Portkey analytics (`/api/v1/usage/*`, incl. `by-team`) and, with `AIG_MCP_SYNC=true`, the MCP registry sync |
| `FIDDLER_API_KEY` | no | Forwarding usage events to Fiddler |
| `PORTKEY_WEBHOOK_SECRET` | no (the webhook answers 503 outside `local` without it) | Shared secret Portkey's `aig-agent-check` guardrail sends in `x-aig-webhook-secret` to `POST /api/v1/guardrails/agent-check`; same value as the gateway tool's `AIG_PORTKEY_WEBHOOK_SECRET` |
| `PLATFORM_SERVICE_TOKEN` | no (the service endpoints answer 503 without it, in every env) | Machine callers send it in `x-aig-service-token` (role `service`): `GET /api/v1/agents` (fiddler-sync), `POST /api/v1/agents/{id}/suspend` and `/reinstate` (telemetry-bridge reconciliation), `POST /api/v1/evals` (evals gate), model transitions/scorecards (model harness), `GET /api/v1/workspaces`, `POST /api/v1/workspaces/{id}/claim` and `PATCH /api/v1/workspaces/{id}/status` (workspace orchestrator); same value as `AIG_PLATFORM_SERVICE_TOKEN` there |
| `GITHUB_DISPATCH_TOKEN` | no (canary dispatches are recorded as `failed` without it) | Phase 7: GitHub token allowed to send `repository_dispatch` to `AIG_GITHUB_REPO` (fine-grained, that repo only) |
| `AGENT_CALLER_SIGNING_KEY` | no (agent invocation is disabled outside `local` without it; `local` uses an ephemeral key; a malformed value stops startup) | EC P-256 private key (PEM PKCS#8/SEC1, base64 of the PEM, or PEM with `\n` escapes) that signs the ES256 caller token `x-aig-caller`; public key at `GET /api/v1/caller-token/jwks` |
| `AGENT_OUTPUT_ENCRYPTION_KEY` | no (`mode=background` answers 503 `output_encryption_not_configured` outside `local` without it; `local` uses an ephemeral key) | Fernet key encrypting stored background invocation output |
| `TELEMETRY_BRIDGE_TOKEN` | no (IDE usage events are not forwarded without it) | Bearer token for telemetry-bridge `POST /ingest/ide-usage`; same value as the bridge's `AIG_BRIDGE_INGEST_TOKEN` |

`AIG_ENV` is shared by name. platform-api accepts a subset of the SDK values (no
`workspace`), so its metadata always validates against `metadata.schema.json`.

## Team workspaces (`backend/workspace-orchestrator`, Phase 6)

Full tables: `backend/workspace-orchestrator/README.md`. Values that are empty or contain
`__REPLACE_ME` / `<...>` count as unset; secrets are never logged, put in ECS overrides or sent to
a workspace.

Orchestrator (`workspace-orchestrator serve`):

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local`, `dev`, `stage`, `prod` |
| `AIG_PLATFORM_API_URL` | required | platform-api base URL |
| `AIG_PLATFORM_SERVICE_TOKEN` (secret) | required | = platform-api `PLATFORM_SERVICE_TOKEN` (list, claim, status, agent registration) |
| `AIG_WS_RUNNER` | `local` in local, else `ecs` | `local` (subprocess, no isolation) is refused outside local |
| `AIG_WS_RELAY_SECRET` (secret) | random in local; required elsewhere | HMAC key of the per-workspace relay tokens |
| `AIG_WS_RELAY_PUBLIC_URL` | `http://127.0.0.1:<port>` in local; required elsewhere | URL workspace tasks use to reach the relay |
| `AIG_WS_RELAY_HOST`, `AIG_WS_RELAY_PORT` | `127.0.0.1`/`0.0.0.0`, `8090` | relay bind address |
| `AIG_WS_POLL_INTERVAL_SECONDS` | `10` | worker tick |
| `AIG_WS_MAX_CONCURRENT` | `5` | workspaces per orchestrator |
| `AIG_WS_IDLE_TIMEOUT_MINUTES` | `30` (open item) | no job activity for this long: stop the task, `failed` |
| `AIG_WS_MAX_RUNTIME_MINUTES` | `120` | hard limit per workspace |
| `AIG_WS_WORKER_ID` | hostname | recorded with the claim |
| `AIG_WS_USER_TIER` | `standard` | `user_tier` of the job's gateway calls |
| `AIG_WS_AGENT_OWNER` | first requester of the team | owner of the auto-registered `workspace.<team>` agent |
| `AIG_WS_NOTIFY_URLS`, `AIG_WS_NOTIFY_SECRET` (secret) | none | signed status notifications (Teams bot `POST /api/notify`) |
| `AIG_WS_RECOVER` | `true` | adopt running tasks after a restart, fail lost ones |
| `AIG_WS_LOCAL_WORKDIR`, `AIG_WS_LOCAL_JOB_ENV_FILE` | temp dir, none | local runner only |
| `AIG_WS_ECS_CLUSTER`, `AIG_WS_ECS_TASK_DEFINITION`, `AIG_WS_ECS_SUBNETS`, `AIG_WS_ECS_SECURITY_GROUPS` | required for `ecs` | Fargate placement (private subnets, restricted-egress SG) |
| `AIG_WS_ECS_CONTAINER_NAME`, `AIG_WS_ECS_ASSIGN_PUBLIC_IP`, `AIG_WS_ECS_PLATFORM_VERSION`, `AIG_WS_ECS_CAPACITY_PROVIDER` | `workspace`, `false`, `LATEST`, none | |
| `AIG_WS_ECS_TEAM_TASK_DEFINITIONS` | `{}` | JSON team -> task definition (team Portkey key secret) |
| `AIG_WS_ECS_PORTKEY_SECRET_ARN_TEMPLATE` | none | `{team}`/`{env}` template; derived `<family>-<team>` task definitions |
| `AIG_WS_ECS_LOG_GROUP`, `AIG_WS_ECS_LOG_STREAM_PREFIX` | none, `workspace` | CloudWatch link in `log_url` |

Workspace job (`workspace-job`, set by the orchestrator / task definition): the SDK variables above
with `AIG_AGENT_ID=workspace.<team>`, `AIG_ENV=workspace`, `AIG_HOST=ecs`,
`AIG_PLATFORM_API_URL=<relay>/platform`, `AIG_PLATFORM_API_TOKEN=<relay token>` (the job sets the
last two), plus:

| Variable | Default | Meaning |
|---|---|---|
| `WORKSPACE_ID`, `REPO_URL`, `WORK_ITEM`, `JOB_PROFILE`, `WORKSPACE_TEAM` | orchestrator | the request |
| `AIG_WS_STATUS_URL`, `AIG_WS_STATUS_TOKEN` (secret, per workspace) | orchestrator | relay base URL and token |
| `GITHUB_TOKEN` (secret) or `GITHUB_APP_ID`, `GITHUB_APP_PRIVATE_KEY` (secret), `GITHUB_APP_INSTALLATION_ID` | | GitHub auth (App token scoped to the repo) |
| `GITHUB_API_URL` | `https://api.github.com` | GHES: `https://<host>/api/v3` |
| `AIG_WS_CODE_AGENT` | `claude` | `claude` (Claude Code CLI), `claude-sdk` (Python Claude Agent SDK), `command` |
| `AIG_WS_CLAUDE_BIN`, `AIG_WS_CLAUDE_MODEL`, `AIG_WS_CLAUDE_PERMISSION_MODE`, `AIG_WS_CLAUDE_MAX_BUDGET_USD`, `AIG_WS_AGENT_COMMAND` | `claude`, none, `bypassPermissions`, none, none | code agent options |
| `AIG_WS_SETUP_COMMAND`, `AIG_WS_TEST_COMMAND`, `AIG_WS_FUNCTIONAL_TEST_COMMAND` | auto-detected | shell commands in the repo |
| `AIG_WS_AGENT_TIMEOUT_MINUTES`, `AIG_WS_TEST_TIMEOUT_MINUTES`, `AIG_WS_FIX_ATTEMPTS` | `60`, `30`, `2` | |
| `AIG_WS_EVAL` | `auto` | `off` skips `aig eval run --post` |
| `AIG_WS_COMMIT_EMAIL`, `AIG_WS_PR_DRAFT`, `AIG_WS_HEARTBEAT_SECONDS`, `AIG_WS_WORKDIR` | see README | |

The job passes Claude Code `ANTHROPIC_BASE_URL` (Portkey root), `ANTHROPIC_AUTH_TOKEN` (the team's
Portkey key) and `ANTHROPIC_CUSTOM_HEADERS` (the four contract headers). `ANTHROPIC_API_KEY` stays
forbidden (raw-key guard).

## Teams bot (`backend/teams-bot`, Phase 6)

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | |
| `PORT` | `3978` | |
| `AIG_PLATFORM_API_URL` | required | platform-api base URL (called with the user's token only) |
| `AIG_WEB_URL` | none | portal links on cards |
| `AIG_BOT_AUTH_MODE` | `dev` in local, else `oauth` | `dev` (`dev:<email>`) only with `AIG_ENV=local` |
| `AIG_BOT_OAUTH_CONNECTION` | `aig-platform` | Azure Bot OAuth connection (Teams SSO) |
| `AIG_BOT_DEV_USER` | none | local fallback email |
| `AIG_BOT_NOTIFY_SECRET` (secret) | required outside local | = `AIG_WS_NOTIFY_SECRET` |
| `AIG_BOT_STATE_FILE` | memory | conversation references for proactive messages |
| `MicrosoftAppId`, `MicrosoftAppPassword` (secret), `MicrosoftAppType`, `MicrosoftAppTenantId` | none in local | Azure Bot / Entra app |

## Gateway sync tool (`backend/gateway/tool`, CLI `aigw`)

Read only by `aigw diff` / `aigw apply` (`validate`, `render`, `route` and `matrix` are offline).
Values are never printed; error messages are scrubbed of them.

| Variable | Required | Meaning |
|---|---|---|
| `AIG_PORTKEY_ADMIN_URL` | for diff/apply | Self-hosted Portkey admin API base URL, e.g. `https://portkey-admin.<corp>/v1`. A value containing `__` or `<` counts as unset |
| `AIG_PORTKEY_ADMIN_API_KEY` | for diff/apply | Portkey organisation admin key (sent as `x-portkey-api-key`). Created by hand in Portkey; never committed |
| `AIG_PORTKEY_ENDPOINTS_FILE` | no | YAML overriding admin API paths per object kind (see `backend/gateway/tool/src/aig_gateway/endpoints.py`) |
| `AIG_PORTKEY_WEBHOOK_SECRET` | when creating/updating the `aig-agent-check` guardrail | Value written into the guardrail's `x-aig-webhook-secret` header; must equal platform-api's `PORTKEY_WEBHOOK_SECRET` (env var name set by `secrets.webhook_secret_env` in `backend/gateway/envs/<env>.yaml`) |
| `AIG_PROVIDER_KEY_ANTHROPIC_PROD`, `AIG_PROVIDER_KEY_OPENAI_PROD`, `AIG_PROVIDER_KEY_ANTHROPIC_SANDBOX`, `AIG_PROVIDER_KEY_OPENAI_SANDBOX` | only to **create** that integration | Provider key sent once on create, never on update. Unset: the integration is reported `blocked` (create it in the Portkey UI instead). Never set these where an SDK runs (raw-key guard) |
| `AIGW_ROOT` | no | Path to `backend/gateway` (auto-detected) |

`scripts/gateway-matrix-live.sh` reuses the SDK variables `AIG_PORTKEY_BASE_URL`,
`AIG_PORTKEY_API_KEY` and `AIG_PORTKEY_CONFIG` (skips when the first two are unset), plus
optional `AIG_MATRIX_AGENT_ID` (default `ide.vscode`), `AIG_MATRIX_TEAM`, `AIG_MATRIX_ENV` and
`AIG_MATRIX_STRICT`.

`aigw canary sync --from-platform-api` (Phase 7) also reads `AIG_PLATFORM_API_URL` (or
`--platform-api-url`) and `AIG_PLATFORM_SERVICE_TOKEN` (`GET /api/v1/models`).

## Model harness (`backend/model-harness`, CLI `aig-model`, Phase 7)

| Variable | Required | Meaning |
|---|---|---|
| `AIG_PLATFORM_API_URL` | online runs | platform-api base URL (model, baselines, transition, scorecard PUT). Unset with `--offline`: `--model` is `provider/name@version` |
| `AIG_PLATFORM_SERVICE_TOKEN` | online runs | platform-api service token (`x-aig-service-token`) |
| `AIG_PORTKEY_BASE_URL` | online runs | Portkey gateway; calls always carry `x-portkey-config: pc-aig-sandbox` |
| `AIG_SANDBOX_PORTKEY_API_KEY` | online runs | The `model-sandbox` workspace key (`aig-model-sandbox`). Never a production key |
| `AIG_PORTKEY_API_KEY` | no | Only compared: equal to the sandbox key = refused (exit 2) |
| `AIG_FIDDLER_URL`, `AIG_FIDDLER_API_KEY` | online runs | Fiddler for the experiments (`fiddler-evals`) |
| `AIG_FIDDLER_PROJECT` | no (default `aig-<env>`) | Fiddler project |
| `AIG_FIDDLER_APPLICATION_ID` | no | Fiddler application of the harness (else `model-harness` is created) |
| `AIG_PORTKEY_ADMIN_URL` | no | Portkey analytics for the run's cost (with the sandbox key); unset: usage x `prices.yaml` |
| `AIG_PORTKEY_COST_PATH`, `AIG_PORTKEY_COST_UNIT` | no | Analytics path (default `/analytics/graphs/cost`) and unit (`cents` / `usd`) |
| `AIG_ENV`, `AIGW_ROOT` | no | Gateway env (default `dev`) and `backend/gateway` root for the baseline routing |

## Caching and compression layer (`backend/cache-compress`)

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | Outside `local`, placeholder or non-https upstreams stop startup |
| `AIG_CC_UPSTREAMS_FILE` | `config/upstreams.yaml` | Route -> provider base URL map (`anthropic`, `openai-a`, `openai-b`) |
| `AIG_CC_UPSTREAMS` | none | JSON object that replaces the file map |
| `AIG_CC_TIMEOUT_SECONDS` | `300` | Upstream timeout (read timeout per chunk) |
| `AIG_CC_COMPRESSOR` | `noop` | `noop` or `large-context` (disabled-by-default stub) |
| `AIG_CC_LARGE_CONTEXT_THRESHOLD_BYTES` | `200000` | Size above which the stub would compress |
| `AIG_LOG_LEVEL` | `INFO` | Log level (bodies, header values and query strings are never logged) |

## telemetry-bridge (`backend/telemetry-bridge`)

Read from the process environment, then from the optional env file `AIG_BRIDGE_ENV_FILE`
(process env wins). Values that are empty or contain `__REPLACE_ME` / `<...>` count as unset.
Secrets (marked) are never logged, printed or returned; `/healthz` shows only
`configured|placeholder|missing`. Placeholders: `backend/telemetry-bridge/.env.example`.

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local`, `dev`, `stage` or `prod`. Outside `local` an ingest endpoint without its secret answers 503 |
| `AIG_LOG_LEVEL` | `INFO` | Prompts, replies and secret values are never logged at any level |
| `AIG_BRIDGE_ENV_FILE` | none | Optional dotenv file (run-local.sh uses `.env`) |
| `AIG_BRIDGE_DATABASE_URL` | `sqlite:///services/telemetry-bridge/state/bridge.db` | SQLAlchemy URL (cursor, dedupe, pending, dead letters, guardrail stats); `postgresql+psycopg://...` with the `postgres` extra |
| `AIG_BRIDGE_CONTRACTS_DIR` | repo `backend/contracts/` (image: `/app/contracts`) | Where `tags.schema.json` and `ide-usage-event.schema.json` are read |
| `AIG_FIDDLER_ROOT` | repo `backend/observability` | Trust thresholds and alert routing (also used by fiddler-sync and the platform-api hook) |
| `AIG_BRIDGE_ENDPOINTS_FILE` | none | YAML overriding Portkey / Fiddler / platform-api / PagerDuty paths (`src/telemetry_bridge/endpoints.py`) |
| `FIDDLER_URL` | none | Fiddler base URL (OTLP `/v1/traces`, REST `/v3/*`) |
| `FIDDLER_API_KEY` (secret) | none | Fiddler access token (Bearer) |
| `FIDDLER_PROJECT_TEMPLATE` | `aig-{env}` | Project for an event, from its `env` tag (same names as `AIG_FIDDLER_PROJECT`) |
| `FIDDLER_OTLP_ENCODING` | `protobuf` | `protobuf` (what fiddler-otel sends) or `json` |
| `FIDDLER_FALLBACK_APPLICATION` | none | Application used when the agent has none (else the event is dead-lettered, retryable) |
| `FIDDLER_TIMEOUT_SECONDS` | `30` | Fiddler request timeout |
| `AIG_PORTKEY_ADMIN_URL` | none | Portkey admin/analytics API base (same name as the gateway tool) |
| `AIG_PORTKEY_ADMIN_API_KEY` (secret) | none | Admin key: logs export, analytics, API-key suspension |
| `AIG_PORTKEY_WORKSPACE_ID` | none | Limit the log export to one workspace |
| `AIG_PORTKEY_COST_UNIT` | `cents` | Unit of Portkey's `cost` (`cents` or `usd`), converted to `aig.cost_usd` |
| `AIG_PLATFORM_API_URL` | none | platform-api base URL (agent registry for reconciliation) |
| `AIG_PLATFORM_SERVICE_TOKEN` (secret) | none | = platform-api `PLATFORM_SERVICE_TOKEN` |
| `AIG_BRIDGE_REGISTRY_FILE` | none | Use a registry YAML (platform-api format) instead of platform-api |
| `AIG_BRIDGE_PUSH_SECRET` (secret) | none | `x-aig-bridge-secret` on `POST /ingest/portkey` and `POST /v1/traces` |
| `AIG_BRIDGE_INGEST_TOKEN` (secret) | none | Bearer token on `POST /ingest/ide-usage` (platform-api) |
| `AIG_BRIDGE_PULL_MODE` | `export` | `export` (Logs Export API), `list` (log listing) or `off` (push only) |
| `AIG_BRIDGE_WORKER` | `false` | Run the pull + redelivery loop inside `serve` |
| `AIG_BRIDGE_PULL_INTERVAL_SECONDS` | `60` | Worker interval |
| `AIG_BRIDGE_PULL_OVERLAP_SECONDS` | `300` | Re-read window before the high-water mark (late logs; duplicates are skipped) |
| `AIG_BRIDGE_PULL_LAG_SECONDS` | `60` | Window ends this long before now |
| `AIG_BRIDGE_PULL_MAX_WINDOW_SECONDS` | `3600` | Largest window per run (catch-up in steps) |
| `AIG_BRIDGE_PULL_INITIAL_LOOKBACK_SECONDS` | `3600` | First run without a cursor |
| `AIG_BRIDGE_EXPORT_MAX_WAIT_SECONDS` | `300` | How long to wait for a Portkey export |
| `AIG_BRIDGE_REDACT_MODE` | `pii` | Prompt/reply handling: `pii` (mask), `hash`, `drop`, `none` |
| `AIG_BRIDGE_MAX_CONTENT_CHARS` | `32000` | Truncation of prompt/reply text |
| `AIG_BRIDGE_RETRY_ATTEMPTS` | `4` | In-request attempts per delivery/API call |
| `AIG_BRIDGE_RETRY_BACKOFF_SECONDS` | `0.5` | Base of the exponential backoff (full jitter) |
| `AIG_BRIDGE_MAX_DELIVERY_ATTEMPTS` | `20` | Deliveries before a pending event is dead-lettered (`delivery_exhausted`) |
| `AIG_BRIDGE_MAX_BATCH` | `1000` | Logs per `POST /ingest/portkey` |
| `AIG_BRIDGE_RECONCILE_PROJECTS` | `aig-<AIG_ENV>` | Comma-separated Fiddler projects counted per agent (dev may add `aig-local,aig-workspace`) |
| `AIG_BRIDGE_RECONCILE_MIN_REQUESTS` | `1` | Gateway requests that make an agent subject to the check |
| `AIG_BRIDGE_RECONCILE_MIN_SPANS` | `1` | Fewer SDK spans than this is a violation |
| `AIG_BRIDGE_RECONCILE_MIN_INVOCATIONS` | `1` | Registry invocations (platform-api records, one day) at which an agent without SDK spans is `untraced_invocations` |
| `AIG_BRIDGE_RECONCILE_INVOCATION_ENV` | `prod` | Version environment whose invocations reconciliation checks (`GET /api/v1/invocations/summary?env=`) |
| `AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS` | `false` | `true`: suspend `untraced_invocations` agents through the reconciliation suspension path (report-only otherwise; never with `--dry-run`) |
| `AIG_BRIDGE_RECONCILE_MIN_TRACE_RATIO` | `0` | Optional: SDK spans / requests below this is a violation (0 = off) |
| `AIG_BRIDGE_RECONCILE_EXEMPT_AGENTS` | `ide.vscode,ide.eclipse,web.portal` | Never suspended by reconciliation |
| `AIG_BRIDGE_AGENT_KEY_NAME_TEMPLATE` | `aig-agent-{agent_id}` | Portkey API key name of an agent (when the registry has no `portkey_api_key_id`) |
| `AIG_BRIDGE_TEAM_KEY_NAME_TEMPLATE` | `aig-{team}-agents` | Team key name, used only with the fallback below |
| `AIG_BRIDGE_SUSPEND_TEAM_KEY_FALLBACK` | `false` | Suspend the shared team key when the agent has no own key (blocks the whole team) |
| `AIG_BRIDGE_SMTP_HOST`, `AIG_BRIDGE_SMTP_PORT` (`587`), `AIG_BRIDGE_SMTP_USER`, `AIG_BRIDGE_SMTP_FROM`, `AIG_BRIDGE_SMTP_STARTTLS` (`true`) | none | Email alerts; `AIG_BRIDGE_SMTP_PASSWORD` (secret) |
| `AIG_ALERT_SLACK_WEBHOOK_PLATFORM`, `AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING`, `AIG_ALERT_SLACK_WEBHOOK_CLAIMS` (secrets) | none | Slack incoming webhooks named by `backend/observability/manifests/alerts.yaml` (`webhook_env`) |
| `AIG_ALERT_PAGERDUTY_ROUTING_KEY` (secret) | none | PagerDuty Events API v2 routing key (`routing_key_env`) |
| `AIG_BRIDGE_EVAL_DATASET_DIR` | `eval-datasets` | `export-failing` output directory |
| `AIG_BRIDGE_REPORTS_DIR` | `reports` | Reconciliation reports and guardrail tickets |

## Fiddler provisioning tool (`backend/observability/tool`, CLI `fiddler-sync`)

Read only by `diff`, `apply` and `provision-agent` (`validate` and `render` are offline, except
`render` with a platform-api registry). Values are never printed.

| Variable | Required | Meaning |
|---|---|---|
| `FIDDLER_URL` | no | Overrides the env overlay's `fiddler_url` |
| `FIDDLER_API_KEY` | for diff/apply | Fiddler access token (Bearer) |
| `AIG_PLATFORM_SERVICE_TOKEN` | when the overlay reads `registry.url` | platform-api `PLATFORM_SERVICE_TOKEN` (`GET /api/v1/agents`) |
| `AIG_ALERT_SLACK_WEBHOOK_*` | to create the Slack webhooks | Sent once on create; unset = `blocked` |
| `AIG_FIDDLER_ROOT` | no | Path to `backend/observability` (auto-detected in a checkout) |
| `AIG_FIDDLER_ENDPOINTS_FILE` | no | YAML overriding Fiddler API paths (`tool/src/aig_fiddler/endpoints.py`) |


## Agent runtimes on Bedrock AgentCore (`infra/terraform/modules/agentcore-runtime`)

| Variable | Set by | Meaning |
|---|---|---|
| `AIG_RUNTIME_SECRET_ARN` | Terraform (agent runtime env) | ARN of the agent's Secrets Manager secret `aig/<env>/agents/<agent_id>`. The AgentCore entrypoint (`infra/ci/docker/*entrypoint*`) reads `AIG_PORTKEY_API_KEY` / `AIG_FIDDLER_API_KEY` from it at start-up, so no secret value is ever placed in the runtime environment or image. Non-secret `AIG_*` values (agent id, team, env=`prod`/`stage`/`dev`, host=`agentcore`, gateway/Fiddler URLs) are set directly. See `docs/deploy.md`. |
| `AIG_CALLER_JWKS_URL` | Terraform (agent runtime env), optional | platform-api caller-token JWKS (default `{AIG_PLATFORM_API_URL}/api/v1/caller-token/jwks`). The serve helpers verify every `aig-http/1` invocation's caller token against it |
| `AIG_CALLER_PUBLIC_KEY` | optional | PEM public key used instead of the JWKS URL (no network fetch); meant for offline tests, not set by Terraform |

Image and runtime facts the invocation path relies on:

- The agent image copies the project's `aig-agent.yaml` next to the entrypoint shim (`/opt/aig/`
  in Python images, `/app/.aig/` in Node images), so `GET /schema` and input validation use the
  same descriptor that deploy auto-registration sent to platform-api.
- The runtime's request-header allow-list contains `X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller`,
  `...-Custom-Aig-Invocation-Id` and `...-Custom-Aig-Trace-Id` (AgentCore forwards only allow-listed
  custom headers), and the runtime is tagged `aig:registered=true` (`registry_invocable`) so
  platform-api's task role may call `InvokeAgentRuntime` on it (tag-scoped IAM in `modules/platform-services`).
