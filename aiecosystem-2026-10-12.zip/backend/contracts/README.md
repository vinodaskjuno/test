# backend/contracts/

The single source of truth for what every AIG component puts on the wire. The Python SDK
(`sdk/python`, Phase 2), the TypeScript SDK (`sdk/typescript`, Phase 2), `backend/platform-api`
and the IDE clients must all follow it. **Change the contract first**, then the implementations.

| File | What it defines |
|---|---|
| [`metadata.schema.json`](metadata.schema.json) | Decoded `x-portkey-metadata` (JSON Schema 2020-12): `user_tier`, `job_profile`, `agent_id`, `team`, `env`, `host`, `user`, `_user`, `trace_id`, and for agents invoked through the registry the optional `caller_user`, `caller_team`, `invocation_id` |
| [`tags.schema.json`](tags.schema.json) | Fiddler / OTel span tags: `agent`, `team`, `tier`, `model`, `env`, `host`, `aig.trace_id`, `aig.user` |
| [`headers.md`](headers.md), [`headers.schema.json`](headers.schema.json) | Portkey headers an SDK emits (and their canonical encoding), the `x-aig-*` client headers to platform-api, forbidden headers |
| [`ide-usage-event.schema.json`](ide-usage-event.schema.json) | IDE token-usage event (VS Code, Eclipse, web) that platform-api sends to `backend/telemetry-bridge` `POST /ingest/ide-usage`; token usage only, never prompts |
| [`invocation-event.schema.json`](invocation-event.schema.json) | Finished agent invocation (metadata only: who, agent, version, env, mode, status, duration, tokens, trace id) that platform-api sends to `backend/telemetry-bridge` `POST /ingest/invocation`; never inputs, outputs or caller tokens |
| [`agent-invocation.md`](agent-invocation.md), [`agent-invocation.schema.json`](agent-invocation.schema.json) | Agent invocation protocol `aig-http/1` between platform-api and agent servers (AgentCore or HTTPS): `POST /invocations` request (`input`/`messages`, `session_id`, `stream`), `x-aig-caller` ES256 caller token + claims, `x-aig-invocation-id`, `x-aig-trace-id`, JSON response, SSE events `delta|output|error|done`, `GET /ping`, optional `GET /schema` |
| [`agent-record.schema.json`](agent-record.schema.json) | Agent registry v2 record (lifecycle, tags, access, org approval), per-environment versions (kind, endpoint/runtime ARN, schemas, auth *reference*, verification) and the invocation record |
| [`env-vars.md`](env-vars.md) | Every `AIG_*` variable for the SDKs, the backend, telemetry-bridge and fiddler-sync; fail-closed rules (there is no `AIG_FAIL_OPEN`) |
| [`errors.md`](errors.md) | SDK fail-closed codes (`AIG_E_*`) and the platform-api HTTP/WebSocket codes already in use |
| [`fixtures/`](fixtures/) | Golden cases: input (env vars + call options, or platform-api state + request headers) to expected headers, span tags or error |
| [`fixture.schema.json`](fixture.schema.json) | Shape of a fixture file |
| [`../gateway/simulation/agent-check-cases.json`](../gateway/simulation/agent-check-cases.json) | Shared cases for the agent-check webhook guardrail: platform-api's real endpoint and the gateway tool's simulator must both agree with them |
| [`scripts/reference.py`](scripts/reference.py) | Executable reference model of the rules (pure Python, no dependencies) |
| [`scripts/check_contracts.py`](scripts/check_contracts.py) | The contract check run by `make contracts` and CI |

## Running the check

```bash
make contracts          # creates backend/contracts/.venv with jsonschema on first run
# or
python3 -m venv backend/contracts/.venv && backend/contracts/.venv/bin/pip install -r backend/contracts/requirements.txt
backend/contracts/.venv/bin/python backend/contracts/scripts/check_contracts.py
```

It verifies that:

1. every `*.schema.json` is valid JSON Schema 2020-12;
2. every fixture matches `fixture.schema.json` and its file name;
3. expected headers validate against `headers.schema.json`, the decoded metadata against
   `metadata.schema.json` and span tags against `tags.schema.json`;
4. `x-portkey-metadata` is canonical (compact, sorted keys) and agrees field by field with the
   span tags, and `aig.trace_id` equals `x-portkey-trace-id`;
5. `scripts/reference.py` reproduces every fixture's `expected` block exactly;
6. every `AIG_*` variable and error code that fixtures use is documented;
7. `agent_invocation` fixtures: request headers/body and caller-token claims validate against
   `agent-invocation.schema.json`, stream events against its `sse_event`, error codes are documented.

## Fixture kinds

| Kind | Input | Expected | Who must pass it |
|---|---|---|---|
| `sdk` | `env` (process environment) + `call` (per-call options; `otel_trace_id` simulates an active span) | `portkey_headers` + `span_tags`, or `error` (`code`, `field`) | Python and TypeScript SDK contract tests (Phase 2, passing) |
| `backend_client` | `call` (job profile, agent id, trace id) | `backend_headers` (`x-aig-*`), or `error` | `@aig/sdk/platform` (backend mode of the TS SDK, used by the VSIX and the web portal: `sdk/typescript/test/platform/core.test.ts`, both dist bundles, and `scripts/cross-sdk-contract.sh`), Eclipse plugin (Java contract tests) |
| `platform_api` | `server` (AIG_ENV, config id, allowed job profiles, user-directory entry) + `request_headers` | `portkey_headers`, or `error` (`code`, `http_status`) | `backend/platform-api/tests/test_contracts.py` (HTTP proxy and WebSocket chat) |
| `agent_invocation` | `invocation`: `case: request` (platform env, signing time, caller, agent version + input schema, client body, mode, client trace id, invocation id), `case: stream` (raw SSE from an agent) or `case: response` (agent status + JSON body) | `agent_request` (transport, headers with `<signed:caller-token>`, body, AgentCore `runtime_session_id`) + `caller_token` (header with `<signing-key:kid>`, claims); or `events` + `result`; or `result`; or `error` (`code`, `field`, `http_status`) | `backend/platform-api/tests/test_agent_invocation_contract.py` (request building, SSE parsing, answer mapping); SDK serve helpers (W3) for verification/streaming |

Markers: `<signed:caller-token>` is the ES256 caller token platform-api signs (compare its decoded
claims with `expected.caller_token.claims`) and `<signing-key:kid>` the RFC 7638 thumbprint of the
signing key. `<generated:uuid4>` means the implementation generates a fresh UUID v4 (tests compare
by shape); `<server-secret:PORTKEY_API_KEY>` stands for platform-api's configured key. Fixture
key values such as `__TEST_PORTKEY_API_KEY__` are deliberately placeholder-shaped so gitleaks
never flags them.

## How an SDK uses the fixtures (Phase 2)

For each `sdk` fixture: start from an empty environment, apply `input.env`, call the SDK's
header/tag builder with `input.call`, then compare. For success cases, headers and tags must
be byte-identical (allowing the markers). For error cases, the error code and `field` must
match. Python and TypeScript run the same files, which is how "both SDKs emit identical
headers and tags" is enforced.

### Conformance status (Phase 2)

Both SDKs are conformance-tested against every `kind: sdk` fixture:

- Python: `sdk/python/tests/test_contract_fixtures.py` (pure builder, `init()` plus a real
  request recorded on the wire, and the error cases through `init()` / per call);
- TypeScript: `sdk/typescript/test/contract.test.ts` (the same three levels);
- cross-SDK: `scripts/cross-sdk-contract.sh` (`make cross-sdk`) dumps every fixture result from
  `python -m aig_sdk.conformance` and `node sdk/typescript/dist/conformance.{cjs,js}` and requires
  Python == TypeScript (CJS and ESM) == the fixtures' `expected`, byte for byte.

### Backend mode (`@aig/sdk/platform`)

The VS Code extension and the web portal no longer carry their own copies of the client headers,
WebSocket frames or SSE parsing: they use the TypeScript SDK's backend mode, whose shared contract
core (`sdk/typescript/src/core`) reproduces every `kind: backend_client` fixture byte for byte
(values and key order). `scripts/cross-sdk-contract.sh` also dumps them with
`node sdk/typescript/dist/conformance.{cjs,js} --kind backend_client` and requires equality with the
fixtures' `expected`. The SDK's REST types are generated from `platform-api.openapi.json`
(`sdk/typescript/src/platform/openapi.d.ts`; a test fails when it is stale). Agent mode (`kind: sdk`)
output is unchanged. See [`docs/sdk-modes.md`](../../docs/sdk-modes.md).

## Adding or changing a rule

1. Edit the schema / markdown, and `scripts/reference.py` if behaviour changes.
2. Add or update fixtures (hand-write `input`; `expected` must be what the reference model
   produces, and review it by eye, because the fixture is the golden value).
3. Run `make contracts`, then update platform-api and the SDKs until `make test` passes.

## Open points

- Resolved (Phase 1): `agent_id` is now **required for every host**. platform-api sends the
  client's `x-aig-agent-id`, or the host's pre-registered agent (`ide.vscode` today;
  `ide.eclipse` and `web.portal` are reserved for the Eclipse plugin and web portal). The gateway
  enforces it with required metadata plus the `aig-agent-check` webhook guardrail
  (`POST /api/v1/guardrails/agent-check`), which denies unknown or suspended agents.
- Resolved (Phase 1): platform-api validates its user directory on load (tier
  `premium|standard|free`, slug-shaped team); invalid entries stop startup outside `local`.
- Values are unverified against a live Portkey/Fiddler: confirm that the self-hosted Portkey
  version supports required metadata and the `_user` key, and the Fiddler tag names.
