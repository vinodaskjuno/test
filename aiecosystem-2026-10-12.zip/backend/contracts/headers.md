# Header contract

Machine-readable version: [`headers.schema.json`](headers.schema.json). Header names are
lower-case. Transport headers (`content-type`, `accept`, `user-agent`, ...) are outside the
contract.

There are two paths to the gateway, and each has its own header set:

```
SDK agent (laptop, VDI, ECS, AgentCore, CI) ──── Portkey headers ────────────────▶ Portkey
IDE / web client ── x-aig-* hints ──▶ platform-api ── Portkey headers ─▶ Portkey
```

## 1. SDK (or platform-api) to Portkey

Both SDKs must emit these four headers on every model call, **byte-identical** for the same
inputs. platform-api emits the same four on behalf of IDE users.

| Header | Value | Source |
|---|---|---|
| `x-portkey-api-key` | Portkey workspace API key | SDK: `AIG_PORTKEY_API_KEY`. platform-api: `PORTKEY_API_KEY` from its key broker. Never a provider key |
| `x-portkey-config` | Portkey config id | `AIG_PORTKEY_CONFIG`, default `pc-aig-router` (platform-api: `portkey_config_id` in its environment YAML) |
| `x-portkey-metadata` | Canonical JSON, see below | Validates against [`metadata.schema.json`](metadata.schema.json) |
| `x-portkey-trace-id` | Trace id, `^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$` | See "Trace id" below |

### `x-portkey-metadata` encoding (canonical JSON)

- Compact: separators `,` and `:` with no whitespace.
- Keys sorted by code point (`_user` sorts before `agent_id`).
- All values are ASCII strings (the schema patterns guarantee it), so there are no escaping
  differences between Python `json.dumps(..., sort_keys=True, separators=(",", ":"))` and
  TypeScript `JSON.stringify` of an object built with sorted keys.
- Optional keys are **omitted**, never sent as `null` or `""`.
- `_user` (Portkey's reserved per-user analytics key) is present exactly when `user` is, with
  the same value.

Example (SDK on a laptop, `AIG_USER` set):

```
x-portkey-metadata: {"_user":"jane.doe@example.com","agent_id":"uw-quote-assistant","env":"local","host":"laptop","job_profile":"claims","team":"underwriting-ai","user":"jane.doe@example.com","user_tier":"premium"}
```

### Where each metadata field comes from

| Field | SDK | platform-api |
|---|---|---|
| `user_tier` | call option, else `AIG_USER_TIER` (no default: missing is an error) | user directory (`config/users.yaml`), never the client |
| `job_profile` | call option, else `AIG_JOB_PROFILE`, else `general` | `x-aig-job-profile`, default `general`, must be in `allowed_job_profiles` |
| `agent_id` | `AIG_AGENT_ID` (required) | `x-aig-agent-id` if sent, else the host's pre-registered agent (`ide.vscode` for host `vscode`; `ide.eclipse` / `web.portal` reserved). Always present |
| `team` | `AIG_TEAM` | user directory (`unassigned` default) |
| `env` | `AIG_ENV` (`local`, `workspace`, `dev`, `stage`, `prod`) | its own `AIG_ENV` (`local`, `dev`, `stage`, `prod`) |
| `host` | `AIG_HOST` (`laptop`, `vdi`, `ecs`, `agentcore`, `ci`) | `vscode` today (`eclipse`/`web` when those clients ship) |
| `user`, `_user` | `AIG_USER` (optional) | signed-in user's email |

Callers cannot override `agent_id`, `team`, `env` or `host` per call.

### Trace id

Precedence: explicit call option, then the active OpenTelemetry trace id (32 hex chars), then
a newly generated UUID v4. A value that does not match the trace-id pattern is ignored (not an
error), which is the same rule platform-api applies to `x-aig-trace-id`. The same id goes into
the Fiddler span as `aig.trace_id`, so Portkey logs and Fiddler traces join on one id.

### Forbidden headers

SDKs must never send `x-portkey-provider`, `x-portkey-virtual-key`, `x-portkey-custom-host` or
`x-portkey-forward-headers`: the routing config owns provider selection, provider keys and the
caching-layer `custom_host`. If an OpenAI-compatible client library insists on an
`Authorization` header, it may carry only the Portkey API key or a non-secret placeholder,
never a provider key.

## 2. Client (VSIX, Eclipse, web) to platform-api

`POST /api/v1/llm/chat/completions` (and the `chat` WebSocket frame, which carries the same
values as `job_profile` / `agent_id` fields).

| Header | Required | Rule |
|---|---|---|
| `authorization` | yes | `Bearer <Entra ID token>` (or `Bearer dev:<email>` on a local dev-mode backend). Auth, outside this contract |
| `x-aig-job-profile` | yes (client default `general`) | One of `underwriting`, `claims`, `operations`, `general`; the backend also checks the environment's `allowed_job_profiles` (400 `invalid_job_profile`) |
| `x-aig-agent-id` | no | `^[A-Za-z0-9._-]{1,64}$` (400 `invalid_agent_id`). When absent, platform-api sends the host's pre-registered agent (`ide.vscode`), so `agent_id` reaches the gateway on every call |
| `x-aig-trace-id` | yes (client generates a UUID v4 if it has none) | Invalid values are replaced by the backend with a new UUID; the response echoes the id in `x-aig-trace-id` |

Clients never send `x-portkey-*` headers; platform-api strips every client `x-portkey-*` and
`Authorization` header and builds the outbound headers from an allow-list.

## Fixtures

Golden cases live in [`fixtures/`](fixtures/). `<generated:uuid4>` means "a fresh UUID v4 here";
`<server-secret:PORTKEY_API_KEY>` means "platform-api's configured key".
