/**
 * Adaptive Cards (schema 1.5) for the agent catalog and agent runs: catalog list, input form
 * generated from a version's `input_schema`, chat prompt, result card, friendly error texts
 * (backend/contracts/errors.md).
 */

import { type Attachment, CardFactory } from 'botbuilder';
import { fields } from './schema.js';
import type { CatalogItem, CatalogVersion, Usage } from './platform.js';

const SCHEMA = 'http://adaptivecards.io/schemas/adaptive-card.json';
/** Agents shown in one list card (Teams cards are limited to about 28 KB). */
export const LIST_LIMIT = 15;
/** Output characters shown in a result card. */
export const OUTPUT_LIMIT = 12000;

/** Submit verbs (Action.Submit `data.action`). */
export const VERB_FORM = 'agent.form';
export const VERB_RUN = 'agent.run';
/** Input ids that are not schema properties. */
export const BACKGROUND_INPUT = 'aig.background';
export const MESSAGE_INPUT = 'aig.message';

function adaptive(body: any[], actions: any[] = []): Attachment {
  return CardFactory.adaptiveCard({ $schema: SCHEMA, type: 'AdaptiveCard', version: '1.5', body, ...(actions.length ? { actions } : {}) });
}

function truncate(s: string, n: number): string {
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

export function versionLabel(v: Pick<CatalogVersion, 'version' | 'env'>): string {
  return `${v.version} (${v.env})`;
}

function runData(item: CatalogItem, v: CatalogVersion, verb: string, extra: Record<string, unknown> = {}) {
  return { action: verb, agent_id: item.agent.agent_id, env: v.env, version: v.version, ...extra };
}

// -- catalog ------------------------------------------------------------------------------------

export function agentsListCard(items: CatalogItem[], query?: string, webUrl?: string): Attachment {
  const heading = query ? `Agents matching "${truncate(query, 60)}"` : 'Agents you can run';
  const body: any[] = [
    { type: 'TextBlock', text: `${heading} (${items.length})`, size: 'Large', weight: 'Bolder', wrap: true },
  ];
  if (!items.length) {
    body.push({ type: 'TextBlock', text: query ? 'No agents match. Try another word, or `agents` for all.' : 'No agents are available to you yet.', wrap: true, isSubtle: true });
    return adaptive(body);
  }
  for (const item of items.slice(0, LIST_LIMIT)) {
    const a = item.agent;
    const d = item.default;
    const status = [a.lifecycle, a.status && a.status !== 'active' ? a.status : undefined].filter(Boolean).join(', ') || 'active';
    const actions: any[] = [{ type: 'Action.Submit', title: 'Run', data: runData(item, d, VERB_FORM) }];
    if (webUrl) actions.push({ type: 'Action.OpenUrl', title: 'Details', url: `${webUrl}/agents/${encodeURIComponent(a.agent_id)}` });
    body.push({
      type: 'Container',
      separator: true,
      spacing: 'Medium',
      items: [
        { type: 'TextBlock', text: a.name || a.agent_id, weight: 'Bolder', wrap: true },
        { type: 'TextBlock', text: a.agent_id, isSubtle: true, size: 'Small', spacing: 'None', fontType: 'Monospace' },
        ...(a.description ? [{ type: 'TextBlock', text: truncate(a.description, 300), wrap: true, spacing: 'Small' }] : []),
        {
          type: 'FactSet',
          facts: [
            { title: 'Team', value: a.team },
            { title: 'Default', value: versionLabel(d) },
            { title: 'Status', value: status },
          ],
        },
        { type: 'ActionSet', actions },
      ],
    });
  }
  if (items.length > LIST_LIMIT) {
    body.push({ type: 'TextBlock', text: `${items.length - LIST_LIMIT} more - narrow it down with \`agents <word>\`.`, wrap: true, isSubtle: true });
  }
  return adaptive(body);
}

// -- input ----------------------------------------------------------------------------------------

function header(item: CatalogItem, v: CatalogVersion): any[] {
  return [
    { type: 'TextBlock', text: `Run ${item.agent.name || item.agent.agent_id}`, size: 'Large', weight: 'Bolder', wrap: true },
    { type: 'TextBlock', text: `${item.agent.agent_id} · ${versionLabel(v)} · ${item.agent.team}`, isSubtle: true, size: 'Small', spacing: 'None', wrap: true },
    ...(item.agent.description ? [{ type: 'TextBlock', text: truncate(item.agent.description, 300), wrap: true }] : []),
  ];
}

function errorBlock(errors?: string[]): any[] {
  return errors?.length ? [{ type: 'TextBlock', text: errors.map((e) => `- ${e}`).join('\n'), color: 'Attention', wrap: true }] : [];
}

const backgroundToggle = (on = false) => ({
  type: 'Input.Toggle', id: BACKGROUND_INPUT, title: 'Run in the background (I post the result here when it is done)', value: on ? 'true' : 'false', valueOn: 'true', valueOff: 'false',
});

/** A form generated from the version's input schema. */
export function agentFormCard(item: CatalogItem, v: CatalogVersion, opts: { prefill?: Record<string, unknown>; errors?: string[]; background?: boolean } = {}): Attachment {
  const body: any[] = [...header(item, v), ...errorBlock(opts.errors)];
  for (const f of fields(v.input_schema)) {
    const given = opts.prefill?.[f.name];
    const value = given !== undefined ? given : f.default;
    const common: Record<string, unknown> = { id: f.id, label: f.label, ...(f.required ? { isRequired: true, errorMessage: `${f.label} is required` } : {}) };
    switch (f.kind) {
      case 'boolean':
        body.push({ type: 'Input.Toggle', ...common, title: f.description ?? f.label, value: String(value) === 'true' ? 'true' : 'false', valueOn: 'true', valueOff: 'false' });
        break;
      case 'number':
      case 'integer':
        body.push({
          type: 'Input.Number', ...common,
          ...(f.minimum !== undefined ? { min: f.minimum } : {}),
          ...(f.maximum !== undefined ? { max: f.maximum } : {}),
          ...(value !== undefined && value !== '' && Number.isFinite(Number(value)) ? { value: Number(value) } : {}),
          ...(f.kind === 'integer' ? { placeholder: 'whole number' } : {}),
        });
        break;
      case 'choice':
        body.push({
          type: 'Input.ChoiceSet', ...common, style: 'compact',
          choices: f.choices!.map((c) => ({ title: String(c), value: String(c) })),
          ...(value !== undefined ? { value: String(value) } : {}),
        });
        break;
      case 'json':
        body.push({
          type: 'Input.Text', ...common, isMultiline: true, placeholder: 'JSON',
          ...(value !== undefined ? { value: typeof value === 'string' ? value : JSON.stringify(value, null, 2) } : {}),
        });
        break;
      default:
        body.push({
          type: 'Input.Text', ...common,
          ...(f.multiline ? { isMultiline: true } : {}),
          ...(f.maxLength !== undefined ? { maxLength: f.maxLength } : {}),
          ...(f.pattern ? { regex: f.pattern } : {}),
          ...(value !== undefined ? { value: String(value) } : {}),
        });
    }
    if (f.description && f.kind !== 'boolean') body.push({ type: 'TextBlock', text: truncate(f.description, 300), size: 'Small', isSubtle: true, wrap: true, spacing: 'None' });
  }
  body.push(backgroundToggle(opts.background));
  return adaptive(body, [{ type: 'Action.Submit', title: 'Run', data: runData(item, v, VERB_RUN) }]);
}

/** Chat-mode agent (no input schema): one message box. */
export function chatPromptCard(item: CatalogItem, v: CatalogVersion, opts: { errors?: string[]; message?: string } = {}): Attachment {
  return adaptive(
    [
      ...header(item, v),
      ...errorBlock(opts.errors),
      { type: 'Input.Text', id: MESSAGE_INPUT, label: 'Message', isMultiline: true, isRequired: true, errorMessage: 'Type a message', ...(opts.message ? { value: opts.message } : {}) },
      backgroundToggle(),
    ],
    [{ type: 'Action.Submit', title: 'Send', data: runData(item, v, VERB_RUN) }],
  );
}

// -- result ---------------------------------------------------------------------------------------

/** A finished run: from a sync invoke or a polled background invocation. */
export interface RunOutcome {
  invocation_id: string;
  agent_id: string;
  agent_name?: string;
  version: string;
  env: string;
  status: string;
  output?: unknown;
  usage?: Usage | null;
  trace_id?: string | null;
  duration_ms?: number | null;
  error_code?: string | null;
  error_message?: string | null;
}

const RUN_COLOR: Record<string, string> = { succeeded: 'Good', failed: 'Attention', timeout: 'Attention', cancelled: 'Warning' };

export function duration(ms?: number | null): string | undefined {
  if (ms === undefined || ms === null) return undefined;
  return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1)} s`;
}

function usageText(u?: Usage | null): string | undefined {
  if (!u) return undefined;
  const parts: string[] = [];
  if (u.prompt_tokens !== undefined) parts.push(`${u.prompt_tokens} in`);
  if (u.completion_tokens !== undefined) parts.push(`${u.completion_tokens} out`);
  const total = u.total_tokens ?? (u.prompt_tokens ?? 0) + (u.completion_tokens ?? 0);
  return parts.length ? `${total} (${parts.join(', ')})` : String(total);
}

function isFlat(o: unknown): o is Record<string, unknown> {
  if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
  const values = Object.values(o);
  return values.length > 0 && values.length <= 25 && values.every((v) => v === null || ['string', 'number', 'boolean'].includes(typeof v));
}

export function outputBlocks(output: unknown): any[] {
  if (output === undefined || output === null) return [{ type: 'TextBlock', text: '(no output)', isSubtle: true, wrap: true }];
  if (typeof output === 'string') return [{ type: 'TextBlock', text: truncate(output, OUTPUT_LIMIT) || '(empty)', wrap: true }];
  if (isFlat(output)) {
    return [{ type: 'FactSet', facts: Object.entries(output).map(([k, v]) => ({ title: k, value: truncate(v === null ? 'null' : String(v), 1000) })) }];
  }
  return [{ type: 'TextBlock', text: truncate(JSON.stringify(output, null, 2), OUTPUT_LIMIT), wrap: true, fontType: 'Monospace', size: 'Small' }];
}

export function resultCard(r: RunOutcome, webUrl?: string, heading?: string): Attachment {
  const ok = r.status === 'succeeded';
  const body: any[] = [
    { type: 'TextBlock', text: heading ?? 'Agent run', size: 'Small', isSubtle: true, wrap: true },
    { type: 'TextBlock', text: r.agent_name || r.agent_id, size: 'Large', weight: 'Bolder', wrap: true },
    { type: 'TextBlock', text: ok ? 'Succeeded' : r.status.charAt(0).toUpperCase() + r.status.slice(1), color: RUN_COLOR[r.status] ?? 'Accent', weight: 'Bolder', wrap: true },
  ];
  if (ok) body.push(...outputBlocks(r.output));
  else body.push({ type: 'TextBlock', text: friendlyError(r.error_code ?? (r.status === 'timeout' ? 'invocation_timeout' : r.status === 'cancelled' ? 'invocation_cancelled' : 'agent_error'), r.error_message ?? undefined), color: 'Attention', wrap: true });
  const facts = [
    { title: 'Version', value: versionLabel(r) },
    { title: 'Duration', value: duration(r.duration_ms) },
    { title: 'Tokens', value: usageText(r.usage) },
    { title: 'Trace id', value: r.trace_id ?? undefined },
    { title: 'Run id', value: r.invocation_id },
  ].filter((f): f is { title: string; value: string } => Boolean(f.value));
  body.push({ type: 'FactSet', separator: true, facts });
  const actions: any[] = [{ type: 'Action.Submit', title: 'Run again', data: { action: VERB_FORM, agent_id: r.agent_id, env: r.env, version: r.version } }];
  if (webUrl) actions.push({ type: 'Action.OpenUrl', title: 'Open in AIG portal', url: `${webUrl}/agents/${encodeURIComponent(r.agent_id)}` });
  return adaptive(body, actions);
}

// -- errors ---------------------------------------------------------------------------------------

const FRIENDLY: Record<string, string> = {
  agent_forbidden: 'You are not allowed to run this agent. Ask the owning team for access.',
  agent_not_invocable: 'This agent cannot run right now (it is suspended, a draft, retired or has no verified version).',
  org_approval_required: 'This agent is shared org-wide but is still waiting for platform-admin approval.',
  input_invalid: 'The agent rejected the input.',
  agent_unavailable: 'The agent could not be reached. Please try again later.',
  agent_error: 'The agent failed while answering.',
  invocation_timeout: 'The agent did not answer in time. For long tasks use `run --background <agent> <input>`.',
  platform_timeout: 'The agent did not answer in time. For long tasks use `run --background <agent> <input>`.',
  invocation_cancelled: 'The run was cancelled.',
  version_not_found: 'That version of the agent does not exist in this environment (or it was retired).',
  agent_not_found: 'No such agent. Type `agents` to see the agents you can run.',
  invocation_not_found: 'That run was not found (or you cannot see it).',
};

/** Detail from the server is worth showing for these (it names the field or version). */
const WITH_DETAIL = new Set(['input_invalid', 'version_not_found']);

export function friendlyError(code: string, message?: string): string {
  const base = FRIENDLY[code];
  if (!base) return message ? `${message} (${code})` : `The run failed (${code}).`;
  return WITH_DETAIL.has(code) && message ? `${base} ${truncate(message, 300)}` : base;
}
