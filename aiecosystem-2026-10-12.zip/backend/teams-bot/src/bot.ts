/**
 * The AIG Teams bot: start / status / list / cancel team workspaces, and discover / run agents
 * (`agents`, `run`), on behalf of the signed-in Teams user (their own platform-api token; never
 * the service token).
 */

import {
  type Attachment,
  type SigninStateVerificationQuery,
  TeamsActivityHandler,
  type TurnContext,
  TurnContext as TC,
} from 'botbuilder';
import {
  agentFormCard, agentsListCard, BACKGROUND_INPUT, chatPromptCard, friendlyError, MESSAGE_INPUT, resultCard, VERB_FORM, VERB_RUN,
} from './agentCards.js';
import type { UserAuth } from './auth.js';
import { BackgroundRuns, type PollerOptions } from './background.js';
import { listText, shortId, startFormCard, workspaceCard } from './cards.js';
import { type Command, HELP, parseCommand } from './commands.js';
import type { Proactive } from './notify.js';
import {
  type CatalogItem, type CatalogVersion, type InvokeBody, JOB_PROFILES, type PlatformClient, PlatformError, type Workspace, type WorkspaceCreate,
} from './platform.js';
import { isChatMode, planRun, validateSubmission } from './schema.js';
import type { ConversationStore } from './store.js';

/** Card button submissions handled by the agent commands. */
type BotCommand =
  | Command
  | { kind: 'agentForm'; agent: string; env?: string; version?: string }
  | { kind: 'agentSubmit'; agent: string; env?: string; version?: string; value: Record<string, unknown> };

/** What the user asked for before signing in (replayed after sign-in). */
type Pending = { text?: string; value?: Record<string, unknown> };

export interface BotDeps {
  platform: PlatformClient;
  auth: UserAuth;
  store: ConversationStore;
  webUrl?: string;
  /** Proactive sender (CloudAdapter.continueConversationAsync); enables background-run notifications. */
  proactive?: Proactive;
  /** Poller timing (tests). */
  poller?: PollerOptions;
}

export class AigTeamsBot extends TeamsActivityHandler {
  private pending = new Map<string, Pending>();
  /** Background agent runs being watched (undefined without a proactive sender). */
  readonly runs?: BackgroundRuns;

  constructor(private deps: BotDeps) {
    super();
    if (deps.proactive) {
      const proactive = deps.proactive;
      // A fresh user token for every poll, read inside a proactive turn for the stored conversation.
      const tokenFor = async (reference: Parameters<Proactive>[0]) => {
        let token: string | null = null;
        await proactive(reference, async (context) => {
          token = await deps.auth.getToken(context);
        });
        return token;
      };
      this.runs = new BackgroundRuns(deps.platform, tokenFor, proactive, deps.webUrl, deps.poller);
    }
    this.onMessage(async (context, next) => {
      await this.handleMessage(context, { text: context.activity.text, value: context.activity.value });
      await next();
    });
    this.onMembersAdded(async (context, next) => {
      for (const m of context.activity.membersAdded ?? []) {
        if (m.id !== context.activity.recipient.id) await context.sendActivity(HELP);
      }
      await next();
    });
  }

  // -- sign-in (Teams SSO / OAuth card) -------------------------------------------------------
  protected override async handleTeamsSigninTokenExchange(context: TurnContext, query: SigninStateVerificationQuery): Promise<void> {
    const token = (query as any)?.token as string | undefined;
    const ok = token ? await this.deps.auth.exchange(context, token) : false;
    if (!ok) {
      // 412 tells Teams the SSO exchange failed, so it shows the sign-in card instead.
      await context.sendActivity({
        type: 'invokeResponse',
        value: { status: 412, body: { id: (query as any)?.id, connectionName: (query as any)?.connectionName, failureDetail: 'token exchange failed' } },
      });
      return;
    }
    await this.resume(context);
  }

  protected override async handleTeamsSigninVerifyState(context: TurnContext, query: SigninStateVerificationQuery): Promise<void> {
    const token = await this.deps.auth.getToken(context, query?.state);
    if (token) await this.resume(context);
  }

  private async resume(context: TurnContext): Promise<void> {
    const pending = this.pending.get(context.activity.from.id);
    this.pending.delete(context.activity.from.id);
    if (pending) await this.handleMessage(context, pending);
    else await context.sendActivity('You are signed in. Type `help` to see what I can do.');
  }

  private async token(context: TurnContext, pending: Pending): Promise<string | null> {
    const token = await this.deps.auth.getToken(context);
    if (token) return token;
    this.pending.set(context.activity.from.id, pending);
    await this.deps.auth.promptSignIn(context);
    return null;
  }

  // -- commands -------------------------------------------------------------------------------
  async handleMessage(context: TurnContext, input: Pending): Promise<void> {
    const value = input.value && typeof input.value === 'object' ? input.value : undefined;
    let cmd: BotCommand;
    const str = (v: unknown) => (typeof v === 'string' && v ? v : undefined);
    if ((value?.action === VERB_FORM || value?.action === VERB_RUN) && typeof value.agent_id === 'string') {
      const target = { agent: value.agent_id, env: str(value.env), version: str(value.version) };
      cmd = value.action === VERB_FORM ? { kind: 'agentForm', ...target } : { kind: 'agentSubmit', ...target, value };
    } else if (value?.action === 'startWorkspace') {
      cmd = { kind: 'start', repo_url: String(value.repo_url ?? '').trim(), work_item: String(value.work_item ?? '').trim(), title: String(value.title ?? '').trim() };
    } else if ((value?.action === 'status' || value?.action === 'cancel') && typeof value.id === 'string') {
      cmd = { kind: value.action, id: value.id };
    } else {
      cmd = parseCommand(input.text);
    }
    if (cmd.kind === 'help') return void (await context.sendActivity(HELP));
    if (cmd.kind === 'form') return void (await context.sendActivity({ attachments: [startFormCard()] }));
    if (cmd.kind === 'unknown') {
      return void (await context.sendActivity(`Sorry, I did not understand "${cmd.text.slice(0, 100)}".\n\n${HELP}`));
    }
    if (cmd.kind === 'run' && !cmd.agent) {
      return void (await context.sendActivity('Which agent? Use `run <agent id> <input>`; type `agents` to see the agents you can run.'));
    }
    const token = await this.token(context, input);
    if (!token) return;
    try {
      switch (cmd.kind) {
        case 'start':
          return await this.start(context, token, cmd, value);
        case 'status':
          return await this.reply(context, await this.resolve(token, cmd.id));
        case 'list':
          return void (await context.sendActivity(listText(await this.deps.platform.listWorkspaces(token))));
        case 'cancel': {
          const ws = await this.resolve(token, cmd.id);
          return await this.reply(context, await this.deps.platform.cancelWorkspace(token, ws.id), 'Workspace cancelled');
        }
        case 'agents': {
          const { items } = await this.deps.platform.catalog(token, cmd.query || undefined);
          return void (await context.sendActivity({ attachments: [agentsListCard(items, cmd.query || undefined, this.deps.webUrl)], summary: `${items.length} agents` } as any));
        }
        case 'run':
          return await this.runCommand(context, token, cmd);
        case 'agentForm': {
          const { item, version } = await this.target(token, cmd.agent, cmd.env, cmd.version);
          return await this.showInput(context, item, version);
        }
        case 'agentSubmit':
          return await this.submit(context, token, cmd);
      }
    } catch (err) {
      await this.replyError(context, err);
    }
  }

  // -- agents ---------------------------------------------------------------------------------

  /** The catalog entry the user may run: exact id, exact name, or a unique id prefix. */
  private async findAgent(token: string, ref: string): Promise<CatalogItem> {
    const needle = ref.trim().toLowerCase();
    const items = needle ? (await this.deps.platform.catalog(token, ref.trim())).items : [];
    const hit = items.find((i) => i.agent.agent_id.toLowerCase() === needle)
      ?? items.find((i) => (i.agent.name ?? '').toLowerCase() === needle);
    if (hit) return hit;
    const prefixed = items.filter((i) => i.agent.agent_id.toLowerCase().startsWith(needle));
    if (prefixed.length === 1) return prefixed[0];
    const shown = ref.slice(0, 64);
    const suggest = (prefixed.length ? prefixed : items).slice(0, 5).map((i) => `\`${i.agent.agent_id}\``);
    throw new PlatformError(404, 'agent_not_found', suggest.length
      ? `No agent "${shown}" you can run. Did you mean ${suggest.join(', ')}?`
      : `No agent "${shown}" you can run. Type \`agents\` to see the agents you can run.`);
  }

  private async target(token: string, agent: string, env?: string, version?: string): Promise<{ item: CatalogItem; version: CatalogVersion }> {
    if (!agent.trim() || agent.length > 200) throw new PlatformError(404, 'agent_not_found', friendlyError('agent_not_found'));
    const item = await this.findAgent(token, agent);
    if (!env && !version) return { item, version: item.default };
    const v = item.versions.find((x) => (!env || x.env === env) && (!version || x.version === version));
    if (!v) throw new PlatformError(404, 'version_not_found', `${friendlyError('version_not_found')} (${[version, env].filter(Boolean).join(' in ')})`);
    return { item, version: v };
  }

  private async showInput(context: TurnContext, item: CatalogItem, v: CatalogVersion, opts: { prefill?: Record<string, unknown>; errors?: string[]; background?: boolean; message?: string } = {}) {
    const card = isChatMode(v.input_schema) ? chatPromptCard(item, v, opts) : agentFormCard(item, v, opts);
    await context.sendActivity({ attachments: [card] });
  }

  private async runCommand(context: TurnContext, token: string, cmd: Extract<Command, { kind: 'run' }>) {
    const { item, version } = await this.target(token, cmd.agent, cmd.env, cmd.version);
    const plan = planRun(version.input_schema, cmd.text);
    if (plan.kind === 'chatPrompt') return this.showInput(context, item, version);
    if (plan.kind === 'form') return this.showInput(context, item, version, { prefill: plan.prefill, errors: plan.errors, background: cmd.background });
    await this.execute(context, token, item, version, plan.body, cmd.background);
  }

  private async submit(context: TurnContext, token: string, cmd: Extract<BotCommand, { kind: 'agentSubmit' }>) {
    const { item, version } = await this.target(token, cmd.agent, cmd.env, cmd.version);
    const background = String(cmd.value[BACKGROUND_INPUT] ?? '').toLowerCase() === 'true';
    if (isChatMode(version.input_schema)) {
      const message = typeof cmd.value[MESSAGE_INPUT] === 'string' ? (cmd.value[MESSAGE_INPUT] as string).trim() : '';
      if (!message) return this.showInput(context, item, version, { errors: ['Type a message.'] });
      return this.execute(context, token, item, version, { messages: [{ role: 'user', content: message.slice(0, 100_000) }] }, background);
    }
    const checked = validateSubmission(version.input_schema, cmd.value);
    if (!checked.ok) return this.showInput(context, item, version, { prefill: checked.values, errors: checked.errors, background });
    await this.execute(context, token, item, version, { input: checked.input }, background);
  }

  private async execute(context: TurnContext, token: string, item: CatalogItem, v: CatalogVersion, body: InvokeBody, background: boolean) {
    const name = item.agent.name || item.agent.agent_id;
    const where = { env: v.env, version: v.version };
    try {
      if (background) {
        const started = await this.deps.platform.invokeAgent(token, item.agent.agent_id, body, { mode: 'background', ...where });
        const run = started.invocation_id.slice(0, 8);
        if (this.runs) {
          this.runs.track({ invocationId: started.invocation_id, agentId: item.agent.agent_id, agentName: name, reference: TC.getConversationReference(context.activity) });
          await context.sendActivity(`Started **${name}** in the background (run \`${run}\`). I will post the result here when it finishes.`);
        } else {
          await context.sendActivity(`Started **${name}** in the background (run \`${run}\`). See the result in the AIG portal.`);
        }
        return;
      }
      const r = await this.deps.platform.invokeAgent(token, item.agent.agent_id, body, { mode: 'sync', ...where });
      const card = resultCard({ ...r, agent_name: name }, this.deps.webUrl);
      await context.sendActivity({ attachments: [card], summary: `${name}: ${r.status}` } as any);
    } catch (err) {
      if (!(err instanceof PlatformError) || err.status === 401) throw err;
      if (err.code === 'input_invalid' && 'input' in body) {
        return this.showInput(context, item, v, { prefill: body.input, errors: [friendlyError(err.code, err.message)], background });
      }
      await context.sendActivity(friendlyError(err.code, err.message));
    }
  }

  private async start(context: TurnContext, token: string, cmd: Extract<Command, { kind: 'start' }>, value?: Record<string, unknown>) {
    if (!cmd.repo_url || !cmd.work_item || !cmd.title) {
      await context.sendActivity({ text: 'Repository, work item and title are required.', attachments: [startFormCard(cmd)] });
      return;
    }
    const body: WorkspaceCreate = { repo_url: cmd.repo_url, work_item: cmd.work_item, title: cmd.title.slice(0, 200) };
    const description = typeof value?.description === 'string' ? value.description.trim() : '';
    if (description) body.description = description.slice(0, 10000);
    const profile = typeof value?.job_profile === 'string' ? value.job_profile : undefined;
    if (profile && profile !== 'general' && (JOB_PROFILES as readonly string[]).includes(profile)) body.job_profile = profile;
    const ws = await this.deps.platform.createWorkspace(token, body);
    // Remember this conversation so status changes come back here (proactive messages).
    this.deps.store.set(ws.id, { reference: TC.getConversationReference(context.activity), userId: context.activity.from.id, lastStatus: ws.status });
    await this.reply(context, ws, 'Workspace requested - I will post updates here');
  }

  /** Full id, or a unique prefix of one of the user's workspaces (8 characters are shown). */
  private async resolve(token: string, idOrPrefix: string): Promise<Workspace> {
    if (/^[0-9a-f-]{36}$/i.test(idOrPrefix)) return this.deps.platform.getWorkspace(token, idOrPrefix);
    const matches = (await this.deps.platform.listWorkspaces(token)).filter((w) => w.id.startsWith(idOrPrefix.toLowerCase()));
    if (matches.length === 1) return matches[0];
    throw new PlatformError(404, matches.length ? 'ambiguous_id' : 'workspace_not_found',
      matches.length ? `"${idOrPrefix}" matches ${matches.length} workspaces; use more characters.` : `No workspace "${idOrPrefix}" found.`);
  }

  private async reply(context: TurnContext, ws: Workspace, heading?: string) {
    const card: Attachment = workspaceCard(ws, this.deps.webUrl, heading);
    await context.sendActivity({ attachments: [card], summary: `${shortId(ws.id)}: ${ws.status}` } as any);
  }

  private async replyError(context: TurnContext, err: unknown) {
    if (err instanceof PlatformError) {
      if (err.status === 401) {
        await this.deps.auth.signOut(context).catch(() => undefined);
        await context.sendActivity('Your AIG sign-in has expired. Send the command again to sign in.');
        return;
      }
      const hint = ['workspace_not_found', 'ambiguous_id', 'agent_not_found', 'version_not_found'].includes(err.code) ? '' : ` (${err.code})`;
      await context.sendActivity(`${err.message}${hint}`);
      return;
    }
    console.error('teams-bot: unexpected error', err instanceof Error ? err.message : 'unknown');
    await context.sendActivity('Something went wrong. Please try again.');
  }
}
