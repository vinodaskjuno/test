/**
 * `POST /api/notify`: status changes pushed by backend/workspace-orchestrator.
 *
 * Signature: `x-aig-signature: sha256=<hex HMAC-SHA256(AIG_BOT_NOTIFY_SECRET, "<x-aig-timestamp>.<raw body>")>`,
 * timestamps older than 5 minutes are rejected (replay). For a workspace started from this bot, the
 * stored conversation reference gets a proactive status card; others are acknowledged and ignored.
 */

import { createHmac, timingSafeEqual } from 'node:crypto';
import type { Attachment, ConversationReference, TurnContext } from 'botbuilder';
import { workspaceCard } from './cards.js';
import { FINAL, type Workspace } from './platform.js';
import type { ConversationStore } from './store.js';

export const TOLERANCE_SECONDS = 300;

export function sign(secret: string, timestamp: string, body: string | Buffer): string {
  return 'sha256=' + createHmac('sha256', secret).update(`${timestamp}.`).update(body).digest('hex');
}

export function verifySignature(secret: string, timestamp: string | undefined, body: string | Buffer, signature: string | undefined, now = Date.now() / 1000): boolean {
  if (!timestamp || !signature || !/^\d+$/.test(timestamp)) return false;
  if (Math.abs(now - Number(timestamp)) > TOLERANCE_SECONDS) return false;
  const expected = Buffer.from(sign(secret, timestamp, body));
  const given = Buffer.from(signature);
  return expected.length === given.length && timingSafeEqual(expected, given);
}

/** Sends to a stored conversation (CloudAdapter.continueConversationAsync in production). */
export type Proactive = (reference: Partial<ConversationReference>, logic: (context: TurnContext) => Promise<void>) => Promise<void>;

export interface NotifyResult {
  status: number;
  body: Record<string, unknown>;
}

export class NotifyHandler {
  constructor(private secret: string | undefined, private store: ConversationStore, private proactive: Proactive, private webUrl?: string) {}

  async handle(headers: Record<string, string | string[] | undefined>, rawBody: string | Buffer): Promise<NotifyResult> {
    if (!this.secret) return { status: 503, body: { error: { code: 'notify_not_configured', message: 'AIG_BOT_NOTIFY_SECRET is not set' } } };
    const h = (n: string) => {
      const v = headers[n];
      return Array.isArray(v) ? v[0] : v;
    };
    if (!verifySignature(this.secret, h('x-aig-timestamp'), rawBody, h('x-aig-signature'))) {
      return { status: 401, body: { error: { code: 'notify_unauthenticated', message: 'missing, stale or invalid signature' } } };
    }
    let payload: { event?: string; workspace?: Workspace };
    try {
      payload = JSON.parse(rawBody.toString());
    } catch {
      return { status: 400, body: { error: { code: 'invalid_json', message: 'body is not JSON' } } };
    }
    const ws = payload.workspace;
    if (payload.event !== 'workspace.status' || !ws?.id || !ws.status) {
      return { status: 400, body: { error: { code: 'invalid_request', message: 'expected a workspace.status event' } } };
    }
    const sub = this.store.get(ws.id);
    if (!sub) return { status: 202, body: { delivered: false } };
    if (sub.lastStatus === ws.status) return { status: 202, body: { delivered: false, duplicate: true } };
    const card: Attachment = workspaceCard(ws, this.webUrl, 'Workspace update');
    await this.proactive(sub.reference, async (context) => {
      await context.sendActivity({ attachments: [card] });
    });
    if (FINAL.has(ws.status)) this.store.delete(ws.id);
    else this.store.set(ws.id, { ...sub, lastStatus: ws.status });
    return { status: 202, body: { delivered: true } };
  }
}
