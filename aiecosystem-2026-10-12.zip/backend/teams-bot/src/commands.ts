/**
 * Text commands: start workspace <repo> <work item> [title], status <id>, list, cancel <id>,
 * agents [query], run [--background] [--env <env>] [--version <v>] <agent> [input], help.
 */

export type Command =
  | { kind: 'start'; repo_url: string; work_item: string; title: string }
  | { kind: 'form' }
  | { kind: 'status'; id: string }
  | { kind: 'cancel'; id: string }
  | { kind: 'list' }
  | { kind: 'help' }
  | { kind: 'agents'; query: string }
  | { kind: 'run'; agent: string; text: string; background: boolean; env?: string; version?: string }
  | { kind: 'unknown'; text: string };

/** Teams prefixes channel messages with `<at>Bot</at>`; strip mentions, tags and entities. */
export function normalize(text: string | undefined): string {
  return (text ?? '')
    .replace(/<at>[^<]*<\/at>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

export function parseCommand(raw: string | undefined): Command {
  const text = normalize(raw);
  const [verb = '', ...rest] = text.split(' ');
  const v = verb.toLowerCase();
  if (!text || v === 'help' || v === '?') return { kind: 'help' };
  if (v === 'list' || v === 'ls') return { kind: 'list' };
  if (v === 'agents' || v === 'agent' || v === 'catalog') return { kind: 'agents', query: rest.join(' ').slice(0, 200) };
  if (v === 'run' || v === 'ask') return parseRun(rest);
  if (v === 'status' || v === 'cancel') {
    const id = rest[0];
    if (!id) return { kind: 'unknown', text };
    return { kind: v, id };
  }
  if (v === 'start' || v === 'new') {
    const args = rest[0]?.toLowerCase() === 'workspace' ? rest.slice(1) : rest;
    if (args.length === 0) return { kind: 'form' };
    if (args.length < 2) return { kind: 'unknown', text };
    const [repo_url, work_item, ...title] = args;
    return { kind: 'start', repo_url, work_item, title: title.join(' ') || `Work item ${work_item}` };
  }
  return { kind: 'unknown', text };
}

function parseRun(args: string[]): Command {
  let background = false;
  let env: string | undefined;
  let version: string | undefined;
  let i = 0;
  for (; i < args.length; i++) {
    const a = args[i];
    const lower = a.toLowerCase();
    if (lower === '--background' || lower === '--bg' || lower === '-b') background = true;
    else if (lower === '--env' || lower === '--version') {
      const value = args[++i];
      if (lower === '--env') env = value;
      else version = value;
    } else if (lower.startsWith('--env=')) env = a.slice(6);
    else if (lower.startsWith('--version=')) version = a.slice(10);
    else break;
  }
  const [agent = '', ...text] = args.slice(i);
  return { kind: 'run', agent, text: text.join(' '), background, ...(env ? { env } : {}), ...(version ? { version } : {}) };
}

export const HELP = [
  '**AIG team workspaces** - a code agent fixes a work item in an isolated workspace and opens a PR.',
  '',
  '- `start workspace <repo url> <work item> [title]` - e.g. `start workspace https://github.com/aig/claims-triage #42 Fix rounding`',
  '- `start` - open the form (adds description and job profile)',
  '- `status <id>` - show one workspace (the first 8 characters of the id are enough)',
  '- `list` - your recent workspaces',
  '- `cancel <id>` - stop a workspace',
  '',
  '**AIG agents** - run the agents you have access to.',
  '',
  '- `agents [search]` - agents you can run (name, team, default version, status) with a Run button',
  '- `run <agent id> <input>` - run an agent, e.g. `run claims-summarizer Summarise claim 123`',
  '- `run <agent id>` - open the agent\'s input form',
  '- `run --background <agent id> <input>` - for long runs: I post the result here when it is done',
  '- `help` - this message',
  '',
  'You get a message here whenever a workspace you started from Teams changes status, and when a background run finishes.',
].join('\n');
