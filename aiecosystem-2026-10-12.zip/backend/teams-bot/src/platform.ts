/**
 * platform-api client that acts ON BEHALF OF THE TEAMS USER: every call carries the user's own
 * bearer token (Entra access token for platform-api from the bot's OAuth connection / Teams SSO,
 * or `dev:<email>` against a local dev-auth backend). The bot never holds the service token.
 */

export const STATUSES = ['queued', 'provisioning', 'running', 'testing', 'pr_opened', 'completed', 'failed', 'cancelled'] as const;
export type WorkspaceStatus = (typeof STATUSES)[number];
export const FINAL: ReadonlySet<string> = new Set(['completed', 'failed', 'cancelled']);
export const JOB_PROFILES = ['general', 'claims', 'underwriting', 'operations'] as const;

export interface Workspace {
  id: string;
  repo_url: string;
  work_item: string;
  title: string;
  description?: string;
  job_profile?: string | null;
  status: WorkspaceStatus;
  requested_by: string;
  team: string;
  pr_url?: string | null;
  log_url?: string | null;
  error?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface WorkspaceCreate {
  repo_url: string;
  work_item: string;
  title: string;
  description?: string;
  job_profile?: string | null;
}

export class PlatformError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

export type FetchLike = (url: string, init?: RequestInit) => Promise<Response>;

export class PlatformClient {
  constructor(private baseUrl: string, private fetchImpl: FetchLike = fetch, private timeoutMs = 15000) {}

  private async call<T>(token: string, method: string, path: string, body?: unknown, timeoutMs = this.timeoutMs): Promise<T> {
    let resp: Response;
    try {
      resp = await this.fetchImpl(`${this.baseUrl}${path}`, {
        method,
        headers: {
          authorization: `Bearer ${token}`,
          accept: 'application/json',
          ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch (err) {
      if ((err as Error)?.name === 'TimeoutError') throw new PlatformError(504, 'platform_timeout', 'The AIG platform did not answer in time.');
      throw new PlatformError(503, 'platform_unreachable', 'The AIG platform is not reachable right now.');
    }
    const text = await resp.text();
    let data: any = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    if (!resp.ok) {
      const err = data?.error ?? {};
      throw new PlatformError(resp.status, String(err.code ?? 'http_error'), String(err.message ?? resp.statusText));
    }
    return data as T;
  }

  createWorkspace(token: string, body: WorkspaceCreate): Promise<Workspace> {
    return this.call(token, 'POST', '/api/v1/workspaces', body);
  }

  getWorkspace(token: string, id: string): Promise<Workspace> {
    return this.call(token, 'GET', `/api/v1/workspaces/${encodeURIComponent(id)}`);
  }

  async listWorkspaces(token: string): Promise<Workspace[]> {
    const data = await this.call<{ items: Workspace[] }>(token, 'GET', '/api/v1/workspaces');
    return data.items ?? [];
  }

  cancelWorkspace(token: string, id: string): Promise<Workspace> {
    return this.call(token, 'POST', `/api/v1/workspaces/${encodeURIComponent(id)}/cancel`);
  }

  // -- agent catalog and invocation (W6) ------------------------------------------------------

  /** Agents the user may run (`GET /api/v1/catalog?q=`); platform-api applies access rules. */
  async catalog(token: string, q?: string): Promise<CatalogList> {
    const qs = q ? `?${new URLSearchParams({ q: q.slice(0, 200) })}` : '';
    const data = await this.call<CatalogList>(token, 'GET', `/api/v1/catalog${qs}`);
    return { items: data.items ?? [], total: data.total ?? (data.items ?? []).length, teams: data.teams ?? [], tags: data.tags ?? [] };
  }

  /** `POST /api/v1/agents/{id}/invoke?mode=sync|background` (sync waits for the agent, up to the server's 120 s). */
  invokeAgent(token: string, agentId: string, body: InvokeBody, opts: { mode: 'sync'; env?: string; version?: string }): Promise<InvokeResult>;
  invokeAgent(token: string, agentId: string, body: InvokeBody, opts: { mode: 'background'; env?: string; version?: string }): Promise<BackgroundStarted>;
  invokeAgent(token: string, agentId: string, body: InvokeBody, opts: { mode: 'sync' | 'background'; env?: string; version?: string }): Promise<InvokeResult | BackgroundStarted> {
    const params = new URLSearchParams({ mode: opts.mode });
    if (opts.env) params.set('env', opts.env);
    if (opts.version) params.set('version', opts.version);
    const timeout = opts.mode === 'sync' ? this.syncInvokeTimeoutMs : this.timeoutMs;
    return this.call(token, 'POST', `/api/v1/agents/${encodeURIComponent(agentId)}/invoke?${params}`, body, timeout);
  }

  /** `GET /api/v1/invocations/{id}` (the output is included for the caller's own runs). */
  getInvocation(token: string, id: string): Promise<Invocation> {
    return this.call(token, 'GET', `/api/v1/invocations/${encodeURIComponent(id)}`);
  }

  /** Client-side budget for a sync invoke: the server's 120 s sync timeout plus margin. */
  syncInvokeTimeoutMs = 130_000;
}

export interface CatalogVersion {
  env: string;
  version: string;
  kind?: string;
  verified?: boolean;
  verified_at?: string | null;
  input_schema?: JsonSchema | null;
  output_schema?: JsonSchema | null;
}

export interface CatalogAgent {
  agent_id: string;
  name: string;
  description?: string | null;
  team: string;
  owner?: string;
  status?: string;
  lifecycle?: string;
  tags?: string[];
  visibility?: string;
}

export interface CatalogItem {
  agent: CatalogAgent;
  versions: CatalogVersion[];
  default: CatalogVersion;
  access?: string;
}

export interface CatalogList {
  items: CatalogItem[];
  total: number;
  teams: string[];
  tags: string[];
}

export type JsonSchema = Record<string, any>;

export type InvokeBody = { input: Record<string, unknown>; session_id?: string } | { messages: { role: string; content: string }[]; session_id?: string };

export interface Usage {
  prompt_tokens?: number;
  completion_tokens?: number;
  total_tokens?: number;
}

export interface InvokeResult {
  invocation_id: string;
  agent_id: string;
  version: string;
  env: string;
  status: string;
  output: unknown;
  usage?: Usage | null;
  trace_id?: string | null;
  duration_ms?: number | null;
}

export interface BackgroundStarted {
  invocation_id: string;
  agent_id: string;
  version: string;
  env: string;
  status: 'queued' | string;
  location?: string;
}

export const INVOCATION_FINAL: ReadonlySet<string> = new Set(['succeeded', 'failed', 'cancelled', 'timeout']);

export interface Invocation {
  id: string;
  agent_id: string;
  version: string;
  env: string;
  status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled' | 'timeout' | string;
  trace_id?: string | null;
  duration_ms?: number | null;
  usage?: Usage | null;
  error_code?: string | null;
  error_message?: string | null;
  output_available?: boolean;
  output?: unknown;
}
