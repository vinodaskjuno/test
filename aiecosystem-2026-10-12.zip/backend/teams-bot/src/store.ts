/**
 * Which conversation started which workspace (for proactive status messages).
 * Local/single replica: a JSON file (AIG_BOT_STATE_FILE) or memory. With several replicas use a
 * shared store (Azure Blob/Table or Cosmos DB) behind the same interface.
 */

import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { ConversationReference } from 'botbuilder';

export interface Subscription {
  reference: Partial<ConversationReference>;
  userId: string;
  lastStatus: string;
}

export interface ConversationStore {
  get(workspaceId: string): Subscription | undefined;
  set(workspaceId: string, sub: Subscription): void;
  delete(workspaceId: string): void;
}

export class MemoryStore implements ConversationStore {
  protected map = new Map<string, Subscription>();
  get(id: string) {
    return this.map.get(id);
  }
  set(id: string, sub: Subscription) {
    this.map.set(id, sub);
  }
  delete(id: string) {
    this.map.delete(id);
  }
}

export class FileStore extends MemoryStore {
  constructor(private path: string) {
    super();
    try {
      const data = JSON.parse(readFileSync(path, 'utf8')) as Record<string, Subscription>;
      for (const [k, v] of Object.entries(data)) this.map.set(k, v);
    } catch {
      /* first run */
    }
  }
  private flush() {
    mkdirSync(dirname(this.path), { recursive: true });
    const tmp = `${this.path}.tmp`;
    writeFileSync(tmp, JSON.stringify(Object.fromEntries(this.map), null, 2), { mode: 0o600 });
    renameSync(tmp, this.path);
  }
  override set(id: string, sub: Subscription) {
    super.set(id, sub);
    this.flush();
  }
  override delete(id: string) {
    super.delete(id);
    this.flush();
  }
}
