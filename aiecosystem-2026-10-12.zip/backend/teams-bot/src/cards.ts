/** Adaptive Cards (schema 1.5, supported by Teams desktop, web and mobile). */

import { type Attachment, CardFactory } from 'botbuilder';
import { FINAL, JOB_PROFILES, type Workspace } from './platform.js';

const STATUS_LABEL: Record<string, string> = {
  queued: 'Queued',
  provisioning: 'Provisioning workspace',
  running: 'Code agent working',
  testing: 'Running tests and evals',
  pr_opened: 'Pull request opened',
  completed: 'Completed (workspace spun down)',
  failed: 'Failed',
  cancelled: 'Cancelled',
};

const STATUS_COLOR: Record<string, string> = {
  pr_opened: 'Good',
  completed: 'Good',
  failed: 'Attention',
  cancelled: 'Warning',
};

export function statusLabel(status: string): string {
  return STATUS_LABEL[status] ?? status;
}

export function shortId(id: string): string {
  return id.slice(0, 8);
}

export function workspaceCard(ws: Workspace, webUrl?: string, heading?: string): Attachment {
  const body: any[] = [
    { type: 'TextBlock', text: heading ?? 'AIG team workspace', size: 'Small', isSubtle: true, wrap: true },
    { type: 'TextBlock', text: ws.title, size: 'Large', weight: 'Bolder', wrap: true },
    {
      type: 'TextBlock',
      text: statusLabel(ws.status),
      color: STATUS_COLOR[ws.status] ?? 'Accent',
      weight: 'Bolder',
      wrap: true,
    },
    {
      type: 'FactSet',
      facts: [
        { title: 'Workspace', value: shortId(ws.id) },
        { title: 'Repository', value: ws.repo_url },
        { title: 'Work item', value: ws.work_item },
        { title: 'Requested by', value: `${ws.requested_by} (${ws.team})` },
        ...(ws.updated_at ? [{ title: 'Updated', value: ws.updated_at }] : []),
      ],
    },
  ];
  if (ws.error) body.push({ type: 'TextBlock', text: ws.error.slice(0, 600), wrap: true, color: 'Attention', fontType: 'Monospace', size: 'Small' });
  const actions: any[] = [];
  if (ws.pr_url) actions.push({ type: 'Action.OpenUrl', title: 'Open pull request', url: ws.pr_url });
  if (ws.log_url) actions.push({ type: 'Action.OpenUrl', title: 'Logs', url: ws.log_url });
  if (webUrl) actions.push({ type: 'Action.OpenUrl', title: 'Open in AIG portal', url: `${webUrl}/workspaces/${ws.id}` });
  actions.push({ type: 'Action.Submit', title: 'Refresh', data: { action: 'status', id: ws.id } });
  if (!FINAL.has(ws.status)) actions.push({ type: 'Action.Submit', title: 'Cancel', data: { action: 'cancel', id: ws.id } });
  return CardFactory.adaptiveCard({ $schema: 'http://adaptivecards.io/schemas/adaptive-card.json', type: 'AdaptiveCard', version: '1.5', body, actions });
}

export function startFormCard(defaults: Partial<Record<'repo_url' | 'work_item' | 'title', string>> = {}): Attachment {
  return CardFactory.adaptiveCard({
    $schema: 'http://adaptivecards.io/schemas/adaptive-card.json',
    type: 'AdaptiveCard',
    version: '1.5',
    body: [
      { type: 'TextBlock', text: 'Start a team workspace', size: 'Large', weight: 'Bolder' },
      { type: 'TextBlock', text: 'A code agent fixes the work item in an isolated workspace, runs the tests and evals, and opens a pull request linked to it.', wrap: true, isSubtle: true },
      { type: 'Input.Text', id: 'repo_url', label: 'Repository URL', isRequired: true, errorMessage: 'Required', placeholder: 'https://github.com/org/repo', value: defaults.repo_url ?? '' },
      { type: 'Input.Text', id: 'work_item', label: 'Work item (issue number or URL)', isRequired: true, errorMessage: 'Required', placeholder: '#42', value: defaults.work_item ?? '' },
      { type: 'Input.Text', id: 'title', label: 'Title', isRequired: true, errorMessage: 'Required', maxLength: 200, value: defaults.title ?? '' },
      { type: 'Input.Text', id: 'description', label: 'Description', isMultiline: true, maxLength: 10000 },
      {
        type: 'Input.ChoiceSet',
        id: 'job_profile',
        label: 'Job profile',
        value: 'general',
        choices: JOB_PROFILES.map((p) => ({ title: p, value: p })),
      },
    ],
    actions: [{ type: 'Action.Submit', title: 'Start workspace', data: { action: 'startWorkspace' } }],
  });
}

export function listText(items: Workspace[]): string {
  if (!items.length) return 'You have no workspaces yet. Type `start` to create one.';
  const lines = items.slice(0, 10).map((w) => {
    const pr = w.pr_url ? ` - [PR](${w.pr_url})` : '';
    return `- \`${shortId(w.id)}\` **${w.title}** - ${statusLabel(w.status)}${pr}`;
  });
  return [`**Your workspaces** (${items.length})`, ...lines].join('\n');
}
