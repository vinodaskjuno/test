/**
 * Background agent runs started from Teams: polls `GET /api/v1/invocations/{id}` ON BEHALF OF THE
 * USER (a fresh token from the Bot Framework token service for every poll, fetched inside a
 * proactive turn for the stored conversation) with backoff (2 s, x1.5, capped at 30 s; gives up
 * after 1 h, the platform's background timeout) and posts the result card proactively to the
 * conversation that started the run (same `Proactive` sender as the orchestrator notifications).
 *
 * Tracked runs live in memory: after a bot restart the user can still see the run in the portal.
 */

import type { ConversationReference } from 'botbuilder';
import { resultCard, type RunOutcome } from './agentCards.js';
import type { Proactive } from './notify.js';
import { INVOCATION_FINAL, type PlatformClient, PlatformError } from './platform.js';

export interface BackgroundRun {
  invocationId: string;
  agentId: string;
  agentName?: string;
  reference: Partial<ConversationReference>;
}

export interface PollerOptions {
  initialDelayMs?: number;
  maxDelayMs?: number;
  factor?: number;
  maxTotalMs?: number;
  now?: () => number;
  setTimer?: (fn: () => void, ms: number) => unknown;
  clearTimer?: (handle: unknown) => void;
}

/** The user's platform-api token for a stored conversation (null when they must sign in again). */
export type TokenFor = (reference: Partial<ConversationReference>) => Promise<string | null>;

export class BackgroundRuns {
  private timers = new Map<string, unknown>();
  private readonly initialDelayMs: number;
  private readonly maxDelayMs: number;
  private readonly factor: number;
  private readonly maxTotalMs: number;
  private readonly now: () => number;
  private readonly setTimer: (fn: () => void, ms: number) => unknown;
  private readonly clearTimer: (handle: unknown) => void;

  constructor(private platform: PlatformClient, private tokenFor: TokenFor, private proactive: Proactive, private webUrl?: string, opts: PollerOptions = {}) {
    this.initialDelayMs = opts.initialDelayMs ?? 2000;
    this.maxDelayMs = opts.maxDelayMs ?? 30_000;
    this.factor = opts.factor ?? 1.5;
    this.maxTotalMs = opts.maxTotalMs ?? 3_600_000;
    this.now = opts.now ?? Date.now;
    this.setTimer = opts.setTimer ?? ((fn, ms) => setTimeout(fn, ms));
    this.clearTimer = opts.clearTimer ?? ((h) => clearTimeout(h as ReturnType<typeof setTimeout>));
  }

  /** Number of runs being watched. */
  get size(): number {
    return this.timers.size;
  }

  track(run: BackgroundRun): void {
    if (this.timers.has(run.invocationId)) return;
    this.schedule(run, this.initialDelayMs, this.now());
  }

  stopAll(): void {
    for (const h of this.timers.values()) this.clearTimer(h);
    this.timers.clear();
  }

  private schedule(run: BackgroundRun, delay: number, startedAt: number): void {
    const handle = this.setTimer(() => {
      void this.poll(run, delay, startedAt).catch((err) => {
        console.error('teams-bot: background poll failed', err instanceof Error ? err.message : 'unknown');
        this.timers.delete(run.invocationId);
      });
    }, delay);
    this.timers.set(run.invocationId, handle);
  }

  private async poll(run: BackgroundRun, delay: number, startedAt: number): Promise<void> {
    const next = Math.min(Math.round(delay * this.factor), this.maxDelayMs);
    const again = () => {
      if (this.now() - startedAt + next > this.maxTotalMs) {
        this.timers.delete(run.invocationId);
        return this.say(run, `The background run \`${run.invocationId.slice(0, 8)}\` of ${run.agentName ?? run.agentId} is still not finished after an hour; I stopped watching it. Check it in the AIG portal.`);
      }
      this.schedule(run, next, startedAt);
    };
    const expired = () => {
      this.timers.delete(run.invocationId);
      return this.say(run, `I could not check the background run \`${run.invocationId.slice(0, 8)}\` because your AIG sign-in expired. Sign in again (send any command) and look it up in the AIG portal.`);
    };
    const token = await this.tokenFor(run.reference);
    if (!token) return expired();
    let inv;
    try {
      inv = await this.platform.getInvocation(token, run.invocationId);
    } catch (err) {
      if (err instanceof PlatformError && (err.status >= 500 || err.status === 429)) return again(); // transient
      if (err instanceof PlatformError && err.status === 401) return expired();
      this.timers.delete(run.invocationId);
      const why = err instanceof PlatformError ? err.message : 'unknown error';
      return this.say(run, `I could not check the background run \`${run.invocationId.slice(0, 8)}\` of ${run.agentName ?? run.agentId}: ${why}`);
    }
    if (!INVOCATION_FINAL.has(inv.status)) return again();
    this.timers.delete(run.invocationId);
    const outcome: RunOutcome = {
      invocation_id: inv.id, agent_id: inv.agent_id, agent_name: run.agentName, version: inv.version, env: inv.env, status: inv.status,
      output: inv.output, usage: inv.usage, trace_id: inv.trace_id, duration_ms: inv.duration_ms, error_code: inv.error_code, error_message: inv.error_message,
    };
    const card = resultCard(outcome, this.webUrl, 'Background run finished');
    await this.proactive(run.reference, async (context) => {
      await context.sendActivity({ attachments: [card], summary: `${run.agentName ?? run.agentId}: ${inv.status}` } as any);
    });
  }

  private async say(run: BackgroundRun, text: string): Promise<void> {
    await this.proactive(run.reference, async (context) => {
      await context.sendActivity(text);
    });
  }
}
