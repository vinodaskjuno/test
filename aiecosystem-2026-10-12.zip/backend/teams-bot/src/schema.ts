/**
 * Agent input from Teams: map free text onto a version's `input_schema`, describe the schema as
 * simple form fields (Adaptive Card inputs) and validate a form submission before invoking.
 *
 * platform-api validates `input` against the schema again (Draft 2020-12) - the checks here only
 * give the user quick, friendly feedback. Only the top-level properties of an object schema become
 * fields; nested objects and arrays are entered as JSON text.
 */

import type { InvokeBody, JsonSchema } from './platform.js';

export type FieldKind = 'text' | 'number' | 'integer' | 'boolean' | 'choice' | 'json';

export interface Field {
  name: string;
  /** Adaptive Card input id (prefixed so it cannot clash with the submit data keys). */
  id: string;
  kind: FieldKind;
  label: string;
  description?: string;
  required: boolean;
  multiline: boolean;
  choices?: unknown[];
  default?: unknown;
  minimum?: number;
  maximum?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
}

/** Property names that take the free text of `run <agent> <text>`. */
export const TEXT_PROPERTY_NAMES = ['prompt', 'question', 'query', 'text', 'input', 'message'];
export const INPUT_PREFIX = 'input.';

function baseType(prop: JsonSchema): string | undefined {
  const t = prop?.type;
  if (Array.isArray(t)) return t.find((x) => x !== 'null');
  return typeof t === 'string' ? t : undefined;
}

function properties(schema: JsonSchema | null | undefined): Record<string, JsonSchema> {
  const p = schema && typeof schema === 'object' ? schema.properties : undefined;
  return p && typeof p === 'object' && !Array.isArray(p) ? p : {};
}

/** No schema, or a schema without properties: the agent is used in chat mode (`messages`). */
export function isChatMode(schema: JsonSchema | null | undefined): boolean {
  return Object.keys(properties(schema)).length === 0;
}

function fieldKind(prop: JsonSchema): FieldKind {
  if (Array.isArray(prop?.enum) && prop.enum.length > 0) return 'choice';
  switch (baseType(prop)) {
    case 'integer':
      return 'integer';
    case 'number':
      return 'number';
    case 'boolean':
      return 'boolean';
    case 'object':
    case 'array':
      return 'json';
    default:
      return 'text'; // string or untyped
  }
}

export function fields(schema: JsonSchema | null | undefined): Field[] {
  const required = new Set<string>(Array.isArray(schema?.required) ? schema!.required : []);
  return Object.entries(properties(schema)).map(([name, prop]) => {
    const kind = fieldKind(prop ?? {});
    const p = prop ?? {};
    const num = (v: unknown) => (typeof v === 'number' ? v : undefined);
    return {
      name,
      id: INPUT_PREFIX + name,
      kind,
      label: typeof p.title === 'string' && p.title ? p.title : name,
      description: typeof p.description === 'string' && p.description ? p.description : undefined,
      required: required.has(name),
      multiline: kind === 'json' || (kind === 'text' && (p.format === 'textarea' || (num(p.maxLength) ?? 0) > 200 || /notes|description|text/i.test(name))),
      choices: kind === 'choice' ? p.enum : undefined,
      default: p.default,
      minimum: num(p.minimum) ?? num(p.exclusiveMinimum),
      maximum: num(p.maximum) ?? num(p.exclusiveMaximum),
      minLength: num(p.minLength),
      maxLength: num(p.maxLength),
      pattern: typeof p.pattern === 'string' ? p.pattern : undefined,
    };
  });
}

export type RunPlan =
  | { kind: 'invoke'; body: InvokeBody }
  /** Show the schema form (optionally pre-filled, with the problems found). */
  | { kind: 'form'; prefill?: Record<string, unknown>; errors?: string[] }
  /** Chat-mode agent without a message: ask for one. */
  | { kind: 'chatPrompt' };

/** The property that receives free text, or undefined. */
export function textProperty(schema: JsonSchema | null | undefined): string | undefined {
  const all = fields(schema);
  const required = all.filter((f) => f.required);
  if (required.length === 1 && required[0].kind === 'text') return required[0].name;
  for (const wanted of TEXT_PROPERTY_NAMES) {
    const f = all.find((x) => x.name.toLowerCase() === wanted && x.kind === 'text');
    if (f) return f.name;
  }
  return undefined;
}

/** What `run <agent> <text>` does for a version with this input schema. */
export function planRun(schema: JsonSchema | null | undefined, text: string): RunPlan {
  const t = text.trim();
  if (isChatMode(schema)) return t ? { kind: 'invoke', body: { messages: [{ role: 'user', content: t }] } } : { kind: 'chatPrompt' };
  if (!t) return { kind: 'form' };
  const target = textProperty(schema);
  if (!target) return { kind: 'form', errors: ['This agent needs structured input - fill in the form.'] };
  const prefill = { [target]: t };
  const missing = fields(schema).filter((f) => f.required && f.name !== target);
  if (missing.length) return { kind: 'form', prefill };
  const checked = validateSubmission(schema, { [INPUT_PREFIX + target]: t });
  return checked.ok ? { kind: 'invoke', body: { input: checked.input } } : { kind: 'form', prefill, errors: checked.errors };
}

export type Validation = { ok: true; input: Record<string, unknown> } | { ok: false; errors: string[]; values: Record<string, unknown> };

function isEmpty(v: unknown): boolean {
  return v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
}

/**
 * Validates an Action.Submit payload (Teams sends Input.Number / Input.Toggle values as strings)
 * and returns the typed `input` object. Fields that are empty and optional are left out.
 */
export function validateSubmission(schema: JsonSchema | null | undefined, values: Record<string, unknown>): Validation {
  const input: Record<string, unknown> = {};
  const errors: string[] = [];
  for (const f of fields(schema)) {
    const raw = values[f.id];
    if (isEmpty(raw)) {
      if (f.required) errors.push(`${f.label} is required.`);
      continue;
    }
    switch (f.kind) {
      case 'boolean': {
        const s = String(raw).toLowerCase();
        if (s !== 'true' && s !== 'false') errors.push(`${f.label} must be true or false.`);
        else input[f.name] = s === 'true';
        break;
      }
      case 'number':
      case 'integer': {
        const n = typeof raw === 'number' ? raw : Number(String(raw).trim());
        if (!Number.isFinite(n)) errors.push(`${f.label} must be a number.`);
        else if (f.kind === 'integer' && !Number.isInteger(n)) errors.push(`${f.label} must be a whole number.`);
        else if (f.minimum !== undefined && n < f.minimum) errors.push(`${f.label} must be at least ${f.minimum}.`);
        else if (f.maximum !== undefined && n > f.maximum) errors.push(`${f.label} must be at most ${f.maximum}.`);
        else input[f.name] = n;
        break;
      }
      case 'choice': {
        const match = f.choices!.find((c) => String(c) === String(raw));
        if (match === undefined) errors.push(`${f.label} must be one of: ${f.choices!.map(String).join(', ')}.`);
        else input[f.name] = match;
        break;
      }
      case 'json': {
        try {
          const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
          const want = fieldKindType(schema, f.name);
          if (want === 'array' && !Array.isArray(parsed)) errors.push(`${f.label} must be a JSON array.`);
          else if (want === 'object' && (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed))) errors.push(`${f.label} must be a JSON object.`);
          else input[f.name] = parsed;
        } catch {
          errors.push(`${f.label} is not valid JSON.`);
        }
        break;
      }
      default: {
        const s = String(raw);
        if (f.minLength !== undefined && s.length < f.minLength) errors.push(`${f.label} needs at least ${f.minLength} characters.`);
        else if (f.maxLength !== undefined && s.length > f.maxLength) errors.push(`${f.label} allows at most ${f.maxLength} characters.`);
        else if (f.pattern && !safeTest(f.pattern, s)) errors.push(`${f.label} has the wrong format.`);
        else input[f.name] = s;
      }
    }
  }
  if (errors.length) {
    const kept: Record<string, unknown> = {};
    for (const f of fields(schema)) if (!isEmpty(values[f.id])) kept[f.name] = values[f.id];
    return { ok: false, errors, values: kept };
  }
  return { ok: true, input };
}

function fieldKindType(schema: JsonSchema | null | undefined, name: string): string | undefined {
  return baseType(properties(schema)[name] ?? {});
}

function safeTest(pattern: string, value: string): boolean {
  try {
    return new RegExp(pattern, 'u').test(value);
  } catch {
    return true; // the server decides
  }
}
