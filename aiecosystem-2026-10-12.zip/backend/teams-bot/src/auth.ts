/**
 * The Teams user's token for platform-api.
 *
 * `OAuthUserAuth` (dev/stage/prod): an Azure Bot "OAuth connection" (AIG_BOT_OAUTH_CONNECTION,
 * provider Azure AD v2, scope `api://<platform-api app id>/access_as_user`). Teams SSO: the sign-in
 * card carries the connection's `tokenExchangeResource`, Teams obtains an SSO token silently and
 * sends `signin/tokenExchange`; the bot exchanges it through the Bot Framework token service
 * (`UserTokenClient.exchangeToken`). Without SSO consent the user clicks the card and finishes
 * with `signin/verifyState` (magic code). The resulting token's audience is platform-api, which
 * validates it like a Web UI token, so every action is the user's own (team, role, audit trail).
 *
 * `DevUserAuth` (AIG_ENV=local only): `dev:<email>` for a platform-api running with
 * AIG_AUTH_MODE=dev; the email comes from the Teams member profile, the Emulator user name or
 * AIG_BOT_DEV_USER.
 */

import { CardFactory, type TurnContext, TeamsInfo } from 'botbuilder';

export interface UserAuth {
  /** The user's platform-api token, or null when the user must sign in first. */
  getToken(context: TurnContext, magicCode?: string): Promise<string | null>;
  /** Sends the sign-in (OAuth / SSO) card. */
  promptSignIn(context: TurnContext): Promise<void>;
  /** Teams SSO: exchange the SSO token. Returns true when the user is now signed in. */
  exchange(context: TurnContext, ssoToken: string): Promise<boolean>;
  signOut(context: TurnContext): Promise<void>;
}

interface TokenClient {
  getUserToken(userId: string, connectionName: string, channelId: string, magicCode: string): Promise<{ token?: string } | undefined>;
  getSignInResource(connectionName: string, activity: any, finalRedirect: string): Promise<any>;
  exchangeToken(userId: string, connectionName: string, channelId: string, req: { token: string }): Promise<{ token?: string } | undefined>;
  signOutUser(userId: string, connectionName: string, channelId: string): Promise<void>;
}

function tokenClient(context: TurnContext): TokenClient {
  const key = (context.adapter as any).UserTokenClientKey;
  const client = key ? context.turnState.get(key) : undefined;
  if (!client) throw new Error('no UserTokenClient on this adapter (is the bot running on CloudAdapter with credentials?)');
  return client as TokenClient;
}

export class OAuthUserAuth implements UserAuth {
  constructor(private connectionName: string, private clientOf: (c: TurnContext) => TokenClient = tokenClient) {}

  async getToken(context: TurnContext, magicCode?: string): Promise<string | null> {
    const a = context.activity;
    const res = await this.clientOf(context).getUserToken(a.from.id, this.connectionName, a.channelId, magicCode ?? '');
    return res?.token ?? null;
  }

  async promptSignIn(context: TurnContext): Promise<void> {
    const res = await this.clientOf(context).getSignInResource(this.connectionName, context.activity, '');
    const card = CardFactory.oauthCard(
      this.connectionName,
      'Sign in to AIG',
      'Sign in so the bot can start and manage team workspaces as you.',
      res?.signInLink,
      res?.tokenExchangeResource,
      res?.tokenPostResource,
    );
    await context.sendActivity({ attachments: [card] });
  }

  async exchange(context: TurnContext, ssoToken: string): Promise<boolean> {
    const a = context.activity;
    try {
      const res = await this.clientOf(context).exchangeToken(a.from.id, this.connectionName, a.channelId, { token: ssoToken });
      return Boolean(res?.token);
    } catch {
      return false;
    }
  }

  async signOut(context: TurnContext): Promise<void> {
    const a = context.activity;
    await this.clientOf(context).signOutUser(a.from.id, this.connectionName, a.channelId);
  }
}

const EMAIL = /^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;

export class DevUserAuth implements UserAuth {
  constructor(private fallbackUser?: string, private memberLookup = (c: TurnContext) => TeamsInfo.getMember(c, c.activity.from.id)) {}

  async getToken(context: TurnContext): Promise<string | null> {
    let email: string | undefined;
    if (context.activity.channelId === 'msteams') {
      try {
        const m = await this.memberLookup(context);
        email = m.email ?? m.userPrincipalName;
      } catch {
        /* not in a team context */
      }
    }
    const name = context.activity.from?.name;
    email = email ?? (name && EMAIL.test(name) ? name : undefined) ?? this.fallbackUser;
    return email && EMAIL.test(email) ? `dev:${email}` : null;
  }

  async promptSignIn(context: TurnContext): Promise<void> {
    await context.sendActivity('Local dev mode: set AIG_BOT_DEV_USER to your email (or use an Emulator user name that is an email).');
  }

  async exchange(): Promise<boolean> {
    return false;
  }

  async signOut(): Promise<void> {}
}
