/** HTTP server (restify): Bot Framework messages, orchestrator notifications, health. */

import {
  CloudAdapter,
  ConfigurationBotFrameworkAuthentication,
  type ConfigurationBotFrameworkAuthenticationOptions,
  type TurnContext,
} from 'botbuilder';
import restify from 'restify';
import { DevUserAuth, OAuthUserAuth, type UserAuth } from './auth.js';
import { AigTeamsBot } from './bot.js';
import { type BotConfig, clean } from './config.js';
import { NotifyHandler, type Proactive } from './notify.js';
import { PlatformClient } from './platform.js';
import { type ConversationStore, FileStore, MemoryStore } from './store.js';

export interface ServerParts {
  server: restify.Server;
  adapter: CloudAdapter;
  bot: AigTeamsBot;
  notify: NotifyHandler;
}

export function createAdapter(env: Record<string, string | undefined> = process.env): CloudAdapter {
  // Reads MicrosoftAppId / MicrosoftAppPassword / MicrosoftAppType / MicrosoftAppTenantId; placeholders
  // count as unset (no app id = anonymous, Bot Framework Emulator in local only - loadConfig enforces).
  const settings = clean(env.MicrosoftAppId)
    ? Object.fromEntries(Object.entries(env).filter(([k, v]) => k.startsWith('Microsoft') && clean(v)))
    : {};
  const auth = new ConfigurationBotFrameworkAuthentication(settings as ConfigurationBotFrameworkAuthenticationOptions);
  const adapter = new CloudAdapter(auth);
  adapter.onTurnError = async (context: TurnContext, error: Error) => {
    console.error('teams-bot: turn error', error.message);
    await context.sendActivity('Something went wrong. Please try again.').catch(() => undefined);
  };
  return adapter;
}

export function createServer(config: BotConfig, opts: { adapter?: CloudAdapter; store?: ConversationStore; auth?: UserAuth; platform?: PlatformClient; proactive?: Proactive } = {}): ServerParts {
  const adapter = opts.adapter ?? createAdapter();
  const store = opts.store ?? (config.stateFile ? new FileStore(config.stateFile) : new MemoryStore());
  const auth = opts.auth ?? (config.authMode === 'dev' ? new DevUserAuth(config.devUser) : new OAuthUserAuth(config.oauthConnectionName));
  const platform = opts.platform ?? new PlatformClient(config.platformApiUrl);
  const proactive: Proactive = opts.proactive ?? ((reference, logic) => adapter.continueConversationAsync(config.microsoftAppId ?? '', reference, logic));
  const bot = new AigTeamsBot({ platform, auth, store, webUrl: config.webUrl, proactive });
  const notify = new NotifyHandler(config.notifySecret, store, proactive, config.webUrl);

  const server = restify.createServer({ name: 'aig-teams-bot' });
  server.get('/healthz', (_req, res, next) => {
    res.json({ status: 'ok', auth: config.authMode, notify: config.notifySecret ? 'configured' : 'missing' });
    return next();
  });
  server.post('/api/messages', restify.plugins.bodyParser({ maxBodySize: 1 << 20 }), async (req, res) => {
    await adapter.process(req as any, res as any, (context) => bot.run(context));
  });
  server.post('/api/notify', restify.plugins.bodyReader({ maxBodySize: 64 * 1024 }), async (req, res) => {
    try {
      const raw = (req as any).body ?? '';
      const result = await notify.handle(req.headers, Buffer.isBuffer(raw) ? raw : String(raw));
      res.json(result.status, result.body);
    } catch (err) {
      console.error('teams-bot: notify failed', err instanceof Error ? err.message : 'unknown');
      res.json(500, { error: { code: 'internal_error', message: 'notification could not be delivered' } });
    }
  });
  return { server, adapter, bot, notify };
}
