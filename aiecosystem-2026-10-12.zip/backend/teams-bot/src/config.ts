/**
 * Bot configuration (backend/contracts/env-vars.md, "Teams bot"). Values that are empty or contain
 * `__REPLACE_ME` / `<...>` count as unset. Secrets (MicrosoftAppPassword, AIG_BOT_NOTIFY_SECRET)
 * are never logged.
 */

export type AuthMode = 'oauth' | 'dev';

export interface BotConfig {
  env: string;
  port: number;
  platformApiUrl: string;
  webUrl?: string;
  authMode: AuthMode;
  oauthConnectionName: string;
  devUser?: string;
  notifySecret?: string;
  stateFile?: string;
  microsoftAppId?: string;
}

export class ConfigError extends Error {}

export function unset(value: string | undefined): boolean {
  if (value === undefined) return true;
  const v = value.trim();
  return !v || v.includes('__REPLACE_ME') || /<[^>]*>/.test(v);
}

export function clean(value: string | undefined): string | undefined {
  return unset(value) ? undefined : value!.trim();
}

export function loadConfig(env: Record<string, string | undefined> = process.env): BotConfig {
  const aigEnv = clean(env.AIG_ENV) ?? 'local';
  if (!['local', 'dev', 'stage', 'prod'].includes(aigEnv)) throw new ConfigError('AIG_ENV must be local, dev, stage or prod');
  const platformApiUrl = clean(env.AIG_PLATFORM_API_URL);
  if (!platformApiUrl) throw new ConfigError('AIG_PLATFORM_API_URL is required');
  const authMode = (clean(env.AIG_BOT_AUTH_MODE) ?? (aigEnv === 'local' ? 'dev' : 'oauth')) as AuthMode;
  if (authMode !== 'oauth' && authMode !== 'dev') throw new ConfigError('AIG_BOT_AUTH_MODE must be oauth or dev');
  if (authMode === 'dev' && aigEnv !== 'local') {
    throw new ConfigError('AIG_BOT_AUTH_MODE=dev is only allowed with AIG_ENV=local (platform-api dev auth)');
  }
  const appId = clean(env.MicrosoftAppId);
  if (aigEnv !== 'local') {
    if (!appId || unset(env.MicrosoftAppPassword) && clean(env.MicrosoftAppType) !== 'UserAssignedMSI') {
      throw new ConfigError('MicrosoftAppId and MicrosoftAppPassword (or MicrosoftAppType=UserAssignedMSI) are required outside local');
    }
    if (!clean(env.AIG_BOT_NOTIFY_SECRET)) throw new ConfigError('AIG_BOT_NOTIFY_SECRET is required outside local');
  }
  return {
    env: aigEnv,
    port: Number(clean(env.PORT) ?? 3978),
    platformApiUrl: platformApiUrl.replace(/\/+$/, ''),
    webUrl: clean(env.AIG_WEB_URL)?.replace(/\/+$/, ''),
    authMode,
    oauthConnectionName: clean(env.AIG_BOT_OAUTH_CONNECTION) ?? 'aig-platform',
    devUser: clean(env.AIG_BOT_DEV_USER),
    notifySecret: clean(env.AIG_BOT_NOTIFY_SECRET),
    stateFile: clean(env.AIG_BOT_STATE_FILE),
    microsoftAppId: appId,
  };
}
