import { loadConfig } from './config.js';
import { createServer } from './server.js';

const config = loadConfig();
const { server } = createServer(config);
server.listen(config.port, () => {
  console.log(`aig-teams-bot listening on :${config.port} (env=${config.env}, auth=${config.authMode})`);
});
