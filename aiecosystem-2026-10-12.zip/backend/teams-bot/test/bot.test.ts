import type { Activity } from 'botbuilder';
import { describe, expect, it } from 'vitest';
import { HELP, parseCommand } from '../src/commands.js';
import { card, setup, ws } from './helpers.js';

const USER = 'user1';
function signIn(auth: ReturnType<typeof setup>['auth'], token = 'entra-token-jane') {
  auth.tokens.set(USER, token);
}

describe('commands', () => {
  it('parses text commands and strips mentions', () => {
    expect(parseCommand('<at>AIG</at> start workspace https://github.com/aig/x #42 Fix the bug')).toEqual({
      kind: 'start', repo_url: 'https://github.com/aig/x', work_item: '#42', title: 'Fix the bug',
    });
    expect(parseCommand('start workspace https://github.com/aig/x CLAIMS-1')).toMatchObject({ title: 'Work item CLAIMS-1' });
    expect(parseCommand('start')).toEqual({ kind: 'form' });
    expect(parseCommand('start workspace')).toEqual({ kind: 'form' });
    expect(parseCommand('start workspace onlyrepo').kind).toBe('unknown');
    expect(parseCommand('STATUS abc12345')).toEqual({ kind: 'status', id: 'abc12345' });
    expect(parseCommand('cancel 3f2b8a52')).toEqual({ kind: 'cancel', id: '3f2b8a52' });
    expect(parseCommand('status').kind).toBe('unknown');
    expect(parseCommand('list')).toEqual({ kind: 'list' });
    expect(parseCommand('')).toEqual({ kind: 'help' });
    expect(parseCommand('dance').kind).toBe('unknown');
  });
});

describe('AigTeamsBot', () => {
  it('answers help and unknown without needing sign-in', async () => {
    const { adapter, auth } = setup();
    await adapter.send('help').assertReply(HELP).startTest();
    await adapter.send('dance').assertReply((a) => expect(a.text).toContain('did not understand')).startTest();
    expect(auth.prompts).toBe(0);
  });

  it('starts a workspace with the USER token and remembers the conversation', async () => {
    const { adapter, auth, api, store } = setup();
    signIn(auth);
    await adapter
      .send({ text: 'start workspace https://github.com/aig/claims-triage #42 Fix rounding', from: { id: USER, name: 'Jane' } } as Partial<Activity>)
      .assertReply((a) => {
        const c = card(a);
        expect(c.body[0].text).toContain('I will post updates here');
        expect(c.body[1].text).toBe('Fix rounding');
        expect(c.actions.map((x: any) => x.title)).toEqual(['Open in AIG portal', 'Refresh', 'Cancel']);
      })
      .startTest();
    const req = api.requests[0];
    expect(req).toMatchObject({ method: 'POST', url: 'http://platform.test/api/v1/workspaces', auth: 'Bearer entra-token-jane' });
    expect(req.body).toEqual({ repo_url: 'https://github.com/aig/claims-triage', work_item: '#42', title: 'Fix rounding' });
    const sub = store.get(api.items[0].id)!;
    expect(sub.lastStatus).toBe('queued');
    expect(sub.reference.conversation?.id).toBeTruthy();
  });

  it('shows the form and accepts its submission (description + job profile)', async () => {
    const { adapter, auth, api } = setup();
    signIn(auth);
    await adapter
      .send({ text: 'start', from: { id: USER } } as Partial<Activity>)
      .assertReply((a) => {
        const ids = card(a).body.filter((b: any) => b.id).map((b: any) => b.id);
        expect(ids).toEqual(['repo_url', 'work_item', 'title', 'description', 'job_profile']);
        expect(card(a).actions[0].data).toEqual({ action: 'startWorkspace' });
      })
      .startTest();
    expect(api.requests).toHaveLength(0);
    await adapter
      .send({ from: { id: USER }, value: { action: 'startWorkspace', repo_url: 'https://github.com/aig/uw', work_item: 'https://github.com/aig/uw/issues/7', title: 'Quote bug', description: 'Premium off', job_profile: 'underwriting' } } as Partial<Activity>)
      .assertReply((a) => expect(card(a).body[1].text).toBe('Quote bug'))
      .startTest();
    expect(api.requests[0].body).toEqual({ repo_url: 'https://github.com/aig/uw', work_item: 'https://github.com/aig/uw/issues/7', title: 'Quote bug', description: 'Premium off', job_profile: 'underwriting' });
    await adapter
      .send({ from: { id: USER }, value: { action: 'startWorkspace', repo_url: '', work_item: '', title: '' } } as Partial<Activity>)
      .assertReply((a) => expect(a.text).toContain('required'))
      .startTest();
  });

  it('status by id prefix, list and cancel', async () => {
    const { adapter, auth, api } = setup();
    signIn(auth);
    api.items = [ws({ status: 'pr_opened', pr_url: 'https://github.com/aig/claims-triage/pull/9', log_url: 'https://logs.example.com/x' }),
      ws({ id: '99999999-1111-4222-8333-444455556666', title: 'Other', status: 'failed', error: 'tests: still failing' })];
    await adapter
      .send({ text: 'status 3f2b8a52', from: { id: USER } } as Partial<Activity>)
      .assertReply((a) => {
        const c = card(a);
        expect(c.body[2].text).toBe('Pull request opened');
        expect(c.actions[0]).toEqual({ type: 'Action.OpenUrl', title: 'Open pull request', url: 'https://github.com/aig/claims-triage/pull/9' });
        expect(c.actions.map((x: any) => x.title)).toContain('Logs');
      })
      .startTest();
    await adapter
      .send({ text: 'status 99999999-1111-4222-8333-444455556666', from: { id: USER } } as Partial<Activity>)
      .assertReply((a) => {
        expect(card(a).body.some((b: any) => b.text === 'tests: still failing')).toBe(true);
        expect(card(a).actions.map((x: any) => x.title)).not.toContain('Cancel');
      })
      .startTest();
    await adapter
      .send({ text: 'list', from: { id: USER } } as Partial<Activity>)
      .assertReply((a) => {
        expect(a.text).toContain('**Your workspaces** (2)');
        expect(a.text).toContain('`3f2b8a52` **Fix rounding** - Pull request opened - [PR](https://github.com/aig/claims-triage/pull/9)');
      })
      .startTest();
    await adapter
      .send({ text: 'status nope', from: { id: USER } } as Partial<Activity>)
      .assertReply('No workspace "nope" found.')
      .startTest();
    await adapter
      .send({ from: { id: USER }, value: { action: 'cancel', id: '3f2b8a52-1111-4222-8333-444455556666' } } as Partial<Activity>)
      .assertReply((a) => expect(card(a).body[0].text).toBe('Workspace cancelled'))
      .startTest();
    expect(api.requests.at(-1)).toMatchObject({ method: 'POST', url: 'http://platform.test/api/v1/workspaces/3f2b8a52-1111-4222-8333-444455556666/cancel' });
    expect(api.requests.every((r) => r.auth === 'Bearer entra-token-jane')).toBe(true);
  });

  it('asks to sign in, then replays the command after the Teams SSO token exchange', async () => {
    const { adapter, auth, api } = setup();
    await adapter.send({ text: 'list', from: { id: USER }, channelId: 'msteams' } as Partial<Activity>).assertReply('SIGN-IN CARD').startTest();
    expect(api.requests).toHaveLength(0);
    await adapter
      .send({ type: 'invoke', name: 'signin/tokenExchange', channelId: 'msteams', from: { id: USER }, value: { id: 'x', connectionName: 'aig-platform', token: 'sso' } } as Partial<Activity>)
      .assertReply((a) => expect(a.text).toContain('You have no workspaces yet'))
      .startTest();
    expect(api.requests[0].auth).toBe('Bearer entra-token-for-sso');
  });

  it('answers 412 when the SSO exchange fails (Teams falls back to the sign-in card)', async () => {
    const { adapter, auth } = setup();
    auth.exchangeOk = false;
    await adapter
      .send({ type: 'invoke', name: 'signin/tokenExchange', channelId: 'msteams', from: { id: USER }, value: { id: 'x', connectionName: 'aig-platform', token: 'sso' } } as Partial<Activity>)
      .assertReply((a) => {
        expect(a.type).toBe('invokeResponse');
        expect((a.value as any).status).toBe(412);
      })
      .startTest();
  });

  it('completes sign-in with the magic code (signin/verifyState)', async () => {
    const { adapter, api } = setup();
    await adapter.send({ text: 'list', from: { id: USER }, channelId: 'msteams' } as Partial<Activity>).assertReply('SIGN-IN CARD').startTest();
    await adapter
      .send({ type: 'invoke', name: 'signin/verifyState', channelId: 'msteams', from: { id: USER }, value: { state: '123456' } } as Partial<Activity>)
      .assertReply((a) => expect(a.text).toContain('You have no workspaces yet'))
      .startTest();
    expect(api.requests[0].auth).toBe('Bearer entra-token-from-magic-code');
  });

  it('signs the user out on 401 and reports platform errors', async () => {
    const { adapter, auth, api } = setup();
    signIn(auth);
    api.failWith = { status: 401, code: 'unauthenticated', message: 'expired' };
    await adapter.send({ text: 'list', from: { id: USER } } as Partial<Activity>).assertReply((a) => expect(a.text).toContain('expired')).startTest();
    expect(auth.signedOut).toBe(1);
    signIn(auth);
    api.failWith = { status: 400, code: 'invalid_job_profile', message: 'job profile must be one of [general]' };
    await adapter
      .send({ text: 'start workspace https://github.com/aig/x #1 T', from: { id: USER } } as Partial<Activity>)
      .assertReply('job profile must be one of [general] (invalid_job_profile)')
      .startTest();
  });

  it('greets new members with help', async () => {
    const { adapter } = setup();
    await adapter
      .send({ type: 'conversationUpdate', membersAdded: [{ id: 'someone', name: 'Bob' }], recipient: { id: 'bot', name: 'AIG' } } as Partial<Activity>)
      .assertReply(HELP)
      .startTest();
  });
});
