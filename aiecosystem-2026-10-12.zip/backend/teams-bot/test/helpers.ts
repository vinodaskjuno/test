import { type Activity, TestAdapter, TurnContext } from 'botbuilder';
import { AigTeamsBot } from '../src/bot.js';
import type { UserAuth } from '../src/auth.js';
import type { PollerOptions } from '../src/background.js';
import type { Proactive } from '../src/notify.js';
import { type CatalogItem, type Invocation, PlatformClient, type Workspace } from '../src/platform.js';
import { MemoryStore } from '../src/store.js';

export const SERVICE_TOKEN = 'svc-SUPERSECRET-should-never-be-used';

export function ws(over: Partial<Workspace> = {}): Workspace {
  return {
    id: '3f2b8a52-1111-4222-8333-444455556666',
    repo_url: 'https://github.com/aig/claims-triage',
    work_item: '#42',
    title: 'Fix rounding',
    description: '',
    job_profile: null,
    status: 'queued',
    requested_by: 'jane@example.com',
    team: 'claims-ai',
    pr_url: null,
    log_url: null,
    error: null,
    created_at: '2026-10-09T10:00:00Z',
    updated_at: '2026-10-09T10:00:00Z',
    ...over,
  };
}

export function agent(id: string, over: { input_schema?: any; name?: string; description?: string; team?: string; lifecycle?: string; versions?: any[] } = {}): CatalogItem {
  const def = { env: 'prod', version: '1.2.0', kind: 'https', verified: true, verified_at: '2026-10-01T00:00:00Z', input_schema: over.input_schema ?? null, output_schema: null };
  return {
    agent: { agent_id: id, name: over.name ?? id, description: over.description ?? `The ${id} agent`, team: over.team ?? 'claims-ai', owner: 'owner@example.com', status: 'active', lifecycle: over.lifecycle ?? 'active', tags: [], visibility: 'team' },
    versions: over.versions ?? [def],
    default: over.versions?.[0] ?? def,
    access: 'team',
  };
}

/** In-memory platform-api behind a fetch implementation; records every request. */
export class FakePlatformApi {
  items: Workspace[] = [];
  agents: CatalogItem[] = [];
  /** Output returned by sync invokes (or a function of the request body). */
  output: unknown = 'Hello from the agent';
  invokeFail?: { status: number; code: string; message: string };
  invocations = new Map<string, Invocation>();
  private seq = 0;
  requests: { method: string; url: string; auth: string | null; body: any }[] = [];
  failWith?: { status: number; code: string; message: string };

  fetch = async (url: string, init: RequestInit = {}): Promise<Response> => {
    const headers = new Headers(init.headers);
    const body = init.body ? JSON.parse(String(init.body)) : undefined;
    const method = init.method ?? 'GET';
    this.requests.push({ method, url, auth: headers.get('authorization'), body });
    if (headers.get('x-aig-service-token')) throw new Error('service token must never be sent by the bot');
    const json = (status: number, data: unknown) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });
    if (this.failWith) return json(this.failWith.status, { error: { code: this.failWith.code, message: this.failWith.message } });
    const u = new URL(url);
    const path = u.pathname;
    if (method === 'GET' && path === '/api/v1/catalog') {
      const q = (u.searchParams.get('q') ?? '').toLowerCase();
      const items = this.agents.filter((i) => !q || [i.agent.agent_id, i.agent.name, i.agent.description ?? ''].some((v) => v.toLowerCase().includes(q)));
      return json(200, { items, total: items.length, teams: [...new Set(items.map((i) => i.agent.team))], tags: [] });
    }
    const inv = path.match(/^\/api\/v1\/agents\/([^/]+)\/invoke$/);
    if (method === 'POST' && inv) {
      if (this.invokeFail) return json(this.invokeFail.status, { error: { code: this.invokeFail.code, message: this.invokeFail.message } });
      const agentId = decodeURIComponent(inv[1]);
      const id = `inv-${String(++this.seq).padStart(4, '0')}-aaaa-4bbb-8ccc-dddddddddddd`;
      const env = u.searchParams.get('env') ?? 'prod';
      const version = u.searchParams.get('version') ?? '1.2.0';
      if (u.searchParams.get('mode') === 'background') {
        this.invocations.set(id, { id, agent_id: agentId, version, env, status: 'queued', trace_id: null, duration_ms: null, usage: null, error_code: null, error_message: null, output_available: false, output: null });
        return json(202, { invocation_id: id, agent_id: agentId, version, env, status: 'queued', location: `/api/v1/invocations/${id}` });
      }
      return json(200, { invocation_id: id, agent_id: agentId, version, env, status: 'succeeded', output: this.output,
        usage: { prompt_tokens: 12, completion_tokens: 30, total_tokens: 42 }, trace_id: 'trace-abc123', duration_ms: 1534 });
    }
    const invocation = path.match(/^\/api\/v1\/invocations\/([^/]+)$/);
    if (method === 'GET' && invocation) {
      const found = this.invocations.get(decodeURIComponent(invocation[1]));
      return found ? json(200, found) : json(404, { error: { code: 'invocation_not_found', message: 'no such invocation' } });
    }
    if (method === 'POST' && path === '/api/v1/workspaces') {
      const created = ws({ ...body, id: `0000000${this.items.length + 1}-aaaa-4bbb-8ccc-dddddddddddd`.slice(-36), requested_by: 'jane@example.com' });
      this.items.unshift(created);
      return json(201, created);
    }
    if (method === 'GET' && path === '/api/v1/workspaces') return json(200, { items: this.items, total: this.items.length });
    const m = path.match(/^\/api\/v1\/workspaces\/([^/]+)(\/cancel)?$/);
    const found = m && this.items.find((w) => w.id === decodeURIComponent(m[1]));
    if (!found) return json(404, { error: { code: 'workspace_not_found', message: 'workspace not found' } });
    if (m![2]) {
      found.status = 'cancelled';
      return json(200, found);
    }
    return json(200, found);
  };
}

export class FakeAuth implements UserAuth {
  tokens = new Map<string, string>();
  prompts = 0;
  signedOut = 0;
  exchangeOk = true;
  async getToken(context: TurnContext, magicCode?: string) {
    if (magicCode === '123456') this.tokens.set(context.activity.from.id, 'entra-token-from-magic-code');
    return this.tokens.get(context.activity.from.id) ?? null;
  }
  async promptSignIn(context: TurnContext) {
    this.prompts++;
    await context.sendActivity('SIGN-IN CARD');
  }
  async exchange(context: TurnContext, sso: string) {
    if (this.exchangeOk) this.tokens.set(context.activity.from.id, `entra-token-for-${sso}`);
    return this.exchangeOk;
  }
  async signOut(context: TurnContext) {
    this.signedOut++;
    this.tokens.delete(context.activity.from.id);
  }
}

export function setup(opts: { background?: boolean; poller?: PollerOptions } = {}) {
  const api = new FakePlatformApi();
  const auth = new FakeAuth();
  const store = new MemoryStore();
  const platform = new PlatformClient('http://platform.test', api.fetch);
  let bot!: AigTeamsBot;
  const adapter = new TestAdapter(async (context) => bot.run(context));
  const { proactive, sent } = testProactive(new TestAdapter()); // separate adapter: proactive sends do not queue up as replies
  bot = new AigTeamsBot({ platform, auth, store, webUrl: 'https://aig.example.com', ...(opts.background ? { proactive, poller: opts.poller } : {}) });
  return { api, auth, store, bot, adapter, sent };
}

/** Proactive sender for tests: runs the logic on a TestAdapter context built from the reference. */
export function testProactive(adapter: TestAdapter): { proactive: Proactive; sent: Partial<Activity>[] } {
  const sent: Partial<Activity>[] = [];
  const proactive: Proactive = async (reference, logic) => {
    const activity = TurnContext.applyConversationReference({ type: 'event', name: 'proactive' }, reference, true);
    const context = new TurnContext(adapter, activity);
    context.onSendActivities(async (_ctx, activities, next) => {
      sent.push(...activities);
      return next();
    });
    await logic(context);
  };
  return { proactive, sent };
}

export function card(activity: Partial<Activity>): any {
  return activity.attachments?.[0]?.content;
}
