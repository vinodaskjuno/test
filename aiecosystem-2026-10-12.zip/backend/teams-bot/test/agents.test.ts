import type { Activity } from 'botbuilder';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { friendlyError, outputBlocks } from '../src/agentCards.js';
import { BackgroundRuns } from '../src/background.js';
import { HELP, parseCommand } from '../src/commands.js';
import { PlatformClient } from '../src/platform.js';
import { fields, planRun, validateSubmission } from '../src/schema.js';
import { agent, card, FakePlatformApi, setup, testProactive } from './helpers.js';
import { TestAdapter } from 'botbuilder';

const USER = 'user1';
const from = { id: USER, name: 'Jane' };
const msg = (text: string) => ({ text, from }) as Partial<Activity>;
const submit = (value: Record<string, unknown>) => ({ from, value }) as Partial<Activity>;

const SUMMARIZER_SCHEMA = {
  type: 'object',
  required: ['claim_text'],
  properties: { claim_text: { type: 'string' }, max_words: { type: 'integer', minimum: 10 } },
};

const UW_SCHEMA = {
  type: 'object',
  required: ['applicant', 'amount', 'product'],
  properties: {
    applicant: { type: 'string', title: 'Applicant name', description: 'Full legal name' },
    amount: { type: 'number', title: 'Amount', minimum: 1000, maximum: 5000000, default: 250000 },
    years: { type: 'integer', minimum: 1, maximum: 30 },
    product: { type: 'string', enum: ['term', 'whole', 'universal'], default: 'term' },
    smoker: { type: 'boolean', title: 'Smoker', default: false },
    notes: { type: 'string' },
    summary: { type: 'string', maxLength: 2000 },
    memo: { type: 'string', format: 'textarea' },
    riders: { type: 'array', items: { type: 'string' } },
  },
};

function signedIn(s: ReturnType<typeof setup>) {
  s.auth.tokens.set(USER, 'entra-token-jane');
  return s;
}

function inputs(c: any): any[] {
  return c.body.filter((b: any) => typeof b.type === 'string' && b.type.startsWith('Input.'));
}

describe('agent commands', () => {
  it('parses agents and run', () => {
    expect(parseCommand('agents')).toEqual({ kind: 'agents', query: '' });
    expect(parseCommand('<at>AIG</at> agents claims triage')).toEqual({ kind: 'agents', query: 'claims triage' });
    expect(parseCommand('run claims-summarizer Summarise claim 123')).toEqual({ kind: 'run', agent: 'claims-summarizer', text: 'Summarise claim 123', background: false });
    expect(parseCommand('run --background --env stage --version 2.0.0 fraud-check check it')).toEqual({
      kind: 'run', agent: 'fraud-check', text: 'check it', background: true, env: 'stage', version: '2.0.0',
    });
    expect(parseCommand('run -b --env=dev x')).toEqual({ kind: 'run', agent: 'x', text: '', background: true, env: 'dev' });
    expect(parseCommand('run q&amp;a is a &lt; b?')).toMatchObject({ agent: 'q&a', text: 'is a < b?' });
    expect(parseCommand('run')).toEqual({ kind: 'run', agent: '', text: '', background: false });
    expect(HELP).toContain('`agents [search]`');
    expect(HELP).toContain('`run --background <agent id> <input>`');
  });

  it('lists the agents the user may run as an Adaptive Card (user token, query in q=)', async () => {
    const s = signedIn(setup());
    s.api.agents = [agent('claims-summarizer', { name: 'Claims summarizer', description: 'Summarises claims' }), agent('fraud-check', { team: 'fraud', lifecycle: 'deprecated' })];
    await s.adapter
      .send(msg('agents'))
      .assertReply((a) => {
        const c = card(a);
        expect(c.body[0].text).toBe('Agents you can run (2)');
        const first = c.body[1];
        expect(first.items[0].text).toBe('Claims summarizer');
        expect(first.items[1].text).toBe('claims-summarizer');
        expect(first.items.find((x: any) => x.type === 'FactSet').facts).toEqual([
          { title: 'Team', value: 'claims-ai' }, { title: 'Default', value: '1.2.0 (prod)' }, { title: 'Status', value: 'active' },
        ]);
        const actions = first.items.find((x: any) => x.type === 'ActionSet').actions;
        expect(actions[0]).toEqual({ type: 'Action.Submit', title: 'Run', data: { action: 'agent.form', agent_id: 'claims-summarizer', env: 'prod', version: '1.2.0' } });
        expect(actions[1].url).toBe('https://aig.example.com/agents/claims-summarizer');
        expect(c.body[2].items.find((x: any) => x.type === 'FactSet').facts[2].value).toBe('deprecated');
      })
      .startTest();
    await s.adapter
      .send(msg('agents summarises'))
      .assertReply((a) => expect(card(a).body[0].text).toBe('Agents matching "summarises" (1)'))
      .startTest();
    await s.adapter.send(msg('agents nothing-here')).assertReply((a) => expect(card(a).body[1].text).toContain('No agents match')).startTest();
    expect(s.api.requests.map((r) => r.url)).toEqual([
      'http://platform.test/api/v1/catalog', 'http://platform.test/api/v1/catalog?q=summarises', 'http://platform.test/api/v1/catalog?q=nothing-here',
    ]);
    expect(s.api.requests.every((r) => r.auth === 'Bearer entra-token-jane')).toBe(true);
  });

  it('asks to sign in before listing agents, then replays', async () => {
    const s = setup();
    s.api.agents = [agent('a1')];
    await s.adapter.send({ text: 'agents', from, channelId: 'msteams' } as Partial<Activity>).assertReply('SIGN-IN CARD').startTest();
    await s.adapter
      .send({ type: 'invoke', name: 'signin/tokenExchange', channelId: 'msteams', from, value: { id: 'x', connectionName: 'aig-platform', token: 'sso' } } as Partial<Activity>)
      .assertReply((a) => expect(card(a).body[0].text).toBe('Agents you can run (1)'))
      .startTest();
    expect(s.api.requests[0].auth).toBe('Bearer entra-token-for-sso');
  });

  it('run maps the text onto the single required string property and shows the result card', async () => {
    const s = signedIn(setup());
    s.api.agents = [agent('claims-summarizer', { name: 'Claims summarizer', input_schema: SUMMARIZER_SCHEMA })];
    await s.adapter
      .send(msg('run claims-summarizer Summarise claim 123'))
      .assertReply((a) => {
        const c = card(a);
        expect(c.body[1].text).toBe('Claims summarizer');
        expect(c.body[2].text).toBe('Succeeded');
        expect(c.body[3].text).toBe('Hello from the agent');
        expect(c.body[4].facts).toEqual([
          { title: 'Version', value: '1.2.0 (prod)' },
          { title: 'Duration', value: '1.5 s' },
          { title: 'Tokens', value: '42 (12 in, 30 out)' },
          { title: 'Trace id', value: 'trace-abc123' },
          { title: 'Run id', value: 'inv-0001-aaaa-4bbb-8ccc-dddddddddddd' },
        ]);
        expect(c.actions[0].data).toEqual({ action: 'agent.form', agent_id: 'claims-summarizer', env: 'prod', version: '1.2.0' });
      })
      .startTest();
    const inv = s.api.requests[1];
    expect(inv).toMatchObject({ method: 'POST', url: 'http://platform.test/api/v1/agents/claims-summarizer/invoke?mode=sync&env=prod&version=1.2.0', auth: 'Bearer entra-token-jane' });
    expect(inv.body).toEqual({ input: { claim_text: 'Summarise claim 123' } });
  });

  it('run uses a well-known text property (question) and pins --env/--version', async () => {
    const s = signedIn(setup());
    const versions = [
      { env: 'prod', version: '1.2.0', verified: true, input_schema: { type: 'object', properties: { question: { type: 'string' }, lang: { type: 'string' } } } },
      { env: 'stage', version: '2.0.0', verified: true, input_schema: { type: 'object', properties: { question: { type: 'string' } } } },
    ];
    s.api.agents = [agent('policy-qa', { versions })];
    await s.adapter.send(msg('run --env stage --version 2.0.0 policy-qa What is covered?')).assertReply((a) => expect(card(a).body[2].text).toBe('Succeeded')).startTest();
    expect(s.api.requests[1].url).toBe('http://platform.test/api/v1/agents/policy-qa/invoke?mode=sync&env=stage&version=2.0.0');
    expect(s.api.requests[1].body).toEqual({ input: { question: 'What is covered?' } });
    await s.adapter.send(msg('run --version 9.9.9 policy-qa hi')).assertReply((a) => expect(a.text).toContain('does not exist')).startTest();
    expect(s.api.requests).toHaveLength(3); // no invoke for the unknown version
  });

  it('run without input schema uses chat mode; structured output becomes a FactSet or JSON', async () => {
    const s = signedIn(setup());
    s.api.agents = [agent('helper')];
    s.api.output = { decision: 'approve', score: 0.92, flagged: false };
    await s.adapter
      .send(msg('run helper hi there'))
      .assertReply((a) => expect(card(a).body[3]).toEqual({ type: 'FactSet', facts: [{ title: 'decision', value: 'approve' }, { title: 'score', value: '0.92' }, { title: 'flagged', value: 'false' }] }))
      .startTest();
    expect(s.api.requests[1].body).toEqual({ messages: [{ role: 'user', content: 'hi there' }] });
    s.api.output = { items: [{ a: 1 }] };
    await s.adapter
      .send(msg('run helper again'))
      .assertReply((a) => {
        expect(card(a).body[3].fontType).toBe('Monospace');
        expect(card(a).body[3].text).toBe(JSON.stringify({ items: [{ a: 1 }] }, null, 2));
      })
      .startTest();
    // no message: a prompt card with one message box
    await s.adapter
      .send(msg('run helper'))
      .assertReply((a) => {
        expect(inputs(card(a)).map((i) => i.id)).toEqual(['aig.message', 'aig.background']);
        expect(card(a).actions[0].data).toEqual({ action: 'agent.run', agent_id: 'helper', env: 'prod', version: '1.2.0' });
      })
      .startTest();
    // chat prompt submission
    await s.adapter.send(submit({ action: 'agent.run', agent_id: 'helper', env: 'prod', version: '1.2.0', 'aig.message': 'from the card', 'aig.background': 'false' }))
      .assertReply((a) => expect(card(a).body[2].text).toBe('Succeeded')).startTest();
    expect(s.api.requests.at(-1)!.body).toEqual({ messages: [{ role: 'user', content: 'from the card' }] });
  });

  it('generates the form card from the schema (all simple types, required, enum, defaults)', async () => {
    const s = signedIn(setup());
    s.api.agents = [agent('underwriter', { name: 'Underwriter', input_schema: UW_SCHEMA })];
    await s.adapter
      .send(msg('run underwriter'))
      .assertReply((a) => {
        const c = card(a);
        expect(c.body[0].text).toBe('Run Underwriter');
        const byId = Object.fromEntries(inputs(c).map((i) => [i.id, i]));
        expect(Object.keys(byId)).toEqual(['input.applicant', 'input.amount', 'input.years', 'input.product', 'input.smoker', 'input.notes', 'input.summary', 'input.memo', 'input.riders', 'aig.background']);
        expect(byId['input.applicant']).toMatchObject({ type: 'Input.Text', label: 'Applicant name', isRequired: true });
        expect(byId['input.applicant'].isMultiline).toBeUndefined();
        expect(c.body.some((b: any) => b.type === 'TextBlock' && b.text === 'Full legal name')).toBe(true);
        expect(byId['input.amount']).toMatchObject({ type: 'Input.Number', label: 'Amount', isRequired: true, min: 1000, max: 5000000, value: 250000 });
        expect(byId['input.years']).toMatchObject({ type: 'Input.Number', min: 1, max: 30 });
        expect(byId['input.years'].isRequired).toBeUndefined();
        expect(byId['input.product']).toMatchObject({ type: 'Input.ChoiceSet', isRequired: true, value: 'term', choices: [{ title: 'term', value: 'term' }, { title: 'whole', value: 'whole' }, { title: 'universal', value: 'universal' }] });
        expect(byId['input.smoker']).toMatchObject({ type: 'Input.Toggle', label: 'Smoker', value: 'false', valueOn: 'true', valueOff: 'false' });
        expect(byId['input.notes'].isMultiline).toBe(true); // name contains notes
        expect(byId['input.summary']).toMatchObject({ isMultiline: true, maxLength: 2000 }); // maxLength > 200
        expect(byId['input.memo'].isMultiline).toBe(true); // format textarea
        expect(byId['input.riders']).toMatchObject({ type: 'Input.Text', isMultiline: true, placeholder: 'JSON' });
        expect(c.actions).toEqual([{ type: 'Action.Submit', title: 'Run', data: { action: 'agent.run', agent_id: 'underwriter', env: 'prod', version: '1.2.0' } }]);
      })
      .startTest();
    expect(s.api.requests).toHaveLength(1); // catalog only
  });

  it('validates a form submission in the bot, then invokes with typed input (and in the background)', async () => {
    const s = signedIn(setup());
    s.api.agents = [agent('underwriter', { input_schema: UW_SCHEMA })];
    const base = { action: 'agent.run', agent_id: 'underwriter', env: 'prod', version: '1.2.0' };
    await s.adapter
      .send(submit({ ...base, 'input.applicant': '', 'input.amount': '12', 'input.years': '2.5', 'input.product': 'other', 'input.smoker': 'false', 'input.riders': '{bad' }))
      .assertReply((a) => {
        const c = card(a);
        const errors = c.body.find((b: any) => b.color === 'Attention').text;
        expect(errors).toContain('Applicant name is required.');
        expect(errors).toContain('Amount must be at least 1000.');
        expect(errors).toContain('years must be a whole number.');
        expect(errors).toContain('product must be one of: term, whole, universal.');
        expect(errors).toContain('riders is not valid JSON.');
        expect(inputs(c).find((i) => i.id === 'input.amount').value).toBe(12); // the user's value is kept
      })
      .startTest();
    expect(s.api.requests.filter((r) => r.url.includes('/invoke'))).toHaveLength(0);
    await s.adapter
      .send(submit({ ...base, 'input.applicant': 'Jane Doe', 'input.amount': '300000', 'input.years': '20', 'input.product': 'whole', 'input.smoker': 'true', 'input.notes': '', 'input.riders': '["waiver"]', 'aig.background': 'false' }))
      .assertReply((a) => expect(card(a).body[2].text).toBe('Succeeded'))
      .startTest();
    const inv = s.api.requests.at(-1)!;
    expect(inv.url).toBe('http://platform.test/api/v1/agents/underwriter/invoke?mode=sync&env=prod&version=1.2.0');
    expect(inv.body).toEqual({ input: { applicant: 'Jane Doe', amount: 300000, years: 20, product: 'whole', smoker: true, riders: ['waiver'] } });
    await s.adapter
      .send(submit({ ...base, 'input.applicant': 'Jane Doe', 'input.amount': 300000, 'input.product': 'term', 'input.smoker': 'false', 'aig.background': 'true' }))
      .assertReply((a) => expect(a.text).toContain('See the result in the AIG portal')) // no proactive sender in this setup
      .startTest();
    expect(s.api.requests.at(-1)!.url).toContain('mode=background');
  });

  it('run with text for a multi-field schema shows the form pre-filled', async () => {
    const s = signedIn(setup());
    const schema = { type: 'object', required: ['question', 'policy_id'], properties: { question: { type: 'string' }, policy_id: { type: 'string' } } };
    s.api.agents = [agent('policy-qa', { input_schema: schema })];
    await s.adapter
      .send(msg('run policy-qa Is flood covered?'))
      .assertReply((a) => expect(inputs(card(a)).find((i) => i.id === 'input.question').value).toBe('Is flood covered?'))
      .startTest();
    expect(s.api.requests).toHaveLength(1);
  });

  it('maps platform errors to friendly text', async () => {
    const s = signedIn(setup());
    s.api.agents = [agent('claims-summarizer', { input_schema: SUMMARIZER_SCHEMA }), agent('claims-triage')];
    s.api.invokeFail = { status: 403, code: 'agent_forbidden', message: 'caller is not allowed' };
    await s.adapter.send(msg('run claims-summarizer x')).assertReply('You are not allowed to run this agent. Ask the owning team for access.').startTest();
    s.api.invokeFail = { status: 504, code: 'invocation_timeout', message: 'sync timeout' };
    await s.adapter.send(msg('run claims-summarizer x')).assertReply((a) => expect(a.text).toContain('run --background')).startTest();
    s.api.invokeFail = { status: 400, code: 'input_invalid', message: 'claim_text: too short' };
    await s.adapter
      .send(msg('run claims-summarizer x'))
      .assertReply((a) => {
        expect(card(a).body.find((b: any) => b.color === 'Attention').text).toContain('The agent rejected the input. claim_text: too short');
        expect(inputs(card(a)).find((i) => i.id === 'input.claim_text').value).toBe('x');
      })
      .startTest();
    s.api.invokeFail = undefined;
    await s.adapter.send(msg('run claims')).assertReply((a) => expect(a.text).toBe('No agent "claims" you can run. Did you mean `claims-summarizer`, `claims-triage`?')).startTest();
    await s.adapter.send(msg('run')).assertReply((a) => expect(a.text).toContain('Which agent?')).startTest();
    s.api.invokeFail = { status: 401, code: 'unauthenticated', message: 'expired' };
    await s.adapter.send(msg('run claims-summarizer x')).assertReply((a) => expect(a.text).toContain('sign-in has expired')).startTest();
    expect(s.auth.signedOut).toBe(1);

    for (const code of ['agent_forbidden', 'agent_not_invocable', 'org_approval_required', 'input_invalid', 'agent_unavailable', 'agent_error', 'invocation_timeout', 'invocation_cancelled', 'version_not_found']) {
      const text = friendlyError(code, 'detail');
      expect(text).not.toContain(`(${code})`);
      expect(text.length).toBeGreaterThan(10);
    }
    expect(friendlyError('org_approval_required')).toContain('approval');
    expect(friendlyError('agent_not_invocable')).toContain('cannot run right now');
    expect(friendlyError('weird_code', 'Something odd')).toBe('Something odd (weird_code)');
  });

  it('never puts tokens in URLs (catalog, invoke, background poll)', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date'] });
    const s = signedIn(setup({ background: true }));
    s.api.agents = [agent('helper')];
    await s.adapter.send(msg('agents')).assertReply(() => undefined).startTest();
    await s.adapter.send(msg('run helper hi')).assertReply(() => undefined).startTest();
    await s.adapter.send(msg('run --background helper hi')).assertReply(() => undefined).startTest();
    await vi.advanceTimersByTimeAsync(2000);
    vi.useRealTimers();
    s.bot.runs!.stopAll();
    expect(s.api.requests.map((r) => new URL(r.url).pathname)).toEqual([
      '/api/v1/catalog', '/api/v1/catalog', '/api/v1/agents/helper/invoke', '/api/v1/catalog', '/api/v1/agents/helper/invoke',
      '/api/v1/invocations/inv-0002-aaaa-4bbb-8ccc-dddddddddddd',
    ]);
    for (const r of s.api.requests) {
      expect(r.url).not.toContain('entra-token');
      expect(r.url.toLowerCase()).not.toMatch(/token|bearer|auth/);
      expect(r.auth).toBe('Bearer entra-token-jane');
    }
  });
});

describe('background runs', () => {
  afterEach(() => vi.useRealTimers());

  it('starts with mode=background, polls with backoff as the user and notifies proactively', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date'] });
    const s = signedIn(setup({ background: true }));
    s.api.agents = [agent('report-writer', { name: 'Report writer' })];
    await s.adapter
      .send({ text: 'run --background report-writer Write the Q3 report', from, conversation: { id: 'conv-42' } } as Partial<Activity>)
      .assertReply((a) => expect(a.text).toBe('Started **Report writer** in the background (run `inv-0001`). I will post the result here when it finishes.'))
      .startTest();
    const id = 'inv-0001-aaaa-4bbb-8ccc-dddddddddddd';
    expect(s.api.requests[1]).toMatchObject({ url: 'http://platform.test/api/v1/agents/report-writer/invoke?mode=background&env=prod&version=1.2.0' });
    expect(s.bot.runs!.size).toBe(1);
    const polls = () => s.api.requests.filter((r) => r.url.endsWith(`/api/v1/invocations/${id}`));

    await vi.advanceTimersByTimeAsync(1999);
    expect(polls()).toHaveLength(0);
    await vi.advanceTimersByTimeAsync(1); // 2 s
    expect(polls()).toHaveLength(1);
    s.api.invocations.get(id)!.status = 'running';
    await vi.advanceTimersByTimeAsync(3000); // +3 s (x1.5)
    expect(polls()).toHaveLength(2);
    Object.assign(s.api.invocations.get(id)!, { status: 'succeeded', output: 'The Q3 report', output_available: true, trace_id: 'trace-bg', duration_ms: 9000, usage: { total_tokens: 900 } });
    await vi.advanceTimersByTimeAsync(4499);
    expect(polls()).toHaveLength(2);
    await vi.advanceTimersByTimeAsync(1); // +4.5 s
    expect(polls()).toHaveLength(3);
    expect(polls().every((r) => r.auth === 'Bearer entra-token-jane' && r.method === 'GET')).toBe(true);
    expect(s.sent).toHaveLength(1);
    const c = card(s.sent[0]);
    expect(c.body[0].text).toBe('Background run finished');
    expect(c.body[1].text).toBe('Report writer');
    expect(c.body[3].text).toBe('The Q3 report');
    expect(c.body[4].facts).toContainEqual({ title: 'Trace id', value: 'trace-bg' });
    expect(s.sent[0].conversation?.id).toBe('conv-42');
    expect(s.bot.runs!.size).toBe(0);
    await vi.advanceTimersByTimeAsync(120_000);
    expect(polls()).toHaveLength(3); // stopped
  });

  it('reports failures, retries transient errors, caps the delay and gives up after an hour', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date'] });
    const api = new FakePlatformApi();
    const platform = new PlatformClient('http://platform.test', api.fetch);
    const { proactive, sent } = testProactive(new TestAdapter());
    let token: string | null = 'tok';
    const runs = new BackgroundRuns(platform, async () => token, proactive, undefined, { maxTotalMs: 120_000 });
    const ref = { conversation: { id: 'c1' } as any, user: { id: 'u1' } as any, channelId: 'msteams', serviceUrl: 'https://x' };
    const base = { agent_id: 'a', version: '1', env: 'prod', trace_id: null, duration_ms: 10, usage: null, output_available: false, output: null };

    api.invocations.set('f1', { id: 'f1', status: 'failed', error_code: 'agent_error', error_message: 'boom', ...base });
    runs.track({ invocationId: 'f1', agentId: 'a', reference: ref });
    await vi.advanceTimersByTimeAsync(2000);
    expect(card(sent[0]).body[2].text).toBe('Failed');
    expect(card(sent[0]).body[3].text).toBe('The agent failed while answering.');

    // transient 503 then still running: backoff 2, 3, 4.5, 6.75, 10.125, 15.19, 22.78, 30, 30 ... until 120 s
    api.invocations.set('slow', { id: 'slow', status: 'running', ...base });
    api.failWith = { status: 503, code: 'unavailable', message: 'x' };
    runs.track({ invocationId: 'slow', agentId: 'a', agentName: 'Slow agent', reference: ref });
    await vi.advanceTimersByTimeAsync(2000);
    api.failWith = undefined;
    await vi.advanceTimersByTimeAsync(118_000);
    const pollTimes = api.requests.filter((r) => r.url.endsWith('/slow')).length;
    expect(pollTimes).toBeGreaterThanOrEqual(8);
    expect(pollTimes).toBeLessThanOrEqual(11);
    expect(sent.at(-1)!.text).toContain('still not finished after an hour');
    expect(runs.size).toBe(0);

    // sign-in expired
    api.invocations.set('e1', { id: 'e1', status: 'running', ...base });
    token = null;
    runs.track({ invocationId: 'e1', agentId: 'a', reference: ref });
    await vi.advanceTimersByTimeAsync(2000);
    expect(sent.at(-1)!.text).toContain('sign-in expired');
    expect(runs.size).toBe(0);
  });
});

describe('schema helpers', () => {
  it('plans runs and validates', () => {
    expect(planRun(null, 'hi')).toEqual({ kind: 'invoke', body: { messages: [{ role: 'user', content: 'hi' }] } });
    expect(planRun({ type: 'object' }, '')).toEqual({ kind: 'chatPrompt' });
    expect(planRun(SUMMARIZER_SCHEMA, '')).toEqual({ kind: 'form' });
    expect(planRun({ type: 'object', required: ['n'], properties: { n: { type: 'integer' } } }, '5').kind).toBe('form');
    expect(planRun({ type: 'object', required: ['t'], properties: { t: { type: 'string', maxLength: 3 } } }, 'toolong')).toMatchObject({ kind: 'form', prefill: { t: 'toolong' } });
    expect(fields({ type: 'object', properties: { x: { type: ['string', 'null'] }, d: { type: 'string', description: 'd' } } }).map((f) => [f.kind, f.multiline])).toEqual([['text', false], ['text', false]]);
    expect(validateSubmission({ type: 'object', properties: { e: { enum: [1, 2] } } }, { 'input.e': '2' })).toEqual({ ok: true, input: { e: 2 } });
    expect(outputBlocks(null)[0].text).toBe('(no output)');
  });
});
