import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
// @ts-expect-error - plain .mjs script without types
import { fill } from '../scripts/package-manifest.mjs';

const PKG = join(__dirname, '..', 'appPackage');

function pngSize(file: string): [number, number] {
  const b = readFileSync(join(PKG, file));
  expect(b.subarray(1, 4).toString()).toBe('PNG');
  return [b.readUInt32BE(16), b.readUInt32BE(20)];
}

describe('Teams app package', () => {
  const template = readFileSync(join(PKG, 'manifest.json'), 'utf8');

  it('has the required icons (color 192x192, outline 32x32)', () => {
    expect(pngSize('color.png')).toEqual([192, 192]);
    expect(pngSize('outline.png')).toEqual([32, 32]);
  });

  it('is a valid manifest with placeholders only for per-environment values', () => {
    const m = JSON.parse(template);
    expect(m.manifestVersion).toBe('1.19');
    expect(m.icons).toEqual({ color: 'color.png', outline: 'outline.png' });
    expect(m.bots[0].scopes).toEqual(['personal', 'team', 'groupChat']);
    expect(m.bots[0].commandLists[0].commands.map((c: any) => c.title)).toEqual(['start', 'start workspace', 'status', 'list', 'cancel', 'agents', 'run', 'help']);
    expect(m.webApplicationInfo.resource).toBe('api://botid-${{BOT_ID}}'); // Teams SSO resource
    expect(m.validDomains).toContain('token.botframework.com');
    const placeholders = [...new Set([...template.matchAll(/\$\{\{([A-Z0-9_]+)\}\}/g)].map((x) => x[1]))].sort();
    expect(placeholders).toEqual(['AIG_PRIVACY_URL', 'AIG_TERMS_URL', 'AIG_WEB_URL', 'BOT_DOMAIN', 'BOT_ID', 'TEAMS_APP_ID']);
  });

  it('fills placeholders and refuses missing ones', () => {
    const env = { TEAMS_APP_ID: '11111111-2222-4333-8444-555555555555', BOT_ID: '66666666-7777-4888-8999-000000000000', BOT_DOMAIN: 'aig-teams-bot.example.com',
      AIG_WEB_URL: 'https://aig.example.com', AIG_PRIVACY_URL: 'https://aig.example.com/privacy', AIG_TERMS_URL: 'https://aig.example.com/terms' };
    const m = JSON.parse(fill(template, env));
    expect(m.bots[0].botId).toBe(env.BOT_ID);
    expect(m.webApplicationInfo.resource).toBe(`api://botid-${env.BOT_ID}`);
    expect(() => fill(template, { ...env, BOT_ID: '__REPLACE_ME_BOT_ID__' })).toThrow(/BOT_ID/);
  });
});
