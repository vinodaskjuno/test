/**
 * The real CloudAdapter behind restify `/api/messages` (anonymous, as in local dev without an app
 * id), replying through a fake Bot Framework connector (the activity's serviceUrl).
 */
import { createServer as createHttpServer, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { afterEach, describe, expect, it } from 'vitest';
import { loadConfig } from '../src/config.js';
import { HELP } from '../src/commands.js';
import { PlatformClient } from '../src/platform.js';
import { createAdapter, createServer } from '../src/server.js';
import { FakeAuth, FakePlatformApi } from './helpers.js';

describe('/api/messages', () => {
  const closers: (() => void)[] = [];
  afterEach(() => closers.splice(0).forEach((c) => c()));

  it('processes a Teams message and replies through the connector', async () => {
    const replies: any[] = [];
    const connector: Server = createHttpServer((req, res) => {
      let body = '';
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        replies.push({ url: req.url, body: JSON.parse(body || '{}') });
        // restify patches http.ServerResponse in this process, so no chaining on writeHead().
        res.statusCode = 200;
        res.setHeader('content-type', 'application/json');
        res.end(JSON.stringify({ id: 'reply-1' }));
      });
    });
    await new Promise<void>((r) => connector.listen(0, '127.0.0.1', () => r()));
    closers.push(() => connector.close());
    const serviceUrl = `http://127.0.0.1:${(connector.address() as AddressInfo).port}/`;

    const api = new FakePlatformApi();
    const auth = new FakeAuth();
    auth.tokens.set('29:user', 'entra-token-jane');
    const config = loadConfig({ AIG_PLATFORM_API_URL: 'http://platform.test' });
    const { server } = createServer(config, { adapter: createAdapter({}), auth, platform: new PlatformClient('http://platform.test', api.fetch) });
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
    closers.push(() => server.close());
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

    const activity = (text: string, id: string) => ({
      type: 'message', id, text, channelId: 'msteams', serviceUrl,
      from: { id: '29:user', name: 'Jane' }, recipient: { id: '28:bot', name: 'AIG' },
      conversation: { id: 'a:conv-1', conversationType: 'personal' }, timestamp: new Date().toISOString(),
    });
    const r1 = await fetch(`${base}/api/messages`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(activity('help', 'm1')) });
    expect(r1.status).toBe(200);
    expect(replies[0].url).toBe('/v3/conversations/a%3Aconv-1/activities/m1');
    expect(replies[0].body.text).toBe(HELP);

    await fetch(`${base}/api/messages`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(activity('start workspace https://github.com/aig/x #5 Fix it', 'm2')) });
    expect(api.requests[0]).toMatchObject({ method: 'POST', auth: 'Bearer entra-token-jane' });
    expect(replies[1].body.attachments[0].contentType).toBe('application/vnd.microsoft.card.adaptive');

    const bad = await fetch(`${base}/api/messages`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '[]' });
    expect(bad.status).toBe(400);
  });
});
