import type { AddressInfo } from 'node:net';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TestAdapter, TurnContext } from 'botbuilder';
import { afterEach, describe, expect, it } from 'vitest';
import { DevUserAuth, OAuthUserAuth } from '../src/auth.js';
import { ConfigError, loadConfig } from '../src/config.js';
import { NotifyHandler, sign, verifySignature } from '../src/notify.js';
import { createServer } from '../src/server.js';
import { FileStore, MemoryStore } from '../src/store.js';
import { FakeAuth, card, testProactive, ws } from './helpers.js';

const SECRET = 'notify-SUPERSECRET-0123456789';
const REF = { conversation: { id: 'conv-1' }, serviceUrl: 'https://smba.trafficmanager.net/amer/', channelId: 'msteams', user: { id: 'u1' }, bot: { id: 'b1' } } as any;

function signed(payload: unknown, ts = String(Math.floor(Date.now() / 1000)), secret = SECRET) {
  const body = JSON.stringify(payload);
  return { headers: { 'x-aig-timestamp': ts, 'x-aig-signature': sign(secret, ts, body), 'content-type': 'application/json' }, body };
}

describe('notify', () => {
  it('verifies HMAC signatures with a replay window (same scheme as the orchestrator)', () => {
    const now = 1_700_000_000;
    const sig = sign(SECRET, String(now), '{"a":1}');
    expect(verifySignature(SECRET, String(now), '{"a":1}', sig, now + 10)).toBe(true);
    expect(verifySignature(SECRET, String(now), '{"a":1}', sig, now + 301)).toBe(false);
    expect(verifySignature(SECRET, String(now), '{"a":2}', sig, now)).toBe(false);
    expect(verifySignature('other', String(now), '{"a":1}', sig, now)).toBe(false);
    expect(verifySignature(SECRET, undefined, '{"a":1}', sig, now)).toBe(false);
    // Python reference: hmac.new(secret, f"{ts}.".encode() + body, sha256) (backend/workspace-orchestrator notify.py)
    expect(sign('k', '1', 'b')).toBe('sha256=2946e37a45bb02a0bf1bf1a7d9219543801fedd301f9f485aebd72c928639bea');
  });

  it('delivers a proactive card to the conversation that started the workspace', async () => {
    const store = new MemoryStore();
    store.set('w1', { reference: REF, userId: 'u1', lastStatus: 'queued' });
    const { proactive, sent } = testProactive(new TestAdapter());
    const handler = new NotifyHandler(SECRET, store, proactive, 'https://aig.example.com');
    const { headers, body } = signed({ event: 'workspace.status', workspace: ws({ id: 'w1', status: 'running' }) });
    expect(await handler.handle(headers, body)).toEqual({ status: 202, body: { delivered: true } });
    expect(card(sent[0]).body[0].text).toBe('Workspace update');
    expect(card(sent[0]).body[2].text).toBe('Code agent working');
    expect(sent[0].conversation?.id).toBe('conv-1');
    expect(store.get('w1')?.lastStatus).toBe('running');
    // duplicate status: not re-sent
    expect((await handler.handle(headers, body)).body).toEqual({ delivered: false, duplicate: true });
    // final status: delivered once, then the subscription is dropped
    const done = signed({ event: 'workspace.status', workspace: ws({ id: 'w1', status: 'completed', pr_url: 'https://github.com/aig/x/pull/1' }) });
    expect((await handler.handle(done.headers, done.body)).body).toEqual({ delivered: true });
    expect(card(sent[1]).actions[0].url).toBe('https://github.com/aig/x/pull/1');
    expect(store.get('w1')).toBeUndefined();
    // workspaces not started from Teams are acknowledged and ignored
    const other = signed({ event: 'workspace.status', workspace: ws({ id: 'w2', status: 'running' }) });
    expect(await handler.handle(other.headers, other.body)).toEqual({ status: 202, body: { delivered: false } });
  });

  it('rejects unsigned, stale, malformed and unconfigured requests', async () => {
    const store = new MemoryStore();
    const { proactive } = testProactive(new TestAdapter());
    const handler = new NotifyHandler(SECRET, store, proactive);
    const ok = signed({ event: 'workspace.status', workspace: ws() });
    expect((await handler.handle({}, ok.body)).status).toBe(401);
    expect((await handler.handle({ ...ok.headers, 'x-aig-signature': 'sha256=00' }, ok.body)).status).toBe(401);
    const stale = signed({ event: 'workspace.status', workspace: ws() }, String(Math.floor(Date.now() / 1000) - 3600));
    expect((await handler.handle(stale.headers, stale.body)).status).toBe(401);
    const wrong = signed({ event: 'other' });
    expect((await handler.handle(wrong.headers, wrong.body)).status).toBe(400);
    const ts = String(Math.floor(Date.now() / 1000));
    expect((await handler.handle({ 'x-aig-timestamp': ts, 'x-aig-signature': sign(SECRET, ts, 'nope') }, 'nope')).status).toBe(400);
    expect((await new NotifyHandler(undefined, store, proactive).handle(ok.headers, ok.body)).status).toBe(503);
  });
});

describe('auth', () => {
  function ctx(channelId = 'msteams', from: any = { id: 'u1', name: 'Jane' }) {
    const adapter = new TestAdapter();
    return new TurnContext(adapter, { type: 'message', channelId, from, conversation: { id: 'c' } as any, recipient: { id: 'b' } as any, serviceUrl: 'https://x' });
  }

  it('OAuthUserAuth uses the Bot Framework token service (SSO card, exchange, magic code)', async () => {
    const calls: any[] = [];
    const client = {
      getUserToken: async (...a: any[]) => (calls.push(['get', ...a]), a[3] === '999' ? { token: 'tok-magic' } : undefined),
      getSignInResource: async (...a: any[]) => (calls.push(['res', a[0]]), { signInLink: 'https://token.botframework.com/signin?x', tokenExchangeResource: { id: 'ter', uri: 'api://botid-123' } }),
      exchangeToken: async (...a: any[]) => (calls.push(['ex', ...a]), a[3].token === 'good' ? { token: 'tok-sso' } : undefined),
      signOutUser: async (...a: any[]) => void calls.push(['out', ...a]),
    };
    const auth = new OAuthUserAuth('aig-platform', () => client);
    const c = ctx();
    const sent: any[] = [];
    c.onSendActivities(async (_c, acts, next) => (sent.push(...acts), next()));
    expect(await auth.getToken(c)).toBeNull();
    expect(await auth.getToken(c, '999')).toBe('tok-magic');
    await auth.promptSignIn(c);
    const oauth = sent[0].attachments[0];
    expect(oauth.contentType).toBe('application/vnd.microsoft.card.oauth');
    expect(oauth.content.connectionName).toBe('aig-platform');
    expect(oauth.content.tokenExchangeResource).toEqual({ id: 'ter', uri: 'api://botid-123' });
    expect(await auth.exchange(c, 'good')).toBe(true);
    expect(await auth.exchange(c, 'bad')).toBe(false);
    await auth.signOut(c);
    expect(calls[0]).toEqual(['get', 'u1', 'aig-platform', 'msteams', '']);
    expect(calls.at(-1)).toEqual(['out', 'u1', 'aig-platform', 'msteams']);
  });

  it('DevUserAuth builds dev:<email> (local only)', async () => {
    expect(await new DevUserAuth(undefined, async () => ({ email: 'jane@example.com' }) as any).getToken(ctx())).toBe('dev:jane@example.com');
    expect(await new DevUserAuth('fallback@example.com', async () => { throw new Error('no team'); }).getToken(ctx())).toBe('dev:fallback@example.com');
    expect(await new DevUserAuth(undefined).getToken(ctx('emulator', { id: 'u', name: 'bob@example.com' }))).toBe('dev:bob@example.com');
    expect(await new DevUserAuth(undefined).getToken(ctx('emulator', { id: 'u', name: 'Bob' }))).toBeNull();
  });
});

describe('config', () => {
  it('validates the environment', () => {
    expect(loadConfig({ AIG_PLATFORM_API_URL: 'http://localhost:8080/' })).toMatchObject({ env: 'local', authMode: 'dev', port: 3978, platformApiUrl: 'http://localhost:8080', oauthConnectionName: 'aig-platform' });
    expect(() => loadConfig({})).toThrow(ConfigError);
    expect(() => loadConfig({ AIG_ENV: 'prod', AIG_PLATFORM_API_URL: 'https://api', AIG_BOT_AUTH_MODE: 'dev' })).toThrow(/only allowed with AIG_ENV=local/);
    expect(() => loadConfig({ AIG_ENV: 'prod', AIG_PLATFORM_API_URL: 'https://api', MicrosoftAppId: 'id' })).toThrow(/MicrosoftAppPassword/);
    expect(() => loadConfig({ AIG_ENV: 'prod', AIG_PLATFORM_API_URL: 'https://api', MicrosoftAppId: 'id', MicrosoftAppPassword: 'pw' })).toThrow(/NOTIFY_SECRET/);
    const prod = loadConfig({ AIG_ENV: 'prod', AIG_PLATFORM_API_URL: 'https://api', MicrosoftAppId: 'id', MicrosoftAppPassword: 'pw', AIG_BOT_NOTIFY_SECRET: 's3cret-value' });
    expect(prod.authMode).toBe('oauth');
    expect(loadConfig({ AIG_PLATFORM_API_URL: 'http://x', AIG_BOT_NOTIFY_SECRET: '__REPLACE_ME_NOTIFY__' }).notifySecret).toBeUndefined();
  });
});

describe('store', () => {
  it('FileStore persists subscriptions', () => {
    const path = join(mkdtempSync(join(tmpdir(), 'aig-bot-')), 'state', 'conversations.json');
    const a = new FileStore(path);
    a.set('w1', { reference: REF, userId: 'u1', lastStatus: 'queued' });
    expect(new FileStore(path).get('w1')?.lastStatus).toBe('queued');
    a.delete('w1');
    expect(JSON.parse(readFileSync(path, 'utf8'))).toEqual({});
  });
});

describe('server', () => {
  let close: (() => void) | undefined;
  afterEach(() => close?.());

  it('serves /healthz and a signed /api/notify over HTTP (restify)', async () => {
    const store = new MemoryStore();
    store.set('w1', { reference: REF, userId: 'u1', lastStatus: 'queued' });
    const { proactive, sent } = testProactive(new TestAdapter());
    const config = loadConfig({ AIG_PLATFORM_API_URL: 'http://platform.test', AIG_BOT_NOTIFY_SECRET: SECRET });
    const { server } = createServer(config, { adapter: {} as any, store, auth: new FakeAuth(), proactive });
    await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
    close = () => server.close();
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
    expect(await (await fetch(`${base}/healthz`)).json()).toEqual({ status: 'ok', auth: 'dev', notify: 'configured' });
    const { headers, body } = signed({ event: 'workspace.status', workspace: ws({ id: 'w1', status: 'testing' }) });
    const ok = await fetch(`${base}/api/notify`, { method: 'POST', headers, body });
    expect(ok.status).toBe(202);
    expect(card(sent[0]).body[2].text).toBe('Running tests and evals');
    const bad = await fetch(`${base}/api/notify`, { method: 'POST', headers: { ...headers, 'x-aig-signature': 'sha256=0' }, body });
    expect(bad.status).toBe(401);
  });
});
