#!/usr/bin/env node
/**
 * Renders the Teams app icons from web/packages/brand-assets/svg with headless Chrome (no npm deps):
 *   appPackage/color.png    192x192, full colour (white AIG mark on AIG navy)
 *   appPackage/outline.png  32x32, white mark on a transparent background (Teams requirement)
 *   node scripts/render-icons.mjs        (CHROME=/path/to/chrome to override)
 */
import { execFileSync } from 'node:child_process';
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const BRAND = join(HERE, '..', '..', '..', 'web', 'packages', 'brand-assets', 'svg');
const OUT = join(HERE, '..', 'appPackage');
const CHROME = [process.env.CHROME, '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/usr/bin/google-chrome', '/usr/bin/chromium']
  .filter(Boolean)
  .find((c) => existsSync(c));

const JOBS = [
  ['aig-icon.svg', 'color.png', 192, '#ffffff'],
  ['aig-activitybar.svg', 'outline.png', 32, '#ffffff'],
];

function page(svg, size, color) {
  const markup = svg
    .replace(/<!--[\s\S]*?-->\s*/g, '')
    .replace(/<svg\b([^>]*?)\swidth="[^"]*"\s+height="[^"]*"/, '<svg$1')
    .replace('<svg', `<svg width="${size}" height="${size}" preserveAspectRatio="xMidYMid meet"`);
  return `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;background:transparent;overflow:hidden}svg{display:block;color:${color}}</style></head><body>${markup}</body></html>`;
}

if (!CHROME) throw new Error('Google Chrome not found; set CHROME=/path/to/chrome');
const tmp = mkdtempSync(join(tmpdir(), 'aig-teams-icons-'));
try {
  for (const [src, out, size, color] of JOBS) {
    const html = join(tmp, `${out}.html`);
    writeFileSync(html, page(readFileSync(join(BRAND, src), 'utf8'), size, color));
    execFileSync(CHROME, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=1',
      '--default-background-color=00000000', `--user-data-dir=${join(tmp, 'profile')}`, `--window-size=${size},${size}`,
      `--screenshot=${join(OUT, out)}`, pathToFileURL(html).href], { stdio: 'ignore' });
    console.log(`rendered appPackage/${out} (${size}x${size})`);
  }
} finally {
  rmSync(tmp, { recursive: true, force: true });
}
