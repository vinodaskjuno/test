#!/usr/bin/env node
/**
 * Builds the Teams app package (zip with manifest.json, color.png, outline.png) for one environment.
 *   TEAMS_APP_ID=<guid> BOT_ID=<bot app id> BOT_DOMAIN=<bot host> AIG_WEB_URL=https://... \
 *   AIG_PRIVACY_URL=https://... AIG_TERMS_URL=https://... node scripts/package-manifest.mjs [out.zip]
 * Fails if a ${{PLACEHOLDER}} is left unset. Uses the system `zip` (no npm dependencies).
 */
import { execFileSync } from 'node:child_process';
import { copyFileSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const PKG = join(HERE, '..', 'appPackage');
const out = resolve(process.argv[2] ?? join(HERE, '..', 'dist', 'aig-teams-app.zip'));

export function fill(template, env) {
  const missing = new Set();
  const text = template.replace(/\$\{\{([A-Z0-9_]+)\}\}/g, (_m, name) => {
    const v = env[name];
    if (!v || v.includes('__REPLACE_ME')) missing.add(name);
    return v ?? '';
  });
  if (missing.size) throw new Error(`set ${[...missing].join(', ')}`);
  JSON.parse(text);
  return text;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const manifest = fill(readFileSync(join(PKG, 'manifest.json'), 'utf8'), process.env);
  const tmp = mkdtempSync(join(tmpdir(), 'aig-teams-pkg-'));
  try {
    writeFileSync(join(tmp, 'manifest.json'), manifest);
    for (const f of ['color.png', 'outline.png']) copyFileSync(join(PKG, f), join(tmp, f));
    execFileSync('mkdir', ['-p', dirname(out)]);
    rmSync(out, { force: true });
    execFileSync('zip', ['-q', '-j', out, join(tmp, 'manifest.json'), join(tmp, 'color.png'), join(tmp, 'outline.png')]);
    console.log(`wrote ${out}`);
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
}
