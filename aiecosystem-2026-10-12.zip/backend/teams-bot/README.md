# AIG Teams bot (`backend/teams-bot`)

Microsoft Teams entry point for Phase 6 team workspaces and for running registered agents
(W6 "Discover + invoke"): a user asks in Teams, the bot calls platform-api **as that user**, and
posts status updates and results back into the chat.

TypeScript, Node 22, `botbuilder` 4.23.3 (`CloudAdapter`, `TeamsActivityHandler`,
`ConfigurationBotFrameworkAuthentication`, `CardFactory`) on `restify` 12.

> Microsoft has announced the successor "Teams SDK" (`@microsoft/teams.apps`) and the Bot Framework
> SDK is in long-term support only. The bot keeps all Teams-specific code in `src/bot.ts`,
> `src/auth.ts` and `src/server.ts`, so a later move touches only those files.

## Commands

| Command | What happens |
|---|---|
| `start workspace <repo url> <work item> [title]` | `POST /api/v1/workspaces` with the user's token; replies with a status card and remembers the conversation |
| `start` | Adaptive Card form (repository, work item, title, description, job profile) |
| `status <id>` | `GET /api/v1/workspaces/{id}` (a unique prefix such as the 8 characters on the card is enough) |
| `list` | the user's workspaces (`GET /api/v1/workspaces`, platform-api returns only theirs) |
| `cancel <id>` | `POST /api/v1/workspaces/{id}/cancel`; the orchestrator then stops the task |
| `agents [search]` | `GET /api/v1/catalog?q=<search>`: the agents the user may run (platform-api applies team / group / org-wide access) as a card with name, id, team, default version + env, status, a **Run** button (opens the input form) and a portal link |
| `run <agent> <input>` | `POST /api/v1/agents/{id}/invoke?mode=sync&env=&version=` with the catalog default version (see below); replies with a result card |
| `run <agent>` | the agent's input form (or a message box for chat-mode agents) |
| `run --background <agent> <input>` | `?mode=background` (202); the result is posted to the chat when the run finishes |
| `help` | usage |

`run` also takes `--env <env>` and `--version <v>` (a version listed in the catalog for that user)
and `-b`/`--bg` for `--background`. `<agent>` is an agent id, an exact agent name or a unique id
prefix; otherwise the bot suggests matching ids.

Workspace cards have **Refresh** and **Cancel** buttons, and links to the PR, the logs (CloudWatch)
and the workspace page in the AIG portal (`AIG_WEB_URL`).

## Running agents

The input sent depends on the default (or chosen) version's `input_schema` from the catalog
(`src/schema.ts`):

- **No schema** (or one without properties): chat mode, `{"messages":[{"role":"user","content":"<text>"}]}`.
- **The text fits one property**: the only required property when it is a string, or a string
  property named `prompt`, `question`, `query`, `text`, `input` or `message` - and no other
  property is required: `{"input":{"<property>":"<text>"}}`.
- **Otherwise** (or no text): an Adaptive Card **form generated from the schema**, pre-filled with
  the text where possible. Top-level properties become inputs: string -> `Input.Text` (multi-line
  for `format: "textarea"`, `maxLength` > 200, or a name containing notes/description/text;
  `maxLength`/`pattern` passed on), number/integer -> `Input.Number` (`minimum`/`maximum`),
  boolean -> `Input.Toggle`, `enum` -> `Input.ChoiceSet`, object/array -> JSON text. `title` is the
  label, `description` is shown under the input, `default` pre-fills it, required properties are
  marked required. A **Run in the background** toggle is added.
- **Submit** (`Action.Submit` data `{action: "agent.run", agent_id, env, version}`, inputs as
  `input.<property>`): the bot re-reads the schema from the catalog (the card data is not trusted),
  checks required fields, numbers/integers, min/max, enums, lengths, patterns and JSON, converts
  Teams' string values to typed JSON and invokes. Problems come back as the same form with the
  user's values and the errors listed. platform-api validates the input again (Draft 2020-12).

The **result card** shows the output (text; a FactSet for a flat object; pretty JSON otherwise,
truncated at 12,000 characters), version + env, duration, tokens, trace id and run id, plus
**Run again** and a portal link. Errors (`backend/contracts/errors.md`) become friendly text:
`agent_forbidden`, `agent_not_invocable`, `org_approval_required`, `input_invalid` (the form comes
back with the server's message), `agent_unavailable`, `agent_error`, `invocation_timeout` (suggests
`run --background`), `invocation_cancelled`, `version_not_found`.

### Background runs

`run --background ...` (or the form's toggle) starts `?mode=background`; platform-api answers
`202 {invocation_id, status: "queued", location}` and the bot replies "Started ...". It then polls
`GET /api/v1/invocations/{id}` **as the user** with backoff (2 s, x1.5, at most 30 s apart; it stops
after 1 h, the platform's background timeout) and, when the run is `succeeded`, `failed`,
`cancelled` or `timeout`, posts the result card into the conversation that started it with the same
proactive sender as the workspace notifications (`CloudAdapter.continueConversationAsync` with the
stored conversation reference). For every poll the bot reads a fresh user token from the Bot
Framework token service inside that proactive turn, so a long run does not depend on a cached
access token; if the user's sign-in has expired the bot says so instead. Transient platform errors
(5xx, 429) are retried. Watched runs live in memory (`src/background.ts`): after a bot restart the
result is still in the AIG portal (Invocations).

A sync run waits for the agent (platform-api's sync timeout is 120 s). Teams expects a bot to answer
an incoming message quickly, so long-running agents should be run with `--background`.

## Authentication: always on behalf of the user

The bot never holds `PLATFORM_SERVICE_TOKEN`. Every platform-api call - workspaces, catalog, agent
invocations and background-run polling - carries the Teams user's own platform-api token in the
`Authorization` header (never in a URL or query string), so team, roles, agent access and the audit
trail (invocation `caller`) are the user's:

- **dev / stage / prod (`AIG_BOT_AUTH_MODE=oauth`)**: an Azure Bot **OAuth connection**
  (`AIG_BOT_OAUTH_CONNECTION`, default `aig-platform`) with **Teams SSO**. When the user has no
  token yet, the bot sends an OAuth card that includes the connection's `tokenExchangeResource`;
  Teams gets an SSO token silently and sends `signin/tokenExchange`, which the bot exchanges with
  `UserTokenClient.exchangeToken`. If that fails the bot answers `412` and Teams shows the sign-in
  button; the user signs in and Teams sends `signin/verifyState` (magic code). The command the user
  typed before signing in is then executed. A `401` from platform-api signs the user out of the
  connection and asks them to try again.
- **local (`AIG_BOT_AUTH_MODE=dev`, only with `AIG_ENV=local`)**: `dev:<email>` against a
  platform-api running `AIG_AUTH_MODE=dev`. The email is the Teams member's email/UPN, an Emulator
  user name that is an email, or `AIG_BOT_DEV_USER`.

## Proactive status updates

`backend/workspace-orchestrator` posts every status change to `POST /api/notify`:

```
x-aig-timestamp: <unix seconds>
x-aig-signature: sha256=<hex HMAC-SHA256(AIG_BOT_NOTIFY_SECRET, "<timestamp>.<raw body>")>
{"event":"workspace.status","sent_at":"...","workspace":{"id","status","title","repo_url","work_item","pr_url","log_url","error",...}}
```

Signatures older than 5 minutes are rejected. If the workspace was started from Teams, the bot
sends a status card to that conversation (`CloudAdapter.continueConversationAsync`); otherwise it
answers `202 {"delivered": false}`. Repeated statuses are not re-sent; after a final status the
subscription is dropped. Subscriptions live in `AIG_BOT_STATE_FILE` (JSON; one replica) - use a
shared store (Azure Blob/Table, Cosmos DB) behind `ConversationStore` for several replicas.

## Configuration

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local`, `dev`, `stage`, `prod` |
| `PORT` | `3978` | |
| `AIG_PLATFORM_API_URL` | required | platform-api base URL |
| `AIG_WEB_URL` | none | AIG portal (card link `<url>/workspaces/<id>`) |
| `AIG_BOT_AUTH_MODE` | `dev` in local, else `oauth` | `dev` is refused outside local |
| `AIG_BOT_OAUTH_CONNECTION` | `aig-platform` | Azure Bot OAuth connection name |
| `AIG_BOT_DEV_USER` | none | local fallback email |
| `AIG_BOT_NOTIFY_SECRET` (secret) | required outside local | = orchestrator `AIG_WS_NOTIFY_SECRET` |
| `AIG_BOT_STATE_FILE` | memory | conversation references (image: `/app/state/conversations.json`) |
| `MicrosoftAppId`, `MicrosoftAppPassword` (secret), `MicrosoftAppType`, `MicrosoftAppTenantId` | none in local (anonymous, Emulator) | Azure Bot / Entra app; required outside local (`UserAssignedMSI` needs no password) |

## Azure setup (placeholders, done once per environment)

1. **Entra app for the bot** (`aig-teams-bot-<env>`): single tenant; client secret (or a
   user-assigned managed identity). Expose an API: Application ID URI `api://botid-<BOT_ID>`, scope
   `access_as_user`, pre-authorise the Teams clients `1fec8e78-bce4-4aaf-ab1b-5451cc387264`
   (desktop/mobile) and `5e3ce6c0-2b1f-4285-8d4b-75ee78787346` (web) - this is what makes Teams SSO
   silent. API permission: delegated `api://<platform-api app id>/access_as_user` (+ `openid`,
   `profile`, `offline_access`), admin consent. Redirect URI
   `https://token.botframework.com/.auth/web/redirect`.
2. **Azure Bot resource** (`aig-teams-bot-<env>`): the app above, messaging endpoint
   `https://<BOT_DOMAIN>/api/messages`, **Microsoft Teams** channel enabled.
3. **OAuth connection** on the Azure Bot: name `aig-platform`, provider **Azure Active Directory
   v2**, client id/secret of the bot app, tenant, scopes `api://<platform-api app id>/access_as_user`,
   **Token Exchange URL** `api://botid-<BOT_ID>` (enables SSO). platform-api must accept tokens with
   that audience (its Entra configuration, same as the Web UI).
4. **Hosting**: the Docker image (`backend/teams-bot/Dockerfile`) on Azure App Service / Container
   Apps or ECS behind HTTPS; settings from Key Vault/Secrets Manager. The orchestrator must reach
   `https://<BOT_DOMAIN>/api/notify` (`AIG_WS_NOTIFY_URLS`).

## Teams app package

`appPackage/manifest.json` (schema 1.19, `${{PLACEHOLDER}}` values) plus `color.png` (192x192) and
`outline.png` (32x32, white on transparent), rendered from `web/packages/brand-assets/svg` with headless
Chrome (`npm run icons`). Build the zip for one environment:

```bash
TEAMS_APP_ID=<new guid> BOT_ID=<bot app id> BOT_DOMAIN=<bot host> AIG_WEB_URL=https://... \
AIG_PRIVACY_URL=https://... AIG_TERMS_URL=https://... npm run package --workspaces=false
# -> dist/aig-teams-app.zip; upload in Teams admin center (org app catalog) or Developer Portal
```

The manifest sets `webApplicationInfo` (`id` = bot app id, `resource` = `api://botid-<BOT_ID>`) for
SSO and `validDomains` = `token.botframework.com` + the bot host.

## Local run

```bash
cd backend/teams-bot && npm ci --workspaces=false
cp .env.example .env            # AIG_BOT_DEV_USER, leave MicrosoftApp* as placeholders (anonymous)
npm run dev --workspaces=false  # http://localhost:3978/api/messages (Bot Framework Emulator)
```

With `backend/platform-api/run-local.sh` and `backend/workspace-orchestrator/run-local.sh`
(`AIG_WS_NOTIFY_URLS=http://localhost:3978/api/notify`, same secret) the whole flow runs locally.

## Tests

`npm test --workspaces=false` (vitest, 36 tests): commands, the bot on the Bot Framework
`TestAdapter` with a mocked platform-api (user bearer token on every call, never the service token),
form submit, status/list/cancel, Teams SSO token exchange + replay, 412 fallback, magic code, 401
sign-out, proactive cards and signature checks, `OAuthUserAuth` against a fake `UserTokenClient`,
the real `CloudAdapter` + restify `/api/messages` replying through a fake connector, `/api/notify`
over HTTP, the manifest and icons; agents (`test/agents.test.ts`): catalog card, text-to-property
mapping, chat mode, the form generated from a schema with every simple type, submission validation
and typed invoke, error mapping, background start + polling with fake timers + proactive result,
retry/give-up/expired sign-in, and no token in any URL.

## Not verified

No real Azure Bot, Entra app or Teams tenant was used: Teams SSO and the OAuth connection are
implemented against the documented `UserTokenClient` / invoke contract and tested with fakes. The
generated agent forms were not rendered in a real Teams client (Adaptive Card 1.5 elements only).
