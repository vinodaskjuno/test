"""Locate and load backend/gateway: manifests, env overlays, config templates and schemas."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator

ENVS: tuple[str, ...] = ("local", "dev", "stage", "prod")
STRICT_ENVS: tuple[str, ...] = ("stage", "prod")  # placeholders refused unless --allow-placeholders

# Manifest kind -> schema file (schemas/<file>). Every manifest kind must appear exactly once.
KIND_SCHEMAS: dict[str, str] = {
    "Gateway": "gateway.schema.json",
    "Workspaces": "workspaces.schema.json",
    "Integrations": "integrations.schema.json",
    "Models": "models.schema.json",
    "Configs": "configs.schema.json",
    "ApiKeys": "api-keys.schema.json",
    "Limits": "limits.schema.json",
    "Guardrails": "guardrails.schema.json",
    "Caching": "caching.schema.json",
    "McpServers": "mcp-servers.schema.json",
    "Canaries": "canaries.schema.json",
}
ENV_SCHEMA = "env.schema.json"
PORTKEY_CONFIG_SCHEMA = "portkey-config.schema.json"


class ManifestError(ValueError):
    """Invalid manifests; ``problems`` lists every issue found."""

    def __init__(self, problems: list[str]):
        super().__init__("\n".join(problems))
        self.problems = problems


def default_root() -> Path:
    env = os.environ.get("AIGW_ROOT")
    if env:
        return Path(env).resolve()
    # tool/src/aig_gateway/loader.py -> backend/gateway
    return Path(__file__).resolve().parents[3]


def _read(path: Path) -> Any:
    text = path.read_text()
    return json.loads(text) if path.suffix == ".json" else yaml.safe_load(text)


@dataclass
class Repo:
    root: Path
    manifests: dict[str, dict] = field(default_factory=dict)  # kind -> spec
    manifest_files: dict[str, Path] = field(default_factory=dict)
    envs: dict[str, dict] = field(default_factory=dict)
    templates: dict[str, Any] = field(default_factory=dict)
    schemas: dict[str, dict] = field(default_factory=dict)

    def spec(self, kind: str) -> dict:
        return self.manifests[kind]

    def validator(self, schema_file: str) -> Draft202012Validator:
        return Draft202012Validator(self.schemas[schema_file])


def load_repo(root: Path | None = None) -> Repo:
    """Load everything and schema-validate it. Raises ManifestError with all problems."""
    root = Path(root or default_root())
    repo = Repo(root=root)
    problems: list[str] = []

    for p in sorted((root / "schemas").glob("*.schema.json")):
        schema = _read(p)
        try:
            Draft202012Validator.check_schema(schema)
        except Exception as exc:  # jsonschema.SchemaError
            problems.append(f"schemas/{p.name}: invalid JSON Schema: {exc}")
        repo.schemas[p.name] = schema
    for needed in [*KIND_SCHEMAS.values(), ENV_SCHEMA, PORTKEY_CONFIG_SCHEMA]:
        if needed not in repo.schemas:
            problems.append(f"schemas/{needed}: missing")
    if problems:
        raise ManifestError(problems)

    for p in sorted((root / "manifests").glob("*.y*ml")):
        doc = _read(p)
        rel = f"manifests/{p.name}"
        if not isinstance(doc, dict) or doc.get("kind") not in KIND_SCHEMAS:
            problems.append(f"{rel}: unknown or missing kind (expected one of {sorted(KIND_SCHEMAS)})")
            continue
        kind = doc["kind"]
        if kind in repo.manifests:
            problems.append(f"{rel}: duplicate kind {kind} (also in {repo.manifest_files[kind].name})")
            continue
        for err in repo.validator(KIND_SCHEMAS[kind]).iter_errors(doc):
            problems.append(f"{rel}: {err.json_path}: {err.message}")
        repo.manifests[kind] = doc.get("spec") or {}
        repo.manifest_files[kind] = p
    for kind in KIND_SCHEMAS:
        if kind not in repo.manifests:
            problems.append(f"manifests: no manifest of kind {kind}")

    for env in ENVS:
        p = root / "envs" / f"{env}.yaml"
        if not p.is_file():
            problems.append(f"envs/{env}.yaml: missing")
            continue
        doc = _read(p)
        for err in repo.validator(ENV_SCHEMA).iter_errors(doc):
            problems.append(f"envs/{env}.yaml: {err.json_path}: {err.message}")
        if isinstance(doc, dict) and doc.get("env") != env:
            problems.append(f"envs/{env}.yaml: env must be {env!r}")
        repo.envs[env] = doc if isinstance(doc, dict) else {}

    for p in sorted((root / "configs").glob("*.json")):
        try:
            repo.templates[p.name] = _read(p)
        except json.JSONDecodeError as exc:
            problems.append(f"configs/{p.name}: invalid JSON: {exc}")

    if problems:
        raise ManifestError(problems)
    return repo
