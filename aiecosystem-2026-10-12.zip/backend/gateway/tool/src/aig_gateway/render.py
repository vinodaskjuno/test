"""Render manifests + an env overlay into the Portkey objects the admin API receives.

The rendered form is what `aigw render` prints and what `diff`/`apply` compare. Secrets are
never resolved here: they stay as {"$secret_env": NAME} markers until `apply` writes.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any

from .canary import apply_overlay
from .loader import Repo
from .template import per_env, secret_markers, substitute

# Apply order (prune runs in reverse). Keys are also the endpoint kinds in endpoints.py.
KINDS: tuple[str, ...] = (
    "workspaces",
    "integrations",
    "guardrails",
    "mcp_servers",
    "configs",
    "api_keys",
    "usage_limits",
    "rate_limits",
)

LOG_ACTIONS = {"deny": False, "async": True}
DENY_ACTIONS = {"deny": True, "async": False}
REDACT_ACTIONS = {"deny": False, "async": False}
PII_CHECKS = ("portkey.pii",)


@dataclass
class Rendered:
    env: str
    context: dict
    objects: dict[str, list[dict]] = field(default_factory=dict)

    def find(self, kind: str, **identity: Any) -> dict | None:
        for obj in self.objects.get(kind, []):
            if all(obj.get(k) == v for k, v in identity.items()):
                return obj
        return None

    def config(self, slug: str = "pc-aig-router", workspace: str | None = None) -> dict:
        for obj in self.objects["configs"]:
            if obj["slug"] == slug and (workspace is None or obj["workspace_id"] == workspace):
                return obj["config"]
        raise KeyError(f"config {slug} not rendered for workspace {workspace}")


def guardrail_mode(g: dict, spec: dict, env: str) -> str:
    """'log' or 'enforce' for one guardrail in one env."""
    if g.get("mode_override"):
        return g["mode_override"]
    return (g.get("mode_by_env") or {}).get(env) or spec["modes"][env]


def effective_action(g: dict, spec: dict, env: str) -> str:
    """'log', 'deny' or 'redact'."""
    return "log" if guardrail_mode(g, spec, env) == "log" else g["enforce"]


def build_context(repo: Repo, env: str) -> dict:
    ctx = copy.deepcopy(repo.envs[env])
    caching = per_env(repo.spec("Caching"), env)
    ctx["caching"] = {"mode": caching["portkey"]["mode"], "max_age": caching["portkey"]["max_age_seconds"]}
    return ctx


def _models(repo: Repo, ctx: dict) -> dict[str, dict]:
    return substitute(repo.spec("Models")["models"], ctx)


def render(repo: Repo, env: str) -> Rendered:
    ctx = build_context(repo, env)
    out = Rendered(env=env, context=ctx, objects={k: [] for k in KINDS})
    models = _models(repo, ctx)
    allow = repo.spec("Models")["allow_lists"]
    ws_spec = repo.spec("Workspaces")
    req = ws_spec["required_metadata"]
    # Phase 7 canaries: candidate models join the allow-lists of the workspaces (and the
    # integration) the overlaid production config is deployed to, only while their entry exists.
    canary_spec = repo.manifests.get("Canaries") or {"config": "pc-aig-router", "canaries": []}
    canaries = substitute(canary_spec.get("canaries") or [], ctx)
    canary_ws = next((set(c["workspaces"]) for c in repo.spec("Configs")["configs"]
                      if c["slug"] == canary_spec.get("config")), set())
    canary_models = {e["model"]["model"] for e in canaries}

    metadata_schema = {
        "type": "object",
        "required": list(req["keys"]),
        "properties": {
            **{k: {"type": "string", "enum": list(v)} for k, v in req.get("enums", {}).items()},
            **{k: {"type": "string", "pattern": v} for k, v in req.get("patterns", {}).items()},
        },
    }
    for ws in ws_spec["workspaces"]:
        out.objects["workspaces"].append(
            {
                "slug": ws["slug"],
                "name": ws["name"],
                "description": ws.get("description", ""),
                "settings": {
                    "is_sandbox": bool(ws.get("sandbox", False)),
                    "required_metadata": {"keys": list(req["keys"]), "schema": metadata_schema},
                    "allowed_models": sorted({models[m]["model"] for m in allow.get(ws["slug"], [])}
                                             | (canary_models if ws["slug"] in canary_ws else set())),
                },
            }
        )

    for it in repo.spec("Integrations")["integrations"]:
        obj: dict[str, Any] = {
            "slug": it["slug"],
            "name": it["name"],
            "ai_provider_id": it["provider"],
            "workspace_ids": list(it["workspaces"]),
            "is_sandbox": bool(it.get("sandbox", False)),
            "allowed_models": sorted({m["model"] for m in models.values() if m["integration"] == it["slug"]}
                                     | {e["model"]["model"] for e in canaries if e["model"]["integration"] == it["slug"]}),
            "key": {"$secret_env": it["secret_env"]},  # create-only, see endpoints.py
        }
        if it.get("deployments"):
            obj["configurations"] = {
                "deployments": [
                    {
                        "name": d["name"],
                        "custom_host": f"{ctx['cache_compress']['host']}/{d['cache_compress_route']}/v1",
                        "weight": d["weight"],
                    }
                    for d in it["deployments"]
                ]
            }
        out.objects["integrations"].append(obj)

    g_spec = repo.spec("Guardrails")
    for g in g_spec["guardrails"]:
        action = effective_action(g, g_spec, env)
        checks = []
        for c in secret_markers(substitute(g["checks"], ctx)):
            c = {"id": c["id"], "parameters": copy.deepcopy(c.get("parameters") or {})}
            if c["id"] in PII_CHECKS:
                c["parameters"]["redact"] = action == "redact"
            checks.append(c)
        out.objects["guardrails"].append(
            {
                "slug": g["slug"],
                "name": g["name"],
                "checks": checks,
                "actions": dict({"log": LOG_ACTIONS, "deny": DENY_ACTIONS, "redact": REDACT_ACTIONS}[action]),
            }
        )

    acct = ctx.get("aws", {}).get("account_id", "<aws-account-id>")
    mcp_spec = repo.spec("McpServers")
    for s in mcp_spec["servers"]:
        out.objects["mcp_servers"].append(
            {
                "slug": s["slug"],
                "name": s["name"],
                "url": substitute(s["url"], ctx),
                "transport": s["transport"],
                "auth": copy.deepcopy(s.get("auth") or {}),
                "workspace_ids": list(s["workspaces"]),
                "access": {
                    "unregistered": mcp_spec["policy"]["unregistered"],
                    "iam_role_arns": [f"arn:aws:iam::{acct}:role/{r}" for r in s["iam_roles"]],
                },
                "tools": copy.deepcopy(s.get("tools") or {}),
            }
        )

    integrations_spec = {i["slug"]: i for i in repo.spec("Integrations")["integrations"]}
    for c in repo.spec("Configs")["configs"]:
        body = substitute(repo.templates[c["template"]], ctx)
        if canaries and c["slug"] == canary_spec.get("config") and not c.get("sandbox"):
            body = apply_overlay(body, canaries, integrations=integrations_spec, host=str(ctx["cache_compress"]["host"]),
                                 job_profiles=list(req["enums"]["job_profile"]))
        for ws in c["workspaces"]:
            out.objects["configs"].append(
                {"slug": c["slug"], "name": c["name"], "workspace_id": ws, "config": copy.deepcopy(body)}
            )

    for k in repo.spec("ApiKeys")["keys"]:
        obj = {
            "name": k["name"],
            "description": k.get("description", ""),
            "type": k["type"],
            "sub_type": k["sub_type"],
            "workspace_id": k["workspace"],
            "scopes": list(k["scopes"]),
        }
        if k.get("default_config"):
            obj["defaults"] = {"config_id": k["default_config"]}
        out.objects["api_keys"].append(obj)

    limits = per_env(repo.spec("Limits"), env)
    threshold = limits["alert_threshold"]
    for ws, lim in limits["teams"].items():
        cond = [{"key": "workspace_id", "value": ws}]
        out.objects["usage_limits"].append(
            {
                "name": f"aig-budget-team-{ws}",
                "type": "cost",
                "credit_limit": lim["monthly_budget_usd"],
                "alert_threshold": round(lim["monthly_budget_usd"] * threshold, 2),
                "periodic_reset": "monthly",
                "conditions": cond,
                "group_by": [{"key": "workspace_id"}],
            }
        )
        out.objects["rate_limits"].append(
            {
                "name": f"aig-rate-team-{ws}",
                "type": "requests",
                "unit": "rpm",
                "value": lim["requests_per_minute"],
                "conditions": cond,
                "group_by": [{"key": "workspace_id"}],
            }
        )
    for jp, lim in limits["job_profiles"].items():
        cond = [{"key": "metadata.job_profile", "value": jp}]
        out.objects["usage_limits"].append(
            {
                "name": f"aig-budget-profile-{jp}",
                "type": "cost",
                "credit_limit": lim["monthly_budget_usd"],
                "alert_threshold": round(lim["monthly_budget_usd"] * threshold, 2),
                "periodic_reset": "monthly",
                "conditions": cond,
                "group_by": [{"key": "metadata.job_profile"}],
            }
        )
        out.objects["rate_limits"].append(
            {
                "name": f"aig-rate-profile-{jp}",
                "type": "tokens",
                "unit": "rpm",
                "value": lim["tokens_per_minute"],
                "conditions": cond,
                "group_by": [{"key": "metadata.job_profile"}],
            }
        )
    return out
