"""Cross-manifest checks on top of the JSON Schemas, run per environment by `aigw validate`."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .loader import ENVS, PORTKEY_CONFIG_SCHEMA, STRICT_ENVS, Repo
from .render import Rendered, render
from .routing import RoutingError, _plan
from .template import TemplateError, find_placeholders


SANDBOX_GUARDRAILS = ("aig-input-pii", "aig-input-injection", "aig-input-policy", "aig-output-policy", "aig-output-pii")


@dataclass
class Report:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    rendered: dict[str, Rendered] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors


def _dupes(items: list[str]) -> list[str]:
    seen, out = set(), []
    for i in items:
        if i in seen and i not in out:
            out.append(i)
        seen.add(i)
    return out


def check_static(repo: Repo) -> list[str]:
    errs: list[str] = []
    ws_list = repo.spec("Workspaces")["workspaces"]
    workspaces = {w["slug"]: w for w in ws_list}
    sandbox_ws = {s for s, w in workspaces.items() if w.get("sandbox")}
    for d in _dupes([w["slug"] for w in ws_list]):
        errs.append(f"workspaces: duplicate slug {d}")
    if sandbox_ws != {"model-sandbox"}:
        errs.append(f"workspaces: exactly one sandbox workspace named model-sandbox expected, got {sorted(sandbox_ws)}")

    integrations = {i["slug"]: i for i in repo.spec("Integrations")["integrations"]}
    for d in _dupes([i["slug"] for i in repo.spec("Integrations")["integrations"]]):
        errs.append(f"integrations: duplicate slug {d}")
    for slug, it in integrations.items():
        for ws in it["workspaces"]:
            if ws not in workspaces:
                errs.append(f"integrations.{slug}: unknown workspace {ws}")
        in_sandbox = set(it["workspaces"]) & sandbox_ws
        if it.get("sandbox") and set(it["workspaces"]) - sandbox_ws:
            errs.append(f"integrations.{slug}: sandbox integration must exist only in model-sandbox")
        if not it.get("sandbox") and in_sandbox:
            errs.append(f"integrations.{slug}: production integration must not be shared with model-sandbox")
        if bool(it.get("sandbox")) != slug.endswith("-sandbox"):
            errs.append(f"integrations.{slug}: slugs ending in -sandbox must be sandbox: true (and only those)")
        weights = [d["weight"] for d in it.get("deployments", [])]
        if weights and abs(sum(weights) - 1.0) > 1e-9:
            errs.append(f"integrations.{slug}: deployment weights must sum to 1")

    models = repo.spec("Models")["models"]
    for alias, m in models.items():
        if m["integration"] not in integrations:
            errs.append(f"models.{alias}: unknown integration {m['integration']}")
    for ws, aliases in repo.spec("Models")["allow_lists"].items():
        if ws not in workspaces:
            errs.append(f"models.allow_lists: unknown workspace {ws}")
            continue
        for a in aliases:
            if a not in models:
                errs.append(f"models.allow_lists.{ws}: unknown model alias {a}")
                continue
            it = integrations.get(models[a]["integration"], {})
            if bool(it.get("sandbox")) != (ws in sandbox_ws):
                errs.append(f"models.allow_lists.{ws}: {a} uses {'sandbox' if it.get('sandbox') else 'production'} "
                            f"integration {it.get('slug')}, not allowed in this workspace")
            elif ws not in it.get("workspaces", []):
                errs.append(f"models.allow_lists.{ws}: {a}'s integration {it.get('slug')} is not shared with {ws}")
    for ws in workspaces:
        if ws not in repo.spec("Models")["allow_lists"]:
            errs.append(f"models.allow_lists: workspace {ws} has no allow-list")

    configs = repo.spec("Configs")["configs"]
    deployed: dict[str, set[str]] = {}
    for d in _dupes([c["slug"] for c in configs]):
        errs.append(f"configs: duplicate slug {d}")
    for c in configs:
        if c["template"] not in repo.templates:
            errs.append(f"configs.{c['slug']}: template configs/{c['template']} not found")
        for ws in c["workspaces"]:
            if ws not in workspaces:
                errs.append(f"configs.{c['slug']}: unknown workspace {ws}")
            elif c.get("sandbox") and ws not in sandbox_ws:
                errs.append(f"configs.{c['slug']}: sandbox configs may only be deployed to model-sandbox, not {ws}")
            elif not c.get("sandbox") and ws in sandbox_ws:
                errs.append(f"configs.{c['slug']}: production configs must not be deployed to model-sandbox")
        deployed[c["slug"]] = set(c["workspaces"])
    errs += check_canaries(repo, integrations, configs, models)

    names = [k["name"] for k in repo.spec("ApiKeys")["keys"]]
    for d in _dupes(names):
        errs.append(f"api_keys: duplicate name {d}")
    for k in repo.spec("ApiKeys")["keys"]:
        if k["workspace"] not in workspaces:
            errs.append(f"api_keys.{k['name']}: unknown workspace {k['workspace']}")
        dc = k.get("default_config")
        if dc and k["workspace"] not in deployed.get(dc, set()):
            errs.append(f"api_keys.{k['name']}: default_config {dc} is not deployed to {k['workspace']}")

    req = repo.spec("Workspaces")["required_metadata"]
    limits = repo.spec("Limits")
    for ws in limits["teams"]:
        if ws not in workspaces:
            errs.append(f"limits.teams: unknown workspace {ws}")
    for jp in limits["job_profiles"]:
        if jp not in req["enums"]["job_profile"]:
            errs.append(f"limits.job_profiles: unknown job profile {jp}")

    g_spec = repo.spec("Guardrails")
    for d in _dupes([g["slug"] for g in g_spec["guardrails"]]):
        errs.append(f"guardrails: duplicate slug {d}")
    if set(g_spec["modes"]) != set(ENVS):
        errs.append(f"guardrails.modes: must define every env {list(ENVS)}")

    roles_by_ws = {s: set(w.get("iam_roles", [])) for s, w in workspaces.items()}
    for s in repo.spec("McpServers")["servers"]:
        allowed_roles: set[str] = set()
        for ws in s["workspaces"]:
            if ws not in workspaces:
                errs.append(f"mcp_servers.{s['slug']}: unknown workspace {ws}")
            elif ws in sandbox_ws:
                errs.append(f"mcp_servers.{s['slug']}: MCP servers are not available in model-sandbox")
            allowed_roles |= roles_by_ws.get(ws, set())
        for r in s["iam_roles"]:
            if r not in allowed_roles:
                errs.append(f"mcp_servers.{s['slug']}: IAM role {r} does not belong to any of its workspaces")
    return errs


def check_canaries(repo: Repo, integrations: dict, configs: list[dict], models: dict) -> list[str]:
    """Phase 7: canary entries name a production config, unique tiers, production integrations only
    (a sandbox-evaluated or rejected model never gets a production route on a sandbox key)."""
    spec = repo.manifests.get("Canaries")
    if not spec:
        return []
    errs: list[str] = []
    target = next((c for c in configs if c["slug"] == spec["config"]), None)
    if target is None:
        errs.append(f"canaries.config: unknown config {spec['config']}")
    elif target.get("sandbox"):
        errs.append(f"canaries.config: {spec['config']} is a sandbox config; canaries apply to production configs only")
    for d in _dupes([e["tier"] for e in spec["canaries"]]):
        errs.append(f"canaries: tier {d} has more than one entry")
    sandbox_aliases = {a for a, m in models.items() if integrations.get(m["integration"], {}).get("sandbox")}
    for e in spec["canaries"]:
        where = f"canaries.{e['tier']}"
        m = e["model"]
        it = integrations.get(m["integration"])
        if it is None:
            errs.append(f"{where}: unknown integration {m['integration']}")
        elif it.get("sandbox"):
            errs.append(f"{where}: {m['alias']} uses sandbox integration {m['integration']}; sandbox keys never get a production route")
        if m["alias"] in sandbox_aliases:
            errs.append(f"{where}: {m['alias']} is a sandbox model alias; it can never get a production route")
        if e["state"] == "canary" and not 0 < float(e["share"]) < 100:
            errs.append(f"{where}: a canary share must be > 0 and < 100 (got {e['share']})")
        if e["state"] == "promoted" and float(e["share"]) != 100:
            errs.append(f"{where}: a promoted model takes 100% of its tier (got {e['share']})")
    return errs


def _strings(node) -> list[str]:
    if isinstance(node, str):
        return [node]
    if isinstance(node, dict):
        return [s for v in node.values() for s in _strings(v)]
    if isinstance(node, list):
        return [s for v in node for s in _strings(v)]
    return []


def check_contracts(repo: Repo, contracts_dir: Path | None = None) -> list[str]:
    """Required-metadata values must equal backend/contracts/metadata.schema.json (when present)."""
    contracts_dir = contracts_dir or repo.root.parent / "contracts"
    path = contracts_dir / "metadata.schema.json"
    if not path.is_file():
        return []
    schema = json.loads(path.read_text())
    defs = schema["$defs"]
    req = repo.spec("Workspaces")["required_metadata"]
    errs = []
    for key in req["keys"]:
        if key not in schema.get("required", []):
            errs.append(f"required_metadata: {key} is not required by backend/contracts/metadata.schema.json")
    for key, values in req["enums"].items():
        if list(values) != list(defs[key]["enum"]):
            errs.append(f"required_metadata.enums.{key} {values} != contracts {defs[key]['enum']}")
    for key, pattern in req["patterns"].items():
        if pattern != defs[key]["pattern"]:
            errs.append(f"required_metadata.patterns.{key} differs from contracts")
    return errs


def check_rendered(repo: Repo, r: Rendered) -> list[str]:
    errs: list[str] = []
    env = r.env
    validator = repo.validator(PORTKEY_CONFIG_SCHEMA)
    integrations = {i["slug"]: i for i in r.objects["integrations"]}
    guardrails = {g["slug"]: g for g in repo.spec("Guardrails")["guardrails"]}
    workspaces = {w["slug"]: w for w in r.objects["workspaces"]}
    host = str(r.context["cache_compress"]["host"]).rstrip("/")
    sandbox_configs = {c["slug"] for c in repo.spec("Configs")["configs"] if c.get("sandbox")}
    sandbox_slugs = {s for s, it in integrations.items() if it["is_sandbox"]}
    for obj in r.objects["configs"]:
        where = f"[{env}] configs.{obj['slug']}@{obj['workspace_id']}"
        cfg = obj["config"]
        is_sandbox_cfg = obj["slug"] in sandbox_configs
        ws_is_sandbox = bool(workspaces.get(obj["workspace_id"], {}).get("settings", {}).get("is_sandbox"))
        if is_sandbox_cfg != ws_is_sandbox:
            errs.append(f"{where}: sandbox configs live only in model-sandbox and production configs never do")
        if not ws_is_sandbox:
            # Deep scan: a sandbox integration must not appear anywhere in a non-sandbox workspace's
            # config (as a leaf, a nested target or a "@slug" provider reference).
            for value in _strings(cfg):
                hit = next((sb for sb in sandbox_slugs if value == sb or value.lstrip("@") == sb
                            or value.startswith(sb + "/") or f"@{sb}" in value), None)
                if hit:
                    errs.append(f"{where}: sandbox integration {hit} is referenced by a non-sandbox workspace config")
        if not is_sandbox_cfg and "cache" not in cfg:
            errs.append(f"{where}: production configs need a cache block")
        for e in validator.iter_errors(cfg):
            errs.append(f"{where}: {e.json_path}: {e.message}")
        names = [t.get("name") for t in cfg.get("targets", [])]
        strategy = cfg.get("strategy", {})
        for ref in [c.get("then") for c in strategy.get("conditions", [])] + [strategy.get("default")]:
            if ref not in names:
                errs.append(f"{where}: condition target {ref!r} is not defined")
        try:
            leaves = [leaf for t in cfg.get("targets", []) for leaf in _plan(t).chain()]
        except RoutingError as exc:
            errs.append(f"{where}: {exc}")
            leaves = []
        allowed = set(workspaces.get(obj["workspace_id"], {}).get("settings", {}).get("allowed_models", []))
        for leaf in leaves:
            it = integrations.get(leaf.virtual_key or "")
            if it is None:
                errs.append(f"{where}: virtual key {leaf.virtual_key!r} is not a declared integration")
            elif it["is_sandbox"] and not is_sandbox_cfg:
                errs.append(f"{where}: sandbox key {leaf.virtual_key} must never be reachable from a production config")
            elif is_sandbox_cfg and not it["is_sandbox"]:
                errs.append(f"{where}: production key {leaf.virtual_key} must never be used by the model sandbox")
            elif obj["workspace_id"] not in it["workspace_ids"]:
                errs.append(f"{where}: integration {leaf.virtual_key} is not shared with {obj['workspace_id']}")
            if not leaf.custom_host or not leaf.custom_host.startswith(host + "/"):
                errs.append(f"{where}: every leaf needs custom_host on the cache-compress layer ({host}/...)")
            if not leaf.model:
                errs.append(f"{where}: every leaf needs override_params.model")
            elif leaf.model not in allowed:
                errs.append(f"{where}: model {leaf.model} is not in {obj['workspace_id']}'s allow-list")
        for hook, key in (("input", "input_guardrails"), ("output", "output_guardrails")):
            for slug in cfg.get(key, []):
                g = guardrails.get(slug)
                if g is None:
                    errs.append(f"{where}: {key} references unknown guardrail {slug}")
                elif g["hook"] != hook:
                    errs.append(f"{where}: guardrail {slug} is a {g['hook']} hook, used in {key}")
        if is_sandbox_cfg:
            # Safety suites run with guardrails ON (the harness agent is not a registered agent;
            # the sandbox-only workspace key is the access control there).
            missing = [g for g in SANDBOX_GUARDRAILS if g not in cfg.get("input_guardrails", []) + cfg.get("output_guardrails", [])]
            if missing:
                errs.append(f"{where}: the model sandbox needs guardrails on: missing {', '.join(missing)}")
        elif "aig-agent-check" not in cfg.get("input_guardrails", []):
            errs.append(f"{where}: the registered-agent webhook guardrail aig-agent-check must be an input guardrail")
    return errs


def validate(repo: Repo, envs: list[str] | None = None, allow_placeholders: bool = False) -> Report:
    report = Report()
    report.errors += check_static(repo)
    report.errors += check_contracts(repo)
    for env in envs or list(ENVS):
        try:
            r = render(repo, env)
        except (TemplateError, KeyError) as exc:
            report.errors.append(f"[{env}] render failed: {exc}")
            continue
        report.rendered[env] = r
        report.errors += check_rendered(repo, r)
        found = [(kind, p, ph) for kind, objs in r.objects.items() for obj in objs for p, ph in find_placeholders(obj)]
        if found:
            unique = sorted({ph for _, _, ph in found})
            msg = f"[{env}] {len(found)} unresolved placeholder value(s): {', '.join(unique)}"
            if env in STRICT_ENVS and not allow_placeholders:
                report.errors.append(msg + " (replace them in envs/" + env + ".yaml, or pass --allow-placeholders)")
            else:
                report.warnings.append(msg)
    return report
