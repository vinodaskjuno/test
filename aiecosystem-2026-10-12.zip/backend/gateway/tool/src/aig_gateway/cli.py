"""aigw: validate, render, diff and apply backend/gateway against a self-hosted Portkey.

  aigw validate [--env ENV ...] [--allow-placeholders]
  aigw render   --env ENV [--kind KIND ...]
  aigw diff     --env ENV [--kind KIND ...] [--prune] [--json] [--exit-code]
  aigw apply    --env ENV [--kind KIND ...] [--yes] [--prune] [--json]
  aigw route    --env ENV --tier TIER --job-profile JOB [--workspace WS]
  aigw matrix   --env ENV [--workspace WS]
  aigw canary set      --tier TIER --model ALIAS --share PCT [--model-id ID --provider P | --integration SLUG]
  aigw canary promote  --tier TIER --model ALIAS
  aigw canary rollback --tier TIER
  aigw canary sync     --from-platform-api [--platform-api-url URL]
  aigw canary show

canary commands edit manifests/canaries.yaml only (deterministic, idempotent; the change is
validated for every env and reverted if invalid). Open a PR with the diff; `aigw apply` pushes it.

diff/apply read AIG_PORTKEY_ADMIN_URL and AIG_PORTKEY_ADMIN_API_KEY. apply is a dry run unless
--yes; it never deletes unless --prune. Secret values are never printed.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .admin import AdminClient, AdminError
from .canary import CanaryError, canary_promote, canary_rollback, canary_set, canary_sync, describe, fetch_models, load_canaries
from .endpoints import load_endpoints
from .loader import ENVS, ManifestError, load_repo
from .plan import apply_plan, build_plan, fetch_remote, format_plan
from .render import KINDS, render
from .routing import resolve
from .simulate import matrix
from .template import mask_secrets
from .validate import validate


def _repo(args):
    return load_repo(Path(args.root) if args.root else None)


def _dump(obj) -> str:
    return json.dumps(obj, indent=2, sort_keys=False)


def cmd_validate(args) -> int:
    repo = _repo(args)
    report = validate(repo, args.env or list(ENVS), allow_placeholders=args.allow_placeholders)
    for w in report.warnings:
        print(f"warning: {w}")
    for e in report.errors:
        print(f"error: {e}", file=sys.stderr)
    if report.ok:
        print(f"validate: OK ({len(repo.manifests)} manifests, envs: {', '.join(report.rendered)})")
        return 0
    print(f"validate: FAILED ({len(report.errors)} error(s))", file=sys.stderr)
    return 1


def _rendered(args):
    repo = _repo(args)
    report = validate(repo, [args.env], allow_placeholders=True)
    if not report.ok:
        for e in report.errors:
            print(f"error: {e}", file=sys.stderr)
        raise SystemExit(1)
    return repo, report.rendered[args.env]


def cmd_render(args) -> int:
    _, r = _rendered(args)
    objects = {k: v for k, v in r.objects.items() if not args.kind or k in args.kind}
    print(_dump({"env": r.env, "objects": mask_secrets(objects)}))
    return 0


def _plan(args):
    repo, r = _rendered(args)
    endpoints = load_endpoints()
    client = AdminClient.from_env()
    try:
        remote = fetch_remote(client, endpoints, args.kind)
        plan = build_plan(r, remote, endpoints, prune=args.prune,
                          managed_patterns=repo.spec("Gateway")["prune"]["managed_patterns"], kinds=args.kind)
    except Exception:
        client.close()
        raise
    return plan, client, endpoints


def cmd_diff(args) -> int:
    plan, client, _ = _plan(args)
    client.close()
    print(_dump(plan.as_dict()) if args.json else format_plan(plan))
    return 2 if args.exit_code and plan.has_changes else 0


def cmd_apply(args) -> int:
    plan, client, endpoints = _plan(args)
    try:
        ok = apply_plan(plan, client, endpoints, yes=args.yes)
    finally:
        client.close()
    if args.json:
        print(_dump({**plan.as_dict(), "dry_run": not args.yes}))
    else:
        print(format_plan(plan, applied=args.yes))
        if not args.yes and plan.has_changes:
            print("Dry run: nothing was written. Re-run with --yes to apply.")
    return 0 if ok else 1


def cmd_route(args) -> int:
    _, r = _rendered(args)
    meta = {"user_tier": args.tier, "job_profile": args.job_profile}
    res = resolve(r.config(workspace=args.workspace), meta)
    print(_dump(res.as_dict()))
    return 0


def cmd_matrix(args) -> int:
    _, r = _rendered(args)
    rows = matrix(r, args.workspace)
    if args.json:
        print(_dump(rows))
        return 0
    print(f"{'tier':<9} {'job_profile':<13} {'rule':<8} {'target':<7} {'mode':<12} models")
    for row in rows:
        models = " | ".join(str(m) for m in row["models"])
        if row["shares"]:
            models += "  shares=" + "/".join(f"{s:g}" for s in row["shares"])
        print(f"{row['user_tier']:<9} {row['job_profile']:<13} {row['rule']!s:<8} {row['target']:<7} {row['mode']:<12} {models}")
    return 0


def cmd_canary(args) -> int:
    repo = _repo(args)
    if args.canary_cmd == "show":
        print(describe(repo))
        return 0
    cf = load_canaries(repo.root)
    before = cf.path.read_text() if cf.path.is_file() else None
    if args.canary_cmd == "set":
        changed, msg = canary_set(repo, tier=args.tier, alias=args.model, share=args.share, model_id=args.model_id,
                                  provider=args.provider, integration=args.integration,
                                  platform_model_id=args.platform_model_id)
    elif args.canary_cmd == "promote":
        changed, msg = canary_promote(repo, tier=args.tier, alias=args.model)
    elif args.canary_cmd == "rollback":
        changed, msg = canary_rollback(repo, tier=args.tier)
    else:
        if not args.from_platform_api:
            print("error: canary sync needs --from-platform-api", file=sys.stderr)
            return 2
        changed, msg = canary_sync(repo, fetch_models(args.platform_api_url))
    if changed:
        try:
            report = validate(load_repo(repo.root), list(ENVS), allow_placeholders=True)
            problems = report.errors
        except ManifestError as exc:
            problems = exc.problems
        if problems:
            if before is None:
                cf.path.unlink(missing_ok=True)
            else:
                cf.path.write_text(before)
            for e in problems:
                print(f"error: {e}", file=sys.stderr)
            print("canary: change reverted (validation failed)", file=sys.stderr)
            return 1
    print(msg)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="aigw", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--root", help="backend/gateway directory (default: auto-detected, or AIGW_ROOT)")
    sub = p.add_subparsers(dest="command", required=True)

    v = sub.add_parser("validate", help="schema + cross-reference checks, render every env")
    v.add_argument("--env", action="append", choices=ENVS, help="limit to these envs (repeatable)")
    v.add_argument("--allow-placeholders", action="store_true", help="accept <placeholders> in stage/prod")
    v.set_defaults(func=cmd_validate)

    def env_cmd(name, func, help_):
        c = sub.add_parser(name, help=help_)
        c.add_argument("--env", required=True, choices=ENVS)
        c.set_defaults(func=func)
        return c

    r = env_cmd("render", cmd_render, "print the final Portkey objects (secrets masked)")
    r.add_argument("--kind", action="append", choices=KINDS)
    for name, func, help_ in (("diff", cmd_diff, "structured diff against the Portkey admin API"),
                              ("apply", cmd_apply, "create/update via the admin API (dry run unless --yes)")):
        c = env_cmd(name, func, help_)
        c.add_argument("--kind", action="append", choices=KINDS)
        c.add_argument("--prune", action="store_true", help="also delete managed objects no manifest declares")
        c.add_argument("--json", action="store_true")
        if name == "diff":
            c.add_argument("--exit-code", action="store_true", help="exit 2 when there are changes")
        else:
            c.add_argument("--yes", action="store_true", help="really write (default: dry run)")
    rt = env_cmd("route", cmd_route, "show which target a tier/job profile is routed to")
    rt.add_argument("--tier", required=True)
    rt.add_argument("--job-profile", required=True)
    rt.add_argument("--workspace", default="aig-platform")
    m = env_cmd("matrix", cmd_matrix, "routing table for every tier x job_profile")
    m.add_argument("--workspace", default="aig-platform")
    m.add_argument("--json", action="store_true")

    cy = sub.add_parser("canary", help="model canary / promote / rollback (edits manifests/canaries.yaml)")
    cy.set_defaults(func=cmd_canary)
    csub = cy.add_subparsers(dest="canary_cmd", required=True)
    cs = csub.add_parser("set", help="add or update the tier's canary (weighted loadbalance target)")
    cs.add_argument("--tier", required=True)
    cs.add_argument("--model", required=True, help="model alias (existing in models.yaml, or new with --model-id)")
    cs.add_argument("--share", required=True, type=float, help="percent of the tier's traffic (0 < share < 100)")
    cs.add_argument("--model-id", help="provider model id for a new alias")
    cs.add_argument("--provider", help="anthropic | openai (picks the production integration)")
    cs.add_argument("--integration", help="production integration slug (instead of --provider)")
    cs.add_argument("--platform-model-id", help="platform-api model catalog id (recorded)")
    cp = csub.add_parser("promote", help="make the canary the tier's target (incumbent kept as fallback)")
    cp.add_argument("--tier", required=True)
    cp.add_argument("--model", required=True)
    cr = csub.add_parser("rollback", help="remove the tier's canary / promotion (one step back)")
    cr.add_argument("--tier", required=True)
    cn = csub.add_parser("sync", help="compute every tier's entry from platform-api model states")
    cn.add_argument("--from-platform-api", action="store_true", required=True)
    cn.add_argument("--platform-api-url", help="default: AIG_PLATFORM_API_URL (token: AIG_PLATFORM_SERVICE_TOKEN)")
    csub.add_parser("show", help="print the current canary entries")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except ManifestError as exc:
        for prob in exc.problems:
            print(f"error: {prob}", file=sys.stderr)
        return 1
    except AdminError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except CanaryError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
