"""Offline evaluator of Portkey config routing.

Models Portkey's documented semantics so routing can be tested without a gateway:

- ``strategy.mode: conditional``: ``conditions`` are checked top to bottom; the first whose
  ``query`` matches wins and its ``then`` names a target; no match -> ``default``.
- Queries read ``metadata.<key>`` (x-portkey-metadata) and ``params.<key>`` (request body).
  Operators: $eq $ne $in $nin $regex $gt $gte $lt $lte, combined with $and / $or. Several keys
  in one query object are an implicit AND; a bare value means $eq.
- Missing fields follow MongoDB-style semantics (Portkey's query language is modelled on it):
  $ne / $nin match a missing field, every other operator does not.
- ``fallback`` tries targets in order; ``loadbalance`` picks by ``weight`` (default 1);
  targets nest.

Verify edge cases (missing fields, type coercion, regex flavour) against AIG's Portkey version;
scripts/gateway-matrix-live.sh checks the real gateway.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

OPERATORS = ("$eq", "$ne", "$in", "$nin", "$regex", "$gt", "$gte", "$lt", "$lte")
LOGICAL = ("$and", "$or")
_MISSING = object()


class RoutingError(ValueError):
    pass


def _field(ctx: dict, path: str) -> Any:
    root, _, rest = path.partition(".")
    if root not in ("metadata", "params") or not rest:
        raise RoutingError(f"query field must start with metadata. or params.: {path!r}")
    cur: Any = ctx.get(root) or {}
    for part in rest.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return _MISSING
        cur = cur[part]
    return cur


def _num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _compare(op: str, actual: Any, expected: Any) -> bool:
    if op == "$ne":
        return actual is _MISSING or actual != expected
    if op == "$nin":
        if not isinstance(expected, list):
            raise RoutingError("$nin needs a list")
        return actual is _MISSING or actual not in expected
    if actual is _MISSING:
        return False
    if op == "$eq":
        return actual == expected
    if op == "$in":
        if not isinstance(expected, list):
            raise RoutingError("$in needs a list")
        return actual in expected
    if op == "$regex":
        if not isinstance(expected, str):
            raise RoutingError("$regex needs a string pattern")
        return isinstance(actual, str) and re.search(expected, actual) is not None
    if op in ("$gt", "$gte", "$lt", "$lte"):
        if _num(actual) and _num(expected) or isinstance(actual, str) and isinstance(expected, str):
            return {"$gt": actual > expected, "$gte": actual >= expected,
                    "$lt": actual < expected, "$lte": actual <= expected}[op]
        return False
    raise RoutingError(f"unsupported operator {op!r}")


def matches(query: dict, ctx: dict) -> bool:
    if not isinstance(query, dict):
        raise RoutingError("query must be an object")
    for key, cond in query.items():
        if key in LOGICAL:
            if not isinstance(cond, list) or not cond:
                raise RoutingError(f"{key} needs a non-empty list of queries")
            results = [matches(q, ctx) for q in cond]
            if not (all(results) if key == "$and" else any(results)):
                return False
            continue
        if key.startswith("$"):
            raise RoutingError(f"unsupported operator {key!r} at query level")
        actual = _field(ctx, key)
        if isinstance(cond, dict) and cond and all(k.startswith("$") for k in cond):
            for op, expected in cond.items():
                if op not in OPERATORS:
                    raise RoutingError(f"unsupported operator {op!r}")
                if not _compare(op, actual, expected):
                    return False
        elif not _compare("$eq", actual, cond):
            return False
    return True


@dataclass
class Leaf:
    virtual_key: str | None
    model: str | None
    custom_host: str | None
    weight: float | None = None
    provider: str | None = None

    def as_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass
class Plan:
    """Resolved strategy tree: a leaf, or a fallback / loadbalance over sub-plans."""

    mode: str  # "single" | "fallback" | "loadbalance"
    leaf: Leaf | None = None
    options: list["Plan"] = field(default_factory=list)
    weights: list[float] = field(default_factory=list)

    def chain(self) -> list[Leaf]:
        """Leaves in the order they would be tried / considered."""
        if self.leaf is not None:
            return [self.leaf]
        return [leaf for opt in self.options for leaf in opt.chain()]

    def models(self) -> list[str | None]:
        return [leaf.model for leaf in self.chain()]

    def shares(self) -> list[float]:
        """Normalised loadbalance shares (empty for non-loadbalance plans)."""
        total = sum(self.weights)
        return [round(w / total, 6) for w in self.weights] if self.mode == "loadbalance" and total else []

    def as_dict(self) -> dict:
        if self.leaf is not None:
            return {"mode": "single", **self.leaf.as_dict()}
        out: dict[str, Any] = {"mode": self.mode, "options": [o.as_dict() for o in self.options]}
        if self.mode == "loadbalance":
            out["shares"] = self.shares()
        return out


@dataclass
class Resolution:
    rule_index: int | None  # None = default
    target: str
    plan: Plan

    @property
    def mode(self) -> str:
        return self.plan.mode

    def as_dict(self) -> dict:
        return {
            "matched_rule": self.rule_index + 1 if self.rule_index is not None else "default",
            "target": self.target,
            **self.plan.as_dict(),
        }


def _leaf(t: dict, inherited: dict) -> Leaf:
    merged = {**inherited, **{k: v for k, v in t.items() if k not in ("targets", "strategy", "name")}}
    return Leaf(
        virtual_key=merged.get("virtual_key"),
        model=(merged.get("override_params") or {}).get("model"),
        custom_host=merged.get("custom_host"),
        weight=t.get("weight"),
        provider=merged.get("provider"),
    )


def _plan(t: dict, inherited: dict | None = None) -> Plan:
    inherited = dict(inherited or {})
    if "targets" not in t:
        return Plan(mode="single", leaf=_leaf(t, inherited))
    mode = (t.get("strategy") or {}).get("mode")
    if mode not in ("fallback", "loadbalance"):
        raise RoutingError(f"nested target {t.get('name')!r}: unsupported strategy {mode!r}")
    if not t["targets"]:
        raise RoutingError(f"target {t.get('name')!r} has no targets")
    # Target-level settings (custom_host, override_params...) are inherited by children.
    for k in ("virtual_key", "custom_host", "override_params", "provider"):
        if k in t:
            inherited[k] = t[k]
    options = [_plan(c, inherited) for c in t["targets"]]
    weights = [float(c.get("weight", 1)) for c in t["targets"]] if mode == "loadbalance" else []
    return Plan(mode=mode, options=options, weights=weights)


def resolve(config: dict, metadata: dict | None = None, params: dict | None = None) -> Resolution:
    """Which target (and strategy tree) Portkey would use for a request."""
    strategy = config.get("strategy") or {}
    targets = config.get("targets") or []
    if strategy.get("mode") != "conditional":
        return Resolution(None, "<root>", _plan({"strategy": strategy, "targets": targets}))
    by_name = {t.get("name"): t for t in targets}
    ctx = {"metadata": metadata or {}, "params": params or {}}
    chosen, index = strategy.get("default"), None
    for i, cond in enumerate(strategy.get("conditions") or []):
        if matches(cond["query"], ctx):
            chosen, index = cond["then"], i
            break
    if chosen not in by_name:
        raise RoutingError(f"target {chosen!r} is not defined in targets")
    return Resolution(index, chosen, _plan(by_name[chosen]))
