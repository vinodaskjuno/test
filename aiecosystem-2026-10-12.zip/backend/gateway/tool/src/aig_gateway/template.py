"""Template values: ${dotted.path} substitution, per-env values, placeholders, secret markers."""

from __future__ import annotations

import copy
import re
from typing import Any

VAR_RE = re.compile(r"\$\{([A-Za-z0-9_.-]+)\}")
# <claude-opus-model-id>, <portkey-gateway-host-dev>, __REPLACE_ME__-style tokens.
PLACEHOLDER_RE = re.compile(r"<[a-z0-9][a-z0-9._-]*>|__[A-Z0-9_]+__")
SECRET_KEY = "secret_env"  # in manifests: {secret_env: NAME}
SECRET_MARKER = "$secret_env"  # in rendered objects: {"$secret_env": NAME}


class TemplateError(ValueError):
    pass


def lookup(context: dict, path: str) -> Any:
    cur: Any = context
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            raise TemplateError(f"undefined template variable ${{{path}}}")
        cur = cur[part]
    return cur


def substitute(value: Any, context: dict) -> Any:
    """Replace ${var} recursively. A string that is exactly "${var}" takes the variable's type."""
    if isinstance(value, dict):
        return {k: substitute(v, context) for k, v in value.items()}
    if isinstance(value, list):
        return [substitute(v, context) for v in value]
    if isinstance(value, str):
        whole = VAR_RE.fullmatch(value)
        if whole:
            return copy.deepcopy(lookup(context, whole.group(1)))
        return VAR_RE.sub(lambda m: str(lookup(context, m.group(1))), value)
    return value


def per_env(value: Any, env: str) -> Any:
    """{per_env: {env: v}, default: v} -> the value for env (recursively)."""
    if isinstance(value, dict):
        if "per_env" in value and set(value) <= {"per_env", "default"}:
            table = value["per_env"] or {}
            if env in table:
                return per_env(table[env], env)
            if "default" in value:
                return per_env(value["default"], env)
            raise TemplateError(f"no value for env {env!r} and no default in {value!r}")
        return {k: per_env(v, env) for k, v in value.items()}
    if isinstance(value, list):
        return [per_env(v, env) for v in value]
    return value


def secret_markers(value: Any) -> Any:
    """{secret_env: NAME} (manifest form) -> {"$secret_env": NAME} (rendered form)."""
    if isinstance(value, dict):
        if set(value) == {SECRET_KEY}:
            return {SECRET_MARKER: value[SECRET_KEY]}
        return {k: secret_markers(v) for k, v in value.items()}
    if isinstance(value, list):
        return [secret_markers(v) for v in value]
    return value


def is_secret(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == {SECRET_MARKER}


def find_placeholders(value: Any, path: str = "") -> list[tuple[str, str]]:
    """(json path, placeholder) for every unresolved placeholder in a rendered value."""
    out: list[tuple[str, str]] = []
    if isinstance(value, dict):
        if is_secret(value):
            return out
        for k, v in value.items():
            out += find_placeholders(v, f"{path}.{k}" if path else str(k))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            out += find_placeholders(v, f"{path}[{i}]")
    elif isinstance(value, str):
        out += [(path, m.group(0)) for m in PLACEHOLDER_RE.finditer(value)]
    return out


def mask_secrets(value: Any) -> Any:
    """Display form: secret markers become "<secret:NAME>" (the value is never resolved)."""
    if isinstance(value, dict):
        if is_secret(value):
            return f"<secret:{value[SECRET_MARKER]}>"
        return {k: mask_secrets(v) for k, v in value.items()}
    if isinstance(value, list):
        return [mask_secrets(v) for v in value]
    return value


def secret_names(value: Any) -> list[str]:
    if isinstance(value, dict):
        if is_secret(value):
            return [value[SECRET_MARKER]]
        return [n for v in value.values() for n in secret_names(v)]
    if isinstance(value, list):
        return [n for v in value for n in secret_names(v)]
    return []


def resolve_secrets(value: Any, environ: dict) -> Any:
    """Replace secret markers with environment values. Raises KeyError(name) when unset."""
    if isinstance(value, dict):
        if is_secret(value):
            name = value[SECRET_MARKER]
            secret = (environ.get(name) or "").strip()
            if not secret or PLACEHOLDER_RE.search(secret) or "REPLACE_ME" in secret.upper():
                raise KeyError(name)
            return secret
        return {k: resolve_secrets(v, environ) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_secrets(v, environ) for v in value]
    return value
