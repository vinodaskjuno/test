"""diff / apply: compare rendered objects with what the Portkey admin API returns and converge.

- Comparison is a *subset* diff: only fields the manifests declare are compared, so
  server-side fields (ids, timestamps, defaults) never show up as drift.
- Secret values are never compared, printed or diffed (``{"$secret_env": NAME}`` markers and
  create-only fields such as an integration's provider key are skipped).
- ``apply`` is a dry run unless ``yes=True``; it creates missing objects, updates drifted ones,
  leaves equal ones alone (idempotent), and deletes only with ``prune=True`` and only objects
  whose identity matches ``gateway.yaml`` ``prune.managed_patterns``.
"""

from __future__ import annotations

import copy
import json
import os
import re
from dataclasses import dataclass, field
from typing import Any

from .admin import AdminClient, AdminError
from .endpoints import Endpoint
from .render import KINDS, Rendered
from .template import is_secret, mask_secrets, resolve_secrets, secret_names

_ABSENT = "<absent>"


@dataclass
class Change:
    path: str
    old: Any
    new: Any

    def as_dict(self) -> dict:
        return {"path": self.path, "from": self.old, "to": self.new}


@dataclass
class Item:
    kind: str
    key: str  # display identity, e.g. "pc-aig-router@aig-claims"
    action: str  # create | update | noop | delete | blocked
    desired: dict | None = None
    remote_id: str | None = None
    changes: list[Change] = field(default_factory=list)
    reason: str = ""
    result: str = ""  # after apply: written | skipped | failed: ...

    def as_dict(self) -> dict:
        out: dict[str, Any] = {"kind": self.kind, "id": self.key, "action": self.action}
        if self.changes:
            out["changes"] = [c.as_dict() for c in self.changes]
        if self.reason:
            out["reason"] = self.reason
        if self.result:
            out["result"] = self.result
        return out


@dataclass
class Plan:
    env: str
    items: list[Item] = field(default_factory=list)

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for i in self.items:
            out[i.action] = out.get(i.action, 0) + 1
        return out

    @property
    def has_changes(self) -> bool:
        return any(i.action in ("create", "update", "delete") for i in self.items)

    def as_dict(self) -> dict:
        return {"env": self.env, "summary": self.counts(), "items": [i.as_dict() for i in self.items]}


def _normalize_remote(ep: Endpoint, remote: dict) -> dict:
    remote = dict(remote)
    for f in ep.json_string_fields:
        if isinstance(remote.get(f), str):
            try:
                remote[f] = json.loads(remote[f])
            except ValueError:
                pass
    return remote


def subset_diff(desired: Any, remote: Any, path: str = "") -> list[Change]:
    if is_secret(desired):
        return []
    if isinstance(desired, dict):
        if not isinstance(remote, dict):
            return [Change(path or "<root>", remote, mask_secrets(desired))]
        out: list[Change] = []
        for k, v in desired.items():
            sub = f"{path}.{k}" if path else k
            if k not in remote:
                if not is_secret(v):
                    out.append(Change(sub, _ABSENT, mask_secrets(v)))
                continue
            out += subset_diff(v, remote[k], sub)
        return out
    if isinstance(desired, list):
        if not isinstance(remote, list) or len(remote) != len(desired):
            return [Change(path, remote, mask_secrets(desired))]
        out = []
        for i, (d, r) in enumerate(zip(desired, remote)):
            out += subset_diff(d, r, f"{path}[{i}]")
        return out
    if desired != remote:
        return [Change(path, remote, desired)]
    return []


def _identity(ep: Endpoint, obj: dict) -> tuple:
    return tuple(obj.get(f) for f in ep.identity)


def _display(ident: tuple) -> str:
    return "@".join(str(p) for p in ident if p is not None)


def _remote_id(ep: Endpoint, remote: dict) -> str | None:
    for f in ep.remote_id:
        if remote.get(f):
            return str(remote[f])
    return None


def build_plan(rendered: Rendered, remote: dict[str, list[dict]], endpoints: dict[str, Endpoint], *,
               prune: bool = False, managed_patterns: list[str] | None = None,
               environ: dict | None = None, kinds: list[str] | None = None) -> Plan:
    environ = os.environ if environ is None else environ
    plan = Plan(env=rendered.env)
    patterns = [re.compile(p) for p in managed_patterns or []]
    selected = [k for k in KINDS if not kinds or k in kinds]
    for kind in selected:
        ep = endpoints[kind]
        remotes = [_normalize_remote(ep, r) for r in remote.get(kind, [])]
        by_id = {_identity(ep, r): r for r in remotes}
        desired_ids = set()
        for obj in rendered.objects.get(kind, []):
            ident = _identity(ep, obj)
            desired_ids.add(ident)
            key = _display(ident)
            missing = [n for n in secret_names(obj) if not (environ.get(n) or "").strip()]
            current = by_id.get(ident)
            if current is None:
                item = Item(kind, key, "create", desired=obj)
                if missing:
                    item.action, item.reason = "blocked", (
                        f"needs secret env {', '.join(sorted(set(missing)))} to create; "
                        "set it or create the object in the Portkey UI")
                plan.items.append(item)
                continue
            comparable = {k: v for k, v in obj.items() if k not in ep.create_only}
            changes = subset_diff(comparable, current)
            update_missing = [n for n in secret_names(comparable) if n in missing]
            if changes and update_missing:
                plan.items.append(Item(kind, key, "blocked", desired=obj, remote_id=_remote_id(ep, current),
                                       changes=changes, reason=f"needs secret env {', '.join(update_missing)} to update"))
            else:
                plan.items.append(Item(kind, key, "update" if changes else "noop", desired=obj,
                                       remote_id=_remote_id(ep, current), changes=changes))
        if prune:
            for ident, r in by_id.items():
                if ident in desired_ids:
                    continue
                name = str(ident[0] or "")
                if any(p.search(name) for p in patterns):
                    plan.items.append(Item(kind, _display(ident), "delete", remote_id=_remote_id(ep, r)))
    if prune:  # delete dependents first
        deletes = [i for i in plan.items if i.action == "delete"]
        others = [i for i in plan.items if i.action != "delete"]
        deletes.sort(key=lambda i: -KINDS.index(i.kind))
        plan.items = others + deletes
    return plan


def fetch_remote(client: AdminClient, endpoints: dict[str, Endpoint], kinds: list[str] | None = None) -> dict:
    return {k: client.list(endpoints[k]) for k in KINDS if not kinds or k in kinds}


def apply_plan(plan: Plan, client: AdminClient, endpoints: dict[str, Endpoint], *, yes: bool,
               environ: dict | None = None) -> bool:
    """Execute the plan when yes=True (otherwise mark everything skipped). Returns success."""
    environ = os.environ if environ is None else environ
    ok = True
    for item in plan.items:
        if item.action == "noop":
            continue
        if item.action == "blocked":
            ok = False
            item.result = "skipped (blocked)"
            continue
        if not yes:
            item.result = "dry-run"
            continue
        ep = endpoints[item.kind]
        try:
            if item.action == "delete":
                client.delete(ep, item.remote_id or "")
            else:
                body = copy.deepcopy(item.desired or {})
                if item.action == "update":
                    body = {k: v for k, v in body.items() if k not in ep.create_only}
                names = secret_names(body)
                body = resolve_secrets(body, environ)
                client.add_redaction([environ.get(n, "") for n in names])
                if item.action == "create":
                    client.create(ep, body)
                else:
                    client.update(ep, item.remote_id or "", body)
            item.result = "written"
        except KeyError as exc:  # secret disappeared between plan and apply
            ok = False
            item.result = f"failed: secret env {exc.args[0]} not set"
        except AdminError as exc:
            ok = False
            item.result = f"failed: {exc}"
    return ok


def format_plan(plan: Plan, *, applied: bool = False) -> str:
    sym = {"create": "+", "update": "~", "delete": "-", "noop": "=", "blocked": "!"}
    lines = [f"Portkey plan for env={plan.env}"]
    for i in plan.items:
        if i.action == "noop":
            continue
        line = f"  {sym[i.action]} {i.kind}/{i.key} ({i.action})"
        if i.reason:
            line += f": {i.reason}"
        if i.result:
            line += f" -> {i.result}"
        lines.append(line)
        for c in i.changes:
            lines.append(f"      {c.path}: {json.dumps(c.old, default=str)} -> {json.dumps(c.new, default=str)}")
    counts = plan.counts()
    lines.append("Summary: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())) if counts else "Summary: nothing declared")
    if not plan.has_changes:
        lines.append("No changes: Portkey matches the manifests.")
    return "\n".join(lines)
