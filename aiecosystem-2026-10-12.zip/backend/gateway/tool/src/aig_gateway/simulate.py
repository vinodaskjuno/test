"""Offline simulation of what the gateway does with one request, in Portkey's order:

1. required metadata (workspace setting) -> reject (HTTP 400) when missing or invalid;
2. input guardrails of the config, in order. Webhook checks (``default.webhook``) are really
   called over HTTP with Portkey's webhook payload; other checks are not simulated.
   A failed check denies (HTTP 446) when the guardrail's action is deny, is only logged when
   the guardrail is async (log mode). ``failOnError`` turns webhook errors into failures;
3. conditional routing (routing.resolve) and the workspace model allow-list.

Also: the MCP gateway registry decision (registered + workspace + IAM role, else refused).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Callable

import httpx
from jsonschema import Draft202012Validator

from .render import Rendered
from .routing import Resolution, resolve
from .template import is_secret, resolve_secrets

WebhookCaller = Callable[[str, dict, dict, float], dict]


@dataclass
class GuardrailResult:
    slug: str
    check: str
    verdict: bool | None  # None = not simulated
    action: str  # deny | log | redact
    detail: dict = field(default_factory=dict)


@dataclass
class Outcome:
    allowed: bool
    status: int  # HTTP status the caller would see (200 = forwarded to a model)
    stage: str  # required_metadata | guardrail | allow_list | routed
    reason: str = ""
    resolution: Resolution | None = None
    guardrails: list[GuardrailResult] = field(default_factory=list)


def http_webhook_caller(url: str, headers: dict, payload: dict, timeout: float) -> dict:
    r = httpx.post(url, json=payload, headers=headers, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, dict) or not isinstance(data.get("verdict"), bool):
        raise ValueError("webhook answer must be {'verdict': bool, ...}")
    return data


def webhook_payload(metadata: dict, body: dict, provider: str | None) -> dict:
    """Portkey's webhook guardrail request body (beforeRequestHook)."""
    return {
        "request": {"json": body, "text": "", "isStreamingRequest": bool(body.get("stream")), "isTransformed": False},
        "response": {},
        "provider": provider or "",
        "requestType": "chatComplete",
        "metadata": metadata,
        "eventType": "beforeRequestHook",
    }


def _action(g: dict) -> str:
    actions = g.get("actions") or {}
    if actions.get("async"):
        return "log"
    return "deny" if actions.get("deny") else "redact"


def simulate(rendered: Rendered, *, workspace: str, metadata: dict, body: dict | None = None,
             config_slug: str = "pc-aig-router", webhook: WebhookCaller | None = None,
             environ: dict | None = None) -> Outcome:
    environ = os.environ if environ is None else environ
    body = body or {"model": "auto", "messages": [{"role": "user", "content": "hello"}]}
    webhook = webhook or http_webhook_caller
    ws = rendered.find("workspaces", slug=workspace)
    if ws is None:
        raise KeyError(f"workspace {workspace} not rendered")
    schema = ws["settings"]["required_metadata"]["schema"]
    errors = sorted(Draft202012Validator(schema).iter_errors(metadata or {}), key=lambda e: e.json_path)
    if errors:
        return Outcome(False, 400, "required_metadata", "; ".join(e.message for e in errors))

    config = rendered.config(config_slug, workspace)
    resolution = resolve(config, metadata, body)
    provider = None
    chain = resolution.plan.chain()
    if chain:
        it = rendered.find("integrations", slug=chain[0].virtual_key)
        provider = it["ai_provider_id"] if it else None

    results: list[GuardrailResult] = []
    for slug in config.get("input_guardrails", []):
        g = rendered.find("guardrails", slug=slug)
        action = _action(g)
        failed = False
        for check in g["checks"]:
            if check["id"] != "default.webhook":
                results.append(GuardrailResult(slug, check["id"], None, action))
                continue
            p = check["parameters"]
            headers = {k: v for k, v in (p.get("headers") or {}).items()}
            try:
                headers = resolve_secrets(headers, environ)
            except KeyError:
                headers = {k: v for k, v in headers.items() if not is_secret(v)}
            try:
                answer = webhook(p["webhookURL"], headers, webhook_payload(metadata, body, provider),
                                 float(p.get("timeout", 3000)) / 1000)
                verdict, detail = bool(answer["verdict"]), dict(answer.get("data") or {})
            except Exception as exc:
                verdict = not p.get("failOnError", False)
                detail = {"reason": "webhook_error", "error": type(exc).__name__}
            results.append(GuardrailResult(slug, check["id"], verdict, action, detail))
            failed = failed or not verdict
        if failed and action == "deny":
            reason = next((r.detail.get("reason", "") for r in results if r.slug == slug and r.verdict is False), "")
            return Outcome(False, 446, "guardrail", f"{slug}: {reason}", resolution, results)

    allowed = set(ws["settings"]["allowed_models"])
    for leaf in chain:
        if leaf.model not in allowed:
            return Outcome(False, 403, "allow_list", f"model {leaf.model} not allowed in {workspace}", resolution, results)
    return Outcome(True, 200, "routed", "", resolution, results)


def mcp_access(rendered: Rendered, *, server: str, workspace: str, iam_role_arn: str) -> tuple[bool, str]:
    """MCP gateway decision: unregistered servers are refused; otherwise workspace + role must match."""
    s = rendered.find("mcp_servers", slug=server)
    if s is None:
        return False, "unregistered_server"
    if workspace not in s["workspace_ids"]:
        return False, "workspace_not_allowed"
    if iam_role_arn not in s["access"]["iam_role_arns"]:
        return False, "role_not_allowed"
    return True, "allowed"


def matrix(rendered: Rendered, workspace: str = "aig-platform", config_slug: str = "pc-aig-router") -> list[dict[str, Any]]:
    """Routing table for every tier x job_profile (routing only, no guardrails)."""
    req = rendered.find("workspaces", slug=workspace)["settings"]["required_metadata"]["schema"]["properties"]
    config = rendered.config(config_slug, workspace)
    rows = []
    for tier in req["user_tier"]["enum"]:
        for job in req["job_profile"]["enum"]:
            res = resolve(config, {"user_tier": tier, "job_profile": job})
            rows.append({
                "user_tier": tier, "job_profile": job,
                "rule": res.rule_index + 1 if res.rule_index is not None else "default",
                "target": res.target, "mode": res.mode, "models": res.plan.models(),
                "shares": res.plan.shares(),
            })
    return rows
