"""Thin Portkey admin API client. The admin key is held privately and redacted from errors."""

from __future__ import annotations

import os
from typing import Any

import httpx

from .endpoints import Endpoint

ADMIN_URL_ENV = "AIG_PORTKEY_ADMIN_URL"
ADMIN_KEY_ENV = "AIG_PORTKEY_ADMIN_API_KEY"
AUTH_HEADER = "x-portkey-api-key"


class AdminError(RuntimeError):
    pass


def _is_placeholder(v: str) -> bool:
    return not v or "__" in v or "<" in v or "REPLACE_ME" in v.upper()


class AdminClient:
    def __init__(self, base_url: str, api_key: str, *, timeout: float = 30.0,
                 transport: httpx.BaseTransport | None = None, redact: list[str] | None = None):
        if _is_placeholder(base_url):
            raise AdminError(f"{ADMIN_URL_ENV} is missing or a placeholder")
        if _is_placeholder(api_key):
            raise AdminError(f"{ADMIN_KEY_ENV} is missing or a placeholder")
        self._key = api_key
        self._redact = [api_key, *(redact or [])]
        self._http = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={AUTH_HEADER: api_key, "content-type": "application/json", "accept": "application/json"},
            timeout=timeout,
            transport=transport,
        )

    @classmethod
    def from_env(cls, environ: dict | None = None, **kw) -> "AdminClient":
        environ = os.environ if environ is None else environ
        return cls(environ.get(ADMIN_URL_ENV, "").strip(), environ.get(ADMIN_KEY_ENV, "").strip(), **kw)

    def add_redaction(self, values: list[str]) -> None:
        self._redact += [v for v in values if v]

    def __repr__(self) -> str:
        return f"AdminClient(base_url={str(self._http.base_url)!r})"

    def close(self) -> None:
        self._http.close()

    def _scrub(self, text: str) -> str:
        for s in self._redact:
            if s:
                text = text.replace(s, "***")
        return text

    def _call(self, method: str, path: str, body: Any = None) -> Any:
        try:
            r = self._http.request(method, path, json=body)
        except httpx.HTTPError as exc:
            raise AdminError(f"{method} {path}: {type(exc).__name__}") from None
        if r.status_code >= 400:
            raise AdminError(f"{method} {path}: HTTP {r.status_code}: {self._scrub(r.text[:500])}")
        if not r.content:
            return None
        try:
            return r.json()
        except ValueError:
            return None

    def list(self, ep: Endpoint) -> list[dict]:
        data = self._call("GET", ep.list)
        if isinstance(data, dict):
            data = data.get(ep.data_key, [])
        return [d for d in (data or []) if isinstance(d, dict)]

    def create(self, ep: Endpoint, body: dict) -> Any:
        return self._call("POST", ep.create.format(**{k: v for k, v in body.items() if isinstance(v, str)}), body)

    def update(self, ep: Endpoint, remote_id: str, body: dict) -> Any:
        return self._call("PUT", ep.update.format(id=remote_id), body)

    def delete(self, ep: Endpoint, remote_id: str) -> Any:
        return self._call("DELETE", ep.delete.format(id=remote_id))
