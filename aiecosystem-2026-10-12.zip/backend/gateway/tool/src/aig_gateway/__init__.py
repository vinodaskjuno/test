"""aig-gateway: Portkey gateway-as-code for the AIG AI Ecosystem (CLI: aigw)."""

__version__ = "0.1.0"
