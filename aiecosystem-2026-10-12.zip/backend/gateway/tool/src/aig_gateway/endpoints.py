"""Portkey admin API endpoint paths: the ONE place to adjust for AIG's self-hosted version.

UNVERIFIED against AIG's self-hosted Portkey. The defaults follow Portkey's public admin API
as documented in 2026; confirm each path, the identity field and the update key with AIG's
Portkey team before the first real `aigw apply --yes`. Overrides without code changes:
set ``AIG_PORTKEY_ENDPOINTS_FILE`` to a YAML file such as

    integrations: {list: /virtual-keys, create: /virtual-keys, update: /virtual-keys/{id}, delete: /virtual-keys/{id}}
    workspaces: {list: /workspaces}

(only the keys you name are replaced).

Assumptions encoded here:
- Auth header ``x-portkey-api-key: <admin key>`` on every call.
- ``GET list`` returns ``{"data": [...]}`` (or a bare list) of every object the admin key can
  see; no pagination beyond the first page is needed for AIG's object counts.
- Objects keep the client-chosen ``slug`` (workspaces, integrations, guardrails, configs, MCP
  servers), so configs can reference ``anthropic-prod`` / ``aig-agent-check`` literally.
- Configs are workspace-scoped, so the same slug ``pc-aig-router`` exists once per workspace.
- ``PUT {update}`` takes the same body as create (minus create-only fields).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from pathlib import Path

import yaml


@dataclass(frozen=True)
class Endpoint:
    list: str
    create: str
    update: str
    delete: str
    identity: tuple[str, ...]  # fields that identify an object (desired <-> remote)
    remote_id: tuple[str, ...] = ("id",)  # remote field(s) used for {id}, first present wins
    create_only: tuple[str, ...] = ()  # sent on create, never on update, never diffed
    data_key: str = "data"
    json_string_fields: tuple[str, ...] = field(default_factory=tuple)  # remote returns JSON as a string


DEFAULT_ENDPOINTS: dict[str, Endpoint] = {
    "workspaces": Endpoint(
        list="/admin/workspaces", create="/admin/workspaces", update="/admin/workspaces/{id}",
        delete="/admin/workspaces/{id}", identity=("slug",), remote_id=("id", "slug"),
    ),
    # Newer Portkey: /integrations. Older deployments: /virtual-keys (override via the file).
    "integrations": Endpoint(
        list="/integrations", create="/integrations", update="/integrations/{id}",
        delete="/integrations/{id}", identity=("slug",), remote_id=("slug", "id"), create_only=("key",),
    ),
    "guardrails": Endpoint(
        list="/guardrails", create="/guardrails", update="/guardrails/{id}", delete="/guardrails/{id}",
        identity=("slug",), remote_id=("slug", "id"),
    ),
    "mcp_servers": Endpoint(
        list="/mcp-servers", create="/mcp-servers", update="/mcp-servers/{id}", delete="/mcp-servers/{id}",
        identity=("slug",), remote_id=("slug", "id"),
    ),
    "configs": Endpoint(
        list="/configs", create="/configs", update="/configs/{id}", delete="/configs/{id}",
        identity=("slug", "workspace_id"), remote_id=("id", "slug"), json_string_fields=("config",),
    ),
    # Portkey creates keys at /api-keys/{type}/{sub-type}; the key value is returned once and
    # never printed by aigw.
    "api_keys": Endpoint(
        list="/api-keys", create="/api-keys/{type}/{sub_type}", update="/api-keys/{id}",
        delete="/api-keys/{id}", identity=("name", "workspace_id"), remote_id=("id",),
        create_only=("type", "sub_type"),
    ),
    "usage_limits": Endpoint(
        list="/usage-limits", create="/usage-limits", update="/usage-limits/{id}",
        delete="/usage-limits/{id}", identity=("name",),
    ),
    "rate_limits": Endpoint(
        list="/rate-limits", create="/rate-limits", update="/rate-limits/{id}",
        delete="/rate-limits/{id}", identity=("name",),
    ),
}


def load_endpoints(path: str | os.PathLike | None = None) -> dict[str, Endpoint]:
    path = path or os.environ.get("AIG_PORTKEY_ENDPOINTS_FILE")
    endpoints = dict(DEFAULT_ENDPOINTS)
    if not path:
        return endpoints
    overrides = yaml.safe_load(Path(path).read_text()) or {}
    for kind, values in overrides.items():
        if kind not in endpoints:
            raise ValueError(f"{path}: unknown kind {kind!r}")
        values = {k: tuple(v) if isinstance(v, list) else v for k, v in (values or {}).items()}
        endpoints[kind] = replace(endpoints[kind], **values)
    return endpoints
