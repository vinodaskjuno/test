"""Phase 7: model canary / promote / rollback as deterministic manifest edits, and sandbox isolation."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
import yaml

from aig_gateway import cli
from aig_gateway.canary import (
    CanaryError,
    canary_promote,
    canary_rollback,
    canary_set,
    canary_sync,
    desired_from_models,
    fetch_models,
    model_alias,
    provider_model_id,
)
from aig_gateway.loader import load_repo
from aig_gateway.render import render
from aig_gateway.simulate import matrix, simulate
from aig_gateway.validate import validate

from conftest import copy_root, edit_manifest, fill_env

CANDIDATE = "claude-opus-next-2026-10"


@pytest.fixture
def root(tmp_path):
    r = copy_root(tmp_path)
    for env in ("local", "dev", "stage", "prod"):
        fill_env(r, env)
    return r


def rows(root, env="prod", workspace="aig-platform"):
    return {(x["user_tier"], x["job_profile"]): x for x in matrix(render(load_repo(root), env), workspace)}


def base_rows(root):
    return rows(root)


def set_premium(root, share=10):
    return canary_set(load_repo(root), tier="premium", alias="claude-opus-next", share=share, model_id=CANDIDATE,
                      provider="anthropic", platform_model_id="m-1")


# --- naming shared with platform-api ---------------------------------------------------------------


def test_alias_and_model_id_derivation():
    assert provider_model_id("claude-sonnet-5", "20261001") == "claude-sonnet-5-20261001"
    assert provider_model_id("gpt-4o-2024-08-06", "2024-08-06") == "gpt-4o-2024-08-06"
    assert provider_model_id("claude-x", "latest") == "claude-x"
    assert model_alias("Claude Sonnet 5", "2026.10") == "claude-sonnet-5-2026-10"
    assert len(model_alias("x" * 80, "v1")) <= 63


# --- canary set ------------------------------------------------------------------------------------


def test_canary_set_adds_weighted_target_for_the_tier_only(root):
    before = base_rows(root)
    changed, msg = set_premium(root)
    assert changed and "10%" in msg
    assert validate(load_repo(root)).ok
    after = rows(root)
    for jp in ("underwriting", "claims", "operations", "general"):
        r = after[("premium", jp)]
        assert r["target"] == "canary-premium-opus" and r["mode"] == "loadbalance" and r["rule"] == 1
        assert r["shares"] == [0.9, 0.1]
        assert r["models"] == ["claude-opus-test", "claude-sonnet-test", CANDIDATE]
    for key, r in before.items():  # standard and free untouched
        if key[0] != "premium":
            assert {k: v for k, v in after[key].items() if k != "rule"} == {k: v for k, v in r.items() if k != "rule"}
    r = render(load_repo(root), "prod")
    for ws in ("aig-underwriting", "aig-claims", "aig-operations", "aig-platform"):
        assert CANDIDATE in r.find("workspaces", slug=ws)["settings"]["allowed_models"]
    assert CANDIDATE not in r.find("workspaces", slug="model-sandbox")["settings"]["allowed_models"]
    assert CANDIDATE in r.find("integrations", slug="anthropic-prod")["allowed_models"]
    entry = yaml.safe_load((root / "manifests" / "canaries.yaml").read_text())["spec"]["canaries"][0]
    assert entry["incumbent"] == ["opus"] and entry["platform_model_id"] == "m-1"


def test_canary_set_is_idempotent_and_updates_share(root):
    set_premium(root)
    first = (root / "manifests" / "canaries.yaml").read_bytes()
    changed, msg = set_premium(root)
    assert not changed and "unchanged" in msg
    assert (root / "manifests" / "canaries.yaml").read_bytes() == first
    changed, _ = set_premium(root, share=25)
    assert changed and rows(root)[("premium", "claims")]["shares"] == [0.75, 0.25]


def test_free_tier_canary_keeps_per_job_profile_incumbents(root):
    canary_set(load_repo(root), tier="free", alias="gpt-next", share=20, model_id="gpt-next-1", provider="openai")
    after = rows(root)
    for jp in ("underwriting", "claims"):
        r = after[("free", jp)]
        assert r["target"] == "canary-free-sonnet" and r["shares"] == [0.8, 0.2]
        assert r["models"] == ["claude-sonnet-test", "gpt-test", "gpt-next-1"]
    for jp in ("operations", "general"):
        r = after[("free", jp)]
        assert r["target"] == "canary-free-openai" and r["models"] == ["gpt-test", "gpt-test", "gpt-next-1"]
    assert after[("standard", "claims")]["target"] == "sonnet"
    cfg = render(load_repo(root), "prod").config(workspace="aig-claims")
    leaf = cfg["targets"][-1]["targets"][-1]
    assert leaf["custom_host"].endswith("/openai-a/v1") and leaf["virtual_key"] == "openai-prod"


@pytest.mark.parametrize("kwargs,needle", [
    ({"share": 0}, "> 0 and < 100"),
    ({"share": 100}, "> 0 and < 100"),
    ({"tier": "gold"}, "unknown tier"),
    ({"integration": "anthropic-sandbox", "provider": None}, "sandbox integration"),
    ({"model_id": None}, "--model-id"),
    ({"provider": "mistral"}, "no production integration"),
])
def test_canary_set_refusals(root, kwargs, needle):
    args = {"tier": "premium", "alias": "claude-opus-next", "share": 10, "model_id": CANDIDATE, "provider": "anthropic"}
    args.update(kwargs)
    with pytest.raises(CanaryError, match=needle):
        canary_set(load_repo(root), **args)
    assert yaml.safe_load((root / "manifests" / "canaries.yaml").read_text())["spec"]["canaries"] == []


def test_sandbox_alias_can_never_be_a_canary(root):
    with pytest.raises(CanaryError, match="sandbox integration"):
        canary_set(load_repo(root), tier="premium", alias="sandbox-claude-candidate", share=10)


def test_second_model_on_a_tier_needs_rollback_first(root):
    set_premium(root)
    with pytest.raises(CanaryError, match="roll it back first"):
        canary_set(load_repo(root), tier="premium", alias="other-model", share=10, model_id="o-1", provider="anthropic")


# --- promote / rollback ----------------------------------------------------------------------------


def test_promote_makes_the_candidate_the_tier_target(root):
    set_premium(root)
    changed, _ = canary_promote(load_repo(root), tier="premium", alias="claude-opus-next")
    assert changed and validate(load_repo(root)).ok
    for jp in ("underwriting", "general"):
        r = rows(root)[("premium", jp)]
        assert r["target"] == "promoted-premium-opus" and r["mode"] == "fallback"
        assert r["models"][0] == CANDIDATE and r["models"][1:] == ["claude-opus-test", "claude-sonnet-test"]
    assert not canary_promote(load_repo(root), tier="premium", alias="claude-opus-next")[0]  # idempotent
    with pytest.raises(CanaryError, match="already promoted"):
        set_premium(root)


def test_promote_needs_a_running_canary(root):
    with pytest.raises(CanaryError, match="promote needs a running canary"):
        canary_promote(load_repo(root), tier="premium", alias="claude-opus-next")


@pytest.mark.parametrize("promote_first", [False, True])
def test_rollback_is_one_step_back_to_the_base_routing(root, promote_first):
    before = base_rows(root)
    base_cfg = render(load_repo(root), "prod").config(workspace="aig-platform")
    set_premium(root)
    if promote_first:
        canary_promote(load_repo(root), tier="premium", alias="claude-opus-next")
    changed, msg = canary_rollback(load_repo(root), tier="premium")
    assert changed and "rolled back" in msg
    assert rows(root) == before
    assert render(load_repo(root), "prod").config(workspace="aig-platform") == base_cfg
    assert CANDIDATE not in render(load_repo(root), "prod").find("workspaces", slug="aig-claims")["settings"]["allowed_models"]
    changed, msg = canary_rollback(load_repo(root), tier="premium")
    assert not changed and "no canary" in msg


# --- --from-platform-api ---------------------------------------------------------------------------

MODELS = [
    {"id": "m-1", "name": "claude-opus-next", "provider": "anthropic", "version": "2026-10", "status": "canary",
     "tiers": ["premium"], "canary_share": 5},
    {"id": "m-2", "name": "bad-model", "provider": "anthropic", "version": "1", "status": "rejected", "tiers": ["standard"]},
    {"id": "m-3", "name": "gpt-next", "provider": "openai", "version": "1", "status": "promoted", "tiers": ["free"],
     "decided_at": "2026-10-01T00:00:00+00:00"},
    {"id": "m-4", "name": "waiting", "provider": "openai", "version": "1", "status": "approved", "tiers": ["standard"]},
    {"id": "m-5", "name": "gone", "provider": "openai", "version": "1", "status": "rolled_back", "tiers": ["standard"]},
]


def test_desired_state_from_platform_api_lifecycle(root):
    before = base_rows(root)
    entries = desired_from_models(load_repo(root), MODELS)
    assert [(e["tier"], e["state"], e["model"]["alias"], e["share"]) for e in entries] == [
        ("premium", "canary", "claude-opus-next-2026-10", 5), ("free", "promoted", "gpt-next-1", 100)]
    changed, msg = canary_sync(load_repo(root), MODELS)
    assert changed and "premium=canary" in msg
    assert not canary_sync(load_repo(root), MODELS)[0]  # idempotent
    r = rows(root)
    assert r[("premium", "claims")]["shares"] == [0.95, 0.05]
    assert r[("standard", "claims")]["target"] == "sonnet"  # rejected / approved / rolled back: no route
    assert r[("free", "general")]["models"][0] == "gpt-next-1"
    assert validate(load_repo(root)).ok
    # The canary is rolled back in platform-api: the next sync removes it.
    canary_sync(load_repo(root), [{**MODELS[0], "status": "rolled_back"}])
    assert {k: v for k, v in rows(root).items() if k[0] == "premium"} == {k: v for k, v in before.items() if k[0] == "premium"}


def test_platform_api_conflicts_are_refused(root):
    two = [MODELS[0], {**MODELS[0], "id": "m-9", "name": "another"}]
    with pytest.raises(CanaryError, match="two canaries"):
        desired_from_models(load_repo(root), two)
    mixed = [MODELS[2], {**MODELS[0], "tiers": ["free"]}]
    with pytest.raises(CanaryError, match="fold the promoted model"):
        desired_from_models(load_repo(root), mixed)


def test_fetch_models_uses_the_service_token():
    with respx.mock() as router:
        route = router.get("https://platform.test/api/v1/models").mock(
            return_value=httpx.Response(200, json={"items": MODELS, "total": len(MODELS)}))
        items = fetch_models("https://platform.test", "svc-token")
    assert len(items) == 5 and route.calls[0].request.headers["x-aig-service-token"] == "svc-token"
    with pytest.raises(CanaryError, match="AIG_PLATFORM_SERVICE_TOKEN"):
        fetch_models("https://platform.test", "")
    with pytest.raises(CanaryError, match="URL not configured"):
        fetch_models("https://<platform-api-host-dev>", "t")
    with respx.mock() as router:
        router.get("https://platform.test/api/v1/models").mock(return_value=httpx.Response(401))
        with pytest.raises(CanaryError, match="401"):
            fetch_models("https://platform.test", "svc-token")


# --- CLI -------------------------------------------------------------------------------------------


def run(capsys, root, *args):
    code = cli.main(["--root", str(root), *args])
    out = capsys.readouterr()
    return code, out.out, out.err


def test_cli_canary_journey_with_matrix(root, capsys):
    code, out, _ = run(capsys, root, "canary", "set", "--tier", "standard", "--model", "claude-sonnet-next",
                       "--share", "10", "--model-id", "claude-sonnet-next-1", "--provider", "anthropic")
    assert code == 0 and "canary claude-sonnet-next on tier standard at 10%" in out
    code, out, _ = run(capsys, root, "matrix", "--env", "prod", "--json")
    m = {(r["user_tier"], r["job_profile"]): r for r in json.loads(out)}
    assert m[("standard", "claims")]["shares"] == [0.9, 0.1] and m[("premium", "claims")]["target"] == "opus"
    code, out, _ = run(capsys, root, "canary", "show")
    assert json.loads(out)[0]["tier"] == "standard"
    code, out, _ = run(capsys, root, "canary", "promote", "--tier", "standard", "--model", "claude-sonnet-next")
    assert code == 0 and "promoted" in out
    code, out, _ = run(capsys, root, "route", "--env", "prod", "--tier", "standard", "--job-profile", "general")
    assert json.loads(out)["options"][0]["model"] == "claude-sonnet-next-1"
    code, out, _ = run(capsys, root, "canary", "rollback", "--tier", "standard")
    assert code == 0
    code, out, _ = run(capsys, root, "route", "--env", "prod", "--tier", "standard", "--job-profile", "general")
    assert json.loads(out)["target"] == "sonnet"
    code, _, err = run(capsys, root, "canary", "promote", "--tier", "standard", "--model", "x")
    assert code == 1 and "promote needs a running canary" in err


def test_cli_reverts_an_invalid_change(root, capsys, monkeypatch):
    from aig_gateway.validate import Report

    before = (root / "manifests" / "canaries.yaml").read_text()
    monkeypatch.setattr(cli, "validate", lambda *a, **k: Report(errors=["boom"]))
    code, _, err = run(capsys, root, "canary", "set", "--tier", "premium", "--model", "claude-opus-next",
                       "--share", "10", "--model-id", CANDIDATE, "--provider", "anthropic")
    assert code == 1 and "reverted" in err
    assert (root / "manifests" / "canaries.yaml").read_text() == before


def test_cli_sync_from_platform_api(root, capsys, monkeypatch):
    monkeypatch.setenv("AIG_PLATFORM_SERVICE_TOKEN", "svc")
    with respx.mock() as router:
        router.get("https://platform.test/api/v1/models").mock(return_value=httpx.Response(200, json={"items": MODELS}))
        code, out, _ = run(capsys, root, "canary", "sync", "--from-platform-api", "--platform-api-url", "https://platform.test")
    assert code == 0 and "free=promoted:gpt-next-1@100%" in out


# --- validate: canary + sandbox isolation rules ----------------------------------------------------


def _canary_entry(**over):
    e = {"tier": "premium", "state": "canary", "share": 10,
         "model": {"alias": "claude-opus-next", "integration": "anthropic-prod", "model": CANDIDATE}}
    e.update(over)
    return e


@pytest.mark.parametrize("mutate,needle", [
    (lambda r: edit_manifest(r, "canaries.yaml", lambda s: s["canaries"].append(
        _canary_entry(model={"alias": "x", "integration": "anthropic-sandbox", "model": "m"}))),
     "sandbox keys never get a production route"),
    (lambda r: edit_manifest(r, "canaries.yaml", lambda s: s["canaries"].append(
        _canary_entry(model={"alias": "sandbox-claude-candidate", "integration": "anthropic-prod", "model": "m"}))),
     "sandbox model alias"),
    (lambda r: edit_manifest(r, "canaries.yaml", lambda s: s["canaries"].extend([_canary_entry(), _canary_entry()])),
     "more than one entry"),
    (lambda r: edit_manifest(r, "canaries.yaml", lambda s: s["canaries"].append(_canary_entry(share=100))),
     "> 0 and < 100"),
    (lambda r: edit_manifest(r, "canaries.yaml", lambda s: s["canaries"].append(_canary_entry(state="promoted", share=50))),
     "100%"),
    (lambda r: edit_manifest(r, "canaries.yaml", lambda s: s.update(config="pc-aig-sandbox")),
     "sandbox config"),
    (lambda r: edit_manifest(r, "configs.yaml", lambda s: s["configs"][1]["workspaces"].append("aig-claims")),
     "sandbox configs may only be deployed to model-sandbox"),
    (lambda r: (r / "configs" / "pc-aig-sandbox.json").write_text(
        (r / "configs" / "pc-aig-sandbox.json").read_text().replace("${virtual_keys.anthropic_sandbox}", "${virtual_keys.anthropic}")),
     "production key anthropic-prod must never be used by the model sandbox"),
    (lambda r: (r / "configs" / "pc-aig-sandbox.json").write_text(
        (r / "configs" / "pc-aig-sandbox.json").read_text().replace('"aig-input-injection", ', "")),
     "guardrails on"),
    (lambda r: (r / "configs" / "pc-aig-router.json").write_text(
        (r / "configs" / "pc-aig-router.json").read_text().replace('"name": "openai",', '"name": "openai", "provider": "@openai-sandbox",')),
     "referenced by a non-sandbox workspace config"),
    (lambda r: (r / "configs" / "pc-aig-router.json").write_text(
        (r / "configs" / "pc-aig-router.json").read_text().replace('"cache": { "mode": "${caching.mode}", "max_age": "${caching.max_age}" },', "")),
     "need a cache block"),
])
def test_isolation_and_canary_violations(tmp_path, mutate, needle):
    root = copy_root(tmp_path)
    mutate(root)
    report = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert not report.ok
    assert any(needle in e for e in report.errors), report.errors


# --- the sandbox key cannot reach the production config (verification item 7) --------------------


def test_sandbox_key_cannot_reach_production_config(rendered):
    for env, r in rendered.items():
        keys = {k["name"]: k for k in r.objects["api_keys"]}
        sandbox_key = keys["aig-model-sandbox"]
        assert sandbox_key["workspace_id"] == "model-sandbox"
        assert sandbox_key["defaults"] == {"config_id": "pc-aig-sandbox"}
        in_sandbox = {c["slug"] for c in r.objects["configs"] if c["workspace_id"] == "model-sandbox"}
        assert in_sandbox == {"pc-aig-sandbox"}, env  # configs are workspace-scoped in Portkey
        with pytest.raises(KeyError):
            r.config("pc-aig-router", "model-sandbox")
        sandbox_slugs = {i["slug"] for i in r.objects["integrations"] if i["is_sandbox"]}
        for c in r.objects["configs"]:
            text = json.dumps(c["config"])
            if c["workspace_id"] != "model-sandbox":
                assert not any(s in text for s in sandbox_slugs), (env, c["slug"], c["workspace_id"])
        # Production keys (default pc-aig-router) never default to the sandbox config either.
        for k in r.objects["api_keys"]:
            if k["workspace_id"] != "model-sandbox":
                assert k.get("defaults", {}).get("config_id") != "pc-aig-sandbox"


def test_sandbox_config_routes_candidates_with_guardrails_on(rendered):
    r = rendered["stage"]
    meta = {"user_tier": "standard", "job_profile": "claims", "agent_id": "harness.model-eval", "team": "model-harness"}
    for slot, model, key in (("sandbox-claude-candidate", "claude-candidate-test", "anthropic-sandbox"),
                             ("sandbox-openai-candidate", "gpt-candidate-test", "openai-sandbox")):
        out = simulate(r, workspace="model-sandbox", config_slug="pc-aig-sandbox",
                       metadata={**meta, "candidate_model": slot}, webhook=lambda *a: {"verdict": True})
        assert out.allowed and out.status == 200
        leaf = out.resolution.plan.chain()[0]
        assert leaf.model == model and leaf.virtual_key == key
        assert list(dict.fromkeys(g.slug for g in out.guardrails)) == ["aig-input-pii", "aig-input-injection", "aig-input-policy"]
    cfg = r.config("pc-aig-sandbox", "model-sandbox")
    assert "cache" not in cfg and cfg["output_guardrails"] == ["aig-output-policy", "aig-output-pii"]
    # A production model cannot be called through the sandbox workspace (allow-list).
    out = simulate(r, workspace="model-sandbox", config_slug="pc-aig-sandbox", metadata=meta,
                   webhook=lambda *a: {"verdict": True})
    assert out.resolution.target == "sandbox-claude-candidate"
