"""diff / apply against a respx-mocked Portkey admin API."""

from __future__ import annotations

import copy
import json

import httpx
import pytest
import respx

from aig_gateway import cli
from aig_gateway.admin import AdminClient, AdminError
from aig_gateway.endpoints import DEFAULT_ENDPOINTS, load_endpoints
from aig_gateway.plan import apply_plan, build_plan, fetch_remote, format_plan
from aig_gateway.render import KINDS

ADMIN = "https://portkey-admin.test.example.com/v1"
ADMIN_KEY = "pk-admin-SUPERSECRET-0123456789"
WEBHOOK_SECRET = "whsec-SUPERSECRET-abcdef"
PROVIDER_KEYS = {
    "AIG_PROVIDER_KEY_ANTHROPIC_PROD": "sk-ant-SUPERSECRET-anthropic-prod",
    "AIG_PROVIDER_KEY_OPENAI_PROD": "sk-SUPERSECRET-openai-prod",
    "AIG_PROVIDER_KEY_ANTHROPIC_SANDBOX": "sk-ant-SUPERSECRET-anthropic-sandbox",
    "AIG_PROVIDER_KEY_OPENAI_SANDBOX": "sk-SUPERSECRET-openai-sandbox",
}
ALL_ENV = {"AIG_PORTKEY_WEBHOOK_SECRET": WEBHOOK_SECRET, **PROVIDER_KEYS}
SECRETS = [ADMIN_KEY, WEBHOOK_SECRET, *PROVIDER_KEYS.values()]
EP = DEFAULT_ENDPOINTS
PATTERNS = ["^aig-", "^pc-aig-", "^model-sandbox$", "^(anthropic|openai)-(prod|sandbox)$"]


class FakePortkey:
    """In-memory admin API: list/create/update/delete per kind, records every write."""

    def __init__(self, mock: respx.MockRouter, initial: dict[str, list[dict]] | None = None):
        self.store: dict[str, list[dict]] = {k: copy.deepcopy((initial or {}).get(k, [])) for k in KINDS}
        self.writes: list[tuple[str, str, dict | None]] = []
        self.auth: set[str | None] = set()
        self.next_id = 1
        for kind in KINDS:
            ep = EP[kind]
            base = ADMIN + ep.list
            mock.get(base).mock(side_effect=lambda req, k=kind: self._list(req, k))
            create = ADMIN + ep.create.split("{")[0].rstrip("/")
            mock.post(url__startswith=create).mock(side_effect=lambda req, k=kind: self._create(req, k))
            item = ADMIN + ep.update.replace("{id}", "")
            mock.put(url__startswith=item).mock(side_effect=lambda req, k=kind: self._update(req, k))
            mock.delete(url__startswith=item).mock(side_effect=lambda req, k=kind: self._delete(req, k))

    def _list(self, req, kind):
        self.auth.add(req.headers.get("x-portkey-api-key"))
        out = []
        for o in self.store[kind]:
            o = dict(o)
            o.pop("key", None)  # Portkey never returns provider keys
            if kind == "configs":
                o["config"] = json.dumps(o["config"])  # returned as a JSON string
            if kind == "guardrails":  # webhook header values masked by the server
                o = json.loads(json.dumps(o).replace(WEBHOOK_SECRET, "********"))
            out.append(o)
        return httpx.Response(200, json={"data": out, "total": len(out)})

    def _create(self, req, kind):
        self.auth.add(req.headers.get("x-portkey-api-key"))
        body = json.loads(req.content)
        self.writes.append(("POST", str(req.url), body))
        body = {**body, "id": f"id-{self.next_id}"}
        self.next_id += 1
        self.store[kind].append(body)
        resp = {"id": body["id"]}
        if kind == "api_keys":
            resp["key"] = "pk-live-SUPERSECRET-newkey"  # returned once on create
        return httpx.Response(200, json=resp)

    def _ident(self, kind, o):
        return o.get("id") or o.get("slug")

    def _update(self, req, kind):
        self.auth.add(req.headers.get("x-portkey-api-key"))
        rid = str(req.url).rsplit("/", 1)[-1]
        body = json.loads(req.content)
        self.writes.append(("PUT", str(req.url), body))
        for o in self.store[kind]:
            if rid in (o.get("id"), o.get("slug")):
                o.update(body)
                return httpx.Response(200, json={"success": True})
        return httpx.Response(404, json={"error": "not found"})

    def _delete(self, req, kind):
        self.auth.add(req.headers.get("x-portkey-api-key"))
        rid = str(req.url).rsplit("/", 1)[-1]
        self.writes.append(("DELETE", str(req.url), None))
        self.store[kind] = [o for o in self.store[kind] if rid not in (o.get("id"), o.get("slug"))]
        return httpx.Response(200, json={"success": True})


@pytest.fixture
def client():
    c = AdminClient(ADMIN, ADMIN_KEY)
    yield c
    c.close()


def plan_for(r, client, prune=False, environ=ALL_ENV):
    remote = fetch_remote(client, EP)
    return build_plan(r, remote, EP, prune=prune, managed_patterns=PATTERNS, environ=environ)


def test_empty_portkey_everything_created(rendered, client):
    r = rendered["dev"]
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        plan = plan_for(r, client)
        assert {i.action for i in plan.items} == {"create"}
        assert len(plan.items) == sum(len(v) for v in r.objects.values())
        assert apply_plan(plan, client, EP, yes=True, environ=ALL_ENV)
        assert all(i.result == "written" for i in plan.items)
        assert fake.auth == {ADMIN_KEY}  # admin key in x-portkey-api-key on every call
        # Apply order: workspaces before integrations before configs before keys.
        kinds_in_order = [w[1].split(ADMIN)[1].split("/")[1] for w in fake.writes]
        assert kinds_in_order.index("admin") < kinds_in_order.index("integrations") < kinds_in_order.index("configs")
        # Second run: idempotent, nothing to do.
        plan2 = plan_for(r, client)
        assert {i.action for i in plan2.items} == {"noop"}, [i.as_dict() for i in plan2.items if i.action != "noop"]
        before = len(fake.writes)
        assert apply_plan(plan2, client, EP, yes=True, environ=ALL_ENV)
        assert len(fake.writes) == before


def test_secrets_resolved_only_at_write_time(rendered, client):
    r = rendered["dev"]
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        apply_plan(plan_for(r, client), client, EP, yes=True, environ=ALL_ENV)
    bodies = {(w[1], json.dumps(w[2])) for w in fake.writes}
    integ = [json.loads(b) for u, b in bodies if "/integrations" in u]
    assert {i["slug"]: i["key"] for i in integ}["anthropic-prod"] == PROVIDER_KEYS["AIG_PROVIDER_KEY_ANTHROPIC_PROD"]
    guard = [json.loads(b) for u, b in bodies if "/guardrails" in u and "aig-agent-check" in b][0]
    assert guard["checks"][0]["parameters"]["headers"] == {"x-aig-webhook-secret": WEBHOOK_SECRET}
    keys = [w for w in fake.writes if "/api-keys/" in w[1]]
    assert {w[1].split("/api-keys/")[1] for w in keys} == {"workspace/service"}


def test_dry_run_writes_nothing(rendered, client, capsys):
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        plan = plan_for(rendered["dev"], client)
        assert apply_plan(plan, client, EP, yes=False, environ=ALL_ENV)
        assert fake.writes == []
        assert all(i.result == "dry-run" for i in plan.items)


def test_update_only_drifted_fields(rendered, client):
    r = rendered["prod"]
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        apply_plan(plan_for(r, client), client, EP, yes=True, environ=ALL_ENV)
        # Someone edits Portkey by hand: drift in a config and a rate limit.
        cfg = [o for o in fake.store["configs"] if o["workspace_id"] == "aig-claims"][0]
        cfg["config"]["strategy"]["default"] = "opus"
        rl = [o for o in fake.store["rate_limits"] if o["name"] == "aig-rate-team-aig-claims"][0]
        rl["value"] = 1
        rl["server_side_field"] = "ignored"
        fake.writes.clear()
        plan = plan_for(r, client)
        changed = {(i.kind, i.key): i for i in plan.items if i.action != "noop"}
        assert set(changed) == {("configs", "pc-aig-router@aig-claims"), ("rate_limits", "aig-rate-team-aig-claims")}
        cfg_item = changed[("configs", "pc-aig-router@aig-claims")]
        assert [(c.path, c.old, c.new) for c in cfg_item.changes] == [("config.strategy.default", "opus", "openai")]
        assert apply_plan(plan, client, EP, yes=True, environ=ALL_ENV)
        assert [w[0] for w in fake.writes] == ["PUT", "PUT"]
        assert all("key" not in (w[2] or {}) for w in fake.writes)
        assert {i.action for i in plan_for(r, client).items} == {"noop"}


def test_integration_key_never_sent_on_update(rendered, client):
    r = rendered["prod"]
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        apply_plan(plan_for(r, client), client, EP, yes=True, environ=ALL_ENV)
        [o for o in fake.store["integrations"] if o["slug"] == "openai-prod"][0]["name"] = "renamed"
        fake.writes.clear()
        plan = plan_for(r, client, environ={})  # no provider keys needed for an update
        item = [i for i in plan.items if i.kind == "integrations" and i.action != "noop"]
        assert len(item) == 1 and item[0].action == "update"
        apply_plan(plan, client, EP, yes=True, environ={"AIG_PORTKEY_WEBHOOK_SECRET": WEBHOOK_SECRET})
        put = [w for w in fake.writes if "/integrations/" in w[1]][0]
        assert "key" not in put[2] and put[1].endswith("/integrations/openai-prod")


def test_missing_provider_key_blocks_create_only(rendered, client):
    env = {k: v for k, v in ALL_ENV.items() if k != "AIG_PROVIDER_KEY_OPENAI_SANDBOX"}
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        plan = plan_for(rendered["dev"], client, environ=env)
        blocked = [i for i in plan.items if i.action == "blocked"]
        assert [(i.kind, i.key) for i in blocked] == [("integrations", "openai-sandbox")]
        assert "AIG_PROVIDER_KEY_OPENAI_SANDBOX" in blocked[0].reason
        assert not apply_plan(plan, client, EP, yes=True, environ=env)  # non-zero overall
        assert not any("openai-sandbox" in json.dumps(w[2]) for w in fake.writes if "/integrations" in w[1])
        assert len(fake.writes) == len(plan.items) - 1


def test_prune_deletes_only_managed_undeclared(rendered, client):
    extra = {
        "configs": [{"id": "c-old", "slug": "pc-aig-old", "workspace_id": "aig-claims", "config": {}},
                    {"id": "c-foreign", "slug": "pc-other-team", "workspace_id": "aig-claims", "config": {}}],
        "guardrails": [{"slug": "aig-retired", "name": "x", "checks": [], "actions": {}}],
        "workspaces": [{"id": "w9", "slug": "someone-elses"}],
    }
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock, extra)
        no_prune = plan_for(rendered["dev"], client)
        assert not [i for i in no_prune.items if i.action == "delete"]
        plan = plan_for(rendered["dev"], client, prune=True)
        deletes = [(i.kind, i.key) for i in plan.items if i.action == "delete"]
        assert deletes == [("configs", "pc-aig-old@aig-claims"), ("guardrails", "aig-retired")]  # dependents first
        apply_plan(plan, client, EP, yes=True, environ=ALL_ENV)
        dels = [w[1] for w in fake.writes if w[0] == "DELETE"]
        assert dels == [f"{ADMIN}/configs/c-old", f"{ADMIN}/guardrails/aig-retired"]
        assert any(o.get("slug") == "pc-other-team" for o in fake.store["configs"])
        assert any(o.get("slug") == "someone-elses" for o in fake.store["workspaces"])


def test_admin_errors_are_scrubbed(client):
    with respx.mock(assert_all_called=False) as mock:
        mock.get(ADMIN + "/configs").mock(return_value=httpx.Response(403, text=f"bad key {ADMIN_KEY}"))
        with pytest.raises(AdminError) as exc:
            client.list(EP["configs"])
    assert ADMIN_KEY not in str(exc.value) and "403" in str(exc.value)
    assert ADMIN_KEY not in repr(client)


@pytest.mark.parametrize("url,key", [("", ADMIN_KEY), (ADMIN, ""), ("https://__PORTKEY_ADMIN__/v1", ADMIN_KEY),
                                     (ADMIN, "__REPLACE_ME_ADMIN__")])
def test_admin_client_requires_real_config(url, key):
    with pytest.raises(AdminError):
        AdminClient(url, key)


def test_endpoint_override_file(tmp_path, monkeypatch):
    f = tmp_path / "endpoints.yaml"
    f.write_text("integrations:\n  list: /virtual-keys\n  create: /virtual-keys\n  update: '/virtual-keys/{id}'\n  delete: '/virtual-keys/{id}'\n")
    monkeypatch.setenv("AIG_PORTKEY_ENDPOINTS_FILE", str(f))
    eps = load_endpoints()
    assert eps["integrations"].list == "/virtual-keys" and eps["integrations"].create_only == ("key",)
    assert eps["configs"] == DEFAULT_ENDPOINTS["configs"]
    f.write_text("nonsense: {list: /x}\n")
    with pytest.raises(ValueError):
        load_endpoints()


# --- CLI end to end ---------------------------------------------------------------------


@pytest.fixture
def cli_env(monkeypatch, concrete_repo):
    monkeypatch.setenv("AIG_PORTKEY_ADMIN_URL", ADMIN)
    monkeypatch.setenv("AIG_PORTKEY_ADMIN_API_KEY", ADMIN_KEY)
    for k, v in ALL_ENV.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("AIG_PORTKEY_ENDPOINTS_FILE", raising=False)
    return ["--root", str(concrete_repo.root)]


def _assert_no_secrets(text):
    for s in SECRETS + ["pk-live-SUPERSECRET-newkey"]:
        assert s not in text
    assert "SUPERSECRET" not in text


def test_cli_diff_apply_flow_never_prints_secrets(cli_env, capsys, caplog):
    caplog.set_level("DEBUG")
    with respx.mock(assert_all_called=False) as mock:
        fake = FakePortkey(mock)
        assert cli.main([*cli_env, "diff", "--env", "prod", "--exit-code"]) == 2
        out = capsys.readouterr().out
        assert "+ configs/pc-aig-router@aig-claims (create)" in out
        assert cli.main([*cli_env, "apply", "--env", "prod"]) == 0
        out += capsys.readouterr().out
        assert "Dry run: nothing was written" in out and fake.writes == []
        assert cli.main([*cli_env, "apply", "--env", "prod", "--yes"]) == 0
        out += capsys.readouterr().out
        assert fake.writes
        assert cli.main([*cli_env, "diff", "--env", "prod", "--exit-code", "--json"]) == 0
        diff = capsys.readouterr().out
        assert json.loads(diff)["summary"] == {"noop": sum(len(v) for v in fake.store.values())}
        out += diff
        assert cli.main([*cli_env, "render", "--env", "prod"]) == 0
        out += capsys.readouterr().out
    _assert_no_secrets(out + caplog.text)
    assert "<secret:AIG_PORTKEY_WEBHOOK_SECRET>" in out


def test_cli_apply_reports_failures_without_secrets(cli_env, capsys):
    with respx.mock(assert_all_called=False) as mock:
        # Registered first, so it wins over the fake's generic create route.
        mock.post(ADMIN + "/guardrails").mock(return_value=httpx.Response(400, text=f"rejected {WEBHOOK_SECRET}"))
        FakePortkey(mock)
        assert cli.main([*cli_env, "apply", "--env", "prod", "--yes", "--kind", "guardrails"]) == 1
    out = capsys.readouterr()
    assert "failed: POST /guardrails: HTTP 400" in out.out
    _assert_no_secrets(out.out + out.err)


def test_cli_requires_admin_env(monkeypatch, cli_env, capsys):
    monkeypatch.delenv("AIG_PORTKEY_ADMIN_API_KEY")
    assert cli.main([*cli_env, "diff", "--env", "dev"]) == 1
    assert "AIG_PORTKEY_ADMIN_API_KEY" in capsys.readouterr().err


def test_format_plan_marks_blocked(rendered, client):
    with respx.mock(assert_all_called=False) as mock:
        FakePortkey(mock)
        plan = plan_for(rendered["dev"], client, environ={})
    text = format_plan(plan)
    assert "(blocked)" in text and "AIG_PROVIDER_KEY_ANTHROPIC_PROD" in text
