"""The offline Portkey conditional-routing evaluator."""

from __future__ import annotations

import pytest

from aig_gateway.routing import RoutingError, matches, resolve

M = {"metadata": {"user_tier": "premium", "job_profile": "claims", "score": 7, "region": "us-east-1"}, "params": {"model": "gpt-x", "max_tokens": 500}}


@pytest.mark.parametrize(
    "query,expected",
    [
        ({"metadata.user_tier": {"$eq": "premium"}}, True),
        ({"metadata.user_tier": "premium"}, True),  # bare value = $eq
        ({"metadata.user_tier": {"$eq": "standard"}}, False),
        ({"metadata.user_tier": {"$ne": "standard"}}, True),
        ({"metadata.user_tier": {"$ne": "premium"}}, False),
        ({"metadata.job_profile": {"$in": ["underwriting", "claims"]}}, True),
        ({"metadata.job_profile": {"$in": ["operations"]}}, False),
        ({"metadata.job_profile": {"$nin": ["operations", "general"]}}, True),
        ({"metadata.job_profile": {"$nin": ["claims"]}}, False),
        ({"metadata.region": {"$regex": "^us-"}}, True),
        ({"metadata.region": {"$regex": "^eu-"}}, False),
        ({"metadata.score": {"$gt": 5}}, True),
        ({"metadata.score": {"$gt": 7}}, False),
        ({"metadata.score": {"$gte": 7}}, True),
        ({"metadata.score": {"$lt": 7}}, False),
        ({"metadata.score": {"$lte": 7}}, True),
        ({"metadata.score": {"$gt": 5, "$lt": 10}}, True),
        ({"metadata.score": {"$gt": "5"}}, False),  # type mismatch never matches
        ({"params.max_tokens": {"$gte": 500}}, True),
        ({"params.model": {"$regex": "^gpt"}}, True),
        ({"metadata.user_tier": "premium", "metadata.job_profile": "operations"}, False),  # implicit AND
        ({"$and": [{"metadata.user_tier": "premium"}, {"metadata.job_profile": "claims"}]}, True),
        ({"$and": [{"metadata.user_tier": "premium"}, {"metadata.job_profile": "general"}]}, False),
        ({"$or": [{"metadata.user_tier": "free"}, {"metadata.job_profile": "claims"}]}, True),
        ({"$or": [{"metadata.user_tier": "free"}, {"metadata.job_profile": "general"}]}, False),
        ({"$or": [{"$and": [{"metadata.score": {"$gt": 1}}, {"metadata.region": {"$regex": "east"}}]}, {"metadata.user_tier": "x"}]}, True),
        # Missing fields: only $ne / $nin match.
        ({"metadata.missing": {"$eq": "x"}}, False),
        ({"metadata.missing": {"$ne": "x"}}, True),
        ({"metadata.missing": {"$in": ["x"]}}, False),
        ({"metadata.missing": {"$nin": ["x"]}}, True),
        ({"metadata.missing": {"$regex": "."}}, False),
        ({"metadata.missing": {"$gt": 0}}, False),
    ],
)
def test_operators(query, expected):
    assert matches(query, M) is expected


@pytest.mark.parametrize(
    "query",
    [{"metadata.x": {"$exists": True}}, {"$not": {}}, {"user_tier": "x"}, {"metadata.x": {"$in": "notalist"}},
     {"$or": []}, {"metadata.x": {"$regex": 5}}],
)
def test_invalid_queries_raise(query):
    with pytest.raises(RoutingError):
        matches(query, {"metadata": {"x": "y"}})


CFG = {
    "strategy": {
        "mode": "conditional",
        "conditions": [
            {"query": {"metadata.a": "1"}, "then": "t1"},
            {"query": {"metadata.b": "2"}, "then": "t2"},
        ],
        "default": "t3",
    },
    "targets": [
        {"name": "t1", "virtual_key": "vk1", "override_params": {"model": "m1"}},
        {"name": "t2", "strategy": {"mode": "fallback"}, "custom_host": "https://h", "targets": [
            {"virtual_key": "vk2", "override_params": {"model": "m2"}},
            {"strategy": {"mode": "loadbalance"}, "targets": [
                {"virtual_key": "vk3", "override_params": {"model": "m3"}, "weight": 3},
                {"virtual_key": "vk4", "override_params": {"model": "m4"}},
            ]},
        ]},
        {"name": "t3", "strategy": {"mode": "loadbalance"}, "targets": [
            {"virtual_key": "vk5", "override_params": {"model": "m5"}, "weight": 0.7},
            {"virtual_key": "vk6", "override_params": {"model": "m6"}, "weight": 0.3},
        ]},
    ],
}


def test_first_match_wins():
    res = resolve(CFG, {"a": "1", "b": "2"})
    assert (res.rule_index, res.target, res.mode, res.plan.models()) == (0, "t1", "single", ["m1"])


def test_second_rule_and_nested_strategies_with_inherited_host():
    res = resolve(CFG, {"b": "2"})
    assert res.rule_index == 1 and res.mode == "fallback"
    assert res.plan.models() == ["m2", "m3", "m4"]
    assert {leaf.custom_host for leaf in res.plan.chain()} == {"https://h"}
    assert res.plan.options[1].shares() == [0.75, 0.25]


def test_default_and_weights():
    res = resolve(CFG, {})
    assert res.rule_index is None and res.target == "t3"
    assert res.plan.shares() == [0.7, 0.3]
    assert res.as_dict()["matched_rule"] == "default"


def test_undefined_target_raises():
    bad = {**CFG, "strategy": {**CFG["strategy"], "default": "nope"}}
    with pytest.raises(RoutingError):
        resolve(bad, {})


def test_non_conditional_root():
    res = resolve({"strategy": {"mode": "fallback"}, "targets": [{"virtual_key": "a", "override_params": {"model": "x"}}]}, {})
    assert res.mode == "fallback" and res.plan.models() == ["x"]
