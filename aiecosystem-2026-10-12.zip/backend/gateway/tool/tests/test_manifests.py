"""Manifests, schemas, rendering and cross-reference validation."""

from __future__ import annotations

import json
import re

import pytest
import yaml

from aig_gateway.loader import ENVS, KIND_SCHEMAS, ManifestError, load_repo
from aig_gateway.render import KINDS, render
from aig_gateway.template import TemplateError, find_placeholders, mask_secrets, per_env, substitute
from aig_gateway.validate import validate

from conftest import GATEWAY_ROOT, REPO_ROOT, copy_root, edit_manifest, fill_env


def test_committed_repo_validates_with_placeholders_allowed(repo):
    report = validate(repo, allow_placeholders=True)
    assert report.ok, report.errors
    assert set(report.rendered) == set(ENVS)


@pytest.mark.parametrize("env", ["stage", "prod"])
def test_placeholders_refused_in_strict_envs(repo, env):
    report = validate(repo, [env])
    assert not report.ok
    assert any("unresolved placeholder" in e and f"[{env}]" in e for e in report.errors)


@pytest.mark.parametrize("env", ["local", "dev"])
def test_placeholders_only_warn_in_local_and_dev(repo, env):
    report = validate(repo, [env])
    assert report.ok, report.errors
    assert any("unresolved placeholder" in w for w in report.warnings)


def test_filled_envs_validate_strictly(concrete_repo):
    report = validate(concrete_repo)
    assert report.ok, report.errors
    assert not report.warnings
    for env, r in report.rendered.items():
        assert not [p for objs in r.objects.values() for o in objs for p in find_placeholders(o)], env


def test_every_kind_has_a_schema_and_a_manifest(repo):
    assert set(repo.manifests) == set(KIND_SCHEMAS)
    for schema in KIND_SCHEMAS.values():
        assert (GATEWAY_ROOT / "schemas" / schema).is_file()
    assert (GATEWAY_ROOT / "schemas" / "env.schema.json").is_file()
    assert (GATEWAY_ROOT / "schemas" / "portkey-config.schema.json").is_file()


def test_schema_violation_reported(tmp_path):
    root = copy_root(tmp_path)
    edit_manifest(root, "integrations.yaml", lambda s: s["integrations"][0].update(key="sk-should-never-be-here"))
    with pytest.raises(ManifestError) as exc:
        load_repo(root)
    assert any("integrations.yaml" in p and "key" in p for p in exc.value.problems)


def test_unknown_template_variable_is_an_error(tmp_path):
    root = copy_root(tmp_path)
    cfg = json.loads((root / "configs" / "pc-aig-router.json").read_text())
    cfg["targets"][0]["targets"][0]["override_params"]["model"] = "${models.does_not_exist}"
    (root / "configs" / "pc-aig-router.json").write_text(json.dumps(cfg))
    report = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert any("undefined template variable" in e for e in report.errors)


def test_required_metadata_matches_contracts(repo):
    schema = json.loads((REPO_ROOT / "backend" / "contracts" / "metadata.schema.json").read_text())
    req = repo.spec("Workspaces")["required_metadata"]
    assert req["keys"] == ["user_tier", "job_profile", "agent_id", "team"]
    for key in req["keys"]:
        assert key in schema["required"]
    for key, values in req["enums"].items():
        assert values == schema["$defs"][key]["enum"]


def test_contract_drift_detected(tmp_path):
    root = copy_root(tmp_path)
    edit_manifest(root, "workspaces.yaml", lambda s: s["required_metadata"]["enums"].update(user_tier=["gold"]))
    contracts = tmp_path / "contracts"
    contracts.mkdir()
    (contracts / "metadata.schema.json").write_text((REPO_ROOT / "backend" / "contracts" / "metadata.schema.json").read_text())
    report = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert any("required_metadata.enums.user_tier" in e for e in report.errors)


# --- pc-aig-router: exactly the blueprint ---------------------------------------------


def test_pc_aig_router_is_the_blueprint(rendered):
    r = rendered["prod"]
    cfg = r.config("pc-aig-router", "aig-platform")
    assert cfg["strategy"] == {
        "mode": "conditional",
        "conditions": [
            {"query": {"metadata.user_tier": {"$eq": "premium"}}, "then": "opus"},
            {"query": {"metadata.user_tier": {"$eq": "standard"}}, "then": "sonnet"},
            {"query": {"metadata.job_profile": {"$in": ["underwriting", "claims"]}}, "then": "sonnet"},
        ],
        "default": "openai",
    }
    targets = {t["name"]: t for t in cfg["targets"]}
    assert [t["name"] for t in cfg["targets"]] == ["opus", "sonnet", "openai"]
    assert targets["opus"]["strategy"] == {"mode": "fallback"}
    assert targets["sonnet"]["strategy"] == {"mode": "fallback"}
    assert targets["openai"]["strategy"] == {"mode": "loadbalance"}
    host = "https://cache-compress.aig.example.com"
    assert [(l["virtual_key"], l["override_params"]["model"]) for l in targets["opus"]["targets"]] == [
        ("anthropic-prod", "claude-opus-test"), ("anthropic-prod", "claude-sonnet-test")]
    assert [(l["virtual_key"], l["override_params"]["model"]) for l in targets["sonnet"]["targets"]] == [
        ("anthropic-prod", "claude-sonnet-test"), ("openai-prod", "gpt-test")]
    lb = targets["openai"]["targets"]
    assert [(l["virtual_key"], l["custom_host"], l["weight"]) for l in lb] == [
        ("openai-prod", f"{host}/openai-a/v1", 0.5), ("openai-prod", f"{host}/openai-b/v1", 0.5)]
    for t in cfg["targets"]:
        for leaf in t["targets"]:
            assert leaf["custom_host"].startswith(host + "/")
            assert set(leaf) <= {"virtual_key", "custom_host", "override_params", "weight"}
    assert cfg["cache"] == {"mode": "semantic", "max_age": 3600}
    assert cfg["input_guardrails"][0] == "aig-agent-check"
    assert set(cfg["input_guardrails"]) == {"aig-agent-check", "aig-input-pii", "aig-input-injection", "aig-input-policy"}
    assert set(cfg["output_guardrails"]) == {"aig-output-schema", "aig-output-policy", "aig-output-pii"}


def test_config_deployed_to_every_production_workspace_only(rendered):
    ws = {o["workspace_id"] for o in rendered["dev"].objects["configs"] if o["slug"] == "pc-aig-router"}
    assert ws == {"aig-underwriting", "aig-claims", "aig-operations", "aig-platform"}


def test_env_overlay_values_flow_into_config(repo):
    r = render(repo, "local")
    leaf = r.config(workspace="aig-platform")["targets"][0]["targets"][0]
    assert leaf["custom_host"] == "http://host.docker.internal:8090/anthropic/v1"
    assert leaf["override_params"]["model"] == "<claude-opus-model-id>"
    assert r.config(workspace="aig-platform")["cache"] == {"mode": "simple", "max_age": 300}


# --- virtual keys / sandbox isolation -----------------------------------------------


def test_sandbox_keys_exist_only_in_model_sandbox(rendered):
    for env, r in rendered.items():
        its = {i["slug"]: i for i in r.objects["integrations"]}
        assert set(its) == {"anthropic-prod", "openai-prod", "anthropic-sandbox", "openai-sandbox"}
        for slug in ("anthropic-sandbox", "openai-sandbox"):
            assert its[slug]["workspace_ids"] == ["model-sandbox"] and its[slug]["is_sandbox"]
        for slug in ("anthropic-prod", "openai-prod"):
            assert "model-sandbox" not in its[slug]["workspace_ids"]
        deployments = its["openai-prod"]["configurations"]["deployments"]
        assert [d["name"] for d in deployments] == ["a", "b"]


def test_integrations_never_carry_a_key_value(rendered):
    for r in rendered.values():
        for it in r.objects["integrations"]:
            assert set(it["key"]) == {"$secret_env"}
            assert mask_secrets(it)["key"].startswith("<secret:AIG_PROVIDER_KEY_")


@pytest.mark.parametrize(
    "mutate,needle",
    [
        (lambda root: (root / "configs" / "pc-aig-router.json").write_text(
            (root / "configs" / "pc-aig-router.json").read_text().replace("${virtual_keys.openai}", "${virtual_keys.openai_sandbox}", 1)),
         "sandbox key"),
        (lambda root: edit_manifest(root, "integrations.yaml",
                                    lambda s: s["integrations"][0]["workspaces"].append("model-sandbox")),
         "must not be shared with model-sandbox"),
        (lambda root: edit_manifest(root, "integrations.yaml",
                                    lambda s: s["integrations"][2]["workspaces"].append("aig-claims")),
         "only in model-sandbox"),
        (lambda root: edit_manifest(root, "configs.yaml", lambda s: s["configs"][0]["workspaces"].append("model-sandbox")),
         "must not be deployed to model-sandbox"),
        (lambda root: edit_manifest(root, "models.yaml", lambda s: s["allow_lists"]["aig-claims"].remove("opus")),
         "allow-list"),
        (lambda root: edit_manifest(root, "models.yaml", lambda s: s["allow_lists"]["aig-claims"].append("sandbox-claude-candidate")),
         "not allowed in this workspace"),
        (lambda root: edit_manifest(root, "api-keys.yaml", lambda s: s["keys"][0].update(workspace="nope")),
         "unknown workspace"),
        (lambda root: edit_manifest(root, "mcp-servers.yaml", lambda s: s["servers"][2]["iam_roles"].append("aig-claims-developer")),
         "does not belong"),
        (lambda root: (root / "configs" / "pc-aig-router.json").write_text(
            (root / "configs" / "pc-aig-router.json").read_text().replace('"aig-agent-check", ', "")),
         "aig-agent-check"),
        (lambda root: (root / "configs" / "pc-aig-router.json").write_text(
            (root / "configs" / "pc-aig-router.json").read_text().replace("${cache_compress.host}/anthropic/v1", "https://api.anthropic.com/v1")),
         "custom_host"),
    ],
)
def test_cross_reference_violations(tmp_path, mutate, needle):
    root = copy_root(tmp_path)
    mutate(root)
    report = validate(load_repo(root), ["dev"], allow_placeholders=True)
    assert not report.ok
    assert any(needle in e for e in report.errors), report.errors


# --- guardrails ------------------------------------------------------------------------


def _g(r, slug):
    return r.find("guardrails", slug=slug)


@pytest.mark.parametrize("env", ["local", "dev"])
def test_content_guardrails_log_only_in_local_and_dev(rendered, env):
    r = rendered[env]
    for slug in ("aig-input-pii", "aig-input-injection", "aig-input-policy", "aig-output-policy", "aig-output-pii", "aig-output-schema"):
        assert _g(r, slug)["actions"] == {"deny": False, "async": True}, slug
    assert _g(r, "aig-input-pii")["checks"][0]["parameters"]["redact"] is False


@pytest.mark.parametrize("env", ["stage", "prod"])
def test_content_guardrails_enforce_in_stage_and_prod(rendered, env):
    r = rendered[env]
    for slug in ("aig-input-injection", "aig-input-policy", "aig-output-policy"):
        assert _g(r, slug)["actions"] == {"deny": True, "async": False}, slug
    for slug in ("aig-input-pii", "aig-output-pii"):
        assert _g(r, slug)["actions"] == {"deny": False, "async": False}
        assert _g(r, slug)["checks"][0]["parameters"]["redact"] is True
    # Documented exception until verified: schema check stays log-only.
    assert _g(r, "aig-output-schema")["actions"] == {"deny": False, "async": True}


def test_agent_check_webhook(rendered):
    for env, r in rendered.items():
        g = _g(r, "aig-agent-check")
        check = g["checks"][0]
        assert check["id"] == "default.webhook"
        assert check["parameters"]["webhookURL"] == "https://platform-api.aig.example.com/api/v1/guardrails/agent-check"
        assert check["parameters"]["headers"] == {"x-aig-webhook-secret": {"$secret_env": "AIG_PORTKEY_WEBHOOK_SECRET"}}
        assert check["parameters"]["failOnError"] is True
        expected = {"deny": False, "async": True} if env == "local" else {"deny": True, "async": False}
        assert g["actions"] == expected, env


# --- workspaces, keys, limits, caching, MCP --------------------------------------------


def test_workspaces_and_required_metadata(rendered):
    r = rendered["prod"]
    slugs = [w["slug"] for w in r.objects["workspaces"]]
    assert slugs == ["aig-underwriting", "aig-claims", "aig-operations", "aig-platform", "model-sandbox"]
    for w in r.objects["workspaces"]:
        assert w["settings"]["required_metadata"]["keys"] == ["user_tier", "job_profile", "agent_id", "team"]
        assert w["settings"]["is_sandbox"] == (w["slug"] == "model-sandbox")
    sandbox = r.find("workspaces", slug="model-sandbox")
    assert sandbox["settings"]["allowed_models"] == ["claude-candidate-test", "gpt-candidate-test"]


def test_api_keys_scoped(rendered):
    keys = {k["name"]: k for k in rendered["prod"].objects["api_keys"]}
    assert keys["aig-platform-api"]["scopes"] == ["completions.write"]
    assert keys["aig-platform-api"]["defaults"] == {"config_id": "pc-aig-router"}
    assert "completions.write" not in keys["aig-platform-analytics"]["scopes"]
    # The sandbox key defaults to the sandbox config, the only config deployed to model-sandbox.
    assert keys["aig-model-sandbox"]["defaults"] == {"config_id": "pc-aig-sandbox"}


def test_budgets_and_rate_limits_per_team_and_profile(rendered):
    usage = {u["name"]: u for u in rendered["prod"].objects["usage_limits"]}
    rate = {u["name"]: u for u in rendered["prod"].objects["rate_limits"]}
    assert usage["aig-budget-team-aig-claims"]["credit_limit"] == 20000
    assert usage["aig-budget-team-aig-claims"]["alert_threshold"] == 16000
    assert usage["aig-budget-profile-underwriting"]["conditions"] == [{"key": "metadata.job_profile", "value": "underwriting"}]
    assert rate["aig-rate-team-aig-platform"]["value"] == 2000
    assert rate["aig-rate-profile-general"]["type"] == "tokens"
    dev_usage = {u["name"]: u for u in rendered["dev"].objects["usage_limits"]}
    assert dev_usage["aig-budget-team-aig-claims"]["credit_limit"] == 500
    assert {f"aig-budget-profile-{p}" for p in ("underwriting", "claims", "operations", "general")} <= set(usage)


def test_caching_owned_by_portkey(repo):
    spec = repo.spec("Caching")
    assert spec["owner"] == "portkey"
    assert spec["cache_compress_layer"]["caching"] == "disabled"


def test_mcp_registry_mapped_to_iam_roles(rendered):
    servers = {s["slug"]: s for s in rendered["prod"].objects["mcp_servers"]}
    assert set(servers) == {"aig-jira", "aig-confluence", "aig-github"}
    gh = servers["aig-github"]
    assert gh["workspace_ids"] == ["aig-platform"]
    assert gh["access"] == {"unregistered": "deny", "iam_role_arns": ["arn:aws:iam::123456789012:role/aig-platform-admin"]}


# --- templating -------------------------------------------------------------------------


def test_template_helpers():
    ctx = {"a": {"b": 5, "s": "x"}}
    assert substitute("${a.b}", ctx) == 5
    assert substitute("v=${a.b}/${a.s}", ctx) == "v=5/x"
    with pytest.raises(TemplateError):
        substitute("${a.c}", ctx)
    assert per_env({"per_env": {"dev": 1}, "default": 2}, "dev") == 1
    assert per_env({"per_env": {"dev": 1}, "default": 2}, "prod") == 2
    with pytest.raises(TemplateError):
        per_env({"per_env": {"dev": 1}}, "prod")
    assert find_placeholders({"x": ["<abc-def>", "__REPLACE_ME_X__", "ok"]}) == [("x[0]", "<abc-def>"), ("x[1]", "__REPLACE_ME_X__")]


def test_no_secret_shaped_values_committed():
    pattern = re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9]{32,}|pk-(live|test|admin)-[A-Za-z0-9]{8,}")
    for p in GATEWAY_ROOT.rglob("*"):
        if ".venv" in p.parts or "tests" in p.parts or not p.is_file() or p.suffix not in (".yaml", ".json", ".md", ".py"):
            continue
        for line in p.read_text().splitlines():
            if "rule:" in line:  # the policy guardrail's own detection regex
                continue
            assert not pattern.search(line), f"{p}: secret-shaped value"


def test_render_covers_every_kind(repo):
    r = render(repo, "dev")
    assert list(r.objects) == list(KINDS)
    assert all(r.objects[k] for k in KINDS)
