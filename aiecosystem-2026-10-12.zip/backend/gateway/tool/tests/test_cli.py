"""Offline CLI commands: validate, render, route, matrix."""

from __future__ import annotations

import json

from aig_gateway import cli

from conftest import GATEWAY_ROOT


def run(capsys, *args):
    code = cli.main(["--root", str(GATEWAY_ROOT), *args])
    out = capsys.readouterr()
    return code, out.out, out.err


def test_validate_all_envs_needs_allow_placeholders(capsys):
    code, _, err = run(capsys, "validate")
    assert code == 1 and "unresolved placeholder" in err
    code, out, _ = run(capsys, "validate", "--allow-placeholders")
    assert code == 0 and "validate: OK" in out
    code, out, _ = run(capsys, "validate", "--env", "local", "--env", "dev")
    assert code == 0


def test_validate_with_filled_env(concrete_repo, capsys):
    code = cli.main(["--root", str(concrete_repo.root), "validate"])
    assert code == 0


def test_render_prints_json_objects(capsys):
    code, out, _ = run(capsys, "render", "--env", "dev", "--kind", "configs")
    data = json.loads(out)
    assert code == 0 and list(data["objects"]) == ["configs"]
    assert data["objects"]["configs"][0]["config"]["strategy"]["default"] == "openai"


def test_route_and_matrix(capsys):
    code, out, _ = run(capsys, "route", "--env", "dev", "--tier", "free", "--job-profile", "claims")
    res = json.loads(out)
    assert code == 0 and res["target"] == "sonnet" and res["matched_rule"] == 3 and res["mode"] == "fallback"
    code, out, _ = run(capsys, "matrix", "--env", "dev")
    assert code == 0 and len(out.strip().splitlines()) == 13 and "shares=0.5/0.5" in out
    code, out, _ = run(capsys, "matrix", "--env", "dev", "--json")
    assert len(json.loads(out)) == 12


def test_manifest_errors_reported(tmp_path, capsys):
    (tmp_path / "schemas").mkdir()
    code = cli.main(["--root", str(tmp_path), "validate"])
    assert code == 1 and "missing" in capsys.readouterr().err
