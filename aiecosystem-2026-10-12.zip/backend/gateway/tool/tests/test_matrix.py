"""Phase 1 exit criterion: routing matrix for every tier x job_profile, and rejection of
missing metadata / unknown or suspended agents (required metadata + webhook guardrail)."""

from __future__ import annotations

import json
import os

import httpx
import pytest
import respx

from aig_gateway.render import render
from aig_gateway.routing import resolve
from aig_gateway.simulate import matrix, mcp_access, simulate

from conftest import GATEWAY_ROOT, REPO_ROOT

TIERS = ("premium", "standard", "free")
JOBS = ("underwriting", "claims", "operations", "general")
OPUS, SONNET, OPENAI = "claude-opus-test", "claude-sonnet-test", "gpt-test"
HOST = "https://cache-compress.aig.example.com"
WEBHOOK = "https://platform-api.aig.example.com/api/v1/guardrails/agent-check"
SECRET = "whsec-TEST-not-a-real-secret-123456"
CASES = json.loads((GATEWAY_ROOT / "simulation" / "agent-check-cases.json").read_text())


def expected(tier: str, job: str):
    if tier == "premium":
        return 1, "opus", "fallback", [(OPUS, "anthropic-prod", "anthropic"), (SONNET, "anthropic-prod", "anthropic")], []
    if tier == "standard":
        return 2, "sonnet", "fallback", [(SONNET, "anthropic-prod", "anthropic"), (OPENAI, "openai-prod", "openai-a")], []
    if job in ("underwriting", "claims"):
        return 3, "sonnet", "fallback", [(SONNET, "anthropic-prod", "anthropic"), (OPENAI, "openai-prod", "openai-a")], []
    return None, "openai", "loadbalance", [(OPENAI, "openai-prod", "openai-a"), (OPENAI, "openai-prod", "openai-b")], [0.5, 0.5]


@pytest.mark.parametrize("env", ["local", "dev", "stage", "prod"])
@pytest.mark.parametrize("workspace", ["aig-underwriting", "aig-claims", "aig-operations", "aig-platform"])
@pytest.mark.parametrize("tier", TIERS)
@pytest.mark.parametrize("job", JOBS)
def test_routing_matrix(rendered, env, workspace, tier, job):
    r = rendered[env]
    res = resolve(r.config("pc-aig-router", workspace), {"user_tier": tier, "job_profile": job, "agent_id": "a", "team": "t"})
    rule, target, mode, chain, shares = expected(tier, job)
    assert res.rule_index == (rule - 1 if rule else None)
    assert res.target == target and res.mode == mode
    host = r.context["cache_compress"]["host"]
    assert [(l.model, l.virtual_key, l.custom_host) for l in res.plan.chain()] == [
        (m, vk, f"{host}/{route}/v1") for m, vk, route in chain]
    assert res.plan.shares() == shares


def test_matrix_table_covers_all_twelve_combinations(rendered):
    rows = matrix(rendered["prod"])
    assert len(rows) == 12
    assert {(r["user_tier"], r["job_profile"]) for r in rows} == {(t, j) for t in TIERS for j in JOBS}
    assert sum(r["target"] == "opus" for r in rows) == 4
    assert sum(r["target"] == "sonnet" for r in rows) == 6
    assert sum(r["target"] == "openai" for r in rows) == 2


def test_unknown_tier_falls_to_default(rendered):
    res = resolve(rendered["prod"].config(workspace="aig-platform"), {"user_tier": "gold", "job_profile": "general"})
    assert res.target == "openai"


# --- gateway simulation: required metadata + agent-check webhook ------------------------


def _responder(request: httpx.Request) -> httpx.Response:
    """Stands in for platform-api, answering from the shared case table (which
    backend/platform-api/tests/test_agent_check_cases.py proves the real endpoint matches)."""
    if request.headers.get("x-aig-webhook-secret") != SECRET:
        return httpx.Response(401, json={"error": {"code": "webhook_unauthenticated"}})
    payload = json.loads(request.content)
    assert payload["eventType"] == "beforeRequestHook" and payload["requestType"] == "chatComplete"
    for case in CASES["cases"]:
        if case["metadata"] == payload["metadata"]:
            return httpx.Response(200, json={"verdict": case["verdict"], "data": {"reason": case["reason"]}})
    return httpx.Response(200, json={"verdict": False, "data": {"reason": "agent_unregistered"}})


@pytest.fixture
def platform_api():
    with respx.mock(assert_all_called=False) as mock:
        route = mock.post(WEBHOOK).mock(side_effect=_responder)
        yield route


ENV = {"AIG_PORTKEY_WEBHOOK_SECRET": SECRET}


@pytest.mark.parametrize("case", CASES["cases"], ids=[c["name"] for c in CASES["cases"]])
@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
def test_agent_check_cases_enforced(rendered, platform_api, case, env):
    out = simulate(rendered[env], workspace="aig-platform", metadata=case["metadata"], environ=ENV)
    if "agent_id" not in case["metadata"]:
        # Required metadata rejects before any guardrail or model is reached.
        assert (out.allowed, out.status, out.stage) == (False, 400, "required_metadata")
        assert not platform_api.called
        return
    assert platform_api.called
    if case["verdict"]:
        assert out.allowed and out.status == 200 and out.stage == "routed"
    else:
        assert (out.allowed, out.status, out.stage) == (False, 446, "guardrail")
        assert case["reason"] in out.reason


@pytest.mark.parametrize("missing", ["user_tier", "job_profile", "agent_id", "team"])
def test_missing_required_metadata_rejected_before_model(rendered, platform_api, missing):
    meta = {"user_tier": "premium", "job_profile": "claims", "agent_id": "ide.vscode", "team": "claims-ai"}
    del meta[missing]
    out = simulate(rendered["prod"], workspace="aig-claims", metadata=meta, environ=ENV)
    assert (out.allowed, out.status, out.stage) == (False, 400, "required_metadata")
    assert missing in out.reason
    assert not platform_api.called


@pytest.mark.parametrize("bad", [{"user_tier": "gold"}, {"job_profile": "marketing"}, {"agent_id": "bad id!"}])
def test_invalid_metadata_values_rejected(rendered, platform_api, bad):
    meta = {"user_tier": "premium", "job_profile": "claims", "agent_id": "ide.vscode", "team": "claims-ai", **bad}
    out = simulate(rendered["prod"], workspace="aig-claims", metadata=meta, environ=ENV)
    assert out.status == 400 and not platform_api.called


def test_no_metadata_at_all_rejected(rendered, platform_api):
    out = simulate(rendered["prod"], workspace="aig-claims", metadata={}, environ=ENV)
    assert out.status == 400


def test_unknown_agent_only_logged_in_local(rendered, platform_api):
    local = rendered["local"]
    meta = {"user_tier": "premium", "job_profile": "claims", "agent_id": "rogue-agent", "team": "claims-ai"}
    with respx.mock(assert_all_called=False) as mock:
        mock.post(local.find("guardrails", slug="aig-agent-check")["checks"][0]["parameters"]["webhookURL"]).mock(
            return_value=httpx.Response(200, json={"verdict": False, "data": {"reason": "agent_unregistered"}}))
        out = simulate(local, workspace="aig-claims", metadata=meta, environ=ENV)
    assert out.allowed and out.status == 200
    agent = [g for g in out.guardrails if g.slug == "aig-agent-check"][0]
    assert agent.verdict is False and agent.action == "log"


@pytest.mark.parametrize(
    "response",
    [httpx.Response(500), httpx.Response(503, json={"error": {"code": "webhook_not_configured"}}),
     httpx.Response(200, json={"unexpected": True}), httpx.ConnectTimeout("t")],
)
def test_webhook_errors_fail_closed(rendered, response):
    meta = {"user_tier": "premium", "job_profile": "claims", "agent_id": "ide.vscode", "team": "claims-ai"}
    with respx.mock() as mock:
        route = mock.post(WEBHOOK)
        route.mock(side_effect=response) if isinstance(response, Exception) else route.mock(return_value=response)
        out = simulate(rendered["prod"], workspace="aig-claims", metadata=meta, environ=ENV)
    assert (out.allowed, out.status) == (False, 446)
    assert "webhook_error" in out.reason


def test_wrong_webhook_secret_fails_closed(rendered, platform_api):
    meta = {"user_tier": "premium", "job_profile": "claims", "agent_id": "ide.vscode", "team": "claims-ai"}
    out = simulate(rendered["prod"], workspace="aig-claims", metadata=meta,
                   environ={"AIG_PORTKEY_WEBHOOK_SECRET": "wrong-secret-value-xyz"})
    assert out.status == 446


def test_ide_traffic_from_platform_api_is_routed(rendered, platform_api):
    meta = {"_user": "jane@example.com", "agent_id": "ide.vscode", "env": "dev", "host": "vscode", "job_profile": "general",
            "team": "underwriting-ai", "user": "jane@example.com", "user_tier": "premium"}
    case = {"metadata": meta, "verdict": True, "reason": "agent_active"}
    CASES["cases"].append(case)
    try:
        out = simulate(rendered["dev"], workspace="aig-platform", metadata=meta, environ=ENV)
    finally:
        CASES["cases"].remove(case)
    assert out.allowed and out.resolution.target == "opus"


# --- MCP gateway registry ---------------------------------------------------------------


def test_mcp_registry_decisions(rendered):
    r = rendered["prod"]
    admin = "arn:aws:iam::123456789012:role/aig-platform-admin"
    claims_dev = "arn:aws:iam::123456789012:role/aig-claims-developer"
    assert mcp_access(r, server="aig-github", workspace="aig-platform", iam_role_arn=admin) == (True, "allowed")
    assert mcp_access(r, server="aig-github", workspace="aig-claims", iam_role_arn=claims_dev) == (False, "workspace_not_allowed")
    assert mcp_access(r, server="aig-jira", workspace="aig-claims", iam_role_arn=claims_dev) == (True, "allowed")
    assert mcp_access(r, server="aig-confluence", workspace="aig-claims",
                      iam_role_arn="arn:aws:iam::123456789012:role/someone-else") == (False, "role_not_allowed")
    assert mcp_access(r, server="random-public-mcp", workspace="aig-claims", iam_role_arn=claims_dev) == (False, "unregistered_server")
    assert mcp_access(r, server="aig-jira", workspace="model-sandbox", iam_role_arn=claims_dev)[0] is False


def test_live_matrix_script_exists_and_skips_without_gateway():
    import subprocess

    script = REPO_ROOT / "scripts" / "gateway-matrix-live.sh"
    assert script.is_file() and os.access(script, os.X_OK)
    env = {k: v for k, v in os.environ.items() if not k.startswith("AIG_PORTKEY")}
    out = subprocess.run([str(script)], capture_output=True, text=True, env=env, timeout=30)
    assert out.returncode == 0
    assert "SKIP" in out.stdout
