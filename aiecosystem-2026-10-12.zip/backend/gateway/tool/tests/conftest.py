from __future__ import annotations

import shutil
from pathlib import Path

import pytest
import yaml

from aig_gateway.loader import load_repo
from aig_gateway.render import render

GATEWAY_ROOT = Path(__file__).resolve().parents[2]
REPO_ROOT = GATEWAY_ROOT.parents[1]

# Concrete (non-placeholder) values used to prove strict validation passes once envs are filled.
CONCRETE = {
    "portkey": {"gateway_url": "https://portkey.aig.example.com/v1", "mcp_gateway_url": "https://portkey.aig.example.com/mcp"},
    "cache_compress": {"host": "https://cache-compress.aig.example.com"},
    "models": {
        "opus": "claude-opus-test",
        "sonnet": "claude-sonnet-test",
        "openai": "gpt-test",
        "sandbox_claude_candidate": "claude-candidate-test",
        "sandbox_openai_candidate": "gpt-candidate-test",
    },
    "webhook": {"agent_check_url": "https://platform-api.aig.example.com/api/v1/guardrails/agent-check"},
    "aws": {"account_id": "123456789012"},
    "mcp": {
        "jira_url": "https://jira-mcp.aig.example.com/mcp",
        "confluence_url": "https://confluence-mcp.aig.example.com/mcp",
        "github_url": "https://github-mcp.aig.example.com/mcp",
    },
}


def copy_root(tmp_path: Path) -> Path:
    dst = tmp_path / "gateway"  # contracts/ is looked up at root.parent
    shutil.copytree(GATEWAY_ROOT, dst, ignore=shutil.ignore_patterns("tool", ".venv", "__pycache__"))
    return dst


def fill_env(root: Path, env: str, values: dict = CONCRETE) -> None:
    p = root / "envs" / f"{env}.yaml"
    data = yaml.safe_load(p.read_text())
    for k, v in values.items():
        data[k] = {**data.get(k, {}), **v} if isinstance(v, dict) else v
    p.write_text(yaml.safe_dump(data, sort_keys=False))


def edit_manifest(root: Path, name: str, fn) -> None:
    p = root / "manifests" / name
    doc = yaml.safe_load(p.read_text())
    fn(doc["spec"])
    p.write_text(yaml.safe_dump(doc, sort_keys=False))


@pytest.fixture(scope="session")
def repo():
    return load_repo(GATEWAY_ROOT)


@pytest.fixture(scope="session")
def concrete_repo(tmp_path_factory):
    root = copy_root(tmp_path_factory.mktemp("concrete"))
    for env in ("local", "dev", "stage", "prod"):
        fill_env(root, env)
    return load_repo(root)


@pytest.fixture(scope="session")
def rendered(concrete_repo):
    return {env: render(concrete_repo, env) for env in ("local", "dev", "stage", "prod")}
