# backend/gateway: Portkey gateway as code (Phase 1)

Everything AIG configures in its **enterprise self-hosted Portkey** (AI gateway, MCP gateway,
control plane) is declared here, reviewed in pull requests, and applied with the `aigw` tool
through the Portkey admin API. Nobody edits routing, keys, guardrails or limits by hand in
the Portkey UI; if someone does, `aigw diff` shows the drift.

The repo holds **placeholders only**: URLs, model ids and account ids are `<angle-bracket>`
values per environment, and no secret is ever written to a file. Secrets are read from
environment variables at apply time and never printed.

## Layout

| Path | What it is |
|---|---|
| `manifests/workspaces.yaml` | Team workspaces (`aig-underwriting`, `aig-claims`, `aig-operations`, `aig-platform`) plus the isolated `model-sandbox`; IAM roles per workspace; **required metadata** (`user_tier`, `job_profile`, `agent_id`, `team`, values mirror `backend/contracts/metadata.schema.json`) |
| `manifests/integrations.yaml` | Provider integrations / virtual keys: `anthropic-prod`, `openai-prod` (deployments A and B), and `anthropic-sandbox` / `openai-sandbox`, which exist **only** in `model-sandbox`. Never contains a key (`secret_env` names the env var read on create) |
| `manifests/models.yaml` | Model aliases (ids from `envs/<env>.yaml`) and per-workspace model allow-lists |
| `manifests/configs.yaml` | Which config templates are deployed to which workspaces (`pc-aig-router` to every production workspace, never to the sandbox; `pc-aig-sandbox` only to `model-sandbox`) |
| `manifests/canaries.yaml` | Phase 7 model canaries / promotions per tier, written only by `aigw canary ...` (see "Model canaries") |
| `manifests/api-keys.yaml` | Scoped workspace API keys (platform-api broker key, analytics key, one agent key per team, sandbox key) |
| `manifests/limits.yaml` | Monthly budgets and rate limits per team workspace and per job profile (values can differ per env) |
| `manifests/guardrails.yaml` | Input hooks (agent check webhook, PII, prompt injection, policy) and output hooks (schema, policy, PII), with log/enforce mode per env |
| `manifests/caching.yaml` | The caching ownership decision (Portkey owns it) and cache settings per env |
| `manifests/mcp-servers.yaml` | MCP gateway registry: approved servers, workspace scoping, IAM-role mapping, tool allow-lists; unregistered servers are refused |
| `manifests/gateway.yaml` | Sync settings (which remote objects `--prune` may delete) |
| `configs/pc-aig-router.json` | The routing config template (blueprint-exact, plus guardrail hooks and the cache block) |
| `configs/pc-aig-sandbox.json` | Model-sandbox config (Phase 7): routes `metadata.candidate_model` to a sandbox candidate slot, sandbox keys only, guardrails on, no cache |
| `envs/{local,dev,stage,prod}.yaml` | Per-env values: gateway and MCP URLs, cache-compress host, model ids, virtual key slugs, webhook URL, AWS account, MCP server URLs |
| `schemas/*.schema.json` | JSON Schema (2020-12) for every manifest kind, the env overlay and the rendered Portkey config |
| `simulation/agent-check-cases.json` | Shared agent-check webhook cases (platform-api tests the real endpoint against them) |
| `tool/` | Python package `aig-gateway`, CLI `aigw` (own venv `tool/.venv`) |

## Using `aigw`

```bash
cd backend/gateway/tool
python3 -m venv .venv && .venv/bin/pip install -e '.[dev]'     # or: make setup (repo root)

.venv/bin/aigw validate                          # all envs; stage/prod fail on placeholders
.venv/bin/aigw validate --allow-placeholders     # what CI runs while envs hold placeholders
.venv/bin/aigw validate --env prod               # one env, strict
.venv/bin/aigw render --env dev                  # final Portkey objects (secrets shown as <secret:NAME>)
.venv/bin/aigw render --env dev --kind configs
.venv/bin/aigw matrix --env dev                  # routing table, every tier x job_profile
.venv/bin/aigw route --env dev --tier free --job-profile claims

# Against the admin API (per env; never commit these values)
export AIG_PORTKEY_ADMIN_URL=https://<portkey-admin-host-dev>/v1
export AIG_PORTKEY_ADMIN_API_KEY=...             # org admin key, created by hand
export AIG_PORTKEY_WEBHOOK_SECRET=...            # same value as platform-api PORTKEY_WEBHOOK_SECRET
.venv/bin/aigw diff --env dev                    # structured diff (add --json, --exit-code)
.venv/bin/aigw apply --env dev                   # DRY RUN: prints the plan, writes nothing
.venv/bin/aigw apply --env dev --yes             # create / update; idempotent
.venv/bin/aigw apply --env dev --yes --prune     # also delete managed objects no manifest declares
```

- `validate` = schema validation of every manifest and env overlay, cross-reference checks
  (workspaces, integrations, allow-lists, guardrail hooks, IAM roles, contract enums, sandbox
  isolation, `custom_host` on every leaf, `aig-agent-check` present), rendering of every env, and
  the placeholder rule (error for stage/prod unless `--allow-placeholders`, warning for local/dev).
- `diff` / `apply` compare only the fields the manifests declare (server-side fields never show
  as drift) and never compare or print secrets. `apply` writes in dependency order (workspaces,
  integrations, guardrails, MCP servers, configs, API keys, usage limits, rate limits) and only
  deletes with `--prune`, and then only objects matching `gateway.yaml` `managed_patterns`.
- Integrations are created with the provider key from `AIG_PROVIDER_KEY_<SLUG>` (for example
  `AIG_PROVIDER_KEY_ANTHROPIC_PROD`). It is sent once on create and never on update. If the
  variable is unset the item is `blocked` and `apply` exits 1; create that key in the Portkey UI
  instead. API keys created by `apply` are never printed: copy them from the Portkey UI into the
  consumer's secret store (platform-api: `aig/<env>/platform-api`).
- Root `make` targets: `make gateway-validate`, `make gateway-render ENV=dev`, `make gateway-test`.

Promotion: change manifests or `envs/<env>.yaml` in a PR (CI runs the tool tests and
`aigw validate`), then run `aigw diff` and `aigw apply --yes` per env, dev -> stage -> prod.
Before stage/prod, replace every placeholder in `envs/<env>.yaml`.

## Routing (`pc-aig-router`)

Rules are checked top to bottom; the first match wins.

| # | Condition | Target | Strategy inside the target |
|---|---|---|---|
| 1 | `metadata.user_tier $eq premium` | `opus` | fallback: Claude Opus -> Claude Sonnet |
| 2 | `metadata.user_tier $eq standard` | `sonnet` | fallback: Claude Sonnet -> OpenAI (deployment A) |
| 3 | `metadata.job_profile $in [underwriting, claims]` | `sonnet` | fallback: Claude Sonnet -> OpenAI (deployment A) |
| - | default | `openai` | loadbalance 50/50: OpenAI deployment A, deployment B |

Resulting matrix (`aigw matrix`): premium x any job -> opus; standard x any -> sonnet;
free x underwriting/claims -> sonnet; free x operations/general -> openai.

Every leaf has `virtual_key` (`anthropic-prod` / `openai-prod`), `override_params.model` (from
`envs/<env>.yaml`) and `custom_host` = the caching and compression layer:
`<cache_compress.host>/anthropic/v1`, `/openai-a/v1` or `/openai-b/v1`. The route segment tells
`backend/cache-compress` which real provider host to forward to (deployments A and B differ
only there). `tool/src/aig_gateway/routing.py` is an offline evaluator of Portkey's conditional
routing ($eq $ne $in $nin $regex $gt $gte $lt $lte $and $or, first match wins, default,
fallback chains, loadbalance weights); the tests run all 12 tier x job_profile combinations,
in every env and workspace, against the rendered config.

**Live check**: `scripts/gateway-matrix-live.sh` sends one request per combination to a real
gateway (needs `AIG_PORTKEY_BASE_URL` + `AIG_PORTKEY_API_KEY`; skips otherwise) and prints the
served model, provider and cache headers, then checks that missing metadata and an unknown
agent are rejected.

## Model sandbox and canaries (Phase 7)

**Sandbox isolation** (`aigw validate`): sandbox integrations live only in `model-sandbox`; no
config deployed to a non-sandbox workspace may reference a sandbox integration anywhere (deep scan
of the rendered config, nested targets and `@slug` references included); `pc-aig-sandbox`
(`sandbox: true` in `configs.yaml`) is deployed only to `model-sandbox`, uses only sandbox keys and
must carry the PII / injection / policy guardrails; production configs need a cache block and are
never deployed to the sandbox. The `aig-model-sandbox` API key defaults to `pc-aig-sandbox`, the
only config in its workspace, so it cannot reach `pc-aig-router`.

**Model canaries** (`manifests/canaries.yaml`, kind `Canaries`):

```bash
aigw canary set      --tier premium --model <alias> --share 10 [--model-id <id> --provider anthropic|openai]
aigw canary promote  --tier premium --model <alias>
aigw canary rollback --tier premium
aigw canary sync --from-platform-api [--platform-api-url URL]   # AIG_PLATFORM_SERVICE_TOKEN
aigw canary show
```

Rendering prepends, per tier and incumbent group, a condition to `pc-aig-router` pointing at
`canary-<tier>-<incumbent>` (loadbalance: incumbent `1 - share/100`, candidate `share/100`) or
`promoted-<tier>-<incumbent>` (fallback: candidate, incumbent). The base template is never
edited; `rollback` restores the exact base render. Edits are deterministic, idempotent and
validated for every env (reverted when invalid); canaries on sandbox integrations or sandbox
aliases are refused. `.github/workflows/model-canary.yml` runs these commands on platform-api's
dispatches and opens the PR; `aigw apply` pushes the merged change. Details and the rollback
runbook: [`docs/model-harness.md`](../../docs/model-harness.md).

## Enforcement: required metadata and the registered-agent check

1. **Required metadata** (workspace setting): calls without `user_tier`, `job_profile`,
   `agent_id` and `team`, or with values outside the contract, are rejected before any model.
2. **`aig-agent-check`** (first input guardrail, `default.webhook`): Portkey POSTs its webhook
   payload (with the request metadata) to platform-api
   `POST /api/v1/guardrails/agent-check`, authenticated with the `x-aig-webhook-secret` header.
   platform-api answers `{"verdict": true|false, "data": {"reason": ...}}` and denies unknown,
   suspended or other-team agents. `failOnError: true`, so a webhook error also denies.
   IDE traffic always carries an agent: platform-api sends `ide.vscode` when the client sends
   none (`ide.eclipse` and `web.portal` are reserved).

`tool/src/aig_gateway/simulate.py` reproduces this order offline (required metadata -> input
guardrails with real HTTP webhook calls -> routing -> allow-list); `tests/test_matrix.py`
proves missing metadata gets 400 and unknown/suspended agents get 446.

## Guardrail modes per environment

| Guardrail | Hook | local | dev | stage | prod |
|---|---|---|---|---|---|
| `aig-agent-check` (webhook) | input | log | **deny** | **deny** | **deny** |
| `aig-input-pii` | input | log | log | redact | redact |
| `aig-input-injection` | input | log | log | deny | deny |
| `aig-input-policy` (moderation + key-material regex) | input | log | log | deny | deny |
| `aig-output-schema` | output | log | log | log* | log* |
| `aig-output-policy` | output | log | log | deny | deny |
| `aig-output-pii` | output | log | log | redact | redact |

"log" = Portkey `async: true, deny: false` (checked and logged, never blocking); "deny" =
`deny: true` (HTTP 446); "redact" = PII check with `redact: true`, call continues. The agent
check is access control, so it is enforced from dev on (local gateways usually cannot reach a
laptop's platform-api). *The output schema check stays log-only until it is verified that
`default.jsonSchema` passes replies to requests that did not ask for JSON; flip `mode_override`
in `guardrails.yaml` once confirmed.

## Caching decision

**Portkey owns caching** (exact "simple" and semantic; semantic also serves exact hits first):
`cache: {mode: semantic, max_age: 3600}` in stage/prod, shorter in dev, `simple` in local.
`backend/cache-compress` **never caches**; it is a pass-through today and will only compress
large context and keep prompt prefixes byte-stable (so provider prompt caches stay warm).
Nothing is cached twice.

## MCP gateway registry

`mcp-servers.yaml` lists the approved servers (`aig-jira`, `aig-confluence`, `aig-github`),
the workspaces that may use them, the IAM roles (rendered as
`arn:aws:iam::<account>:role/<role>`, roles must belong to those workspaces) and the allowed
tools. `policy.unregistered: deny`: the MCP gateway refuses any server not registered here,
and SDK MCP clients connect only through `AIG_PORTKEY_MCP_URL`. `simulate.mcp_access` and the
tests cover allowed, wrong workspace, wrong role and unregistered.

## Assumptions to verify with AIG's Portkey team

Nothing here has been run against the real self-hosted Portkey yet (see `docs/PROGRESS.md`).

1. **Admin API paths and shapes** (`tool/src/aig_gateway/endpoints.py`, overridable with
   `AIG_PORTKEY_ENDPOINTS_FILE`): `/admin/workspaces`, `/integrations` (or `/virtual-keys` on
   older versions), `/guardrails`, `/mcp-servers`, `/configs`, `/api-keys/{type}/{sub-type}`,
   `/usage-limits`, `/rate-limits`; list responses as `{"data": [...]}` without pagination;
   `PUT` accepts the create body; auth header `x-portkey-api-key`.
2. **Client-chosen slugs** are accepted for workspaces, integrations, guardrails, MCP servers
   and configs (so `pc-aig-router`, `anthropic-prod` and `aig-agent-check` can be referenced
   literally), and config slugs are workspace-scoped (one `pc-aig-router` per workspace). If
   not, switch to per-workspace slugs and set `AIG_PORTKEY_CONFIG` per team.
3. **Integrations are org-level and shareable** with several workspaces (`workspace_ids`), and
   carry `allowed_models` and `configurations.deployments`; guardrails and MCP servers are
   org-level too.
4. **Required metadata** (Apr 2026 changelog) is available in the self-hosted version and is
   configured per workspace as rendered under `settings.required_metadata`; field names to
   confirm.
5. **Guardrail check ids and parameters**: `default.webhook` (`webhookURL`, `headers`,
   `timeout`, `failOnError`), `portkey.pii` (`categories`, `redact`),
   `portkey.promptInjection`, `portkey.moderateContent`, `default.regexMatch` (`rule`, `not`),
   `default.jsonSchema`; actions `deny` / `async`; config keys `input_guardrails` /
   `output_guardrails`; the webhook payload carries `metadata` (platform-api also accepts it
   as a JSON string or under `request.metadata`).
6. **`custom_host` semantics**: Portkey appends the provider endpoint to `custom_host` (so
   leaves end in `/v1`) and forwards the provider auth headers to the custom host.
7. **Usage/rate-limit policy fields** (`conditions`, `group_by`, `credit_limit`,
   `periodic_reset`, `unit: rpm`) and API key `scopes` names.
8. **Conditional-routing edge cases** (missing fields, type coercion, regex flavour) match the
   evaluator; `scripts/gateway-matrix-live.sh` checks the real behaviour.
9. **Real values**: model ids, the OpenAI deployment B host, the cache-compress host, the
   platform-api webhook URL reachable from the gateway, AWS account ids and MCP server URLs.
