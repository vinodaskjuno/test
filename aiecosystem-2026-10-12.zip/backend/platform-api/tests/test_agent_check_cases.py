"""The shared agent-check cases (backend/gateway/simulation/agent-check-cases.json) against the
real webhook endpoint, with the registry from config/agents.example.yaml. The gateway tool's
offline simulator answers with the same verdicts, so both sides agree on the contract."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import yaml
from fastapi.testclient import TestClient

from conftest import PORTKEY_KEY, PROJECT_ROOT, USERS, make_settings
from platform_api.agents import YamlAgentRegistry
from platform_api.main import create_app
from platform_api.secrets import SecretStore
from platform_api.users import YamlUserDirectory

CASES_FILE = Path(
    os.environ.get("AIG_AGENT_CHECK_CASES")
    or PROJECT_ROOT.parent / "gateway" / "simulation" / "agent-check-cases.json"
)
if not CASES_FILE.is_file():
    pytest.skip(f"shared cases not found at {CASES_FILE}", allow_module_level=True)

DATA = json.loads(CASES_FILE.read_text())
SECRET = "whsec-TEST-not-a-real-secret-123456"


def test_cases_use_this_services_example_registry():
    assert DATA["registry"] == "backend/platform-api/config/agents.example.yaml"


@pytest.mark.parametrize("case", DATA["cases"], ids=[c["name"] for c in DATA["cases"]])
def test_shared_case(case):
    registry = YamlAgentRegistry(yaml.safe_load((PROJECT_ROOT / "config" / "agents.example.yaml").read_text()), env="dev")
    app = create_app(
        make_settings("dev", "oidc"),
        secrets=SecretStore({"PORTKEY_API_KEY": PORTKEY_KEY, "PORTKEY_WEBHOOK_SECRET": SECRET}),
        users=YamlUserDirectory(USERS, "standard"),
        agents=registry,
    )
    payload = {
        "request": {"json": {"model": "auto", "messages": [{"role": "user", "content": "hello"}]}, "text": "",
                    "isStreamingRequest": False, "isTransformed": False},
        "response": {}, "provider": "anthropic", "requestType": "chatComplete",
        "metadata": case["metadata"], "eventType": "beforeRequestHook",
    }
    with TestClient(app) as c:
        r = c.post("/api/v1/guardrails/agent-check", json=payload, headers={"x-aig-webhook-secret": SECRET})
    assert r.status_code == 200
    body = r.json()
    assert body["verdict"] is case["verdict"]
    assert body["data"]["reason"] == case["reason"]
