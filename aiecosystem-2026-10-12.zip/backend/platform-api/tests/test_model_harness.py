"""Phase 7 model harness in platform-api: sandbox-only keys, approval gate, canary dispatch."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
import yaml
from conftest import ADMIN_KEY, USERS, assert_no_secrets, configured_secrets, dev_auth, make_settings
from fastapi.testclient import TestClient
from platform_api.errors import StartupError
from platform_api.main import create_app
from platform_api.model_gate import evaluate, load_thresholds, parse_thresholds
from platform_api.model_harness import model_alias, provider_model_id
from platform_api.users import YamlUserDirectory

SERVICE_TOKEN = "svc-SUPERSECRET-55443322110099"
GH_TOKEN = "ghp_SUPERSECRETdispatch0123456789abcdef"
SVC = {"x-aig-service-token": SERVICE_TOKEN}
ADMIN = dev_auth("admin@example.com")
APPROVER = dev_auth("approver@example.com")
JANE = dev_auth("jane@example.com")
ADMIN_API = "http://localhost:8787/v1"  # config/environments/local.yaml portkey_admin_api_url
DISPATCH_URL = "https://api.github.com/repos/aig/aiecosystem/dispatches"
MODEL = {"name": "claude-sonnet-5", "provider": "anthropic", "version": "20261001", "tiers": ["standard"],
         "job_profiles": ["claims"], "use_case": "claims triage", "data_classification": "confidential",
         "expected_monthly_cost_usd": 1200}
GOOD = {"accuracy": 0.91, "faithfulness": 0.95, "safety_critical_failures": 0, "latency_p95_ms": 1800,
        "cost_per_1k_usd": 0.012, "baseline": {"model": "claude-sonnet-4", "accuracy": 0.88, "faithfulness": 0.94},
        "passed": True, "evidence_url": "https://fiddler.example.com/experiments/42", "mode": "fiddler",
        "datasets": [{"name": "claims", "suite": "benchmark", "classification": "synthetic", "cases": 8},
                     {"name": "prompt_injection", "suite": "safety", "classification": "masked", "cases": 10}]}


def build(settings=None, **kw):
    secrets = configured_secrets(**{"PLATFORM_SERVICE_TOKEN": SERVICE_TOKEN, "GITHUB_DISPATCH_TOKEN": GH_TOKEN,
                                    **kw.pop("secrets", {})})
    return create_app(settings or make_settings(**kw), secrets=secrets, users=YamlUserDirectory(USERS, "standard"),
                      agent_hooks=[])


@pytest.fixture
def c():
    with TestClient(build()) as client:
        yield client


def _to(client, mid, to, who=None, **extra):
    who = who or (APPROVER if to in ("approved", "rejected", "promoted", "rolled_back") else SVC)
    return client.post(f"/api/v1/models/{mid}/transition", headers=who, json={"to": to, **extra})


def _new(client, **over):
    return client.post("/api/v1/models", headers=JANE, json={**MODEL, **over}).json()["id"]


def _evaluating(client, card=None, **over):
    mid = _new(client, **over)
    _to(client, mid, "sandbox")
    _to(client, mid, "evaluating")
    if card is not None:
        r = client.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json=card)
        assert r.status_code == 200, r.text
    return mid


def _audit(client, mid):
    return client.get(f"/api/v1/audit?entity_type=model&entity_id={mid}", headers=APPROVER).json()["items"]


# --- naming shared with aigw canary ---------------------------------------------------------------


def test_alias_and_model_id_match_the_gateway_tool():
    # Same table as backend/gateway/tool/tests/test_canary.py::test_alias_and_model_id_derivation.
    assert provider_model_id("claude-sonnet-5", "20261001") == "claude-sonnet-5-20261001"
    assert provider_model_id("gpt-4o-2024-08-06", "2024-08-06") == "gpt-4o-2024-08-06"
    assert provider_model_id("claude-x", "latest") == "claude-x"
    assert model_alias("Claude Sonnet 5", "2026.10") == "claude-sonnet-5-2026-10"
    assert len(model_alias("x" * 80, "v1")) <= 63


def test_new_model_view_has_harness_fields(c):
    m = c.get(f"/api/v1/models/{_new(c)}", headers=JANE).json()
    assert m["sandbox_key_status"] == "not_created" and m["canary_dispatch_status"] == "not_sent"
    assert m["routing_model_id"] == "claude-sonnet-5-20261001" and m["canary_alias"] == "claude-sonnet-5-20261001"
    assert m["gate"] is None and m["ready_for_approval"] is False and m["canary_pr_url"] is None


# --- sandbox-only key -----------------------------------------------------------------------------


def test_sandbox_key_disabled_by_default_makes_no_call(c):
    with respx.mock(assert_all_called=False) as router:
        route = router.post(f"{ADMIN_API}/providers")
        m = _to(c, _new(c), "sandbox").json()
    assert not route.called and m["status"] == "sandbox" and m["sandbox_key_status"] == "disabled"


def test_sandbox_key_created_in_model_sandbox_only():
    with TestClient(build(model_sandbox_sync=True)) as c, respx.mock() as router:
        route = router.post(f"{ADMIN_API}/providers").mock(
            return_value=httpx.Response(201, json={"id": "p-1", "slug": "aig-sbx-fromportkey", "api_key": "sk-ant-SUPERSECRET-x"}))
        mid = _new(c)
        r = _to(c, mid, "sandbox", ADMIN)
        assert r.status_code == 200
        m = r.json()
        assert m["status"] == "sandbox" and m["sandbox_key_status"] == "created" and m["sandbox_key_id"] == "aig-sbx-fromportkey"
        req = route.calls[0].request
        body = json.loads(req.content)
        assert req.headers["x-portkey-api-key"] == ADMIN_KEY
        assert body["workspace_id"] == "model-sandbox" and body["integration_id"] == "anthropic-sandbox"
        assert body["slug"] == f"aig-sbx-{mid[:8]}" and "key" not in body and "api_key" not in body
        assert_no_secrets(r.text) and "sk-ant" not in r.text
        entry = next(a for a in _audit(c, mid) if a["action"] == "model.sandbox_key")
        assert entry["details"] == {"sandbox_key_status": "created", "sandbox_key_id": "aig-sbx-fromportkey", "sandbox_error": None}
        assert "sk-ant" not in json.dumps(_audit(c, mid))


@pytest.mark.parametrize("response,error", [
    (httpx.Response(500, text="internal SUPERSECRET detail"), "returned 500"),
    (httpx.TimeoutException("slow"), "timed out"),
    (httpx.ConnectError("down"), "unreachable"),
])
def test_sandbox_key_failure_is_recorded_and_never_blocks(response, error):
    with TestClient(build(model_sandbox_sync=True)) as c, respx.mock() as router:
        mock = router.post(f"{ADMIN_API}/providers")
        mock.side_effect = response if isinstance(response, Exception) else None
        if not isinstance(response, Exception):
            mock.mock(return_value=response)
        r = _to(c, _new(c), "sandbox")
        assert r.status_code == 200
        m = r.json()
        assert m["status"] == "sandbox" and m["sandbox_key_status"] == "failed" and error in m["sandbox_error"]
        assert "SUPERSECRET" not in r.text


def test_sandbox_key_conflict_counts_as_created():
    with TestClient(build(model_sandbox_sync=True)) as c, respx.mock() as router:
        router.post(f"{ADMIN_API}/providers").mock(return_value=httpx.Response(409))
        mid = _new(c)
        m = _to(c, mid, "sandbox").json()
        assert m["sandbox_key_status"] == "created" and m["sandbox_key_id"] == f"aig-sbx-{mid[:8]}"


def test_sandbox_key_needs_a_sandbox_integration_and_the_admin_key():
    with TestClient(build(model_sandbox_sync=True)) as c, respx.mock(assert_all_called=False) as router:
        route = router.post(f"{ADMIN_API}/providers")
        m = _to(c, _new(c, provider="bedrock"), "sandbox").json()
        assert m["sandbox_key_status"] == "failed" and "no sandbox integration" in m["sandbox_error"]
        assert not route.called
    with TestClient(build(model_sandbox_sync=True, secrets={"PORTKEY_ADMIN_API_KEY": None})) as c:
        m = _to(c, _new(c), "sandbox").json()
        assert m["sandbox_key_status"] == "failed" and "PORTKEY_ADMIN_API_KEY" in m["sandbox_error"]


def test_sandbox_key_refuses_a_production_integration(tmp_path):
    cfg_dir = tmp_path / "config"
    (cfg_dir / "environments").mkdir(parents=True)
    from conftest import PROJECT_ROOT

    data = yaml.safe_load((PROJECT_ROOT / "config" / "environments" / "local.yaml").read_text())
    data["model_sandbox_integrations"] = {"anthropic": "anthropic-prod"}
    (cfg_dir / "environments" / "local.yaml").write_text(yaml.safe_dump(data))
    (cfg_dir / "model-gate-thresholds.yaml").write_text((PROJECT_ROOT / "config" / "model-gate-thresholds.yaml").read_text())
    from platform_api.config import Settings

    settings = Settings(env="local", auth_mode="dev", config_dir=cfg_dir, secrets_dir=tmp_path / "none",
                        model_sandbox_sync=True)
    with TestClient(build(settings)) as c, respx.mock(assert_all_called=False) as router:
        route = router.post(f"{ADMIN_API}/providers")
        m = _to(c, _new(c), "sandbox").json()
        assert m["sandbox_key_status"] == "failed" and "not a sandbox integration" in m["sandbox_error"]
        assert not route.called


# --- approval gate --------------------------------------------------------------------------------


def test_approve_without_scorecard_is_refused_and_audited(c):
    mid = _evaluating(c)
    r = _to(c, mid, "approved", note="looks fine")
    assert r.status_code == 409 and r.json()["error"]["code"] == "approval_gate_failed"
    assert "no scorecard" in r.json()["error"]["message"]
    m = c.get(f"/api/v1/models/{mid}", headers=JANE).json()
    assert m["status"] == "evaluating" and m["decided_by"] is None
    refused = next(a for a in _audit(c, mid) if a["action"] == "model.approval_refused")
    assert refused["actor"] == "approver@example.com" and refused["details"]["gate"]["passed"] is False


def test_admins_cannot_approve_or_bypass(c):
    mid = _evaluating(c, {**GOOD, "latency_p95_ms": 99999})
    assert _to(c, mid, "approved", ADMIN).status_code == 403  # approver role required
    assert _to(c, mid, "approved", SVC).status_code == 403
    assert _to(c, mid, "approved").status_code == 409


def test_passing_scorecard_makes_the_model_ready_and_approval_records_evidence(c):
    mid = _evaluating(c, GOOD)
    m = c.get(f"/api/v1/models/{mid}", headers=JANE).json()
    assert m["gate"]["passed"] is True and m["ready_for_approval"] is True
    assert m["gate"]["tiers"]["standard"]["passed"] is True and m["gate"]["thresholds_status"] == "open-item"
    r = _to(c, mid, "approved", note="meets gate")
    assert r.status_code == 200 and r.json()["status"] == "approved" and r.json()["ready_for_approval"] is False
    entry = next(a for a in _audit(c, mid) if a["details"].get("to") == "approved")
    assert entry["details"]["scorecard"]["accuracy"] == 0.91 and entry["details"]["gate"]["passed"] is True
    assert entry["details"]["scorecard"]["datasets"][0]["classification"] == "synthetic"


@pytest.mark.parametrize("card,tiers,needle", [
    ({**GOOD, "passed": False}, ["standard"], "passed=false"),
    ({**GOOD, "safety_critical_failures": 1}, ["standard"], "critical failure"),
    ({**GOOD, "accuracy": 0.80}, ["standard"], "accuracy"),
    ({**GOOD, "faithfulness": 0.90}, ["standard"], "faithfulness"),
    ({**GOOD, "latency_p95_ms": 6000}, ["standard"], "latency"),
    ({**GOOD, "cost_per_1k_usd": 0.03}, ["standard"], "cost"),
    ({**GOOD, "cost_per_1k_usd": 0.012}, ["standard", "free"], "free: cost"),  # free budget 0.005
    ({**GOOD, "tiers": {"standard": {"passed": False, "failures": ["claims accuracy"]}}}, ["standard"], "marked this tier"),
    ({**GOOD, "tiers": {"standard": {"accuracy": 0.5, "baseline": {"accuracy": 0.9}}}}, ["standard"], "standard: accuracy"),
])
def test_gate_failures_block_approval(c, card, tiers, needle):
    mid = _evaluating(c, card, tiers=tiers, version=f"v-{abs(hash(needle)) % 10**8}")
    m = c.get(f"/api/v1/models/{mid}", headers=JANE).json()
    assert m["gate"]["passed"] is False and m["ready_for_approval"] is False
    r = _to(c, mid, "approved")
    assert r.status_code == 409 and needle in r.json()["error"]["message"], r.json()


def test_gate_passes_for_every_requested_tier(c):
    card = {**GOOD, "cost_per_1k_usd": 0.004, "latency_p95_ms": 3000,
            "tiers": {"premium": {"baseline": {"accuracy": 0.9, "faithfulness": 0.9}, "accuracy": 0.92}}}
    mid = _evaluating(c, card, tiers=["premium", "standard", "free"])
    gate = c.get(f"/api/v1/models/{mid}", headers=JANE).json()["gate"]
    assert gate["passed"] and set(gate["tiers"]) == {"premium", "standard", "free"}
    assert _to(c, mid, "approved").status_code == 200


def test_reject_records_the_evidence(c):
    mid = _evaluating(c, {**GOOD, "safety_critical_failures": 2, "passed": False})
    r = _to(c, mid, "rejected", note="jailbreak suite failed")
    assert r.status_code == 200 and r.json()["status"] == "rejected"
    entry = next(a for a in _audit(c, mid) if a["details"].get("to") == "rejected")
    assert entry["details"]["note"] == "jailbreak suite failed"
    assert entry["details"]["scorecard"]["safety_critical_failures"] == 2 and entry["details"]["gate"]["passed"] is False
    assert _to(c, mid, "canary", ADMIN).status_code == 409  # a rejected model never gets a production route


def test_scorecard_policy_refuses_offline_runs_and_unclassified_data(c):
    mid = _evaluating(c)
    r = c.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json={**GOOD, "mode": "offline"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "offline_scorecard_refused"
    bad = {**GOOD, "datasets": [{"name": "prod-claims-export", "classification": "confidential"}]}
    r = c.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json=bad)
    assert r.status_code == 400 and r.json()["error"]["code"] == "dataset_classification_refused"
    assert "prod-claims-export" in r.json()["error"]["message"]
    assert c.get(f"/api/v1/models/{mid}", headers=JANE).json()["scorecard"] is None


# --- thresholds config ----------------------------------------------------------------------------


def test_thresholds_file_is_validated():
    from conftest import PROJECT_ROOT

    t = load_thresholds(PROJECT_ROOT / "config" / "model-gate-thresholds.yaml")
    assert set(t["tiers"]) == {"premium", "standard", "free"}
    assert all(v["max_critical_safety_failures"] == 0 for v in t["tiers"].values())
    good = yaml.safe_load((PROJECT_ROOT / "config" / "model-gate-thresholds.yaml").read_text())
    for mutate, needle in (
        (lambda d: d["tiers"]["premium"].update(max_critical_safety_failures=1), "must be 0"),
        (lambda d: d["tiers"].pop("free"), "tier free has no thresholds"),
        (lambda d: d["tiers"]["standard"].pop("max_cost_per_1k_usd"), "misses"),
        (lambda d: d["tiers"]["standard"].update(max_latency_p95_ms="fast"), "must be a number"),
        (lambda d: d["tiers"].update(gold={}), "unknown tier"),
    ):
        doc = yaml.safe_load(yaml.safe_dump(good))
        mutate(doc)
        with pytest.raises(ValueError, match=needle):
            parse_thresholds(doc)


def test_missing_thresholds_fail_closed(tmp_path):
    missing = tmp_path / "nope.yaml"
    with pytest.raises(StartupError, match="thresholds"):
        build(env="dev", auth_mode="oidc", model_gate_thresholds_file=missing)
    with TestClient(build(model_gate_thresholds_file=missing)) as c:  # local: starts, approvals refused
        mid = _evaluating(c, GOOD)
        r = _to(c, mid, "approved")
        assert r.status_code == 409 and "not configured" in r.json()["error"]["message"]


def test_evaluate_without_baseline_only_applies_absolute_limits():
    from conftest import PROJECT_ROOT

    t = load_thresholds(PROJECT_ROOT / "config" / "model-gate-thresholds.yaml")
    gate = evaluate({**GOOD, "baseline": {}}, ["standard"], t)
    assert gate["passed"] and any("no baseline" in n for n in gate["tiers"]["standard"]["notes"])


# --- canary dispatch ------------------------------------------------------------------------------


def _approved(client):
    mid = _evaluating(client, GOOD)
    assert _to(client, mid, "approved").status_code == 200
    return mid


def test_dispatch_disabled_by_default(c):
    mid = _approved(c)
    with respx.mock(assert_all_called=False) as router:
        route = router.post(DISPATCH_URL)
        m = _to(c, mid, "canary", ADMIN).json()
    assert not route.called and m["canary_dispatch_status"] == "disabled"


def test_canary_promote_rollback_dispatch_repository_events():
    with TestClient(build(canary_dispatch=True, github_repo="aig/aiecosystem")) as c, respx.mock() as router:
        route = router.post(DISPATCH_URL).mock(return_value=httpx.Response(204))
        a = _approved(c)
        r = _to(c, a, "canary", ADMIN, canary_share=5, note="start canary")
        assert r.status_code == 200 and r.json()["canary_dispatch_status"] == "dispatched"
        assert_no_secrets(r.text) and GH_TOKEN not in r.text
        req = route.calls[0].request
        body = json.loads(req.content)
        assert req.headers["authorization"] == f"Bearer {GH_TOKEN}"
        assert req.headers["accept"] == "application/vnd.github+json"
        assert body["event_type"] == "model_canary"
        assert body["client_payload"] == {"model_id": a, "alias": "claude-sonnet-5-20261001",
                                          "model": "claude-sonnet-5-20261001", "provider": "anthropic",
                                          "tiers": ["standard"], "share": 5.0, "state": "canary", "env": "local",
                                          "note": "start canary"}
        assert len(body["client_payload"]) <= 10  # GitHub's limit
        assert _to(c, a, "promoted").json()["canary_dispatch_status"] == "dispatched"
        assert json.loads(route.calls[1].request.content)["event_type"] == "model_promote"
        b = _approved_v(c, "v-rb")
        _to(c, b, "canary", ADMIN)
        assert _to(c, b, "rolled_back", note="error rate").json()["canary_dispatch_status"] == "dispatched"
        assert json.loads(route.calls[-1].request.content)["event_type"] == "model_rollback"
        events = [x["details"].get("event") for x in _audit(c, b) if x["action"] == "model.canary_dispatch"]
        assert events == ["model_rollback", "model_canary"]
        assert GH_TOKEN not in json.dumps(_audit(c, a))


def _approved_v(client, version):
    mid = _evaluating(client, GOOD, version=version)
    assert _to(client, mid, "approved").status_code == 200
    return mid


@pytest.mark.parametrize("kw,error", [
    ({"github_repo": None}, "AIG_GITHUB_REPO"),
    ({"github_repo": "aig/aiecosystem", "secrets": {"GITHUB_DISPATCH_TOKEN": None}}, "GITHUB_DISPATCH_TOKEN"),
])
def test_dispatch_misconfiguration_is_recorded(kw, error):
    with TestClient(build(canary_dispatch=True, **kw)) as c:
        mid = _approved(c)
        m = _to(c, mid, "canary", ADMIN).json()
        assert m["status"] == "canary" and m["canary_dispatch_status"] == "failed" and error in m["canary_dispatch_error"]


def test_dispatch_failure_never_blocks_the_transition():
    with TestClient(build(canary_dispatch=True, github_repo="aig/aiecosystem")) as c, respx.mock() as router:
        router.post(DISPATCH_URL).mock(return_value=httpx.Response(404, text="Not Found SUPERSECRET"))
        mid = _approved(c)
        r = _to(c, mid, "canary", ADMIN)
        assert r.status_code == 200 and r.json()["status"] == "canary"
        assert r.json()["canary_dispatch_status"] == "failed" and "404" in r.json()["canary_dispatch_error"]
        assert "SUPERSECRET" not in r.text


def test_canary_pr_is_recorded_by_the_workflow(c):
    mid = _approved(c)
    url = "https://github.com/aig/aiecosystem/pull/42"
    assert c.put(f"/api/v1/models/{mid}/canary-pr", headers=SVC, json={"url": url}).json()["error"]["code"] == "invalid_transition"
    _to(c, mid, "canary", ADMIN)
    assert c.put(f"/api/v1/models/{mid}/canary-pr", headers=JANE, json={"url": url}).status_code == 403
    assert c.put(f"/api/v1/models/{mid}/canary-pr", headers=SVC, json={"url": "http://x"}).status_code == 400
    m = c.put(f"/api/v1/models/{mid}/canary-pr", headers=SVC, json={"url": url}).json()
    assert m["canary_pr_url"] == url
    assert any(a["action"] == "model.canary_pr" and a["details"]["url"] == url for a in _audit(c, mid))
