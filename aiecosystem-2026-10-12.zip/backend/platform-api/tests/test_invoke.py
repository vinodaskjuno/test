"""Agent invocation over HTTP: sync / stream / background / cancel / timeout through the HTTPS
invoker (a tiny local agent app implementing aig-http/1, plus respx for wire-level cases), access
and input validation, caller token, invocation records, audit, and no secret leaks."""

from __future__ import annotations

import asyncio
import json
import logging

import httpx
import jwt
import pytest
import respx
from agent_helpers import (
    ADMIN,
    AGENT_API_KEY,
    BOB,
    CARA,
    ENDPOINT,
    GINA,
    OLGA,
    SVC,
    TestAgent,
    active_agent,
    audit,
    build_app,
    ec_pem,
    parse_sse,
    register_agent,
    register_version,
    wait_for,
)
from conftest import assert_no_secrets
from cryptography.fernet import Fernet
from fastapi.testclient import TestClient

from platform_api.agent_secrets import DefaultSecretResolver
from platform_api.errors import StartupError

INVOKE = "/api/v1/agents/claims-triage/invoke"


@pytest.fixture
def agent():
    return TestAgent()


@pytest.fixture
def c(agent):
    with TestClient(build_app(agent=agent)) as client:
        active_agent(client)
        yield client


# --- sync ---------------------------------------------------------------------------------------


def test_sync_invoke_signs_caller_token_and_records(c, agent):
    r = c.post(INVOKE, headers={**CARA, "x-aig-trace-id": "trace-claims-0001"},
               json={"input": {"claim_id": "CLM-4411"}, "session_id": "case-4411"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["status"] == "succeeded" and body["env"] == "prod" and body["version"] == "1.0.0"
    assert body["output"] == {"claim_id": "CLM-4411", "user": "cara@example.com", "team": "claims-ai",
                              "groups": [], "messages": 0}
    assert body["usage"] == {"prompt_tokens": 11, "completion_tokens": 7, "total_tokens": 18}
    assert body["trace_id"] == "trace-claims-0001" == r.headers["x-aig-trace-id"]
    inv_id = body["invocation_id"]
    assert r.headers["x-aig-invocation-id"] == inv_id
    # What the agent received: contract headers + body, and a token it verified (aud = agent id).
    sent = agent.requests[-1]
    assert sent["body"] == {"input": {"claim_id": "CLM-4411"}, "session_id": "case-4411", "stream": False}
    assert sent["headers"]["x-aig-invocation-id"] == inv_id and sent["headers"]["accept"] == "application/json"
    claims = agent.claims[-1]
    assert claims["iss"] == "aig-platform-api/local" and claims["aud"] == "claims-triage"
    assert claims["tier"] == "premium" and claims["name"] == "Cara Claims" and claims["env"] == "prod"
    assert claims["jti"] == claims["invocation_id"] == inv_id and claims["exp"] - claims["iat"] == 300
    header = jwt.get_unverified_header(sent["headers"]["x-aig-caller"])
    assert header["alg"] == "ES256" and header["typ"] == "aig-caller+jwt"
    assert header["kid"] == c.get("/api/v1/caller-token/jwks").json()["keys"][0]["kid"]
    # The record: metadata only.
    rec = c.get(f"/api/v1/invocations/{inv_id}", headers=CARA).json()
    assert rec["status"] == "succeeded" and rec["mode"] == "sync" and rec["caller"] == "cara@example.com"
    assert rec["usage"]["total_tokens"] == 18 and rec["duration_ms"] >= 0 and rec["session_id"] == "case-4411"
    assert rec["output"] is None and rec["output_available"] is False  # output is stored for background runs only
    entry = [e for e in audit(c, entity_type="agent_invocation") if e["entity_id"] == inv_id]
    assert entry[0]["action"] == "agent.invoke" and entry[0]["details"]["mode"] == "sync"
    assert "CLM-4411" not in json.dumps(audit(c))


def test_chat_mode_and_jwks_are_public(c, agent):
    r = c.post(INVOKE, headers=BOB, json={"messages": [{"role": "user", "content": "hi"}]})
    assert r.json()["output"]["messages"] == 1
    jwks = c.get("/api/v1/caller-token/jwks")
    assert jwks.status_code == 200 and jwks.json()["keys"][0]["crv"] == "P-256"
    assert "d" not in jwks.json()["keys"][0]  # public key only
    assert jwks.headers["cache-control"].startswith("public")


@pytest.mark.parametrize("body,fragment", [
    ({"input": {"claim_id": "1"}, "messages": [{"role": "user", "content": "x"}]}, "exactly one"),
    ({}, "exactly one"),
    ({"input": {"notes": "no id"}}, "input.claim_id"),
    ({"input": {"claim_id": 5}}, "input.claim_id"),
    ({"input": {"claim_id": "1", "extra": True}}, "input.extra"),
    ({"input": "text"}, "must be an object"),
    ({"messages": [{"role": "robot", "content": "x"}]}, "messages.0"),
    ({"input": {"claim_id": "1"}, "session_id": "bad id!"}, "session_id"),
    ({"input": {"claim_id": "1"}, "aig_context": {"caller": "forged"}}, "aig_context"),
])
def test_input_validation(c, agent, body, fragment):
    before = len(agent.requests)
    r = c.post(INVOKE, headers=BOB, json=body)
    assert r.status_code == 400, r.text
    assert r.json()["error"]["code"] == "input_invalid" and fragment in r.json()["error"]["message"]
    assert len(agent.requests) == before  # nothing reached the agent


def test_access_rules(c):
    assert c.post(INVOKE, headers=OLGA, json={"input": {"claim_id": "1"}}).json()["error"]["code"] == "agent_forbidden"
    assert c.post(INVOKE, headers=GINA, json={"input": {"claim_id": "1"}}).status_code == 403
    c.put("/api/v1/agents/claims-triage/access", headers=BOB, json={"visibility": "groups", "allowed_groups": ["UW-Analysts"]})
    r = c.post(INVOKE, headers=GINA, json={"input": {"claim_id": "1"}})
    assert r.status_code == 200 and r.json()["output"]["groups"] == ["UW-Analysts"]
    c.put("/api/v1/agents/claims-triage/access", headers=BOB, json={"visibility": "org"})
    r = c.post(INVOKE, headers=OLGA, json={"input": {"claim_id": "1"}})
    assert r.status_code == 403 and r.json()["error"]["code"] == "org_approval_required"
    c.post("/api/v1/agents/claims-triage/access/approve", headers=ADMIN)
    assert c.post(INVOKE, headers=OLGA, json={"input": {"claim_id": "1"}}).status_code == 200
    # Non-team callers only run prod.
    r = c.post(INVOKE + "?env=dev", headers=OLGA, json={"input": {"claim_id": "1"}})
    assert r.status_code == 403 and r.json()["error"]["code"] == "agent_forbidden"
    assert c.post("/api/v1/agents/nope/invoke", headers=BOB, json={"input": {}}).status_code == 404
    assert c.post(INVOKE, headers=SVC, json={"input": {"claim_id": "1"}}).status_code == 401  # users only


def test_lifecycle_and_version_selection(c, agent):
    # Team may run unverified non-prod versions; users never.
    register_version(c, version="2.0.0-rc.1", env="dev")
    r = c.post(INVOKE + "?env=dev", headers=CARA, json={"input": {"claim_id": "1"}})
    assert r.status_code == 200 and r.json()["version"] == "2.0.0-rc.1"
    assert agent.claims[-1]["env"] == "dev"
    # Explicit versions.
    assert c.post(INVOKE + "?version=1.0.0", headers=BOB, json={"input": {"claim_id": "1"}}).json()["version"] == "1.0.0"
    r = c.post(INVOKE + "?version=9.9.9", headers=BOB, json={"input": {"claim_id": "1"}})
    assert r.status_code == 404 and r.json()["error"]["code"] == "version_not_found"
    register_version(c, version="1.1.0")  # newer but unverified prod version: not picked
    assert c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}}).json()["version"] == "1.0.0"
    r = c.post(INVOKE + "?version=1.1.0&env=prod", headers=BOB, json={"input": {"claim_id": "1"}})
    assert r.status_code == 409 and r.json()["error"]["code"] == "agent_not_invocable"
    # Suspended / retired / built-in agents are not invocable.
    c.post("/api/v1/agents/claims-triage/suspend", headers=SVC, json={"reason": "no traces"})
    assert c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}}).json()["error"]["code"] == "agent_not_invocable"
    c.post("/api/v1/agents/claims-triage/reinstate", headers=SVC, json={"reason": "fixed"})
    c.post("/api/v1/agents/claims-triage/lifecycle", headers=BOB, json={"to": "retired"})
    assert c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}}).status_code == 409
    assert c.post("/api/v1/agents/ide.vscode/invoke", headers=BOB, json={"messages": [{"role": "user", "content": "x"}]}
                  ).json()["error"]["code"] in ("agent_forbidden", "agent_not_invocable")


def test_draft_agents_run_for_the_team_outside_prod(agent):
    with TestClient(build_app(agent=agent)) as c:
        register_agent(c)
        register_version(c, headers=BOB, env="dev")
        register_version(c, headers=BOB, env="prod", version="1.0.0")
        assert c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}}).json()["env"] == "dev"
        r = c.post(INVOKE + "?env=prod", headers=BOB, json={"input": {"claim_id": "1"}})
        assert r.status_code == 409 and "draft" in r.json()["error"]["message"]
        assert c.post(INVOKE, headers=OLGA, json={"input": {"claim_id": "1"}}).status_code == 403


def test_agent_failures_map_to_contract_codes(c):
    r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1", "mode": "fail"}})
    assert r.status_code == 502 and r.json()["error"] == {"code": "agent_error", "message": "model call failed"}
    r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1", "mode": "deny"}})
    assert r.status_code == 400 and r.json()["error"]["code"] == "input_invalid"
    inv = c.get("/api/v1/invocations?mine=1", headers=BOB).json()["items"]
    assert [i["status"] for i in inv[:2]] == ["failed", "failed"]
    assert inv[1]["error_code"] == "agent_error"


@respx.mock(assert_all_called=False)
def test_wire_errors_with_respx(respx_mock):
    with TestClient(build_app()) as c:
        active_agent(c)
        route = respx_mock.post(f"{ENDPOINT}/invocations")
        cases = [
            (httpx.Response(401, json={"error": {"code": "caller_unauthenticated", "message": "bad token"}}), 502, "agent_unavailable"),
            (httpx.Response(429), 503, "agent_unavailable"),
            (httpx.Response(504), 504, "invocation_timeout"),
            (httpx.Response(200, json={"no": "output"}), 502, "agent_error"),
            (httpx.Response(200, content=b"not json", headers={"content-type": "application/json"}), 502, "agent_error"),
            (httpx.ConnectError("refused"), 502, "agent_unavailable"),
        ]
        for response, status, code in cases:
            if isinstance(response, Exception):
                route.mock(side_effect=response)
            else:
                route.mock(side_effect=None, return_value=response)
            r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}})
            assert (r.status_code, r.json()["error"]["code"]) == (status, code), r.text


# --- stream -------------------------------------------------------------------------------------


def test_stream_mode_relays_sse(c, agent):
    with c.stream("POST", INVOKE + "?mode=stream", headers=BOB, json={"input": {"claim_id": "CLM-9"}}) as r:
        assert r.status_code == 200 and r.headers["content-type"].startswith("text/event-stream")
        text = r.read().decode()
    events = parse_sse(text)
    assert [e["event"] for e in events] == ["delta", "delta", "output", "done"]
    assert "".join(e["data"]["text"] for e in events if e["event"] == "delta") == "Severity: HIGH"
    inv_id = events[-1]["data"]["invocation_id"]
    assert all(e["data"]["invocation_id"] == inv_id for e in events)
    assert events[2]["data"]["output"]["claim_id"] == "CLM-9" and events[2]["data"]["usage"]["total_tokens"] == 18
    assert events[-1]["data"]["status"] == "succeeded"
    assert agent.requests[-1]["body"]["stream"] is True
    assert agent.requests[-1]["headers"]["accept"] == "text/event-stream"
    assert c.get(f"/api/v1/invocations/{inv_id}", headers=BOB).json()["mode"] == "stream"
    # body.stream=true selects stream mode too; errors arrive in-band.
    with c.stream("POST", INVOKE, headers=BOB, json={"input": {"claim_id": "1", "mode": "fail"}, "stream": True}) as r:
        events = parse_sse(r.read().decode())
    assert [e["event"] for e in events] == ["error", "done"]
    assert events[0]["data"]["code"] == "agent_error" and events[1]["data"]["status"] == "failed"


@respx.mock(assert_all_called=False)
def test_stream_parses_split_frames_comments_and_truncation(respx_mock):
    async def chunks():
        yield b": keepalive\n\nevent: del"
        yield b'ta\ndata: {"text":"Hel'
        yield b'lo"}\n\nevent: progress\ndata: {}\n\n'
        yield b'event: output\ndata: {"output":"Hello","usage":{"total_tokens":3,"cost":1}}\n\nevent: done\ndata: {}\n\n'

    with TestClient(build_app()) as c:
        active_agent(c)
        respx_mock.post(f"{ENDPOINT}/invocations").mock(
            return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, content=chunks()))
        events = parse_sse(c.post(INVOKE + "?mode=stream", headers=BOB, json={"input": {"claim_id": "1"}}).text)
        assert [e["event"] for e in events] == ["delta", "output", "done"]
        assert events[1]["data"]["usage"] == {"total_tokens": 3}
        respx_mock.post(f"{ENDPOINT}/invocations").mock(return_value=httpx.Response(
            200, headers={"content-type": "text/event-stream"}, content=b'event: delta\ndata: {"text":"part"}\n\n'))
        events = parse_sse(c.post(INVOKE + "?mode=stream", headers=BOB, json={"input": {"claim_id": "1"}}).text)
        assert [e["event"] for e in events] == ["delta", "error", "done"]
        assert events[1]["data"]["message"] == "agent stream ended unexpectedly"


# --- timeout / background / cancel --------------------------------------------------------------


def test_sync_timeout(agent):
    with TestClient(build_app(agent=agent, agent_sync_timeout_seconds=0.3)) as c:
        active_agent(c)
        r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1", "mode": "slow"}})
        assert r.status_code == 504 and r.json()["error"]["code"] == "invocation_timeout"
        inv = c.get("/api/v1/invocations?mine=1", headers=BOB).json()["items"][0]
        assert inv["status"] == "timeout" and inv["error_code"] == "invocation_timeout"


def test_background_run_stores_encrypted_output(c, agent):
    r = c.post(INVOKE + "?mode=background", headers=CARA, json={"input": {"claim_id": "CLM-7"}})
    assert r.status_code == 202, r.text
    body = r.json()
    assert body["status"] == "queued" and r.headers["location"] == body["location"] == f"/api/v1/invocations/{body['invocation_id']}"
    url = body["location"]
    rec = wait_for(lambda: (x := c.get(url, headers=CARA).json())["status"] == "succeeded" and x)
    assert rec["output"]["claim_id"] == "CLM-7" and rec["output_available"] is True and rec["output_expires_at"]
    # The owner sees the output, an admin only the metadata, others nothing.
    assert c.get(url, headers=BOB).json()["output"]["claim_id"] == "CLM-7"
    admin_view = c.get(url, headers=ADMIN).json()
    assert admin_view["status"] == "succeeded" and admin_view["output"] is None and admin_view["output_available"] is False
    assert c.get(url, headers=OLGA).status_code == 404
    # Stored encrypted, never in plain text.
    from sqlalchemy import select

    from platform_api.db import AgentInvocationRow

    with c.app.state.db.session() as s:
        stored = s.scalar(select(AgentInvocationRow.output_encrypted).where(AgentInvocationRow.id == body["invocation_id"]))
    assert stored and "CLM-7" not in stored
    # Listing: own runs, runs of owned agents; mine=1 only own.
    assert body["invocation_id"] in [i["id"] for i in c.get("/api/v1/invocations", headers=BOB).json()["items"]]
    assert c.get("/api/v1/invocations?mine=1", headers=BOB).json()["items"] == []
    assert c.get("/api/v1/invocations", headers=OLGA).json()["items"] == []
    assert len(c.get("/api/v1/invocations?agent_id=claims-triage", headers=ADMIN).json()["items"]) == 1
    # Cancel of a finished run.
    r = c.post(f"{url}/cancel", headers=CARA)
    assert r.status_code == 409 and r.json()["error"]["code"] == "invocation_finished"


def test_background_cancel_and_limits(agent):
    with TestClient(build_app(agent=agent, agent_max_background_per_user=1)) as c:
        active_agent(c)
        r = c.post(INVOKE + "?mode=background", headers=BOB, json={"input": {"claim_id": "1", "mode": "slow"}})
        url = r.json()["location"]
        wait_for(lambda: c.get(url, headers=BOB).json()["status"] == "running")
        r = c.post(INVOKE + "?mode=background", headers=BOB, json={"input": {"claim_id": "2"}})
        assert r.status_code == 429 and r.json()["error"]["code"] == "too_many_requests"
        assert c.post(f"{url}/cancel", headers=OLGA).status_code == 404
        r = c.post(f"{url}/cancel", headers=BOB)
        assert r.status_code == 200 and r.json()["status"] == "cancelled"
        rec = c.get(url, headers=BOB).json()
        assert rec["status"] == "cancelled" and rec["error_code"] == "invocation_cancelled"
        assert any(e["action"] == "agent.invocation.cancel" for e in audit(c, entity_type="agent_invocation"))


def test_background_needs_output_key_outside_local(agent):
    secrets = {"AGENT_CALLER_SIGNING_KEY": ec_pem()}
    app = build_app(env="dev", agent=agent, secrets=secrets)
    app.state.authenticator.dev_mode = True  # the dev token path only; the policy under test is the key
    with TestClient(app) as c:
        c.post("/api/v1/agents", headers=SVC, json={"agent_id": "claims-triage", "owner": "bob@example.com", "team": "claims-ai"})
        register_version(c, verified=True, activate=True)
        r = c.post(INVOKE + "?mode=background", headers=BOB, json={"input": {"claim_id": "1"}})
        assert r.status_code == 503 and r.json()["error"]["code"] == "output_encryption_not_configured"
        assert c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}}).status_code == 200
    app = build_app(env="dev", agent=agent, secrets={**secrets, "AGENT_OUTPUT_ENCRYPTION_KEY": Fernet.generate_key().decode()})
    app.state.authenticator.dev_mode = True
    with TestClient(app) as c:
        c.post("/api/v1/agents", headers=SVC, json={"agent_id": "claims-triage", "owner": "bob@example.com", "team": "claims-ai"})
        register_version(c, verified=True, activate=True)
        assert c.post(INVOKE + "?mode=background", headers=BOB, json={"input": {"claim_id": "1"}}).status_code == 202


def test_restart_marks_open_background_runs_cancelled():
    from platform_api.db import Database
    from platform_api.invocations import InvocationStore

    db = Database.in_memory()
    store = InvocationStore(db)
    store.create(invocation_id="11111111-1111-4111-8111-111111111111", agent_id="a", version="1", env="prod",
                 caller="bob@example.com", team="t", mode="background", purpose="invoke", trace_id="t" * 8, session_id=None)
    assert store.mark_interrupted() == 1
    assert store.get("11111111-1111-4111-8111-111111111111").status == "cancelled"


# --- invocation switched off / keys -------------------------------------------------------------


def test_invocation_disabled_without_signing_key_outside_local(agent):
    app = build_app(env="dev", agent=agent)
    app.state.authenticator.dev_mode = True
    with TestClient(app) as c:
        c.post("/api/v1/agents", headers=SVC, json={"agent_id": "claims-triage", "owner": "bob@example.com", "team": "claims-ai"})
        register_version(c, verified=True, activate=True)
        r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}})
        assert r.status_code == 503 and r.json()["error"]["code"] == "agent_invocation_disabled"
        assert c.get("/api/v1/caller-token/jwks").status_code == 503
    with pytest.raises(StartupError, match="AGENT_CALLER_SIGNING_KEY"):
        build_app(env="dev", agent_invocation=True)
    with pytest.raises(StartupError, match="AGENT_CALLER_SIGNING_KEY"):
        build_app(env="dev", secrets={"AGENT_CALLER_SIGNING_KEY": "not-a-key"})
    with TestClient(build_app(agent=agent, agent_invocation=False)) as c:
        active_agent(c)
        assert c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}}).json()["error"]["code"] == "agent_invocation_disabled"


def test_signing_key_formats():
    import base64

    from platform_api.caller_token import SigningKeyError, load_private_key

    pem = ec_pem()
    k1 = load_private_key(pem)
    k2 = load_private_key(base64.b64encode(pem.encode()).decode())
    k3 = load_private_key(pem.replace("\n", "\\n"))
    assert k1.private_numbers() == k2.private_numbers() == k3.private_numbers()
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec

    p384 = ec.generate_private_key(ec.SECP384R1()).private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
    with pytest.raises(SigningKeyError, match="P-256"):
        load_private_key(p384)
    with pytest.raises(SigningKeyError) as exc:
        load_private_key("-----BEGIN PRIVATE KEY-----\nSUPERSECRET\n-----END PRIVATE KEY-----")
    assert "SUPERSECRET" not in str(exc.value)


# --- agent credentials --------------------------------------------------------------------------


def test_api_key_from_local_secret_never_leaks(agent, caplog, monkeypatch):
    monkeypatch.setenv("CLAIMS_AGENT_KEY", AGENT_API_KEY)
    caplog.set_level(logging.DEBUG)
    with TestClient(build_app(agent=agent)) as c:
        register_agent(c)
        register_version(c, auth={"type": "api_key", "secret_arn": "local:CLAIMS_AGENT_KEY"}, verified=True, activate=True)
        r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}})
        assert r.status_code == 200
        assert agent.requests[-1]["headers"]["x-api-key"] == AGENT_API_KEY
        texts = [r.text, c.get("/api/v1/agents/claims-triage/versions", headers=BOB).text,
                 c.get("/api/v1/invocations", headers=BOB).text, json.dumps(audit(c))]
        for t in texts:
            assert AGENT_API_KEY not in t
            assert_no_secrets(t)
    assert AGENT_API_KEY not in caplog.text and "SUPERSECRET" not in caplog.text


@respx.mock(assert_all_called=False)
def test_oauth_client_credentials_and_redaction(respx_mock):
    secret = json.dumps({"token_url": "https://login.example.com/token", "client_id": "aig-platform",
                         "client_secret": "oauth-SUPERSECRET-client", "scope": "agents/invoke"})

    class Resolver:
        def resolve(self, ref):
            assert ref.startswith("arn:aws:secretsmanager:")
            return secret

    token_route = respx_mock.post("https://login.example.com/token").mock(
        return_value=httpx.Response(200, json={"access_token": "tok-SUPERSECRET-abc", "expires_in": 3600}))
    agent_route = respx_mock.post(f"{ENDPOINT}/invocations").mock(return_value=httpx.Response(
        200, json={"output": {"echo": "tok-SUPERSECRET-abc"}, "trace_id": "trace-1234567"}))
    with TestClient(build_app(secret_resolver=Resolver())) as c:
        register_agent(c)
        register_version(c, auth={"type": "oauth_client_credentials",
                                  "secret_arn": "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/prod/agents/x-AbC"},
                         verified=True, activate=True)
        r1 = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}})
        r2 = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "2"}})
        assert r1.status_code == r2.status_code == 200
        assert agent_route.calls[0].request.headers["authorization"] == "Bearer tok-SUPERSECRET-abc"
        assert token_route.call_count == 1  # cached until 60 s before expiry
        form = token_route.calls[0].request.content.decode()
        assert "grant_type=client_credentials" in form and "scope=agents%2Finvoke" in form
        # The agent echoed the token: redacted in the response.
        assert r1.json()["output"] == {"echo": "***redacted***"}
        assert "SUPERSECRET" not in r1.text + r2.text


def test_unresolvable_secret_is_agent_unavailable(agent):
    with TestClient(build_app(agent=agent)) as c:
        register_agent(c)
        register_version(c, auth={"type": "api_key", "secret_arn": "local:MISSING_AGENT_KEY_X"}, verified=True, activate=True)
        r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}})
        assert r.status_code == 502 and r.json()["error"]["code"] == "agent_unavailable"
        assert "MISSING_AGENT_KEY_X" not in r.text


def test_secret_resolver_aws_and_local_rules(tmp_path):
    class Fake:
        calls = 0

        def get_secret_value(self, SecretId):
            Fake.calls += 1
            return {"SecretString": "v-SUPERSECRET"}

    seen: list[str] = []
    arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/agents/a/invoke-auth-AbC"
    r = DefaultSecretResolver(env="dev", secrets_dir=tmp_path, register_redaction=seen.append, client_factory=Fake)
    assert r.resolve(arn) == "v-SUPERSECRET" and r.resolve(arn) == "v-SUPERSECRET" and Fake.calls == 1
    assert seen == ["v-SUPERSECRET"]
    from platform_api.agent_secrets import AgentAuthError

    with pytest.raises(AgentAuthError):
        r.resolve("local:X")
    (tmp_path / ".env.local").write_text("FILE_KEY=from-file\n")
    local = DefaultSecretResolver(env="local", secrets_dir=tmp_path, environ={})
    assert local.resolve("local:FILE_KEY") == "from-file"


def test_retention_purge():
    from datetime import timedelta

    from platform_api.db import AgentInvocationRow, Database, utcnow
    from platform_api.invocations import InvocationStore

    db = Database.in_memory()
    store = InvocationStore(db)
    store.create(invocation_id="22222222-2222-4222-8222-222222222222", agent_id="a", version="1", env="prod",
                 caller="b@example.com", team="t", mode="background", purpose="invoke", trace_id="t" * 8, session_id=None,
                 status="running")
    store.finish("22222222-2222-4222-8222-222222222222", status="succeeded", output_encrypted="gAAAA-token")
    with db.session() as s:
        row = s.get(AgentInvocationRow, "22222222-2222-4222-8222-222222222222")
        row.output_expires_at = utcnow() - timedelta(days=1)
    store.purge_expired(force=True)
    assert store.get("22222222-2222-4222-8222-222222222222").has_output is False
    with db.session() as s:
        s.get(AgentInvocationRow, "22222222-2222-4222-8222-222222222222").retain_until = utcnow() - timedelta(days=1)
    store.purge_expired(force=True)
    assert store.get("22222222-2222-4222-8222-222222222222") is None


def test_keepalive_comments_on_silent_streams(monkeypatch, agent):
    import platform_api.routes.invoke as invoke_mod

    monkeypatch.setattr(invoke_mod, "KEEPALIVE_SECONDS", 0.05)

    async def slow_events(handle):
        await asyncio.sleep(0.2)
        yield {"event": "done", "data": {"invocation_id": handle.id, "status": "succeeded", "duration_ms": 1}}

    with TestClient(build_app(agent=agent)) as c:
        active_agent(c)
        monkeypatch.setattr(c.app.state.invoker, "run", slow_events)
        text = c.post(INVOKE + "?mode=stream", headers=BOB, json={"input": {"claim_id": "1"}}).text
        assert text.startswith(": keepalive") and "event: done" in text


def test_cors_exposes_invocation_id_header():
    """Browsers must be able to read x-aig-invocation-id when a stream starts (web portal)."""
    from fastapi.testclient import TestClient

    from conftest import make_app

    app = make_app()
    with TestClient(app) as c:
        r = c.options(
            "/api/v1/catalog",
            headers={"Origin": "http://localhost:3000", "Access-Control-Request-Method": "GET"},
        )
        r2 = c.get("/healthz", headers={"Origin": "http://localhost:3000"})
    exposed = (r2.headers.get("access-control-expose-headers") or "").lower()
    assert r.status_code in (200, 204)
    assert "x-aig-invocation-id" in exposed and "x-aig-trace-id" in exposed
