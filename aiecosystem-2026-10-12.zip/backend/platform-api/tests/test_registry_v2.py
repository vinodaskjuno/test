"""Registry v2: draft registration, versions (auth + validation), lifecycle, access + approvals,
catalog filtering, gateway rules for draft/retired agents, groups claims, audit, migration."""

from __future__ import annotations

import pytest
from agent_helpers import (
    ADMIN,
    BOB,
    CARA,
    ENDPOINT,
    GINA,
    OLGA,
    SVC,
    active_agent,
    audit,
    build_app,
    ec_pem,
    register_agent,
    register_version,
)
from conftest import assert_no_secrets
from fastapi.testclient import TestClient

from platform_api.auth import Principal, groups_from_claims
from platform_api.authz import user_caller
from platform_api.users import YamlUserDirectory, validate_user_directory

ARN = "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/claims_triage-AbC123"
SECRET_ARN = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/prod/agents/claims-triage/invoke-auth-AbCdEf"


@pytest.fixture
def c():
    with TestClient(build_app()) as client:
        yield client


# --- registration defaults ----------------------------------------------------------------------


def test_new_agents_are_drafts_and_carry_v2_fields(c):
    agent = register_agent(c, tags=["Claims", "triage", "claims"], docs_url="https://docs.example.com/x",
                           data_classification="confidential")
    assert agent["lifecycle"] == "draft" and agent["status"] == "active"
    assert agent["tags"] == ["claims", "triage"]
    assert agent["visibility"] == "team" and agent["allowed_groups"] == [] and agent["org_approval"] == "none"
    assert agent["data_classification"] == "confidential" and agent["docs_url"] == "https://docs.example.com/x"
    # Built-ins stay active.
    assert c.get("/api/v1/agents/ide.vscode", headers=BOB).json()["agent"]["lifecycle"] == "active"
    # Users may not register an active agent; admins and the service token may.
    assert c.post("/api/v1/agents", headers=BOB, json={"agent_id": "x1", "lifecycle": "active"}).status_code == 403
    r = c.post("/api/v1/agents", headers=SVC, json={"agent_id": "x2", "owner": "o@example.com", "team": "t",
                                                    "lifecycle": "active"})
    assert r.status_code == 201 and r.json()["agent"]["lifecycle"] == "active"
    assert c.post("/api/v1/agents", headers=BOB, json={"agent_id": "x3", "tags": ["Bad Tag!"]}).status_code == 400
    # PATCH updates catalog fields.
    r = c.patch("/api/v1/agents/claims-triage", headers=BOB, json={"tags": ["fnol"], "data_classification": "internal"})
    assert r.json()["agent"]["tags"] == ["fnol"] and r.json()["agent"]["data_classification"] == "internal"
    assert audit(c, entity_id="claims-triage")[0]["details"]["lifecycle"] == "draft"


# --- versions -----------------------------------------------------------------------------------


def test_version_registration_auth(c):
    register_agent(c)
    # Service (deploy workflow): any kind.
    out = register_version(c, kind="agentcore", endpoint=None, runtime_arn=ARN, qualifier="prod", expect=(201,))
    assert out["created"] is True and out["version"]["kind"] == "agentcore"
    assert out["version"]["verification_status"] == "unverified"
    # Owner: https only, no verified/activate.
    assert register_version(c, headers=BOB, version="1.1.0", expect=(201,))["version"]["created_by"] == "bob@example.com"
    r = c.post("/api/v1/agents/claims-triage/versions", headers=BOB,
               json={"version": "2", "env": "prod", "kind": "agentcore", "runtime_arn": ARN})
    assert r.status_code == 403
    r = c.post("/api/v1/agents/claims-triage/versions", headers=BOB,
               json={"version": "2", "env": "prod", "kind": "https", "endpoint": ENDPOINT, "verified": True})
    assert r.status_code == 403
    # Same team but not the owner, and other users: forbidden. Admin: https allowed.
    for who in (CARA, OLGA):
        r = c.post("/api/v1/agents/claims-triage/versions", headers=who,
                   json={"version": "3", "env": "prod", "kind": "https", "endpoint": ENDPOINT})
        assert r.status_code == 403
    assert register_version(c, headers=ADMIN, version="1.2.0", expect=(201,))["created"] is True
    # Re-registering the same (env, version) replaces it (deploy re-runs): 200, verification reset.
    out = register_version(c, version="1.1.0", verified=True, expect=(200,))
    assert out["created"] is False and out["version"]["verification_status"] == "passed"
    out = register_version(c, headers=BOB, version="1.1.0", expect=(200,))
    assert out["version"]["verification_status"] == "unverified"
    # Builtins have no versions; unknown agents 404.
    assert c.post("/api/v1/agents/ide.vscode/versions", headers=SVC,
                  json={"version": "1", "env": "prod", "kind": "https", "endpoint": ENDPOINT}).status_code == 400
    assert c.post("/api/v1/agents/nope/versions", headers=SVC,
                  json={"version": "1", "env": "prod", "kind": "https", "endpoint": ENDPOINT}).status_code == 404
    events = [e for e in audit(c, entity_id="claims-triage") if e["action"] == "agent.version.register"]
    assert len(events) == 5 and events[0]["details"]["auth_type"] == "none"


@pytest.mark.parametrize("body,fragment", [
    ({"endpoint": "http://agents.example.com"}, "https"),
    ({"endpoint": "https://user:pw@agents.example.com"}, "credentials"),
    ({"endpoint": "https://agents.example.com/x?key=1"}, "credentials"),
    ({"kind": "agentcore", "endpoint": None, "runtime_arn": "arn:aws:lambda:us-east-1:1:function:x"}, "runtime_arn"),
    ({"kind": "agentcore", "endpoint": None, "runtime_arn": ARN, "auth": {"type": "api_key", "secret_arn": SECRET_ARN}}, "SigV4"),
    ({"auth": {"type": "api_key"}}, "secret_arn"),
    ({"auth": {"type": "api_key", "secret_arn": "aig/prod/x"}}, "secret_arn"),
    ({"auth": {"type": "none", "secret_arn": SECRET_ARN}}, "empty"),
    ({"input_schema": {"type": "nonsense"}}, "input_schema"),
    ({"version": "bad version"}, "version must match"),
    ({"git_sha": "zz"}, "git_sha"),
    ({"verified": False, "activate": True}, "activate"),
])
def test_version_validation(c, body, fragment):
    register_agent(c)
    payload = {"version": "1.0.0", "env": "prod", "kind": "https", "endpoint": ENDPOINT, **body}
    r = c.post("/api/v1/agents/claims-triage/versions", headers=SVC, json=payload)
    assert r.status_code == 400, r.text
    assert r.json()["error"]["code"] == "version_invalid"
    assert fragment in r.json()["error"]["message"]


def test_secret_values_are_refused_and_never_stored(c):
    register_agent(c)
    r = c.post("/api/v1/agents/claims-triage/versions", headers=SVC, json={
        "version": "1", "env": "prod", "kind": "https", "endpoint": ENDPOINT,
        "auth": {"type": "api_key", "secret_arn": SECRET_ARN, "value": "SUPERSECRET-raw-key"}})
    assert r.status_code == 400 and r.json()["error"]["code"] == "invalid_request"
    out = register_version(c, auth={"type": "api_key", "secret_arn": SECRET_ARN})
    assert out["version"]["auth"] == {"type": "api_key", "secret_arn": SECRET_ARN}


def test_local_endpoints_only_in_local():
    with TestClient(build_app()) as c:
        register_agent(c)
        out = register_version(c, env="local", endpoint="http://localhost:8080", auth={"type": "api_key",
                                                                                       "secret_arn": "local:MY_AGENT_KEY"})
        assert out["version"]["endpoint"] == "http://localhost:8080"
    with TestClient(build_app(env="dev", secrets={"AGENT_CALLER_SIGNING_KEY": ec_pem()})) as c:
        r = c.post("/api/v1/agents", headers=SVC, json={"agent_id": "a1", "owner": "bob@example.com", "team": "claims-ai"})
        assert r.status_code == 201
        for body in ({"env": "local"}, {"endpoint": "http://localhost:8080"}, {"endpoint": "https://localhost"},
                     {"auth": {"type": "api_key", "secret_arn": "local:MY_AGENT_KEY"}}):
            payload = {"version": "1", "env": "dev", "kind": "https", "endpoint": ENDPOINT, **body}
            r = c.post("/api/v1/agents/a1/versions", headers=SVC, json=payload)
            assert r.json()["error"]["code"] in ("version_invalid", "invalid_request"), (body, r.text)


def test_versions_list_visibility_and_retire(c):
    register_agent(c)
    register_version(c, version="1.0.0")
    register_version(c, version="1.0.0", env="dev")
    assert c.get("/api/v1/agents/claims-triage/versions", headers=CARA).json()["total"] == 2
    assert c.get("/api/v1/agents/claims-triage/versions?env=dev", headers=SVC).json()["total"] == 1
    assert c.get("/api/v1/agents/claims-triage/versions", headers=ADMIN).status_code == 200
    r = c.get("/api/v1/agents/claims-triage/versions", headers=OLGA)
    assert r.status_code == 403 and r.json()["error"]["code"] == "agent_forbidden"
    # Retire needs env when the version exists in several envs.
    assert c.post("/api/v1/agents/claims-triage/versions/1.0.0/retire", headers=BOB).json()["error"]["code"] == "env_required"
    assert c.post("/api/v1/agents/claims-triage/versions/1.0.0/retire?env=dev", headers=OLGA).status_code == 403
    r = c.post("/api/v1/agents/claims-triage/versions/1.0.0/retire?env=dev", headers=BOB)
    assert {(v["env"], v["status"]) for v in r.json()["items"]} == {("dev", "retired"), ("prod", "active")}
    assert c.post("/api/v1/agents/claims-triage/versions/9.9/retire?env=dev", headers=BOB).status_code == 404


# --- lifecycle ----------------------------------------------------------------------------------


def test_lifecycle_transitions(c):
    register_agent(c)
    url = "/api/v1/agents/claims-triage/lifecycle"
    # Activation needs a verified version.
    r = c.post(url, headers=BOB, json={"to": "active"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "verification_required"
    register_version(c, headers=BOB)  # unverified
    assert c.post(url, headers=BOB, json={"to": "active"}).json()["error"]["code"] == "verification_required"
    register_version(c, version="1.0.1", verified=True)
    # Only the owner (or an admin) may change it.
    assert c.post(url, headers=CARA, json={"to": "active"}).status_code == 403
    assert c.post(url, headers=SVC, json={"to": "active"}).status_code == 401  # users only (service token refused)
    assert c.post(url, headers=BOB, json={"to": "deprecated"}).json()["error"]["code"] == "invalid_transition"
    assert c.post(url, headers=BOB, json={"to": "active"}).json()["agent"]["lifecycle"] == "active"
    assert c.post(url, headers=BOB, json={"to": "active"}).status_code == 200  # idempotent
    assert c.post(url, headers=BOB, json={"to": "deprecated"}).json()["agent"]["lifecycle"] == "deprecated"
    assert c.post(url, headers=ADMIN, json={"to": "active"}).json()["agent"]["lifecycle"] == "active"
    assert c.post(url, headers=BOB, json={"to": "draft"}).json()["error"]["code"] == "invalid_transition"
    r = c.post(url, headers=BOB, json={"to": "retired", "reason": "replaced by v2"})
    assert r.json()["agent"]["lifecycle"] == "retired" and r.json()["agent"]["lifecycle_changed_at"]
    assert c.post(url, headers=ADMIN, json={"to": "active"}).json()["error"]["code"] == "invalid_transition"
    # Retired agents take no new versions.
    assert c.post("/api/v1/agents/claims-triage/versions", headers=SVC,
                  json={"version": "5", "env": "prod", "kind": "https", "endpoint": ENDPOINT}).status_code == 409
    assert c.post("/api/v1/agents/ide.vscode/lifecycle", headers=ADMIN, json={"to": "retired"}).status_code == 409
    trail = [(e["details"].get("from"), e["details"]["to"]) for e in audit(c, entity_id="claims-triage")
             if e["action"] == "agent.lifecycle"]
    assert trail == [("draft", "active"), ("active", "deprecated"), ("deprecated", "active"), ("active", "retired")]


def test_deploy_registration_activates_prod(c):
    register_agent(c)
    out = register_version(c, verified=True, activate=True, git_sha="3f9c2e1", image_digest="sha256:abc")
    assert out["activated"] is True and out["agent"]["lifecycle"] == "active"
    assert out["version"]["verification"]["source"] == "deploy"
    assert any(e["action"] == "agent.lifecycle" and e["details"]["source"] == "deploy"
               for e in audit(c, entity_id="claims-triage"))


# --- access -------------------------------------------------------------------------------------


def test_access_groups_org_and_approval(c):
    register_agent(c)
    url = "/api/v1/agents/claims-triage/access"
    assert c.put(url, headers=CARA, json={"visibility": "groups", "allowed_groups": ["UW-Analysts"]}).status_code == 403
    r = c.put(url, headers=BOB, json={"visibility": "groups", "allowed_groups": ["UW-Analysts", "UW-Analysts", " x "]})
    assert r.json()["agent"]["allowed_groups"] == ["UW-Analysts", "x"]
    assert c.put(url, headers=BOB, json={"visibility": "groups", "allowed_groups": ["bad/group"]}).status_code == 400
    r = c.put(url, headers=BOB, json={"visibility": "org", "allowed_groups": ["UW-Analysts"]})
    assert r.json()["agent"]["org_approval"] == "pending"
    approve = "/api/v1/agents/claims-triage/access/approve"
    assert c.post(approve, headers=BOB).status_code == 403
    r = c.post(approve, headers=ADMIN, json={"reason": "reviewed"})
    assert r.json()["agent"]["org_approval"] == "approved" and r.json()["agent"]["org_approval_by"] == "admin@example.com"
    assert c.post(approve, headers=ADMIN).json()["error"]["code"] == "invalid_transition"
    # Re-saving org keeps the approval; narrowing and widening again needs a new approval.
    assert c.put(url, headers=BOB, json={"visibility": "org"}).json()["agent"]["org_approval"] == "approved"
    r = c.put(url, headers=BOB, json={"visibility": "team", "allowed_groups": ["ignored"]})
    assert r.json()["agent"]["org_approval"] == "none" and r.json()["agent"]["allowed_groups"] == []
    assert c.put(url, headers=BOB, json={"visibility": "org"}).json()["agent"]["org_approval"] == "pending"
    assert c.post("/api/v1/agents/claims-triage/access/reject", headers=ADMIN).json()["agent"]["org_approval"] == "rejected"
    actions = [e["action"] for e in audit(c, entity_id="claims-triage") if e["action"].startswith("agent.access")]
    assert actions == ["agent.access", "agent.access", "agent.access.approve", "agent.access", "agent.access",
                       "agent.access", "agent.access.reject"]


# --- catalog ------------------------------------------------------------------------------------


def _ids(c, headers, **params) -> list[str]:
    r = c.get("/api/v1/catalog", headers=headers, params=params)
    assert r.status_code == 200, r.text
    return [i["agent"]["agent_id"] for i in r.json()["items"]]


def test_catalog_filters_by_access_lifecycle_and_verification(c):
    active_agent(c, "claims-triage")
    c.patch("/api/v1/agents/claims-triage", headers=BOB, json={"tags": ["claims", "triage"], "description": "FNOL triage"})
    # Draft agent with a verified version: never in the catalog.
    register_agent(c, "claims-draft")
    register_version(c, "claims-draft", verified=True)
    # Active agent whose only prod version is unverified.
    register_agent(c, "claims-unverified")
    register_version(c, "claims-unverified", version="0.1", env="dev", verified=True)
    c.post("/api/v1/agents/claims-unverified/lifecycle", headers=BOB, json={"to": "active"})
    register_version(c, "claims-unverified", version="0.2", env="prod")
    # Group-shared and org-wide agents.
    active_agent(c, "claims-groups")
    c.put("/api/v1/agents/claims-groups/access", headers=BOB, json={"visibility": "groups", "allowed_groups": ["UW-Analysts"]})
    active_agent(c, "claims-org")
    c.put("/api/v1/agents/claims-org/access", headers=BOB, json={"visibility": "org"})

    assert _ids(c, BOB) == ["claims-groups", "claims-org", "claims-triage", "claims-unverified"]
    assert _ids(c, CARA) == ["claims-groups", "claims-org", "claims-triage", "claims-unverified"]  # same team
    assert _ids(c, GINA) == ["claims-groups"]  # Entra group
    assert _ids(c, OLGA) == []  # org-wide still pending
    c.post("/api/v1/agents/claims-org/access/approve", headers=ADMIN)
    assert _ids(c, OLGA) == ["claims-org"]
    assert _ids(c, ADMIN) == ["claims-org"]  # admins get no bypass

    body = c.get("/api/v1/catalog", headers=BOB).json()
    item = next(i for i in body["items"] if i["agent"]["agent_id"] == "claims-unverified")
    assert [(v["env"], v["version"]) for v in item["versions"]] == [("dev", "0.1")]  # team sees verified dev
    assert item["access"] == "owner"
    triage = next(i for i in body["items"] if i["agent"]["agent_id"] == "claims-triage")
    assert triage["default"]["env"] == "prod" and triage["default"]["input_schema"]["required"] == ["claim_id"]
    assert body["teams"] == ["claims-ai"] and body["tags"] == ["claims", "triage"]
    assert _ids(c, BOB, q="fnol") == ["claims-triage"]
    assert _ids(c, BOB, tag="triage") == ["claims-triage"]
    assert _ids(c, BOB, team="other") == []
    # Suspended and retired agents disappear.
    c.post("/api/v1/agents/claims-triage/suspend", headers=SVC, json={"reason": "no traces"})
    c.post("/api/v1/agents/claims-groups/lifecycle", headers=BOB, json={"to": "retired"})
    assert _ids(c, BOB) == ["claims-org", "claims-unverified"]
    assert c.get("/api/v1/catalog", headers=SVC).status_code == 401
    assert_no_secrets(c.get("/api/v1/catalog", headers=BOB).text)


# --- gateway rules ------------------------------------------------------------------------------


def _check(c, agent_id: str, team: str = "claims-ai") -> dict:
    return c.post("/api/v1/guardrails/agent-check", json={"metadata": {
        "agent_id": agent_id, "team": team, "user_tier": "standard", "job_profile": "claims"}}).json()


def test_gateway_allows_drafts_only_in_local_and_dev():
    with TestClient(build_app()) as c:
        register_agent(c, "draft-bot")
        assert _check(c, "draft-bot")["verdict"] is True
    with TestClient(build_app(env="dev", secrets={"AGENT_CALLER_SIGNING_KEY": ec_pem(),
                                                  "PORTKEY_WEBHOOK_SECRET": "hook-secret-1"})) as c:
        c.post("/api/v1/agents", headers=SVC, json={"agent_id": "draft-bot", "owner": "bob@example.com", "team": "claims-ai"})
        assert c.post("/api/v1/guardrails/agent-check", headers={"x-aig-webhook-secret": "hook-secret-1"}, json={
            "metadata": {"agent_id": "draft-bot", "team": "claims-ai", "user_tier": "free", "job_profile": "claims"}
        }).json()["verdict"] is True
    with TestClient(build_app(env="prod", secrets={"AGENT_CALLER_SIGNING_KEY": ec_pem(),
                                                   "PORTKEY_WEBHOOK_SECRET": "hook-secret-1"})) as c:
        c.post("/api/v1/agents", headers=SVC, json={"agent_id": "draft-bot", "owner": "bob@example.com", "team": "claims-ai"})
        verdict = c.post("/api/v1/guardrails/agent-check", headers={"x-aig-webhook-secret": "hook-secret-1"}, json={
            "metadata": {"agent_id": "draft-bot", "team": "claims-ai", "user_tier": "free", "job_profile": "claims"}
        }).json()
        assert verdict["verdict"] is False and verdict["data"]["reason"] == "agent_draft"
        assert verdict["data"]["error"] == "AIG_E_AGENT_UNREGISTERED"


def test_gateway_denies_retired_and_keeps_deprecated(c):
    active_agent(c)
    c.post("/api/v1/agents/claims-triage/lifecycle", headers=BOB, json={"to": "deprecated"})
    assert _check(c, "claims-triage")["verdict"] is True
    c.post("/api/v1/agents/claims-triage/lifecycle", headers=BOB, json={"to": "retired"})
    verdict = _check(c, "claims-triage")
    assert verdict["verdict"] is False and verdict["data"]["reason"] == "agent_retired"


# --- groups claims ------------------------------------------------------------------------------


def test_groups_from_token_and_directory():
    assert groups_from_claims({"groups": ["b", "a", "a", 3, "x" * 129]}) == ("a", "b")
    assert groups_from_claims({"_claim_names": {"groups": "src1"}}) == ()
    directory = YamlUserDirectory({"users": {"g@example.com": {"team": "t", "tier": "free", "groups": ["G1"]}}}, "standard")

    class State:
        users = directory

    caller = user_caller(State, Principal(email="g@example.com", groups=("G2",)))
    assert caller.groups == frozenset({"G1", "G2"})
    assert validate_user_directory({"users": {"a@example.com": {"team": "t", "tier": "free", "groups": "G1"}}})
    assert validate_user_directory({"users": {"a@example.com": {"team": "t", "tier": "free", "groups": ["ok-1"]}}}) == []


def test_oidc_groups_claim_grants_group_access(rsa_key):
    from conftest import make_jwt

    app = build_app(env="dev", secrets={"AGENT_CALLER_SIGNING_KEY": ec_pem()})
    app.state.authenticator._key_resolver = lambda token: rsa_key.public_key()
    cfg = app.state.env_config
    with TestClient(app) as c:
        c.post("/api/v1/agents", headers=SVC, json={"agent_id": "grp-bot", "owner": "bob@example.com", "team": "claims-ai"})
        register_version(c, "grp-bot", verified=True, activate=True)
        owner = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience, email="bob@example.com")
        r = c.put("/api/v1/agents/grp-bot/access", headers={"Authorization": f"Bearer {owner}"},
                  json={"visibility": "groups", "allowed_groups": ["0b6a5c1e-1111-2222-3333-444455556666"]})
        assert r.status_code == 200, r.text
        member = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience, email="olga@example.com",
                          groups=["0b6a5c1e-1111-2222-3333-444455556666"])
        outsider = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience, email="olga@example.com")
        assert _ids(c, {"Authorization": f"Bearer {member}"}) == ["grp-bot"]
        assert _ids(c, {"Authorization": f"Bearer {outsider}"}) == []


# --- migration ----------------------------------------------------------------------------------


def test_migration_0003_upgrades_existing_agents(tmp_path):
    import sqlalchemy as sa

    from conftest import PROJECT_ROOT
    from platform_api.db import current_revision, make_engine, upgrade

    engine = make_engine(f"sqlite:///{tmp_path / 'm.db'}")
    upgrade(engine, PROJECT_ROOT / "migrations", "0002_model_harness")
    with engine.begin() as conn:
        conn.execute(sa.text(
            "INSERT INTO agents (agent_id, name, description, team, owner, status, shared, builtin, status_reason, "
            "hosts_seen, created_at, updated_at) VALUES ('old-bot', 'Old', '', 'claims-ai', 'bob@example.com', "
            "'active', 0, 0, '', '[]', '2026-01-01 00:00:00', '2026-01-01 00:00:00')"))
    upgrade(engine, PROJECT_ROOT / "migrations")
    assert current_revision(engine) == "0003_agent_registry_v2"
    with engine.connect() as conn:
        row = conn.execute(sa.text("SELECT lifecycle, visibility, org_approval, tags, allowed_groups FROM agents "
                                   "WHERE agent_id = 'old-bot'")).one()
        assert tuple(row) == ("active", "team", "none", "[]", "[]")
        assert {"agent_versions", "agent_invocations"} <= set(sa.inspect(conn).get_table_names())
    from alembic import command

    from platform_api.db import alembic_config

    cfg = alembic_config(PROJECT_ROOT / "migrations")
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        command.downgrade(cfg, "0002_model_harness")
    assert current_revision(engine) == "0002_model_harness"
    with engine.connect() as conn:
        assert "agent_versions" not in sa.inspect(conn).get_table_names()
        assert "lifecycle" not in {c["name"] for c in sa.inspect(conn).get_columns("agents")}
    engine.dispose()


def test_api_responses_match_agent_record_schema(c):
    """GET agent / versions / invocation conform to backend/contracts/agent-record.schema.json."""
    import json as _json

    from conftest import PROJECT_ROOT
    from jsonschema import Draft202012Validator
    from referencing import Registry, Resource

    schema = _json.loads((PROJECT_ROOT.parent / "contracts" / "agent-record.schema.json").read_text())
    registry = Registry().with_resource(schema["$id"], Resource.from_contents(schema))

    def check(defn, value):
        errors = list(Draft202012Validator({"$ref": f"{schema['$id']}#/$defs/{defn}"}, registry=registry).iter_errors(value))
        assert not errors, [f"{e.json_path}: {e.message}" for e in errors]

    register_agent(c, tags=["claims"])
    register_version(c, verified=True, activate=True, auth={"type": "api_key", "secret_arn": SECRET_ARN})
    register_version(c, version="2.0", kind="agentcore", endpoint=None, runtime_arn=ARN, qualifier="prod")
    agent = c.get("/api/v1/agents/claims-triage", headers=BOB).json()["agent"]
    agent["versions"] = c.get("/api/v1/agents/claims-triage/versions", headers=BOB).json()["items"]
    check("agent", agent)

    store = c.app.state.invocations
    store.create(invocation_id="33333333-3333-4333-8333-333333333333", agent_id="claims-triage", version="1.0.0",
                 env="prod", caller="bob@example.com", team="claims-ai", mode="sync", purpose="invoke",
                 trace_id="trace-00000001", session_id=None, status="running")
    store.finish("33333333-3333-4333-8333-333333333333", status="succeeded", usage={"total_tokens": 3})
    check("invocation", c.get("/api/v1/invocations/33333333-3333-4333-8333-333333333333", headers=BOB).json())
