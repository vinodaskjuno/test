"""Tier + cost-based routing: cost_mode from the user directory, route in responses, POST /api/v1/routing/test."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from conftest import PORTKEY_KEY, assert_no_secrets, configured_secrets, dev_auth
from platform_api.main import create_app
from platform_api.users import YamlUserDirectory, validate_user_directory
from conftest import make_settings

GATEWAY = "http://localhost:8787/v1/chat/completions"
USERS = {
    "default_team": "unassigned",
    "default_cost_mode": "balanced",
    "teams": {"finance-ai": {"cost_mode": "economy"}},
    "users": {
        "q@example.com": {"name": "Q", "team": "uw", "tier": "premium", "cost_mode": "quality"},
        "fin@example.com": {"name": "F", "team": "finance-ai", "tier": "premium"},
        "plain@example.com": {"name": "P", "team": "uw", "tier": "standard"},
        "admin@example.com": {"name": "A", "team": "aig-platform", "tier": "standard", "roles": ["user", "admin"]},
    },
}


def completion(model: str) -> dict:
    return {"id": "c1", "object": "chat.completion", "model": model,
            "choices": [{"index": 0, "message": {"role": "assistant", "content": f"I am {model} {PORTKEY_KEY}"}}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8}}


@pytest.fixture
def client():
    app = create_app(make_settings(), secrets=configured_secrets(), users=YamlUserDirectory(USERS, "standard"))
    with TestClient(app) as c:
        yield c


@pytest.fixture
def gateway():
    with respx.mock(assert_all_called=False) as router:
        yield router


def test_cost_mode_resolution_user_team_default():
    d = YamlUserDirectory(USERS, "standard")
    assert d.lookup("q@example.com").cost_mode == "quality"
    assert d.lookup("fin@example.com").cost_mode == "economy"  # team default
    assert d.lookup("plain@example.com").cost_mode == "balanced"  # directory default
    assert d.lookup("unknown@example.com").cost_mode == "balanced"


def test_invalid_cost_modes_are_reported():
    bad = {"default_cost_mode": "cheap", "teams": {"t": {"cost_mode": "x"}}, "users": {"a@b.co": {"team": "t", "tier": "free", "cost_mode": "y"}}}
    problems = " ".join(validate_user_directory(bad))
    assert "cost_mode 'cheap'" in problems and "cost_mode 'x'" in problems and "cost_mode 'y'" in problems


def test_metadata_session_and_route_headers_carry_cost_mode(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion("m")))
    s = client.get("/api/v1/session", headers=dev_auth("q@example.com")).json()
    assert s["user_tier"] == "premium" and s["cost_mode"] == "quality"
    r = client.post("/api/v1/llm/chat/completions", json={"messages": [{"role": "user", "content": "hi"}]},
                    headers={**dev_auth("fin@example.com"), "x-aig-job-profile": "claims"})
    assert r.status_code == 200
    md = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert md["cost_mode"] == "economy" and md["user_tier"] == "premium"
    assert r.headers["x-aig-route-cost-mode"] == "economy"
    assert r.headers["x-aig-route-user-tier"] == "premium"
    assert r.headers["x-aig-route-job-profile"] == "claims"


def test_client_cannot_set_cost_mode(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion("m")))
    client.post("/api/v1/llm/chat/completions", json={"messages": [{"role": "user", "content": "hi"}]},
                headers={**dev_auth("plain@example.com"), "x-portkey-metadata": '{"cost_mode":"quality","user_tier":"premium"}'})
    md = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert md["cost_mode"] == "balanced" and md["user_tier"] == "standard"


def test_routing_test_own_route(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion("sonnet-x")))
    r = client.post("/api/v1/routing/test", json={"job_profile": "underwriting"}, headers=dev_auth("q@example.com"))
    body = r.json()
    assert r.status_code == 200 and body["ok"] is True and body["model"] == "sonnet-x"
    assert body["route"] == {"user_tier": "premium", "cost_mode": "quality", "job_profile": "underwriting", "usage_state": "normal"}
    assert body["usage"]["total_tokens"] == 8 and body["trace_id"]
    assert_no_secrets(r.text)
    sent = json.loads(route.calls.last.request.content)
    assert sent["stream"] is False and sent["max_tokens"] == 60


def test_routing_test_overrides_are_admin_only(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion("nova-lite")))
    assert client.post("/api/v1/routing/test", json={"cost_mode": "economy"}, headers=dev_auth("q@example.com")).status_code == 403
    r = client.post("/api/v1/routing/test", json={"user_tier": "free", "cost_mode": "economy"}, headers=dev_auth("admin@example.com"))
    assert r.status_code == 200 and r.json()["route"]["user_tier"] == "free"
    md = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert md["user_tier"] == "free" and md["cost_mode"] == "economy"
    bad = client.post("/api/v1/routing/test", json={"user_tier": "gold"}, headers=dev_auth("admin@example.com"))
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "invalid_user_tier"
    bad = client.post("/api/v1/routing/test", json={"cost_mode": "cheap"}, headers=dev_auth("admin@example.com"))
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "invalid_cost_mode"


def test_routing_test_reports_upstream_error(client, gateway):
    gateway.post(GATEWAY).mock(return_value=httpx.Response(404, json={"error": {"message": f"model legacy {PORTKEY_KEY}"}}))
    r = client.post("/api/v1/routing/test", json={}, headers=dev_auth("q@example.com"))
    body = r.json()
    assert r.status_code == 200 and body["ok"] is False and body["status"] == 404 and "legacy" in body["error"]
    assert_no_secrets(r.text)
