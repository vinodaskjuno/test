from __future__ import annotations

import json
import sys
import types

import pytest

from conftest import PORTKEY_KEY, PROJECT_ROOT, assert_no_secrets
from platform_api.config import ENVIRONMENTS
from platform_api.secrets import (
    SECRET_NAMES,
    SecretStore,
    aws_secret_id,
    is_placeholder,
    load_aws_secrets,
    load_env_secrets,
    load_secrets,
    placeholder_for,
    secret_status,
)


@pytest.mark.parametrize(
    "value,expected",
    [
        (None, True),
        ("", True),
        ("   ", True),
        ("__REPLACE_ME_PORTKEY_API_KEY_DEV__", True),
        ("__REPLACE_ME", True),
        ("  __REPLACE_ME_X__ ", True),
        ("pk-real-key", False),
        ("x__REPLACE_ME", True),  # marker anywhere => placeholder
        ("pk-replace-me-not-a-marker", False),
    ],
)
def test_is_placeholder(value, expected):
    assert is_placeholder(value) is expected


def test_secret_status_mask():
    assert secret_status(None) == "missing"
    assert secret_status("") == "missing"
    assert secret_status("__REPLACE_ME_PORTKEY_API_KEY_PROD__") == "placeholder"
    assert secret_status(PORTKEY_KEY) == "configured"


def test_placeholder_format():
    assert placeholder_for("PORTKEY_API_KEY", "dev") == "__REPLACE_ME_PORTKEY_API_KEY_DEV__"


def test_store_never_reveals_values_in_repr():
    store = SecretStore({"PORTKEY_API_KEY": PORTKEY_KEY})
    assert_no_secrets(repr(store))
    assert_no_secrets(str(store))
    assert store.get("PORTKEY_API_KEY") == PORTKEY_KEY
    assert store.statuses() == {
        "PORTKEY_API_KEY": "configured",
        "PORTKEY_ADMIN_API_KEY": "missing",
        "FIDDLER_API_KEY": "missing",
        "PORTKEY_WEBHOOK_SECRET": "missing",
        "PLATFORM_SERVICE_TOKEN": "missing",
        "TELEMETRY_BRIDGE_TOKEN": "missing",
        "GITHUB_DISPATCH_TOKEN": "missing",
        "AGENT_CALLER_SIGNING_KEY": "missing",
        "AGENT_OUTPUT_ENCRYPTION_KEY": "missing",
    }


def test_placeholder_values_are_not_returned():
    store = SecretStore({"PORTKEY_API_KEY": "__REPLACE_ME_PORTKEY_API_KEY_DEV__"})
    assert store.get("PORTKEY_API_KEY") is None
    assert store.status("PORTKEY_API_KEY") == "placeholder"


@pytest.mark.parametrize("env", ENVIRONMENTS)
def test_committed_templates_contain_only_placeholders(env):
    path = PROJECT_ROOT / "secrets" / f"{env}.env.example"
    lines = [l for l in path.read_text().splitlines() if l.strip() and not l.lstrip().startswith("#")]
    values = dict(l.split("=", 1) for l in lines)
    assert set(values) == set(SECRET_NAMES)
    for name, value in values.items():
        assert value == placeholder_for(name, env)


def test_no_real_secret_files_committed():
    """A developer's secrets/.env.<env> may exist locally, but git must never track or stage it."""
    import subprocess

    files = list((PROJECT_ROOT / "secrets").glob(".env.*"))
    if not files:
        return
    tracked = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "--", *map(str, files)],
        cwd=PROJECT_ROOT, capture_output=True, text=True, check=False,
    )
    if tracked.returncode != 0:
        pytest.skip("not a git checkout: cannot tell whether local secret files are ignored")
    assert tracked.stdout.strip() == "", f"secret files would be committed: {tracked.stdout}"


def test_env_file_loading_and_process_env_precedence(tmp_path):
    (tmp_path / ".env.dev").write_text(
        "# comment\nPORTKEY_API_KEY=\"from-file\"\nexport FIDDLER_API_KEY=fdl-file\nPORTKEY_ADMIN_API_KEY=__REPLACE_ME_PORTKEY_ADMIN_API_KEY_DEV__\n"
    )
    store = load_env_secrets("dev", tmp_path, environ={})
    assert store.get("PORTKEY_API_KEY") == "from-file"
    assert store.get("FIDDLER_API_KEY") == "fdl-file"
    assert store.status("PORTKEY_ADMIN_API_KEY") == "placeholder"

    store = load_env_secrets("dev", tmp_path, environ={"PORTKEY_API_KEY": "from-env"})
    assert store.get("PORTKEY_API_KEY") == "from-env"


def test_env_file_for_other_env_is_ignored(tmp_path):
    (tmp_path / ".env.prod").write_text("PORTKEY_API_KEY=prod-key\n")
    store = load_env_secrets("dev", tmp_path, environ={})
    assert store.status("PORTKEY_API_KEY") == "missing"


class FakeSecretsManager:
    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    def get_secret_value(self, SecretId):
        self.calls.append(SecretId)
        return {"SecretString": json.dumps(self.payload)}


def test_aws_provider_reads_json_secret():
    fake = FakeSecretsManager({"PORTKEY_API_KEY": "aws-key", "FIDDLER_API_KEY": ""})
    store = load_aws_secrets("stage", client=fake)
    assert fake.calls == ["aig/stage/platform-api"]
    assert store.get("PORTKEY_API_KEY") == "aws-key"
    assert store.status("FIDDLER_API_KEY") == "missing"
    assert store.source == "aws"


def test_aws_provider_imports_boto3_lazily(monkeypatch, tmp_path):
    fake = FakeSecretsManager({"PORTKEY_API_KEY": "aws-key"})
    boto3 = types.ModuleType("boto3")
    boto3.client = lambda service: fake if service == "secretsmanager" else None
    monkeypatch.setitem(sys.modules, "boto3", boto3)
    store = load_secrets("aws", "prod", tmp_path)
    assert store.get("PORTKEY_API_KEY") == "aws-key"
    assert aws_secret_id("prod") == "aig/prod/platform-api"


@pytest.mark.parametrize(
    "raw,status",
    [
        ('"__REPLACE_ME_PORTKEY_API_KEY_DEV__"', "placeholder"),
        ("'__REPLACE_ME_X'", "placeholder"),
        (' " __REPLACE_ME_X__ " ', "placeholder"),
        ("__replace_me_portkey_api_key_dev__", "placeholder"),
        ('"__Replace_Me_X"', "placeholder"),
        ("pk-__REPLACE_ME_PORTKEY_API_KEY_DEV__", "placeholder"),
        ('""', "missing"),
        ("''", "missing"),
        ('"   "', "missing"),
    ],
)
def test_quoted_and_lowercase_placeholders_via_process_env(tmp_path, raw, status):
    store = load_env_secrets("dev", tmp_path, environ={"PORTKEY_API_KEY": raw})
    assert store.status("PORTKEY_API_KEY") == status
    assert store.get("PORTKEY_API_KEY") is None
    assert is_placeholder(raw) is True
    assert secret_status(raw) == status


def test_quoted_real_key_is_unwrapped_from_process_env(tmp_path):
    store = load_env_secrets("dev", tmp_path, environ={"PORTKEY_API_KEY": f' "{PORTKEY_KEY}" '})
    assert store.status("PORTKEY_API_KEY") == "configured"
    assert store.get("PORTKEY_API_KEY") == PORTKEY_KEY


def test_mismatched_quotes_are_not_stripped():
    assert SecretStore({"PORTKEY_API_KEY": "\"abc'"}).get("PORTKEY_API_KEY") == "\"abc'"


def test_quoted_placeholder_from_aws_json():
    fake = FakeSecretsManager({"PORTKEY_API_KEY": '"__REPLACE_ME_PORTKEY_API_KEY_PROD__"', "FIDDLER_API_KEY": '""'})
    store = load_aws_secrets("prod", client=fake)
    assert store.status("PORTKEY_API_KEY") == "placeholder"
    assert store.status("FIDDLER_API_KEY") == "missing"


GITIGNORED_SECRET_PATHS = [
    "secrets/dev.env",
    "secrets/.env",
    "secrets/.env.prod",
    "secrets/prod.json",
    "secrets/stage.env.local",
    "secrets/portkey.key",
]


@pytest.mark.parametrize("path", GITIGNORED_SECRET_PATHS)
def test_gitignore_covers_real_secret_files(tmp_path, path):
    import shutil
    import subprocess

    git = shutil.which("git")
    if not git:
        pytest.skip("git not installed")
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run([git, "init", "-q"], cwd=repo, check=True)
    shutil.copy(PROJECT_ROOT / ".gitignore", repo / ".gitignore")
    (repo / "secrets").mkdir()
    for env in ENVIRONMENTS:
        (repo / "secrets" / f"{env}.env.example").write_text("x\n")
    target = repo / path
    target.write_text("PORTKEY_API_KEY=real\n")

    def ignored(p: str) -> bool:
        return subprocess.run([git, "check-ignore", "-q", p], cwd=repo).returncode == 0

    assert ignored(path)
    for env in ENVIRONMENTS:
        assert not ignored(f"secrets/{env}.env.example")
