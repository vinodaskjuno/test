from __future__ import annotations

import logging

import pytest
from fastapi.testclient import TestClient

from conftest import PORTKEY_KEY, assert_no_secrets, configured_secrets, dev_auth, make_app, make_settings
from platform_api.auth import Authenticator
from platform_api.errors import StartupError
from platform_api.main import create_app
from platform_api.secrets import SecretStore


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
@pytest.mark.parametrize("value", [None, "", "__REPLACE_ME_PORTKEY_API_KEY_DEV__"])
def test_fail_closed_outside_local(env, value):
    with pytest.raises(StartupError, match="refusing to start"):
        make_app(env=env, auth_mode="oidc", secrets=SecretStore({"PORTKEY_API_KEY": value}))


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
def test_starts_outside_local_when_key_configured(env):
    app = make_app(env=env, auth_mode="oidc", secrets=SecretStore({"PORTKEY_API_KEY": PORTKEY_KEY}))
    with TestClient(app) as c:
        assert c.get("/healthz").json()["env"] == env


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
def test_dev_auth_mode_rejected_outside_local(env):
    with pytest.raises(StartupError, match="AIG_AUTH_MODE=dev"):
        make_app(env=env, auth_mode="dev")


def test_authenticator_itself_rejects_dev_mode_outside_local():
    with pytest.raises(StartupError):
        Authenticator(env="prod", auth_mode="dev", issuer="i", audience="a", jwks_url="https://x")


def test_local_starts_with_placeholder_and_warns(caplog):
    caplog.set_level(logging.WARNING)
    app = make_app(secrets=SecretStore({"PORTKEY_API_KEY": "__REPLACE_ME_PORTKEY_API_KEY_LOCAL__"}))
    assert "required secrets not configured" in caplog.text
    with TestClient(app) as c:
        r = c.post("/api/v1/llm/chat/completions", json={"model": "x", "messages": []}, headers=dev_auth())
    assert r.status_code == 503
    assert r.json()["error"]["code"] == "portkey_key_not_configured"


def test_secrets_loaded_from_gitignored_env_file(tmp_path, monkeypatch):
    for n in ("PORTKEY_API_KEY", "PORTKEY_ADMIN_API_KEY", "FIDDLER_API_KEY"):
        monkeypatch.delenv(n, raising=False)
    (tmp_path / ".env.stage").write_text(f"PORTKEY_API_KEY={PORTKEY_KEY}\n")
    app = create_app(make_settings("stage", "oidc", secrets_dir=tmp_path))
    with TestClient(app) as c:
        body = c.get("/healthz").json()
    assert body["secrets"]["PORTKEY_API_KEY"] == "configured"


def test_startup_logs_do_not_leak(caplog, capfd):
    caplog.set_level(logging.DEBUG)
    app = make_app(env="prod", auth_mode="oidc", secrets=configured_secrets())
    with TestClient(app) as c:
        c.get("/healthz")
    logging.getLogger("platform_api").info("accidental log of %s", PORTKEY_KEY)
    out, err = capfd.readouterr()
    assert_no_secrets(caplog.text + out + err)
