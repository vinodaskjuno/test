"""Phase 4 portal API: roles, session/preferences, agents (DB registry), audit of agent changes, CORS."""

from __future__ import annotations

import pytest
from conftest import USERS, assert_no_secrets, configured_secrets, dev_auth, make_app, make_settings
from fastapi.testclient import TestClient
from platform_api.agent_hooks import AgentHook
from platform_api.errors import StartupError
from platform_api.main import create_app
from platform_api.users import YamlUserDirectory, validate_user_directory

SERVICE_TOKEN = "svc-SUPERSECRET-11223344556677"
SVC = {"x-aig-service-token": SERVICE_TOKEN}
ADMIN = dev_auth("admin@example.com")
APPROVER = dev_auth("approver@example.com")
JANE = dev_auth("jane@example.com")
BOB = dev_auth("bob@example.com")


def build(hooks=None, **kw):
    return create_app(
        make_settings(**kw),
        secrets=configured_secrets(PLATFORM_SERVICE_TOKEN=SERVICE_TOKEN),
        users=YamlUserDirectory(USERS, "standard"),
        agent_hooks=hooks or [],
    )


@pytest.fixture
def c():
    with TestClient(build()) as client:
        yield client


# --- roles / session / preferences ---------------------------------------------------------------


def test_roles_validated_on_load(tmp_path):
    assert validate_user_directory({"users": {"a@example.com": {"team": "t", "tier": "free", "roles": ["user", "admin"]}}}) == []
    assert validate_user_directory({"users": {"a@example.com": {"team": "t", "tier": "free", "roles": ["root"]}}})
    assert validate_user_directory({"users": {"a@example.com": {"team": "t", "tier": "free", "roles": []}}})
    f = tmp_path / "users.yaml"
    f.write_text("users:\n  a@example.com: {tier: free, team: t, roles: [superuser]}\n")
    with pytest.raises(StartupError, match="roles"):
        YamlUserDirectory.from_file(f, "standard", env="prod")
    d = YamlUserDirectory.from_file(f, "standard", env="local")  # dropped with a warning in local
    assert d.lookup("a@example.com").roles == ("user",)


def test_session_has_roles_preferences_and_links(c):
    body = c.get("/api/v1/session", headers=ADMIN).json()
    assert body["roles"] == ["user", "admin"]
    assert body["preferences"] == {"theme": "system"}
    # local.yaml holds placeholders for both, so no link is handed out.
    assert body["links"] == {"portkey_url": None, "fiddler_url": None}
    assert c.get("/api/v1/session", headers=JANE).json()["roles"] == ["user"]
    assert c.get("/api/v1/session", headers=APPROVER).json()["roles"] == ["user", "approver"]


def test_session_links_from_config():
    app = build()
    app.state.env_config.portkey_ui_url = "https://portkey.example.com/"
    app.state.env_config.fiddler_url = "https://fiddler.example.com"
    with TestClient(app) as client:
        links = client.get("/api/v1/session", headers=JANE).json()["links"]
    assert links == {"portkey_url": "https://portkey.example.com", "fiddler_url": "https://fiddler.example.com"}


def test_preferences_round_trip_per_user(c):
    assert c.get("/api/v1/me/preferences").status_code == 401
    assert c.get("/api/v1/me/preferences", headers=JANE).json() == {"theme": "system"}
    r = c.put("/api/v1/me/preferences", headers=JANE, json={"theme": "dark"})
    assert r.status_code == 200 and r.json() == {"theme": "dark"}
    assert c.get("/api/v1/me/preferences", headers=JANE).json() == {"theme": "dark"}
    assert c.get("/api/v1/me/preferences", headers=BOB).json() == {"theme": "system"}
    assert c.get("/api/v1/session", headers=JANE).json()["preferences"] == {"theme": "dark"}
    bad = c.put("/api/v1/me/preferences", headers=JANE, json={"theme": "neon"})
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "invalid_request"
    assert c.put("/api/v1/me/preferences", headers={**JANE, "content-type": "application/json"}, content=b"{nope").json()["error"]["code"] == "invalid_json"
    # The service token is not a user.
    assert c.get("/api/v1/me/preferences", headers=SVC).status_code == 401


# --- agents ---------------------------------------------------------------------------------------


def test_list_agents_shape_and_filters(c):
    r = c.get("/api/v1/agents", headers=JANE)
    body = r.json()
    assert body["total"] == len(body["items"]) and body["agents"] == body["items"]
    vscode = next(a for a in body["items"] if a["agent_id"] == "ide.vscode")
    assert vscode["builtin"] is True and vscode["shared"] is True and vscode["name"] == "VS Code extension"
    for key in ("agent_id", "name", "description", "team", "owner", "status", "builtin", "created_at", "updated_at",
                "last_seen_at", "hosts_seen", "fiddler_application_id", "links"):
        assert key in vscode
    assert vscode["links"] == {"fiddler": None, "portkey": None}
    # local seeds config/agents.example.yaml on first start
    ids = {a["agent_id"] for a in body["items"]}
    assert {"uw-quote-assistant", "legacy-claims-bot"} <= ids
    assert {a["agent_id"] for a in c.get("/api/v1/agents?status=suspended", headers=JANE).json()["items"]} == {"legacy-claims-bot"}
    assert {a["team"] for a in c.get("/api/v1/agents?team=claims-ai", headers=JANE).json()["items"]} == {"claims-ai"}
    assert [a["agent_id"] for a in c.get("/api/v1/agents?q=QUOTE", headers=JANE).json()["items"]] == ["uw-quote-assistant"]
    assert c.get("/api/v1/agents?status=bogus", headers=JANE).status_code == 400


def test_register_defaults_admin_override_and_sdk_compat(c):
    # SDK shape: {agent_id, team, owner, description, template}; name optional.
    r = c.post("/api/v1/agents", headers=JANE, json={"agent_id": "uw-x", "team": "x", "owner": "x@x.com", "description": "d", "template": "langgraph-py"})
    assert r.status_code == 201
    agent = r.json()["agent"]
    assert agent["owner"] == "jane@example.com" and agent["team"] == "underwriting-ai"
    assert agent["name"] == "uw-x" and agent["status"] == "active" and agent["builtin"] is False
    assert agent["created_at"].endswith("+00:00")
    dup = c.post("/api/v1/agents", headers=JANE, json={"agent_id": "uw-x", "name": "again"})
    assert dup.status_code == 409 and dup.json()["error"]["code"] == "agent_exists"
    r = c.post("/api/v1/agents", headers=ADMIN, json={"agent_id": "ops-bot", "name": "Ops bot", "owner": "ops@example.com", "team": "operations-ai"})
    assert r.json()["agent"]["owner"] == "ops@example.com" and r.json()["agent"]["team"] == "operations-ai"
    r = c.post("/api/v1/agents", headers=ADMIN, json={"agent_id": "admin-own", "name": "Mine"})
    assert r.json()["agent"]["owner"] == "admin@example.com" and r.json()["agent"]["team"] == "aig-platform"
    assert c.post("/api/v1/agents", headers=ADMIN, json={"agent_id": "bad-team", "team": "has space"}).json()["error"]["code"] == "invalid_agent"
    got = c.get("/api/v1/agents/ops-bot", headers=SVC).json()
    assert got["agent"]["name"] == "Ops bot"
    audit = c.get("/api/v1/audit?entity_type=agent&entity_id=ops-bot", headers=ADMIN).json()["items"]
    assert audit[0]["action"] == "agent.register" and audit[0]["actor"] == "admin@example.com"


def test_patch_owner_or_admin_only(c):
    c.post("/api/v1/agents", headers=JANE, json={"agent_id": "jane-agent", "name": "Jane's"})
    assert c.patch("/api/v1/agents/jane-agent", headers=BOB, json={"name": "hijack"}).status_code == 403
    r = c.patch("/api/v1/agents/jane-agent", headers=JANE, json={"name": "Renamed", "description": "new"})
    assert r.status_code == 200 and r.json()["agent"]["name"] == "Renamed" and r.json()["agent"]["description"] == "new"
    r = c.patch("/api/v1/agents/jane-agent", headers=ADMIN, json={"owner": "bob@example.com"})
    assert r.json()["agent"]["owner"] == "bob@example.com"
    assert c.patch("/api/v1/agents/jane-agent", headers=JANE, json={"name": "x"}).status_code == 403  # no longer owner
    assert c.patch("/api/v1/agents/nope", headers=ADMIN, json={"name": "x"}).status_code == 404
    assert c.patch("/api/v1/agents/ide.vscode", headers=JANE, json={"name": "x"}).status_code == 403
    assert c.patch("/api/v1/agents/jane-agent", headers=SVC, json={"name": "x"}).status_code == 401
    assert c.patch("/api/v1/agents/jane-agent", headers=ADMIN, json={"name": ""}).status_code == 400
    actions = [e["action"] for e in c.get("/api/v1/audit?entity_id=jane-agent", headers=ADMIN).json()["items"]]
    assert actions == ["agent.update", "agent.update", "agent.register"]


def test_admin_can_suspend_and_reinstate_with_audit(c):
    r = c.post("/api/v1/agents/uw-quote-assistant/suspend", headers=ADMIN, json={"reason": "owner left"})
    assert r.status_code == 200 and r.json()["changed"] is True
    agent = r.json()["agent"]
    assert agent["status"] == "suspended" and agent["status_reason"] == "admin:admin@example.com: owner left"
    verdict = c.post("/api/v1/guardrails/agent-check", json={"metadata": {
        "agent_id": "uw-quote-assistant", "team": "underwriting-ai", "user_tier": "premium", "job_profile": "underwriting"}}).json()
    assert verdict["data"]["reason"] == "agent_suspended"
    assert c.post("/api/v1/agents/uw-quote-assistant/reinstate", headers=SVC, json={"reason": "ok", "source": "platform-team"}).json()["agent"]["status"] == "active"
    assert c.post("/api/v1/agents/uw-quote-assistant/suspend", headers=APPROVER, json={"reason": "x"}).status_code == 403
    actions = [e["action"] for e in c.get("/api/v1/audit?entity_type=agent&entity_id=uw-quote-assistant", headers=APPROVER).json()["items"]]
    assert actions == ["agent.reinstate", "agent.suspend"]


def test_last_seen_from_agent_check_and_proxy(c):
    assert c.get("/api/v1/agents/uw-quote-assistant", headers=JANE).json()["agent"]["last_seen_at"] is None
    meta = {"agent_id": "uw-quote-assistant", "team": "underwriting-ai", "user_tier": "premium",
            "job_profile": "underwriting", "host": "laptop"}
    assert c.post("/api/v1/guardrails/agent-check", json={"metadata": meta}).json()["verdict"] is True
    agent = c.get("/api/v1/agents/uw-quote-assistant", headers=JANE).json()["agent"]
    assert agent["last_seen_at"] and agent["hosts_seen"] == ["laptop"]
    # A denied call does not count as seen.
    c.post("/api/v1/guardrails/agent-check", json={"metadata": {**meta, "agent_id": "legacy-claims-bot", "team": "claims-ai"}})
    assert c.get("/api/v1/agents/legacy-claims-bot", headers=JANE).json()["agent"]["last_seen_at"] is None


def test_fiddler_application_id_from_hook_is_stored_and_linked():
    def hook(agent, **_):
        return {"fiddler_application_id": "8a1d2c3e-1111-4222-8333-444455556666"}

    app = build(hooks=[AgentHook("test:hook", hook)])
    app.state.env_config.fiddler_url = "https://fiddler.example.com"
    app.state.env_config.portkey_ui_url = "https://portkey.example.com"
    with TestClient(app) as client:
        client.post("/api/v1/agents", headers=JANE, json={"agent_id": "traced-agent", "name": "Traced"})
        agent = client.get("/api/v1/agents/traced-agent", headers=JANE).json()["agent"]
    assert agent["fiddler_application_id"] == "8a1d2c3e-1111-4222-8333-444455556666"
    assert agent["links"]["fiddler"] == "https://fiddler.example.com/applications/8a1d2c3e-1111-4222-8333-444455556666"
    assert agent["links"]["portkey"] == "https://portkey.example.com/logs?metadata.agent_id=traced-agent"


def test_validation_errors_use_the_envelope(c):
    r = c.post("/api/v1/agents", headers=JANE, json={"name": "no id"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "invalid_request" and "agent_id" in r.json()["error"]["message"]
    r = c.get("/api/v1/nope", headers=JANE)
    assert r.status_code == 404 and r.json()["error"]["code"] == "not_found"
    r = c.delete("/api/v1/agents", headers=JANE)
    assert r.status_code == 405 and r.json()["error"]["code"] == "method_not_allowed"


def test_cors_preflight_allows_put_patch_and_aig_headers():
    app = make_app()
    with TestClient(app) as client:
        r = client.options("/api/v1/agents/x", headers={
            "Origin": "http://localhost:3000", "Access-Control-Request-Method": "PATCH",
            "Access-Control-Request-Headers": "authorization,content-type,x-aig-agent-id"})
        assert r.status_code == 200
        assert "PATCH" in r.headers["access-control-allow-methods"] and "PUT" in r.headers["access-control-allow-methods"]
        assert "x-aig-agent-id" in r.headers["access-control-allow-headers"]
        evil = client.options("/api/v1/agents", headers={"Origin": "https://evil.example.com", "Access-Control-Request-Method": "GET"})
        assert "access-control-allow-origin" not in evil.headers


def test_no_secrets_in_portal_responses(c):
    texts = [c.get(p, headers=ADMIN).text for p in ("/api/v1/agents", "/api/v1/session", "/api/v1/audit", "/api/v1/me/preferences")]
    for t in texts:
        assert_no_secrets(t)
        assert SERVICE_TOKEN not in t
