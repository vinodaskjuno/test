from __future__ import annotations

from urllib.parse import parse_qs, urlsplit

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from platform_api.errors import StartupError
from platform_api.routes.local_auth import callback_url, normalize_redirect_uri, valid_redirect_uri
from platform_api.routes.usage import count_users, summarize_models

from conftest import ADMIN_KEY, assert_no_secrets, configured_secrets, dev_auth, make_app  # noqa: I001

USERS_URL = r"http://localhost:8787/v1/analytics/groups/users.*"
MODELS_URL = r"http://localhost:8787/v1/analytics/groups/model\?.*"
GRAPH_URL = r"http://localhost:8787/v1/analytics/graphs/(requests|tokens|cost)\?.*"
ADMIN = dev_auth("admin@example.com")
CB = "vscode://aig.aig-ai-ecosystem/auth-callback"
STATE = "s" * 24


@pytest.fixture
def gateway():
    with respx.mock(assert_all_called=False) as router:
        yield router


# ---------- dashboard ----------

def test_dashboard_aggregates_models_and_counts_users(client, gateway):
    users = gateway.get(url__regex=USERS_URL).mock(
        return_value=httpx.Response(200, json={"total": 3, "data": [{"user": "a@x.com"}, {"user": "b@x.com"}, {"user": "c@x.com"}]})
    )
    models = gateway.get(url__regex=MODELS_URL).mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {"model": "claude-sonnet", "requests": 10, "prompt_tokens": 600, "completion_tokens": 200, "cost": 250},
                    {"model": "claude-opus", "requests": 2, "total_tokens": 1200, "cost": "500"},
                    {"model": "claude-sonnet", "requests": 1, "total_tokens": 100, "cost": 50},
                ]
            },
        )
    )
    r = client.get("/api/v1/usage/dashboard?days=7&scope=org", headers=ADMIN)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["source"] == "portkey_analytics" and body["window"]["days"] == 7
    assert body["totals"]["users"] == 3
    assert [m["model"] for m in body["models"]] == ["claude-opus", "claude-sonnet"]
    sonnet = body["models"][1]
    assert sonnet == {
        "model": "claude-sonnet", "requests": 11, "tokens": 900, "prompt_tokens": 600,
        "completion_tokens": 200, "cost_usd": 3.0, "share": round(900 / 2100, 4),
    }
    assert body["totals"]["tokens"] == 2100 and body["totals"]["requests"] == 13
    assert body["totals"]["cost_usd"] == 8.0  # cents -> USD
    for route in (users, models):
        assert route.calls.last.request.headers["x-portkey-api-key"] == ADMIN_KEY
    assert "a@x.com" not in r.text, "dashboard must not expose per-user rows"
    assert_no_secrets(r.text)


def test_dashboard_is_cached(client, gateway):
    users = gateway.get(url__regex=USERS_URL).mock(return_value=httpx.Response(200, json={"data": []}))
    gateway.get(url__regex=MODELS_URL).mock(return_value=httpx.Response(200, json={"data": []}))
    for _ in range(3):
        assert client.get("/api/v1/usage/dashboard?scope=org", headers=ADMIN).status_code == 200
    assert users.call_count == 1


def test_dashboard_paginates_users(client, gateway):
    page0 = [{"user": f"u{i}@x.com"} for i in range(100)]
    page1 = [{"user": f"v{i}@x.com"} for i in range(5)]

    def users(request):
        page = int(request.url.params["current_page"])
        return httpx.Response(200, json={"data": page0 if page == 0 else page1})

    gateway.get(url__regex=USERS_URL).mock(side_effect=users)
    gateway.get(url__regex=MODELS_URL).mock(return_value=httpx.Response(200, json={"data": []}))
    body = client.get("/api/v1/usage/dashboard?scope=org", headers=ADMIN).json()
    assert body["totals"]["users"] == 105


def test_dashboard_requires_auth_and_admin_key(gateway):
    with TestClient(make_app(secrets=configured_secrets(PORTKEY_ADMIN_API_KEY="__REPLACE_ME_PORTKEY_ADMIN_API_KEY_LOCAL__"))) as c:
        assert c.get("/api/v1/usage/dashboard").status_code == 401
        r = c.get("/api/v1/usage/dashboard", headers=dev_auth())
    assert r.status_code == 501 and r.json()["error"]["code"] == "usage_not_configured"


@pytest.mark.parametrize("status,code", [(500, "usage_upstream_error"), (403, "usage_forbidden")])
def test_dashboard_upstream_error(client, gateway, status, code):
    gateway.get(url__regex=USERS_URL).mock(return_value=httpx.Response(status, text="boom"))
    gateway.get(url__regex=MODELS_URL).mock(return_value=httpx.Response(200, json={"data": []}))
    r = client.get("/api/v1/usage/dashboard?scope=org", headers=ADMIN)
    assert r.status_code == 502 and r.json()["error"]["code"] == code


# ---------- per-user dashboard (default scope) ----------

def test_org_scope_is_admin_only(client, gateway):
    r = client.get("/api/v1/usage/dashboard?scope=org", headers=dev_auth("jane@example.com"))
    assert r.status_code == 403 and r.json()["error"]["code"] == "forbidden"


def test_user_dashboard_filters_by_caller_and_reports_unavailable_graphs(client, gateway):
    models = gateway.get(url__regex=MODELS_URL).mock(
        return_value=httpx.Response(200, json={"data": [{"model": "nova-lite", "requests": 3}, {"model": "sonnet", "requests": 1}]})
    )
    graphs = gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403, json={"error": "no"}))
    r = client.get("/api/v1/usage/dashboard?days=7", headers=dev_auth("Jane@Example.com"))
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["scope"] == "user" and body["user"] == "Jane@Example.com"
    assert body["unavailable"] == ["tokens", "cost", "series"] and "series" not in body
    assert body["totals"]["requests"] == 4 and body["totals"]["users"] == 1 and body["totals"]["tokens"] == 0
    assert [m["model"] for m in body["models"]] == ["nova-lite", "sonnet"] and body["models"][0]["share"] == 0.75
    sent = models.calls.last.request.url.params
    assert sent["metadata"] == '{"_user":"jane@example.com"}'
    assert graphs.calls and all(c.request.url.params["metadata"] == '{"_user":"jane@example.com"}' for c in graphs.calls)
    assert models.calls.last.request.headers["x-portkey-api-key"] == ADMIN_KEY
    assert_no_secrets(r.text)


def test_user_dashboard_uses_graphs_when_permitted(client, gateway):
    gateway.get(url__regex=MODELS_URL).mock(
        return_value=httpx.Response(200, json={"data": [{"model": "sonnet", "requests": 5, "total_tokens": 900, "cost": 120}]})
    )

    def graph(request):
        metric = request.url.path.rsplit("/", 1)[-1]
        totals = {"requests": 5, "tokens": 1000, "cost": 150}
        day = request.url.params["time_of_generation_max"][:10]
        return httpx.Response(200, json={"summary": {"total": totals[metric]}, "data_points": [{"timestamp": f"{day}T00:00:00Z", "total": totals[metric]}]})

    gateway.get(url__regex=GRAPH_URL).mock(side_effect=graph)
    body = client.get("/api/v1/usage/dashboard?days=7", headers=dev_auth()).json()
    assert body["unavailable"] == []
    assert body["totals"]["tokens"] == 1000 and body["totals"]["cost_usd"] == 1.5 and body["totals"]["requests"] == 5
    assert len(body["series"]) == 8 and body["series"][-1]["tokens"] == 1000 and body["series"][-1]["users"] == 1
    assert body["previous"]["tokens"] == 1000 and body["previous"]["cost_usd"] == 1.5


def test_user_dashboard_without_traffic(client, gateway):
    gateway.get(url__regex=MODELS_URL).mock(return_value=httpx.Response(200, json={"data": []}))
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    body = client.get("/api/v1/usage/dashboard", headers=dev_auth()).json()
    assert body["models"] == [] and body["totals"]["users"] == 0 and body["totals"]["requests"] == 0


def test_summarize_and_count_helpers():
    assert summarize_models([], "usd") == []
    rows = [{"ai_model": "m", "req_units": 3, "res_units": 4, "cost": 1.5}, {"name": None, "tokens": True}]
    out = summarize_models(rows, "usd")
    assert out[0]["model"] == "m" and out[0]["tokens"] == 7 and out[0]["cost_usd"] == 1.5
    assert count_users([{"user": "A@x.com"}, {"user": "a@x.com"}, {"user": ""}], None) == 1
    assert count_users([], 9) == 9


# ---------- local browser sign-in ----------

@pytest.mark.parametrize(
    "uri,ok",
    [
        (CB, True),
        ("vscode-insiders://aig.aig-ai-ecosystem/auth-callback", True),
        ("vscode://AIG.aig-ai-ecosystem/auth-callback?windowId=1", True),
        ("vscode://evil.ext/auth-callback", False),
        ("https://evil.example.com/auth-callback", False),
        ("vscode://aig.aig-ai-ecosystem/other", False),
        ("vscode://aig.aig-ai-ecosystem/auth-callback#x", False),
        ("javascript:alert(1)", False),
        ("", False),
    ],
)
def test_valid_redirect_uri(uri, ok):
    assert valid_redirect_uri(uri) is ok


def test_callback_url_replaces_injected_params():
    url = callback_url(CB + "?windowId=2&email=evil@x.com&state=bad", "jane@example.com", STATE)
    q = parse_qs(urlsplit(url).query)
    assert q == {"windowId": ["2"], "email": ["jane@example.com"], "state": [STATE]}


def test_signin_form_renders_with_csp(client):
    r = client.get("/auth/local/signin", params={"redirect_uri": CB, "state": STATE, "login_hint": "jane@example.com"})
    assert r.status_code == 200
    assert "default-src 'none'" in r.headers["content-security-policy"]
    assert "form-action 'self'" in r.headers["content-security-policy"]
    assert r.headers["cache-control"] == "no-store"
    assert 'value="jane@example.com"' in r.text and "<script" not in r.text


@pytest.mark.parametrize(
    "params",
    [{"redirect_uri": "https://evil.example.com/auth-callback", "state": STATE}, {"redirect_uri": CB, "state": "short"}, {}],
)
def test_signin_form_rejects_bad_params(client, params):
    assert client.get("/auth/local/signin", params=params).status_code == 400


def test_signin_submit_redirects_back_to_vscode(client):
    r = client.post("/auth/local/signin", data={"redirect_uri": CB, "state": STATE, "email": "jane@example.com"})
    assert r.status_code == 200
    expected = f"{CB}?email=jane%40example.com&amp;state={STATE}"
    assert f'content="0;url={expected}"' in r.text
    assert f'href="{expected}"' in r.text


def test_signin_submit_invalid_email_rerenders_escaped(client):
    r = client.post("/auth/local/signin", data={"redirect_uri": CB, "state": STATE, "email": '"><script>x</script>'})
    assert r.status_code == 200
    assert "Enter a valid email" in r.text and "<script>x" not in r.text and "http-equiv=\"refresh\"" not in r.text


def test_signin_submit_rejects_open_redirect(client):
    r = client.post("/auth/local/signin", data={"redirect_uri": "https://evil.example.com/x", "state": STATE, "email": "a@b.co"})
    assert r.status_code == 400


def test_signin_not_available_outside_dev_mode(rsa_key):
    app = make_app(env="dev", auth_mode="oidc", key_resolver=lambda _t: rsa_key.public_key())
    with TestClient(app) as c:
        assert c.get("/auth/local/signin", params={"redirect_uri": CB, "state": STATE}).status_code == 404
        assert c.post("/auth/local/signin", data={"redirect_uri": CB, "state": STATE, "email": "a@b.co"}).status_code == 404
    with TestClient(make_app(env="local", auth_mode="oidc")) as c:
        assert c.get("/auth/local/signin", params={"redirect_uri": CB, "state": STATE}).status_code == 404


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("vscode://aig.aig-ai-ecosystem/auth-callback%3FwindowId=6", "vscode://aig.aig-ai-ecosystem/auth-callback?windowId=6"),
        ("vscode://aig.aig-ai-ecosystem/auth-callback%253FwindowId%253D6", "vscode://aig.aig-ai-ecosystem/auth-callback?windowId=6"),
        ("vscode://aig.aig-ai-ecosystem/auth-callback?windowId=6", "vscode://aig.aig-ai-ecosystem/auth-callback?windowId=6"),
        ("vscode://evil.ext/auth-callback%3Fx=1", "vscode://evil.ext/auth-callback?x=1"),
    ],
)
def test_normalize_redirect_uri(raw, expected):
    assert normalize_redirect_uri(raw) == expected


def test_signin_accepts_encoded_window_id_and_keeps_it(client):
    """Regression: VS Code's callback '?windowId=6' arrived percent-encoded into the path (%253F)."""
    mangled = "vscode://aig.aig-ai-ecosystem/auth-callback%3FwindowId=6"
    assert client.get("/auth/local/signin", params={"redirect_uri": mangled, "state": STATE}).status_code == 200
    r = client.post("/auth/local/signin", data={"redirect_uri": mangled, "state": STATE, "email": "jane@example.com"})
    assert r.status_code == 200
    assert f'href="{CB}?windowId=6&amp;email=jane%40example.com&amp;state={STATE}"' in r.text


def test_normalized_foreign_authority_still_rejected(client):
    r = client.get("/auth/local/signin", params={"redirect_uri": "vscode://evil.ext/auth-callback%3Fx=1", "state": STATE})
    assert r.status_code == 400


def test_usage_me_reports_cost_in_usd_like_the_dashboard(client, gateway):
    """Regression: /usage/me returned Portkey's raw cost (cents) while the dashboard showed USD."""
    gateway.get(url__regex=USERS_URL).mock(
        return_value=httpx.Response(200, json={"data": [{"user": "jane@example.com", "requests": 3, "tokens": 900, "cost": 250}]})
    )
    body = client.get("/api/v1/usage/me", headers=dev_auth()).json()
    assert body["cost"] == 250 and body["cost_usd"] == 2.5
