"""platform-api reproduces every ``kind: agent_invocation`` fixture in backend/contracts/fixtures:
the request it sends to an agent (headers, body, AgentCore session id, caller-token header and
claims), how it parses agent SSE streams and how it maps non-stream agent answers."""

from __future__ import annotations

import asyncio
import json
import uuid
from types import SimpleNamespace

import httpx
import jwt
import pytest
import respx
from conftest import PROJECT_ROOT

import platform_api.caller_token as caller_token_mod
import platform_api.invoker as invoker_mod
from platform_api.agent_secrets import AgentAuthenticator, DefaultSecretResolver
from platform_api.agents import AgentRecord
from platform_api.agents_db import DbAgentRegistry, DbAgentVersions
from platform_api.caller_token import CallerTokenSigner
from platform_api.config import Settings
from platform_api.db import Database
from platform_api.invocations import InvocationStore
from platform_api.invoker import AgentCoreInvoker, HttpsInvoker, InvocationError, Invoker, SseParser

FIXTURES = PROJECT_ROOT.parent / "contracts" / "fixtures"
SIGNED = "<signed:caller-token>"
KID = "<signing-key:kid>"
ENDPOINT = "https://agent.contract.test"
ARN = "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/contract_agent-AbC123"


def load(case: str) -> list[dict]:
    out = []
    for p in sorted(FIXTURES.glob("*.json")):
        fx = json.loads(p.read_text())
        if fx["kind"] == "agent_invocation" and fx["input"]["invocation"]["case"] == case:
            out.append(fx)
    return out


def test_fixtures_exist():
    assert len(load("request")) >= 5 and len(load("stream")) >= 3 and len(load("response")) >= 2


def build_invoker(env: str, client: httpx.AsyncClient | None = None) -> Invoker:
    db = Database.in_memory()
    settings = Settings(env=env, auth_mode="dev" if env == "local" else "oidc")
    https = HttpsInvoker(lambda: client, AgentAuthenticator(DefaultSecretResolver(env=env, secrets_dir=PROJECT_ROOT)))
    return Invoker(settings=settings, registry=DbAgentRegistry(db), versions=DbAgentVersions(db),
                   store=InvocationStore(db), db=db, signer=CallerTokenSigner.generate(env=env, ttl_seconds=300),
                   cipher=None, https=https, agentcore=AgentCoreInvoker(), secrets_provider=lambda: [],
                   disabled_reason=None)


def seed(invoker: Invoker, inv: dict) -> SimpleNamespace:
    agent, caller = inv["agent"], inv["caller"]
    invoker.registry.register(AgentRecord(agent_id=agent["agent_id"], owner=caller["email"], team=caller["team"],
                                          lifecycle="active"))
    fields = {"kind": agent["kind"], "input_schema": agent.get("input_schema"),
              "endpoint": ENDPOINT if agent["kind"] == "https" else None,
              "runtime_arn": ARN if agent["kind"] == "agentcore" else None}
    invoker.versions.upsert(agent["agent_id"], agent["version"], agent["env"], fields=fields, created_by="t",
                            verification={"passed": True})
    return SimpleNamespace(email=caller["email"], name=caller["name"], team=caller["team"],
                           groups=frozenset(caller.get("groups") or ()), is_service=False,
                           profile=SimpleNamespace(user_tier=caller["tier"]))


@pytest.mark.parametrize("fx", load("request"), ids=lambda f: f["name"])
def test_request_fixtures(fx, monkeypatch):
    inv = fx["input"]["invocation"]
    monkeypatch.setattr(invoker_mod.uuid, "uuid4", lambda: uuid.UUID(inv["invocation_id"]))
    monkeypatch.setattr(caller_token_mod.time, "time", lambda: inv["now"])
    invoker = build_invoker(inv["env"])
    invoker.signer.ttl_seconds = int(inv.get("ttl_seconds") or 300)
    caller = seed(invoker, inv)
    expected = fx["expected"]
    try:
        plan = invoker.prepare(caller, inv["agent"]["agent_id"], inv["client_body"], env=inv["agent"]["env"],
                               mode=inv.get("mode") or "sync",
                               trace_id=(inv.get("request_headers") or {}).get("x-aig-trace-id"))
        handle = invoker.open(plan)
    except InvocationError as exc:
        assert "error" in expected, f"unexpected refusal {exc.code}: {exc.message}"
        assert exc.code == expected["error"]["code"] and exc.status == expected["error"]["http_status"]
        assert exc.message.split(":")[0] == expected["error"]["field"]
        return
    call = handle.call
    token = call.caller_token
    want = expected["agent_request"]
    headers = {**call.headers, "x-aig-caller": SIGNED}
    assert headers == want["headers"]
    body = json.loads(json.dumps(call.body))
    if "aig_context" in body:
        assert body["aig_context"]["caller"] == token
        body["aig_context"]["caller"] = SIGNED
    assert body == want["body"]
    assert want["transport"] == call.version.kind
    if call.version.kind == "agentcore":
        assert call.runtime_session_id == want["runtime_session_id"]
        params = AgentCoreInvoker.params(call)
        assert params["runtimeSessionId"] == want["runtime_session_id"] and params["agentRuntimeArn"] == ARN
        assert json.loads(params["payload"])["aig_context"]["caller"] == token
    header = jwt.get_unverified_header(token)
    assert header == {**expected["caller_token"]["header"], "kid": invoker.signer.kid}
    claims = jwt.decode(token, options={"verify_signature": False})
    assert claims == expected["caller_token"]["claims"]
    # And the signature verifies with the published JWKS key, the way an agent verifies it.
    key = jwt.PyJWK(invoker.signer.jwks()["keys"][0]).key
    jwt.decode(token, key, algorithms=["ES256"], audience=inv["agent"]["agent_id"], options={"verify_exp": False,
                                                                                              "verify_iat": False,
                                                                                              "verify_nbf": False})


@pytest.mark.parametrize("fx", load("stream"), ids=lambda f: f["name"])
def test_stream_fixtures(fx):
    inv = fx["input"]["invocation"]
    parser = SseParser(1 << 20)
    events = []
    for line in inv["sse"].split("\n"):
        e = parser.line(line)
        if e is not None:
            events.append({"event": e.kind, "data": e.data})
    tail = parser.close()
    if tail is not None:
        events.append({"event": tail.kind, "data": tail.data})
    assert events == fx["expected"]["events"]
    assert run_through_invoker(fx, httpx.Response(200, headers={"content-type": "text/event-stream"},
                                                  content=inv["sse"].encode())) == fx["expected"]["result"]


@pytest.mark.parametrize("fx", load("response"), ids=lambda f: f["name"])
def test_response_fixtures(fx):
    inv = fx["input"]["invocation"]
    result = run_through_invoker(fx, httpx.Response(inv["http_status"], json=inv["body"]))
    expected = dict(fx["expected"]["result"])
    assert result.pop("text", "") == ""
    assert result == expected


def run_through_invoker(fx: dict, response: httpx.Response) -> dict:
    """Full Invoker.run over the HTTPS transport (respx), reduced to the fixture's result shape."""
    inv = {"agent": {"agent_id": "contract-agent", "version": "1", "env": "prod", "kind": "https"},
           "caller": {"email": "bob@example.com", "name": "Bob", "team": "claims-ai", "tier": "standard"}}

    async def go() -> dict:
        with respx.mock() as router:
            router.post(f"{ENDPOINT}/invocations").mock(return_value=response)
            async with httpx.AsyncClient() as client:
                invoker = build_invoker("local", client)
                caller = seed(invoker, inv)
                handle = invoker.open(invoker.prepare(caller, "contract-agent", {"messages": [
                    {"role": "user", "content": "x"}]}, mode="stream"))
                events = [e async for e in invoker.run(handle)]
        o = handle.outcome
        assert events[-1]["event"] == "done" and events[-1]["data"]["status"] == o.status
        if o.error is not None:
            err = {"code": o.error.code, "message": o.error.message}
            if fx["input"]["invocation"]["case"] == "response":
                err = {"code": o.error.code, "http_status": o.error.status, "message": o.error.message}
            return {"status": o.status, "error": err, "text": o.text}
        out = {"status": o.status, "output": o.output, "text": o.text}
        if o.usage:
            out["usage"] = o.usage
        return out

    return asyncio.run(go())
