"""Phase 1: agent registry, Portkey agent-check webhook guardrail, default IDE agent id and
user-directory validation."""

from __future__ import annotations

import json
import logging

import httpx
import pytest
import respx
import yaml
from fastapi.testclient import TestClient

from conftest import PORTKEY_KEY, PROJECT_ROOT, USERS, assert_no_secrets, dev_auth, make_settings
from platform_api.agents import (
    BUILTIN_AGENTS,
    DEFAULT_AGENT_BY_HOST,
    YamlAgentRegistry,
    default_agent_for_host,
    resolve_agents_file,
)
from platform_api.errors import StartupError
from platform_api.main import create_app
from platform_api.routes.guardrails import evaluate_agent_check
from platform_api.secrets import SecretStore
from platform_api.users import YamlUserDirectory, validate_user_directory

WEBHOOK_SECRET = "whsec-SUPERSECRET-0011223344556677"
URL = "/api/v1/guardrails/agent-check"
GATEWAY = "http://localhost:8787/v1/chat/completions"
REGISTRY_DATA = {
    "agents": {
        "uw-quote-assistant": {"owner": "jane@example.com", "team": "underwriting-ai", "status": "active"},
        "legacy-bot": {"owner": "bob@example.com", "team": "claims-ai", "status": "suspended"},
    }
}


def secrets(**extra) -> SecretStore:
    values = {"PORTKEY_API_KEY": PORTKEY_KEY, "PORTKEY_WEBHOOK_SECRET": WEBHOOK_SECRET}
    values.update(extra)
    return SecretStore(values)


def app_with(env="local", auth_mode=None, store=None, registry=None):
    auth_mode = auth_mode or ("dev" if env == "local" else "oidc")
    return create_app(
        make_settings(env, auth_mode),
        secrets=store if store is not None else secrets(),
        users=YamlUserDirectory(USERS, "standard"),
        agents=registry if registry is not None else YamlAgentRegistry(REGISTRY_DATA),
    )


def payload(**meta) -> dict:
    base = {"user_tier": "premium", "job_profile": "underwriting", "agent_id": "uw-quote-assistant",
            "team": "underwriting-ai", "env": "dev", "host": "laptop"}
    base.update(meta)
    base = {k: v for k, v in base.items() if v is not None}
    return {
        "request": {"json": {"model": "x", "messages": [{"role": "user", "content": "PROMPT-SECRET"}]}},
        "response": {},
        "provider": "anthropic",
        "requestType": "chatComplete",
        "metadata": base,
        "eventType": "beforeRequestHook",
    }


def call(client, body, secret=WEBHOOK_SECRET):
    headers = {"x-aig-webhook-secret": secret} if secret is not None else {}
    return client.post(URL, json=body, headers=headers)


# --- webhook verdicts --------------------------------------------------------------------


def test_active_registered_agent_allowed():
    with TestClient(app_with()) as c:
        r = call(c, payload())
    assert r.status_code == 200
    assert r.json() == {
        "verdict": True,
        "data": {"reason": "agent_active", "agent_id": "uw-quote-assistant", "owner_team": "underwriting-ai"},
    }


@pytest.mark.parametrize(
    "meta,reason",
    [
        ({"agent_id": "nobody-registered-this"}, "agent_unregistered"),
        ({"agent_id": "legacy-bot", "team": "claims-ai"}, "agent_suspended"),
        ({"agent_id": None}, "required_metadata_missing"),
        ({"team": None}, "required_metadata_missing"),
        ({"user_tier": None}, "required_metadata_missing"),
        ({"job_profile": None}, "required_metadata_missing"),
        ({"agent_id": "  "}, "required_metadata_missing"),
        ({"agent_id": "bad id!"}, "invalid_agent_id"),
        ({"team": "claims-ai"}, "team_mismatch"),
    ],
)
def test_denied_verdicts(meta, reason):
    with TestClient(app_with()) as c:
        r = call(c, payload(**meta))
    assert r.status_code == 200
    body = r.json()
    assert body["verdict"] is False
    assert body["data"]["reason"] == reason
    if reason in ("agent_unregistered", "agent_suspended"):
        assert body["data"]["error"] == "AIG_E_AGENT_UNREGISTERED"


def test_missing_metadata_denied():
    body = payload()
    del body["metadata"]
    with TestClient(app_with()) as c:
        r = call(c, body)
    assert r.json()["verdict"] is False and r.json()["data"]["reason"] == "metadata_missing"


def test_metadata_as_json_string_and_nested_under_request():
    as_string = payload()
    as_string["metadata"] = json.dumps(as_string["metadata"])
    nested = payload()
    nested["request"]["metadata"] = nested.pop("metadata")
    with TestClient(app_with()) as c:
        assert call(c, as_string).json()["verdict"] is True
        assert call(c, nested).json()["verdict"] is True


@pytest.mark.parametrize("raw", [b"not json", b"[1,2]", b"null", b""])
def test_malformed_payload_fails_closed(raw):
    with TestClient(app_with()) as c:
        r = c.post(URL, content=raw, headers={"x-aig-webhook-secret": WEBHOOK_SECRET})
    assert r.status_code == 200
    assert r.json()["verdict"] is False
    assert r.json()["data"]["reason"] == "invalid_payload"


@pytest.mark.parametrize("agent_id", list(DEFAULT_AGENT_BY_HOST.values()))
def test_builtin_ide_agents_are_shared_and_allowed_for_any_team(agent_id):
    with TestClient(app_with(registry=YamlAgentRegistry(None))) as c:
        r = call(c, payload(agent_id=agent_id, team="claims-ai", host="vscode"))
    assert r.json()["verdict"] is True


def test_registry_file_can_suspend_a_builtin_agent():
    reg = YamlAgentRegistry({"agents": {"ide.eclipse": {"owner": "p@example.com", "team": "aig-platform",
                                                         "status": "suspended", "shared": True}}})
    assert evaluate_agent_check(reg, payload(agent_id="ide.eclipse"))["data"]["reason"] == "agent_suspended"
    assert evaluate_agent_check(reg, payload(agent_id="ide.vscode"))["verdict"] is True


def test_registry_exception_fails_closed():
    class Broken:
        def get(self, agent_id):
            raise RuntimeError("db down")

        def all(self):
            return []

    with TestClient(app_with(registry=Broken())) as c:
        r = call(c, payload())
    assert r.json() == {"verdict": False, "data": {"reason": "internal_error", "message": "agent check failed"}}


# --- webhook authentication --------------------------------------------------------------


@pytest.mark.parametrize("bad", [None, "", "wrong", WEBHOOK_SECRET + "x", WEBHOOK_SECRET[:-1]])
def test_wrong_or_missing_secret_rejected(bad):
    with TestClient(app_with()) as c:
        r = call(c, payload(), secret=bad)
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "webhook_unauthenticated"
    assert_no_secrets(r.text)


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
@pytest.mark.parametrize("value", [None, "__REPLACE_ME_PORTKEY_WEBHOOK_SECRET_DEV__"])
def test_unconfigured_secret_rejected_outside_local(env, value):
    app = app_with(env=env, store=SecretStore({"PORTKEY_API_KEY": PORTKEY_KEY, "PORTKEY_WEBHOOK_SECRET": value}))
    with TestClient(app) as c:
        r = call(c, payload(), secret="anything")
    assert r.status_code == 503
    assert r.json()["error"]["code"] == "webhook_not_configured"


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
def test_configured_secret_works_outside_local(env):
    with TestClient(app_with(env=env)) as c:
        assert call(c, payload()).json()["verdict"] is True
        assert call(c, payload(), secret="nope").status_code == 401


def test_unconfigured_secret_allowed_in_local_with_warning(caplog):
    caplog.set_level(logging.WARNING)
    with TestClient(app_with(store=SecretStore({"PORTKEY_API_KEY": PORTKEY_KEY}))) as c:
        r = call(c, payload(), secret=None)
    assert r.json()["verdict"] is True
    assert "PORTKEY_WEBHOOK_SECRET" in caplog.text


def test_secret_and_prompt_never_logged_or_returned(caplog, capfd):
    caplog.set_level(logging.DEBUG)
    with TestClient(app_with()) as c:
        r1 = call(c, payload())
        r2 = call(c, payload(), secret="wrong")
        h = c.get("/healthz").json()
    out, err = capfd.readouterr()
    text = caplog.text + out + err + r1.text + r2.text + json.dumps(h)
    assert WEBHOOK_SECRET not in text
    assert "PROMPT-SECRET" not in caplog.text + out + err
    assert h["secrets"]["PORTKEY_WEBHOOK_SECRET"] == "configured"


def test_secret_compared_in_constant_time():
    src = (PROJECT_ROOT / "src" / "platform_api" / "routes" / "guardrails.py").read_text()
    assert "hmac.compare_digest" in src


# --- default agent id for IDE traffic ----------------------------------------------------


def test_default_agent_for_host_mapping():
    assert default_agent_for_host("vscode") == "ide.vscode"
    assert default_agent_for_host("eclipse") == "ide.eclipse"
    assert default_agent_for_host("web") == "web.portal"
    with pytest.raises(ValueError):
        default_agent_for_host("laptop")
    assert {a.agent_id for a in BUILTIN_AGENTS} == set(DEFAULT_AGENT_BY_HOST.values())


def test_http_proxy_sends_ide_vscode_when_client_sends_no_agent():
    with respx.mock(assert_all_called=False) as gw, TestClient(app_with()) as c:
        route = gw.post(GATEWAY).mock(return_value=httpx.Response(200, json={"choices": []}))
        r = c.post("/api/v1/llm/chat/completions", json={"model": "x", "messages": []}, headers=dev_auth())
        assert r.status_code == 200
        meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["agent_id"] == "ide.vscode" and meta["host"] == "vscode"
    # ...and the gateway's agent-check webhook allows exactly that metadata.
    assert evaluate_agent_check(YamlAgentRegistry(None), {"metadata": meta})["verdict"] is True


def test_ws_chat_sends_ide_vscode_when_client_sends_no_agent():
    sse = b'data: {"choices":[{"index":0,"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n'
    with respx.mock(assert_all_called=False) as gw, TestClient(app_with()) as c:
        route = gw.post(GATEWAY).mock(
            return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, content=sse)
        )
        with c.websocket_connect("/api/v1/ws", headers=dev_auth()) as ws:
            assert json.loads(ws.receive_text())["type"] == "ready"
            ws.send_text(json.dumps({"type": "chat", "id": "c1", "messages": [{"role": "user", "content": "hi"}]}))
            while json.loads(ws.receive_text())["type"] not in ("chat.done", "chat.error"):
                pass
        meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["agent_id"] == "ide.vscode"


def test_client_agent_id_still_wins():
    with respx.mock(assert_all_called=False) as gw, TestClient(app_with()) as c:
        route = gw.post(GATEWAY).mock(return_value=httpx.Response(200, json={"choices": []}))
        c.post("/api/v1/llm/chat/completions", json={"model": "x", "messages": []},
               headers={**dev_auth(), "x-aig-agent-id": "uw-quote-assistant"})
        meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["agent_id"] == "uw-quote-assistant"


# --- agent registry file handling --------------------------------------------------------


def test_example_agents_file_is_valid_and_has_ide_agents():
    data = yaml.safe_load((PROJECT_ROOT / "config" / "agents.example.yaml").read_text())
    reg = YamlAgentRegistry(data, env="prod")  # strict validation
    for agent_id in DEFAULT_AGENT_BY_HOST.values():
        assert reg.get(agent_id) is not None and reg.get(agent_id).shared
    assert reg.get("legacy-claims-bot").status == "suspended"


@pytest.mark.parametrize(
    "entry",
    [
        {"owner": "a@example.com", "team": "t", "status": "paused"},
        {"owner": "", "team": "t", "status": "active"},
        {"owner": "a@example.com", "team": "", "status": "active"},
        {"owner": "a@example.com", "team": "bad team", "status": "active"},
        "not-a-mapping",
    ],
)
def test_invalid_agent_entries_fail_outside_local_warn_in_local(entry, caplog):
    data = {"agents": {"some-agent": entry}}
    with pytest.raises(StartupError, match="invalid agent registry"):
        YamlAgentRegistry(data, env="prod")
    caplog.set_level(logging.WARNING)
    reg = YamlAgentRegistry(data, env="local")
    assert reg.get("some-agent") is None
    assert "ignoring invalid agent registry" in caplog.text


def test_invalid_agent_id_key_rejected():
    with pytest.raises(StartupError):
        YamlAgentRegistry({"agents": {"bad id": {"owner": "a@example.com", "team": "t"}}}, env="dev")


def test_agents_example_file_only_in_local(tmp_path, caplog):
    (tmp_path / "agents.example.yaml").write_text("agents: {}\n")
    assert resolve_agents_file("local", tmp_path) == tmp_path / "agents.example.yaml"
    caplog.set_level(logging.WARNING)
    for env in ("dev", "stage", "prod"):
        assert resolve_agents_file(env, tmp_path) is None
        assert resolve_agents_file(env, tmp_path, tmp_path / "agents.example.yaml") is None
    (tmp_path / "agents.yaml").write_text("agents: {}\n")
    assert resolve_agents_file("prod", tmp_path) == tmp_path / "agents.yaml"
    assert resolve_agents_file("prod", tmp_path, tmp_path / "missing.yaml") is None


def test_real_agents_file_not_committed_and_gitignored():
    assert not (PROJECT_ROOT / "config" / "agents.yaml").exists()
    assert "config/agents.yaml" in (PROJECT_ROOT / ".gitignore").read_text()


def test_outside_local_without_file_only_builtins_registered(monkeypatch):
    monkeypatch.delenv("AIG_AGENTS_FILE", raising=False)
    app = create_app(make_settings("prod", "oidc"), secrets=secrets(), users=YamlUserDirectory(USERS, "standard"))
    ids = {a.agent_id for a in app.state.agents.all()}
    assert ids == set(DEFAULT_AGENT_BY_HOST.values())


def test_local_uses_example_agents(monkeypatch):
    monkeypatch.delenv("AIG_AGENTS_FILE", raising=False)
    app = create_app(make_settings("local", "dev"), secrets=secrets(), users=YamlUserDirectory(USERS, "standard"))
    assert app.state.agents.get("uw-quote-assistant") is not None


def test_agents_file_setting(tmp_path):
    f = tmp_path / "agents.yaml"
    f.write_text(yaml.safe_dump({"agents": {"x.y": {"owner": "o@example.com", "team": "t1", "status": "active"}}}))
    app = create_app(make_settings("dev", "oidc", agents_file=f), secrets=secrets(),
                     users=YamlUserDirectory(USERS, "standard"))
    assert app.state.agents.get("x.y").team == "t1"


# --- user directory validation -----------------------------------------------------------


def test_example_user_directory_is_valid():
    assert validate_user_directory(yaml.safe_load((PROJECT_ROOT / "config" / "users.example.yaml").read_text())) == []


@pytest.mark.parametrize(
    "users,needle",
    [
        ({"a@example.com": {"team": "t", "tier": "gold"}}, "tier"),
        ({"a@example.com": {"team": "t"}}, "tier"),
        ({"a@example.com": {"team": "", "tier": "free"}}, "team"),
        ({"a@example.com": {"tier": "free"}}, "team"),
        ({"a@example.com": {"team": "has space", "tier": "free"}}, "team"),
        ({"a@example.com": "premium"}, "mapping"),
    ],
)
def test_invalid_user_entries(users, needle, tmp_path, caplog):
    assert any(needle in p for p in validate_user_directory({"users": users}))
    f = tmp_path / "users.yaml"
    f.write_text(yaml.safe_dump({"users": users}))
    for env in ("dev", "stage", "prod"):
        with pytest.raises(StartupError, match="invalid user directory"):
            YamlUserDirectory.from_file(f, "standard", env=env)
    caplog.set_level(logging.WARNING)
    d = YamlUserDirectory.from_file(f, "standard", env="local")
    assert "ignoring invalid user directory" in caplog.text
    profile = d.lookup("a@example.com")
    assert profile.user_tier == "standard" and profile.team == "unassigned"  # invalid entry dropped


def test_invalid_default_team_rejected(tmp_path):
    f = tmp_path / "users.yaml"
    f.write_text("default_team: 'bad team'\nusers: {}\n")
    with pytest.raises(StartupError):
        YamlUserDirectory.from_file(f, "standard", env="prod")
    assert YamlUserDirectory.from_file(f, "standard", env="local").default_team == "unassigned"


def test_startup_fails_outside_local_with_invalid_users_file(tmp_path):
    f = tmp_path / "users.yaml"
    f.write_text("users:\n  jane@example.com: {tier: gold, team: real}\n")
    with pytest.raises(StartupError, match="invalid user directory"):
        create_app(make_settings("stage", "oidc", users_file=f), secrets=secrets())


def test_valid_entries_kept_in_local_when_others_invalid(tmp_path):
    f = tmp_path / "users.yaml"
    f.write_text("users:\n  a@example.com: {tier: gold, team: t}\n  b@example.com: {tier: premium, team: t2}\n")
    d = YamlUserDirectory.from_file(f, "free", env="local")
    assert d.lookup("b@example.com").user_tier == "premium"
    assert d.lookup("a@example.com").user_tier == "free"
