"""AgentCore transport: bedrock-agentcore invoke_agent_runtime via botocore Stubber (JSON and SSE
answers, parameters incl. the caller-scoped runtimeSessionId and aig_context, error mapping)."""

from __future__ import annotations

import io
import json

import boto3
import pytest
from agent_helpers import BOB, CARA, SVC, build_app, parse_sse, register_agent, register_version
from botocore.response import StreamingBody
from botocore.stub import ANY, Stubber
from fastapi.testclient import TestClient

from platform_api.invoker import AgentCoreInvoker, runtime_session_id

ARN = "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/claims_triage-AbC123"
INVOKE = "/api/v1/agents/claims-triage/invoke"


def body_of(data: bytes) -> StreamingBody:
    return StreamingBody(io.BytesIO(data), len(data))


@pytest.fixture
def stubbed():
    client = boto3.client("bedrock-agentcore", region_name="us-east-1", aws_access_key_id="AKIDEXAMPLE",
                          aws_secret_access_key="example-not-a-secret")
    with Stubber(client) as stub:
        yield client, stub
        stub.assert_no_pending_responses()


def _app(client):
    return build_app(agentcore_client_factory=lambda: client)


def _setup(c, qualifier="prod"):
    register_agent(c)
    register_version(c, kind="agentcore", endpoint=None, runtime_arn=ARN, qualifier=qualifier, verified=True, activate=True)


def test_sync_json_answer_and_parameters(stubbed):
    client, stub = stubbed
    answer = json.dumps({"output": {"severity": "LOW"}, "usage": {"prompt_tokens": 5, "completion_tokens": 2,
                                                                  "total_tokens": 7}, "trace_id": "x" * 8}).encode()
    stub.add_response("invoke_agent_runtime",
                      {"contentType": "application/json", "response": body_of(answer), "statusCode": 200},
                      {"agentRuntimeArn": ARN, "qualifier": "prod", "contentType": "application/json",
                       "accept": "application/json", "runtimeSessionId": ANY, "payload": ANY})
    with TestClient(_app(client)) as c:
        _setup(c)
        r = c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "CLM-7"}, "session_id": "case-CLM-7"})
        assert r.status_code == 200, r.text
        assert r.json()["output"] == {"severity": "LOW"} and r.json()["usage"]["total_tokens"] == 7
        assert c.get(f"/api/v1/invocations/{r.json()['invocation_id']}", headers=CARA).json()["status"] == "succeeded"


def test_payload_carries_aig_context_and_scoped_session(stubbed, monkeypatch):
    client, stub = stubbed
    captured = {}
    real = AgentCoreInvoker._invoke

    def spy(self, params, headers):
        captured["params"], captured["headers"] = params, headers
        return real(self, params, headers)

    monkeypatch.setattr(AgentCoreInvoker, "_invoke", spy)
    stub.add_response("invoke_agent_runtime", {"contentType": "application/json",
                                               "response": body_of(b'{"output": "ok"}'), "statusCode": 200})
    with TestClient(_app(client)) as c:
        _setup(c)
        r = c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "CLM-7"}, "session_id": "case-CLM-7"})
        inv_id = r.json()["invocation_id"]
    params, headers = captured["params"], captured["headers"]
    payload = json.loads(params["payload"])
    assert payload["input"] == {"claim_id": "CLM-7"} and payload["stream"] is False
    assert payload["aig_context"]["invocation_id"] == inv_id
    assert payload["aig_context"]["caller"] == headers["X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller"]
    assert params["runtimeSessionId"] == runtime_session_id("claims-triage", "cara@example.com", "case-CLM-7", inv_id)
    assert 33 <= len(params["runtimeSessionId"]) <= 256
    # Another user with the same session id gets another AgentCore session.
    assert runtime_session_id("claims-triage", "bob@example.com", "case-CLM-7", inv_id) != params["runtimeSessionId"]
    assert runtime_session_id("a", "b@example.com", None, inv_id) == f"aig-inv-{inv_id}"


def test_streaming_answer(stubbed):
    client, stub = stubbed
    sse = (b"event: delta\ndata: {\"text\": \"Sev\"}\n\n: keepalive\n\nevent: delta\ndata: {\"text\": \"ere\"}\n\n"
           b"event: output\ndata: {\"output\": {\"severity\": \"HIGH\"}}\n\nevent: done\ndata: {}\n\n")
    stub.add_response("invoke_agent_runtime",
                      {"contentType": "text/event-stream", "response": body_of(sse), "statusCode": 200},
                      {"agentRuntimeArn": ARN, "contentType": "application/json", "accept": "text/event-stream",
                       "runtimeSessionId": ANY, "payload": ANY})
    with TestClient(_app(client)) as c:
        _setup(c, qualifier=None)
        events = parse_sse(c.post(INVOKE + "?mode=stream", headers=BOB, json={"input": {"claim_id": "1"}}).text)
    assert [e["event"] for e in events] == ["delta", "delta", "output", "done"]
    assert "".join(e["data"]["text"] for e in events[:2]) == "Severe"
    assert events[2]["data"]["output"] == {"severity": "HIGH"}


@pytest.mark.parametrize("error_code,status,code", [
    ("ResourceNotFoundException", 502, "agent_unavailable"),
    ("AccessDeniedException", 502, "agent_unavailable"),
    ("ThrottlingException", 503, "agent_unavailable"),
    ("RuntimeClientError", 502, "agent_error"),
    ("ValidationException", 502, "agent_error"),
])
def test_client_errors_are_mapped(stubbed, error_code, status, code):
    client, stub = stubbed
    stub.add_client_error("invoke_agent_runtime", service_error_code=error_code, service_message="boom",
                          http_status_code=400)
    with TestClient(_app(client)) as c:
        _setup(c)
        r = c.post(INVOKE, headers=BOB, json={"input": {"claim_id": "1"}})
        assert (r.status_code, r.json()["error"]["code"]) == (status, code)
        rec = c.get("/api/v1/invocations?mine=1", headers=BOB).json()["items"][0]
        assert rec["status"] == "failed" and rec["error_code"] == code


def test_only_the_deploy_pipeline_registers_agentcore(stubbed):
    client, _ = stubbed
    with TestClient(_app(client)) as c:
        register_agent(c)
        r = c.post("/api/v1/agents/claims-triage/versions", headers=BOB,
                   json={"version": "1", "env": "prod", "kind": "agentcore", "runtime_arn": ARN})
        assert r.status_code == 403
        assert c.post("/api/v1/agents/claims-triage/versions", headers=SVC,
                      json={"version": "1", "env": "prod", "kind": "agentcore", "runtime_arn": ARN}).status_code == 201


def test_custom_headers_hook_adds_contract_headers():
    from types import SimpleNamespace

    from platform_api.invoker import _AGENTCORE_HEADERS, _add_agentcore_headers

    request = SimpleNamespace(headers={})
    token = _AGENTCORE_HEADERS.set({"X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Trace-Id": "trace-1"})
    try:
        _add_agentcore_headers(request)
    finally:
        _AGENTCORE_HEADERS.reset(token)
    assert request.headers == {"X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Trace-Id": "trace-1"}
    _add_agentcore_headers(request := SimpleNamespace(headers={}))
    assert request.headers == {}


def test_verify_agentcore_skips_health(stubbed):
    client, stub = stubbed
    stub.add_response("invoke_agent_runtime", {"contentType": "application/json",
                                               "response": body_of(b'{"output": "ok"}'), "statusCode": 200})
    app = _app(client)
    with TestClient(app) as c:
        register_agent(c)
        register_version(c, kind="agentcore", endpoint=None, runtime_arn=ARN)
        app.state.agents.touch("claims-triage", "agentcore")
        body = c.post("/api/v1/agents/claims-triage/versions/1.0.0/verify", headers=BOB).json()
    checks = {x["name"]: x["status"] for x in body["checks"]}
    assert checks == {"health": "skipped", "invocation": "passed", "gateway": "passed", "trace": "skipped"}
    assert body["passed"] is True and body["activated"] is True
