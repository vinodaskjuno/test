"""Host-header spoofing, example user directory fallback, split-secret stream redaction."""

from __future__ import annotations

import logging

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from conftest import (
    ADMIN_KEY,
    FIDDLER_KEY,
    PORTKEY_KEY,
    PROJECT_ROOT,
    PUBLIC_BASE_URL,
    assert_no_secrets,
    configured_secrets,
    dev_auth,
    make_app,
    make_jwt,
    make_settings,
)
from platform_api.config import load_env_config
from platform_api.errors import StartupError
from platform_api.main import create_app
from platform_api.users import resolve_users_file

GATEWAY = "http://localhost:8787/v1/chat/completions"
BODY = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}], "stream": True}
NON_LOCAL = ["dev", "stage", "prod"]


# --- 1. AIG_PUBLIC_BASE_URL / Host header ---------------------------------------------


@pytest.mark.parametrize("env", NON_LOCAL)
@pytest.mark.parametrize(
    "value",
    [
        None,
        "",
        "   ",
        "https://__AIG_PUBLIC_BASE_URL_DEV__",
        '"https://__AIG_PUBLIC_BASE_URL_DEV__"',
        "http://aig-api.example.com",
        "aig-api.example.com",
        "https://",
    ],
)
def test_startup_fails_without_valid_public_base_url(env, value):
    with pytest.raises(StartupError, match="AIG_PUBLIC_BASE_URL"):
        make_app(env=env, auth_mode="oidc", public_base_url=value)


@pytest.mark.parametrize("env", NON_LOCAL)
def test_startup_ok_with_https_public_base_url(env):
    app = make_app(env=env, auth_mode="oidc", public_base_url="https://aig-api.example.com/")
    with TestClient(app) as c:
        assert c.get("/healthz").status_code == 200


def test_local_starts_without_public_base_url():
    app = make_app(public_base_url=None)
    with TestClient(app) as c:
        assert c.get("/healthz").status_code == 200


def _oidc_session(env, rsa_key, headers):
    app = make_app(env=env, auth_mode="oidc", key_resolver=lambda _t: rsa_key.public_key())
    cfg = load_env_config(make_settings(env, "oidc"))
    token = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience)
    with TestClient(app) as c:
        return c.get("/api/v1/session", headers={"Authorization": f"Bearer {token}", **headers})


@pytest.mark.parametrize("env", NON_LOCAL)
def test_spoofed_host_header_ignored_outside_local(env, rsa_key):
    r = _oidc_session(
        env,
        rsa_key,
        {"Host": "evil.example.net", "X-Forwarded-Host": "evil.example.net", "X-Forwarded-Proto": "http"},
    )
    assert r.status_code == 200
    base = r.json()["llm"]["base_url"]
    assert base == f"{PUBLIC_BASE_URL}/api/v1/llm"
    assert "evil" not in base


def test_local_falls_back_to_request_url():
    app = make_app(public_base_url=None)
    with TestClient(app) as c:
        body = c.get("/api/v1/session", headers={**dev_auth(), "Host": "localhost:8080"}).json()
    assert body["llm"]["base_url"] == "http://localhost:8080/api/v1/llm"


def test_dockerfile_does_not_trust_all_proxies():
    text = (PROJECT_ROOT / "Dockerfile").read_text()
    assert "ENV FORWARDED_ALLOW_IPS=127.0.0.1" in text
    assert "--forwarded-allow-ips" in text
    assert "FORWARDED_ALLOW_IPS=*" not in text and "'*'" not in text


# --- 2. users.example.yaml only in local ----------------------------------------------


def _example_dir(tmp_path, with_real=False):
    (tmp_path / "users.example.yaml").write_text(
        (PROJECT_ROOT / "config" / "users.example.yaml").read_text()
    )
    if with_real:
        (tmp_path / "users.yaml").write_text("users:\n  jane.doe@example.com: {tier: gold, team: real}\n")
    return tmp_path


def test_example_users_used_in_local(tmp_path):
    assert resolve_users_file("local", _example_dir(tmp_path)) == tmp_path / "users.example.yaml"


@pytest.mark.parametrize("env", NON_LOCAL)
def test_example_users_never_used_outside_local(env, tmp_path, caplog):
    caplog.set_level(logging.WARNING)
    assert resolve_users_file(env, _example_dir(tmp_path)) is None
    assert "default_user_tier" in caplog.text
    # Explicitly pointing AIG_USERS_FILE at the example file is ignored too.
    assert resolve_users_file(env, tmp_path, tmp_path / "users.example.yaml") is None


@pytest.mark.parametrize("env", ["local", *NON_LOCAL])
def test_real_users_file_preferred(env, tmp_path):
    d = _example_dir(tmp_path, with_real=True)
    assert resolve_users_file(env, d) == d / "users.yaml"
    custom = tmp_path / "custom.yaml"
    custom.write_text("users: {}\n")
    assert resolve_users_file(env, d, custom) == custom


@pytest.mark.parametrize("env", NON_LOCAL)
def test_example_premium_tier_not_granted_outside_local(env, rsa_key, monkeypatch):
    # Real repo config dir: has users.example.yaml (jane.doe = premium) but no users.yaml.
    assert not (PROJECT_ROOT / "config" / "users.yaml").exists()
    monkeypatch.delenv("AIG_USERS_FILE", raising=False)
    app = create_app(
        make_settings(env, "oidc"), secrets=configured_secrets(), key_resolver=lambda _t: rsa_key.public_key()
    )
    cfg = load_env_config(make_settings(env, "oidc"))
    token = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience, email="jane.doe@example.com")
    with TestClient(app) as c:
        body = c.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"}).json()
    assert body["user_tier"] == cfg.default_user_tier
    assert body["team"] == "unassigned"


def test_example_premium_tier_still_works_in_local(monkeypatch):
    monkeypatch.delenv("AIG_USERS_FILE", raising=False)
    app = create_app(make_settings("local", "dev"), secrets=configured_secrets())
    with TestClient(app) as c:
        body = c.get("/api/v1/session", headers=dev_auth("jane.doe@example.com")).json()
    assert body["user_tier"] == "premium"


# --- 3. split-secret redaction in streams ---------------------------------------------


class _ChunkStream(httpx.AsyncByteStream):
    def __init__(self, chunks, exc: Exception | None = None):
        self.chunks, self.exc = chunks, exc

    async def __aiter__(self):
        for c in self.chunks:
            yield c
        if self.exc:
            raise self.exc


def _split_every_way(payload: bytes):
    """Yield chunkings that cut the payload at every byte position (2 and 3 pieces)."""
    for i in range(1, len(payload)):
        yield [payload[:i], payload[i:]]
    for i in range(1, len(payload), 3):
        for j in range(i + 1, len(payload), 5):
            yield [payload[:i], payload[i:j], payload[j:]]


def _stream(gateway, chunks, exc=None):
    gateway.post(GATEWAY).mock(
        return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=_ChunkStream(chunks, exc))
    )
    app = make_app()
    with TestClient(app) as c, c.stream("POST", "/api/v1/llm/chat/completions", json=BODY, headers=dev_auth()) as r:
        assert r.status_code == 200
        return b"".join(r.iter_raw())


@pytest.fixture
def gateway():
    with respx.mock(assert_all_called=False) as router:
        yield router


@pytest.mark.parametrize("secret", [PORTKEY_KEY, ADMIN_KEY, FIDDLER_KEY])
def test_secret_split_across_chunks_is_redacted(gateway, secret):
    payload = f'data: {{"echo":"{secret}"}}\n\ndata: [DONE]\n\n'.encode()
    expected = payload.replace(secret.encode(), b"***redacted***")
    cuts = list(_split_every_way(payload))
    for chunks in cuts:
        out = _stream(gateway, chunks)
        assert out == expected, chunks
    assert len(cuts) > len(payload)


def test_one_byte_chunks_redacted_and_order_preserved(gateway):
    payload = f"data: a{PORTKEY_KEY}b{FIDDLER_KEY}c\n\ndata: [DONE]\n\n".encode()
    out = _stream(gateway, [bytes([b]) for b in payload])
    assert out == b"data: a***redacted***b***redacted***c\n\ndata: [DONE]\n\n"


@pytest.mark.parametrize(
    "exc,code",
    [(httpx.ReadTimeout("slow"), "upstream_timeout"), (httpx.ReadError("reset"), "upstream_interrupted")],
)
def test_held_tail_flushed_redacted_before_error_event(gateway, exc, code):
    head = b'data: {"content":"x'
    chunks = [head + PORTKEY_KEY[:10].encode(), PORTKEY_KEY[10:].encode() + b'"}']
    out = _stream(gateway, chunks, exc).decode()
    assert_no_secrets(out)
    body, _, err = out.rpartition("\n\ndata: ")
    assert body == 'data: {"content":"x***redacted***"}'
    assert f'"code":"{code}"' in err


def test_short_tail_flushed_at_end(gateway):
    # Total output shorter than the hold-back window must still be delivered.
    assert _stream(gateway, [b"da", b"ta: x\n\n"]) == b"data: x\n\n"
