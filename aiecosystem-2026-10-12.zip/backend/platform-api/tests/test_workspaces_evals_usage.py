"""Phase 4: team workspaces, eval history, usage by team (live Portkey only), routing view."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
from conftest import ADMIN_KEY, PORTKEY_KEY, USERS, assert_no_secrets, configured_secrets, dev_auth, make_settings
from fastapi.testclient import TestClient
from platform_api.main import create_app
from platform_api.routes.usage import summarize_teams
from platform_api.users import YamlUserDirectory

SERVICE_TOKEN = "svc-SUPERSECRET-99001122334455"
SVC = {"x-aig-service-token": SERVICE_TOKEN}
ADMIN = dev_auth("admin@example.com")
JANE = dev_auth("jane@example.com")
BOB = dev_auth("bob@example.com")
WS = {"repo_url": "https://github.example.com/aig/claims-triage", "work_item": "CLAIMS-1234",
      "title": "Fix triage rounding", "description": "Totals are off by a cent", "job_profile": "claims"}


def build(secrets=None, **kw):
    return create_app(make_settings(**kw),
                      secrets=secrets or configured_secrets(PLATFORM_SERVICE_TOKEN=SERVICE_TOKEN),
                      users=YamlUserDirectory(USERS, "standard"), agent_hooks=[])


@pytest.fixture
def c():
    with TestClient(build()) as client:
        yield client


# --- workspaces -----------------------------------------------------------------------------------


def test_workspace_request_visibility_and_validation(c):
    r = c.post("/api/v1/workspaces", headers=JANE, json=WS)
    assert r.status_code == 201
    w = r.json()
    assert w["status"] == "queued" and w["requested_by"] == "jane@example.com" and w["team"] == "underwriting-ai"
    assert set(w) >= {"id", "repo_url", "work_item", "title", "description", "job_profile", "status", "requested_by",
                      "team", "pr_url", "log_url", "error", "created_at", "updated_at"}
    c.post("/api/v1/workspaces", headers=BOB, json={**WS, "job_profile": None, "repo_url": "git@github.example.com:aig/x.git"})
    assert [x["requested_by"] for x in c.get("/api/v1/workspaces", headers=JANE).json()["items"]] == ["jane@example.com"]
    assert c.get("/api/v1/workspaces", headers=ADMIN).json()["total"] == 2
    assert c.get("/api/v1/workspaces?status=queued", headers=SVC).json()["total"] == 2
    assert c.get(f"/api/v1/workspaces/{w['id']}", headers=BOB).json()["error"]["code"] == "workspace_not_found"
    assert c.get(f"/api/v1/workspaces/{w['id']}", headers=ADMIN).status_code == 200
    assert c.post("/api/v1/workspaces", headers=JANE, json={**WS, "job_profile": "hr"}).json()["error"]["code"] == "invalid_job_profile"
    assert c.post("/api/v1/workspaces", headers=JANE, json={**WS, "repo_url": "file:///etc"}).status_code == 400
    assert c.post("/api/v1/workspaces", headers=JANE, json={"title": "x"}).status_code == 400
    assert c.post("/api/v1/workspaces", headers=SVC, json=WS).status_code == 401  # users only


def test_orchestrator_status_updates_and_cancel(c):
    wid = c.post("/api/v1/workspaces", headers=JANE, json=WS).json()["id"]
    patch = lambda body, who=SVC: c.patch(f"/api/v1/workspaces/{wid}/status", headers=who, json=body)  # noqa: E731
    assert patch({"status": "provisioning"}, JANE).status_code == 401
    assert patch({"status": "provisioning"}, ADMIN).status_code == 401
    assert patch({"status": "exploded"}).status_code == 400
    assert patch({"status": "running", "log_url": "https://logs.example.com/w/1"}).json()["log_url"] == "https://logs.example.com/w/1"
    assert patch({"status": "pr_opened", "pr_url": "javascript:alert(1)"}).status_code == 400
    w = patch({"status": "pr_opened", "pr_url": "https://github.example.com/aig/claims-triage/pull/7"}).json()
    assert w["status"] == "pr_opened" and w["pr_url"].endswith("/pull/7")
    assert c.post(f"/api/v1/workspaces/{wid}/cancel", headers=BOB).status_code == 404
    assert c.post(f"/api/v1/workspaces/{wid}/cancel", headers=JANE).json()["status"] == "cancelled"
    assert c.post(f"/api/v1/workspaces/{wid}/cancel", headers=JANE).json()["error"]["code"] == "invalid_transition"
    assert patch({"status": "running"}).json()["error"]["code"] == "invalid_transition"
    actions = [a["action"] for a in c.get(f"/api/v1/audit?entity_id={wid}", headers=ADMIN).json()["items"]]
    assert actions == ["workspace.cancel", "workspace.status", "workspace.status", "workspace.request"]


def test_workspace_failure_records_error(c):
    wid = c.post("/api/v1/workspaces", headers=JANE, json=WS).json()["id"]
    w = c.patch(f"/api/v1/workspaces/{wid}/status", headers=SVC, json={"status": "failed", "error": "unit tests failed"}).json()
    assert w["status"] == "failed" and w["error"] == "unit tests failed"
    assert c.post(f"/api/v1/workspaces/{wid}/cancel", headers=ADMIN).status_code == 409


def test_orchestrator_claim_is_atomic_and_service_only(c):
    wid = c.post("/api/v1/workspaces", headers=JANE, json=WS).json()["id"]
    claim = lambda who=SVC, **kw: c.post(f"/api/v1/workspaces/{wid}/claim", headers=who, **kw)  # noqa: E731
    assert claim(JANE).status_code == 401  # users never claim
    assert claim(ADMIN).status_code == 401
    assert claim({"x-aig-service-token": "wrong"}).json()["error"]["code"] == "service_unauthenticated"
    w = claim(json={"worker": "orch-1"})
    assert w.status_code == 200 and w.json()["status"] == "provisioning"
    second = claim(json={"worker": "orch-2"})
    assert second.status_code == 409 and second.json()["error"]["code"] == "invalid_transition"
    assert c.post("/api/v1/workspaces/nope/claim", headers=SVC).json()["error"]["code"] == "workspace_not_found"
    assert c.get("/api/v1/workspaces?status=queued", headers=SVC).json()["total"] == 0
    audit = c.get(f"/api/v1/audit?entity_id={wid}", headers=ADMIN).json()["items"]
    assert audit[0]["action"] == "workspace.claim" and audit[0]["details"]["worker"] == "orch-1"
    # A cancelled request can no longer be claimed.
    wid2 = c.post("/api/v1/workspaces", headers=JANE, json=WS).json()["id"]
    c.post(f"/api/v1/workspaces/{wid2}/cancel", headers=JANE)
    assert c.post(f"/api/v1/workspaces/{wid2}/claim", headers=SVC).status_code == 409
    # No body is fine (worker defaults to "orchestrator").
    wid3 = c.post("/api/v1/workspaces", headers=JANE, json=WS).json()["id"]
    assert c.post(f"/api/v1/workspaces/{wid3}/claim", headers=SVC).json()["status"] == "provisioning"


def test_claim_race_between_two_workers_has_one_winner(tmp_path):
    """Two apps sharing one file database (two orchestrator replicas, real connections and
    transactions): exactly one claim wins. Postgres decides the same race with the row lock of
    the conditional UPDATE."""
    import threading

    import platform_api.main as main_module
    from platform_api.db import Base, Database, make_engine

    engine = make_engine(f"sqlite:///{tmp_path / 'race.db'}")
    Base.metadata.create_all(engine)
    db = Database(engine)
    original = main_module.open_database
    main_module.open_database = lambda settings: db
    try:
        with TestClient(build()) as c1, TestClient(build()) as c2:
            wid = c1.post("/api/v1/workspaces", headers=JANE, json=WS).json()["id"]
            codes: list[int] = []
            def go(client):
                codes.append(client.post(f"/api/v1/workspaces/{wid}/claim", headers=SVC).status_code)
            threads = [threading.Thread(target=go, args=(cl,)) for cl in (c1, c2, c1, c2)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            assert sorted(codes) == [200, 409, 409, 409]
    finally:
        main_module.open_database = original


# --- evals ----------------------------------------------------------------------------------------

RUN = {"agent_id": "uw-quote-assistant", "dataset": "uw-golden-v3", "experiment_id": "exp-123",
       "scores": {"accuracy": 0.9, "faithfulness": 0.97}, "baseline_scores": {"accuracy": 0.88, "faithfulness": 0.96},
       "passed": True, "fiddler_url": "https://fiddler.example.com/exp/123", "git_sha": "a1b2c3d", "pr": "aig/uw#42"}


def test_evals_post_service_only_and_list(c):
    assert c.post("/api/v1/evals", headers=ADMIN, json=RUN).status_code == 401
    r = c.post("/api/v1/evals", headers=SVC, json=RUN)
    assert r.status_code == 201
    run = r.json()
    assert run["id"] and run["created_at"] and run["scores"] == RUN["scores"] and run["passed"] is True
    c.post("/api/v1/evals", headers=SVC, json={**RUN, "agent_id": "claims-triage.v2", "passed": False})
    assert c.post("/api/v1/evals", headers=SVC, json={**RUN, "agent_id": "bad id"}).json()["error"]["code"] == "invalid_agent_id"
    assert c.post("/api/v1/evals", headers=SVC, json={**RUN, "scores": {"accuracy": "great"}}).status_code == 400
    all_runs = c.get("/api/v1/evals", headers=JANE).json()
    assert all_runs["total"] == 2 and all_runs["items"][0]["agent_id"] == "claims-triage.v2"
    mine = c.get("/api/v1/evals?agent_id=uw-quote-assistant&limit=5", headers=JANE).json()
    assert mine["total"] == 1 and mine["items"][0]["experiment_id"] == "exp-123"
    assert c.get("/api/v1/evals?limit=1", headers=SVC).json() | {"items": []} == {"items": [], "total": 2}


# --- usage by team --------------------------------------------------------------------------------

TEAM_URL = r"http://localhost:8787/v1/analytics/groups/metadata/team.*"


def test_by_team_needs_admin_key_and_never_returns_sample_data():
    app = build(secrets=configured_secrets(PORTKEY_ADMIN_API_KEY=None))
    with TestClient(app) as client:
        r = client.get("/api/v1/usage/by-team?days=7", headers=JANE)
    assert r.status_code == 501 and r.json()["error"]["code"] == "usage_not_configured"


def test_by_team_from_portkey_analytics():
    rows = [
        {"metadata_value": "claims-ai", "requests": 10, "total_tokens": 5000, "cost": 250, "users": 3},
        {"metadata_value": "underwriting-ai", "requests": 4, "prompt_tokens": 900, "completion_tokens": 100, "cost": 50, "unique_users": 2},
        {"metadata_value": "claims-ai", "requests": 1, "total_tokens": 100, "cost": 5, "users": 1},
    ]
    with respx.mock() as router, TestClient(build()) as client:
        route = router.get(url__regex=TEAM_URL).mock(return_value=httpx.Response(200, json={"data": rows, "total": 3}))
        r = client.get("/api/v1/usage/by-team?days=90", headers=JANE)
        assert client.get("/api/v1/usage/by-team?days=14", headers=JANE).status_code == 400
        assert client.get("/api/v1/usage/by-team").status_code == 401
    assert r.status_code == 200
    body = r.json()
    assert body["items"] == [
        {"team": "claims-ai", "users": 4, "requests": 11, "tokens": 5100, "cost_usd": 2.55},
        {"team": "underwriting-ai", "users": 2, "requests": 4, "tokens": 1000, "cost_usd": 0.5},
    ]
    assert body["total"] == 2 and body["window"]["days"] == 90 and body["source"] == "portkey_analytics"
    assert route.calls[0].request.headers["x-portkey-api-key"] == ADMIN_KEY
    assert_no_secrets(r.text)


def test_by_team_upstream_error():
    with respx.mock() as router, TestClient(build()) as client:
        router.get(url__regex=TEAM_URL).mock(return_value=httpx.Response(500))
        r = client.get("/api/v1/usage/by-team?days=30", headers=JANE)
    assert r.status_code == 502 and r.json()["error"]["code"] == "usage_upstream_error"


def test_summarize_teams_defaults():
    assert summarize_teams([{"requests": 1}], "usd") == [{"team": "unassigned", "users": 0, "requests": 1, "tokens": 0, "cost_usd": 0.0}]


# --- routing --------------------------------------------------------------------------------------


def test_routing_not_available(c, tmp_path):
    r = c.get("/api/v1/routing", headers=JANE)
    assert r.status_code == 404 and r.json()["error"]["code"] == "routing_not_available"
    with TestClient(build(routing_config_file=tmp_path / "missing.json")) as client:
        assert client.get("/api/v1/routing", headers=JANE).json()["error"]["code"] == "routing_not_available"
    bad = tmp_path / "bad.json"
    bad.write_text("{not json")
    with TestClient(build(routing_config_file=bad)) as client:
        assert client.get("/api/v1/routing", headers=JANE).status_code == 404


def test_routing_reads_aigw_render_output(tmp_path):
    config = {"strategy": {"mode": "conditional", "conditions": [{"query": {"metadata.user_tier": {"$eq": "premium"}}, "then": "opus"}],
                           "default": "openai-lb"}, "targets": [{"name": "opus", "override_params": {"model": "claude-opus"}}],
              "leak": PORTKEY_KEY}
    rendered = {"env": "dev", "objects": {"configs": [
        {"slug": "other", "workspace_id": "aig-claims", "config": {}},
        {"slug": "pc-aig-router", "workspace_id": "aig-claims", "config": config},
    ]}}
    f = tmp_path / "routing.json"
    f.write_text(json.dumps(rendered))
    with TestClient(build(routing_config_file=f)) as client:
        assert client.get("/api/v1/routing").status_code == 401
        r = client.get("/api/v1/routing", headers=JANE)
    assert r.status_code == 200
    body = r.json()
    assert body["env"] == "dev" and body["config_id"] == "pc-aig-router"
    assert body["config"]["strategy"]["mode"] == "conditional"
    assert body["config"]["leak"] == "***redacted***"
    assert_no_secrets(r.text)
    bare = tmp_path / "bare.json"
    bare.write_text(json.dumps({"strategy": {"mode": "single"}}))
    with TestClient(build(routing_config_file=bare)) as client:
        assert client.get("/api/v1/routing", headers=JANE).json() == {"env": "local", "config_id": "pc-aig-router", "config": {"strategy": {"mode": "single"}}}
