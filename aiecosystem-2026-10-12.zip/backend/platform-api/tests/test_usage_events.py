"""IDE usage events -> telemetry bridge (POST /ingest/ide-usage): contract-valid, fire-and-forget,
token counts only, never blocks or fails a chat."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import httpx
import pytest
import respx
from conftest import PROJECT_ROOT, USERS, configured_secrets, dev_auth, make_settings
from fastapi.testclient import TestClient
from jsonschema import Draft202012Validator, FormatChecker
from platform_api.main import create_app
from platform_api.usage_events import build_ide_usage_event, cache_status
from platform_api.users import YamlUserDirectory
from referencing import Registry, Resource

CONTRACTS = Path(os.environ.get("AIG_CONTRACTS_DIR") or PROJECT_ROOT.parent / "contracts")
SCHEMAS = {p.name: json.loads(p.read_text()) for p in CONTRACTS.glob("*.schema.json")}
REGISTRY = Registry().with_resources((s["$id"], Resource.from_contents(s)) for s in SCHEMAS.values())
EVENT_SCHEMA = Draft202012Validator(SCHEMAS["ide-usage-event.schema.json"], registry=REGISTRY, format_checker=FormatChecker())

GATEWAY = "http://localhost:8787/v1/chat/completions"
BRIDGE = "http://bridge.test"
INGEST = f"{BRIDGE}/ingest/ide-usage"
BRIDGE_TOKEN = "bridge-SUPERSECRET-0099887766"
PROMPT = "PROMPT-TEXT-must-never-leave-the-proxy"
USAGE = {"prompt_tokens": 12, "completion_tokens": 30, "total_tokens": 42}


def build(token=BRIDGE_TOKEN, url=BRIDGE):
    secrets = configured_secrets(TELEMETRY_BRIDGE_TOKEN=token) if token else configured_secrets()
    return create_app(make_settings(telemetry_bridge_url=url), secrets=secrets,
                      users=YamlUserDirectory(USERS, "standard"), agent_hooks=[])


def wait_for(route, n=1, timeout=3.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline and route.call_count < n:
        time.sleep(0.02)
    return route.call_count >= n


def sse(*texts, usage=None, model="claude-sonnet-x") -> bytes:
    events = [{"id": "c1", "model": model, "choices": [{"index": 0, "delta": {"content": t}}]} for t in texts]
    if usage:
        events.append({"id": "c1", "model": model, "choices": [], "usage": usage})
    return ("".join(f"data: {json.dumps(e)}\n\n" for e in events) + "data: [DONE]\n\n").encode()


def assert_event(event: dict, *, source="vscode", agent="ide.vscode") -> None:
    errors = sorted(EVENT_SCHEMA.iter_errors(event), key=str)
    assert not errors, [e.message for e in errors]
    assert event["source"] == source and event["agent_id"] == agent
    assert event["prompt_tokens"] == 12 and event["completion_tokens"] == 30 and event["total_tokens"] == 42
    assert PROMPT not in json.dumps(event)


def test_builder_output_matches_the_contract():
    meta = {"user_tier": "premium", "job_profile": "claims", "agent_id": "ide.vscode", "team": "claims-ai",
            "env": "local", "host": "vscode", "user": "jane@example.com", "_user": "jane@example.com"}
    event = build_ide_usage_event(metadata=meta, usage=USAGE, model="gpt-4o", trace_id="3f2b8c1e-1111-4222-8333-444455556666",
                                  latency_ms=12.34, cache="hit")
    assert_event(event)
    assert event["cache"] == "hit" and event["trace_id"].startswith("3f2b") and event["model"] == "gpt-4o"
    # Values that do not fit are dropped / defaulted, never sent invalid.
    odd = build_ide_usage_event(metadata={**meta, "user": "not an email", "job_profile": "hr"}, usage=USAGE,
                                model="bad model name!", trace_id="short", latency_ms=-1, cache="weird")
    assert_event(odd)
    assert odd["model"] == "auto" and "user" not in odd and "job_profile" not in odd and "trace_id" not in odd
    assert build_ide_usage_event(metadata={**meta, "host": "laptop"}, usage=USAGE, model=None, trace_id=None) is None
    assert build_ide_usage_event(metadata=meta, usage={"prompt_tokens": 1}, model=None, trace_id=None) is None
    assert cache_status("SEMANTIC HIT") == "semantic_hit" and cache_status("MISS") == "miss" and cache_status(None) is None


def test_http_completion_forwards_one_event():
    with respx.mock() as router, TestClient(build()) as client:
        router.post(GATEWAY).mock(return_value=httpx.Response(
            200, json={"id": "x", "model": "claude-sonnet-x", "choices": [], "usage": USAGE},
            headers={"x-portkey-cache-status": "MISS"}))
        bridge = router.post(INGEST).mock(return_value=httpx.Response(202, json={"counts": {"accepted": 1}}))
        r = client.post("/api/v1/llm/chat/completions", headers=dev_auth(),
                        json={"model": "x", "messages": [{"role": "user", "content": PROMPT}]})
        assert r.status_code == 200
        assert wait_for(bridge)
    req = bridge.calls[0].request
    assert req.headers["authorization"] == f"Bearer {BRIDGE_TOKEN}"
    event = json.loads(req.content)
    assert_event(event)
    assert event["model"] == "claude-sonnet-x" and event["cache"] == "miss" and event["user"] == "jane@example.com"
    assert event["trace_id"] == r.headers["x-aig-trace-id"] and event["team"] == "underwriting-ai"


def test_http_stream_forwards_usage_after_the_stream():
    with respx.mock() as router, TestClient(build()) as client:
        router.post(GATEWAY).mock(return_value=httpx.Response(
            200, headers={"content-type": "text/event-stream"}, content=sse("Hel", "lo", usage=USAGE)))
        bridge = router.post(INGEST).mock(return_value=httpx.Response(202))
        r = client.post("/api/v1/llm/chat/completions", headers=dev_auth(),
                        json={"model": "x", "stream": True, "messages": [{"role": "user", "content": PROMPT}]})
        assert r.status_code == 200 and "Hel" in r.text
        assert wait_for(bridge)
    assert_event(json.loads(bridge.calls[0].request.content))


def test_browser_requests_are_tagged_web_portal():
    with respx.mock() as router, TestClient(build()) as client:
        gw = router.post(GATEWAY).mock(return_value=httpx.Response(200, json={"choices": [], "usage": USAGE}))
        bridge = router.post(INGEST).mock(return_value=httpx.Response(202))
        client.post("/api/v1/llm/chat/completions", headers={**dev_auth(), "Origin": "http://localhost:3000"},
                    json={"model": "x", "messages": []})
        assert wait_for(bridge)
    meta = json.loads(gw.calls[0].request.headers["x-portkey-metadata"])
    assert meta["host"] == "web" and meta["agent_id"] == "web.portal"
    assert_event(json.loads(bridge.calls[0].request.content), source="web", agent="web.portal")


@pytest.mark.parametrize("failure", ["status", "timeout", "connect"])
def test_bridge_failures_never_affect_the_chat(failure):
    with respx.mock() as router, TestClient(build()) as client:
        router.post(GATEWAY).mock(return_value=httpx.Response(200, json={"choices": [], "usage": USAGE}))
        bridge = router.post(INGEST)
        if failure == "status":
            bridge.mock(return_value=httpx.Response(503))
        elif failure == "timeout":
            bridge.mock(side_effect=httpx.ReadTimeout("slow"))
        else:
            bridge.mock(side_effect=httpx.ConnectError("down"))
        r = client.post("/api/v1/llm/chat/completions", headers=dev_auth(), json={"model": "x", "messages": []})
        assert r.status_code == 200
        assert wait_for(bridge)


@pytest.mark.parametrize("token,url", [(None, BRIDGE), (BRIDGE_TOKEN, None)])
def test_not_forwarded_without_url_or_token(token, url):
    with respx.mock(assert_all_called=False) as router, TestClient(build(token=token, url=url)) as client:
        router.post(GATEWAY).mock(return_value=httpx.Response(200, json={"choices": [], "usage": USAGE}))
        bridge = router.post(INGEST).mock(return_value=httpx.Response(202))
        assert client.post("/api/v1/llm/chat/completions", headers=dev_auth(), json={"model": "x", "messages": []}).status_code == 200
        time.sleep(0.1)
    assert not bridge.called


def test_no_event_without_usage_or_on_upstream_error():
    with respx.mock(assert_all_called=False) as router, TestClient(build()) as client:
        gw = router.post(GATEWAY)
        bridge = router.post(INGEST).mock(return_value=httpx.Response(202))
        gw.mock(return_value=httpx.Response(200, json={"choices": []}))
        client.post("/api/v1/llm/chat/completions", headers=dev_auth(), json={"model": "x", "messages": []})
        gw.mock(return_value=httpx.Response(429, json={"error": {"message": "rate"}, "usage": USAGE}))
        client.post("/api/v1/llm/chat/completions", headers=dev_auth(), json={"model": "x", "messages": []})
        time.sleep(0.1)
    assert not bridge.called


def test_websocket_chat_done_forwards_one_event():
    with respx.mock() as router, TestClient(build()) as client:
        router.post(GATEWAY).mock(return_value=httpx.Response(
            200, headers={"content-type": "text/event-stream"}, content=sse("Hi", usage=USAGE)))
        bridge = router.post(INGEST).mock(return_value=httpx.Response(202))
        with client.websocket_connect("/api/v1/ws", headers=dev_auth()) as ws:
            assert json.loads(ws.receive_text())["type"] == "ready"
            ws.send_text(json.dumps({"type": "chat", "id": "c1", "messages": [{"role": "user", "content": PROMPT}]}))
            frames = []
            while True:
                frames.append(json.loads(ws.receive_text()))
                if frames[-1]["type"] in ("chat.done", "chat.error"):
                    break
            assert frames[-1]["type"] == "chat.done" and frames[-1]["usage"] == USAGE
            assert wait_for(bridge)
    event = json.loads(bridge.calls[0].request.content)
    assert_event(event)
    assert event["trace_id"] == frames[-1]["trace_id"] and event["model"] == "claude-sonnet-x"
