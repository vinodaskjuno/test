"""Browser clients: WebSocket bearer token via Sec-WebSocket-Protocol, and local web sign-in redirects."""

from __future__ import annotations

import logging
from urllib.parse import parse_qs, urlsplit

import pytest
from conftest import dev_auth, make_app
from fastapi.testclient import TestClient
from platform_api.routes.local_auth import valid_redirect_uri
from starlette.websockets import WebSocketDisconnect

WS = "/api/v1/ws"
WEB = "http://localhost:3000"  # local.yaml web_allowed_origins / cors_allowed_origins
STATE = "abcdefghijklmnop1234"


@pytest.fixture
def client():
    with TestClient(make_app()) as c:
        yield c


def _close_code(client, **kw) -> tuple[int, str | None]:
    with client.websocket_connect(WS, **kw) as ws:
        with pytest.raises(WebSocketDisconnect) as exc:
            ws.receive_text()
        return exc.value.code, ws.accepted_subprotocol


def test_header_auth_still_works(client):
    with client.websocket_connect(WS, headers=dev_auth()) as ws:
        assert ws.receive_json()["type"] == "ready"
        assert ws.accepted_subprotocol is None


def test_subprotocol_auth_selects_only_aig_bearer(client, caplog):
    caplog.set_level(logging.DEBUG)
    token = "dev:jane@example.com"
    with client.websocket_connect(WS, subprotocols=["aig.bearer", token], headers={"Origin": WEB}) as ws:
        ready = ws.receive_json()
        assert ready["type"] == "ready" and ready["user"]["email"] == "jane@example.com"
        assert ws.accepted_subprotocol == "aig.bearer"
        assert token not in (ws.accepted_subprotocol or "")
    assert token not in caplog.text


@pytest.mark.parametrize("protocols", [["aig.bearer"], ["aig.bearer", "dev:not-an-email"], ["aig.bearer", "garbage.jwt.x"],
                                       ["other", "dev:jane@example.com"]])
def test_bad_or_missing_subprotocol_token_closes_4401(client, protocols):
    code, selected = _close_code(client, subprotocols=protocols, headers={"Origin": WEB})
    assert code == 4401
    assert selected in (None, "aig.bearer")  # the token entry is never selected


def test_disallowed_origin_closes_4403_even_with_a_valid_token(client):
    code, _ = _close_code(client, subprotocols=["aig.bearer", "dev:jane@example.com"], headers={"Origin": "https://evil.example.com"})
    assert code == 4403


def test_web_origin_from_web_allowed_origins_only():
    app = make_app()
    app.state.env_config.cors_allowed_origins = []
    app.state.env_config.web_allowed_origins = ["https://portal.example.com"]
    with TestClient(app) as c:
        with c.websocket_connect(WS, subprotocols=["aig.bearer", "dev:jane@example.com"], headers={"Origin": "https://portal.example.com"}) as ws:
            assert ws.receive_json()["type"] == "ready"


# --- local web sign-in -----------------------------------------------------------------------------


def test_valid_redirect_uri_for_web_origins():
    origins = ["http://localhost:3000", "https://portal.example.com/"]
    assert valid_redirect_uri("http://localhost:3000/auth/callback", origins)
    assert valid_redirect_uri("https://portal.example.com/auth/callback?x=1", origins)
    assert valid_redirect_uri("vscode://aig.aig-ai-ecosystem/auth-callback", origins)  # vscode rules unchanged
    for bad in (
        "http://localhost:3000/auth/callback",  # without configured origins
    ):
        assert not valid_redirect_uri(bad)
    for bad in (
        "http://localhost:3001/auth/callback",
        "https://localhost:3000/auth/callback",  # scheme is part of the origin
        "http://localhost:3000/other",
        "http://localhost:3000/auth/callback#frag",
        "http://evil@localhost:3000/auth/callback",
        "https://portal.example.com.evil.com/auth/callback",
        "javascript://localhost:3000/auth/callback",
        "vscode://evil.ext/auth-callback",
    ):
        assert not valid_redirect_uri(bad, origins), bad


def test_web_signin_flow_redirects_back_to_the_portal(client):
    r = client.get(f"/auth/local/signin?redirect_uri={WEB}/auth/callback&state={STATE}")
    assert r.status_code == 200 and "AIG web portal" in r.text
    r = client.post("/auth/local/signin", data={"redirect_uri": f"{WEB}/auth/callback", "state": STATE, "email": "jane@example.com"})
    assert r.status_code == 200 and "Open the portal" in r.text
    target = r.text.split('url=', 1)[1].split('"', 1)[0].replace("&amp;", "&")
    parts = urlsplit(target)
    assert f"{parts.scheme}://{parts.netloc}{parts.path}" == f"{WEB}/auth/callback"
    assert parse_qs(parts.query) == {"email": ["jane@example.com"], "state": [STATE]}


def test_web_signin_denies_unlisted_origins(client):
    r = client.get(f"/auth/local/signin?redirect_uri=https://evil.example.com/auth/callback&state={STATE}")
    assert r.status_code == 400 and r.json()["error"]["code"] == "invalid_redirect_uri"
    r = client.post("/auth/local/signin", data={"redirect_uri": "http://localhost:3999/auth/callback", "state": STATE, "email": "a@example.com"})
    assert r.status_code == 400


def test_web_signin_is_still_local_dev_only():
    with TestClient(make_app(auth_mode="oidc")) as c:
        assert c.get(f"/auth/local/signin?redirect_uri={WEB}/auth/callback&state={STATE}").status_code == 404


def test_subprotocol_token_base64url_encoded_dev_token():
    """Browsers cannot send "dev:<email>" as a subprotocol (":" "@"); the encoded form works."""
    import base64

    from platform_api.routes.ws import _subprotocol_token

    enc = "b64u." + base64.urlsafe_b64encode(b"dev:jane@example.com").decode().rstrip("=")
    assert _subprotocol_token(["aig.bearer", enc]) == "dev:jane@example.com"
    assert _subprotocol_token(["aig.bearer", "raw.jwt.token"]) == "raw.jwt.token"
    assert _subprotocol_token(["aig.bearer", "b64u.***"]) is None
    assert _subprotocol_token(["aig.bearer", "b64u."]) is None
    assert _subprotocol_token(["other", enc]) is None
