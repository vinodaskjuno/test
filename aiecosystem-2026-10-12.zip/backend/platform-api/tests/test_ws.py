from __future__ import annotations

import asyncio
import json
import logging

import httpx
import pytest
import respx
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

from platform_api.config import load_env_config
from platform_api.routes.ws import MAX_CONCURRENT_CHATS

from conftest import (
    ADMIN_KEY,
    PORTKEY_KEY,
    assert_no_secrets,
    configured_secrets,
    dev_auth,
    make_app,
    make_jwt,
    make_settings,
)

GATEWAY = "http://localhost:8787/v1/chat/completions"
USERS_URL = r"http://localhost:8787/v1/analytics/groups/users.*"
MODELS_URL = r"http://localhost:8787/v1/analytics/groups/model\?.*"
GRAPH_URL = r"http://localhost:8787/v1/analytics/graphs/.*"
WS = "/api/v1/ws"
MSGS = [{"role": "user", "content": "hi"}]


@pytest.fixture
def gateway():
    with respx.mock(assert_all_called=False) as router:
        yield router


def sse(*events, usage=None, model=None) -> bytes:
    out = []
    for text in events:
        out.append({"id": "c1", "object": "chat.completion.chunk", "choices": [{"index": 0, "delta": {"content": text}}],
                    **({"model": model} if model else {})})
    if usage:
        out.append({"id": "c1", "object": "chat.completion.chunk", "choices": [], "usage": usage})
    body = "".join(f"data: {json.dumps(e)}\n\n" for e in out) + "data: [DONE]\n\n"
    return body.encode()


def hanging_stream(first: bytes | None = None):
    """Upstream that sends an optional first chunk then never finishes (until cancelled)."""

    async def gen():
        if first:
            yield first
        await asyncio.sleep(3600)
        yield b""

    return lambda request: httpx.Response(200, headers={"content-type": "text/event-stream"}, content=gen())


class Recorder:
    """Wraps a test websocket and records every received frame for leak checks."""

    def __init__(self, ws):
        self.ws = ws
        self.frames: list[str] = []

    def send(self, obj):
        self.ws.send_text(json.dumps(obj))

    def recv(self) -> dict:
        text = self.ws.receive_text()
        self.frames.append(text)
        return json.loads(text)

    def recv_until(self, pred, limit=50) -> list[dict]:
        got = []
        for _ in range(limit):
            m = self.recv()
            got.append(m)
            if pred(m):
                return got
        raise AssertionError(f"condition not met: {got}")

    def assert_clean(self):
        assert_no_secrets("\n".join(self.frames))


def connect(client, headers=None):
    return client.websocket_connect(WS, headers=dev_auth() if headers is None else headers)


def ready(client, headers=None):
    """Context manager-ish helper: returns (cm, Recorder) after consuming 'ready'."""
    cm = connect(client, headers)
    ws = cm.__enter__()
    rec = Recorder(ws)
    first = rec.recv()
    assert first["type"] == "ready"
    return cm, rec, first


def expect_close(client, headers, code):
    with connect(client, headers) as ws:
        with pytest.raises(WebSocketDisconnect) as exc:
            ws.receive_text()
    assert exc.value.code == code
    return exc.value


# ---------- auth / origin ----------

def test_ready_payload(client):
    with connect(client) as ws:
        msg = Recorder(ws).recv()
    assert msg["type"] == "ready"
    assert msg["user"] == {"email": "jane@example.com", "name": "Jane Doe"}
    assert msg["team"] == "underwriting-ai"
    assert msg["env"] == "local"
    assert msg["user_tier"] == "premium"
    assert msg["allowed_job_profiles"] == ["underwriting", "claims", "operations", "general"]
    assert "T" in msg["server_time"]
    assert_no_secrets(json.dumps(msg))


def test_missing_auth_closes_4401(client):
    exc = expect_close(client, {}, 4401)
    assert exc.reason == "unauthenticated"


@pytest.mark.parametrize("header", ["Bearer ", "Basic Zm9vOmJhcg==", "Bearer dev:not-an-email", "Bearer garbage.jwt.token"])
def test_bad_auth_closes_4401(client, header):
    expect_close(client, {"Authorization": header}, 4401)


def test_dev_token_rejected_outside_local(rsa_key):
    app = make_app(env="dev", auth_mode="oidc", key_resolver=lambda _t: rsa_key.public_key())
    with TestClient(app) as c:
        expect_close(c, dev_auth(), 4401)


def test_jwt_accepted_outside_local(rsa_key):
    cfg = load_env_config(make_settings("dev", "oidc"))
    token = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience)
    app = make_app(env="dev", auth_mode="oidc", key_resolver=lambda _t: rsa_key.public_key())
    with TestClient(app) as c, connect(c, {"Authorization": f"Bearer {token}"}) as ws:
        msg = Recorder(ws).recv()
    assert msg["type"] == "ready" and msg["user"]["email"] == "jane@example.com" and msg["env"] == "dev"


def test_dev_mode_in_local_without_dev_auth_mode_rejects_dev_token(rsa_key):
    app = make_app(env="local", auth_mode="oidc", key_resolver=lambda _t: rsa_key.public_key())
    with TestClient(app) as c:
        expect_close(c, dev_auth(), 4401)


def test_origin_checks(client):
    exc = expect_close(client, {**dev_auth(), "Origin": "https://evil.example.com"}, 4403)
    assert exc.reason == "forbidden_origin"
    with connect(client, {**dev_auth(), "Origin": "http://localhost:3000"}) as ws:
        assert Recorder(ws).recv()["type"] == "ready"


# ---------- framing ----------

def test_ping_pong_and_bad_frames_do_not_close(client):
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "ping"})
        assert rec.recv() == {"type": "pong"}
        rec.ws.send_text("{not json")
        assert rec.recv()["code"] == "bad_request"
        rec.send({"type": "nope"})
        m = rec.recv()
        assert m["type"] == "error" and m["code"] == "bad_request"
        rec.send([1, 2])
        assert rec.recv()["code"] == "bad_request"
        rec.ws.send_text(json.dumps({"type": "ping", "pad": "x" * (64 * 1024)}))
        m = rec.recv()
        assert m["type"] == "error" and m["code"] == "bad_request" and "exceeds" in m["message"]
        rec.ws.send_bytes(b"\x00\x01")
        assert rec.recv()["code"] == "bad_request"
        rec.send({"type": "pong"})  # ignored
        rec.send({"type": "ping"})
        assert rec.recv() == {"type": "pong"}
    finally:
        cm.__exit__(None, None, None)


def test_server_keepalive_ping(app):
    with TestClient(app) as c:
        app.state.settings.ws_ping_interval_seconds = 0.05
        cm, rec, _ = ready(c)
        try:
            assert rec.recv() == {"type": "ping"}
        finally:
            cm.__exit__(None, None, None)


# ---------- chat ----------

def test_chat_streams_deltas_and_done_with_usage(client, gateway, caplog):
    caplog.set_level(logging.DEBUG)
    usage = {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7}
    route = gateway.post(GATEWAY).mock(
        return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, content=sse("hel", "lo", usage=usage))
    )
    cm, rec, _ = ready(client, {**dev_auth("bob@example.com"), "x-portkey-api-key": "client-key", "x-portkey-config": "pc-evil"})
    try:
        rec.send(
            {
                "type": "chat", "id": "c-1", "messages": MSGS, "job_profile": "claims", "agent_id": "triage.v2",
                "model": "gpt-4o", "temperature": 0.2, "max_tokens": 50,
                # client attempts to smuggle routing/tier fields: must be ignored
                "user_tier": "premium", "x-portkey-api-key": "client-key", "metadata": {"user_tier": "premium"},
            }
        )
        frames = rec.recv_until(lambda m: m["type"] in ("chat.done", "chat.error"))
    finally:
        cm.__exit__(None, None, None)
    deltas = [f["text"] for f in frames if f["type"] == "chat.delta"]
    assert "".join(deltas) == "hello"
    assert all(f["id"] == "c-1" for f in frames)
    done = frames[-1]
    assert done["type"] == "chat.done" and done["usage"] == usage and len(done["trace_id"]) >= 8
    # Routing inputs (server-side values, never the smuggled ones) are reported with the answer.
    assert done["route"] == {"user_tier": "standard", "cost_mode": "balanced", "job_profile": "claims", "usage_state": "normal"}
    assert "model" not in done  # upstream chunks carried no model

    sent = route.calls.last.request
    assert sent.headers["x-portkey-api-key"] == PORTKEY_KEY
    assert sent.headers["x-portkey-config"] == "pc-aig-router"
    assert sent.headers["x-portkey-trace-id"] == done["trace_id"]
    assert "authorization" not in sent.headers
    assert "client-key" not in str(sent.headers)
    meta = json.loads(sent.headers["x-portkey-metadata"])
    assert meta["user_tier"] == "standard" and meta["team"] == "claims-ai"
    assert meta["job_profile"] == "claims" and meta["agent_id"] == "triage.v2" and meta["_user"] == "bob@example.com"
    body = json.loads(sent.content)
    assert body == {
        "messages": MSGS, "stream": True, "stream_options": {"include_usage": True},
        "model": "gpt-4o", "temperature": 0.2, "max_tokens": 50,
    }
    rec.assert_clean()
    assert_no_secrets(caplog.text)


def test_chat_redacts_secret_split_across_deltas(client, gateway):
    half = len(PORTKEY_KEY) // 2
    gateway.post(GATEWAY).mock(
        return_value=httpx.Response(200, content=sse("key=", PORTKEY_KEY[:half], PORTKEY_KEY[half:], " end"))
    )
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "r", "messages": MSGS})
        frames = rec.recv_until(lambda m: m["type"] == "chat.done")
    finally:
        cm.__exit__(None, None, None)
    text = "".join(f.get("text", "") for f in frames)
    assert text == "key=***redacted*** end"
    rec.assert_clean()


@pytest.mark.parametrize(
    "extra,code",
    [
        ({"job_profile": "hacking"}, "invalid_job_profile"),
        ({"agent_id": "bad id!"}, "invalid_agent_id"),
        ({"messages": []}, "bad_request"),
        ({"messages": [{"role": "wizard", "content": "x"}]}, "bad_request"),
        ({"temperature": "hot"}, "bad_request"),
        ({"max_tokens": 0}, "bad_request"),
    ],
)
def test_chat_validation_errors(client, gateway, extra, code):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, content=sse("x")))
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "v", "messages": MSGS, **extra})
        m = rec.recv()
    finally:
        cm.__exit__(None, None, None)
    assert m["type"] == "chat.error" and m["id"] == "v" and m["code"] == code
    assert not route.called


def test_chat_invalid_id_is_bad_request(client):
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "has space", "messages": MSGS})
        m = rec.recv()
    finally:
        cm.__exit__(None, None, None)
    assert m["type"] == "error" and m["code"] == "bad_request"


@pytest.mark.parametrize(
    "secrets,code",
    [
        (configured_secrets(PORTKEY_API_KEY="__REPLACE_ME_PORTKEY_API_KEY_LOCAL__"), "portkey_key_not_configured"),
        (configured_secrets(PORTKEY_API_KEY=""), "portkey_key_not_configured"),
    ],
)
def test_chat_placeholder_key(gateway, secrets, code):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, content=sse("x")))
    with TestClient(make_app(secrets=secrets)) as c:
        cm, rec, _ = ready(c)
        try:
            rec.send({"type": "chat", "id": "p", "messages": MSGS})
            m = rec.recv()
        finally:
            cm.__exit__(None, None, None)
    assert m["type"] == "chat.error" and m["code"] == code
    assert not route.called


def test_chat_placeholder_gateway(gateway, app):
    with TestClient(app) as c:
        app.state.env_config = app.state.env_config.model_copy(update={"portkey_gateway_url": "https://__GW__/v1"})
        cm, rec, _ = ready(c)
        try:
            rec.send({"type": "chat", "id": "g", "messages": MSGS})
            m = rec.recv()
        finally:
            cm.__exit__(None, None, None)
    assert m["code"] == "portkey_gateway_not_configured"


def test_chat_upstream_http_error(client, gateway):
    gateway.post(GATEWAY).mock(
        return_value=httpx.Response(429, json={"error": {"message": f"rate limited for key {PORTKEY_KEY}"}})
    )
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "e", "messages": MSGS})
        m = rec.recv()
        rec.send({"type": "ping"})  # socket still usable
        assert rec.recv() == {"type": "pong"}
    finally:
        cm.__exit__(None, None, None)
    assert m["type"] == "chat.error" and m["code"] == "upstream_error" and m["status"] == 429
    assert "rate limited" in m["message"] and "***redacted***" in m["message"]
    rec.assert_clean()


@pytest.mark.parametrize(
    "exc,code",
    [
        (httpx.ReadTimeout("t"), "upstream_timeout"),
        (httpx.ConnectError("c"), "upstream_unavailable"),
    ],
)
def test_chat_upstream_transport_errors(client, gateway, exc, code):
    gateway.post(GATEWAY).mock(side_effect=exc)
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "t", "messages": MSGS})
        m = rec.recv()
    finally:
        cm.__exit__(None, None, None)
    assert m["type"] == "chat.error" and m["code"] == code and m["trace_id"]


@pytest.mark.parametrize(
    "exc,code", [(httpx.ReadTimeout("t"), "upstream_timeout"), (httpx.RemoteProtocolError("x"), "upstream_interrupted")]
)
def test_chat_stream_interrupted_midway(client, gateway, exc, code):
    async def gen():
        yield sse("partial")[: -len("data: [DONE]\n\n")]
        raise exc

    gateway.post(GATEWAY).mock(side_effect=lambda r: httpx.Response(200, content=gen()))
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "i", "messages": MSGS})
        frames = rec.recv_until(lambda m: m["type"] in ("chat.done", "chat.error"))
    finally:
        cm.__exit__(None, None, None)
    assert frames[0] == {"type": "chat.delta", "id": "i", "text": "partial"}
    assert frames[-1]["type"] == "chat.error" and frames[-1]["code"] == code


def test_cancel(client, gateway):
    gateway.post(GATEWAY).mock(side_effect=hanging_stream(sse("first")[: -len("data: [DONE]\n\n")]))
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "chat", "id": "k", "messages": MSGS})
        assert rec.recv() == {"type": "chat.delta", "id": "k", "text": "first"}
        rec.send({"type": "cancel", "id": "k"})
        assert rec.recv() == {"type": "chat.error", "id": "k", "code": "cancelled", "message": "cancelled"}
        rec.send({"type": "cancel", "id": "k"})
        assert rec.recv()["code"] == "unknown_id"
        # the id is free again
        gateway.post(GATEWAY).mock(return_value=httpx.Response(200, content=sse("ok")))
        rec.send({"type": "chat", "id": "k", "messages": MSGS})
        frames = rec.recv_until(lambda m: m["type"] == "chat.done")
    finally:
        cm.__exit__(None, None, None)
    assert frames[0]["text"] == "ok"


def test_concurrency_limit_and_duplicate_id(client, gateway):
    gateway.post(GATEWAY).mock(side_effect=hanging_stream())
    cm, rec, _ = ready(client)
    try:
        for i in range(MAX_CONCURRENT_CHATS):
            rec.send({"type": "chat", "id": f"c{i}", "messages": MSGS})
        rec.send({"type": "chat", "id": "c0", "messages": MSGS})
        m = rec.recv()
        assert m["type"] == "chat.error" and m["id"] == "c0" and m["code"] == "duplicate_id"
        rec.send({"type": "chat", "id": "extra", "messages": MSGS})
        m = rec.recv()
        assert m["type"] == "chat.error" and m["id"] == "extra" and m["code"] == "too_many_requests"
        rec.send({"type": "cancel", "id": "c1"})
        assert rec.recv()["code"] == "cancelled"
        rec.send({"type": "chat", "id": "extra", "messages": MSGS})
        rec.send({"type": "ping"})
        assert rec.recv() == {"type": "pong"}  # accepted (no error before pong)
    finally:
        cm.__exit__(None, None, None)  # disconnect must clean up the hanging tasks


def test_abrupt_disconnect_mid_stream_cleans_up(app, gateway):
    gateway.post(GATEWAY).mock(side_effect=hanging_stream(sse("x")[: -len("data: [DONE]\n\n")]))
    with TestClient(app) as c:
        cm, rec, _ = ready(c)
        rec.send({"type": "chat", "id": "a", "messages": MSGS})
        rec.send({"type": "usage.subscribe", "days": 7})
        rec.recv()
        cm.__exit__(None, None, None)
        # server is still healthy afterwards
        assert c.get("/healthz").status_code == 200


# ---------- usage ----------

def test_usage_subscribe_pushes_once_replace_and_unsubscribe(client, gateway):
    """The caller's own usage from Portkey analytics (mocked); exactly one push per subscribe (no periodic refresh)."""
    gateway.get(url__regex=MODELS_URL).mock(
        return_value=httpx.Response(200, json={"data": [{"model": "claude-sonnet", "requests": 2, "total_tokens": 200, "cost": 50}]})
    )
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    expected_keys = set(client.get("/api/v1/usage/dashboard?days=7", headers=dev_auth()).json())
    client.app.state.settings.ws_usage_interval_seconds = 0.05
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "usage.subscribe", "days": 7})
        first = rec.recv()
        rec.send({"type": "ping"})
        assert rec.recv() == {"type": "pong"}  # no second usage push in between
        rec.send({"type": "usage.subscribe", "days": 90})  # replaces (= manual refresh)
        m = rec.recv_until(lambda m: m["type"] == "usage" and m["days"] == 90)[-1]
        rec.send({"type": "usage.unsubscribe"})
        rec.send({"type": "ping"})
        rec.recv_until(lambda m: m["type"] == "pong")
    finally:
        cm.__exit__(None, None, None)
    assert first["type"] == "usage" and first["days"] == 7
    assert first["data"]["source"] == "portkey_analytics" and set(first["data"]) == expected_keys
    assert first["data"]["scope"] == "user" and first["data"]["totals"]["users"] == 1
    assert m["data"]["window"]["days"] == 90
    rec.assert_clean()


def test_no_demo_mode_exists(monkeypatch):
    """Enterprise: there is no sample-data mode; AIG_USAGE_DEMO has no effect."""
    import platform_api.routes.usage as usage
    from platform_api.config import Settings

    monkeypatch.setenv("AIG_USAGE_DEMO", "true")
    assert not hasattr(usage, "demo_dashboard")
    assert "usage_demo" not in Settings.model_fields


def test_usage_subscribe_matches_http_dashboard_and_no_push_after_chat(client, gateway):
    models = gateway.get(url__regex=MODELS_URL).mock(
        return_value=httpx.Response(200, json={"data": [{"model": "claude-sonnet", "requests": 3, "total_tokens": 300, "cost": 100}]})
    )
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    gateway.post(GATEWAY).mock(return_value=httpx.Response(200, content=sse("hi")))
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "usage.subscribe", "days": 30})
        pushed = rec.recv()
        http_body = client.get("/api/v1/usage/dashboard?days=30", headers=dev_auth()).json()
        rec.send({"type": "chat", "id": "u", "messages": MSGS})
        frames = rec.recv_until(lambda m: m["type"] == "chat.done")
        rec.send({"type": "ping"})
        assert rec.recv() == {"type": "pong"}  # no usage push after the chat
    finally:
        cm.__exit__(None, None, None)
    for body in (pushed["data"], http_body):
        body.pop("generated_at", None)
        body.pop("window", None)
    assert pushed["type"] == "usage" and pushed["data"] == http_body
    assert pushed["data"]["user"] == "jane@example.com" and pushed["data"]["totals"]["requests"] == 3
    assert frames[-1]["type"] == "chat.done"
    assert models.calls.last.request.headers["x-portkey-api-key"] == ADMIN_KEY
    rec.assert_clean()


def test_usage_not_configured(gateway):
    with TestClient(make_app(secrets=configured_secrets(PORTKEY_ADMIN_API_KEY="__REPLACE_ME_X__"))) as c:
        cm, rec, _ = ready(c)
        try:
            rec.send({"type": "usage.subscribe", "days": 7})
            m = rec.recv()
        finally:
            cm.__exit__(None, None, None)
    assert m == {"type": "usage.error", "code": "usage_not_configured", "message": m["message"]}


def test_usage_upstream_error_and_bad_days(client, gateway):
    gateway.get(url__regex=MODELS_URL).mock(return_value=httpx.Response(500, text=f"boom {ADMIN_KEY}"))
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "usage.subscribe", "days": 14})
        assert rec.recv()["code"] == "bad_request"
        rec.send({"type": "usage.subscribe", "days": 7})
        m = rec.recv()
    finally:
        cm.__exit__(None, None, None)
    assert m["type"] == "usage.error" and m["code"] == "usage_upstream_error"
    rec.assert_clean()


def test_no_secrets_in_frames_or_logs_end_to_end(client, gateway, caplog):
    caplog.set_level(logging.DEBUG)
    gateway.post(GATEWAY).mock(return_value=httpx.Response(200, content=sse(f"leak {PORTKEY_KEY} {ADMIN_KEY}")))
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    gateway.get(url__regex=MODELS_URL).mock(return_value=httpx.Response(200, json={"data": [{"model": ADMIN_KEY}]}))
    cm, rec, _ = ready(client)
    try:
        rec.send({"type": "usage.subscribe", "days": 30})
        rec.recv()
        rec.send({"type": "chat", "id": "s", "messages": MSGS})
        rec.recv_until(lambda m: m["type"] == "chat.done")
        rec.send({"type": "bogus", "x": PORTKEY_KEY})
        rec.recv()
    finally:
        cm.__exit__(None, None, None)
    rec.assert_clean()
    assert_no_secrets(caplog.text)


def test_text_redactor_holds_only_possible_secret_prefixes():
    from platform_api.routes.ws import _TextRedactor

    r = _TextRedactor([PORTKEY_KEY, ADMIN_KEY])
    assert r.feed("hello ") == "hello "  # nothing held for ordinary text
    assert r.feed("pk-") == ""  # could be the start of a key
    assert r.feed("x!") == "pk-x!"
    out = "".join(r.feed(ch) for ch in PORTKEY_KEY) + r.flush()
    assert out == "***redacted***"


def test_chat_done_reports_the_served_model(client, gateway):
    gateway.post(GATEWAY).mock(
        return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, content=sse("ok", model="us.amazon.nova-lite-v1:0"))
    )
    cm, rec, _ = ready(client, dev_auth("jane@example.com"))
    try:
        rec.send({"type": "chat", "id": "c-m", "messages": MSGS})
        frames = rec.recv_until(lambda m: m["type"] in ("chat.done", "chat.error"))
    finally:
        cm.__exit__(None, None, None)
    done = frames[-1]
    assert done["type"] == "chat.done" and done["model"] == "us.amazon.nova-lite-v1:0"
    assert done["route"]["user_tier"] == "premium" and done["route"]["job_profile"] == "general"
