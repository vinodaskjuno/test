"""Local browser sign-in: RFC 8252 loopback redirects for native IDE clients (the Eclipse plugin)."""

from __future__ import annotations

from urllib.parse import parse_qs, urlsplit

import pytest
from conftest import make_app
from fastapi.testclient import TestClient
from platform_api.routes.local_auth import is_loopback_redirect, is_web_redirect, valid_redirect_uri

STATE = "abcdefghijklmnop1234"
V4 = "http://127.0.0.1:53123/auth/callback"
V6 = "http://[::1]:61000/auth/callback"


@pytest.mark.parametrize(
    "uri,ok",
    [
        (V4, True),
        (V6, True),
        ("http://127.0.0.1:1/auth/callback", True),
        ("http://127.0.0.1:65535/auth/callback", True),
        ("http://127.0.0.1:53123/auth/callback?x=1", True),  # extra query is kept, email/state replaced
        ("http://127.0.0.1/auth/callback", False),  # explicit (ephemeral) port required
        ("https://127.0.0.1:53123/auth/callback", False),  # loopback is plain http (RFC 8252 7.3)
        ("http://localhost:53123/auth/callback", False),  # names can be re-pointed; IP literals only
        ("http://127.0.0.2:53123/auth/callback", False),
        ("http://0.0.0.0:53123/auth/callback", False),
        ("http://127.0.0.1.evil.example:53123/auth/callback", False),
        ("http://evil.example@127.0.0.1:53123/auth/callback", False),
        ("http://user:pw@127.0.0.1:53123/auth/callback", False),
        ("http://127.0.0.1:53123/callback", False),
        ("http://127.0.0.1:53123/auth/callback/", False),
        ("http://127.0.0.1:53123/auth/callback#frag", False),
        ("http://127.0.0.1:0/auth/callback", False),
        ("http://127.0.0.1:99999/auth/callback", False),
        ("http://[::2]:53123/auth/callback", False),
    ],
)
def test_loopback_redirect_rules(uri, ok):
    assert is_loopback_redirect(uri) is ok
    assert valid_redirect_uri(uri) is ok  # no web origins configured: only the loopback rule can match


def test_loopback_is_not_treated_as_a_web_portal_redirect():
    assert is_web_redirect(V4) is False
    assert is_web_redirect("http://localhost:3000/auth/callback") is True


@pytest.fixture
def client():
    with TestClient(make_app()) as c:
        yield c


@pytest.mark.parametrize("redirect", [V4, V6])
def test_signin_form_accepts_loopback(client, redirect):
    r = client.get("/auth/local/signin", params={"redirect_uri": redirect, "state": STATE})
    assert r.status_code == 200
    assert "AIG IDE plugin" in r.text and "return to the IDE" in r.text
    assert r.headers["content-security-policy"].startswith("default-src 'none'")


def test_signin_submit_redirects_to_loopback_with_state(client):
    r = client.post(
        "/auth/local/signin",
        data={"redirect_uri": V4 + "?x=1&email=evil@x.com", "state": STATE, "email": "jane@example.com"},
    )
    assert r.status_code == 200
    assert "Return to the IDE" in r.text
    start = r.text.index('url=') + 4
    target = r.text[start : r.text.index('"', start)].replace("&amp;", "&")
    parts = urlsplit(target)
    assert (parts.scheme, parts.hostname, parts.port, parts.path) == ("http", "127.0.0.1", 53123, "/auth/callback")
    assert parse_qs(parts.query) == {"x": ["1"], "email": ["jane@example.com"], "state": [STATE]}


@pytest.mark.parametrize(
    "redirect",
    ["http://localhost:53123/auth/callback", "http://127.0.0.1/auth/callback", "https://127.0.0.1:5000/auth/callback"],
)
def test_signin_rejects_non_loopback_http(client, redirect):
    r = client.get("/auth/local/signin", params={"redirect_uri": redirect, "state": STATE})
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "invalid_redirect_uri"


def test_loopback_signin_only_in_local_dev_mode():
    with TestClient(make_app(env="local", auth_mode="oidc")) as c:
        assert c.get("/auth/local/signin", params={"redirect_uri": V4, "state": STATE}).status_code == 404
        assert c.post("/auth/local/signin", data={"redirect_uri": V4, "state": STATE, "email": "a@b.co"}).status_code == 404
