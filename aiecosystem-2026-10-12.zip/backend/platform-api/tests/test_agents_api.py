"""Phase 3: agent registry API (list, register + hooks, service-token suspend/reinstate)."""

from __future__ import annotations

import sys
import types

import pytest
import yaml
from conftest import (
    USERS,
    assert_no_secrets,
    configured_secrets,
    dev_auth,
    make_settings,
)
from fastapi.testclient import TestClient
from platform_api.agent_hooks import FIDDLER_HOOK, AgentHook, load_agent_hooks
from platform_api.agents import AgentRecord, YamlAgentRegistry
from platform_api.errors import StartupError
from platform_api.main import create_app
from platform_api.users import YamlUserDirectory

SERVICE_TOKEN = "svc-SUPERSECRET-99887766554433"
SVC = {"x-aig-service-token": SERVICE_TOKEN}
REGISTRY = {
    "agents": {
        "uw-quote-assistant": {"owner": "jane@example.com", "team": "underwriting-ai", "status": "active"},
        "untraced-bot": {"owner": "bob@example.com", "team": "claims-ai", "status": "active"},
    }
}


def build(registry=None, hooks=None, env="local", token=SERVICE_TOKEN, **kw):
    secrets = configured_secrets(PLATFORM_SERVICE_TOKEN=token) if token else configured_secrets()
    return create_app(
        make_settings(env, "dev" if env == "local" else "oidc", **kw),
        secrets=secrets,
        users=YamlUserDirectory(USERS, "standard"),
        agents=registry if registry is not None else YamlAgentRegistry(REGISTRY),
        agent_hooks=hooks if hooks is not None else [],
    )


def test_list_requires_auth_and_accepts_service_token_or_user():
    with TestClient(build()) as c:
        assert c.get("/api/v1/agents").status_code == 401
        assert c.get("/api/v1/agents", headers={"x-aig-service-token": "wrong"}).json()["error"]["code"] == "service_unauthenticated"
        ids = [a["agent_id"] for a in c.get("/api/v1/agents", headers=SVC).json()["agents"]]
        assert {"uw-quote-assistant", "untraced-bot", "ide.vscode"} <= set(ids)
        assert c.get("/api/v1/agents", headers=dev_auth()).status_code == 200
        r = c.get("/api/v1/agents/untraced-bot", headers=SVC)
        assert r.json()["agent"]["owner"] == "bob@example.com"
        assert c.get("/api/v1/agents/nope", headers=SVC).status_code == 404


def test_service_token_not_configured_is_503_even_in_local():
    with TestClient(build(token=None)) as c:
        r = c.post("/api/v1/agents/untraced-bot/suspend", headers=SVC, json={"reason": "x"})
        assert r.status_code == 503
        assert r.json()["error"]["code"] == "service_token_not_configured"


def test_suspend_is_service_only_idempotent_and_blocks_agent_check():
    registry = YamlAgentRegistry(REGISTRY)
    with TestClient(build(registry)) as c:
        # A user token without the admin role is not enough (Phase 4: 403 forbidden; admins may suspend).
        assert c.post("/api/v1/agents/untraced-bot/suspend", headers=dev_auth(), json={"reason": "x"}).status_code == 403
        body = {"reason": "gateway traffic without Fiddler traces", "source": "reconciliation", "evidence": {"requests": 12}}
        r = c.post("/api/v1/agents/untraced-bot/suspend", headers=SVC, json=body)
        assert r.status_code == 200, r.text
        assert r.json()["changed"] is True
        agent = r.json()["agent"]
        assert agent["status"] == "suspended"
        assert agent["status_reason"].startswith("reconciliation: gateway traffic")
        assert agent["status_changed_at"]
        again = c.post("/api/v1/agents/untraced-bot/suspend", headers=SVC, json=body)
        assert again.json()["changed"] is False
        assert registry.get("untraced-bot").status == "suspended"
        assert c.post("/api/v1/agents/missing/suspend", headers=SVC, json=body).status_code == 404
        assert c.post("/api/v1/agents/untraced-bot/suspend", headers=SVC, json={}).json()["error"]["code"] == "invalid_request"
        # The agent-check webhook now denies it (local: no webhook secret needed).
        verdict = c.post(
            "/api/v1/guardrails/agent-check",
            json={"metadata": {"agent_id": "untraced-bot", "team": "claims-ai", "user_tier": "free", "job_profile": "claims"}},
        ).json()
        assert verdict["verdict"] is False and verdict["data"]["reason"] == "agent_suspended"
        r = c.post("/api/v1/agents/untraced-bot/reinstate", headers=SVC, json={"reason": "fixed tracing", "source": "platform-team"})
        assert r.json()["agent"]["status"] == "active"
        assert_no_secrets(r.text)
        assert SERVICE_TOKEN not in r.text


def test_suspension_is_persisted_to_a_real_registry_file(tmp_path):
    path = tmp_path / "agents.yaml"
    path.write_text(yaml.safe_dump(REGISTRY))
    registry = YamlAgentRegistry.from_file(path, env="dev")
    registry.set_status("untraced-bot", "suspended", "reconciliation: no traces")
    reloaded = YamlAgentRegistry.from_file(path, env="dev")
    assert reloaded.get("untraced-bot").status == "suspended"
    assert reloaded.get("untraced-bot").status_reason == "reconciliation: no traces"
    assert reloaded.get("uw-quote-assistant").status == "active"


def test_example_registry_is_never_rewritten(tmp_path):
    path = tmp_path / "agents.example.yaml"
    original = yaml.safe_dump(REGISTRY)
    path.write_text(original)
    registry = YamlAgentRegistry.from_file(path, env="local")
    registry.set_status("untraced-bot", "suspended", "x")
    assert registry.get("untraced-bot").status == "suspended"
    assert path.read_text() == original


def test_register_as_user_runs_hooks_in_background():
    calls = []

    def hook(agent, *, env, fiddler_url, fiddler_api_key):
        calls.append((agent, env, fiddler_api_key is not None))
        return {"application": agent["agent_id"]}

    registry = YamlAgentRegistry(REGISTRY)
    with TestClient(build(registry, hooks=[AgentHook("test:hook", hook)])) as c:
        r = c.post("/api/v1/agents", headers=dev_auth("jane@example.com"), json={"agent_id": "uw-new-agent", "owner": "evil@x.com", "team": "other"})
        assert r.status_code == 201, r.text
        agent = r.json()["agent"]
        # Users register for themselves and their directory team; body owner/team are ignored.
        assert agent["owner"] == "jane@example.com" and agent["team"] == "underwriting-ai"
        assert r.json()["hooks"] == [{"hook": "test:hook", "status": "scheduled"}]
        assert c.post("/api/v1/agents", headers=dev_auth(), json={"agent_id": "uw-new-agent"}).status_code == 409
        assert c.post("/api/v1/agents", headers=dev_auth(), json={"agent_id": "bad id!"}).status_code == 400
    assert calls and calls[0][0]["agent_id"] == "uw-new-agent" and calls[0][1] == "local" and calls[0][2] is True


def test_register_as_service_needs_owner_and_team_and_failing_hook_is_harmless():
    def boom(agent, **_):
        raise RuntimeError("fiddler down")

    with TestClient(build(hooks=[AgentHook("test:boom", boom)])) as c:
        assert c.post("/api/v1/agents", headers=SVC, json={"agent_id": "svc-agent"}).status_code == 400
        r = c.post("/api/v1/agents", headers=SVC, json={"agent_id": "svc-agent", "owner": "ops@example.com", "team": "claims-ai"})
        assert r.status_code == 201
        assert c.get("/api/v1/agents/svc-agent", headers=SVC).json()["agent"]["team"] == "claims-ai"


def test_read_only_registry_answers_501():
    class ReadOnly:
        def get(self, agent_id):
            return AgentRecord(agent_id, "a@example.com", "t")

        def all(self):
            return []

    with TestClient(build(ReadOnly())) as c:
        r = c.post("/api/v1/agents/x/suspend", headers=SVC, json={"reason": "r"})
        assert r.status_code == 501 and r.json()["error"]["code"] == "registry_read_only"


def test_fiddler_autoprovision_flag_loads_the_aig_fiddler_hook(monkeypatch):
    fake_pkg = types.ModuleType("aig_fiddler")
    fake = types.ModuleType("aig_fiddler.hooks")
    fake.on_agent_registered = lambda agent, **kw: {"ok": True}
    monkeypatch.setitem(sys.modules, "aig_fiddler", fake_pkg)
    monkeypatch.setitem(sys.modules, "aig_fiddler.hooks", fake)
    hooks = load_agent_hooks(fiddler_autoprovision=True, extra=None, env="dev")
    assert [h.name for h in hooks] == [FIDDLER_HOOK]
    assert load_agent_hooks(fiddler_autoprovision=False, extra=None, env="dev") == []


def test_missing_hook_package_fails_closed_outside_local(monkeypatch):
    monkeypatch.setitem(sys.modules, "aig_fiddler", None)  # import raises ImportError
    with pytest.raises(StartupError):
        load_agent_hooks(fiddler_autoprovision=True, extra=None, env="prod")
    assert load_agent_hooks(fiddler_autoprovision=True, extra=None, env="local") == []
