from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from conftest import assert_no_secrets, configured_secrets, dev_auth, make_app, make_jwt
from platform_api.config import Settings, load_env_config
from platform_api.secrets import SecretStore


def test_healthz_shows_statuses_only(client):
    r = client.get("/healthz")
    assert r.status_code == 200
    body = r.json()
    assert body == {
        "status": "ok",
        "env": "local",
        "secrets": {
            "PORTKEY_API_KEY": "configured",
            "PORTKEY_ADMIN_API_KEY": "configured",
            "FIDDLER_API_KEY": "configured",
            "PORTKEY_WEBHOOK_SECRET": "missing",
            "PLATFORM_SERVICE_TOKEN": "missing",
            "TELEMETRY_BRIDGE_TOKEN": "missing",
            "GITHUB_DISPATCH_TOKEN": "missing",
            "AGENT_CALLER_SIGNING_KEY": "missing",
            "AGENT_OUTPUT_ENCRYPTION_KEY": "missing",
        },
        "database": {"backend": "sqlite", "status": "ok"},
    }
    assert_no_secrets(r.text)


def test_healthz_placeholder_and_missing():
    app = make_app(secrets=SecretStore({"PORTKEY_API_KEY": "__REPLACE_ME_PORTKEY_API_KEY_LOCAL__"}))
    with TestClient(app) as c:
        s = c.get("/healthz").json()["secrets"]
    assert s == {
        "PORTKEY_API_KEY": "placeholder",
        "PORTKEY_ADMIN_API_KEY": "missing",
        "FIDDLER_API_KEY": "missing",
        "PORTKEY_WEBHOOK_SECRET": "missing",
        "PLATFORM_SERVICE_TOKEN": "missing",
        "TELEMETRY_BRIDGE_TOKEN": "missing",
        "GITHUB_DISPATCH_TOKEN": "missing",
        "AGENT_CALLER_SIGNING_KEY": "missing",
        "AGENT_OUTPUT_ENCRYPTION_KEY": "missing",
    }


def test_session_requires_auth(client):
    r = client.get("/api/v1/session")
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "unauthenticated"


def test_session_contents_and_no_keys(client):
    r = client.get("/api/v1/session", headers=dev_auth("jane@example.com"))
    assert r.status_code == 200
    body = r.json()
    assert body["user"] == {"email": "jane@example.com", "name": "Jane Doe"}
    assert body["team"] == "underwriting-ai"
    assert body["user_tier"] == "premium"
    assert body["env"] == "local"
    assert body["allowed_job_profiles"] == ["underwriting", "claims", "operations", "general"]
    assert body["llm"] == {"base_url": "http://testserver/api/v1/llm", "config_id": "pc-aig-router"}
    assert "url" in body["fiddler"]
    assert_no_secrets(r.text)
    # "portkey_url" (Phase 4 links) is the only allowed occurrence of "key".
    assert "key" not in r.text.lower().replace('"portkey_url"', "")


def test_session_unknown_user_gets_default_tier(client):
    body = client.get("/api/v1/session", headers=dev_auth("new.person@example.com")).json()
    assert body["user_tier"] == "standard"
    assert body["team"] == "unassigned"


def test_session_uses_public_base_url():
    app = make_app(public_base_url="https://aig-api.example.com/")
    with TestClient(app) as c:
        body = c.get("/api/v1/session", headers=dev_auth()).json()
    assert body["llm"]["base_url"] == "https://aig-api.example.com/api/v1/llm"


def test_dev_token_rejected_in_local_oidc_mode():
    app = make_app(auth_mode="oidc")
    with TestClient(app) as c:
        assert c.get("/api/v1/session", headers=dev_auth()).status_code == 401


@pytest.mark.parametrize("token", ["dev:", "dev:not-an-email", "dev:a@b"])
def test_malformed_dev_tokens(client, token):
    assert client.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"}).status_code == 401


def test_non_bearer_scheme_rejected(client):
    assert client.get("/api/v1/session", headers={"Authorization": "Basic Zm9vOmJhcg=="}).status_code == 401


def _oidc_app(rsa_key, env="dev"):
    return make_app(env=env, auth_mode="oidc", secrets=configured_secrets(), key_resolver=lambda _t: rsa_key.public_key())


def _cfg(env):
    from conftest import make_settings

    return load_env_config(make_settings(env, "oidc"))


@pytest.mark.parametrize("env", ["dev", "prod"])
def test_oidc_jwt_accepted(rsa_key, env):
    cfg = _cfg(env)
    token = make_jwt(rsa_key, iss=cfg.oidc_issuer, aud=cfg.oidc_audience)
    with TestClient(_oidc_app(rsa_key, env)) as c:
        r = c.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["user"]["email"] == "jane@example.com"


def test_dev_token_rejected_in_dev_env(rsa_key):
    with TestClient(_oidc_app(rsa_key)) as c:
        assert c.get("/api/v1/session", headers=dev_auth()).status_code == 401


@pytest.mark.parametrize(
    "kwargs",
    [
        {"aud": "api://wrong"},
        {"iss": "https://evil.example.com"},
        {"exp_delta": -60},
    ],
)
def test_oidc_jwt_rejected(rsa_key, kwargs):
    cfg = _cfg("dev")
    claims = {"iss": cfg.oidc_issuer, "aud": cfg.oidc_audience}
    exp_delta = kwargs.pop("exp_delta", 300)
    claims.update(kwargs)
    token = make_jwt(rsa_key, exp_delta=exp_delta, **claims)
    with TestClient(_oidc_app(rsa_key)) as c:
        assert c.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"}).status_code == 401


def test_oidc_jwt_wrong_signing_key(rsa_key):
    from cryptography.hazmat.primitives.asymmetric import rsa

    other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    cfg = _cfg("dev")
    token = make_jwt(other, iss=cfg.oidc_issuer, aud=cfg.oidc_audience)
    with TestClient(_oidc_app(rsa_key)) as c:
        assert c.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"}).status_code == 401


def test_hs256_token_rejected(rsa_key):
    import jwt

    cfg = _cfg("dev")
    token = jwt.encode({"iss": cfg.oidc_issuer, "aud": cfg.oidc_audience, "exp": 9999999999, "email": "x@y.com"}, "k" * 32, algorithm="HS256")
    with TestClient(_oidc_app(rsa_key)) as c:
        assert c.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"}).status_code == 401
