from __future__ import annotations

import json
import logging

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from conftest import ADMIN_KEY, PORTKEY_KEY, assert_no_secrets, configured_secrets, dev_auth, make_app

GATEWAY = "http://localhost:8787/v1/chat/completions"
BODY = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]}
COMPLETION = {"id": "chatcmpl-1", "object": "chat.completion", "choices": [{"index": 0, "message": {"role": "assistant", "content": "hello"}}]}


@pytest.fixture
def gateway():
    with respx.mock(assert_all_called=False) as router:
        yield router


def post(client, headers=None, body=BODY):
    return client.post("/api/v1/llm/chat/completions", json=body, headers={**dev_auth(), **(headers or {})})


def test_server_key_injected_and_client_headers_stripped(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    r = post(
        client,
        {
            "x-portkey-api-key": "client-supplied-key",  # gitleaks:allow (dummy header; proxy must strip it)
            "x-portkey-config": "pc-evil",
            "x-portkey-metadata": json.dumps({"user_tier": "premium"}),
            "x-portkey-virtual-key": "vk-evil",
            "x-portkey-provider": "openai",
            "x-portkey-trace-id": "client-trace-evil",
        },
    )
    assert r.status_code == 200
    assert r.json() == COMPLETION
    sent = route.calls.last.request
    assert sent.headers["x-portkey-api-key"] == PORTKEY_KEY
    assert sent.headers["x-portkey-config"] == "pc-aig-router"
    assert "x-portkey-virtual-key" not in sent.headers
    assert "x-portkey-provider" not in sent.headers
    assert sent.headers["x-portkey-trace-id"] != "client-trace-evil"
    assert "authorization" not in sent.headers
    assert "client-supplied-key" not in str(sent.headers)
    assert json.loads(sent.content) == BODY
    assert_no_secrets(r.text)


def test_metadata_built_server_side_with_tier_from_directory(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    r = post(
        client,
        {
            "Authorization": "Bearer dev:bob@example.com",
            "x-aig-job-profile": "claims",
            "x-aig-agent-id": "claims-triage.v2",
            "x-portkey-metadata": json.dumps({"user_tier": "premium"}),
            "x-aig-user-tier": "premium",
        },
    )
    assert r.status_code == 200
    meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["user_tier"] == "standard"  # from directory, not the client
    assert meta["job_profile"] == "claims"
    assert meta["agent_id"] == "claims-triage.v2"
    assert meta["team"] == "claims-ai"
    assert meta["env"] == "local"
    assert meta["host"] == "vscode"
    assert meta["user"] == "bob@example.com"


def test_default_job_profile_is_general(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    assert post(client).status_code == 200
    meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["job_profile"] == "general"
    assert meta["user_tier"] == "premium"
    assert meta["agent_id"] == "ide.vscode"  # host's pre-registered agent when the client sends none


@pytest.mark.parametrize("profile", ["marketing", "UNDERWRITING", "general;drop"])
def test_invalid_job_profile_rejected(client, gateway, profile):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    r = post(client, {"x-aig-job-profile": profile})
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "invalid_job_profile"
    assert not route.called


@pytest.mark.parametrize("agent", ["a" * 65, "bad agent", "x/y"])
def test_invalid_agent_id_rejected(client, gateway, agent):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    r = post(client, {"x-aig-agent-id": agent})
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "invalid_agent_id"
    assert not route.called


def test_trace_id_echoed_when_valid(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    tid = "3f2b8c1e-1111-4222-8333-444455556666"
    r = post(client, {"x-aig-trace-id": tid})
    assert r.headers["x-aig-trace-id"] == tid
    assert route.calls.last.request.headers["x-portkey-trace-id"] == tid


def test_trace_id_generated_when_invalid(client, gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    r = post(client, {"x-aig-trace-id": "bad id\twith spaces"})
    tid = r.headers["x-aig-trace-id"]
    assert tid != "bad id\twith spaces" and len(tid) == 36
    assert route.calls.last.request.headers["x-portkey-trace-id"] == tid


def test_streaming_passthrough(client, gateway):
    sse = (
        b'data: {"choices":[{"delta":{"content":"Hel"}}]}\n\n'
        b'data: {"choices":[{"delta":{"content":"lo"}}]}\n\n'
        b"data: [DONE]\n\n"
    )
    route = gateway.post(GATEWAY).mock(
        return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=httpx.ByteStream(sse))
    )
    with client.stream(
        "POST", "/api/v1/llm/chat/completions", json={**BODY, "stream": True}, headers=dev_auth()
    ) as r:
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/event-stream")
        assert r.headers["x-aig-trace-id"]
        received = b"".join(r.iter_raw())
    assert received == sse
    sent = route.calls.last.request
    assert sent.headers["accept"] == "text/event-stream"
    assert json.loads(sent.content)["stream"] is True


def test_streaming_upstream_error_relayed(client, gateway):
    gateway.post(GATEWAY).mock(return_value=httpx.Response(429, json={"error": {"message": "rate limited"}}))
    r = post(client, body={**BODY, "stream": True})
    assert r.status_code == 429
    assert r.json()["error"]["message"] == "rate limited"


@pytest.mark.parametrize("status", [400, 401, 429, 500, 502])
def test_upstream_errors_relayed_with_status(client, gateway, status):
    gateway.post(GATEWAY).mock(return_value=httpx.Response(status, json={"error": {"message": f"upstream {status}"}}))
    r = post(client)
    assert r.status_code == status
    assert r.json()["error"]["message"] == f"upstream {status}"
    assert r.headers["x-aig-trace-id"]


def test_upstream_error_echoing_key_is_redacted(client, gateway):
    gateway.post(GATEWAY).mock(return_value=httpx.Response(401, json={"error": f"bad key {PORTKEY_KEY}"}))
    r = post(client)
    assert r.status_code == 401
    assert_no_secrets(r.text)


def test_timeout_returns_504(client, gateway):
    gateway.post(GATEWAY).mock(side_effect=httpx.ReadTimeout("slow"))
    r = post(client)
    assert r.status_code == 504
    assert r.json()["error"]["code"] == "upstream_timeout"


def test_connect_error_returns_502(client, gateway):
    gateway.post(GATEWAY).mock(side_effect=httpx.ConnectError("down"))
    r = post(client)
    assert r.status_code == 502


def test_503_when_key_placeholder_in_local(gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    app = make_app(secrets=configured_secrets(PORTKEY_API_KEY="__REPLACE_ME_PORTKEY_API_KEY_LOCAL__"))
    with TestClient(app) as c:
        r = post(c)
    assert r.status_code == 503
    assert r.json() == {"error": {"code": "portkey_key_not_configured", "message": "Portkey API key is not configured on the backend"}}
    assert not route.called


def test_requires_auth(client, gateway):
    r = client.post("/api/v1/llm/chat/completions", json=BODY)
    assert r.status_code == 401


@pytest.mark.parametrize("raw", [b"not json", b"[1,2]", b'"str"'])
def test_bad_body(client, gateway, raw):
    r = client.post("/api/v1/llm/chat/completions", content=raw, headers={**dev_auth(), "content-type": "application/json"})
    assert r.status_code == 400


def test_no_secret_in_any_response_or_log(gateway, caplog, capfd):
    caplog.set_level(logging.DEBUG)
    gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    gateway.get(url__regex=r".*/analytics/groups/users.*").mock(
        return_value=httpx.Response(200, json={"data": [{"user": "jane@example.com", "requests": 3, "cost": 0.12}]})
    )
    app = make_app(secrets=configured_secrets())
    texts = []
    with TestClient(app) as c:
        for method, path, kw in [
            ("GET", "/healthz", {}),
            ("GET", "/api/v1/session", {"headers": dev_auth()}),
            ("POST", "/api/v1/llm/chat/completions", {"headers": dev_auth(), "json": BODY}),
            ("POST", "/api/v1/llm/chat/completions", {"headers": {**dev_auth(), "x-aig-job-profile": "nope"}, "json": BODY}),
            ("GET", "/api/v1/usage/me", {"headers": dev_auth()}),
            ("GET", "/api/v1/session", {}),
            ("GET", "/openapi.json", {}),
        ]:
            r = c.request(method, path, **kw)
            texts.append(r.text + json.dumps(dict(r.headers)))
    out, err = capfd.readouterr()
    assert_no_secrets("\n".join(texts) + caplog.text + out + err)
    for rec in caplog.records:
        assert_no_secrets(rec.getMessage())


def test_usage_me(client, gateway):
    route = gateway.get(url__regex=r"http://localhost:8787/v1/analytics/groups/users.*").mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"user": "other@example.com", "requests": 9}, {"user": "jane@example.com", "requests": 3, "cost": 0.12, "tokens": 1500}]},
        )
    )
    r = client.get("/api/v1/usage/me", headers=dev_auth())
    assert r.status_code == 200
    body = r.json()
    assert body["requests"] == 3 and body["cost"] == 0.12 and body["tokens"] == 1500
    assert route.calls.last.request.headers["x-portkey-api-key"] == ADMIN_KEY
    assert_no_secrets(r.text)


def test_usage_not_configured(gateway):
    app = make_app(secrets=configured_secrets(PORTKEY_ADMIN_API_KEY="__REPLACE_ME_PORTKEY_ADMIN_API_KEY_LOCAL__"))
    with TestClient(app) as c:
        r = c.get("/api/v1/usage/me", headers=dev_auth())
    assert r.status_code == 501
    assert r.json()["error"]["code"] == "usage_not_configured"


class _BrokenStream(httpx.AsyncByteStream):
    def __init__(self, first: bytes, exc: Exception):
        self.first, self.exc = first, exc

    async def __aiter__(self):
        yield self.first
        raise self.exc


def _sse_events(text: str) -> list[str]:
    return [l[len("data: "):] for l in text.splitlines() if l.startswith("data: ")]


@pytest.mark.parametrize(
    "exc,code",
    [
        (httpx.ReadTimeout("slow"), "upstream_timeout"),
        (httpx.ReadError("reset"), "upstream_interrupted"),
        (httpx.RemoteProtocolError("bad"), "upstream_interrupted"),
    ],
)
def test_stream_failure_midway_emits_error_event(client, gateway, exc, code):
    first = b'data: {"choices":[{"delta":{"content":"hel"}}]}\n\n'
    gateway.post(GATEWAY).mock(
        return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=_BrokenStream(first, exc))
    )
    with client.stream(
        "POST", "/api/v1/llm/chat/completions", json={**BODY, "stream": True}, headers=dev_auth()
    ) as r:
        assert r.status_code == 200
        text = "".join(r.iter_text())
    events = _sse_events(text)
    assert events[0] == '{"choices":[{"delta":{"content":"hel"}}]}'
    last = json.loads(events[-1])
    assert last["error"]["code"] == code
    assert "[DONE]" not in events
    assert_no_secrets(text)


def test_stream_error_event_terminates_partial_event(client, gateway):
    # Upstream dies mid-event (no blank line yet); the error must still be its own event.
    first = b'data: {"choices":[{"delta":{"content":"hel'
    gateway.post(GATEWAY).mock(
        return_value=httpx.Response(
            200, headers={"content-type": "text/event-stream"}, stream=_BrokenStream(first, httpx.ReadTimeout("slow"))
        )
    )
    with client.stream(
        "POST", "/api/v1/llm/chat/completions", json={**BODY, "stream": True}, headers=dev_auth()
    ) as r:
        text = "".join(r.iter_text())
    blocks = [b for b in text.split("\n\n") if b.strip()]
    assert json.loads(blocks[-1][len("data: "):])["error"]["code"] == "upstream_timeout"


def test_eclipse_agent_id_is_attributed_to_host_eclipse(client, gateway):
    """Eclipse sends x-aig-agent-id: ide.eclipse; metadata must say host=eclipse, not vscode."""
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
    r = post(client, {"x-aig-agent-id": "ide.eclipse"})
    assert r.status_code == 200
    meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["host"] == "eclipse" and meta["agent_id"] == "ide.eclipse"
    r = post(client)
    meta = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert meta["host"] == "vscode" and meta["agent_id"] == "ide.vscode"
