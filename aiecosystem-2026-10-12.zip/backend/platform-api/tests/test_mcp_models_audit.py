"""Phase 4: MCP registry (+ Portkey MCP gateway sync), model catalog lifecycle, audit log."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
from conftest import ADMIN_KEY, USERS, assert_no_secrets, configured_secrets, dev_auth, make_settings
from fastapi.testclient import TestClient
from platform_api.main import create_app
from platform_api.users import YamlUserDirectory

SERVICE_TOKEN = "svc-SUPERSECRET-55443322110099"
SVC = {"x-aig-service-token": SERVICE_TOKEN}
ADMIN = dev_auth("admin@example.com")
APPROVER = dev_auth("approver@example.com")
JANE = dev_auth("jane@example.com")
ADMIN_API = "http://localhost:8787/v1"  # local.yaml portkey_admin_api_url
SERVER = {"name": "ServiceNow", "url": "https://mcp.servicenow.example.com/mcp", "description": "Tickets",
          "iam_roles": ["aig-claims-developer"], "workspaces": ["aig-claims"]}


def build(**kw):
    return create_app(make_settings(**kw), secrets=configured_secrets(PLATFORM_SERVICE_TOKEN=SERVICE_TOKEN),
                      users=YamlUserDirectory(USERS, "standard"), agent_hooks=[])


@pytest.fixture
def c():
    with TestClient(build()) as client:
        yield client


# --- MCP registry ---------------------------------------------------------------------------------


def test_request_list_and_validation(c):
    assert c.post("/api/v1/mcp-servers", json=SERVER).status_code == 401
    r = c.post("/api/v1/mcp-servers", headers=JANE, json=SERVER)
    assert r.status_code == 201, r.text
    s = r.json()
    assert s["status"] == "pending" and s["requested_by"] == "jane@example.com" and s["sync_status"] == "not_synced"
    for key in ("id", "name", "url", "description", "iam_roles", "workspaces", "status", "requested_by", "decided_by",
                "decided_at", "reason", "sync_status", "created_at"):
        assert key in s
    assert c.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["error"]["code"] == "mcp_server_exists"
    listed = c.get("/api/v1/mcp-servers", headers=JANE).json()
    assert listed["total"] == 1 and listed["items"][0]["id"] == s["id"]
    assert c.get("/api/v1/mcp-servers?status=approved", headers=SVC).json()["total"] == 0
    for bad in ({**SERVER, "url": "ftp://x"}, {**SERVER, "url": "https://u:p@host/mcp"},
                {**SERVER, "workspaces": ["bad space"]}, {**SERVER, "iam_roles": ["role with space"]}, {"name": "x"}):
        r = c.post("/api/v1/mcp-servers", headers=JANE, json=bad)
        assert r.status_code == 400 and r.json()["error"]["code"] == "invalid_request", bad


def test_http_mcp_url_only_in_local():
    from platform_api.errors import ApiError
    from platform_api.routes.mcp import _validate
    from platform_api.schemas import McpServerCreate

    _validate(McpServerCreate(name="x", url="http://mcp.local/mcp"), "local")
    for env in ("dev", "stage", "prod"):
        with pytest.raises(ApiError):
            _validate(McpServerCreate(name="x", url="http://mcp.local/mcp"), env)
        _validate(McpServerCreate(name="x", url="https://mcp.example.com/mcp"), env)


def test_approve_requires_admin_and_sync_disabled_by_default(c):
    sid = c.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["id"]
    assert c.post(f"/api/v1/mcp-servers/{sid}/approve", headers=JANE).status_code == 403
    assert c.post(f"/api/v1/mcp-servers/{sid}/approve", headers=SVC).status_code == 403
    assert c.post("/api/v1/mcp-servers/nope/approve", headers=ADMIN).json()["error"]["code"] == "mcp_server_not_found"
    r = c.post(f"/api/v1/mcp-servers/{sid}/approve", headers=ADMIN, json={"reason": "reviewed"})
    assert r.status_code == 200
    s = r.json()
    assert s["status"] == "approved" and s["decided_by"] == "admin@example.com" and s["decided_at"]
    assert s["reason"] == "reviewed" and s["sync_status"] == "disabled"
    again = c.post(f"/api/v1/mcp-servers/{sid}/reject", headers=ADMIN)
    assert again.status_code == 409 and again.json()["error"]["code"] == "invalid_transition"
    audit = c.get(f"/api/v1/audit?entity_type=mcp_server&entity_id={sid}", headers=ADMIN).json()["items"]
    assert [a["action"] for a in audit] == ["mcp.approve", "mcp.request"]


def test_reject_with_and_without_reason(c):
    a = c.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["id"]
    r = c.post(f"/api/v1/mcp-servers/{a}/reject", headers=ADMIN, json={"reason": "duplicate of aig-jira"})
    assert r.json()["status"] == "rejected" and r.json()["reason"] == "duplicate of aig-jira" and r.json()["sync_status"] == "not_synced"
    b = c.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["id"]  # url free again after rejection
    assert c.post(f"/api/v1/mcp-servers/{b}/reject", headers=ADMIN).json()["reason"] is None


def test_sync_to_portkey_mcp_gateway_upserts():
    app = build(mcp_sync=True)
    with respx.mock(assert_all_called=True) as router, TestClient(app) as client:
        create = router.post(f"{ADMIN_API}/mcp-servers").mock(return_value=httpx.Response(409, json={"error": "exists"}))
        update = router.put(url__regex=rf"{ADMIN_API}/mcp-servers/aig-servicenow-[0-9a-f]{{8}}").mock(
            return_value=httpx.Response(200, json={"ok": True}))
        sid = client.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["id"]
        s = client.post(f"/api/v1/mcp-servers/{sid}/approve", headers=ADMIN).json()
    assert s["sync_status"] == "synced" and s["sync_error"] is None and s["synced_at"]
    sent = json.loads(create.calls[0].request.content)
    assert sent["url"] == SERVER["url"] and sent["workspace_ids"] == ["aig-claims"]
    assert sent["access"] == {"unregistered": "deny", "iam_roles": ["aig-claims-developer"]}
    assert create.calls[0].request.headers["x-portkey-api-key"] == ADMIN_KEY
    assert update.called


@pytest.mark.parametrize("failure", ["status", "timeout", "connect"])
def test_sync_failure_is_recorded_and_never_fails_the_approval(failure):
    app = build(mcp_sync=True)
    with respx.mock() as router, TestClient(app) as client:
        route = router.post(f"{ADMIN_API}/mcp-servers")
        if failure == "status":
            route.mock(return_value=httpx.Response(500, text=f"boom {ADMIN_KEY}"))
        elif failure == "timeout":
            route.mock(side_effect=httpx.ReadTimeout("slow"))
        else:
            route.mock(side_effect=httpx.ConnectError("down"))
        sid = client.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["id"]
        r = client.post(f"/api/v1/mcp-servers/{sid}/approve", headers=ADMIN)
        audit = client.get(f"/api/v1/audit?entity_id={sid}", headers=ADMIN).json()["items"]
    assert r.status_code == 200
    s = r.json()
    assert s["status"] == "approved" and s["sync_status"] == "failed" and s["sync_error"]
    assert_no_secrets(r.text)
    assert audit[0]["action"] == "mcp.sync" and audit[0]["details"]["sync_status"] == "failed"


def test_sync_without_admin_key_fails_softly():
    app = create_app(make_settings(mcp_sync=True), secrets=configured_secrets(PORTKEY_ADMIN_API_KEY=None),
                     users=YamlUserDirectory(USERS, "standard"), agent_hooks=[])
    with TestClient(app) as client:
        sid = client.post("/api/v1/mcp-servers", headers=JANE, json=SERVER).json()["id"]
        s = client.post(f"/api/v1/mcp-servers/{sid}/approve", headers=ADMIN).json()
    assert s["status"] == "approved" and s["sync_status"] == "failed" and "not configured" in s["sync_error"]


# --- model catalog --------------------------------------------------------------------------------

MODEL = {"name": "claude-sonnet-5", "provider": "anthropic", "version": "2026-09", "tiers": ["standard"],
         "job_profiles": ["claims"], "use_case": "claims triage", "data_classification": "confidential",
         "expected_monthly_cost_usd": 1200.5}
CARD = {"accuracy": 0.91, "faithfulness": 0.95, "safety_critical_failures": 0, "latency_p95_ms": 1800,
        "cost_per_1k_usd": 0.012, "baseline": {"accuracy": 0.88, "model": "claude-sonnet-4"}, "passed": True,
        "evidence_url": "https://fiddler.example.com/experiments/42"}


def _to(client, mid, to, who, **extra):
    return client.post(f"/api/v1/models/{mid}/transition", headers=who, json={"to": to, **extra})


def test_model_request_and_validation(c):
    r = c.post("/api/v1/models", headers=JANE, json=MODEL)
    assert r.status_code == 201
    m = r.json()
    assert m["status"] == "requested" and m["requested_by"] == "jane@example.com"
    assert m["allowed_transitions"] == ["sandbox"] and m["scorecard"] is None and m["canary_share"] is None
    assert c.post("/api/v1/models", headers=JANE, json=MODEL).json()["error"]["code"] == "model_exists"
    assert c.get(f"/api/v1/models/{m['id']}", headers=SVC).json()["name"] == "claude-sonnet-5"
    assert c.get("/api/v1/models/nope", headers=JANE).json()["error"]["code"] == "model_not_found"
    assert c.get("/api/v1/models", headers=JANE).json()["total"] == 1
    for bad in ({**MODEL, "data_classification": "secret"}, {**MODEL, "tiers": ["gold"]},
                {**MODEL, "job_profiles": ["hr"]}, {**MODEL, "expected_monthly_cost_usd": -1}):
        assert c.post("/api/v1/models", headers=JANE, json={**bad, "version": "v-bad"}).status_code == 400


def test_full_lifecycle_with_roles_and_audit(c):
    mid = c.post("/api/v1/models", headers=JANE, json=MODEL).json()["id"]
    assert _to(c, mid, "sandbox", JANE).status_code == 403
    assert _to(c, mid, "approved", ADMIN).status_code == 403  # approver-only step
    bad = _to(c, mid, "evaluating", ADMIN)
    assert bad.status_code == 409 and bad.json()["error"]["code"] == "invalid_transition"
    assert _to(c, mid, "sandbox", SVC).json()["status"] == "sandbox"
    assert _to(c, mid, "evaluating", ADMIN, note="running suites").json()["status"] == "evaluating"
    # scorecard: admin/service only
    assert c.put(f"/api/v1/models/{mid}/scorecard", headers=JANE, json=CARD).status_code == 403
    assert c.put(f"/api/v1/models/{mid}/scorecard", headers=APPROVER, json=CARD).status_code == 403
    assert c.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json={**CARD, "accuracy": "high"}).status_code == 400
    r = c.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json=CARD)
    assert r.status_code == 200 and r.json()["scorecard"]["passed"] is True and r.json()["scorecard"]["updated_by"] == "service"
    m = _to(c, mid, "approved", APPROVER, note="meets gate").json()
    assert m["status"] == "approved" and m["decided_by"] == "approver@example.com" and m["decided_at"]
    assert _to(c, mid, "canary", ADMIN, canary_share=150).status_code == 400
    m = _to(c, mid, "canary", ADMIN, canary_share=5).json()
    assert m["status"] == "canary" and m["canary_share"] == 5 and m["canary_started_at"]
    assert _to(c, mid, "promoted", SVC).status_code == 403
    m = _to(c, mid, "promoted", APPROVER).json()
    assert m["status"] == "promoted" and m["canary_share"] == 100 and m["allowed_transitions"] == []
    assert _to(c, mid, "rolled_back", APPROVER).json()["error"]["code"] == "invalid_transition"
    assert c.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json=CARD).status_code == 409
    audit = c.get(f"/api/v1/audit?entity_type=model&entity_id={mid}", headers=APPROVER).json()["items"]
    actions = [(a["action"], a["details"].get("to")) for a in reversed(audit)]
    assert actions == [("model.request", None), ("model.transition", "sandbox"), ("model.transition", "evaluating"),
                       ("model.scorecard", None), ("model.transition", "approved"), ("model.transition", "canary"),
                       ("model.transition", "promoted")]
    approved = next(a for a in audit if a["details"].get("to") == "approved")
    assert approved["actor"] == "approver@example.com" and approved["details"]["note"] == "meets gate"
    assert approved["details"]["evidence_url"] == CARD["evidence_url"]


def test_reject_and_rollback(c):
    a = c.post("/api/v1/models", headers=JANE, json=MODEL).json()["id"]
    _to(c, a, "sandbox", ADMIN)
    _to(c, a, "evaluating", ADMIN)
    assert _to(c, a, "rejected", APPROVER, note="safety failures").json()["status"] == "rejected"
    assert _to(c, a, "canary", ADMIN).status_code == 409
    b = c.post("/api/v1/models", headers=JANE, json={**MODEL, "version": "v2"}).json()["id"]
    for step, who in (("sandbox", ADMIN), ("evaluating", ADMIN)):
        _to(c, b, step, who)
    assert c.put(f"/api/v1/models/{b}/scorecard", headers=SVC, json=CARD).status_code == 200  # Phase 7 gate
    for step, who in (("approved", APPROVER), ("canary", ADMIN)):
        _to(c, b, step, who)
    m = _to(c, b, "rolled_back", APPROVER).json()
    assert m["status"] == "rolled_back" and m["canary_share"] == 0 and c.get(f"/api/v1/models/{b}", headers=JANE).json()["canary_share"] == 0
    assert _to(c, b, "canary", ADMIN, canary_share=10).status_code == 409


def test_canary_share_only_with_canary(c):
    mid = c.post("/api/v1/models", headers=JANE, json=MODEL).json()["id"]
    assert _to(c, mid, "sandbox", ADMIN, canary_share=10).json()["error"]["code"] == "invalid_request"
    assert _to(c, mid, "nowhere", ADMIN).status_code == 400


# --- audit ----------------------------------------------------------------------------------------


def test_audit_requires_admin_or_approver_and_limits(c):
    for i in range(3):
        c.post("/api/v1/models", headers=JANE, json={**MODEL, "version": f"v{i}"})
    assert c.get("/api/v1/audit", headers=JANE).status_code == 403
    assert c.get("/api/v1/audit", headers=SVC).status_code == 403
    assert c.get("/api/v1/audit").status_code == 401
    body = c.get("/api/v1/audit?limit=2", headers=ADMIN).json()
    assert body["total"] == 3 and len(body["items"]) == 2
    entry = body["items"][0]
    assert set(entry) == {"id", "at", "actor", "action", "entity_type", "entity_id", "details"}
    assert entry["details"]["version"] == "v2"  # newest first
    assert c.get("/api/v1/audit?limit=0", headers=ADMIN).status_code == 400
