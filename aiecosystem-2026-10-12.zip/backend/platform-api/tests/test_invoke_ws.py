"""WebSocket agent frames: agent.invoke / agent.delta / agent.output / agent.done / agent.error /
agent.cancel and agent.invocation.status pushes for background runs."""

from __future__ import annotations

import json

import pytest
from agent_helpers import (
    AGENT_API_KEY,
    BOB,
    CARA,
    OLGA,
    TestAgent,
    active_agent,
    build_app,
    register_agent,
    register_version,
)
from conftest import assert_no_secrets
from fastapi.testclient import TestClient

from platform_api.routes.ws import MAX_CONCURRENT_CHATS

WS = "/api/v1/ws"


class Socket:
    def __init__(self, ws):
        self.ws = ws
        self.frames: list[str] = []

    def send(self, obj):
        self.ws.send_text(json.dumps(obj))

    def recv(self) -> dict:
        text = self.ws.receive_text()
        self.frames.append(text)
        return json.loads(text)

    def until(self, pred, limit=50) -> list[dict]:
        got = []
        for _ in range(limit):
            m = self.recv()
            if m["type"] == "ping":
                continue
            got.append(m)
            if pred(m):
                return got
        raise AssertionError(got)


@pytest.fixture
def agent():
    return TestAgent()


@pytest.fixture
def c(agent):
    with TestClient(build_app(agent=agent)) as client:
        active_agent(client)
        yield client


def open_ws(c, headers=BOB):
    cm = c.websocket_connect(WS, headers=headers)
    s = Socket(cm.__enter__())
    assert s.recv()["type"] == "ready"
    return cm, s


def test_agent_invoke_streams_frames(c, agent):
    cm, s = open_ws(c, CARA)
    try:
        s.send({"type": "agent.invoke", "id": "r1", "agent_id": "claims-triage", "input": {"claim_id": "CLM-1"},
                "session_id": "s-1"})
        frames = s.until(lambda m: m["type"] == "agent.done")
    finally:
        cm.__exit__(None, None, None)
    types = [f["type"] for f in frames]
    assert types == ["agent.invocation.status", "agent.delta", "agent.delta", "agent.output", "agent.done"]
    status = frames[0]
    assert status["status"] == "running" and status["id"] == "r1" and status["mode"] == "stream"
    inv_id = status["invocation_id"]
    assert all(f["invocation_id"] == inv_id and f["id"] == "r1" for f in frames)
    assert "".join(f["text"] for f in frames if f["type"] == "agent.delta") == "Severity: HIGH"
    assert frames[3]["output"]["user"] == "cara@example.com" and frames[3]["usage"]["total_tokens"] == 18
    assert frames[4]["status"] == "succeeded"
    assert agent.requests[-1]["body"]["session_id"] == "s-1"
    rec = c.get(f"/api/v1/invocations/{inv_id}", headers=CARA).json()
    assert rec["status"] == "succeeded" and rec["mode"] == "stream"
    assert_no_secrets("\n".join(s.frames))


def test_agent_errors_and_validation(c):
    cm, s = open_ws(c, OLGA)
    try:
        s.send({"type": "agent.invoke", "id": "r1", "agent_id": "claims-triage", "input": {"claim_id": "1"}})
        err = s.recv()
        assert err == {"type": "agent.error", "id": "r1", "code": "agent_forbidden", "message": "you may not run this agent"}
        s.send({"type": "agent.invoke", "id": "bad id", "agent_id": "claims-triage"})
        assert s.recv()["code"] == "bad_request"
        s.send({"type": "agent.invoke", "id": "r2", "agent_id": "bad agent!"})
        assert s.recv()["code"] == "bad_request"
        s.send({"type": "agent.invoke", "id": "r3", "agent_id": "claims-triage", "env": "qa"})
        assert s.recv()["code"] == "bad_request"
        s.send({"type": "agent.cancel", "id": "nope"})
        assert s.recv() == {"type": "agent.error", "id": "nope", "code": "unknown_id",
                            "message": "no running agent invocation with this id"}
    finally:
        cm.__exit__(None, None, None)
    cm, s = open_ws(c, BOB)
    try:
        s.send({"type": "agent.invoke", "id": "r4", "agent_id": "claims-triage", "input": {"wrong": 1}})
        err = s.recv()
        assert err["type"] == "agent.error" and err["code"] == "input_invalid"
        s.send({"type": "agent.invoke", "id": "r5", "agent_id": "claims-triage", "input": {"claim_id": "1", "mode": "fail"}})
        frames = s.until(lambda m: m["type"] == "agent.done")
        assert [f["type"] for f in frames] == ["agent.invocation.status", "agent.error", "agent.done"]
        assert frames[1]["code"] == "agent_error" and frames[2]["status"] == "failed"
    finally:
        cm.__exit__(None, None, None)


def test_agent_cancel_and_concurrency(c):
    cm, s = open_ws(c, BOB)
    try:
        for i in range(MAX_CONCURRENT_CHATS):
            s.send({"type": "agent.invoke", "id": f"slow{i}", "agent_id": "claims-triage",
                    "input": {"claim_id": "1", "mode": "slow"}})
            assert s.until(lambda m: m["type"] == "agent.invocation.status")[-1]["status"] == "running"
        s.send({"type": "agent.invoke", "id": "extra", "agent_id": "claims-triage", "input": {"claim_id": "1"}})
        assert s.until(lambda m: m.get("id") == "extra")[-1]["code"] == "too_many_requests"
        s.send({"type": "chat", "id": "chat1", "messages": [{"role": "user", "content": "hi"}]})
        assert s.until(lambda m: m.get("id") == "chat1")[-1]["code"] == "too_many_requests"
        s.send({"type": "agent.invoke", "id": "slow0", "agent_id": "claims-triage", "input": {"claim_id": "1"}})
        assert s.until(lambda m: m.get("id") == "slow0")[-1]["code"] == "duplicate_id"
        s.send({"type": "agent.cancel", "id": "slow0"})
        frames = s.until(lambda m: m["type"] == "agent.done" and m["id"] == "slow0")
        cancel = [f for f in frames if f.get("id") == "slow0"]
        assert [f["type"] for f in cancel] == ["agent.error", "agent.done"]
        assert cancel[0]["code"] == "invocation_cancelled" and cancel[1]["status"] == "cancelled"
        inv_id = cancel[1]["invocation_id"]
    finally:
        cm.__exit__(None, None, None)
    rec = c.get(f"/api/v1/invocations/{inv_id}", headers=BOB).json()
    assert rec["status"] == "cancelled" and rec["error_code"] == "invocation_cancelled"
    # Closing the socket cancelled the other foreground runs.
    statuses = {i["status"] for i in c.get("/api/v1/invocations?mine=1", headers=BOB).json()["items"]}
    assert statuses == {"cancelled"}


def test_background_runs_push_status(c):
    cm, s = open_ws(c, BOB)
    try:
        s.send({"type": "agent.invoke", "id": "bg1", "agent_id": "claims-triage", "input": {"claim_id": "CLM-3"},
                "background": True})
        frames = s.until(lambda m: m["type"] == "agent.invocation.status" and m["status"] == "succeeded")
    finally:
        cm.__exit__(None, None, None)
    statuses = [f["status"] for f in frames if f["type"] == "agent.invocation.status"]
    assert statuses[0] == "queued" and statuses[-1] == "succeeded" and "running" in statuses
    final = frames[-1]
    assert final["id"] == "bg1" and final["mode"] == "background" and final["usage"]["total_tokens"] == 18
    rec = c.get(f"/api/v1/invocations/{final['invocation_id']}", headers=BOB).json()
    assert rec["output"]["claim_id"] == "CLM-3"


def test_background_started_over_http_pushes_to_the_socket(c):
    cm, s = open_ws(c, BOB)
    try:
        r = c.post("/api/v1/agents/claims-triage/invoke?mode=background", headers=BOB,
                   json={"input": {"claim_id": "1"}})
        inv_id = r.json()["invocation_id"]
        frames = s.until(lambda m: m["type"] == "agent.invocation.status" and m["status"] == "succeeded")
        assert frames[-1]["invocation_id"] == inv_id
    finally:
        cm.__exit__(None, None, None)


def test_ws_cancel_background_by_invocation_id(c):
    cm, s = open_ws(c, BOB)
    try:
        s.send({"type": "agent.invoke", "id": "bg2", "agent_id": "claims-triage",
                "input": {"claim_id": "1", "mode": "slow"}, "background": True})
        inv_id = s.until(lambda m: m["type"] == "agent.invocation.status" and m["status"] == "running")[-1]["invocation_id"]
        s.send({"type": "agent.cancel", "invocation_id": inv_id})
        last = s.until(lambda m: m["type"] == "agent.invocation.status" and m["status"] == "cancelled")[-1]
        assert last["error_code"] == "invocation_cancelled"
    finally:
        cm.__exit__(None, None, None)


def test_agent_secrets_redacted_from_frames(monkeypatch):
    monkeypatch.setenv("CLAIMS_AGENT_KEY", AGENT_API_KEY)

    agent = TestAgent()
    with TestClient(build_app(agent=agent)) as c:
        register_agent(c)
        register_version(c, auth={"type": "api_key", "secret_arn": "local:CLAIMS_AGENT_KEY"}, verified=True, activate=True)
        # The key platform-api resolved for this agent comes back in the agent's answer (the test
        # agent echoes claim_id): it is redacted from every frame.
        cm, s = open_ws(c, BOB)
        try:
            s.send({"type": "agent.invoke", "id": "r1", "agent_id": "claims-triage",
                    "input": {"claim_id": AGENT_API_KEY}})
            frames = s.until(lambda m: m["type"] == "agent.done")
        finally:
            cm.__exit__(None, None, None)
    text = "\n".join(s.frames)
    assert AGENT_API_KEY not in text and "***redacted***" in text
    assert frames[-1]["status"] == "succeeded"
