"""backend/contracts/platform-api.openapi.json must match the app (web generates its client from it)."""

from __future__ import annotations

import importlib.util
import json

from conftest import PROJECT_ROOT

SCRIPT = PROJECT_ROOT / "scripts" / "export-openapi.py"
COMMITTED = PROJECT_ROOT.parent / "contracts" / "platform-api.openapi.json"


def _exporter():
    spec = importlib.util.spec_from_file_location("export_openapi", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_committed_openapi_matches_the_app():
    exporter = _exporter()
    assert COMMITTED.is_file(), "run backend/platform-api/scripts/export-openapi.py"
    assert COMMITTED.read_text() == exporter.render(), (
        "backend/contracts/platform-api.openapi.json is stale: run .venv/bin/python scripts/export-openapi.py"
    )


def test_openapi_covers_the_portal_api():
    doc = json.loads(COMMITTED.read_text())
    paths = doc["paths"]
    expected = {
        ("get", "/api/v1/session"), ("get", "/api/v1/me/preferences"), ("put", "/api/v1/me/preferences"),
        ("get", "/api/v1/agents"), ("post", "/api/v1/agents"), ("get", "/api/v1/agents/{agent_id}"),
        ("patch", "/api/v1/agents/{agent_id}"), ("post", "/api/v1/agents/{agent_id}/suspend"),
        ("post", "/api/v1/agents/{agent_id}/reinstate"), ("get", "/api/v1/mcp-servers"), ("post", "/api/v1/mcp-servers"),
        ("post", "/api/v1/mcp-servers/{server_id}/approve"), ("post", "/api/v1/mcp-servers/{server_id}/reject"),
        ("get", "/api/v1/models"), ("post", "/api/v1/models"), ("get", "/api/v1/models/{model_id}"),
        ("post", "/api/v1/models/{model_id}/transition"), ("put", "/api/v1/models/{model_id}/scorecard"),
        ("get", "/api/v1/audit"), ("get", "/api/v1/workspaces"), ("post", "/api/v1/workspaces"),
        ("get", "/api/v1/workspaces/{workspace_id}"), ("post", "/api/v1/workspaces/{workspace_id}/cancel"),
        ("post", "/api/v1/workspaces/{workspace_id}/claim"),
        ("patch", "/api/v1/workspaces/{workspace_id}/status"), ("get", "/api/v1/evals"), ("post", "/api/v1/evals"),
        ("get", "/api/v1/usage/me"), ("get", "/api/v1/usage/dashboard"), ("get", "/api/v1/usage/by-team"),
        ("get", "/api/v1/routing"),
        # Registry v2 + invocation.
        ("get", "/api/v1/agents/{agent_id}/versions"), ("post", "/api/v1/agents/{agent_id}/versions"),
        ("post", "/api/v1/agents/{agent_id}/versions/{version}/verify"),
        ("post", "/api/v1/agents/{agent_id}/versions/{version}/retire"),
        ("post", "/api/v1/agents/{agent_id}/lifecycle"), ("put", "/api/v1/agents/{agent_id}/access"),
        ("post", "/api/v1/agents/{agent_id}/access/approve"), ("post", "/api/v1/agents/{agent_id}/access/reject"),
        ("get", "/api/v1/catalog"), ("post", "/api/v1/agents/{agent_id}/invoke"), ("get", "/api/v1/invocations"),
        ("get", "/api/v1/invocations/{invocation_id}"), ("post", "/api/v1/invocations/{invocation_id}/cancel"),
        ("get", "/api/v1/caller-token/jwks"),
    }
    missing = sorted(f"{m.upper()} {p}" for m, p in expected if m not in paths.get(p, {}))
    assert not missing, missing
    schemes = doc["components"]["securitySchemes"]
    assert {"HTTPBearer", "APIKeyHeader"} <= set(schemes)
    assert "SUPERSECRET" not in COMMITTED.read_text()
