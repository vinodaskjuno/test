"""Usage-based routing: limits (tier defaults + team/user overrides) vs live Portkey usage -> usage_state."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from conftest import configured_secrets, dev_auth, make_settings
from platform_api.main import create_app
from platform_api.users import YamlUserDirectory, merge_limits, validate_user_directory

GATEWAY = "http://localhost:8787/v1/chat/completions"
MODELS_URL = r"http://localhost:8787/v1/analytics/groups/model\?.*"
GRAPH_URL = r"http://localhost:8787/v1/analytics/graphs/(tokens|cost)\?.*"
USERS = {
    "default_team": "unassigned",
    "teams": {"capped": {"limits": {"daily": {"requests": 10}}}},
    "users": {
        "lim@example.com": {"name": "L", "team": "uw", "tier": "premium", "cost_mode": "quality", "limits": {"daily": {"requests": 5}}},
        "team@example.com": {"name": "T", "team": "capped", "tier": "standard"},
        "free@example.com": {"name": "F", "team": "uw", "tier": "free"},
        "admin@example.com": {"name": "A", "team": "aig-platform", "tier": "standard", "roles": ["user", "admin"]},
    },
}
LIMITS = {"premium": {"daily": {"tokens": 1000}}, "standard": {"daily": {"requests": 100}}}


def completion(model: str = "m") -> dict:
    return {"id": "c", "object": "chat.completion", "model": model, "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}}]}


@pytest.fixture
def gateway():
    with respx.mock(assert_all_called=False) as router:
        yield router


def make_client(limits=LIMITS):
    app = create_app(make_settings(), secrets=configured_secrets(), users=YamlUserDirectory(USERS, "standard"))
    app.state.env_config.usage_limits = {k: v for k, v in app.state.env_config.__class__.model_validate({**app.state.env_config.model_dump(), "usage_limits": limits}).usage_limits.items()}
    app.state.env_config.usage_cache_seconds = 0
    return TestClient(app)


def requests_rows(n: int) -> httpx.Response:
    return httpx.Response(200, json={"data": [{"model": "sonnet", "requests": n}]})


def test_merge_and_validation():
    assert merge_limits({"daily": {"requests": 5, "tokens": 9}}, {"daily": {"requests": 2}}) == {"daily": {"requests": 2, "tokens": 9}}
    bad = {"users": {"a@b.co": {"team": "t", "tier": "free", "limits": {"weekly": {"requests": 1}}}},
           "teams": {"t": {"limits": {"daily": {"bananas": 1}}}}}
    problems = " ".join(validate_user_directory(bad))
    assert "limits.weekly" in problems and "limits.daily.bananas" in problems


@pytest.mark.parametrize("used,state", [(3, "normal"), (4, "soft"), (5, "hard"), (9, "hard")])
def test_request_limit_states_reach_portkey_metadata(gateway, used, state):
    gateway.get(url__regex=MODELS_URL).mock(return_value=requests_rows(used))
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion()))
    with make_client() as c:
        r = c.post("/api/v1/llm/chat/completions", json={"messages": [{"role": "user", "content": "hi"}]}, headers=dev_auth("lim@example.com"))
        lim = c.get("/api/v1/usage/limits", headers=dev_auth("lim@example.com")).json()
    md = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    assert md["usage_state"] == state and r.headers["x-aig-route-usage-state"] == state
    assert lim["state"] == state
    req = next(x for x in lim["checks"] if x["metric"] == "requests")
    assert req["limit"] == 5 and req["used"] == used and req["period"] == "daily"
    tokens = next(x for x in lim["checks"] if x["metric"] == "tokens")  # tier default, graphs refused
    assert tokens["status"] == "unavailable" and "note" in lim


def test_team_override_and_no_limits(gateway):
    gateway.get(url__regex=MODELS_URL).mock(return_value=requests_rows(8))
    with make_client() as c:
        team = c.get("/api/v1/usage/limits", headers=dev_auth("team@example.com")).json()
        free = c.get("/api/v1/usage/limits", headers=dev_auth("free@example.com")).json()
    assert team["limits"] == {"daily": {"requests": 10}} and team["state"] == "soft"
    assert free == {**free, "state": "normal", "configured": False, "checks": []}


def test_all_unavailable_is_unknown_and_routes_like_normal(gateway):
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion()))
    with make_client({"premium": {"daily": {"tokens": 10}, "monthly": {"cost_usd": 1}}}) as c:
        c.post("/api/v1/llm/chat/completions", json={"messages": [{"role": "user", "content": "hi"}]}, headers=dev_auth("free@example.com"))  # free: no limits
        lim = c.get("/api/v1/usage/limits", headers=dev_auth("admin@example.com")).json()  # standard: none either
        c.post("/api/v1/llm/chat/completions", json={"messages": [{"role": "user", "content": "hi"}]}, headers=dev_auth("lim@example.com"))
    assert lim["state"] == "normal"
    md = json.loads(route.calls.last.request.headers["x-portkey-metadata"])
    # lim@ has a requests limit too, but groups/model is not mocked here -> unavailable as well
    assert md["usage_state"] == "unknown"


def test_routing_test_usage_state_override_is_admin_only(gateway):
    route = gateway.post(GATEWAY).mock(return_value=httpx.Response(200, json=completion("nova-lite")))
    gateway.get(url__regex=MODELS_URL).mock(return_value=requests_rows(0))
    gateway.get(url__regex=GRAPH_URL).mock(return_value=httpx.Response(403))
    with make_client() as c:
        assert c.post("/api/v1/routing/test", json={"usage_state": "hard"}, headers=dev_auth("lim@example.com")).status_code == 403
        bad = c.post("/api/v1/routing/test", json={"usage_state": "x"}, headers=dev_auth("admin@example.com"))
        ok = c.post("/api/v1/routing/test", json={"usage_state": "soft", "user_tier": "premium", "cost_mode": "quality"}, headers=dev_auth("admin@example.com"))
        own = c.post("/api/v1/routing/test", json={}, headers=dev_auth("lim@example.com")).json()
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "invalid_usage_state"
    assert ok.json()["route"]["usage_state"] == "soft"
    assert own["route"]["usage_state"] == "normal" and own["usage_status"]["configured"] is True
    assert json.loads(route.calls.last.request.headers["x-portkey-metadata"])["usage_state"] == "normal"
