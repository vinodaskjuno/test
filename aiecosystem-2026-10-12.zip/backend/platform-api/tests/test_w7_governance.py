"""W7 observability + governance: invocation events to the telemetry bridge (metadata only),
audit coverage of every registry/invocation action, catalog exclusions, retention purge."""

from __future__ import annotations

import json
import os
from datetime import timedelta
from pathlib import Path

import pytest
import respx
from agent_helpers import (
    ADMIN,
    BOB,
    CARA,
    GINA,
    OLGA,
    SVC,
    TestAgent,
    active_agent,
    audit,
    build_app,
    register_agent,
    register_version,
    wait_for,
)
from conftest import PROJECT_ROOT, make_settings
from fastapi.testclient import TestClient
from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

import platform_api.main as main_module
from platform_api.db import AgentInvocationRow, Database, utcnow
from platform_api.invocation_events import agent_host, build_invocation_event
from platform_api.invocations import InvocationStore

CONTRACTS = Path(os.environ.get("AIG_CONTRACTS_DIR") or PROJECT_ROOT.parent / "contracts")
SCHEMAS = {p.name: json.loads(p.read_text()) for p in CONTRACTS.glob("*.schema.json")}
REGISTRY = Registry().with_resources((s["$id"], Resource.from_contents(s)) for s in SCHEMAS.values())
EVENT_SCHEMA = Draft202012Validator(SCHEMAS["invocation-event.schema.json"], registry=REGISTRY,
                                    format_checker=FormatChecker())
BRIDGE = "http://bridge.test"
INGEST = f"{BRIDGE}/ingest/invocation"
BRIDGE_TOKEN = "bridge-SUPERSECRET-1122334455"
INVOKE = "/api/v1/agents/claims-triage/invoke"


def assert_contract(event: dict) -> None:
    errors = sorted(EVENT_SCHEMA.iter_errors(event), key=str)
    assert not errors, [e.message for e in errors]


# --- invocation events -> telemetry bridge ------------------------------------------------------


def test_builder_matches_the_contract_and_drops_what_does_not_fit():
    base = dict(invocation_id="0b6f1d2e-6c1a-4a8e-9c7d-1f2e3d4c5b6a", agent_id="claims-triage", team="claims-ai",
                version="1.0.0", env="prod", kind="agentcore", platform_env="prod", mode="stream", purpose="invoke",
                status="failed", trace_id="trace-claims-0001", caller_user="cara@example.com", caller_team="claims-ai",
                caller_tier="premium", duration_ms=1234, usage={"prompt_tokens": 3, "completion_tokens": 4},
                error_code="agent_error", session_id="case-1")
    event = build_invocation_event(**base)
    assert_contract(event)
    assert event["agent_host"] == "agentcore" and event["error_code"] == "agent_error" and "total_tokens" not in event
    ok = build_invocation_event(**{**base, "status": "succeeded", "session_id": "bad session!"})
    assert_contract(ok)
    assert "error_code" not in ok and "session_id" not in ok
    assert build_invocation_event(**{**base, "caller_user": "not-an-email"}) is None
    assert build_invocation_event(**{**base, "invocation_id": "nope"}) is None
    assert build_invocation_event(**{**base, "status": "running"}) is None
    assert agent_host("https", "local") == "laptop" and agent_host("https", "prod") == "ecs"


def _bridge_app(agent, **kw):
    return build_app(agent=agent, secrets={"TELEMETRY_BRIDGE_TOKEN": BRIDGE_TOKEN}, telemetry_bridge_url=BRIDGE, **kw)


def test_finished_invocation_posts_one_metadata_only_event():
    agent = TestAgent()
    with respx.mock(assert_all_called=False) as router:
        route = router.post(INGEST).respond(202, json={"counts": {"forwarded": 1}})
        with TestClient(_bridge_app(agent)) as c:
            active_agent(c)
            r = c.post(INVOKE, headers={**CARA, "x-aig-trace-id": "trace-claims-0042"},
                       json={"input": {"claim_id": "CLM-SECRET-INPUT"}, "session_id": "case-9"})
            assert r.status_code == 200, r.text
            inv_id = r.json()["invocation_id"]
            assert wait_for(lambda: route.call_count >= 1)
    req = route.calls[0].request
    assert req.headers["authorization"] == f"Bearer {BRIDGE_TOKEN}"
    event = json.loads(req.content)
    assert_contract(event)
    assert event["invocation_id"] == inv_id and event["trace_id"] == "trace-claims-0042"
    assert event["agent_id"] == "claims-triage" and event["team"] == "claims-ai" and event["env"] == "prod"
    assert event["caller_user"] == "cara@example.com" and event["caller_team"] == "claims-ai"
    assert event["caller_tier"] == "premium" and event["status"] == "succeeded" and event["mode"] == "sync"
    assert event["agent_host"] == "laptop" and event["kind"] == "https" and event["session_id"] == "case-9"
    assert event["total_tokens"] == 18
    raw = req.content.decode()
    assert "CLM-SECRET-INPUT" not in raw and "x-aig-caller" not in raw  # never input, output or token


def test_failed_invocation_event_carries_the_error_code():
    agent = TestAgent()
    with respx.mock(assert_all_called=False) as router:
        route = router.post(INGEST).respond(202)
        with TestClient(_bridge_app(agent)) as c:
            active_agent(c)
            assert c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "C", "mode": "fail"}}).status_code == 502
            assert wait_for(lambda: route.call_count >= 1)
    event = json.loads(route.calls[0].request.content)
    assert_contract(event)
    assert event["status"] == "failed" and event["error_code"] == "agent_error"


def test_bridge_down_or_unconfigured_never_breaks_an_invocation():
    agent = TestAgent()
    with respx.mock(assert_all_called=False) as router:
        route = router.post(INGEST).respond(503)
        with TestClient(_bridge_app(agent)) as c:
            active_agent(c)
            assert c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "C"}}).status_code == 200
            assert wait_for(lambda: route.call_count >= 1)
    with respx.mock(assert_all_called=False) as router:
        route = router.post(INGEST).respond(202)
        with TestClient(build_app(agent=TestAgent(), telemetry_bridge_url=BRIDGE)) as c:  # no token
            active_agent(c)
            assert c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "C"}}).status_code == 200
        assert route.call_count == 0


# --- audit coverage -----------------------------------------------------------------------------


def test_every_registry_and_invocation_action_is_audited():
    agent = TestAgent()
    app = build_app(agent=agent)
    agent.on_invoke = lambda claims: app.state.agents.touch("claims-triage", "agentcore")
    with TestClient(app) as c:
        register_agent(c)                                                     # agent.register
        register_version(c, headers=BOB)                                      # agent.version.register
        assert c.post("/api/v1/agents/claims-triage/versions/1.0.0/verify", headers=BOB).json()["passed"]
        c.put("/api/v1/agents/claims-triage/access", headers=BOB, json={"visibility": "org"})   # agent.access
        c.post("/api/v1/agents/claims-triage/access/approve", headers=ADMIN)                     # approve
        c.put("/api/v1/agents/claims-triage/access", headers=BOB, json={"visibility": "team"})
        c.put("/api/v1/agents/claims-triage/access", headers=BOB, json={"visibility": "org"})
        c.post("/api/v1/agents/claims-triage/access/reject", headers=ADMIN)                      # reject
        inv = c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "C"}}).json()["invocation_id"]
        bg = c.post(INVOKE, headers=CARA, params={"mode": "background"},
                    json={"input": {"claim_id": "C", "mode": "slow"}}).json()["invocation_id"]
        assert c.post(f"/api/v1/invocations/{bg}/cancel", headers=CARA).status_code == 200
        c.post("/api/v1/agents/claims-triage/lifecycle", headers=BOB, json={"to": "deprecated"})
        c.post("/api/v1/agents/claims-triage/versions/1.0.0/retire", headers=BOB)
        c.post("/api/v1/agents/claims-triage/suspend", headers=SVC, json={"reason": "no traces"})

        agent_actions = [e["action"] for e in audit(c, entity_type="agent", entity_id="claims-triage")]
        for action in ("agent.register", "agent.version.register", "agent.version.verify", "agent.lifecycle",
                       "agent.access", "agent.access.approve", "agent.access.reject", "agent.version.retire",
                       "agent.suspend"):
            assert action in agent_actions, (action, agent_actions)
        assert agent_actions.count("agent.lifecycle") >= 2  # verify activation + deprecate
        # entity_type=invocation is the alias of agent_invocation.
        inv_entries = audit(c, entity_type="invocation")
        assert inv_entries == audit(c, entity_type="agent_invocation")
        by_id = {}
        for e in inv_entries:
            by_id.setdefault(e["entity_id"], []).append(e["action"])
        assert by_id[inv] == ["agent.invoke"] and by_id[bg] == ["agent.invoke", "agent.invocation.cancel"]
        assert len([a for a in by_id.values() if a[0] == "agent.invoke"]) == 3  # verify run + sync + background
        assert all(e["details"]["agent_id"] == "claims-triage" for e in inv_entries)
        assert c.get("/api/v1/audit", headers=CARA, params={"entity_type": "invocation"}).status_code == 403


# --- catalog exclusions -------------------------------------------------------------------------


def _catalog(c, headers=BOB) -> list[str]:
    return [i["agent"]["agent_id"] for i in c.get("/api/v1/catalog", headers=headers).json()["items"]]


def test_catalog_excludes_suspended_retired_and_drafts_in_prod():
    with TestClient(build_app(agent=TestAgent())) as c:
        active_agent(c, "claims-triage")
        active_agent(c, "claims-deprecated")
        c.post("/api/v1/agents/claims-deprecated/lifecycle", headers=BOB, json={"to": "deprecated"})
        active_agent(c, "claims-retired-version")
        register_agent(c, "claims-draft")
        register_version(c, "claims-draft", verified=True)  # verified prod version, agent still a draft
        assert _catalog(c) == ["claims-deprecated", "claims-retired-version", "claims-triage"]
        c.post("/api/v1/agents/claims-retired-version/versions/1.0.0/retire", headers=BOB)
        c.post("/api/v1/agents/claims-triage/suspend", headers=SVC, json={"reason": "no traces"})
        assert _catalog(c) == ["claims-deprecated"]  # deprecated stays invocable until retired
        c.post("/api/v1/agents/claims-deprecated/lifecycle", headers=BOB, json={"to": "retired"})
        assert _catalog(c) == [] and _catalog(c, CARA) == []
        # Not invocable either.
        assert c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "C"}}).json()["error"]["code"] == "agent_not_invocable"
        r = c.post("/api/v1/agents/claims-draft/invoke", headers=OLGA, json={"input": {"claim_id": "C"}})
        assert r.status_code == 403
        assert _catalog(c, GINA) == []


# --- retention purge ----------------------------------------------------------------------------


def _row(s, inv_id: str, *, age_days: float, status: str = "succeeded", output: str | None = None,
         mode: str = "sync") -> None:
    at = utcnow() - timedelta(days=age_days)
    s.add(AgentInvocationRow(id=inv_id, agent_id="claims-triage", version="1.0.0", env="prod", caller="cara@example.com",
                             team="claims-ai", mode=mode, purpose="invoke", status=status, session_id=None,
                             trace_id=inv_id, created_at=at, started_at=at, finished_at=at,
                             retain_until=utcnow() + timedelta(days=365), output_encrypted=output,
                             output_expires_at=utcnow() + timedelta(days=365) if output else None))


@pytest.fixture
def seeded():
    db = Database.in_memory()
    with db.session() as s:
        _row(s, "new", age_days=1)
        _row(s, "old", age_days=91)
        _row(s, "old-running", age_days=120, status="running", mode="background")
        _row(s, "bg-old-output", age_days=31, output="gAAAA-ciphertext", mode="background")
        _row(s, "bg-fresh-output", age_days=2, output="gAAAA-ciphertext", mode="background")
    return db


def test_purge_deletes_old_metadata_and_outputs_by_configured_windows(seeded):
    store = InvocationStore(seeded)
    assert store.purge(dry_run=True) == {"invocations_deleted": 1, "outputs_cleared": 1}
    assert store.get("old") is not None  # dry run changes nothing
    assert store.purge() == {"invocations_deleted": 1, "outputs_cleared": 1}
    assert store.get("old") is None and store.get("old-running") is not None  # open runs are kept
    assert store.get("bg-old-output").has_output is False and store.get("bg-old-output") is not None
    assert store.get("bg-fresh-output").has_output is True
    assert store.purge(retention_days=30, output_retention_days=1) == {"invocations_deleted": 1, "outputs_cleared": 1}
    assert store.get("bg-old-output") is None and store.get("bg-fresh-output").has_output is False


def test_purge_cli(seeded, monkeypatch, capsys):
    monkeypatch.setattr(main_module, "open_database", lambda settings: seeded)
    monkeypatch.setattr(seeded, "dispose", lambda: None, raising=False)
    monkeypatch.setenv("AIG_ENV", "local")
    monkeypatch.setenv("AIG_AGENT_INVOCATION_RETENTION_DAYS", "90")
    assert main_module.run(["invocations", "purge", "--dry-run"]) == 0
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out == {"command": "invocations purge", "dry_run": True, "retention_days": 90, "output_retention_days": 30,
                   "invocations_deleted": 1, "outputs_cleared": 1}
    assert main_module.run(["invocations", "purge", "--retention-days", "60", "--output-retention-days", "20"]) == 0
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out["invocations_deleted"] == 1 and out["dry_run"] is False
    assert main_module.run(["invocations", "purge", "--retention-days", "10", "--output-retention-days", "20"]) == 2
    assert main_module.run(["invocations", "purge", "--retention-days", "0"]) == 2


def test_purge_function_uses_settings_defaults(seeded):
    settings = make_settings(agent_invocation_retention_days=100, agent_output_retention_days=40)
    assert main_module.purge_invocations(settings, database=seeded, dry_run=True) == 0
    assert InvocationStore(seeded).get("old") is not None


# --- invocation summary (telemetry-bridge reconciliation) -----------------------------------------


def test_invocation_summary_for_reconciliation():
    with TestClient(build_app(agent=TestAgent())) as c:
        active_agent(c)
        for mode in ("echo", "echo", "fail"):
            c.post(INVOKE, headers=CARA, json={"input": {"claim_id": "C", "mode": mode}})
        since = (utcnow() - timedelta(hours=1)).isoformat()
        until = (utcnow() + timedelta(hours=1)).isoformat()
        r = c.get("/api/v1/invocations/summary", headers=SVC, params={"since": since, "until": until, "env": "prod"})
        assert r.status_code == 200, r.text
        assert r.json()["items"] == [{"agent_id": "claims-triage", "version": "1.0.0", "env": "prod", "invocations": 3,
                                      "succeeded": 2, "failed": 1}]
        assert c.get("/api/v1/invocations/summary", headers=ADMIN, params={"since": since, "until": until}).status_code == 200
        assert c.get("/api/v1/invocations/summary", headers=CARA, params={"since": since, "until": until}).status_code == 403
        assert c.get("/api/v1/invocations/summary", headers=SVC, params={"since": until, "until": since}).status_code == 400
        assert c.get("/api/v1/invocations/summary", headers=SVC, params={"since": "x", "until": until}).status_code == 400
        assert c.get("/api/v1/invocations/summary", headers=SVC,
                     params={"since": since, "until": until, "env": "dev"}).json()["items"] == []
