from __future__ import annotations

import time
from pathlib import Path

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient

import platform_api.main as main_module
from platform_api.config import Settings
from platform_api.db import Database
from platform_api.main import create_app
from platform_api.secrets import SecretStore
from platform_api.users import YamlUserDirectory

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Distinctive fake secret values: tests assert these never leak anywhere.
PORTKEY_KEY = "pk-test-SUPERSECRET-0123456789abcdef"
ADMIN_KEY = "pk-admin-SUPERSECRET-fedcba9876543210"
FIDDLER_KEY = "fdl-SUPERSECRET-aaaabbbbcccc"
ALL_SECRET_VALUES = (PORTKEY_KEY, ADMIN_KEY, FIDDLER_KEY)

USERS = {
    "default_team": "unassigned",
    "users": {
        "jane@example.com": {"name": "Jane Doe", "team": "underwriting-ai", "tier": "premium"},
        "bob@example.com": {"name": "Bob", "team": "claims-ai", "tier": "standard"},
        # Phase 4 roles.
        "admin@example.com": {"name": "Ada Admin", "team": "aig-platform", "tier": "standard", "roles": ["user", "admin"]},
        "approver@example.com": {"name": "Abe Approver", "team": "model-risk", "tier": "standard", "roles": ["approver"]},
    },
}


@pytest.fixture(autouse=True)
def in_memory_database(monkeypatch):
    """Every app built by a test gets its own in-memory SQLite database (schema from the models;
    tests/test_db.py checks the Alembic migrations produce the same schema). Tests of the real
    URL policy call platform_api.db.open_database directly."""
    monkeypatch.setattr(main_module, "open_database", lambda settings: Database.in_memory())
    monkeypatch.setattr(main_module, "resolve_database_url", lambda env, url: "sqlite://")


def configured_secrets(**overrides) -> SecretStore:
    values = {"PORTKEY_API_KEY": PORTKEY_KEY, "PORTKEY_ADMIN_API_KEY": ADMIN_KEY, "FIDDLER_API_KEY": FIDDLER_KEY}
    values.update(overrides)
    return SecretStore(values)


PUBLIC_BASE_URL = "https://aig-api.test.example.com"


def make_settings(env: str = "local", auth_mode: str = "dev", **kw) -> Settings:
    # Non-local envs require AIG_PUBLIC_BASE_URL; pass public_base_url=None to test its absence.
    if env != "local":
        kw.setdefault("public_base_url", PUBLIC_BASE_URL)
    return Settings(
        env=env,
        auth_mode=auth_mode,
        config_dir=PROJECT_ROOT / "config",
        secrets_dir=kw.pop("secrets_dir", PROJECT_ROOT / "tests" / "_nonexistent_secrets"),
        **kw,
    )


def make_app(env="local", auth_mode="dev", secrets=None, key_resolver=None, **kw):
    return create_app(
        make_settings(env, auth_mode, **kw),
        secrets=secrets if secrets is not None else configured_secrets(),
        users=YamlUserDirectory(USERS, "standard"),
        key_resolver=key_resolver,
    )


@pytest.fixture
def app():
    return make_app()


@pytest.fixture
def client(app):
    with TestClient(app) as c:
        yield c


def dev_auth(email: str = "jane@example.com") -> dict[str, str]:
    return {"Authorization": f"Bearer dev:{email}"}


@pytest.fixture(scope="session")
def rsa_key():
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def make_jwt(private_key, *, iss: str, aud: str, email="jane@example.com", exp_delta=300, **extra) -> str:
    now = int(time.time())
    claims = {"iss": iss, "aud": aud, "iat": now, "exp": now + exp_delta, "preferred_username": email, "name": "Jane Doe"}
    claims.update(extra)
    return jwt.encode(claims, private_key, algorithm="RS256", headers={"kid": "test"})


def assert_no_secrets(text: str) -> None:
    for value in ALL_SECRET_VALUES:
        assert value not in text, "secret value leaked"
    assert "SUPERSECRET" not in text
