"""Conformance with the repo-wide contracts in ../contracts (single source of truth).

The metadata platform-api sends to Portkey (HTTP proxy and WebSocket chat) must validate
against backend/contracts/metadata.schema.json, be canonically encoded (compact, sorted keys), and
match the golden `platform_api` fixtures byte for byte. Error codes and config values used by
the backend must be documented in / allowed by the contracts.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

import httpx
import pytest
import respx
import yaml
from fastapi.testclient import TestClient
from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from platform_api.config import ENVIRONMENTS
from platform_api.main import create_app
from platform_api.routes.llm import LlmCall, build_metadata
from platform_api.users import UserProfile, YamlUserDirectory

from conftest import PORTKEY_KEY, PROJECT_ROOT, configured_secrets, make_settings

CONTRACTS = Path(os.environ.get("AIG_CONTRACTS_DIR") or PROJECT_ROOT.parent / "contracts")
if not (CONTRACTS / "metadata.schema.json").is_file():  # e.g. the service copied out of the monorepo
    pytest.skip(f"contracts not found at {CONTRACTS}", allow_module_level=True)

GATEWAY = "http://localhost:8787/v1/chat/completions"
BODY = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]}
COMPLETION = {"id": "x", "object": "chat.completion", "choices": []}
UUID4_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$")
GENERATED = "<generated:uuid4>"
SERVER_SECRET = "<server-secret:PORTKEY_API_KEY>"


def _schemas() -> dict[str, dict]:
    return {p.name: json.loads(p.read_text()) for p in CONTRACTS.glob("*.schema.json")}


SCHEMAS = _schemas()
REGISTRY = Registry().with_resources((s["$id"], Resource.from_contents(s)) for s in SCHEMAS.values())
META = Draft202012Validator(SCHEMAS["metadata.schema.json"], registry=REGISTRY, format_checker=FormatChecker())
META_DEFS = SCHEMAS["metadata.schema.json"]["$defs"]
PORTKEY_HEADERS = Draft202012Validator(
    {"$ref": SCHEMAS["headers.schema.json"]["$id"] + "#/$defs/portkey"}, registry=REGISTRY
)


def canonical(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def assert_metadata_conforms(raw: str) -> dict:
    meta = json.loads(raw)
    errors = [f"{e.json_path}: {e.message}" for e in META.iter_errors(meta)]
    assert not errors, errors
    assert raw == canonical(meta), "x-portkey-metadata must be compact JSON with sorted keys"
    return meta


def fixtures(kind: str) -> list[dict]:
    out = []
    for p in sorted((CONTRACTS / "fixtures").glob("*.json")):
        fx = json.loads(p.read_text())
        if fx["kind"] == kind:
            out.append(fx)
    return out


PLATFORM_FIXTURES = fixtures("platform_api")


def test_platform_api_fixtures_exist():
    assert PLATFORM_FIXTURES, "backend/contracts/fixtures has no platform_api cases"


def app_for(server: dict):
    user = server["user"]
    directory = YamlUserDirectory(
        {"users": {user["email"]: {"team": user["team"], "tier": user["tier"]}}}, default_user_tier="standard"
    )
    app = create_app(make_settings(server["env"], "dev"), secrets=configured_secrets(), users=directory)
    env_cfg = app.state.env_config
    env_cfg.portkey_config_id = server.get("config_id", env_cfg.portkey_config_id)
    if server.get("allowed_job_profiles"):
        env_cfg.allowed_job_profiles = list(server["allowed_job_profiles"])
    return app


def assert_matches_expected(sent_headers, expected: dict, *, trace_generated: bool = False) -> None:
    exp = expected["portkey_headers"]
    assert sent_headers["x-portkey-api-key"] == (PORTKEY_KEY if exp["x-portkey-api-key"] == SERVER_SECRET else exp["x-portkey-api-key"])
    assert sent_headers["x-portkey-config"] == exp["x-portkey-config"]
    assert sent_headers["x-portkey-metadata"] == exp["x-portkey-metadata"]  # byte-identical
    assert_metadata_conforms(sent_headers["x-portkey-metadata"])
    trace = sent_headers["x-portkey-trace-id"]
    if trace_generated or exp["x-portkey-trace-id"] == GENERATED:
        assert UUID4_RE.match(trace), trace
    else:
        assert trace == exp["x-portkey-trace-id"]
    contract_headers = {k: sent_headers[k] for k in exp}
    assert not list(PORTKEY_HEADERS.iter_errors(contract_headers))


@pytest.mark.parametrize("fx", PLATFORM_FIXTURES, ids=[f["name"] for f in PLATFORM_FIXTURES])
def test_http_proxy_matches_golden_fixture(fx):
    server, req = fx["input"]["server"], fx["input"].get("request_headers", {})
    if server["env"] != "local":
        pytest.skip("fixture runner uses dev auth, which only exists in AIG_ENV=local")
    with respx.mock(assert_all_called=False) as gw, TestClient(app_for(server)) as client:
        route = gw.post(GATEWAY).mock(return_value=httpx.Response(200, json=COMPLETION))
        r = client.post(
            "/api/v1/llm/chat/completions",
            json=BODY,
            headers={**req, "Authorization": f"Bearer dev:{server['user']['email']}"},
        )
        if "error" in fx["expected"]:
            err = fx["expected"]["error"]
            assert r.status_code == err.get("http_status", r.status_code)
            assert r.json()["error"]["code"] == err["code"]
            assert not route.called
            return
        assert r.status_code == 200
        assert_matches_expected(route.calls.last.request.headers, fx["expected"])


@pytest.mark.parametrize("fx", PLATFORM_FIXTURES, ids=[f["name"] for f in PLATFORM_FIXTURES])
def test_ws_chat_matches_golden_fixture(fx):
    server, req = fx["input"]["server"], fx["input"].get("request_headers", {})
    if server["env"] != "local":
        pytest.skip("fixture runner uses dev auth, which only exists in AIG_ENV=local")
    frame = {"type": "chat", "id": "c-1", "messages": BODY["messages"]}
    if "x-aig-job-profile" in req:
        frame["job_profile"] = req["x-aig-job-profile"]
    if "x-aig-agent-id" in req:
        frame["agent_id"] = req["x-aig-agent-id"]
    sse = b'data: {"choices":[{"index":0,"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n'
    with respx.mock(assert_all_called=False) as gw, TestClient(app_for(server)) as client:
        route = gw.post(GATEWAY).mock(
            return_value=httpx.Response(200, headers={"content-type": "text/event-stream"}, content=sse)
        )
        with client.websocket_connect(
            "/api/v1/ws", headers={"Authorization": f"Bearer dev:{server['user']['email']}"}
        ) as ws:
            assert json.loads(ws.receive_text())["type"] == "ready"
            ws.send_text(json.dumps(frame))
            while True:
                msg = json.loads(ws.receive_text())
                if msg["type"] in ("chat.done", "chat.error"):
                    break
        if "error" in fx["expected"]:
            assert msg["type"] == "chat.error" and msg["code"] == fx["expected"]["error"]["code"]
            assert not route.called
            return
        assert msg["type"] == "chat.done", msg
        # The WebSocket chat frame carries no trace id; the server always generates one.
        assert_matches_expected(route.calls.last.request.headers, fx["expected"], trace_generated=True)


@pytest.mark.parametrize("env", ENVIRONMENTS)
@pytest.mark.parametrize("tier", ["premium", "standard", "free"])
@pytest.mark.parametrize("agent_id", [None, "claims-triage.v2"])
def test_built_metadata_validates_for_every_env_and_tier(env, tier, agent_id):
    profile = UserProfile(email="jane.doe@example.com", name="Jane", team="underwriting-ai", user_tier=tier)
    for job_profile in META_DEFS["job_profile"]["enum"]:
        meta = build_metadata(profile=profile, job_profile=job_profile, agent_id=agent_id, env=env)
        call = LlmCall(
            trace_id="0f8fad5b-d9cb-469f-a165-70867728950e", profile=profile, job_profile=job_profile,
            agent_id=agent_id, metadata=meta, url=GATEWAY, secrets=[], _api_key="k", _config_id="pc-aig-router",
        )
        for stream in (False, True):
            assert_metadata_conforms(call.headers(stream)["x-portkey-metadata"])


def test_backend_environments_are_contract_envs():
    assert set(ENVIRONMENTS) <= set(META_DEFS["env"]["enum"])


@pytest.mark.parametrize("env", ENVIRONMENTS)
def test_environment_yaml_values_are_allowed_by_contract(env):
    cfg = yaml.safe_load((PROJECT_ROOT / "config" / "environments" / f"{env}.yaml").read_text())
    assert set(cfg["allowed_job_profiles"]) <= set(META_DEFS["job_profile"]["enum"])
    assert cfg["default_user_tier"] in META_DEFS["user_tier"]["enum"]
    assert re.match(r"^[A-Za-z0-9._-]{1,128}$", cfg["portkey_config_id"])


def test_example_user_directory_values_are_allowed_by_contract():
    data = yaml.safe_load((PROJECT_ROOT / "config" / "users.example.yaml").read_text())
    team_re = re.compile(META_DEFS["team"]["pattern"])
    assert team_re.match(data["default_team"])
    for email, entry in data["users"].items():
        assert entry["tier"] in META_DEFS["user_tier"]["enum"], email
        assert team_re.match(entry["team"]), email


def test_every_backend_error_code_is_documented():
    documented = (CONTRACTS / "errors.md").read_text()
    src = "\n".join(p.read_text() for p in (PROJECT_ROOT / "src" / "platform_api").rglob("*.py"))
    codes = set(re.findall(r'ApiError\(\s*\d+,\s*"([a-z_]+)"', src))
    codes |= set(re.findall(r'(?:chat_error|_sse_error|usage_error)\([^)]*?"([a-z_]+)"', src))
    codes |= set(re.findall(r'reason="([a-z_]+)"', src))
    codes |= set(re.findall(r'"code":\s*"([a-z_]+)"', src))
    assert codes, "no error codes found in the backend source"
    missing = sorted(c for c in codes if f"`{c}`" not in documented)
    assert not missing, f"undocumented error codes (add them to backend/contracts/errors.md): {missing}"
