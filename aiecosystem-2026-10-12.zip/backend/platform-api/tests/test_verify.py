"""Version verification: health + test invocation + gateway agent-check seen + pluggable trace check."""

from __future__ import annotations

import pytest
from agent_helpers import ADMIN, BOB, CARA, SVC, TestAgent, audit, build_app, register_agent, register_version
from fastapi.testclient import TestClient

VERIFY = "/api/v1/agents/claims-triage/versions/1.0.0/verify"


def gateway_touch(app, agent_id="claims-triage"):
    """Simulates the agent's model call passing Portkey's agent-check webhook."""
    return lambda claims: app.state.agents.touch(agent_id, "agentcore")


@pytest.fixture
def agent():
    return TestAgent()


def test_verify_passes_and_activates_a_draft_on_prod(agent):
    app = build_app(agent=agent)
    agent.on_invoke = gateway_touch(app)
    with TestClient(app) as c:
        register_agent(c)
        register_version(c, headers=BOB)
        assert c.post(VERIFY, headers=CARA).status_code == 403  # owner, admin or service only
        r = c.post(VERIFY, headers=BOB)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["passed"] is True and body["code"] is None and body["activated"] is True
        assert {c_["name"]: c_["status"] for c_ in body["checks"]} == {
            "health": "passed", "invocation": "passed", "gateway": "passed", "trace": "skipped"}
        assert body["version"]["verification_status"] == "passed" and body["version"]["verified_at"]
        trace = next(c_ for c_ in body["checks"] if c_["name"] == "trace")
        assert trace["detail"].startswith("not_configured")
        # The test input came from the schema's examples; the record is a verify invocation.
        assert agent.requests[-1]["body"]["input"] == {"claim_id": "CLM-1"}
        assert agent.claims[-1]["user"] == "bob@example.com"
        rec = c.get(f"/api/v1/invocations/{body['invocation_id']}", headers=BOB).json()
        assert rec["purpose"] == "verify" and rec["status"] == "succeeded"
        assert c.get("/api/v1/agents/claims-triage", headers=BOB).json()["agent"]["lifecycle"] == "active"
        actions = [e["action"] for e in audit(c, entity_id="claims-triage")]
        assert "agent.version.verify" in actions and actions[-1] == "agent.lifecycle"
        # Now in the catalog for the team.
        assert [i["agent"]["agent_id"] for i in c.get("/api/v1/catalog", headers=CARA).json()["items"]] == ["claims-triage"]


def test_verify_fails_without_gateway_traffic(agent):
    with TestClient(build_app(agent=agent)) as c:
        register_agent(c)
        register_version(c, headers=BOB)
        body = c.post(VERIFY, headers=BOB, json={"input": {"claim_id": "X-1"}}).json()
        assert body["passed"] is False and body["code"] == "verification_failed" and body["activated"] is False
        gateway = next(c_ for c_ in body["checks"] if c_["name"] == "gateway")
        assert gateway["status"] == "failed" and "agent-check" in gateway["detail"]
        assert body["version"]["verification_status"] == "failed"
        assert agent.requests[-1]["body"]["input"] == {"claim_id": "X-1"}
        assert c.get("/api/v1/agents/claims-triage", headers=BOB).json()["agent"]["lifecycle"] == "draft"


def test_verify_health_and_invocation_failures(agent):
    app = build_app(agent=agent)
    agent.on_invoke = gateway_touch(app)
    agent.ping_status = 503
    with TestClient(app) as c:
        register_agent(c)
        register_version(c, headers=BOB, env="dev")
        body = c.post(VERIFY + "?env=dev", headers=ADMIN, json={"input": {"claim_id": "1", "mode": "fail"}}).json()
        checks = {c_["name"]: c_ for c_ in body["checks"]}
        assert checks["health"]["status"] == "failed" and "503" in checks["health"]["detail"]
        assert checks["invocation"]["status"] == "failed" and checks["invocation"]["detail"].startswith("agent_error")
        assert body["passed"] is False
        # Invalid test input is refused before anything runs.
        r = c.post(VERIFY + "?env=dev", headers=BOB, json={"input": {"nope": 1}})
        assert r.status_code == 400 and r.json()["error"]["code"] == "input_invalid"
        assert c.post("/api/v1/agents/claims-triage/versions/9.9/verify?env=dev", headers=BOB).status_code == 404


def test_trace_check_required_and_pluggable(agent, monkeypatch):
    import sys
    import types

    calls = []

    def check_trace(agent_dict, *, env, version, invocation_id, trace_id, since, fiddler_url, fiddler_api_key):
        calls.append({"agent": agent_dict["agent_id"], "env": env, "trace_id": trace_id, "key": bool(fiddler_api_key)})
        return {"found": True, "detail": "1 span in aig-prod"}

    module = types.ModuleType("aig_test_trace")
    module.check_trace = check_trace
    monkeypatch.setitem(sys.modules, "aig_test_trace", module)

    app = build_app(agent=agent, agent_verify_require_trace=True)
    agent.on_invoke = gateway_touch(app)
    with TestClient(app) as c:
        register_agent(c)
        register_version(c, headers=BOB)
        body = c.post(VERIFY, headers=BOB).json()
        trace = next(c_ for c_ in body["checks"] if c_["name"] == "trace")
        assert body["passed"] is False and trace["status"] == "failed" and "not_configured" in trace["detail"]

    app = build_app(agent=agent, agent_verify_require_trace=True, agent_trace_check="aig_test_trace:check_trace")
    agent.on_invoke = gateway_touch(app)
    with TestClient(app) as c:
        register_agent(c)
        register_version(c, headers=BOB)
        body = c.post(VERIFY, headers=SVC, json={"activate": False}).json()
        assert body["passed"] is True and body["activated"] is False
        assert next(c_ for c_ in body["checks"] if c_["name"] == "trace")["detail"] == "1 span in aig-prod"
        assert calls[-1] == {"agent": "claims-triage", "env": "prod", "trace_id": body["trace_id"], "key": True}
        # Service verification uses the platform identity in the caller token.
        assert agent.claims[-1]["user"] == "verify@platform.aig.internal"


def test_verify_needs_env_when_ambiguous(agent):
    app = build_app(agent=agent)
    with TestClient(app) as c:
        register_agent(c)
        register_version(c, headers=BOB, env="dev")
        register_version(c, headers=BOB, env="stage")
        r = c.post(VERIFY, headers=BOB)
        assert r.status_code == 400 and r.json()["error"]["code"] == "env_required"
