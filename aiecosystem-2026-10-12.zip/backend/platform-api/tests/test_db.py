"""Phase 4 persistence: URL policy (fail closed), Alembic migrations, DB agent registry, CLI."""

from __future__ import annotations

import logging

import pytest
import yaml
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext
from conftest import PROJECT_ROOT, USERS, configured_secrets, make_settings
from fastapi.testclient import TestClient
from platform_api import db as dbmod
from platform_api.agents import BUILTIN_IDS, AgentRecord, AgentRegistryError
from platform_api.agents_db import DbAgentRegistry
from platform_api.db import Base, Database, current_revision, head_revision, make_engine, resolve_database_url, upgrade
from platform_api.errors import StartupError
from platform_api.main import create_app, run
from platform_api.users import YamlUserDirectory

MIGRATIONS = PROJECT_ROOT / "migrations"


@pytest.fixture
def real_db(monkeypatch):
    """Undo conftest's in-memory patch: use the real URL policy and open_database."""
    import platform_api.main as main_module

    monkeypatch.setattr(main_module, "open_database", dbmod.open_database)
    monkeypatch.setattr(main_module, "resolve_database_url", dbmod.resolve_database_url)


# --- URL policy ---------------------------------------------------------------------------------


def test_local_defaults_to_sqlite_file():
    url = resolve_database_url("local", None)
    assert url.startswith("sqlite:///") and url.endswith(".run/platform.db")


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
def test_outside_local_database_url_is_required(env):
    with pytest.raises(StartupError, match="AIG_DATABASE_URL is not set"):
        resolve_database_url(env, None)
    with pytest.raises(StartupError, match="must be a Postgres URL"):
        resolve_database_url(env, "sqlite:////tmp/x.db")
    with pytest.raises(StartupError, match="placeholder"):
        resolve_database_url(env, "postgresql+psycopg://u:__REPLACE_ME_DB_PASSWORD__@db/aig")


def test_postgres_url_uses_psycopg3_and_password_is_hidden():
    url = resolve_database_url("prod", "postgresql://aig:s3cr3t-pw@db.internal:5432/aig")
    assert url.startswith("postgresql+psycopg://")
    assert dbmod.url_password(url) == "s3cr3t-pw"
    assert "s3cr3t-pw" not in dbmod.safe_url(url)


def test_invalid_url_fails_closed():
    with pytest.raises(StartupError, match="not a valid database URL"):
        resolve_database_url("local", "not a url ::")


def test_create_app_outside_local_without_database_url_refuses_to_start(monkeypatch):
    import platform_api.main as main_module

    monkeypatch.setattr(main_module, "open_database", dbmod.open_database)
    monkeypatch.setattr(main_module, "resolve_database_url", dbmod.resolve_database_url)
    monkeypatch.delenv("AIG_DATABASE_URL", raising=False)
    with pytest.raises(StartupError, match="AIG_DATABASE_URL"):
        create_app(make_settings("prod", "oidc"), secrets=configured_secrets(), users=YamlUserDirectory(USERS, "standard"))


def test_database_password_is_redacted_from_logs(monkeypatch, tmp_path, caplog):
    import platform_api.main as main_module

    seen = {}

    def fake_open(settings):
        seen["url"] = settings.database_url
        return Database.in_memory()

    monkeypatch.setattr(main_module, "open_database", fake_open)
    monkeypatch.setattr(main_module, "resolve_database_url", dbmod.resolve_database_url)
    url = "postgresql+psycopg://aig:pw-SUPERSECRET-db@db.internal/aig"
    create_app(make_settings("prod", "oidc", database_url=url), secrets=configured_secrets(),
               users=YamlUserDirectory(USERS, "standard"))
    caplog.set_level(logging.INFO)
    logging.getLogger("platform_api").info("oops %s", seen["url"])
    assert "pw-SUPERSECRET-db" not in caplog.text


# --- migrations ---------------------------------------------------------------------------------


def test_migrations_match_the_models(tmp_path):
    engine = make_engine(f"sqlite:///{tmp_path / 'm.db'}")
    upgrade(engine, MIGRATIONS)
    assert current_revision(engine) == head_revision(MIGRATIONS)
    with engine.connect() as conn:
        diff = compare_metadata(MigrationContext.configure(conn), Base.metadata)
    assert diff == [], f"models and migrations differ; add a migration: {diff}"


def test_local_open_database_migrates_a_file(tmp_path):
    settings = make_settings("local", "dev", database_url=f"sqlite:///{tmp_path / 'p.db'}")
    database = dbmod.open_database(settings)
    assert current_revision(database.engine) == head_revision(MIGRATIONS)
    assert database.ping()


def test_schema_not_at_head_refuses_to_start_without_auto_migrate(tmp_path):
    settings = make_settings("local", "dev", database_url=f"sqlite:///{tmp_path / 'e.db'}", db_auto_migrate=False)
    with pytest.raises(StartupError, match="db upgrade"):
        dbmod.open_database(settings)


def test_cli_db_upgrade_and_agents_import(tmp_path, monkeypatch, capsys, real_db):
    db_file = tmp_path / "cli.db"
    monkeypatch.setenv("AIG_ENV", "local")
    monkeypatch.setenv("AIG_DATABASE_URL", f"sqlite:///{db_file}")
    assert run(["db", "upgrade"]) == 0
    assert f"upgraded to {head_revision(MIGRATIONS)}" in capsys.readouterr().out
    assert run(["db", "current"]) == 0
    reg_file = tmp_path / "agents.yaml"
    reg_file.write_text(yaml.safe_dump({"agents": {
        "cli-agent": {"owner": "o@example.com", "team": "t1", "status": "active", "name": "CLI agent"},
        "old-bot": {"owner": "o@example.com", "team": "t1", "status": "suspended"},
    }}))
    assert run(["agents", "import", str(reg_file)]) == 0
    assert "2 created" in capsys.readouterr().out
    assert run(["agents", "import", str(reg_file)]) == 0
    assert "2 skipped" in capsys.readouterr().out
    registry = DbAgentRegistry(Database(make_engine(f"sqlite:///{db_file}")))
    assert registry.get("cli-agent").name == "CLI agent"
    assert registry.get("old-bot").status == "suspended"
    assert BUILTIN_IDS <= {a.agent_id for a in registry.all()}
    assert run(["agents", "import", str(tmp_path / "missing.yaml")]) == 2


def test_cli_fails_closed_outside_local_without_url(monkeypatch, capsys, real_db):
    monkeypatch.setenv("AIG_ENV", "prod")
    monkeypatch.delenv("AIG_DATABASE_URL", raising=False)
    assert run(["db", "upgrade"]) == 1
    assert "AIG_DATABASE_URL" in capsys.readouterr().err


# --- database agent registry ----------------------------------------------------------------------


def test_db_registry_register_status_update_touch():
    registry = DbAgentRegistry(Database.in_memory())
    registry.ensure_builtins()
    assert registry.get("ide.vscode").builtin and registry.get("ide.vscode").shared
    rec = registry.register(AgentRecord(agent_id="a1", owner="o@example.com", team="t1", name="A one"))
    assert rec.created_at and rec.updated_at and rec.status == "active"
    with pytest.raises(AgentRegistryError) as exc:
        registry.register(AgentRecord(agent_id="a1", owner="o@example.com", team="t1"))
    assert exc.value.code == "agent_exists"
    with pytest.raises(AgentRegistryError):
        registry.register(AgentRecord(agent_id="bad id", owner="o@example.com", team="t1"))
    s = registry.set_status("a1", "suspended", "reconciliation: no traces")
    assert s.status == "suspended" and s.status_changed_at
    again = registry.set_status("a1", "suspended", "other")
    assert again.status_reason == "reconciliation: no traces"  # idempotent
    assert registry.update("a1", name="Renamed", owner="new@example.com").owner == "new@example.com"
    registry.touch("a1", "vscode")
    registry.touch("a1", "laptop")
    registry.touch("a1", "laptop")  # throttled, no duplicate
    got = registry.get("a1")
    assert got.last_seen_at and list(got.hosts_seen) == ["vscode", "laptop"]
    registry.touch("unknown-agent", "vscode")  # no error
    registry.set_fiddler_application_id("a1", "1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    assert registry.get("a1").fiddler_application_id.startswith("1b4e28ba")


def test_registry_is_seeded_once_from_the_yaml_file(tmp_path, monkeypatch):
    import platform_api.main as main_module

    shared = Database.in_memory()
    monkeypatch.setattr(main_module, "open_database", lambda settings: shared)
    f = tmp_path / "agents.yaml"
    f.write_text(yaml.safe_dump({"agents": {"seed.me": {"owner": "o@example.com", "team": "t1", "status": "active"}}}))
    users = YamlUserDirectory(USERS, "standard")
    app = create_app(make_settings("dev", "oidc", agents_file=f), secrets=configured_secrets(), users=users)
    assert app.state.agents.get("seed.me") is not None
    app.state.agents.set_status("seed.me", "suspended", "x")
    # A second start against the same database does not re-import (the DB is the source of truth).
    f.write_text(yaml.safe_dump({"agents": {"other": {"owner": "o@example.com", "team": "t1", "status": "active"}}}))
    app2 = create_app(make_settings("dev", "oidc", agents_file=f), secrets=configured_secrets(), users=users)
    assert app2.state.agents.get("seed.me").status == "suspended"
    assert app2.state.agents.get("other") is None


def test_suspension_survives_restart_with_a_database_file(tmp_path, monkeypatch):
    import platform_api.main as main_module

    url = f"sqlite:///{tmp_path / 'restart.db'}"
    monkeypatch.setattr(main_module, "open_database", dbmod.open_database)
    monkeypatch.setattr(main_module, "resolve_database_url", dbmod.resolve_database_url)
    svc = {"x-aig-service-token": "svc-token-123456"}
    secrets = configured_secrets(PLATFORM_SERVICE_TOKEN="svc-token-123456")
    users = YamlUserDirectory(USERS, "standard")
    with TestClient(create_app(make_settings(database_url=url), secrets=secrets, users=users)) as c:
        r = c.post("/api/v1/agents/uw-quote-assistant/suspend", headers=svc, json={"reason": "no traces"})
        assert r.status_code == 200 and r.json()["changed"] is True
    with TestClient(create_app(make_settings(database_url=url), secrets=secrets, users=users)) as c:
        assert c.get("/api/v1/agents/uw-quote-assistant", headers=svc).json()["agent"]["status"] == "suspended"



@pytest.mark.skipif(not __import__("os").environ.get("AIG_TEST_POSTGRES_URL"),
                    reason="set AIG_TEST_POSTGRES_URL (CI runs a Postgres service) to check the migrations on Postgres")
def test_migrations_on_postgres_match_the_models():
    import os

    url = resolve_database_url("dev", os.environ["AIG_TEST_POSTGRES_URL"])
    engine = make_engine(url)
    try:
        upgrade(engine, MIGRATIONS)
        assert current_revision(engine) == head_revision(MIGRATIONS)
        with engine.connect() as conn:
            assert compare_metadata(MigrationContext.configure(conn), Base.metadata) == []
        registry = DbAgentRegistry(Database(engine))
        registry.ensure_builtins()
        assert registry.get("ide.vscode").builtin
    finally:
        engine.dispose()
