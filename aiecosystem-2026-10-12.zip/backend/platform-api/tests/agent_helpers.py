"""Shared helpers for the registry v2 / invocation tests: a tiny agent server implementing the
aig-http/1 contract (backend/contracts/agent-invocation.md), app builders and API shortcuts."""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Callable

import httpx
import jwt
from conftest import USERS as BASE_USERS
from conftest import configured_secrets, dev_auth, make_settings
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.testclient import TestClient

from platform_api.main import create_app
from platform_api.users import YamlUserDirectory

SERVICE_TOKEN = "svc-SUPERSECRET-5566778899aabb"
SVC = {"x-aig-service-token": SERVICE_TOKEN}
AGENT_API_KEY = "agentkey-SUPERSECRET-0011223344"
ENDPOINT = "https://claims-triage.agents.test"

USERS = {
    "default_team": "unassigned",
    "users": {
        **BASE_USERS["users"],
        "bob@example.com": {"name": "Bob", "team": "claims-ai", "tier": "standard"},
        "cara@example.com": {"name": "Cara Claims", "team": "claims-ai", "tier": "premium"},
        "gina@example.com": {"name": "Gina Group", "team": "finance-ai", "tier": "standard", "groups": ["UW-Analysts"]},
        "olga@example.com": {"name": "Olga Other", "team": "ops-ai", "tier": "free"},
    },
}
BOB, CARA, GINA, OLGA, JANE = (dev_auth(e) for e in (
    "bob@example.com", "cara@example.com", "gina@example.com", "olga@example.com", "jane@example.com"))
ADMIN = dev_auth("admin@example.com")

INPUT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["claim_id"],
    "properties": {"claim_id": {"type": "string"}, "mode": {"enum": ["echo", "stream", "slow", "fail", "deny"]},
                   "notes": {"type": "string"}},
    "examples": [{"claim_id": "CLM-1"}],
}


def ec_pem() -> str:
    key = ec.generate_private_key(ec.SECP256R1())
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption()).decode()


class TestAgent:
    """An agent server implementing aig-http/1. Verifies the caller token like a real agent (ES256,
    aud == its agent id), records every request, and behaves per ``input.mode``."""

    __test__ = False

    def __init__(self, agent_id: str = "claims-triage", jwks_getter: Callable[[], dict] | None = None):
        self.agent_id = agent_id
        self.jwks_getter = jwks_getter
        self.requests: list[dict] = []
        self.claims: list[dict] = []
        self.on_invoke: Callable[[dict], Any] | None = None
        self.ping_status = 200
        self.app = self._build()

    def verify(self, token: str) -> dict:
        jwks = self.jwks_getter() if self.jwks_getter else None
        if not jwks:
            raise jwt.InvalidTokenError("no jwks")
        header = jwt.get_unverified_header(token)
        key = next(k for k in jwks["keys"] if k["kid"] == header["kid"])
        return jwt.decode(token, jwt.PyJWK(key).key, algorithms=["ES256"], audience=self.agent_id, leeway=60)

    def _build(self) -> FastAPI:
        app = FastAPI()

        @app.get("/ping")
        async def ping():
            return JSONResponse({"status": "Healthy"}, status_code=self.ping_status)

        @app.post("/invocations")
        async def invocations(request: Request):
            body = await request.json()
            headers = dict(request.headers)
            self.requests.append({"headers": headers, "body": body})
            token = headers.get("x-aig-caller") or (body.get("aig_context") or {}).get("caller")
            try:
                claims = self.verify(token or "")
            except Exception:
                return JSONResponse({"error": {"code": "caller_unauthenticated", "message": "bad caller token"}},
                                    status_code=401)
            self.claims.append(claims)
            if self.on_invoke is not None:
                self.on_invoke(claims)
            inp = body.get("input") or {}
            mode = inp.get("mode", "echo")
            usage = {"prompt_tokens": 11, "completion_tokens": 7, "total_tokens": 18}
            output = {"claim_id": inp.get("claim_id"), "user": claims["user"], "team": claims["team"],
                      "groups": claims["groups"], "messages": len(body.get("messages") or [])}
            if mode == "fail":
                return JSONResponse({"error": {"code": "internal", "message": "model call failed"}}, status_code=500)
            if mode == "deny":
                return JSONResponse({"error": {"code": "input_invalid", "message": "unknown claim"}}, status_code=400)
            if mode == "slow":
                await asyncio.sleep(30)
            if body.get("stream"):
                async def gen():
                    for part in ("Severity: ", "HIGH"):
                        yield f"event: delta\ndata: {json.dumps({'text': part})}\n\n"
                    yield f"event: output\ndata: {json.dumps({'output': output, 'usage': usage})}\n\n"
                    yield "event: done\ndata: {}\n\n"
                return StreamingResponse(gen(), media_type="text/event-stream")
            return {"output": output, "usage": usage, "trace_id": headers.get("x-aig-trace-id")}

        return app


def build_app(*, env: str = "local", agent: TestAgent | None = None, secrets: dict | None = None,
              agentcore_client_factory=None, secret_resolver=None, **settings_kw):
    auth_mode = "dev" if env == "local" else "oidc"
    values = {"PLATFORM_SERVICE_TOKEN": SERVICE_TOKEN, **(secrets or {})}
    agent_client = None
    if agent is not None:
        agent_client = httpx.AsyncClient(transport=httpx.ASGITransport(app=agent.app))
    app = create_app(
        make_settings(env, auth_mode, **settings_kw),
        secrets=configured_secrets(**values),
        users=YamlUserDirectory(USERS, "standard"),
        agent_hooks=[],
        agent_http_client=agent_client,
        agentcore_client_factory=agentcore_client_factory,
        secret_resolver=secret_resolver,
    )
    if agent is not None:
        agent.jwks_getter = lambda: app.state.invoker.signer.jwks()
    return app


def register_agent(c: TestClient, agent_id: str = "claims-triage", *, owner_headers=BOB, **body) -> dict:
    r = c.post("/api/v1/agents", headers=owner_headers, json={"agent_id": agent_id, **body})
    assert r.status_code == 201, r.text
    return r.json()["agent"]


def register_version(c: TestClient, agent_id: str = "claims-triage", *, headers=SVC, expect=(200, 201), **body) -> dict:
    payload = {"version": "1.0.0", "env": "prod", "kind": "https", "endpoint": ENDPOINT, "input_schema": INPUT_SCHEMA}
    payload.update(body)
    r = c.post(f"/api/v1/agents/{agent_id}/versions", headers=headers, json=payload)
    assert r.status_code in expect, r.text
    return r.json()


def active_agent(c: TestClient, agent_id: str = "claims-triage", *, version: str = "1.0.0", env: str = "prod",
                 **version_body) -> None:
    """Register a draft agent owned by Bob (claims-ai) plus a deploy-verified version, then activate."""
    register_agent(c, agent_id)
    register_version(c, agent_id, version=version, env=env, verified=True,
                     activate=(env == "prod"), **version_body)
    if env != "prod":
        r = c.post(f"/api/v1/agents/{agent_id}/lifecycle", headers=BOB, json={"to": "active"})
        assert r.status_code == 200, r.text


def audit(c: TestClient, **params) -> list[dict]:
    """Audit entries, oldest first."""
    return list(reversed(c.get("/api/v1/audit", headers=ADMIN, params={"limit": 1000, **params}).json()["items"]))


def wait_for(fn: Callable[[], Any], timeout: float = 5.0, interval: float = 0.05):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        value = fn()
        if value:
            return value
        time.sleep(interval)
    raise AssertionError("condition not met in time")


def parse_sse(text: str) -> list[dict]:
    events, name, data = [], None, []
    for line in text.split("\n") + [""]:
        if line == "":
            if data:
                events.append({"event": name, "data": json.loads("\n".join(data))})
            name, data = None, []
        elif line.startswith(":"):
            continue
        elif line.startswith("event:"):
            name = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].strip())
    return events
