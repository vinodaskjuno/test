"""Callers and role checks (Phase 4).

Two kinds of caller:

- **user**: ``Authorization: Bearer <token>`` (Entra ID JWT, or ``dev:<email>`` in local dev auth).
  Roles come from the user directory (``roles``: ``user`` | ``admin`` | ``approver``; default
  ``[user]``).
- **service**: ``x-aig-service-token: <PLATFORM_SERVICE_TOKEN>`` (compared in constant time). Acts
  as the role ``service``. Used by telemetry-bridge, fiddler-sync, the evals gate and the workspace
  orchestrator. Without the secret every service call answers ``503 service_token_not_configured``
  (in every env: machine actions never run unauthenticated).

A request that carries the service header is always treated as a service call (a wrong token is
``401 service_unauthenticated``, never a fallback to the bearer token). Missing roles give
``403 forbidden``.
"""

from __future__ import annotations

import hmac
from dataclasses import dataclass, field
from typing import Literal

from fastapi import Depends, Request, Security
from fastapi.security import APIKeyHeader, HTTPBearer

from .auth import principal_from_header
from .errors import ApiError
from .users import UserProfile

SERVICE_HEADER = "x-aig-service-token"
SERVICE_SECRET = "PLATFORM_SERVICE_TOKEN"
SERVICE_ROLE = "service"

# Declared only so the OpenAPI document shows both schemes; the headers are parsed below.
_bearer_scheme = HTTPBearer(auto_error=False, description="Entra ID access token (local: dev:<email>)")
_service_scheme = APIKeyHeader(name=SERVICE_HEADER, auto_error=False, description="PLATFORM_SERVICE_TOKEN (machine callers)")


@dataclass(frozen=True)
class Caller:
    kind: Literal["user", "service"]
    email: str  # "service" for the service token
    roles: frozenset[str] = field(default_factory=frozenset)
    name: str | None = None
    team: str | None = None
    profile: UserProfile | None = None
    # Entra group claims of the token merged with the directory's groups (registry v2 access).
    groups: frozenset[str] = field(default_factory=frozenset)

    def has(self, *roles: str) -> bool:
        return any(r in self.roles for r in roles)

    @property
    def is_service(self) -> bool:
        return self.kind == "service"

    @property
    def is_admin(self) -> bool:
        return "admin" in self.roles


def service_auth(request: Request) -> None:
    expected = request.app.state.secrets.get(SERVICE_SECRET)
    if not expected:
        raise ApiError(503, "service_token_not_configured", f"{SERVICE_SECRET} is not configured on the backend")
    supplied = request.headers.get(SERVICE_HEADER) or ""
    if not hmac.compare_digest(supplied.encode(), expected.encode()):
        raise ApiError(401, "service_unauthenticated", "missing or invalid service token")


def user_caller(state, principal) -> Caller:
    """Caller for an authenticated user principal (HTTP and WebSocket)."""
    profile = state.users.lookup(principal.email, principal.name)
    groups = frozenset(getattr(principal, "groups", ()) or ()) | frozenset(getattr(profile, "groups", ()) or ())
    return Caller(kind="user", email=principal.email, roles=frozenset(getattr(profile, "roles", ("user",))),
                  name=profile.name, team=profile.team, profile=profile, groups=groups)


def resolve_caller(request: Request) -> Caller:
    state = request.app.state
    if SERVICE_HEADER in request.headers:
        service_auth(request)
        return Caller(kind="service", email="service", roles=frozenset({SERVICE_ROLE}))
    principal = principal_from_header(state.authenticator, request.headers.get("authorization"))
    return user_caller(state, principal)


async def get_caller(
    request: Request,
    _bearer=Security(_bearer_scheme),
    _service=Security(_service_scheme),
) -> Caller:
    """User (Bearer) or service (x-aig-service-token) caller."""
    return resolve_caller(request)


async def get_user(request: Request, _bearer=Security(_bearer_scheme)) -> Caller:
    """Bearer-token users only (the service token is not accepted)."""
    state = request.app.state
    principal = principal_from_header(state.authenticator, request.headers.get("authorization"))
    return user_caller(state, principal)


async def get_service(request: Request, _service=Security(_service_scheme)) -> Caller:
    """Service token only."""
    service_auth(request)
    return Caller(kind="service", email="service", roles=frozenset({SERVICE_ROLE}))


def forbidden(message: str = "this action needs another role") -> ApiError:
    return ApiError(403, "forbidden", message)


def require_roles(*roles: str):
    """Dependency: caller (user or service) must hold one of ``roles`` (``service`` = service token)."""

    async def dep(caller: Caller = Depends(get_caller)) -> Caller:
        if not caller.has(*roles):
            raise forbidden(f"requires role {' or '.join(roles)}")
        return caller

    return dep
