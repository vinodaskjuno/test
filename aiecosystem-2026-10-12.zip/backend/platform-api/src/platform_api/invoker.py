"""Agent invocation (registry v2, backend/contracts/agent-invocation.md).

Flow for every surface (HTTP sync / SSE stream / background, WebSocket ``agent.invoke``, verify):

1. ``Invoker.prepare`` (no side effects): agent exists, caller may run it (owner, team, allowed
   Entra groups, org-wide after approval), status/lifecycle allow it, a version is selected
   (users: newest verified prod version; owner/team may pick dev/stage/local, verified or not),
   the body is validated (exactly one of input/messages; ``input`` against the version's
   ``input_schema``). Raises ``InvocationError``.
2. ``Invoker.open``: creates the invocation record (metadata only), writes the audit entry
   ``agent.invoke``, signs the caller token.
3. ``Invoker.run``: async generator of client-facing events (``delta`` / ``output`` / ``error`` /
   ``done``, each with ``invocation_id``). It pumps the transport (``HttpsInvoker`` or
   ``AgentCoreInvoker``) in an inner task, enforces the mode's timeout, honours cancellation
   (``Invoker.cancel``, a closed client connection), redacts platform secrets from everything it
   yields and closes the record (usage, status, error code; encrypted output for background runs).

``BackgroundRunner`` runs background invocations as app-level asyncio tasks (they survive the
client disconnecting) and pushes ``agent.invocation.status`` frames to the caller's WebSockets.

Inputs, outputs, caller tokens and agent credentials are never logged.
"""

from __future__ import annotations

import asyncio
import contextvars
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable, Protocol

import httpx
from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError

from .agent_secrets import AgentAuthenticator, AgentAuthError
from .agents import BUILTIN_IDS, PLATFORM_TEAM, AgentRecord, AgentVersion
from .caller_token import CallerIdentity, CallerTokenSigner
from .db import add_audit
from .errors import ApiError
from .invocations import Invocation, InvocationStore, OutputCipher
from .redaction import TextRedactor
from .routes.llm import TRACE_ID_RE, redact_text

log = logging.getLogger(__name__)

MODES = ("sync", "stream", "background")
ENV_ORDER = ("prod", "stage", "dev", "local")
CLIENT_BODY_KEYS = frozenset({"input", "messages", "session_id", "stream"})
MESSAGE_ROLES = ("system", "user", "assistant", "tool", "developer")
SESSION_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
MAX_MESSAGES = 200
MAX_ERROR_MESSAGE = 500
VERIFY_IDENTITY = CallerIdentity(email="verify@platform.aig.internal", name="AIG platform verification",
                                 team=PLATFORM_TEAM, tier="standard")
AGENTCORE_HEADER_PREFIX = "X-Amzn-Bedrock-AgentCore-Runtime-Custom-"


class InvocationError(Exception):
    """A refused or failed invocation (``code`` from errors.md, ``status`` = HTTP status)."""

    def __init__(self, code: str, status: int, message: str = ""):
        super().__init__(code)
        self.code = code
        self.status = status
        self.message = (message or code.replace("_", " "))[:MAX_ERROR_MESSAGE]

    def api_error(self, headers: dict[str, str] | None = None) -> ApiError:
        return ApiError(self.status, self.code, self.message, headers)


# --- access, lifecycle, version selection, input validation (pure) ------------------------------


def is_team_member(agent: AgentRecord, caller: Any) -> bool:
    email = (getattr(caller, "email", "") or "").lower()
    return bool(email) and (agent.owner.lower() == email or (bool(caller.team) and caller.team == agent.team))


def access_denial(agent: AgentRecord, caller: Any) -> str | None:
    """None when the caller may run the agent, else ``agent_forbidden`` / ``org_approval_required``.
    Admins get no bypass: platform administration is not data access."""
    if is_team_member(agent, caller):
        return None
    groups = set(getattr(caller, "groups", ()) or ())
    if agent.visibility in ("groups", "org") and groups & set(agent.allowed_groups):
        return None
    if agent.visibility == "org":
        return None if agent.org_approval == "approved" else "org_approval_required"
    return "agent_forbidden"


def lifecycle_denial(agent: AgentRecord, *, team: bool) -> str | None:
    if agent.builtin or agent.agent_id in BUILTIN_IDS:
        return "built-in agents are not invocable"
    if not agent.active:
        return "agent is suspended"
    if agent.lifecycle == "retired":
        return "agent is retired"
    if agent.lifecycle == "draft" and not team:
        return "agent is a draft; only its owner and team may run it"
    return None


def select_version(agent: AgentRecord, versions: list[AgentVersion], *, team: bool, platform_env: str,
                   env: str | None = None, version: str | None = None, allow_unverified: bool = False) -> AgentVersion:
    """Pick the version to run. Users: prod only, verified only. Owner/team: any env (``local``
    only when platform-api itself runs in local), unverified allowed outside prod. Drafts never
    run in prod. Without ``env`` the first env in prod, stage, dev, local with a usable version wins."""
    if env is not None and env != "prod" and not team and not allow_unverified:
        raise InvocationError("agent_forbidden", 403, "only the agent's owner and team may run non-prod versions")
    envs = [env] if env else list(ENV_ORDER)
    found_unverified = False
    for e in envs:
        if e != "prod" and not (team or allow_unverified):
            continue
        if e == "local" and platform_env != "local":
            continue
        if e == "prod" and agent.lifecycle == "draft" and not allow_unverified:
            continue
        candidates = [v for v in versions if v.env == e and v.usable and (version is None or v.version == version)]
        need_verified = not allow_unverified and (e == "prod" or not team)
        usable = [v for v in candidates if v.verified] if need_verified else candidates
        if usable:
            return usable[0]
        found_unverified = found_unverified or bool(candidates)
    if version is not None and not found_unverified:
        raise InvocationError("version_not_found", 404, f"version {version!r} is not registered"
                              + (f" in {env}" if env else ""))
    if env == "prod" and agent.lifecycle == "draft":
        raise InvocationError("agent_not_invocable", 409, "draft agents do not run in prod; activate the agent first")
    if found_unverified:
        raise InvocationError("agent_not_invocable", 409, "no verified version is available (run verification)")
    raise InvocationError("agent_not_invocable", 409, "no usable version is registered"
                          + (f" in {env}" if env else ""))


def _error_field(error) -> str:
    path = ["input", *[str(p) for p in error.absolute_path]]
    if error.validator == "required" and isinstance(error.instance, dict):
        missing = [p for p in error.validator_value if p not in error.instance]
        if missing:
            path.append(str(missing[0]))
    elif error.validator == "additionalProperties" and isinstance(error.instance, dict):
        allowed = set((error.schema or {}).get("properties", {}))
        extra = sorted(k for k in error.instance if k not in allowed)
        if extra:
            path.append(extra[0])
    return ".".join(path)


def validate_body(body: Any, input_schema: dict | None) -> dict[str, Any]:
    """Client invoke body -> agent body (without ``stream``). Same rules as reference.py."""
    if not isinstance(body, dict):
        raise InvocationError("input_invalid", 400, "body must be a JSON object")
    unknown = sorted(k for k in body if k not in CLIENT_BODY_KEYS)
    if unknown:
        raise InvocationError("input_invalid", 400, f"{unknown[0]}: unknown field (allowed: input, messages, session_id, stream)")
    has_input, has_messages = body.get("input") is not None, body.get("messages") is not None
    if has_input == has_messages:
        raise InvocationError("input_invalid", 400, "input: give exactly one of input or messages")
    out: dict[str, Any] = {}
    if has_input:
        if not isinstance(body["input"], dict):
            raise InvocationError("input_invalid", 400, "input: must be an object")
        if input_schema:
            errors = sorted(Draft202012Validator(input_schema).iter_errors(body["input"]),
                            key=lambda e: [str(p) for p in e.absolute_path])
            if errors:
                first = errors[0]
                raise InvocationError("input_invalid", 400, f"{_error_field(first)}: {first.message}"[:MAX_ERROR_MESSAGE])
        out["input"] = body["input"]
    else:
        msgs = body["messages"]
        if not isinstance(msgs, list) or not 1 <= len(msgs) <= MAX_MESSAGES:
            raise InvocationError("input_invalid", 400, f"messages: must be an array of 1..{MAX_MESSAGES} messages")
        for i, m in enumerate(msgs):
            if not isinstance(m, dict) or m.get("role") not in MESSAGE_ROLES or not isinstance(m.get("content"), (str, list)):
                raise InvocationError("input_invalid", 400, f"messages.{i}: needs a role in {list(MESSAGE_ROLES)} and content")
        out["messages"] = [{"role": m["role"], "content": m["content"]} for m in msgs]
    if body.get("session_id") is not None:
        if not isinstance(body["session_id"], str) or not SESSION_ID_RE.match(body["session_id"]):
            raise InvocationError("input_invalid", 400, "session_id: must match [A-Za-z0-9._:-]{1,128}")
        out["session_id"] = body["session_id"]
    if body.get("stream") is not None and not isinstance(body["stream"], bool):
        raise InvocationError("input_invalid", 400, "stream: must be a boolean")
    return out


def check_json_schema(schema: Any) -> str | None:
    """None when ``schema`` is a usable Draft 2020-12 schema object, else the problem."""
    if schema is None:
        return None
    if not isinstance(schema, dict):
        return "must be a JSON Schema object"
    try:
        Draft202012Validator.check_schema(schema)
    except SchemaError as exc:
        return f"invalid JSON Schema: {exc.message}"[:300]
    return None


def runtime_session_id(agent_id: str, user: str, session_id: str | None, invocation_id: str) -> str:
    import hashlib

    if session_id is None:
        return f"aig-inv-{invocation_id}"
    return "aig-" + hashlib.sha256(f"{agent_id}\n{user}\n{session_id}".encode()).hexdigest()


# --- transport layer ----------------------------------------------------------------------------


@dataclass
class AgentEvent:
    kind: str  # delta | output | error | done
    data: dict


@dataclass
class AgentCall:
    agent_id: str
    version: AgentVersion
    body: dict
    headers: dict[str, str]
    caller_token: str = field(repr=False)
    invocation_id: str = ""
    trace_id: str = ""
    stream: bool = False
    runtime_session_id: str = ""


class Transport(Protocol):
    def events(self, call: AgentCall) -> AsyncIterator[AgentEvent]: ...


AGENT_STATUS_ERRORS = (
    ((400, 400), "input_invalid", 400),
    ((422, 422), "input_invalid", 400),
    ((408, 408), "invocation_timeout", 504),
    ((504, 504), "invocation_timeout", 504),
    ((401, 404), "agent_unavailable", 502),
    ((429, 429), "agent_unavailable", 503),
    ((405, 499), "agent_error", 502),
    ((500, 599), "agent_error", 502),
)


def error_for_status(status: int, body: Any) -> InvocationError:
    code, http_status = "agent_error", 502
    for (lo, hi), c, h in AGENT_STATUS_ERRORS:
        if lo <= status <= hi:
            code, http_status = c, h
            break
    err = body.get("error") if isinstance(body, dict) else None
    message = err.get("message") if isinstance(err, dict) and isinstance(err.get("message"), str) else None
    return InvocationError(code, http_status, message or f"agent answered HTTP {status}")


def usage_of(obj: Any) -> dict[str, int] | None:
    if not isinstance(obj, dict):
        return None
    out = {k: obj[k] for k in ("prompt_tokens", "completion_tokens", "total_tokens")
           if isinstance(obj.get(k), int) and not isinstance(obj.get(k), bool) and obj[k] >= 0}
    return out or None


def json_result_events(body: Any) -> list[AgentEvent]:
    if not isinstance(body, dict) or "output" not in body:
        raise InvocationError("agent_error", 502, "agent response has no output")
    data: dict[str, Any] = {"output": body["output"]}
    if usage_of(body.get("usage")):
        data["usage"] = usage_of(body.get("usage"))
    if isinstance(body.get("trace_id"), str):
        data["trace_id"] = body["trace_id"]
    return [AgentEvent("output", data), AgentEvent("done", {})]


class SseParser:
    """Incremental SSE parser (contract framing; same rules as reference.parse_sse)."""

    NAMES = ("delta", "output", "error", "done")

    def __init__(self, max_event_bytes: int):
        self.max = max_event_bytes
        self.name: str | None = None
        self.data: list[str] = []
        self.size = 0

    def line(self, line: str) -> AgentEvent | None:
        line = line.rstrip("\r")
        if line == "":
            return self._dispatch()
        if line.startswith(":"):
            return None
        fld, _, value = line.partition(":")
        value = value[1:] if value.startswith(" ") else value
        if fld == "event":
            self.name = value
        elif fld == "data":
            self.size += len(value)
            if self.size > self.max:
                raise InvocationError("agent_error", 502, "agent stream event exceeds the size limit")
            self.data.append(value)
        return None

    def _dispatch(self) -> AgentEvent | None:
        name, data = self.name or "message", self.data
        self.name, self.data, self.size = None, [], 0
        if not data or name not in self.NAMES:
            return None
        try:
            payload = json.loads("\n".join(data))
        except ValueError:
            return None
        return AgentEvent(name, payload) if isinstance(payload, dict) else None

    def close(self) -> AgentEvent | None:
        return self._dispatch()


async def _read_limited(resp: httpx.Response, limit: int) -> bytes:
    raw = b""
    async for chunk in resp.aiter_bytes():
        raw += chunk
        if len(raw) > limit:
            raise InvocationError("agent_error", 502, "agent response exceeds the size limit")
    return raw


class HttpsInvoker:
    """kind ``https``: POST {endpoint}/invocations with httpx; SSE passthrough parsing."""

    def __init__(self, client_getter: Callable[[], httpx.AsyncClient], authenticator: AgentAuthenticator, *,
                 connect_timeout: float = 10.0, max_bytes: int = 4 * 1024 * 1024):
        self._client = client_getter
        self.authenticator = authenticator
        self.connect_timeout = connect_timeout
        self.max_bytes = max_bytes

    def _timeout(self) -> httpx.Timeout:
        # Read timeout is unbounded here: Invoker.run enforces the mode's overall deadline.
        return httpx.Timeout(connect=self.connect_timeout, read=None, write=30.0, pool=self.connect_timeout)

    async def _auth_headers(self, version: AgentVersion) -> dict[str, str]:
        try:
            return await self.authenticator.headers(version.auth, self._client(), timeout=self.connect_timeout)
        except AgentAuthError as exc:
            log.warning("agent credentials unavailable for %s %s: %s", version.agent_id, version.env, exc)
            raise InvocationError("agent_unavailable", 502, "platform-api could not obtain the agent's credentials") from None

    async def events(self, call: AgentCall) -> AsyncIterator[AgentEvent]:
        version = call.version
        url = (version.endpoint or "").rstrip("/") + "/invocations"
        headers = {**call.headers, **(await self._auth_headers(version))}
        client = self._client()
        try:
            req = client.build_request("POST", url, headers=headers, content=json.dumps(call.body).encode(),
                                       timeout=self._timeout())
            resp = await client.send(req, stream=True, follow_redirects=False)
        except httpx.TimeoutException:
            raise InvocationError("agent_unavailable", 502, "agent did not accept the connection in time") from None
        except httpx.HTTPError as exc:
            log.warning("agent %s unreachable: %s", call.agent_id, type(exc).__name__)
            raise InvocationError("agent_unavailable", 502, "agent server unreachable") from None
        try:
            if resp.status_code >= 300:
                raw = await _read_limited(resp, 64 * 1024)
                try:
                    body = json.loads(raw) if raw else None
                except ValueError:
                    body = None
                raise error_for_status(resp.status_code, body)
            ctype = resp.headers.get("content-type", "")
            if "text/event-stream" in ctype:
                parser = SseParser(self.max_bytes)
                async for line in resp.aiter_lines():
                    event = parser.line(line)
                    if event is not None:
                        yield event
                tail = parser.close()
                if tail is not None:
                    yield tail
                return
            raw = await _read_limited(resp, self.max_bytes)
            try:
                body = json.loads(raw)
            except ValueError:
                raise InvocationError("agent_error", 502, "agent response is not JSON") from None
            for event in json_result_events(body):
                yield event
        except (httpx.ReadError, httpx.RemoteProtocolError) as exc:
            log.warning("agent %s stream interrupted: %s", call.agent_id, type(exc).__name__)
            raise InvocationError("agent_error", 502, "agent stream was interrupted") from None
        finally:
            await resp.aclose()

    async def ping(self, version: AgentVersion) -> tuple[bool, str]:
        url = (version.endpoint or "").rstrip("/") + "/ping"
        try:
            headers = await self._auth_headers(version)
            resp = await self._client().get(url, headers=headers, timeout=self.connect_timeout, follow_redirects=False)
        except InvocationError as exc:
            return False, exc.message
        except httpx.HTTPError as exc:
            return False, f"GET /ping failed ({type(exc).__name__})"
        if 200 <= resp.status_code < 300:
            return True, f"GET /ping answered {resp.status_code}"
        return False, f"GET /ping answered {resp.status_code}"


_AGENTCORE_HEADERS: contextvars.ContextVar[dict[str, str] | None] = contextvars.ContextVar("aig_agentcore_headers",
                                                                                             default=None)

AGENTCORE_ERRORS = {
    "ResourceNotFoundException": ("agent_unavailable", 502, "AgentCore runtime not found"),
    "AccessDeniedException": ("agent_unavailable", 502, "platform-api may not invoke this AgentCore runtime"),
    "ThrottlingException": ("agent_unavailable", 503, "AgentCore throttled the invocation"),
    "ServiceQuotaExceededException": ("agent_unavailable", 503, "AgentCore quota exceeded"),
    "RetryableConflictException": ("agent_unavailable", 503, "AgentCore session busy; retry"),
    "ValidationException": ("agent_error", 502, "AgentCore rejected the request"),
    "RuntimeClientError": ("agent_error", 502, "the agent runtime failed"),
    "InternalServerException": ("agent_error", 502, "AgentCore internal error"),
}


def _add_agentcore_headers(request, **_kwargs) -> None:
    """botocore before-sign hook: the contract headers as allow-listed AgentCore custom headers."""
    for name, value in (_AGENTCORE_HEADERS.get() or {}).items():
        request.headers[name] = value


class AgentCoreInvoker:
    """kind ``agentcore``: ``bedrock-agentcore`` ``invoke_agent_runtime`` with platform-api's IAM
    role (SigV4). boto3 is blocking, so calls and stream reads run in worker threads."""

    def __init__(self, *, region: str | None = None, read_timeout: float = 900.0, connect_timeout: float = 10.0,
                 max_bytes: int = 4 * 1024 * 1024, client_factory: Callable[[], Any] | None = None):
        self.region = region
        self.read_timeout = read_timeout
        self.connect_timeout = connect_timeout
        self.max_bytes = max_bytes
        self.client_factory = client_factory
        self._client = None

    def client(self):
        if self._client is None:
            if self.client_factory is not None:
                self._client = self.client_factory()
            else:
                import boto3  # lazy: optional dependency (pip install '.[aws]')
                from botocore.config import Config

                cfg = Config(read_timeout=int(self.read_timeout) + 30, connect_timeout=int(self.connect_timeout),
                             retries={"max_attempts": 1, "mode": "standard"})
                self._client = boto3.client("bedrock-agentcore", region_name=self.region, config=cfg)
            try:
                self._client.meta.events.register("before-sign.bedrock-agentcore.InvokeAgentRuntime",
                                                  _add_agentcore_headers)
            except Exception:  # stubbed / fake clients
                pass
        return self._client

    @staticmethod
    def params(call: AgentCall) -> dict[str, Any]:
        params: dict[str, Any] = {
            "agentRuntimeArn": call.version.runtime_arn,
            "contentType": "application/json",
            "accept": "text/event-stream" if call.stream else "application/json",
            "runtimeSessionId": call.runtime_session_id,
            "payload": json.dumps(call.body).encode(),
        }
        if call.version.qualifier:
            params["qualifier"] = call.version.qualifier
        return params

    def _invoke(self, params: dict, headers: dict[str, str]):
        token = _AGENTCORE_HEADERS.set(headers)
        try:
            return self.client().invoke_agent_runtime(**params)
        finally:
            _AGENTCORE_HEADERS.reset(token)

    @staticmethod
    def _map(exc: Exception) -> InvocationError:
        code = getattr(exc, "response", {}).get("Error", {}).get("Code") if hasattr(exc, "response") else None
        if code in AGENTCORE_ERRORS:
            c, s, m = AGENTCORE_ERRORS[code]
            return InvocationError(c, s, m)
        name = type(exc).__name__
        if "Timeout" in name:
            return InvocationError("invocation_timeout", 504, "AgentCore did not answer in time")
        if "Endpoint" in name or "Connect" in name:
            return InvocationError("agent_unavailable", 502, "AgentCore endpoint unreachable")
        return InvocationError("agent_error", 502, f"AgentCore invocation failed ({code or name})")

    async def events(self, call: AgentCall) -> AsyncIterator[AgentEvent]:
        headers = {
            AGENTCORE_HEADER_PREFIX + "Aig-Caller": call.caller_token,
            AGENTCORE_HEADER_PREFIX + "Aig-Invocation-Id": call.invocation_id,
            AGENTCORE_HEADER_PREFIX + "Aig-Trace-Id": call.trace_id,
        }
        try:
            resp = await asyncio.to_thread(self._invoke, self.params(call), headers)
        except InvocationError:
            raise
        except Exception as exc:
            log.warning("agentcore invoke failed for %s: %s", call.agent_id, type(exc).__name__)
            raise self._map(exc) from None
        stream = resp.get("response")
        status = int(resp.get("statusCode") or 200)
        ctype = resp.get("contentType") or ""
        try:
            if status >= 300:
                raw = await asyncio.to_thread(stream.read, 64 * 1024) if stream is not None else b""
                try:
                    body = json.loads(raw) if raw else None
                except ValueError:
                    body = None
                raise error_for_status(status, body)
            if "text/event-stream" in ctype:
                parser = SseParser(self.max_bytes)
                lines = stream.iter_lines(keepends=False)
                while True:
                    line = await asyncio.to_thread(next, lines, None)
                    if line is None:
                        break
                    event = parser.line(line.decode("utf-8", "replace") if isinstance(line, bytes) else line)
                    if event is not None:
                        yield event
                tail = parser.close()
                if tail is not None:
                    yield tail
                return
            raw = await asyncio.to_thread(stream.read, self.max_bytes + 1) if stream is not None else b""
            if len(raw) > self.max_bytes:
                raise InvocationError("agent_error", 502, "agent response exceeds the size limit")
            try:
                body = json.loads(raw)
            except ValueError:
                raise InvocationError("agent_error", 502, "agent response is not JSON") from None
            for event in json_result_events(body):
                yield event
        except InvocationError:
            raise
        except Exception as exc:
            log.warning("agentcore stream failed for %s: %s", call.agent_id, type(exc).__name__)
            raise self._map(exc) from None
        finally:
            if stream is not None:
                try:
                    stream.close()
                except Exception:
                    pass


# --- orchestration ------------------------------------------------------------------------------


@dataclass
class Plan:
    agent: AgentRecord
    version: AgentVersion
    identity: CallerIdentity
    body: dict
    mode: str
    purpose: str
    trace_id: str | None
    timeout: float


@dataclass
class Outcome:
    status: str = "running"
    output: Any = None
    has_output: bool = False
    text: str = ""
    usage: dict | None = None
    error: InvocationError | None = None
    duration_ms: int = 0
    agent_trace_id: str | None = None


@dataclass
class Handle:
    invocation: Invocation
    plan: Plan
    call: AgentCall = field(repr=False)
    cancel_event: asyncio.Event | None = None
    outcome: Outcome = field(default_factory=Outcome)
    pump: asyncio.Task | None = None

    @property
    def id(self) -> str:
        return self.invocation.id


def identity_of(caller: Any) -> CallerIdentity:
    profile = getattr(caller, "profile", None)
    return CallerIdentity(
        email=caller.email, name=(getattr(caller, "name", None) or caller.email)[:200],
        team=getattr(caller, "team", None) or "unassigned",
        tier=getattr(profile, "user_tier", None) or "standard",
        groups=tuple(sorted(getattr(caller, "groups", ()) or ())),
    )


class Invoker:
    def __init__(self, *, settings: Any, registry: Any, versions: Any, store: InvocationStore, db: Any,
                 signer: CallerTokenSigner | None, cipher: OutputCipher | None, https: HttpsInvoker,
                 agentcore: AgentCoreInvoker, secrets_provider: Callable[[], list[str]], disabled_reason: str | None,
                 on_finish: Callable[["Handle"], None] | None = None):
        self.settings = settings
        self.registry = registry
        self.versions = versions
        self.store = store
        self.db = db
        self.signer = signer
        self.cipher = cipher
        self.https = https
        self.agentcore = agentcore
        self._secrets = secrets_provider
        self.disabled_reason = disabled_reason
        self.on_finish = on_finish  # e.g. the telemetry-bridge invocation event (metadata only)
        self.active: dict[str, Handle] = {}

    @property
    def enabled(self) -> bool:
        return self.disabled_reason is None and self.signer is not None

    def transport(self, kind: str) -> Transport:
        return self.agentcore if kind == "agentcore" else self.https

    def timeout_for(self, mode: str) -> float:
        s = self.settings
        return {"sync": s.agent_sync_timeout_seconds, "stream": s.agent_stream_timeout_seconds,
                "background": s.agent_background_timeout_seconds}[mode]

    # -- 1. prepare ------------------------------------------------------------------------------

    def prepare(self, caller: Any, agent_id: str, body: Any, *, env: str | None = None, version: str | None = None,
                mode: str = "sync", trace_id: str | None = None, purpose: str = "invoke") -> Plan:
        if not self.enabled:
            raise InvocationError("agent_invocation_disabled", 503, self.disabled_reason or "agent invocation is disabled")
        if mode not in MODES:
            raise InvocationError("input_invalid", 400, f"mode must be one of {list(MODES)}")
        agent = self.registry.get(agent_id)
        if agent is None:
            raise InvocationError("agent_not_found", 404, f"agent {agent_id!r} is not registered")
        verify = purpose == "verify"
        team = is_team_member(agent, caller)
        if not verify:
            denial = access_denial(agent, caller)
            if denial == "org_approval_required":
                raise InvocationError(denial, 403, "org-wide access to this agent is waiting for platform-admin approval")
            if denial:
                raise InvocationError(denial, 403, "you may not run this agent")
        problem = lifecycle_denial(agent, team=team or verify)
        if problem:
            raise InvocationError("agent_not_invocable", 409, problem)
        if mode == "background" and self.cipher is None:
            raise InvocationError("output_encryption_not_configured", 503,
                                  "AGENT_OUTPUT_ENCRYPTION_KEY is not configured; background runs are refused")
        chosen = select_version(agent, self.versions.list(agent.agent_id, include_retired=False), team=team,
                                platform_env=self.settings.env, env=env, version=version, allow_unverified=verify)
        agent_body = validate_body(body, chosen.input_schema)
        identity = VERIFY_IDENTITY if (verify and getattr(caller, "is_service", False)) else identity_of(caller)
        return Plan(agent=agent, version=chosen, identity=identity, body=agent_body, mode=mode, purpose=purpose,
                    trace_id=trace_id if trace_id and TRACE_ID_RE.match(trace_id) else None,
                    timeout=self.timeout_for(mode))

    # -- 2. open ---------------------------------------------------------------------------------

    def open(self, plan: Plan, *, actor: str | None = None) -> Handle:
        if mode_is_background := plan.mode == "background":
            limit = self.settings.agent_max_background_per_user
            if self.store.count_open(caller=plan.identity.email, mode="background") >= limit:
                raise InvocationError("too_many_requests", 429, f"at most {limit} running background invocations per user")
        invocation_id = str(uuid.uuid4())
        trace_id = plan.trace_id or invocation_id
        v = plan.version
        inv = self.store.create(
            invocation_id=invocation_id, agent_id=plan.agent.agent_id, version=v.version, env=v.env,
            caller=plan.identity.email, team=plan.identity.team, mode=plan.mode, purpose=plan.purpose,
            trace_id=trace_id, session_id=plan.body.get("session_id"),
            status="queued" if mode_is_background else "running",
        )
        try:
            with self.db.session() as s:
                add_audit(s, actor=actor or plan.identity.email, action="agent.invoke", entity_type="agent_invocation",
                          entity_id=invocation_id, details={"agent_id": plan.agent.agent_id, "version": v.version,
                                                            "env": v.env, "mode": plan.mode, "purpose": plan.purpose})
        except Exception as exc:
            log.error("audit write failed for invocation %s: %s", invocation_id, type(exc).__name__)
        stream = plan.mode == "stream"
        body = {**plan.body, "stream": stream}
        token = self.signer.sign(self.signer.claims(  # type: ignore[union-attr]
            plan.identity, agent_id=plan.agent.agent_id, version=v.version, agent_env=v.env,
            invocation_id=invocation_id, trace_id=trace_id))
        headers = {"content-type": "application/json", "accept": "text/event-stream" if stream else "application/json",
                   "x-aig-caller": token, "x-aig-invocation-id": invocation_id, "x-aig-trace-id": trace_id}
        rsid = ""
        if v.kind == "agentcore":
            body["aig_context"] = {"caller": token, "invocation_id": invocation_id, "trace_id": trace_id}
            rsid = runtime_session_id(plan.agent.agent_id, plan.identity.email, plan.body.get("session_id"), invocation_id)
        call = AgentCall(agent_id=plan.agent.agent_id, version=v, body=body, headers=headers, caller_token=token,
                         invocation_id=invocation_id, trace_id=trace_id, stream=stream, runtime_session_id=rsid)
        log.info("agent invoke %s agent=%s version=%s env=%s mode=%s purpose=%s", invocation_id,
                 plan.agent.agent_id, v.version, v.env, plan.mode, plan.purpose)
        return Handle(invocation=inv, plan=plan, call=call)

    # -- 3. run ----------------------------------------------------------------------------------

    def _redact_value(self, value: Any, secrets: list[str]) -> Any:
        if not secrets:
            return value
        text = json.dumps(value, separators=(",", ":"))
        if not any(s in text for s in secrets):
            return value
        return json.loads(redact_text(text, secrets))

    async def run(self, handle: Handle) -> AsyncIterator[dict]:
        """Client-facing events: ``{"event": name, "data": {...}}``. Never raises for agent
        failures (they become ``error`` + ``done``); re-raises cancellation of the consumer."""
        inv_id = handle.id
        outcome = handle.outcome
        handle.cancel_event = asyncio.Event()
        self.active[inv_id] = handle
        if handle.plan.mode == "background":
            self.store.mark_running(inv_id)
        loop = asyncio.get_running_loop()
        started = loop.time()
        deadline = started + handle.plan.timeout
        queue: asyncio.Queue = asyncio.Queue(maxsize=256)
        transport = self.transport(handle.call.version.kind)
        secrets = [s for s in self._secrets() if s]
        redactor = TextRedactor(secrets)

        async def pump() -> None:
            try:
                async for event in transport.events(handle.call):
                    await queue.put(("event", event))
                await queue.put(("end", None))
            except asyncio.CancelledError:
                raise
            except InvocationError as exc:
                await queue.put(("error", exc))
            except Exception as exc:
                log.warning("agent invocation %s failed: %s", inv_id, type(exc).__name__)
                await queue.put(("error", InvocationError("agent_error", 502, "agent invocation failed")))

        handle.pump = asyncio.create_task(pump())
        done_seen = False
        try:
            while outcome.error is None:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    outcome.status = "timeout"
                    outcome.error = InvocationError("invocation_timeout", 504,
                                                    f"agent did not finish within {int(handle.plan.timeout)} s")
                    break
                getter = asyncio.ensure_future(queue.get())
                canceller = asyncio.ensure_future(handle.cancel_event.wait())
                try:
                    finished, _ = await asyncio.wait({getter, canceller}, timeout=remaining,
                                                     return_when=asyncio.FIRST_COMPLETED)
                finally:
                    for f in (getter, canceller):
                        if not f.done():
                            f.cancel()
                if canceller in finished and getter not in finished:
                    outcome.status = "cancelled"
                    outcome.error = InvocationError("invocation_cancelled", 409, "invocation cancelled")
                    break
                if getter not in finished:
                    continue  # deadline check at the top of the loop
                kind, item = getter.result()
                if kind == "end":
                    break
                if kind == "error":
                    outcome.status = "timeout" if item.code == "invocation_timeout" else "failed"
                    outcome.error = item
                    break
                event: AgentEvent = item
                fresh = self._secrets()
                if len(fresh) != len(secrets):  # credentials resolved by the transport after the start
                    secrets = [s for s in fresh if s]
                    redactor.secrets = secrets
                if event.kind == "delta" and isinstance(event.data.get("text"), str):
                    outcome.text += event.data["text"]
                    text = redactor.feed(event.data["text"])
                    if text:
                        yield {"event": "delta", "data": {"text": text, "invocation_id": inv_id}}
                elif event.kind == "output" and "output" in event.data:
                    outcome.output, outcome.has_output = event.data["output"], True
                    outcome.usage = usage_of(event.data.get("usage")) or outcome.usage
                    if isinstance(event.data.get("trace_id"), str):
                        outcome.agent_trace_id = event.data["trace_id"]
                elif event.kind == "error":
                    msg = event.data.get("message") if isinstance(event.data.get("message"), str) else "agent error"
                    outcome.status = "failed"
                    outcome.error = InvocationError("agent_error", 502, redact_text(msg, secrets))
                elif event.kind == "done":
                    done_seen = True
                    break
            if outcome.error is None:
                if not (done_seen or outcome.has_output):
                    outcome.status = "failed"
                    outcome.error = InvocationError("agent_error", 502, "agent stream ended unexpectedly")
                else:
                    outcome.status = "succeeded"
                    if not outcome.has_output:
                        outcome.output, outcome.has_output = outcome.text, True
            tail = redactor.flush()
            if tail:
                yield {"event": "delta", "data": {"text": tail, "invocation_id": inv_id}}
            outcome.duration_ms = int((loop.time() - started) * 1000)
            self._finish(handle, secrets)
            if outcome.error is None:
                data: dict[str, Any] = {"output": self._redact_value(outcome.output, secrets),
                                        "trace_id": handle.call.trace_id, "invocation_id": inv_id}
                if outcome.usage:
                    data["usage"] = outcome.usage
                yield {"event": "output", "data": data}
            else:
                yield {"event": "error", "data": {"code": outcome.error.code,
                                                  "message": redact_text(outcome.error.message, secrets),
                                                  "invocation_id": inv_id}}
            yield {"event": "done", "data": {"invocation_id": inv_id, "status": outcome.status,
                                             "duration_ms": outcome.duration_ms}}
        except (asyncio.CancelledError, GeneratorExit):
            if outcome.status in ("running",):
                outcome.status = "cancelled"
                outcome.error = InvocationError(
                    "invocation_cancelled", 409,
                    "platform-api stopped before the run finished" if handle.plan.mode == "background"
                    else "client disconnected")
                outcome.duration_ms = int((loop.time() - started) * 1000)
                self._finish(handle, secrets)
            raise
        finally:
            # Never await here: this runs while the consumer is being cancelled, and swallowing or
            # delaying that cancellation would break the caller's cancel scope. The pump closes its
            # upstream response in its own finally once cancelled.
            if handle.pump is not None and not handle.pump.done():
                handle.pump.cancel()
            self.active.pop(inv_id, None)

    def _finish(self, handle: Handle, secrets: list[str]) -> None:
        o = handle.outcome
        encrypted = None
        if handle.plan.mode == "background" and o.error is None and self.cipher is not None:
            encrypted = self.cipher.encrypt(self._redact_value(o.output, secrets))
        try:
            self.store.finish(handle.id, status=o.status, usage=o.usage,
                              error_code=o.error.code if o.error else None,
                              error_message=redact_text(o.error.message, secrets) if o.error else None,
                              output_encrypted=encrypted)
        except Exception as exc:
            log.error("could not close invocation record %s: %s", handle.id, type(exc).__name__)
        log.info("agent invoke %s finished status=%s ms=%d", handle.id, o.status, o.duration_ms)
        if self.on_finish is not None:
            try:
                self.on_finish(handle)
            except Exception as exc:
                log.warning("invocation finish hook failed for %s: %s", handle.id, type(exc).__name__)

    async def run_to_end(self, handle: Handle) -> Outcome:
        async for _ in self.run(handle):
            pass
        return handle.outcome

    def audit_cancel(self, actor: str, invocation_id: str, agent_id: str, *, via: str) -> None:
        try:
            with self.db.session() as s:
                add_audit(s, actor=actor, action="agent.invocation.cancel", entity_type="agent_invocation",
                          entity_id=invocation_id, details={"agent_id": agent_id, "via": via})
        except Exception as exc:
            log.error("audit write failed for cancel %s: %s", invocation_id, type(exc).__name__)

    def cancel(self, invocation_id: str) -> bool:
        """Cancel an invocation running in this process. False when it is not running here."""
        handle = self.active.get(invocation_id)
        if handle is None or handle.cancel_event is None:
            return False
        handle.cancel_event.set()
        return True


# --- background runs ----------------------------------------------------------------------------


class BackgroundRunner:
    """App-level tasks for ``mode=background`` (independent of the client connection) plus a tiny
    pub/sub of ``agent.invocation.status`` frames keyed by caller email (WebSocket sessions)."""

    def __init__(self, invoker: Invoker):
        self.invoker = invoker
        self.tasks: dict[str, asyncio.Task] = {}
        self.listeners: dict[str, set[Callable[[dict], Any]]] = {}

    def subscribe(self, email: str, fn: Callable[[dict], Any]) -> None:
        self.listeners.setdefault(email.lower(), set()).add(fn)

    def unsubscribe(self, email: str, fn: Callable[[dict], Any]) -> None:
        subs = self.listeners.get(email.lower())
        if subs:
            subs.discard(fn)
            if not subs:
                self.listeners.pop(email.lower(), None)

    async def publish(self, email: str, frame: dict) -> None:
        for fn in list(self.listeners.get(email.lower(), ())):
            try:
                res = fn(frame)
                if asyncio.iscoroutine(res):
                    await res
            except Exception as exc:
                log.debug("status push failed: %s", type(exc).__name__)

    def status_frame(self, handle: Handle, status: str, *, request_id: str | None = None) -> dict:
        o = handle.outcome
        frame: dict[str, Any] = {"type": "agent.invocation.status", "invocation_id": handle.id,
                                 "agent_id": handle.plan.agent.agent_id, "version": handle.plan.version.version,
                                 "env": handle.plan.version.env, "mode": handle.plan.mode, "status": status}
        if request_id:
            frame["id"] = request_id
        if status in ("succeeded", "failed", "cancelled", "timeout"):
            frame["duration_ms"] = o.duration_ms
            if o.usage:
                frame["usage"] = o.usage
            if o.error:
                frame["error_code"] = o.error.code
        return frame

    def start(self, handle: Handle, *, request_id: str | None = None) -> asyncio.Task:
        async def runner() -> None:
            email = handle.plan.identity.email
            await self.publish(email, self.status_frame(handle, "running", request_id=request_id))
            try:
                await self.invoker.run_to_end(handle)
            except asyncio.CancelledError:
                await self.publish(email, self.status_frame(handle, "cancelled", request_id=request_id))
                raise
            except Exception as exc:
                log.warning("background invocation %s crashed: %s", handle.id, type(exc).__name__)
            await self.publish(email, self.status_frame(handle, handle.outcome.status, request_id=request_id))

        task = asyncio.create_task(runner())
        self.tasks[handle.id] = task
        task.add_done_callback(lambda _t: self.tasks.pop(handle.id, None))
        return task

    async def shutdown(self) -> None:
        tasks = list(self.tasks.values())
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
