"""IDE token-usage events -> backend/telemetry-bridge (``POST /ingest/ide-usage``).

After each completed chat (HTTP proxy and WebSocket ``chat.done``) that reports token usage,
platform-api posts one event shaped by ``backend/contracts/ide-usage-event.schema.json`` to
``{AIG_TELEMETRY_BRIDGE_URL}/ingest/ide-usage`` with ``Authorization: Bearer
<TELEMETRY_BRIDGE_TOKEN>``. The bridge forwards it to Fiddler.

- Fire-and-forget: the post runs as a background task with a short timeout
  (``AIG_TELEMETRY_BRIDGE_TIMEOUT_SECONDS``, default 5 s). It never blocks, delays or fails a chat;
  failures are logged (exception type / status only).
- Token counts only: prompts and replies are never part of the event.
- ``build_ide_usage_event`` enforces the contract (enums, patterns, non-negative integers): optional
  fields that do not fit are dropped, and an event whose required fields do not fit is not sent.
  ``tests/test_usage_events.py`` validates built events against the JSON schema itself.
- Disabled (no-op) unless both the URL and the token are configured.
"""

from __future__ import annotations

import asyncio
import logging
import re
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx

from .config import configured_url

log = logging.getLogger(__name__)

INGEST_PATH = "/ingest/ide-usage"
TOKEN_SECRET = "TELEMETRY_BRIDGE_TOKEN"

_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")
_MODEL_RE = re.compile(r"^[A-Za-z0-9._:/@-]{1,128}$")
_TRACE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$")
SOURCES = ("vscode", "eclipse", "web")
TIERS = ("premium", "standard", "free")
JOB_PROFILES = ("underwriting", "claims", "operations", "general")
ENVS = ("local", "dev", "stage", "prod")
_CACHE = {"hit": "hit", "semantic hit": "semantic_hit", "semantic_hit": "semantic_hit", "miss": "miss",
          "disabled": "disabled"}


def cache_status(header: str | None) -> str | None:
    """Map Portkey's x-portkey-cache-status header (HIT, SEMANTIC HIT, MISS, DISABLED, ...)."""
    if not header:
        return None
    return _CACHE.get(header.strip().lower(), "unknown")


def _int(v: Any) -> int | None:
    return v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None


def build_ide_usage_event(
    *,
    metadata: dict[str, str],
    usage: dict[str, Any],
    model: str | None,
    trace_id: str | None,
    latency_ms: float | None = None,
    cache: str | None = None,
    request_kind: str = "chat",
) -> dict | None:
    """One contract-valid event, or None if a required field cannot be filled correctly."""
    prompt, completion = _int(usage.get("prompt_tokens")), _int(usage.get("completion_tokens"))
    if prompt is None or completion is None:
        return None
    source, agent_id, team = metadata.get("host"), metadata.get("agent_id"), metadata.get("team")
    tier, env = metadata.get("user_tier"), metadata.get("env")
    if source not in SOURCES or tier not in TIERS or env not in ENVS:
        return None
    if not (isinstance(agent_id, str) and _ID_RE.match(agent_id) and isinstance(team, str) and _ID_RE.match(team)):
        return None
    event: dict[str, Any] = {
        "event_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": source,
        "agent_id": agent_id,
        "team": team,
        "user_tier": tier,
        "env": env,
        "model": model if isinstance(model, str) and _MODEL_RE.match(model) else "auto",
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": _int(usage.get("total_tokens")) if _int(usage.get("total_tokens")) is not None else prompt + completion,
        "status": "ok",
        "request_kind": request_kind,
    }
    if metadata.get("job_profile") in JOB_PROFILES:
        event["job_profile"] = metadata["job_profile"]
    user = metadata.get("user")
    if isinstance(user, str) and len(user) <= 254 and _EMAIL_RE.match(user):
        event["user"] = user
    if isinstance(trace_id, str) and _TRACE_RE.match(trace_id):
        event["trace_id"] = trace_id
    if isinstance(latency_ms, (int, float)) and not isinstance(latency_ms, bool) and latency_ms >= 0:
        event["latency_ms"] = round(float(latency_ms), 1)
    if cache in ("hit", "semantic_hit", "miss", "disabled", "unknown"):
        event["cache"] = cache
    return event


def forwarding_enabled(state: Any) -> bool:
    return bool(configured_url(state.settings.telemetry_bridge_url) and state.secrets.get(TOKEN_SECRET))


async def _post(state: Any, event: dict) -> None:
    url = configured_url(state.settings.telemetry_bridge_url)
    token = state.secrets.get(TOKEN_SECRET)
    if not url or not token:
        return
    client: httpx.AsyncClient | None = state.http_client
    if client is None:
        return
    try:
        resp = await client.post(
            url + INGEST_PATH, json=event,
            headers={"authorization": f"Bearer {token}", "content-type": "application/json"},
            timeout=state.settings.telemetry_bridge_timeout_seconds,
        )
        if resp.status_code >= 400:
            log.warning("ide usage event rejected by the telemetry bridge: HTTP %s", resp.status_code)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        log.warning("ide usage event not delivered: %s", type(exc).__name__)


def submit_ide_usage(state: Any, event: dict | None) -> None:
    """Schedule delivery (fire-and-forget). Never raises."""
    if event is None or not forwarding_enabled(state):
        return
    try:
        tasks: set = state.usage_event_tasks
        task = asyncio.get_running_loop().create_task(_post(state, event))
        tasks.add(task)
        task.add_done_callback(tasks.discard)
    except Exception as exc:
        log.warning("ide usage event not scheduled: %s", type(exc).__name__)


def forward_chat_usage(state: Any, *, metadata: dict[str, str], usage: dict | None, model: str | None,
                       trace_id: str | None, latency_ms: float | None, cache: str | None = None) -> None:
    """Build and submit the event for one completed chat (no-op without usage). Never raises."""
    if not usage:
        return
    try:
        submit_ide_usage(state, build_ide_usage_event(
            metadata=metadata, usage=usage, model=model, trace_id=trace_id, latency_ms=latency_ms, cache=cache))
    except Exception as exc:
        log.warning("ide usage event not built: %s", type(exc).__name__)
