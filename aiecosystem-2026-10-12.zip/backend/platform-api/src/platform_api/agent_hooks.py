"""Agent lifecycle hooks: code that runs after an agent registers (Phase 3).

The only hook shipped today provisions the agent's Fiddler application (one application per
registered agent, in the environment's Fiddler project). It lives in the Fiddler provisioning
tool (``backend/observability/tool``, package ``aig-fiddler``) as
``aig_fiddler.hooks:on_agent_registered``; platform-api only calls it, behind the feature flag
``AIG_FIDDLER_AUTOPROVISION=true``, so platform-api never depends on that package otherwise.

Interface (any callable can be plugged in through ``AIG_AGENT_HOOKS="module:function,..."``)::

    def on_agent_registered(agent: dict, *, env: str, fiddler_url: str | None,
                            fiddler_api_key: str | None) -> dict | None

``agent`` is ``AgentRecord.to_dict()``. Hooks run after the registration response (FastAPI
background task); a failing hook is logged and never undoes the registration. The scheduled
``fiddler-sync apply`` run creates anything a failed hook missed.
"""

from __future__ import annotations

import importlib
import logging
from dataclasses import dataclass
from typing import Any, Callable

from .agents import AgentRecord
from .errors import StartupError

log = logging.getLogger(__name__)

FIDDLER_HOOK = "aig_fiddler.hooks:on_agent_registered"

HookFn = Callable[..., Any]


@dataclass(frozen=True)
class AgentHook:
    name: str
    fn: HookFn


def _import(spec: str) -> HookFn:
    module_name, _, attr = spec.partition(":")
    if not module_name or not attr:
        raise ValueError(f"hook {spec!r} must look like 'package.module:function'")
    fn = getattr(importlib.import_module(module_name), attr)
    if not callable(fn):
        raise ValueError(f"hook {spec!r} is not callable")
    return fn


def load_agent_hooks(*, fiddler_autoprovision: bool, extra: str | None, env: str) -> list[AgentHook]:
    """Resolve the configured hooks. A hook that cannot be imported stops startup outside
    ``local`` (the flag was set on purpose) and is skipped with a warning in ``local``."""
    specs: list[str] = []
    if fiddler_autoprovision:
        specs.append(FIDDLER_HOOK)
    specs += [s.strip() for s in (extra or "").split(",") if s.strip()]
    hooks: list[AgentHook] = []
    for spec in dict.fromkeys(specs):
        try:
            hooks.append(AgentHook(spec, _import(spec)))
        except Exception as exc:  # ImportError, AttributeError, ValueError
            msg = f"agent hook {spec} unavailable ({type(exc).__name__}: {exc})"
            if spec == FIDDLER_HOOK:
                msg += "; install backend/observability/tool (pip install aig-fiddler) or unset AIG_FIDDLER_AUTOPROVISION"
            if env != "local":
                raise StartupError(f"refusing to start in AIG_ENV={env}: {msg}") from None
            log.warning("AIG_ENV=local: %s", msg)
    return hooks


def run_registered_hooks(hooks: list[AgentHook], agent: AgentRecord, *, env: str, context: dict[str, Any]) -> list[dict]:
    """Run every hook; return one result per hook. Never raises."""
    results = []
    for hook in hooks:
        try:
            out = hook.fn(agent.to_dict(), env=env, **context)
            results.append({"hook": hook.name, "status": "ok", "result": out})
            log.info("agent hook %s ok for %s", hook.name, agent.agent_id)
        except Exception as exc:
            # Exception text only (no context values): hooks receive keys, never log them.
            log.error("agent hook %s failed for %s: %s", hook.name, agent.agent_id, type(exc).__name__)
            results.append({"hook": hook.name, "status": "error", "error": type(exc).__name__})
    return results
