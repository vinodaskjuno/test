"""Persistence (Phase 4): SQLAlchemy 2.x models, engine setup, URL policy and Alembic helpers.

- ``AIG_DATABASE_URL`` picks the database. ``local`` defaults to the SQLite file
  ``.run/platform.db``; ``dev``, ``stage`` and ``prod`` **require** a Postgres URL
  (``postgresql+psycopg://...``) and refuse to start without one (fail closed).
- The schema is owned by Alembic (``migrations/``). ``aig-platform-api db upgrade`` applies it.
  ``local`` migrates automatically at startup; elsewhere startup refuses to run against a schema
  that is not at head (``AIG_DB_AUTO_MIGRATE=true`` opts in to migrating at startup).
- The URL's password is never logged (it is added to the log redaction filter, and the URL is
  only ever rendered with the password hidden).

Tests use ``Database.in_memory()`` (SQLite in memory, schema from the models); a contract test
checks that the Alembic migrations produce exactly the same schema.
"""

from __future__ import annotations

import logging
import re
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    Index,
    Integer,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
    create_engine,
    text,
)
from sqlalchemy.engine import Engine, make_url
from sqlalchemy.exc import ArgumentError, SQLAlchemyError
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker
from sqlalchemy.pool import StaticPool

from .config import PROJECT_ROOT
from .errors import StartupError

log = logging.getLogger(__name__)

LOCAL_DB_PATH = PROJECT_ROOT / ".run" / "platform.db"
_PLACEHOLDER_RE = re.compile(r"__[A-Z0-9_]+__")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None) -> str | None:
    """ISO-8601 UTC (seconds). SQLite returns naive datetimes; they are stored as UTC."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


class Base(DeclarativeBase):
    pass


TS = DateTime(timezone=True)


class AgentRow(Base):
    __tablename__ = "agents"

    agent_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    team: Mapped[str] = mapped_column(String(64), index=True)
    owner: Mapped[str] = mapped_column(String(254), index=True)
    status: Mapped[str] = mapped_column(String(16), default="active", index=True)
    shared: Mapped[bool] = mapped_column(Boolean, default=False)
    builtin: Mapped[bool] = mapped_column(Boolean, default=False)
    status_reason: Mapped[str] = mapped_column(Text, default="")
    status_changed_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    fiddler_application_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_seen_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    hosts_seen: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    # Registry v2 (migration 0003_agent_registry_v2). Server defaults keep existing rows valid:
    # agents registered before v2 were usable, so they are "active".
    lifecycle: Mapped[str] = mapped_column(String(16), default="active", server_default="active", index=True)
    lifecycle_changed_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    tags: Mapped[list] = mapped_column(JSON, default=list, server_default=text("'[]'"))
    docs_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    data_classification: Mapped[str | None] = mapped_column(String(16), nullable=True)
    visibility: Mapped[str] = mapped_column(String(16), default="team", server_default="team")
    allowed_groups: Mapped[list] = mapped_column(JSON, default=list, server_default=text("'[]'"))
    org_approval: Mapped[str] = mapped_column(String(16), default="none", server_default="none")
    org_approval_by: Mapped[str | None] = mapped_column(String(254), nullable=True)
    org_approval_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)


class AgentVersionRow(Base):
    """One deployable version of an agent in one environment (registry v2). Never holds a secret
    value: ``auth`` is ``{"type", "secret_arn"}`` (a Secrets Manager reference)."""

    __tablename__ = "agent_versions"
    __table_args__ = (UniqueConstraint("agent_id", "env", "version", name="uq_agent_versions_agent_env_version"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(64), ForeignKey("agents.agent_id"), index=True)
    version: Mapped[str] = mapped_column(String(128))
    env: Mapped[str] = mapped_column(String(8))
    kind: Mapped[str] = mapped_column(String(16))
    endpoint: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    runtime_arn: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    qualifier: Mapped[str | None] = mapped_column(String(128), nullable=True)
    protocol: Mapped[str] = mapped_column(String(32), default="aig-http/1")
    input_schema: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    output_schema: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    auth: Mapped[dict] = mapped_column(JSON, default=dict)
    git_sha: Mapped[str | None] = mapped_column(String(64), nullable=True)
    image_digest: Mapped[str | None] = mapped_column(String(128), nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    verification_status: Mapped[str] = mapped_column(String(16), default="unverified")
    verification: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="active", index=True)
    created_by: Mapped[str] = mapped_column(String(254))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class AgentInvocationRow(Base):
    """Invocation record: metadata only (90-day retention). ``output_encrypted`` is set only for
    background runs (Fernet token, 30-day retention)."""

    __tablename__ = "agent_invocations"
    __table_args__ = (Index("ix_agent_invocations_agent_created", "agent_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(64), index=True)
    version: Mapped[str] = mapped_column(String(128))
    env: Mapped[str] = mapped_column(String(8))
    caller: Mapped[str] = mapped_column(String(254), index=True)
    team: Mapped[str] = mapped_column(String(64))
    mode: Mapped[str] = mapped_column(String(16))
    purpose: Mapped[str] = mapped_column(String(16), default="invoke")
    status: Mapped[str] = mapped_column(String(16), default="queued", index=True)
    session_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    trace_id: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    started_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    prompt_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    completion_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    total_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_expires_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    retain_until: Mapped[datetime] = mapped_column(TS, index=True)


class UserPreferenceRow(Base):
    __tablename__ = "user_preferences"

    email: Mapped[str] = mapped_column(String(254), primary_key=True)
    theme: Mapped[str] = mapped_column(String(16), default="system")
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class McpServerRow(Base):
    __tablename__ = "mcp_servers"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), index=True)
    url: Mapped[str] = mapped_column(String(2048))
    description: Mapped[str] = mapped_column(Text, default="")
    iam_roles: Mapped[list] = mapped_column(JSON, default=list)
    workspaces: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(16), default="pending", index=True)
    requested_by: Mapped[str] = mapped_column(String(254))
    decided_by: Mapped[str | None] = mapped_column(String(254), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    sync_status: Mapped[str] = mapped_column(String(16), default="not_synced")
    sync_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    synced_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class ModelRow(Base):
    __tablename__ = "models"
    __table_args__ = (UniqueConstraint("provider", "name", "version", name="uq_models_provider_name_version"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    provider: Mapped[str] = mapped_column(String(64))
    version: Mapped[str] = mapped_column(String(64))
    tiers: Mapped[list] = mapped_column(JSON, default=list)
    job_profiles: Mapped[list] = mapped_column(JSON, default=list)
    use_case: Mapped[str] = mapped_column(Text, default="")
    data_classification: Mapped[str] = mapped_column(String(16))
    expected_monthly_cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(16), default="requested", index=True)
    requested_by: Mapped[str] = mapped_column(String(254))
    scorecard: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    canary_share: Mapped[float | None] = mapped_column(Float, nullable=True)
    canary_started_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    decided_by: Mapped[str | None] = mapped_column(String(254), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    # Phase 7 model harness (migration 0002_model_harness).
    sandbox_key_status: Mapped[str | None] = mapped_column(String(16), nullable=True)
    sandbox_key_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    sandbox_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    canary_dispatch_status: Mapped[str | None] = mapped_column(String(16), nullable=True)
    canary_dispatch_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    canary_pr_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    gate: Mapped[dict | None] = mapped_column(JSON, nullable=True)


class AuditRow(Base):
    __tablename__ = "audit_log"
    __table_args__ = (Index("ix_audit_log_entity", "entity_type", "entity_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(254))
    action: Mapped[str] = mapped_column(String(64))
    entity_type: Mapped[str] = mapped_column(String(32))
    entity_id: Mapped[str] = mapped_column(String(128))
    details: Mapped[dict] = mapped_column(JSON, default=dict)


class WorkspaceRow(Base):
    __tablename__ = "workspaces"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    repo_url: Mapped[str] = mapped_column(String(2048))
    work_item: Mapped[str] = mapped_column(String(500))
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    job_profile: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="queued", index=True)
    requested_by: Mapped[str] = mapped_column(String(254), index=True)
    team: Mapped[str] = mapped_column(String(64))
    pr_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    log_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class EvalRunRow(Base):
    __tablename__ = "eval_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(64), index=True)
    dataset: Mapped[str] = mapped_column(String(256))
    experiment_id: Mapped[str] = mapped_column(String(256))
    scores: Mapped[dict] = mapped_column(JSON, default=dict)
    baseline_scores: Mapped[dict] = mapped_column(JSON, default=dict)
    passed: Mapped[bool] = mapped_column(Boolean)
    fiddler_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    git_sha: Mapped[str | None] = mapped_column(String(64), nullable=True)
    pr: Mapped[str | None] = mapped_column(String(256), nullable=True)
    created_by: Mapped[str] = mapped_column(String(254))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)


def add_audit(
    session: Session, *, actor: str, action: str, entity_type: str, entity_id: str, details: dict | None = None
) -> AuditRow:
    """Append one audit record in the caller's transaction (so it commits with the change)."""
    row = AuditRow(at=utcnow(), actor=actor, action=action, entity_type=entity_type, entity_id=entity_id,
                   details=details or {})
    session.add(row)
    log.info("audit %s %s/%s by %s", action, entity_type, entity_id, actor)
    return row


class Database:
    """Engine + session factory. ``session()`` commits on success and rolls back on error."""

    def __init__(self, engine: Engine):
        self.engine = engine
        self._factory = sessionmaker(engine, expire_on_commit=False)

    @classmethod
    def in_memory(cls) -> "Database":
        engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
        Base.metadata.create_all(engine)
        return cls(engine)

    @property
    def backend(self) -> str:
        return self.engine.dialect.name

    @contextmanager
    def session(self) -> Iterator[Session]:
        s = self._factory()
        try:
            yield s
            s.commit()
        except BaseException:
            s.rollback()
            raise
        finally:
            s.close()

    def ping(self) -> bool:
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return True
        except SQLAlchemyError:
            return False

    def dispose(self) -> None:
        self.engine.dispose()


# --- URL policy ---------------------------------------------------------------------------


def resolve_database_url(env: str, configured: str | None) -> str:
    """The URL to use, or StartupError. Outside local a postgresql URL is required."""
    url = (configured or "").strip().strip("\"'").strip()
    if not url:
        if env != "local":
            raise StartupError(
                f"refusing to start in AIG_ENV={env}: AIG_DATABASE_URL is not set "
                "(postgresql+psycopg://user:password@host:5432/aig_platform)"
            )
        return f"sqlite:///{LOCAL_DB_PATH}"
    if _PLACEHOLDER_RE.search(url):
        raise StartupError(f"refusing to start in AIG_ENV={env}: AIG_DATABASE_URL is still a placeholder")
    try:
        parsed = make_url(url)
    except ArgumentError:
        raise StartupError(f"refusing to start in AIG_ENV={env}: AIG_DATABASE_URL is not a valid database URL") from None
    if parsed.drivername == "postgresql":  # psycopg 3 is the installed driver (not psycopg2)
        parsed = parsed.set(drivername="postgresql+psycopg")
    if env != "local" and not parsed.drivername.startswith("postgresql"):
        raise StartupError(
            f"refusing to start in AIG_ENV={env}: AIG_DATABASE_URL must be a Postgres URL "
            f"(postgresql+psycopg://...), got {parsed.drivername}"
        )
    return parsed.render_as_string(hide_password=False)


def url_password(url: str) -> str | None:
    try:
        return make_url(url).password or None
    except ArgumentError:
        return None


def safe_url(url: str) -> str:
    try:
        return make_url(url).render_as_string(hide_password=True)
    except ArgumentError:
        return "<invalid url>"


def make_engine(url: str) -> Engine:
    parsed = make_url(url)
    if parsed.get_backend_name() == "sqlite":
        kwargs: dict[str, Any] = {"connect_args": {"check_same_thread": False}}
        if parsed.database in (None, "", ":memory:"):
            kwargs["poolclass"] = StaticPool
        else:
            Path(parsed.database).parent.mkdir(parents=True, exist_ok=True)
        return create_engine(url, **kwargs)
    return create_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=10)


# --- Alembic --------------------------------------------------------------------------------


def alembic_config(migrations_dir: Path, url: str | None = None):
    from alembic.config import Config

    cfg = Config()
    cfg.set_main_option("script_location", str(migrations_dir))
    if url:
        cfg.attributes["url"] = url  # attributes, not ini options: no %-interpolation of passwords
    return cfg


def upgrade(engine: Engine, migrations_dir: Path, revision: str = "head") -> None:
    from alembic import command

    cfg = alembic_config(migrations_dir)
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        command.upgrade(cfg, revision)


def head_revision(migrations_dir: Path) -> str | None:
    from alembic.script import ScriptDirectory

    return ScriptDirectory.from_config(alembic_config(migrations_dir)).get_current_head()


def current_revision(engine: Engine) -> str | None:
    from alembic.runtime.migration import MigrationContext

    with engine.connect() as conn:
        return MigrationContext.configure(conn).get_current_revision()


def open_database(settings) -> Database:
    """Resolve the URL (fail closed), connect, then migrate (local) or verify the schema is at head."""
    url = resolve_database_url(settings.env, settings.database_url)
    engine = make_engine(url)
    auto = settings.db_auto_migrate if settings.db_auto_migrate is not None else settings.env == "local"
    migrations_dir = Path(settings.migrations_dir)
    try:
        if auto:
            upgrade(engine, migrations_dir)
        else:
            head, current = head_revision(migrations_dir), current_revision(engine)
            if current != head:
                raise StartupError(
                    f"refusing to start in AIG_ENV={settings.env}: database schema is at {current or 'empty'}, "
                    f"expected {head}. Run `aig-platform-api db upgrade` first."
                )
    except SQLAlchemyError as exc:
        engine.dispose()
        raise StartupError(
            f"refusing to start in AIG_ENV={settings.env}: database {safe_url(url)} unavailable ({type(exc).__name__})"
        ) from None
    log.info("database %s ready (%s)", engine.dialect.name, safe_url(url))
    return Database(engine)
