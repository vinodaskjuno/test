"""Phase 7 model harness side effects of model lifecycle transitions.

1. **Sandbox key** (``requested -> sandbox``, ``AIG_MODEL_SANDBOX_SYNC=true``): create a
   sandbox-only Portkey provider (virtual key) for the candidate in the ``model-sandbox``
   workspace through the Portkey admin API: ``POST {admin_url}{portkey_sandbox_providers_path}``
   with ``{name, slug, workspace_id, integration_id, note}``. The provider *references* the
   sandbox integration (``anthropic-sandbox`` / ``openai-sandbox``, created by ``aigw apply``), so
   no provider key ever passes through platform-api. A 409 (slug exists) counts as created
   (idempotent). Only integrations whose slug ends in ``-sandbox`` are ever used.
2. **Canary dispatch** (``-> canary | promoted | rolled_back``, ``AIG_CANARY_DISPATCH=true``):
   ``POST {github_api_url}/repos/{AIG_GITHUB_REPO}/dispatches`` with event type
   ``model_canary`` / ``model_promote`` / ``model_rollback`` and the payload the
   ``model-canary`` workflow turns into ``aigw canary set|promote|rollback`` + a PR.

Neither ever raises or blocks the transition: the outcome is recorded on the model
(``sandbox_key_status``/``sandbox_key_id``/``sandbox_error``, ``canary_dispatch_status``/
``canary_dispatch_error``) with short messages that never contain response bodies or secrets.
Paths and body shapes are unverified against the self-hosted Portkey (see
backend/gateway/README.md "Assumptions").
"""

from __future__ import annotations

import logging
import re
from typing import Any

import httpx

from .config import configured_url

log = logging.getLogger(__name__)
TIMEOUT_SECONDS = 10.0
DISPATCH_EVENTS = {"canary": "model_canary", "promoted": "model_promote", "rolled_back": "model_rollback"}


# Same derivation as backend/gateway/tool/src/aig_gateway/canary.py (tests keep them equal).
def provider_model_id(name: str, version: str) -> str:
    name, version = name.strip(), (version or "").strip()
    if not version or version.lower() == "latest" or version in name:
        return name
    return f"{name}-{version}"


def model_alias(name: str, version: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", provider_model_id(name, version).lower()).strip("-")
    return (slug or "model")[:63].rstrip("-")


def sandbox_slug(model: dict) -> str:
    return f"aig-sbx-{model['id'][:8]}"


async def create_sandbox_key(state: Any, model: dict) -> tuple[str, str | None, str | None]:
    """Returns (sandbox_key_status, sandbox_key_id, sandbox_error)."""
    if not state.settings.model_sandbox_sync:
        return "disabled", None, None
    try:
        cfg = state.env_config
        integration = (cfg.model_sandbox_integrations or {}).get(str(model.get("provider", "")).lower())
        if not integration:
            return "failed", None, f"no sandbox integration for provider {model.get('provider')!r}"
        if not integration.endswith("-sandbox"):
            return "failed", None, f"integration {integration} is not a sandbox integration"
        key = state.secrets.get("PORTKEY_ADMIN_API_KEY")
        base = configured_url(state.settings.portkey_admin_url) or configured_url(cfg.portkey_admin_api_url)
        if not key or not base:
            return "failed", None, "Portkey admin API is not configured (AIG_PORTKEY_ADMIN_URL / PORTKEY_ADMIN_API_KEY)"
        slug = sandbox_slug(model)
        body = {
            "name": f"sandbox {model['provider']}/{model['name']}@{model['version']}"[:100],
            "slug": slug,
            "workspace_id": cfg.model_sandbox_workspace,
            "integration_id": integration,
            "note": f"AIG model harness candidate {model['id']}: model-sandbox only, synthetic or masked data only",
        }
        headers = {"x-portkey-api-key": key, "content-type": "application/json", "accept": "application/json"}
        path = "/" + cfg.portkey_sandbox_providers_path.strip("/")
        try:
            resp = await state.http_client.post(f"{base}{path}", json=body, headers=headers, timeout=TIMEOUT_SECONDS)
        except httpx.TimeoutException:
            return "failed", None, "Portkey admin API timed out"
        except httpx.RequestError as exc:
            return "failed", None, f"Portkey admin API unreachable ({type(exc).__name__})"
        if resp.status_code == 409:
            log.info("sandbox key %s already exists for model %s", slug, model["id"])
            return "created", slug, None
        if resp.status_code >= 400:
            return "failed", None, f"Portkey admin API returned {resp.status_code}"
        key_id = slug
        try:
            data = resp.json()
            if isinstance(data, dict):
                inner = data.get("data") if isinstance(data.get("data"), dict) else {}
                found = data.get("slug") or inner.get("slug")
                if isinstance(found, str) and re.fullmatch(r"[A-Za-z0-9._@-]{1,128}", found):
                    key_id = found
        except ValueError:
            pass
        log.info("sandbox key %s created in %s for model %s", key_id, cfg.model_sandbox_workspace, model["id"])
        return "created", key_id, None
    except Exception as exc:  # never fail the transition because of the sandbox key
        log.warning("sandbox key creation failed for %s: %s", model.get("id"), type(exc).__name__)
        return "failed", None, f"sandbox key creation failed ({type(exc).__name__})"


def dispatch_payload(state: Any, model: dict, target: str, note: str | None) -> dict:
    """GitHub allows at most 10 top-level client_payload properties."""
    return {
        "model_id": model["id"],
        "alias": model_alias(model["name"], model["version"]),
        "model": provider_model_id(model["name"], model["version"]),
        "provider": model["provider"],
        "tiers": list(model.get("tiers") or []),
        "share": model.get("canary_share"),
        "state": target,
        "env": state.settings.env,
        "note": (note or "")[:200],
    }


async def dispatch_canary(state: Any, model: dict, target: str, note: str | None = None) -> tuple[str, str | None]:
    """Returns (canary_dispatch_status, canary_dispatch_error)."""
    if not state.settings.canary_dispatch:
        return "disabled", None
    try:
        event = DISPATCH_EVENTS[target]
        repo = (state.settings.github_repo or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
            return "failed", "GitHub repository not configured (AIG_GITHUB_REPO=owner/repo)"
        token = state.secrets.get("GITHUB_DISPATCH_TOKEN")
        if not token:
            return "failed", "GITHUB_DISPATCH_TOKEN is not configured"
        api = (state.settings.github_api_url or "https://api.github.com").rstrip("/")
        headers = {"authorization": f"Bearer {token}", "accept": "application/vnd.github+json",
                   "x-github-api-version": "2022-11-28", "content-type": "application/json"}
        body = {"event_type": event, "client_payload": dispatch_payload(state, model, target, note)}
        try:
            resp = await state.http_client.post(f"{api}/repos/{repo}/dispatches", json=body, headers=headers,
                                                timeout=TIMEOUT_SECONDS)
        except httpx.TimeoutException:
            return "failed", "GitHub API timed out"
        except httpx.RequestError as exc:
            return "failed", f"GitHub API unreachable ({type(exc).__name__})"
        if resp.status_code >= 400:
            return "failed", f"GitHub API returned {resp.status_code}"
        log.info("dispatched %s for model %s to %s", event, model["id"], repo)
        return "dispatched", None
    except Exception as exc:  # never fail the transition because of the dispatch
        log.warning("canary dispatch failed for %s: %s", model.get("id"), type(exc).__name__)
        return "failed", f"dispatch failed ({type(exc).__name__})"
