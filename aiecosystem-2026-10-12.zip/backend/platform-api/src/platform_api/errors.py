"""Uniform error envelope: {"error": {"code": ..., "message": ...}}."""

from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse


class StartupError(RuntimeError):
    """Raised when the service must refuse to start (fail closed)."""


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str = "", headers: dict[str, str] | None = None):
        super().__init__(code)
        self.status_code = status_code
        self.code = code
        self.message = message or code.replace("_", " ")
        self.headers = headers or {}


def error_body(code: str, message: str) -> dict:
    return {"error": {"code": code, "message": message}}


async def api_error_handler(_: Request, exc: ApiError) -> JSONResponse:
    return JSONResponse(error_body(exc.code, exc.message), status_code=exc.status_code, headers=exc.headers)
