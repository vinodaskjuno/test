"""Database-backed agent registry (Phase 4 default; same interface as ``YamlAgentRegistry``).

Implements ``AgentRegistry`` / ``MutableAgentRegistry`` (``get``, ``all``, ``register``,
``set_status``) plus the portal operations: ``update`` (name/description/owner and the v2 catalog
fields tags/docs_url/data_classification), ``touch`` (last_seen_at / hosts_seen from the
agent-check webhook and proxied calls), ``set_fiddler_application_id`` (from the Fiddler
provisioning hook) and the registry v2 operations ``set_lifecycle`` and ``set_access``.

``DbAgentVersions`` stores the per-environment versions (``agent_versions``): endpoint or AgentCore
runtime, protocol, input/output schema, auth *reference* and verification result.

The built-in interactive agents (``ide.vscode``, ``ide.eclipse``, ``web.portal``) are always
present (``ensure_builtins``). A registry YAML file is only a one-time seed: it is imported when
the table is empty (first start) or explicitly with ``aig-platform-api agents import FILE``.
"""

from __future__ import annotations

import logging
import threading
import time

import uuid

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from .agents import (
    AGENT_ID_RE,
    AGENT_STATUSES,
    BUILTIN_AGENTS,
    LIFECYCLES,
    BUILTIN_IDS,
    TEAM_RE,
    AgentRecord,
    AgentRegistryError,
    AgentStatus,
    AgentVersion,
    Lifecycle,
)
from .db import AgentRow, AgentVersionRow, Database, iso, utcnow

log = logging.getLogger(__name__)

# A seen-update is written at most once per agent per interval unless a new host appears.
TOUCH_INTERVAL_SECONDS = 60.0
MAX_HOSTS = 16


def _record(row: AgentRow) -> AgentRecord:
    return AgentRecord(
        agent_id=row.agent_id,
        owner=row.owner,
        team=row.team,
        status=row.status,  # type: ignore[arg-type]
        shared=bool(row.shared),
        description=row.description or "",
        status_reason=row.status_reason or "",
        status_changed_at=iso(row.status_changed_at) or "",
        name=row.name or "",
        builtin=bool(row.builtin),
        created_at=iso(row.created_at) or "",
        updated_at=iso(row.updated_at) or "",
        last_seen_at=iso(row.last_seen_at) or "",
        hosts_seen=tuple(row.hosts_seen or ()),
        fiddler_application_id=row.fiddler_application_id or "",
        lifecycle=(row.lifecycle or "active"),  # type: ignore[arg-type]
        lifecycle_changed_at=iso(row.lifecycle_changed_at) or "",
        tags=tuple(row.tags or ()),
        docs_url=row.docs_url or "",
        data_classification=row.data_classification or "",
        visibility=row.visibility or "team",
        allowed_groups=tuple(row.allowed_groups or ()),
        org_approval=row.org_approval or "none",
        org_approval_by=row.org_approval_by or "",
        org_approval_at=iso(row.org_approval_at) or "",
    )


def _validate(record: AgentRecord) -> None:
    if not AGENT_ID_RE.match(record.agent_id):
        raise AgentRegistryError("invalid_agent", "agent_id must match [A-Za-z0-9._-]{1,64}")
    if not record.owner.strip():
        raise AgentRegistryError("invalid_agent", "owner is required")
    if not TEAM_RE.match(record.team):
        raise AgentRegistryError("invalid_agent", "team must match [A-Za-z0-9._-]{1,64}")
    if record.status not in AGENT_STATUSES:
        raise AgentRegistryError("invalid_agent", f"status must be one of {list(AGENT_STATUSES)}")
    if record.lifecycle not in LIFECYCLES:
        raise AgentRegistryError("invalid_agent", f"lifecycle must be one of {list(LIFECYCLES)}")


class DbAgentRegistry:
    def __init__(self, db: Database):
        self.db = db
        self._seen: dict[str, tuple[float, frozenset[str]]] = {}
        self._lock = threading.Lock()

    # -- reads -------------------------------------------------------------------------------

    def get(self, agent_id: str) -> AgentRecord | None:
        with self.db.session() as s:
            row = s.get(AgentRow, agent_id)
            return _record(row) if row else None

    def all(self) -> list[AgentRecord]:
        with self.db.session() as s:
            return [_record(r) for r in s.scalars(select(AgentRow).order_by(AgentRow.agent_id))]

    def is_empty(self) -> bool:
        with self.db.session() as s:
            return (s.scalar(select(func.count()).select_from(AgentRow)) or 0) == 0

    # -- mutations ---------------------------------------------------------------------------

    def _insert(self, s, record: AgentRecord) -> AgentRow:
        now = utcnow()
        row = AgentRow(
            agent_id=record.agent_id, name=record.name or "", description=record.description or "",
            team=record.team, owner=record.owner, status=record.status, shared=record.shared,
            builtin=record.builtin or record.agent_id in BUILTIN_IDS, status_reason=record.status_reason or "",
            status_changed_at=None, fiddler_application_id=record.fiddler_application_id or None,
            last_seen_at=None, hosts_seen=list(record.hosts_seen), created_at=now, updated_at=now,
            lifecycle=record.lifecycle, lifecycle_changed_at=None, tags=list(record.tags),
            docs_url=record.docs_url or None, data_classification=record.data_classification or None,
            visibility=record.visibility, allowed_groups=list(record.allowed_groups),
            org_approval=record.org_approval,
        )
        s.add(row)
        return row

    def register(self, record: AgentRecord) -> AgentRecord:
        _validate(record)
        try:
            with self.db.session() as s:
                if s.get(AgentRow, record.agent_id) is not None:
                    raise AgentRegistryError("agent_exists", f"agent {record.agent_id!r} is already registered")
                row = self._insert(s, record)
                s.flush()
                return _record(row)
        except IntegrityError:  # concurrent registration of the same id
            raise AgentRegistryError("agent_exists", f"agent {record.agent_id!r} is already registered") from None

    def set_status(self, agent_id: str, status: AgentStatus, reason: str = "") -> AgentRecord:
        if status not in AGENT_STATUSES:
            raise AgentRegistryError("invalid_agent", f"status must be one of {list(AGENT_STATUSES)}")
        with self.db.session() as s:
            row = s.get(AgentRow, agent_id, with_for_update=True)
            if row is None:
                raise AgentRegistryError("agent_not_found", f"agent {agent_id!r} is not registered")
            if row.status != status:  # idempotent: keep the original reason and timestamp
                now = utcnow().replace(microsecond=0)
                row.status, row.status_reason, row.status_changed_at, row.updated_at = status, reason[:500], now, now
            s.flush()
            return _record(row)

    def update(self, agent_id: str, *, name: str | None = None, description: str | None = None,
               owner: str | None = None, tags: list[str] | None = None, docs_url: str | None = None,
               data_classification: str | None = None) -> AgentRecord:
        with self.db.session() as s:
            row = s.get(AgentRow, agent_id, with_for_update=True)
            if row is None:
                raise AgentRegistryError("agent_not_found", f"agent {agent_id!r} is not registered")
            if owner is not None and not owner.strip():
                raise AgentRegistryError("invalid_agent", "owner is required")
            for field, value in (("name", name), ("description", description), ("owner", owner)):
                if value is not None:
                    setattr(row, field, value.strip() if field != "description" else value)
            if tags is not None:
                row.tags = list(dict.fromkeys(tags))
            if docs_url is not None:
                row.docs_url = docs_url.strip() or None
            if data_classification is not None:
                row.data_classification = data_classification or None
            row.updated_at = utcnow()
            s.flush()
            return _record(row)

    def set_lifecycle(self, agent_id: str, lifecycle: Lifecycle) -> AgentRecord:
        """Set the lifecycle (transition rules are checked by the caller; idempotent)."""
        if lifecycle not in LIFECYCLES:
            raise AgentRegistryError("invalid_agent", f"lifecycle must be one of {list(LIFECYCLES)}")
        with self.db.session() as s:
            row = s.get(AgentRow, agent_id, with_for_update=True)
            if row is None:
                raise AgentRegistryError("agent_not_found", f"agent {agent_id!r} is not registered")
            if row.lifecycle != lifecycle:
                now = utcnow().replace(microsecond=0)
                row.lifecycle, row.lifecycle_changed_at, row.updated_at = lifecycle, now, now
            s.flush()
            return _record(row)

    def set_access(self, agent_id: str, *, visibility: str, allowed_groups: list[str], org_approval: str,
                   org_approval_by: str | None = None) -> AgentRecord:
        with self.db.session() as s:
            row = s.get(AgentRow, agent_id, with_for_update=True)
            if row is None:
                raise AgentRegistryError("agent_not_found", f"agent {agent_id!r} is not registered")
            row.visibility, row.allowed_groups, row.org_approval = visibility, list(allowed_groups), org_approval
            if org_approval_by is not None:
                row.org_approval_by, row.org_approval_at = org_approval_by, utcnow().replace(microsecond=0)
            row.updated_at = utcnow()
            s.flush()
            return _record(row)

    def set_fiddler_application_id(self, agent_id: str, application_id: str) -> None:
        with self.db.session() as s:
            row = s.get(AgentRow, agent_id)
            if row is not None and application_id:
                row.fiddler_application_id = str(application_id)[:128]
                row.updated_at = utcnow()

    def touch(self, agent_id: str, host: str | None = None) -> None:
        """Record that the agent was seen (throttled). Never raises."""
        host = (host or "").strip()[:32]
        now = time.monotonic()
        with self._lock:
            last, hosts = self._seen.get(agent_id, (0.0, frozenset()))
            if now - last < TOUCH_INTERVAL_SECONDS and (not host or host in hosts):
                return
            self._seen[agent_id] = (now, hosts | ({host} if host else set()))
        try:
            with self.db.session() as s:
                row = s.get(AgentRow, agent_id)
                if row is None:
                    return
                row.last_seen_at = utcnow()
                seen = list(row.hosts_seen or [])
                if host and host not in seen:
                    row.hosts_seen = (seen + [host])[-MAX_HOSTS:]
        except Exception as exc:  # telemetry only: never break a model call or the webhook
            log.warning("agent last_seen update failed for %s: %s", agent_id, type(exc).__name__)

    # -- seeding -----------------------------------------------------------------------------

    def ensure_builtins(self) -> None:
        with self.db.session() as s:
            for rec in BUILTIN_AGENTS:
                row = s.get(AgentRow, rec.agent_id)
                if row is None:
                    self._insert(s, rec)
                elif not row.builtin:
                    row.builtin = True

    def import_records(self, records: dict[str, AgentRecord] | list[AgentRecord], *, update: bool = False) -> dict[str, int]:
        """Import (seed) registry entries. Existing ids are skipped unless ``update``."""
        counts = {"created": 0, "updated": 0, "skipped": 0}
        items = list(records.values()) if isinstance(records, dict) else list(records)
        with self.db.session() as s:
            for rec in items:
                _validate(rec)
                row = s.get(AgentRow, rec.agent_id)
                if row is None:
                    row = self._insert(s, rec)
                    if rec.status != "active":
                        row.status_changed_at = utcnow().replace(microsecond=0)
                    counts["created"] += 1
                elif update:
                    row.owner, row.team, row.shared = rec.owner, rec.team, rec.shared
                    row.description = rec.description or row.description
                    row.name = rec.name or row.name
                    if row.status != rec.status:
                        row.status, row.status_reason = rec.status, rec.status_reason or "import"
                        row.status_changed_at = utcnow().replace(microsecond=0)
                    row.updated_at = utcnow()
                    counts["updated"] += 1
                else:
                    counts["skipped"] += 1
        return counts


# --- versions (registry v2) ---------------------------------------------------------------------


def _version(row: AgentVersionRow) -> AgentVersion:
    return AgentVersion(
        id=row.id, agent_id=row.agent_id, version=row.version, env=row.env, kind=row.kind,
        endpoint=row.endpoint, runtime_arn=row.runtime_arn, qualifier=row.qualifier, protocol=row.protocol,
        input_schema=row.input_schema, output_schema=row.output_schema,
        auth=dict(row.auth or {"type": "none", "secret_arn": None}), git_sha=row.git_sha,
        image_digest=row.image_digest, verification_status=row.verification_status or "unverified",
        verified_at=iso(row.verified_at) or "", verification=row.verification, status=row.status,
        created_by=row.created_by, created_at=iso(row.created_at) or "", updated_at=iso(row.updated_at) or "",
    )


VERSION_FIELDS = ("kind", "endpoint", "runtime_arn", "qualifier", "protocol", "input_schema", "output_schema",
                  "auth", "git_sha", "image_digest")


class DbAgentVersions:
    """agent_versions store. Field validation happens in the route (``versions_api``); this class
    only persists. ``upsert`` is idempotent for deploy re-runs: the same (agent, env, version)
    replaces the endpoint/schema and resets verification unless ``verification`` is given."""

    def __init__(self, db: Database):
        self.db = db

    def list(self, agent_id: str, *, env: str | None = None, include_retired: bool = True) -> list[AgentVersion]:
        with self.db.session() as s:
            q = select(AgentVersionRow).where(AgentVersionRow.agent_id == agent_id)
            if env:
                q = q.where(AgentVersionRow.env == env)
            if not include_retired:
                q = q.where(AgentVersionRow.status == "active")
            rows = s.scalars(q.order_by(AgentVersionRow.created_at.desc(), AgentVersionRow.version.desc()))
            return [_version(r) for r in rows]

    def by_agents(self, agent_ids: list[str]) -> dict[str, list[AgentVersion]]:
        """Active versions of many agents (newest first), for the catalog."""
        out: dict[str, list[AgentVersion]] = {a: [] for a in agent_ids}
        if not agent_ids:
            return out
        with self.db.session() as s:
            rows = s.scalars(
                select(AgentVersionRow)
                .where(AgentVersionRow.agent_id.in_(agent_ids), AgentVersionRow.status == "active")
                .order_by(AgentVersionRow.created_at.desc(), AgentVersionRow.version.desc())
            )
            for r in rows:
                out[r.agent_id].append(_version(r))
        return out

    def get(self, agent_id: str, version: str, env: str) -> AgentVersion | None:
        with self.db.session() as s:
            row = s.scalar(select(AgentVersionRow).where(
                AgentVersionRow.agent_id == agent_id, AgentVersionRow.env == env, AgentVersionRow.version == version))
            return _version(row) if row else None

    def find(self, agent_id: str, version: str) -> list[AgentVersion]:
        """The version in every environment it exists in."""
        with self.db.session() as s:
            rows = s.scalars(select(AgentVersionRow).where(
                AgentVersionRow.agent_id == agent_id, AgentVersionRow.version == version))
            return [_version(r) for r in rows]

    def upsert(self, agent_id: str, version: str, env: str, *, fields: dict, created_by: str,
               verification: dict | None = None) -> tuple[AgentVersion, bool]:
        """Create or replace; returns (version, created)."""
        now = utcnow()
        with self.db.session() as s:
            row = s.scalar(select(AgentVersionRow).where(
                AgentVersionRow.agent_id == agent_id, AgentVersionRow.env == env,
                AgentVersionRow.version == version).with_for_update())
            created = row is None
            if created:
                row = AgentVersionRow(id=str(uuid.uuid4()), agent_id=agent_id, version=version, env=env,
                                      created_by=created_by, created_at=now)
                s.add(row)
            for key in VERSION_FIELDS:
                setattr(row, key, fields.get(key))
            row.protocol = fields.get("protocol") or "aig-http/1"
            row.auth = fields.get("auth") or {"type": "none", "secret_arn": None}
            row.status = "active"
            row.updated_at = now
            if verification is not None:
                row.verification_status = "passed" if verification.get("passed") else "failed"
                row.verified_at = now if verification.get("passed") else None
                row.verification = verification
            else:
                row.verification_status, row.verified_at, row.verification = "unverified", None, None
            s.flush()
            return _version(row), created

    def record_verification(self, agent_id: str, version: str, env: str, result: dict) -> AgentVersion:
        with self.db.session() as s:
            row = s.scalar(select(AgentVersionRow).where(
                AgentVersionRow.agent_id == agent_id, AgentVersionRow.env == env,
                AgentVersionRow.version == version).with_for_update())
            if row is None:
                raise AgentRegistryError("version_not_found", f"version {version!r} ({env}) is not registered")
            now = utcnow()
            row.verification_status = "passed" if result.get("passed") else "failed"
            if result.get("passed"):
                row.verified_at = now
            row.verification = result
            row.updated_at = now
            s.flush()
            return _version(row)

    def set_status(self, agent_id: str, version: str, env: str, status: str) -> AgentVersion:
        with self.db.session() as s:
            row = s.scalar(select(AgentVersionRow).where(
                AgentVersionRow.agent_id == agent_id, AgentVersionRow.env == env,
                AgentVersionRow.version == version).with_for_update())
            if row is None:
                raise AgentRegistryError("version_not_found", f"version {version!r} ({env}) is not registered")
            row.status, row.updated_at = status, utcnow()
            s.flush()
            return _version(row)
