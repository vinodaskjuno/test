"""Pluggable user directory: maps an authenticated email to tier/team."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import yaml

from .errors import StartupError

log = logging.getLogger(__name__)
EXAMPLE_USERS_FILE = "users.example.yaml"
# Same values as backend/contracts/metadata.schema.json (user_tier enum, team pattern).
USER_TIERS: tuple[str, ...] = ("premium", "standard", "free")
# Cost-based routing (metadata.cost_mode): economy | balanced | quality. Set per user, per team
# (`teams: {<team>: {cost_mode}}`) or directory-wide (`default_cost_mode`); default balanced.
# The Portkey config combines it with user_tier (the tier caps the model, the cost mode picks within it).
COST_MODES: tuple[str, ...] = ("economy", "balanced", "quality")
DEFAULT_COST_MODE = "balanced"
TEAM_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
# Portal roles (Phase 4). Everyone is a "user"; "admin" manages the registries, "approver" signs off
# model approvals/promotions. The service token acts as the separate role "service" (authz.py).
USER_ROLES: tuple[str, ...] = ("user", "admin", "approver")
DEFAULT_ROLES: tuple[str, ...] = ("user",)


def normalize_roles(roles) -> tuple[str, ...]:
    """Valid roles in USER_ROLES order, always including "user"."""
    given = set(roles or ()) | {"user"}
    return tuple(r for r in USER_ROLES if r in given)


def role_problems(roles) -> list[str]:
    if roles is None:
        return []
    if not isinstance(roles, list) or not roles:
        return [f"roles must be a non-empty list drawn from {list(USER_ROLES)}"]
    bad = [r for r in roles if r not in USER_ROLES]
    return [f"roles {bad!r} must be drawn from {list(USER_ROLES)}"] if bad else []


GROUP_RE = re.compile(r"^[A-Za-z0-9 ._@:-]{1,128}$")


@dataclass(frozen=True)
class UserProfile:
    email: str
    name: str
    team: str
    user_tier: str
    roles: tuple[str, ...] = DEFAULT_ROLES
    # Directory groups (local dev auth has no Entra token, so users.yaml can declare groups;
    # merged with the token's groups claim by authz.Caller).
    groups: tuple[str, ...] = ()
    cost_mode: str = DEFAULT_COST_MODE
    # Usage-limit overrides from the directory (team, then user), merged over the tier defaults by
    # platform_api.usage_limits: {"daily": {"tokens"|"cost_usd"|"requests": n}, "monthly": {...}}.
    limits: dict | None = None


LIMIT_PERIODS = ("daily", "monthly")
LIMIT_METRICS = ("tokens", "cost_usd", "requests")


def limits_problems(value) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, dict):
        return ["limits must be a mapping of daily/monthly -> {tokens, cost_usd, requests}"]
    problems = []
    for period, metrics in value.items():
        if period not in LIMIT_PERIODS or not isinstance(metrics, dict):
            problems.append(f"limits.{period} must be one of {list(LIMIT_PERIODS)} mapping to metrics")
            continue
        for metric, n in metrics.items():
            if metric not in LIMIT_METRICS or isinstance(n, bool) or not isinstance(n, (int, float)) or n < 0:
                problems.append(f"limits.{period}.{metric} must be one of {list(LIMIT_METRICS)} with a number >= 0")
    return problems


def merge_limits(*layers: dict | None) -> dict | None:
    """Later layers override earlier ones metric by metric."""
    out: dict[str, dict] = {}
    for layer in layers:
        for period, metrics in (layer or {}).items():
            if isinstance(metrics, dict):
                out.setdefault(period, {}).update(metrics)
    return out or None


def cost_mode_problems(value) -> list[str]:
    if value is None or value in COST_MODES:
        return []
    return [f"cost_mode {value!r} must be one of {list(COST_MODES)}"]


def group_problems(groups) -> list[str]:
    if groups is None:
        return []
    if not isinstance(groups, list) or not all(isinstance(g, str) and GROUP_RE.match(g) for g in groups):
        return ["groups must be a list of group ids/names matching [A-Za-z0-9 ._@:-]{1,128}"]
    return []


class UserDirectory(Protocol):
    def lookup(self, email: str, name: str | None = None) -> UserProfile: ...


def validate_user_directory(data: dict | None) -> list[str]:
    """Problems in a user-directory document (tier must be premium|standard|free, team a slug,
    optional roles drawn from user|admin|approver).

    Values end up in x-portkey-metadata, so they must satisfy backend/contracts/metadata.schema.json.
    """
    problems: list[str] = []
    data = data or {}
    if not isinstance(data, dict):
        return ["user directory must be a mapping with a 'users' key"]
    default_team = data.get("default_team", "unassigned")
    if not TEAM_RE.match(str(default_team)):
        problems.append(f"default_team {default_team!r} must match [A-Za-z0-9._-]{{1,64}}")
    problems += cost_mode_problems(data.get("default_cost_mode"))
    teams = data.get("teams") or {}
    if not isinstance(teams, dict):
        problems.append("'teams' must be a mapping of team -> {cost_mode}")
    else:
        for team, entry in teams.items():
            if not TEAM_RE.match(str(team)) or not isinstance(entry, dict):
                problems.append(f"team {team!r}: must be a slug mapping to {{cost_mode}}")
                continue
            problems += [f"team {team!r}: {p}" for p in cost_mode_problems(entry.get("cost_mode"))]
            problems += [f"team {team!r}: {p}" for p in limits_problems(entry.get("limits"))]
    users = data.get("users") or {}
    if not isinstance(users, dict):
        return problems + ["'users' must be a mapping of email -> {name, team, tier}"]
    for email, entry in users.items():
        if not isinstance(entry, dict):
            problems.append(f"user {email!r}: entry must be a mapping")
            continue
        tier, team = entry.get("tier"), entry.get("team")
        if tier not in USER_TIERS:
            problems.append(f"user {email!r}: tier {tier!r} must be one of {list(USER_TIERS)}")
        if team is None or not str(team).strip() or not TEAM_RE.match(str(team)):
            problems.append(f"user {email!r}: team {team!r} must be a non-empty [A-Za-z0-9._-]{{1,64}} slug")
        problems += [f"user {email!r}: {p}" for p in role_problems(entry.get("roles"))]
        problems += [f"user {email!r}: {p}" for p in group_problems(entry.get("groups"))]
        problems += [f"user {email!r}: {p}" for p in cost_mode_problems(entry.get("cost_mode"))]
        problems += [f"user {email!r}: {p}" for p in limits_problems(entry.get("limits"))]
    return problems


class YamlUserDirectory:
    """Default directory backed by a YAML file (see config/users.example.yaml)."""

    def __init__(self, data: dict | None, default_user_tier: str):
        data = data or {}
        self.default_user_tier = default_user_tier
        self.default_team = str(data.get("default_team", "unassigned"))
        dcm = data.get("default_cost_mode")
        self.default_cost_mode = dcm if dcm in COST_MODES else DEFAULT_COST_MODE
        teams = data.get("teams") if isinstance(data.get("teams"), dict) else {}
        self._team_cost = {
            str(t): e["cost_mode"] for t, e in teams.items() if isinstance(e, dict) and e.get("cost_mode") in COST_MODES
        }
        self._team_limits = {
            str(t): e["limits"] for t, e in teams.items() if isinstance(e, dict) and e.get("limits") and not limits_problems(e.get("limits"))
        }
        self._users = {str(k).lower(): (v or {}) for k, v in (data.get("users") or {}).items()}

    @classmethod
    def from_file(cls, path: Path | None, default_user_tier: str, env: str = "local") -> "YamlUserDirectory":
        """Load and validate. Invalid entries: StartupError outside local; in local a warning
        and the invalid entries are dropped (those users get the defaults)."""
        data = yaml.safe_load(path.read_text()) if path and Path(path).is_file() else {}
        problems = validate_user_directory(data)
        if problems:
            detail = "; ".join(problems)
            name = Path(path).name if path else "<none>"
            if env != "local":
                raise StartupError(f"refusing to start in AIG_ENV={env}: invalid user directory {name}: {detail}")
            log.warning("AIG_ENV=local: ignoring invalid user directory entries in %s: %s", name, detail)
            data = dict(data or {})
            if not TEAM_RE.match(str(data.get("default_team", "unassigned"))):
                data.pop("default_team", None)
            users = data.get("users") if isinstance(data.get("users"), dict) else {}
            if data.get("default_cost_mode") not in (None, *COST_MODES):
                data.pop("default_cost_mode", None)
            data["users"] = {
                k: v
                for k, v in users.items()
                if isinstance(v, dict)
                and v.get("tier") in USER_TIERS
                and TEAM_RE.match(str(v.get("team") or ""))
                and not role_problems(v.get("roles"))
                and not group_problems(v.get("groups"))
                and not cost_mode_problems(v.get("cost_mode"))
                and not limits_problems(v.get("limits"))
            }
        return cls(data, default_user_tier)

    def lookup(self, email: str, name: str | None = None) -> UserProfile:
        entry = self._users.get(email.lower(), {})
        team = str(entry.get("team") or self.default_team)
        cost_mode = entry.get("cost_mode") if entry.get("cost_mode") in COST_MODES else self._team_cost.get(team, self.default_cost_mode)
        return UserProfile(
            email=email,
            name=str(entry.get("name") or name or email),
            team=team,
            user_tier=str(entry.get("tier") or self.default_user_tier),
            roles=normalize_roles(entry.get("roles")),
            groups=tuple(sorted(set(entry.get("groups") or ()))),
            cost_mode=cost_mode,
            limits=merge_limits(self._team_limits.get(team), entry.get("limits") if not limits_problems(entry.get("limits")) else None),
        )


def resolve_users_file(env: str, config_dir: Path, users_file: Path | None = None) -> Path | None:
    """Pick the user directory file.

    Order: AIG_USERS_FILE, then config/users.yaml. config/users.example.yaml (which
    grants sample premium tiers) is used only in AIG_ENV=local. Outside local, a
    missing directory returns None, so every user gets default_user_tier.
    """
    if users_file:
        path = Path(users_file)
        if env != "local" and path.name == EXAMPLE_USERS_FILE:
            log.warning("AIG_USERS_FILE points at %s, which is ignored in AIG_ENV=%s", EXAMPLE_USERS_FILE, env)
            return None
        if not path.is_file():
            log.warning("AIG_USERS_FILE=%s does not exist; all users get default_user_tier", path)
            return None
        return path
    real = Path(config_dir) / "users.yaml"
    if real.is_file():
        return real
    if env == "local":
        return Path(config_dir) / EXAMPLE_USERS_FILE
    log.warning(
        "AIG_ENV=%s: no user directory (set AIG_USERS_FILE or create config/users.yaml); "
        "all users get default_user_tier",
        env,
    )
    return None
