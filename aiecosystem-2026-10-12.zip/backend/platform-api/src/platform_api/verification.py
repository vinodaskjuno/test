"""Version verification: "no gateway, no Fiddler, no agent" for agents registered by hand.

``POST /api/v1/agents/{id}/versions/{version}/verify`` runs, in order:

1. ``health``: ``GET {endpoint}/ping`` (kind https; AgentCore runtimes are health-managed by
   AgentCore, so the check is ``skipped`` and the test invocation covers it);
2. ``invocation``: a real test invocation through the invoker (record ``purpose=verify``);
3. ``gateway``: the Portkey agent-check webhook saw this agent id recently: ``last_seen_at``
   within ``AIG_AGENT_VERIFY_SEEN_WINDOW_SECONDS`` (default 300) - the agent called a model through
   the gateway with its own agent id;
4. ``trace``: a pluggable Fiddler trace check (``AIG_AGENT_TRACE_CHECK=module:function``, same
   plug-in mechanism as ``AIG_AGENT_HOOKS``)::

       def check_trace(agent: dict, *, env, version, invocation_id, trace_id, since,
                       fiddler_url, fiddler_api_key) -> bool | {"found": bool, "detail": str}

   Not configured: the check reports ``not_configured`` and fails the verification when
   ``AIG_AGENT_VERIFY_REQUIRE_TRACE`` is true (default: true outside local/dev), else ``skipped``.

The result is stored on the version (``verification_status``, ``verified_at``, ``verification``) and
audited (``agent.version.verify``). A passing **prod** verification activates a draft agent unless
the body says ``activate: false``.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from .agents import lifecycle_transition_allowed
from .db import add_audit, utcnow
from .invoker import InvocationError

log = logging.getLogger(__name__)


def _parse_iso(value: str) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def default_test_body(input_schema: dict | None) -> dict | None:
    if not input_schema:
        return {"messages": [{"role": "user", "content": "ping"}]}
    examples = input_schema.get("examples")
    if isinstance(examples, list) and examples and isinstance(examples[0], dict):
        return {"input": examples[0]}
    return None


def trace_required(settings: Any) -> bool:
    if settings.agent_verify_require_trace is not None:
        return bool(settings.agent_verify_require_trace)
    return settings.env not in ("local", "dev")


async def _trace_check(state: Any, agent: Any, version: Any, *, invocation_id: str, trace_id: str,
                       since: datetime) -> dict:
    hook = getattr(state, "agent_trace_check", None)
    if hook is None:
        required = trace_required(state.settings)
        return {"name": "trace", "status": "failed" if required else "skipped",
                "detail": "not_configured: no trace check (AIG_AGENT_TRACE_CHECK) is configured"
                          + ("; required in this environment (AIG_AGENT_VERIFY_REQUIRE_TRACE)" if required else "")}
    kwargs = {"env": version.env, "version": version.version, "invocation_id": invocation_id, "trace_id": trace_id,
              "since": since.isoformat(timespec="seconds"), "fiddler_url": state.env_config.fiddler_url,
              "fiddler_api_key": state.secrets.get("FIDDLER_API_KEY")}  # gitleaks:allow (a lookup, not a value)
    try:
        if inspect.iscoroutinefunction(hook):
            res = await hook(agent.to_dict(), **kwargs)
        else:
            res = await asyncio.to_thread(hook, agent.to_dict(), **kwargs)
    except Exception as exc:  # hooks get keys: never log their values or exception text
        log.warning("trace check failed for %s: %s", agent.agent_id, type(exc).__name__)
        return {"name": "trace", "status": "failed", "detail": f"trace check raised {type(exc).__name__}"}
    found = res if isinstance(res, bool) else bool(isinstance(res, dict) and res.get("found"))
    detail = res.get("detail") if isinstance(res, dict) and isinstance(res.get("detail"), str) else None
    return {"name": "trace", "status": "passed" if found else "failed",
            "detail": (detail or ("Fiddler trace found" if found else "no Fiddler trace for this invocation"))[:300]}


async def verify_version(state: Any, caller: Any, agent_id: str, version: str, env: str, body: dict | None, *,
                         activate: bool | None = None) -> dict:
    invoker, registry, versions = state.invoker, state.agents, state.agent_versions
    target = versions.get(agent_id, version, env)
    if target is None:
        raise InvocationError("version_not_found", 404, f"version {version!r} ({env}) is not registered")
    test_body = body if body else default_test_body(target.input_schema)
    if test_body is None:
        raise InvocationError("input_invalid", 400, "this version declares an input_schema: give a test input "
                              "(body.input) or add 'examples' to the schema")
    started = utcnow()
    checks: list[dict] = []
    if target.kind == "https":
        ok, detail = await invoker.https.ping(target)
        checks.append({"name": "health", "status": "passed" if ok else "failed", "detail": detail})
    else:
        checks.append({"name": "health", "status": "skipped",
                       "detail": "AgentCore manages runtime health; the test invocation covers it"})

    plan = invoker.prepare(caller, agent_id, test_body, env=env, version=version, mode="sync", purpose="verify")
    handle = invoker.open(plan, actor=caller.email)
    outcome = await invoker.run_to_end(handle)
    if outcome.error is None:
        checks.append({"name": "invocation", "status": "passed",
                       "detail": f"test invocation succeeded in {outcome.duration_ms} ms"})
    else:
        checks.append({"name": "invocation", "status": "failed",
                       "detail": f"{outcome.error.code}: {outcome.error.message}"[:300]})

    window = float(state.settings.agent_verify_seen_window_seconds)
    agent = registry.get(agent_id)
    seen = _parse_iso(agent.last_seen_at if agent else "")
    if seen is not None and seen >= utcnow() - timedelta(seconds=window):
        checks.append({"name": "gateway", "status": "passed", "detail": f"agent-check saw {agent_id} at {agent.last_seen_at}"})
    else:
        checks.append({"name": "gateway", "status": "failed",
                       "detail": f"the gateway agent-check has not seen {agent_id} in the last {int(window)} s: the "
                                 f"agent must call models through Portkey with its own agent id (agent mode)"})
    checks.append(await _trace_check(state, agent, target, invocation_id=handle.id, trace_id=handle.call.trace_id,
                                     since=started))

    passed = all(c["status"] in ("passed", "skipped") for c in checks)
    result = {"passed": passed, "code": None if passed else "verification_failed", "checks": checks,
              "invocation_id": handle.id, "trace_id": handle.call.trace_id,
              "at": utcnow().isoformat(timespec="seconds"), "by": caller.email, "source": "verify"}
    updated = versions.record_verification(agent_id, version, env, result)
    activated = False
    should_activate = activate if activate is not None else env == "prod"
    if passed and should_activate and agent is not None and agent.lifecycle == "draft" \
            and lifecycle_transition_allowed("draft", "active"):
        registry.set_lifecycle(agent_id, "active")
        activated = True
    try:
        with state.db.session() as s:
            add_audit(s, actor=caller.email, action="agent.version.verify", entity_type="agent", entity_id=agent_id,
                      details={"version": version, "env": env, "passed": passed, "invocation_id": handle.id,
                               "checks": {c["name"]: c["status"] for c in checks}})
            if activated:
                add_audit(s, actor=caller.email, action="agent.lifecycle", entity_type="agent", entity_id=agent_id,
                          details={"from": "draft", "to": "active", "source": "verify"})
    except Exception as exc:
        log.error("audit write failed for verify %s: %s", agent_id, type(exc).__name__)
    return {"passed": passed, "code": result["code"], "checks": checks, "invocation_id": handle.id,
            "trace_id": handle.call.trace_id, "activated": activated, "version": updated}
