"""Streaming secret redaction shared by the WebSocket chat and agent invocations."""

from __future__ import annotations

from .routes.llm import redact_text


class TextRedactor:
    """Redacts secrets from a stream of text deltas, even if a secret straddles deltas.

    Only the longest buffer suffix that could still be the start of a secret is held
    back until more text arrives, so ordinary text streams through without delay.
    """

    def __init__(self, secrets: list[str]):
        self.secrets = [s for s in secrets if s]
        self.buf = ""

    def _held(self) -> int:
        best = 0
        for s in self.secrets:
            for n in range(min(len(s) - 1, len(self.buf)), best, -1):
                if self.buf.endswith(s[:n]):
                    best = n
                    break
        return best

    def feed(self, text: str) -> str:
        self.buf = redact_text(self.buf + text, self.secrets) if self.secrets else self.buf + text
        if not self.secrets:
            out, self.buf = self.buf, ""
            return out
        cut = len(self.buf) - self._held()
        out, self.buf = self.buf[:cut], self.buf[cut:]
        return out

    def flush(self) -> str:
        out, self.buf = self.buf, ""
        return out
