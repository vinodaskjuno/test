"""Agent registry: which agent ids exist, who owns them and whether they may call models.

Phase 1 uses it for the Portkey webhook guardrail (``POST /api/v1/guardrails/agent-check``),
which denies unknown or suspended agents at the gateway. Phase 4 made the database registry
(``agents_db.DbAgentRegistry``) the default; the YAML registry below remains for tests, tools and
the one-time seed/import (``aig-platform-api agents import``). Callers depend only on the
``AgentRegistry`` protocol.

Interactive surfaces have no agent of their own, so platform-api sends a pre-registered,
host-specific agent id for them (``DEFAULT_AGENT_BY_HOST``). Those built-in agents are always
present (a registry file may override them, for example to suspend ``ide.eclipse``).
"""

from __future__ import annotations

import logging
import os
import re
import tempfile
import threading
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Protocol

import yaml

from .errors import StartupError

log = logging.getLogger(__name__)

EXAMPLE_AGENTS_FILE = "agents.example.yaml"
AGENT_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
TEAM_RE = AGENT_ID_RE
AGENT_STATUSES: tuple[str, ...] = ("active", "suspended")
AgentStatus = Literal["active", "suspended"]

# --- Registry v2 (agent-record.schema.json) ---------------------------------------------------
# lifecycle is the catalog state; status (active|suspended) stays the orthogonal gateway switch.
LIFECYCLES: tuple[str, ...] = ("draft", "active", "deprecated", "retired")
Lifecycle = Literal["draft", "active", "deprecated", "retired"]
LIFECYCLE_TRANSITIONS: dict[str, frozenset[str]] = {
    "draft": frozenset({"active", "retired"}),
    "active": frozenset({"deprecated", "retired"}),
    "deprecated": frozenset({"active", "retired"}),
    "retired": frozenset(),
}
# Environments (platform-api AIG_ENV) in which the gateway lets draft agents call models, so
# developers can run an agent before its first deploy. Elsewhere drafts are denied (agent_draft).
DRAFT_GATEWAY_ENVS: frozenset[str] = frozenset({"local", "dev"})
VISIBILITIES: tuple[str, ...] = ("team", "groups", "org")
ORG_APPROVALS: tuple[str, ...] = ("none", "pending", "approved", "rejected")
DATA_CLASSIFICATIONS: tuple[str, ...] = ("public", "internal", "confidential", "restricted")
TAG_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,31}$")
GROUP_RE = re.compile(r"^[A-Za-z0-9 ._@:-]{1,128}$")
MAX_TAGS = 20
MAX_ALLOWED_GROUPS = 50

# Interactive host -> the agent id platform-api sends when the client sends no x-aig-agent-id.
# The web portal is detected by Origin; Eclipse by its built-in agent id (HOST_BY_BUILTIN_AGENT).
DEFAULT_AGENT_BY_HOST: dict[str, str] = {
    "vscode": "ide.vscode",
    "eclipse": "ide.eclipse",
    "web": "web.portal",
}
# Reverse map: a client that sends a built-in IDE agent id is that host (e.g. Eclipse sends ide.eclipse).
HOST_BY_BUILTIN_AGENT: dict[str, str] = {agent: host for host, agent in DEFAULT_AGENT_BY_HOST.items()}
PLATFORM_TEAM = "aig-platform"
PLATFORM_OWNER = "platform-team@aig.example.com"
BUILTIN_NAMES: dict[str, str] = {
    "ide.vscode": "VS Code extension",
    "ide.eclipse": "Eclipse plugin",
    "web.portal": "Web portal",
}


def default_agent_for_host(host: str) -> str:
    try:
        return DEFAULT_AGENT_BY_HOST[host]
    except KeyError:
        raise ValueError(f"no default agent for host {host!r}") from None


@dataclass(frozen=True)
class AgentRecord:
    agent_id: str
    owner: str
    team: str
    status: AgentStatus = "active"
    # Shared agents (the IDE/web surfaces) may be used by any team; others only by their team.
    shared: bool = False
    description: str = ""
    # Why the status was last changed (for example "reconciliation: gateway traffic without
    # Fiddler traces") and when (ISO 8601 UTC). Empty for agents never suspended.
    status_reason: str = ""
    status_changed_at: str = ""
    # Phase 4 (database registry). Empty strings / () when unknown; the API renders them as null / [].
    name: str = ""
    builtin: bool = False
    created_at: str = ""
    updated_at: str = ""
    last_seen_at: str = ""
    hosts_seen: tuple[str, ...] = ()
    fiddler_application_id: str = ""
    # Registry v2. Defaults describe an agent registered before v2 (usable, team-only).
    lifecycle: Lifecycle = "active"
    lifecycle_changed_at: str = ""
    tags: tuple[str, ...] = ()
    docs_url: str = ""
    data_classification: str = ""
    visibility: str = "team"
    allowed_groups: tuple[str, ...] = ()
    org_approval: str = "none"
    org_approval_by: str = ""
    org_approval_at: str = ""

    @property
    def active(self) -> bool:
        """Gateway status (not the lifecycle): False once suspended."""
        return self.status == "active"

    def to_dict(self) -> dict:
        d = asdict(self)
        for key in ("hosts_seen", "tags", "allowed_groups"):
            d[key] = list(getattr(self, key))
        return d


VERSION_ENVS: tuple[str, ...] = ("local", "dev", "stage", "prod")
VERSION_KINDS: tuple[str, ...] = ("agentcore", "https")
AUTH_TYPES: tuple[str, ...] = ("none", "api_key", "oauth_client_credentials")
PROTOCOL = "aig-http/1"
VERSION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$")


@dataclass(frozen=True)
class AgentVersion:
    """One deployable version of an agent in one environment (agent_versions row). ``auth`` holds
    only ``{"type", "secret_arn"}``: a reference, never a secret value."""

    id: str
    agent_id: str
    version: str
    env: str
    kind: str
    endpoint: str | None = None
    runtime_arn: str | None = None
    qualifier: str | None = None
    protocol: str = PROTOCOL
    input_schema: dict | None = None
    output_schema: dict | None = None
    auth: dict = field(default_factory=lambda: {"type": "none", "secret_arn": None})
    git_sha: str | None = None
    image_digest: str | None = None
    verification_status: str = "unverified"
    verified_at: str = ""
    verification: dict | None = None
    status: str = "active"
    created_by: str = ""
    created_at: str = ""
    updated_at: str = ""

    @property
    def verified(self) -> bool:
        return self.verification_status == "passed"

    @property
    def usable(self) -> bool:
        return self.status == "active"

    def to_dict(self) -> dict:
        return asdict(self)


def gateway_denial(agent: AgentRecord, env: str | None) -> str | None:
    """Why the gateway agent-check must deny this registered agent (None = allowed).

    ``suspended`` keeps today's behaviour; ``retired`` is always denied; ``draft`` passes only when
    platform-api runs in ``DRAFT_GATEWAY_ENVS`` (local, dev). ``env`` None (pure callers such as
    the gateway simulator) treats drafts like ``local``."""
    if not agent.active:
        return "agent_suspended"
    if agent.lifecycle == "retired":
        return "agent_retired"
    if agent.lifecycle == "draft" and (env or "local") not in DRAFT_GATEWAY_ENVS:
        return "agent_draft"
    return None


def lifecycle_transition_allowed(current: str, target: str) -> bool:
    return target in LIFECYCLE_TRANSITIONS.get(current, frozenset())


BUILTIN_AGENTS: tuple[AgentRecord, ...] = tuple(
    AgentRecord(
        agent_id=agent_id,
        owner=PLATFORM_OWNER,
        team=PLATFORM_TEAM,
        status="active",
        shared=True,
        description=f"Interactive {host} traffic proxied by platform-api",
        name=BUILTIN_NAMES.get(agent_id, agent_id),
        builtin=True,
    )
    for host, agent_id in DEFAULT_AGENT_BY_HOST.items()
)
BUILTIN_IDS: frozenset[str] = frozenset(DEFAULT_AGENT_BY_HOST.values())


class AgentRegistry(Protocol):
    def get(self, agent_id: str) -> AgentRecord | None: ...

    def all(self) -> list[AgentRecord]: ...


class AgentRegistryError(RuntimeError):
    """A registry mutation was refused (``code`` is the platform-api error code)."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


class MutableAgentRegistry(AgentRegistry, Protocol):
    """Registries that support registration and status changes (the YAML default does, the
    Phase 4 Postgres registry will). Used by the /api/v1/agents routes."""

    def register(self, record: AgentRecord) -> AgentRecord: ...

    def set_status(self, agent_id: str, status: AgentStatus, reason: str = "") -> AgentRecord: ...

    # Registry v2 (both shipped registries implement these; routes check with hasattr).
    def set_lifecycle(self, agent_id: str, lifecycle: Lifecycle) -> AgentRecord: ...

    def set_access(self, agent_id: str, *, visibility: str, allowed_groups: list[str], org_approval: str,
                   org_approval_by: str | None = None) -> AgentRecord: ...


def validate_agent_entries(data: dict | None) -> tuple[dict[str, AgentRecord], list[str]]:
    """Parse the YAML document; return (valid records, problems). Never raises."""
    records: dict[str, AgentRecord] = {}
    problems: list[str] = []
    data = data or {}
    if not isinstance(data, dict):
        return records, ["agents file must be a mapping with an 'agents' key"]
    entries = data.get("agents") or {}
    if not isinstance(entries, dict):
        return records, ["'agents' must be a mapping of agent_id -> {owner, team, status}"]
    for agent_id, entry in entries.items():
        agent_id = str(agent_id)
        if not AGENT_ID_RE.match(agent_id):
            problems.append(f"agent {agent_id!r}: id must match [A-Za-z0-9._-]{{1,64}}")
            continue
        if not isinstance(entry, dict):
            problems.append(f"agent {agent_id!r}: entry must be a mapping")
            continue
        owner = str(entry.get("owner") or "").strip()
        team = str(entry.get("team") or "").strip()
        status = str(entry.get("status") or "active").strip()
        lifecycle = str(entry.get("lifecycle") or "active").strip()
        bad = []
        if not owner:
            bad.append("owner is required")
        if not TEAM_RE.match(team):
            bad.append("team must match [A-Za-z0-9._-]{1,64}")
        if status not in AGENT_STATUSES:
            bad.append(f"status must be one of {list(AGENT_STATUSES)}")
        if lifecycle not in LIFECYCLES:
            bad.append(f"lifecycle must be one of {list(LIFECYCLES)}")
        if bad:
            problems.append(f"agent {agent_id!r}: " + "; ".join(bad))
            continue
        records[agent_id] = AgentRecord(
            agent_id=agent_id,
            owner=owner,
            team=team,
            status=status,  # type: ignore[arg-type]
            shared=bool(entry.get("shared", False)),
            description=str(entry.get("description") or ""),
            status_reason=str(entry.get("status_reason") or ""),
            status_changed_at=str(entry.get("status_changed_at") or ""),
            name=str(entry.get("name") or BUILTIN_NAMES.get(agent_id, "")),
            builtin=agent_id in BUILTIN_IDS,
            lifecycle=lifecycle,  # type: ignore[arg-type]
        )
    return records, problems


def read_agents_file(path: Path | None, *, env: str = "local") -> dict[str, AgentRecord]:
    """Validated records from a registry YAML file (none if ``path`` is missing). Invalid entries
    stop startup outside ``local`` (StartupError) and are skipped with a warning in ``local``."""
    if not path or not Path(path).is_file():
        return {}
    records, problems = validate_agent_entries(yaml.safe_load(Path(path).read_text()))
    if problems:
        detail = "; ".join(problems)
        if env != "local":
            raise StartupError(f"refusing to start in AIG_ENV={env}: invalid agent registry {Path(path).name}: {detail}")
        log.warning("AIG_ENV=local: ignoring invalid agent registry entries in %s: %s", Path(path).name, detail)
    return records


class YamlAgentRegistry:
    """Default registry backed by a YAML file (see config/agents.example.yaml).

    Mutations (``register``, ``set_status``) always apply in memory. They are also written back
    to the file (atomically) when the registry was loaded from a real registry file
    (``persist_path``); the ``agents.example.yaml`` sample is never rewritten. Without a
    writable file a suspension lasts until restart, which is why the Phase 4 Postgres registry
    replaces this class; the daily reconciliation re-applies suspensions every run.
    """

    def __init__(self, data: dict | None = None, *, env: str = "local", source: str = "<inline>",
                 persist_path: Path | None = None):
        records, problems = validate_agent_entries(data)
        if problems:
            detail = "; ".join(problems)
            if env != "local":
                raise StartupError(f"refusing to start in AIG_ENV={env}: invalid agent registry {source}: {detail}")
            log.warning("AIG_ENV=local: ignoring invalid agent registry entries in %s: %s", source, detail)
        self._agents: dict[str, AgentRecord] = {a.agent_id: a for a in BUILTIN_AGENTS}
        self._agents.update(records)
        # Ids written back to the file: everything the file declared plus later mutations.
        self._file_ids: set[str] = set(records)
        self._persist_path = Path(persist_path) if persist_path else None
        self._lock = threading.Lock()

    @classmethod
    def from_file(cls, path: Path | None, *, env: str = "local") -> "YamlAgentRegistry":
        if path and Path(path).is_file():
            persist = None if Path(path).name == EXAMPLE_AGENTS_FILE else Path(path)
            return cls(yaml.safe_load(Path(path).read_text()), env=env, source=Path(path).name, persist_path=persist)
        return cls(None, env=env)

    def get(self, agent_id: str) -> AgentRecord | None:
        return self._agents.get(agent_id)

    def all(self) -> list[AgentRecord]:
        return sorted(self._agents.values(), key=lambda a: a.agent_id)

    # -- mutations -------------------------------------------------------------------------

    def register(self, record: AgentRecord) -> AgentRecord:
        if not AGENT_ID_RE.match(record.agent_id):
            raise AgentRegistryError("invalid_agent", "agent_id must match [A-Za-z0-9._-]{1,64}")
        if not record.owner.strip():
            raise AgentRegistryError("invalid_agent", "owner is required")
        if not TEAM_RE.match(record.team):
            raise AgentRegistryError("invalid_agent", "team must match [A-Za-z0-9._-]{1,64}")
        if record.status not in AGENT_STATUSES:
            raise AgentRegistryError("invalid_agent", f"status must be one of {list(AGENT_STATUSES)}")
        if record.lifecycle not in LIFECYCLES:
            raise AgentRegistryError("invalid_agent", f"lifecycle must be one of {list(LIFECYCLES)}")
        with self._lock:
            if record.agent_id in self._agents:
                raise AgentRegistryError("agent_exists", f"agent {record.agent_id!r} is already registered")
            self._agents[record.agent_id] = record
            self._file_ids.add(record.agent_id)
            self._persist()
        return record

    def set_status(self, agent_id: str, status: AgentStatus, reason: str = "") -> AgentRecord:
        if status not in AGENT_STATUSES:
            raise AgentRegistryError("invalid_agent", f"status must be one of {list(AGENT_STATUSES)}")
        with self._lock:
            current = self._agents.get(agent_id)
            if current is None:
                raise AgentRegistryError("agent_not_found", f"agent {agent_id!r} is not registered")
            if current.status == status:
                return current  # idempotent: keep the original reason and timestamp
            updated = replace(
                current, status=status, status_reason=reason[:500],
                status_changed_at=datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            )
            self._agents[agent_id] = updated
            self._file_ids.add(agent_id)
            self._persist()
        return updated

    def _change(self, agent_id: str, **changes) -> AgentRecord:
        with self._lock:
            current = self._agents.get(agent_id)
            if current is None:
                raise AgentRegistryError("agent_not_found", f"agent {agent_id!r} is not registered")
            updated = replace(current, **changes, updated_at=_now_iso())
            self._agents[agent_id] = updated
            self._file_ids.add(agent_id)
            self._persist()
        return updated

    def set_lifecycle(self, agent_id: str, lifecycle: Lifecycle) -> AgentRecord:
        if lifecycle not in LIFECYCLES:
            raise AgentRegistryError("invalid_agent", f"lifecycle must be one of {list(LIFECYCLES)}")
        current = self.get(agent_id)
        if current is not None and current.lifecycle == lifecycle:
            return current
        return self._change(agent_id, lifecycle=lifecycle, lifecycle_changed_at=_now_iso())

    def set_access(self, agent_id: str, *, visibility: str, allowed_groups: list[str], org_approval: str,
                   org_approval_by: str | None = None) -> AgentRecord:
        changes: dict = {"visibility": visibility, "allowed_groups": tuple(allowed_groups), "org_approval": org_approval}
        if org_approval_by is not None:
            changes.update(org_approval_by=org_approval_by, org_approval_at=_now_iso())
        return self._change(agent_id, **changes)

    def update(self, agent_id: str, **changes) -> AgentRecord:
        clean = {k: (tuple(v) if isinstance(v, list) else v) for k, v in changes.items() if v is not None}
        return self._change(agent_id, **clean)

    def _persist(self) -> None:
        if self._persist_path is None:
            log.warning("agent registry has no writable file; the change lasts until restart")
            return
        doc: dict = {"agents": {}}
        for agent_id in sorted(self._file_ids):
            rec = self._agents[agent_id]
            entry = {"owner": rec.owner, "team": rec.team, "status": rec.status}
            if rec.shared:
                entry["shared"] = True
            if rec.lifecycle != "active":
                entry["lifecycle"] = rec.lifecycle
            for key in ("description", "status_reason", "status_changed_at"):
                if getattr(rec, key):
                    entry[key] = getattr(rec, key)
            doc["agents"][agent_id] = entry
        path = self._persist_path
        fd, tmp = tempfile.mkstemp(prefix=".agents.", suffix=".yaml", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w") as fh:
                fh.write("# Managed by platform-api (agent registration / suspension). Comments are not kept.\n")
                yaml.safe_dump(doc, fh, sort_keys=False)
            os.replace(tmp, path)
        except OSError:
            log.exception("could not write the agent registry file; the change lasts until restart")
            try:
                os.unlink(tmp)
            except OSError:
                pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def resolve_agents_file(env: str, config_dir: Path, agents_file: Path | None = None) -> Path | None:
    """Same rule as the user directory: AIG_AGENTS_FILE, then config/agents.yaml; the example
    file (which registers sample agents) is used only in AIG_ENV=local. Outside local a missing
    file leaves only the built-in IDE/web agents registered."""
    if agents_file:
        path = Path(agents_file)
        if env != "local" and path.name == EXAMPLE_AGENTS_FILE:
            log.warning("AIG_AGENTS_FILE points at %s, which is ignored in AIG_ENV=%s", EXAMPLE_AGENTS_FILE, env)
            return None
        if not path.is_file():
            log.warning("AIG_AGENTS_FILE=%s does not exist; only built-in agents are registered", path)
            return None
        return path
    real = Path(config_dir) / "agents.yaml"
    if real.is_file():
        return real
    if env == "local":
        return Path(config_dir) / EXAMPLE_AGENTS_FILE
    log.warning(
        "AIG_ENV=%s: no agent registry file (set AIG_AGENTS_FILE or create config/agents.yaml); "
        "only built-in agents (%s) are registered",
        env,
        ", ".join(DEFAULT_AGENT_BY_HOST.values()),
    )
    return None
