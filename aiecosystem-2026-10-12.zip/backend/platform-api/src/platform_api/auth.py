"""Bearer-token authentication: Entra ID / OIDC JWTs, plus a local-only dev mode."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any, Callable

import jwt
from fastapi import Request

from .errors import ApiError, StartupError

log = logging.getLogger(__name__)

DEV_PREFIX = "dev:"
_EMAIL_RE = re.compile(r"^[^@\s:]+@[^@\s:]+\.[^@\s:]+$")
ALLOWED_ALGS = ["RS256", "RS384", "RS512", "PS256", "ES256"]

KeyResolver = Callable[[str], Any]


MAX_GROUPS = 200
GROUP_MAX_LEN = 128


@dataclass(frozen=True)
class Principal:
    email: str
    name: str | None = None
    # Entra ID group claims (object ids, or names when the app registration emits them). Tokens
    # with a group overage (_claim_names instead of groups) carry none: access then falls back to
    # owner/team/org-wide, which only ever narrows what the caller may do.
    groups: tuple[str, ...] = ()


def groups_from_claims(claims: dict) -> tuple[str, ...]:
    raw = claims.get("groups")
    if not isinstance(raw, list):
        return ()
    clean = [g for g in raw if isinstance(g, str) and 0 < len(g) <= GROUP_MAX_LEN]
    return tuple(sorted(set(clean)))[:MAX_GROUPS]


def _unauthorized(message: str = "authentication required") -> ApiError:
    return ApiError(401, "unauthenticated", message, headers={"WWW-Authenticate": "Bearer"})


class Authenticator:
    def __init__(
        self,
        *,
        env: str,
        auth_mode: str,
        issuer: str,
        audience: str,
        jwks_url: str,
        key_resolver: KeyResolver | None = None,
    ):
        if auth_mode == "dev" and env != "local":
            raise StartupError(f"AIG_AUTH_MODE=dev is only allowed when AIG_ENV=local (got {env})")
        self.env = env
        self.dev_mode = auth_mode == "dev" and env == "local"
        self.issuer = issuer
        self.audience = audience
        self.jwks_url = jwks_url
        self._key_resolver = key_resolver
        self._jwks_client: jwt.PyJWKClient | None = None

    def _resolve_key(self, token: str) -> Any:
        if self._key_resolver is not None:
            return self._key_resolver(token)
        if self._jwks_client is None:
            self._jwks_client = jwt.PyJWKClient(self.jwks_url, cache_keys=True, lifespan=3600)
        return self._jwks_client.get_signing_key_from_jwt(token).key

    def verify(self, token: str) -> Principal:
        if token.startswith(DEV_PREFIX):
            if not self.dev_mode:
                raise _unauthorized("dev tokens are not accepted in this environment")
            email = token[len(DEV_PREFIX):].strip()
            if not _EMAIL_RE.match(email):
                raise _unauthorized("invalid dev token")
            return Principal(email=email, name=None)
        try:
            key = self._resolve_key(token)
            claims = jwt.decode(
                token,
                key=key,
                algorithms=ALLOWED_ALGS,
                audience=self.audience,
                issuer=self.issuer,
                options={"require": ["exp", "iss", "aud"]},
            )
        except (jwt.PyJWTError, ValueError, KeyError) as exc:
            log.info("token rejected: %s", type(exc).__name__)
            raise _unauthorized("invalid token") from None
        email = claims.get("preferred_username") or claims.get("email") or claims.get("upn")
        if not email or not isinstance(email, str):
            raise _unauthorized("token has no user identity")
        return Principal(email=email, name=claims.get("name"), groups=groups_from_claims(claims))


def principal_from_header(authenticator: Authenticator, header: str | None) -> Principal:
    """Validate an ``Authorization: Bearer <token>`` header value (HTTP and WebSocket)."""
    scheme, _, token = (header or "").partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        raise _unauthorized()
    return authenticator.verify(token.strip())


async def require_principal(request: Request) -> Principal:
    return principal_from_header(request.app.state.authenticator, request.headers.get("authorization", ""))
