"""Usage-based routing: compare a user's live Portkey usage with their limits.

Limits come from the environment config (`usage_limits`, per tier) merged with the user directory's
team and user overrides (`limits:`), per period (daily = UTC day, monthly = UTC calendar month) and
metric (tokens, cost_usd, requests). Usage is read from Portkey analytics filtered by metadata
`_user` (graphs/tokens and graphs/cost; requests from groups/model). The result's `state` goes into
x-portkey-metadata as `usage_state`, which the Portkey config `pc-aig-router` uses first:

  normal   below the soft threshold on every limit (or no limits)  -> tier / cost routing as usual
  soft     >= usage_soft_threshold (default 80%) of any limit      -> one model level lower
  hard     >= 100% of any limit                                     -> cheapest model only
  unknown  every limited metric could not be read from Portkey      -> routed like normal (fail open)

A metric Portkey refuses (e.g. no analytics permission) is reported as `unavailable` and never
counts towards the state. Results are cached per user for `usage_cache_seconds`.
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Any

from .errors import ApiError
from .routes.usage import _analytics_rows, _graph, _graph_total, _to_usd, summarize_models
from .users import LIMIT_METRICS, LIMIT_PERIODS, merge_limits

log = logging.getLogger(__name__)
USAGE_STATES = ("normal", "soft", "hard", "unknown")


def effective_limits(state: Any, profile: Any) -> dict[str, dict[str, float]]:
    """Tier defaults from the env config, overridden by the directory (team, then user)."""
    tier_cfg = state.env_config.usage_limits.get(profile.user_tier)
    tier = tier_cfg.model_dump(exclude_none=True) if tier_cfg else {}
    tier = {p: {m: v for m, v in (ms or {}).items() if v is not None} for p, ms in tier.items()}
    merged = merge_limits(tier, getattr(profile, "limits", None)) or {}
    return {p: {m: v for m, v in ms.items() if m in LIMIT_METRICS and v is not None} for p, ms in merged.items() if p in LIMIT_PERIODS and ms}


def _windows(now: datetime) -> dict[str, tuple[datetime, datetime]]:
    day = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return {"daily": (day, now), "monthly": (day.replace(day=1), now)}


async def _period_usage(state: Any, email: str, start: datetime, end: datetime, metrics: set[str]) -> dict[str, float | None]:
    """Used amount per metric for one window; None when Portkey refused that metric."""
    md = {"_user": email.lower()}
    unit = state.env_config.portkey_cost_unit
    out: dict[str, float | None] = {}
    jobs: dict[str, Any] = {}
    if "tokens" in metrics:
        jobs["tokens"] = _graph(state, "tokens", start, end, md)
    if "cost_usd" in metrics:
        jobs["cost_usd"] = _graph(state, "cost", start, end, md)
    if "requests" in metrics:
        jobs["requests"] = _analytics_rows(state, "/analytics/groups/model", start, end, metadata=md)
    results = await asyncio.gather(*jobs.values(), return_exceptions=True)
    for metric, res in zip(jobs, results):
        if isinstance(res, BaseException):
            if isinstance(res, ApiError) and res.code in ("usage_forbidden", "usage_upstream_error", "upstream_timeout", "upstream_unavailable"):
                out[metric] = None
                continue
            raise res
        if metric == "requests":
            rows, _ = res
            out[metric] = float(sum(m["requests"] for m in summarize_models(rows, unit)))
        elif res is None:
            out[metric] = None
        else:
            total = _graph_total(res) or 0.0
            out[metric] = _to_usd(total, unit) if metric == "cost_usd" else total
    return out


async def evaluate_usage(state: Any, profile: Any, *, refresh: bool = False) -> dict:
    """The caller's usage state with per-limit details (cached per user)."""
    limits = effective_limits(state, profile)
    threshold = state.env_config.usage_soft_threshold
    base = {"user": profile.email, "user_tier": profile.user_tier, "soft_threshold": threshold, "limits": limits}
    if not limits:
        return {**base, "state": "normal", "configured": False, "checks": [], "checked_at": None}
    cache: dict[str, tuple[float, dict]] = state.usage_limit_cache
    key = profile.email.lower()
    hit = cache.get(key)
    if hit and not refresh and hit[0] > time.monotonic():
        return hit[1]
    now = datetime.now(timezone.utc)
    windows = _windows(now)
    checks: list[dict] = []
    reason: str | None = None
    try:
        periods = list(limits)
        used = await asyncio.gather(*[
            _period_usage(state, profile.email, *windows[p], set(limits[p])) for p in periods
        ])
    except ApiError as exc:
        # e.g. 501 usage_not_configured (no admin key): fail open.
        used, reason = None, exc.message
    if used is None:
        for p, ms in limits.items():
            checks += [{"period": p, "metric": m, "limit": lim, "used": None, "ratio": None, "status": "unavailable"} for m, lim in ms.items()]
    else:
        for p, u in zip(periods, used):
            start, _ = windows[p]
            for m, lim in limits[p].items():
                val = u.get(m)
                if val is None:
                    checks.append({"period": p, "metric": m, "limit": lim, "used": None, "ratio": None, "status": "unavailable", "since": start.isoformat()})
                    continue
                ratio = (val / lim) if lim > 0 else (1.0 if val > 0 else 0.0)
                status = "hard" if ratio >= 1 else "soft" if ratio >= threshold else "ok"
                checks.append({"period": p, "metric": m, "limit": lim, "used": round(val, 4), "ratio": round(ratio, 4), "status": status, "since": start.isoformat()})
    known = [c for c in checks if c["status"] != "unavailable"]
    if any(c["status"] == "hard" for c in known):
        st = "hard"
    elif any(c["status"] == "soft" for c in known):
        st = "soft"
    elif known:
        st = "normal"
    else:
        st = "unknown"
    result = {**base, "state": st, "configured": True, "checks": checks, "checked_at": now.isoformat()}
    if reason or any(c["status"] == "unavailable" for c in checks):
        result["note"] = reason or "Some limits cannot be checked: Portkey refused those analytics (the admin key needs analytics read permission). They never trigger a downgrade."
    cache[key] = (time.monotonic() + state.env_config.usage_cache_seconds, result)
    return result


async def apply_usage_state(state: Any, call: Any) -> dict:
    """Sets call.metadata['usage_state'] from the caller's live usage; returns the evaluation."""
    try:
        ev = await evaluate_usage(state, call.profile)
    except Exception as exc:  # never fail a chat because the usage lookup failed
        log.warning("usage evaluation failed: %s", type(exc).__name__)
        ev = {"state": "unknown", "configured": True, "checks": []}
    call.metadata["usage_state"] = ev["state"]
    return ev
