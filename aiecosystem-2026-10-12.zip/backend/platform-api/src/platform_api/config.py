"""Process settings (AIG_* env vars) and per-environment, non-secret YAML config."""

from __future__ import annotations

from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

import yaml
from pydantic import AliasChoices, BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .errors import StartupError

ENVIRONMENTS: tuple[str, ...] = ("local", "dev", "stage", "prod")
JOB_PROFILES: tuple[str, ...] = ("underwriting", "claims", "operations", "general")

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    """Process-level settings. Secrets are deliberately NOT part of this model."""

    model_config = SettingsConfigDict(env_prefix="AIG_", extra="ignore")

    env: Literal["local", "dev", "stage", "prod"] = "local"
    auth_mode: Literal["oidc", "dev"] = "oidc"
    secret_provider: Literal["env", "aws"] = "env"
    config_dir: Path = PROJECT_ROOT / "config"
    # Personal, gitignored overrides of config/environments/<env>.yaml (AIG_CONFIG_OVERRIDE_FILE).
    config_override_file: Path | None = None
    secrets_dir: Path = PROJECT_ROOT / "secrets"
    users_file: Path | None = None
    agents_file: Path | None = None
    public_base_url: str | None = None
    upstream_timeout_seconds: float = 120.0
    log_level: str = "INFO"
    # WebSocket (/api/v1/ws): usage push interval (AIG_WS_USAGE_INTERVAL, min 5s) and keepalive ping interval.
    ws_usage_interval_seconds: float = Field(
        15.0,
        validation_alias=AliasChoices(
            "ws_usage_interval_seconds", "AIG_WS_USAGE_INTERVAL", "AIG_WS_USAGE_INTERVAL_SECONDS"
        ),
    )
    ws_ping_interval_seconds: float = 25.0
    # Phase 3: create the agent's Fiddler application when it registers (AIG_FIDDLER_AUTOPROVISION).
    # Needs the aig-fiddler package (backend/observability/tool) and FIDDLER_API_KEY.
    fiddler_autoprovision: bool = False
    # Extra agent-registered hooks, "module:function" comma-separated (AIG_AGENT_HOOKS).
    agent_hooks: str | None = None
    # Phase 4 persistence (AIG_DATABASE_URL). Local default: sqlite file .run/platform.db; required
    # (postgresql+psycopg://...) in dev/stage/prod. Never logged with its password.
    database_url: str | None = None
    # Run Alembic migrations at startup (AIG_DB_AUTO_MIGRATE). Unset: true in local, false elsewhere
    # (there the schema must already be at head: run `aig-platform-api db upgrade` first).
    db_auto_migrate: bool | None = None
    migrations_dir: Path = PROJECT_ROOT / "migrations"
    # Portkey admin API base for the MCP registry sync (AIG_PORTKEY_ADMIN_URL); falls back to the
    # environment's portkey_admin_api_url. The key is the PORTKEY_ADMIN_API_KEY secret.
    portkey_admin_url: str | None = None
    # Push approved MCP servers to the Portkey MCP gateway (AIG_MCP_SYNC).
    mcp_sync: bool = False
    # IDE usage events -> backend/telemetry-bridge POST /ingest/ide-usage (AIG_TELEMETRY_BRIDGE_URL).
    telemetry_bridge_url: str | None = None
    telemetry_bridge_timeout_seconds: float = 5.0
    # Rendered Portkey config written by `aigw render` (AIG_ROUTING_CONFIG_FILE), for GET /api/v1/routing.
    routing_config_file: Path | None = None
    # Phase 7 model harness. Create a sandbox-only Portkey provider (virtual key) in the model-sandbox
    # workspace when a model enters the sandbox (AIG_MODEL_SANDBOX_SYNC; PORTKEY_ADMIN_API_KEY).
    model_sandbox_sync: bool = False
    # Emit a GitHub repository_dispatch (model_canary / model_promote / model_rollback) on those
    # transitions (AIG_CANARY_DISPATCH; GITHUB_DISPATCH_TOKEN), so .github/workflows/model-canary.yml
    # opens the manifest PR. AIG_GITHUB_REPO = "owner/repo"; AIG_GITHUB_API_URL for GitHub Enterprise.
    canary_dispatch: bool = False
    github_repo: str | None = None
    github_api_url: str = "https://api.github.com"
    # Approval-gate thresholds per tier (AIG_MODEL_GATE_THRESHOLDS_FILE); default
    # config/model-gate-thresholds.yaml (same values as backend/model-harness/thresholds.yaml).
    model_gate_thresholds_file: Path | None = None
    # --- Agent registry v2 + invocation (backend/contracts/agent-invocation.md) -----------------
    # AIG_AGENT_INVOCATION: unset = on in local, elsewhere on when AGENT_CALLER_SIGNING_KEY is
    # configured (otherwise invoke answers 503 agent_invocation_disabled); true outside local
    # without the key stops startup; false turns invocation off everywhere.
    agent_invocation: bool | None = None
    agent_sync_timeout_seconds: float = 120.0
    agent_stream_timeout_seconds: float = 900.0
    agent_background_timeout_seconds: float = 3600.0
    agent_connect_timeout_seconds: float = 10.0
    agent_caller_token_ttl_seconds: int = 300
    agent_max_background_per_user: int = 10
    # Largest agent answer (JSON body or one SSE event) platform-api accepts, in bytes.
    agent_max_response_bytes: int = 4 * 1024 * 1024
    # Verification: the gateway agent-check must have seen the agent within this window.
    agent_verify_seen_window_seconds: float = 300.0
    # Trace check hook "module:function" (AIG_AGENT_TRACE_CHECK). Unset = "not configured", which
    # fails verification unless AIG_AGENT_VERIFY_REQUIRE_TRACE is false (default false only in
    # local and dev).
    agent_trace_check: str | None = None
    agent_verify_require_trace: bool | None = None
    agent_invocation_retention_days: int = 90
    agent_output_retention_days: int = 30
    # AWS region of the AgentCore runtimes (default: the SDK's region resolution, AWS_REGION).
    agentcore_region: str | None = None

    @field_validator("ws_usage_interval_seconds")
    @classmethod
    def _min_usage_interval(cls, v: float) -> float:
        return max(5.0, float(v))

    @field_validator("ws_ping_interval_seconds")
    @classmethod
    def _min_ping_interval(cls, v: float) -> float:
        return max(1.0, float(v))


class PeriodLimits(BaseModel):
    """Usage limits for one period. A metric left out (None) is not limited."""

    tokens: int | None = Field(default=None, ge=0)
    cost_usd: float | None = Field(default=None, ge=0)
    requests: int | None = Field(default=None, ge=0)


class UsageLimits(BaseModel):
    """Daily (UTC day) and monthly (UTC calendar month) usage limits."""

    daily: PeriodLimits | None = None
    monthly: PeriodLimits | None = None


class EnvConfig(BaseModel):
    """Non-secret configuration from config/environments/<env>.yaml."""

    portkey_gateway_url: str
    portkey_config_id: str = "pc-aig-router"
    portkey_mcp_gateway_url: str | None = None
    portkey_admin_api_url: str | None = None
    fiddler_url: str | None = None
    oidc_issuer: str
    oidc_audience: str
    oidc_jwks_url: str
    cors_allowed_origins: list[str] = Field(default_factory=list)
    default_user_tier: str = "standard"
    # Unit Portkey analytics reports cost in; converted to USD for the dashboard. Verify per version.
    portkey_cost_unit: Literal["cents", "usd"] = "cents"
    allowed_job_profiles: list[str] = Field(default_factory=lambda: list(JOB_PROFILES))
    # Phase 4 web portal.
    portkey_ui_url: str | None = None
    # Browser origins of web: allowed for CORS and the WebSocket (with cors_allowed_origins)
    # and, in local dev-auth only, as local sign-in redirect targets (<origin>/auth/callback).
    web_allowed_origins: list[str] = Field(default_factory=list)
    # Portkey admin API paths (verify against the self-hosted version).
    portkey_mcp_servers_path: str = "/mcp-servers"
    portkey_usage_by_team_path: str = "/analytics/groups/metadata/team"
    # Phase 7 sandbox keys: POST {admin}{path} creates a workspace provider (virtual key) that
    # references a sandbox integration (no provider key passes through platform-api).
    portkey_sandbox_providers_path: str = "/providers"
    model_sandbox_workspace: str = "model-sandbox"
    # Provider -> sandbox integration slug (backend/gateway/manifests/integrations.yaml).
    model_sandbox_integrations: dict[str, str] = Field(
        default_factory=lambda: {"anthropic": "anthropic-sandbox", "openai": "openai-sandbox"}
    )
    # Deep links on agent objects; {fiddler_url}, {portkey_ui_url}, {agent_id}, {fiddler_application_id}.
    # A link is null when a value it needs is missing or still a placeholder.
    fiddler_agent_link: str = "{fiddler_url}/applications/{fiddler_application_id}"
    portkey_agent_link: str = "{portkey_ui_url}/logs?metadata.agent_id={agent_id}"
    # Usage-based routing: default limits per tier (premium | standard | free); teams and users can
    # override them in the user directory (`limits:`). Usage is read from Portkey analytics (filtered
    # by metadata `_user`). At usage_soft_threshold of any limit the request carries
    # metadata.usage_state=soft (one model level lower), at 100% usage_state=hard (cheapest model).
    # Empty = usage-based routing off (usage_state is always "normal").
    usage_limits: dict[str, UsageLimits] = Field(default_factory=dict)
    usage_soft_threshold: float = Field(default=0.8, gt=0, le=1)
    # How long one user's usage evaluation is cached (Portkey analytics is not queried per request).
    usage_cache_seconds: float = Field(default=60.0, ge=0)

    @property
    def admin_api_url(self) -> str:
        return self.portkey_admin_api_url or self.portkey_gateway_url

    @property
    def browser_origins(self) -> list[str]:
        """Origins allowed for CORS and the WebSocket: cors_allowed_origins + web_allowed_origins."""
        return list(dict.fromkeys([*self.cors_allowed_origins, *self.web_allowed_origins]))


def configured_url(value: str | None) -> str | None:
    """A non-secret URL from config, or None when unset or still a __PLACEHOLDER__."""
    v = (value or "").strip()
    return None if not v or "__" in v else v.rstrip("/")


def has_placeholder(value: str | None) -> bool:
    """True if a non-secret config value still contains a __PLACEHOLDER__ token."""
    return not value or "__" in value


def public_base_url_problem(value: str | None) -> str | None:
    """Why AIG_PUBLIC_BASE_URL is unusable outside local, or None if it is fine.

    Required: non-empty, no __PLACEHOLDER__ token, https scheme with a host.
    """
    v = (value or "").strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        v = v[1:-1].strip()
    if not v:
        return "missing"
    if "__" in v:
        return "placeholder"
    parts = urlsplit(v)
    if parts.scheme.lower() != "https" or not parts.hostname:
        return "must be an absolute https:// URL"
    return None


def load_env_config(settings: Settings) -> EnvConfig:
    path = Path(settings.config_dir) / "environments" / f"{settings.env}.yaml"
    if not path.is_file():
        raise StartupError(f"missing environment config: {path}")
    data = yaml.safe_load(path.read_text()) or {}
    # Optional personal overrides (AIG_CONFIG_OVERRIDE_FILE, e.g. config/environments/local.override.yaml,
    # gitignored): top-level keys replace the committed values. run-local.sh sets it when the file exists.
    if settings.config_override_file and str(settings.config_override_file).strip() not in ("", "."):
        override = Path(settings.config_override_file)
        if not override.is_file():
            raise StartupError(f"AIG_CONFIG_OVERRIDE_FILE does not exist: {override}")
        extra = yaml.safe_load(override.read_text()) or {}
        if not isinstance(extra, dict):
            raise StartupError(f"{override.name} must hold a mapping")
        data = {**data, **extra}
    cfg = EnvConfig.model_validate(data)
    unknown = [p for p in cfg.allowed_job_profiles if p not in JOB_PROFILES]
    if unknown:
        raise StartupError(f"unknown job profiles in {path.name}: {unknown}")
    return cfg
