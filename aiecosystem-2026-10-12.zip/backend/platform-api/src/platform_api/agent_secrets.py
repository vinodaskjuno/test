"""Credentials platform-api uses to call HTTPS agents (version ``auth``), resolved at call time.

The registry stores only a reference (``auth.secret_arn``); values come from:

- ``arn:aws...:secretsmanager:...`` - AWS Secrets Manager (platform-api task role, cached 5 min);
- ``local:<NAME>`` - only in ``AIG_ENV=local``: ``<NAME>`` from the process environment or
  ``secrets/.env.local``.

Secret formats (agent-invocation.md): ``api_key`` = the key or JSON ``{"api_key", "header"}``;
``oauth_client_credentials`` = JSON ``{"token_url", "client_id", "client_secret", "scope"?,
"audience"?}``. Every resolved value is added to the log/frame redaction list; nothing here logs a
value or returns one to a client.
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
from pathlib import Path
from typing import Any, Callable, Protocol

import httpx

from .secrets import _parse_env_file

log = logging.getLogger(__name__)

ARN_RE = re.compile(r"^arn:aws[a-z-]*:secretsmanager:[a-z0-9-]+:[0-9]{12}:secret:[A-Za-z0-9/_+=.@-]{1,512}$")
LOCAL_REF_RE = re.compile(r"^local:([A-Z][A-Z0-9_]{0,127})$")
CACHE_SECONDS = 300.0
DEFAULT_API_KEY_HEADER = "x-api-key"
HEADER_NAME_RE = re.compile(r"^[A-Za-z0-9-]{1,64}$")
FORBIDDEN_AUTH_HEADERS = frozenset({"host", "content-type", "content-length", "accept", "x-aig-caller",
                                    "x-aig-invocation-id", "x-aig-trace-id", "cookie"})


class AgentAuthError(RuntimeError):
    """Credentials could not be resolved or used (message never contains a secret)."""


class SecretResolver(Protocol):
    def resolve(self, ref: str) -> str: ...


def valid_secret_ref(ref: str, env: str) -> bool:
    return bool(ARN_RE.match(ref)) or (env == "local" and bool(LOCAL_REF_RE.match(ref)))


class DefaultSecretResolver:
    """``arn:`` refs via Secrets Manager (lazy boto3), ``local:`` refs in local only."""

    def __init__(self, *, env: str, secrets_dir: Path, register_redaction: Callable[[str], None] | None = None,
                 client_factory: Callable[[], Any] | None = None, environ: dict[str, str] | None = None):
        self.env = env
        self.secrets_dir = Path(secrets_dir)
        self._register = register_redaction or (lambda _v: None)
        self._client_factory = client_factory
        self._client = None
        self._environ = environ
        self._cache: dict[str, tuple[float, str]] = {}
        self._lock = threading.Lock()

    def _remember(self, ref: str, value: str) -> str:
        self._register(value)
        with self._lock:
            self._cache[ref] = (time.monotonic() + CACHE_SECONDS, value)
        return value

    def resolve(self, ref: str) -> str:
        with self._lock:
            hit = self._cache.get(ref)
        if hit and hit[0] > time.monotonic():
            return hit[1]
        m = LOCAL_REF_RE.match(ref or "")
        if m:
            if self.env != "local":
                raise AgentAuthError("local: secret references are only allowed in AIG_ENV=local")
            environ = os.environ if self._environ is None else self._environ
            value = environ.get(m.group(1))
            if not value:
                path = self.secrets_dir / ".env.local"
                value = _parse_env_file(path).get(m.group(1)) if path.is_file() else None
            if not value or value.strip().lower().startswith("__replace_me"):
                raise AgentAuthError(f"local secret {m.group(1)} is not set")
            return self._remember(ref, value.strip())
        if not ARN_RE.match(ref or ""):
            raise AgentAuthError("secret reference is neither a Secrets Manager ARN nor local:<NAME>")
        try:
            if self._client is None:
                if self._client_factory is not None:
                    self._client = self._client_factory()
                else:
                    import boto3  # lazy: optional dependency (pip install '.[aws]')

                    self._client = boto3.client("secretsmanager")
            value = self._client.get_secret_value(SecretId=ref).get("SecretString") or ""
        except Exception as exc:
            raise AgentAuthError(f"secret could not be read ({type(exc).__name__})") from None
        if not value:
            raise AgentAuthError("secret has no SecretString")
        return self._remember(ref, value)


def _json_or_none(value: str) -> dict | None:
    try:
        data = json.loads(value)
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


class AgentAuthenticator:
    """Turns a version's ``auth`` into request headers (api key / OAuth client-credentials token)."""

    def __init__(self, resolver: SecretResolver, *, register_redaction: Callable[[str], None] | None = None):
        self.resolver = resolver
        self._register = register_redaction or (lambda _v: None)
        self._tokens: dict[str, tuple[float, str]] = {}
        self._lock = threading.Lock()

    async def headers(self, auth: dict | None, client: httpx.AsyncClient, *, timeout: float = 10.0) -> dict[str, str]:
        auth = auth or {}
        kind = auth.get("type") or "none"
        if kind == "none":
            return {}
        ref = auth.get("secret_arn") or ""
        try:
            value = self.resolver.resolve(ref)
        except AgentAuthError:
            raise
        except Exception as exc:
            raise AgentAuthError(f"secret could not be resolved ({type(exc).__name__})") from None
        if kind == "api_key":
            data = _json_or_none(value)
            key = str(data.get("api_key") or "") if data else value.strip()
            header = str(data.get("header") or DEFAULT_API_KEY_HEADER) if data else DEFAULT_API_KEY_HEADER
            if not key:
                raise AgentAuthError("api_key secret has no api_key")
            if not HEADER_NAME_RE.match(header) or header.lower() in FORBIDDEN_AUTH_HEADERS:
                raise AgentAuthError("api_key secret names an unusable header")
            self._register(key)
            return {header: key}
        if kind == "oauth_client_credentials":
            return {"authorization": f"Bearer {await self._oauth_token(ref, value, client, timeout)}"}
        raise AgentAuthError(f"unsupported auth type {kind!r}")

    async def _oauth_token(self, ref: str, value: str, client: httpx.AsyncClient, timeout: float) -> str:
        with self._lock:
            hit = self._tokens.get(ref)
        if hit and hit[0] > time.monotonic():
            return hit[1]
        data = _json_or_none(value) or {}
        token_url, client_id, client_secret = data.get("token_url"), data.get("client_id"), data.get("client_secret")
        if not (isinstance(token_url, str) and token_url.startswith("https://") and client_id and client_secret):
            raise AgentAuthError("oauth secret needs https token_url, client_id and client_secret")
        self._register(str(client_secret))
        form = {"grant_type": "client_credentials", "client_id": str(client_id), "client_secret": str(client_secret)}
        for key in ("scope", "audience"):
            if data.get(key):
                form[key] = str(data[key])
        try:
            resp = await client.post(token_url, data=form, timeout=timeout)
        except httpx.HTTPError as exc:
            raise AgentAuthError(f"token endpoint unreachable ({type(exc).__name__})") from None
        if resp.status_code >= 400:
            raise AgentAuthError(f"token endpoint answered HTTP {resp.status_code}")
        try:
            body = resp.json()
        except ValueError:
            body = {}
        token = body.get("access_token") if isinstance(body, dict) else None
        if not isinstance(token, str) or not token:
            raise AgentAuthError("token endpoint returned no access_token")
        self._register(token)
        expires = body.get("expires_in") if isinstance(body.get("expires_in"), (int, float)) else 300
        with self._lock:
            self._tokens[ref] = (time.monotonic() + max(0.0, float(expires) - 60.0), token)
        return token
