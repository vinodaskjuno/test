"""OpenAI-compatible LLM proxy to the self-hosted Portkey gateway.

The client never sees or supplies a Portkey key. Outbound headers are built from
scratch (allow-list), so client x-portkey-* and Authorization headers are dropped.
"""

from __future__ import annotations

import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import httpx
from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response, StreamingResponse
from starlette.background import BackgroundTask

from ..agents import default_agent_for_host
from ..auth import Principal, require_principal
from ..config import has_placeholder
from ..errors import ApiError
from ..usage_events import cache_status, forward_chat_usage

router = APIRouter(prefix="/api/v1/llm", tags=["llm"])
log = logging.getLogger(__name__)

TRACE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$")
AGENT_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
# Interactive host sent in metadata. Requests with an Origin header come from a browser (the web
# portal: host "web", agent web.portal); everything else is the VS Code extension. Eclipse will pass
# its host when it ships (agents.DEFAULT_AGENT_BY_HOST).
HOST = "vscode"
WEB_HOST = "web"


def request_host(origin: str | None, agent_id: str | None = None) -> str:
    """Host for metadata. A built-in IDE agent id names its host (ide.eclipse -> eclipse), so
    Eclipse traffic is attributed correctly; otherwise browsers (Origin) are web, the rest vscode."""
    from ..agents import HOST_BY_BUILTIN_AGENT

    if agent_id and agent_id in HOST_BY_BUILTIN_AGENT:
        return HOST_BY_BUILTIN_AGENT[agent_id]
    return WEB_HOST if origin else HOST
DEFAULT_JOB_PROFILE = "general"


def resolve_trace_id(raw: str | None) -> str:
    if raw and TRACE_ID_RE.match(raw):
        return raw
    return str(uuid.uuid4())


def build_metadata(
    *, profile, job_profile: str, agent_id: str | None, env: str, host: str = HOST
) -> dict[str, str]:
    """Server-built x-portkey-metadata. agent_id is always present: the gateway requires it
    (required metadata + agent-check webhook), so interactive traffic without a client agent id
    carries the host's pre-registered agent (ide.vscode for host=vscode)."""
    return {
        "user_tier": profile.user_tier,  # from the server-side directory, never the client
        # Cost-based routing (economy | balanced | quality), also from the directory, never the client.
        "cost_mode": getattr(profile, "cost_mode", "balanced"),
        "job_profile": job_profile,
        "agent_id": agent_id or default_agent_for_host(host),
        "team": profile.team,
        "env": env,
        "host": host,
        "user": profile.email,
        "_user": profile.email,  # Portkey's reserved key for per-user analytics
    }


def route_info(metadata: dict[str, str]) -> dict[str, str]:
    """The routing inputs Portkey's conditional config sees (shown to the user next to the served model)."""
    return {k: metadata[k] for k in ("user_tier", "cost_mode", "job_profile", "usage_state") if metadata.get(k)}


def route_headers(metadata: dict[str, str]) -> dict[str, str]:
    """x-aig-route-* response headers (exposed to browsers via CORS) for HTTP chat responses."""
    r = route_info(metadata)
    return {f"x-aig-route-{k.replace('_', '-')}": v for k, v in r.items()}


def extract_usage(obj: Any) -> dict | None:
    """Token counts from an OpenAI-style ``usage`` object (integers only)."""
    if not isinstance(obj, dict):
        return None
    out = {
        k: obj[k]
        for k in ("prompt_tokens", "completion_tokens", "total_tokens")
        if isinstance(obj.get(k), int) and not isinstance(obj.get(k), bool)
    }
    return out or None


class SseUsageSniffer:
    """Reads the model and the final ``usage`` from an SSE stream as it is relayed (token counts
    only; nothing else is kept). Lines without usage are not parsed once the model is known."""

    MAX_LINE = 1024 * 1024

    def __init__(self) -> None:
        self._buf = b""
        self.usage: dict | None = None
        self.model: str | None = None

    def feed(self, chunk: bytes) -> None:
        self._buf += chunk
        if b"\n" not in self._buf:
            if len(self._buf) > self.MAX_LINE:
                self._buf = b""
            return
        *lines, self._buf = self._buf.split(b"\n")
        for line in lines:
            self._line(line)

    def close(self) -> None:
        self._line(self._buf)
        self._buf = b""

    def _line(self, line: bytes) -> None:
        line = line.strip()
        if not line.startswith(b"data:") or (self.model is not None and b'"usage"' not in line):
            return
        try:
            event = json.loads(line[5:])
        except (ValueError, UnicodeDecodeError):
            return
        if not isinstance(event, dict):
            return
        if self.model is None and isinstance(event.get("model"), str):
            self.model = event["model"]
        self.usage = extract_usage(event.get("usage")) or self.usage


def note_agent_seen(state: Any, agent_id: str | None, host: str) -> None:
    """Update the agent's last_seen_at / hosts_seen (database registry only; throttled). Never raises."""
    touch = getattr(getattr(state, "agents", None), "touch", None)
    if touch is None or not agent_id:
        return
    try:
        touch(agent_id, host)
    except Exception as exc:
        log.warning("agent last_seen update failed: %s", type(exc).__name__)


def redact_text(text: str, secrets: list[str]) -> str:
    for s in secrets:
        text = text.replace(s, "***redacted***")
    return text


def _redact(content: bytes, secrets: list[str]) -> bytes:
    for s in secrets:
        content = content.replace(s.encode(), b"***redacted***")
    return content


def _sse_error(code: str, message: str) -> bytes:
    payload = json.dumps({"error": {"code": code, "message": message}}, separators=(",", ":"))
    return b"\n\ndata: " + payload.encode() + b"\n\n"


@dataclass
class LlmCall:
    """A validated, server-side-authorised Portkey call (shared by HTTP and WebSocket)."""

    trace_id: str
    profile: Any
    job_profile: str
    agent_id: str | None
    metadata: dict[str, str]
    url: str
    secrets: list[str] = field(repr=False)
    _api_key: str = field(repr=False)
    _config_id: str = ""

    def headers(self, stream: bool) -> dict[str, str]:
        """Outbound headers, built from scratch (allow-list); never derived from client headers."""
        return {
            "content-type": "application/json",
            "accept": "text/event-stream" if stream else "application/json",
            "x-portkey-api-key": self._api_key,
            "x-portkey-config": self._config_id,
            # Canonical encoding from backend/contracts/headers.md: compact JSON, keys sorted.
            "x-portkey-metadata": json.dumps(self.metadata, separators=(",", ":"), sort_keys=True),
            "x-portkey-trace-id": self.trace_id,
        }


def prepare_llm_call(
    state: Any,
    principal: Principal,
    *,
    job_profile: str | None,
    agent_id: str | None,
    trace_id: str | None = None,
    host: str = HOST,
) -> LlmCall:
    """Validate config + client-supplied routing hints; raise ApiError (with x-aig-trace-id) on failure."""
    cfg = state.env_config
    trace_id = resolve_trace_id(trace_id)
    trace_hdr = {"x-aig-trace-id": trace_id}

    api_key = state.secrets.get("PORTKEY_API_KEY")
    if not api_key:
        raise ApiError(503, "portkey_key_not_configured", "Portkey API key is not configured on the backend", trace_hdr)
    if has_placeholder(cfg.portkey_gateway_url):
        raise ApiError(503, "portkey_gateway_not_configured", "Portkey gateway URL is not configured", trace_hdr)

    allowed = cfg.allowed_job_profiles
    job_profile = (job_profile or "").strip() or (DEFAULT_JOB_PROFILE if DEFAULT_JOB_PROFILE in allowed else allowed[0])
    if job_profile not in allowed:
        raise ApiError(400, "invalid_job_profile", f"job profile must be one of {allowed}", trace_hdr)

    agent_id = (agent_id or "").strip() or None
    if agent_id is not None and not AGENT_ID_RE.match(agent_id):
        raise ApiError(400, "invalid_agent_id", "agent id must match [A-Za-z0-9._-]{1,64}", trace_hdr)

    profile = state.users.lookup(principal.email, principal.name)
    agent_id = agent_id or default_agent_for_host(host)
    return LlmCall(
        trace_id=trace_id,
        profile=profile,
        job_profile=job_profile,
        agent_id=agent_id,
        metadata=build_metadata(
            profile=profile, job_profile=job_profile, agent_id=agent_id, env=state.settings.env, host=host
        ),
        url=cfg.portkey_gateway_url.rstrip("/") + "/chat/completions",
        secrets=state.secrets.configured_values(),
        _api_key=api_key,
        _config_id=cfg.portkey_config_id,
    )


from ..usage_limits import apply_usage_state  # noqa: E402  (after the helpers usage_limits needs)


@router.post("/chat/completions")
async def chat_completions(request: Request, principal: Principal = Depends(require_principal)):
    state = request.app.state
    call = prepare_llm_call(
        state,
        principal,
        job_profile=request.headers.get("x-aig-job-profile"),
        agent_id=request.headers.get("x-aig-agent-id"),
        trace_id=request.headers.get("x-aig-trace-id"),
        host=request_host(request.headers.get("origin"), request.headers.get("x-aig-agent-id")),
    )
    await apply_usage_state(state, call)  # usage-based routing: metadata.usage_state
    trace_id, profile, job_profile = call.trace_id, call.profile, call.job_profile
    trace_hdr = {"x-aig-trace-id": trace_id}
    note_agent_seen(state, call.agent_id, call.metadata["host"])

    try:
        body = json.loads(await request.body() or b"null")
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ApiError(400, "invalid_json", "request body must be JSON", trace_hdr) from None
    if not isinstance(body, dict):
        raise ApiError(400, "invalid_request", "request body must be a JSON object", trace_hdr)

    stream = body.get("stream") is True
    headers = call.headers(stream)
    url = call.url
    client: httpx.AsyncClient = state.http_client
    secrets = call.secrets
    started = time.monotonic()

    def done(status: int) -> None:
        log.info(
            "llm proxy trace_id=%s user=%s job_profile=%s stream=%s status=%s ms=%d",
            trace_id, profile.email, job_profile, stream, status, (time.monotonic() - started) * 1000,
        )

    try:
        upstream_req = client.build_request("POST", url, headers=headers, content=json.dumps(body).encode())
        upstream = await client.send(upstream_req, stream=stream)
    except httpx.TimeoutException:
        done(504)
        raise ApiError(504, "upstream_timeout", "Portkey gateway timed out", trace_hdr) from None
    except httpx.RequestError as exc:
        done(502)
        log.warning("upstream error trace_id=%s: %s", trace_id, type(exc).__name__)
        raise ApiError(502, "upstream_unavailable", "Portkey gateway unreachable", trace_hdr) from None

    content_type = upstream.headers.get("content-type", "application/json")
    cache = cache_status(upstream.headers.get("x-portkey-cache-status"))

    def forward(usage: dict | None, model: str | None) -> None:
        forward_chat_usage(state, metadata=call.metadata, usage=usage, model=model, trace_id=trace_id,
                           latency_ms=(time.monotonic() - started) * 1000, cache=cache)

    if stream and upstream.status_code < 400:
        done(upstream.status_code)
        sniffer = SseUsageSniffer()

        # A secret can straddle chunk boundaries, so keep the last (longest secret - 1)
        # bytes back until the next chunk arrives; anything earlier is safe to emit.
        hold = max((len(s.encode()) for s in secrets), default=1) - 1

        async def relay():
            buf = b""
            try:
                async for chunk in upstream.aiter_raw():
                    sniffer.feed(chunk)
                    buf = _redact(buf + chunk, secrets) if secrets else buf + chunk
                    if len(buf) > hold:
                        cut = len(buf) - hold
                        out, buf = buf[:cut], buf[cut:]
                        yield out
            except httpx.TimeoutException:
                # Status is already sent; signal truncation in-band with the shared error envelope.
                log.warning("upstream stream timed out trace_id=%s", trace_id)
                if buf:
                    yield buf
                    buf = b""
                yield _sse_error("upstream_timeout", "Portkey gateway timed out")
                return
            except (httpx.ReadError, httpx.RemoteProtocolError) as exc:
                log.warning("upstream stream interrupted trace_id=%s: %s", trace_id, type(exc).__name__)
                if buf:
                    yield buf
                    buf = b""
                yield _sse_error("upstream_interrupted", "Portkey gateway stream was interrupted")
                return
            if buf:
                yield buf
            sniffer.close()
            forward(sniffer.usage, sniffer.model)

        return StreamingResponse(
            relay(),
            status_code=upstream.status_code,
            media_type=content_type or "text/event-stream",
            headers={**trace_hdr, **route_headers(call.metadata), "cache-control": "no-cache", "x-accel-buffering": "no"},
            background=BackgroundTask(upstream.aclose),
        )

    try:
        content = await upstream.aread() if stream else upstream.content
    except httpx.TimeoutException:
        done(504)
        raise ApiError(504, "upstream_timeout", "Portkey gateway timed out", trace_hdr) from None
    finally:
        if stream:
            await upstream.aclose()
    done(upstream.status_code)
    if upstream.status_code < 400:
        try:
            parsed = json.loads(content) if content else None
        except (ValueError, UnicodeDecodeError):
            parsed = None
        if isinstance(parsed, dict):
            forward(extract_usage(parsed.get("usage")), parsed.get("model") if isinstance(parsed.get("model"), str) else None)
    return Response(
        content=_redact(content, secrets),
        status_code=upstream.status_code,
        media_type=content_type,
        headers={**trace_hdr, **route_headers(call.metadata)},
    )
