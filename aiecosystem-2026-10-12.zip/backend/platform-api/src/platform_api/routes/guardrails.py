"""Portkey webhook guardrail: registered-agent check.

POST /api/v1/guardrails/agent-check

Portkey's input guardrail ``aig-agent-check`` (backend/gateway/manifests/guardrails.yaml) calls
this endpoint before every model call. Portkey webhook contract (verify against the AIG
self-hosted version):

- Request JSON: ``{"request": {...}, "response": {...}, "provider": "...", "requestType": "...",
  "metadata": {...x-portkey-metadata...}, "eventType": "beforeRequestHook"|"afterRequestHook"}``.
  ``metadata`` may also arrive as a JSON string, or nested under ``request.metadata``.
- Response JSON (always HTTP 200 once authenticated): ``{"verdict": true|false, "data": {...}}``.
  ``verdict: false`` makes Portkey deny the call (the guardrail is configured with ``deny``).

Auth: Portkey sends the shared secret ``PORTKEY_WEBHOOK_SECRET`` in the ``x-aig-webhook-secret``
header (configured as a webhook header on the guardrail). It is compared in constant time.
Outside ``local`` the endpoint refuses to answer (503) when the secret is not configured, so a
missing secret can never silently allow traffic (the guardrail uses failOnError -> deny).

The check is fail-closed: anything unexpected is ``verdict: false``. Prompts and replies in the
payload are never read or logged.
"""

from __future__ import annotations

import hmac
import json
import logging
from typing import Any

from fastapi import APIRouter, Request

from ..agents import AGENT_ID_RE, gateway_denial
from ..errors import ApiError
from .llm import note_agent_seen

router = APIRouter(prefix="/api/v1/guardrails", tags=["guardrails"])
log = logging.getLogger(__name__)

SECRET_HEADER = "x-aig-webhook-secret"
SECRET_NAME = "PORTKEY_WEBHOOK_SECRET"
# Same list as backend/gateway/manifests/workspaces.yaml required_metadata.
REQUIRED_METADATA: tuple[str, ...] = ("user_tier", "job_profile", "agent_id", "team")
MAX_BODY_BYTES = 4 * 1024 * 1024


def _authenticate(request: Request) -> None:
    state = request.app.state
    expected = state.secrets.get(SECRET_NAME)
    if not expected:
        if state.settings.env != "local":
            raise ApiError(503, "webhook_not_configured", f"{SECRET_NAME} is not configured on the backend")
        log.warning("agent-check webhook called without %s configured (allowed only in AIG_ENV=local)", SECRET_NAME)
        return
    supplied = request.headers.get(SECRET_HEADER) or ""
    if not hmac.compare_digest(supplied.encode(), expected.encode()):
        raise ApiError(401, "webhook_unauthenticated", "missing or invalid webhook secret")


def _metadata(payload: Any) -> dict | None:
    if not isinstance(payload, dict):
        return None
    candidates = [payload.get("metadata")]
    req = payload.get("request")
    if isinstance(req, dict):
        candidates.append(req.get("metadata"))
    for meta in candidates:
        if isinstance(meta, str):
            try:
                meta = json.loads(meta)
            except ValueError:
                continue
        if isinstance(meta, dict):
            return meta
    return None


def _deny(reason: str, message: str, **extra: Any) -> dict:
    return {"verdict": False, "data": {"reason": reason, "message": message, **extra}}


_DENIAL_MESSAGES = {
    "agent_suspended": "agent is suspended",
    "agent_retired": "agent is retired",
    "agent_draft": "agent is a draft (drafts run only in local and dev)",
}


def evaluate_agent_check(registry: Any, payload: Any, env: str | None = None) -> dict:
    """Pure decision function (also mirrored by the gateway tool's offline simulator).

    ``env`` is platform-api's AIG_ENV (registry v2: draft agents pass only in local/dev; ``None``
    behaves like local, which is what the simulator's shared cases assume)."""
    meta = _metadata(payload)
    if meta is None:
        return _deny("metadata_missing", "request carries no x-portkey-metadata")
    missing = [k for k in REQUIRED_METADATA if not isinstance(meta.get(k), str) or not meta.get(k).strip()]
    if missing:
        return _deny("required_metadata_missing", "required metadata missing", missing=missing)
    agent_id = meta["agent_id"].strip()
    if not AGENT_ID_RE.match(agent_id):
        return _deny("invalid_agent_id", "agent_id must match [A-Za-z0-9._-]{1,64}")
    agent = registry.get(agent_id)
    if agent is None:
        return _deny("agent_unregistered", "agent is not registered", agent_id=agent_id, error="AIG_E_AGENT_UNREGISTERED")
    denial = gateway_denial(agent, env)
    if denial is not None:
        return _deny(
            denial, _DENIAL_MESSAGES[denial], agent_id=agent_id, status=agent.status,
            lifecycle=getattr(agent, "lifecycle", "active"), error="AIG_E_AGENT_UNREGISTERED",
        )
    team = meta["team"].strip()
    if not agent.shared and team != agent.team:
        return _deny("team_mismatch", "agent belongs to a different team", agent_id=agent_id)
    return {"verdict": True, "data": {"reason": "agent_active", "agent_id": agent_id, "owner_team": agent.team}}


@router.post("/agent-check")
async def agent_check(request: Request) -> dict:
    _authenticate(request)
    raw = await request.body()
    payload: Any = None
    if len(raw) > MAX_BODY_BYTES:
        result = _deny("payload_too_large", "webhook payload too large")
    else:
        try:
            payload = json.loads(raw or b"null")
        except (ValueError, UnicodeDecodeError):
            payload = None
        if not isinstance(payload, dict):
            result = _deny("invalid_payload", "webhook payload must be a JSON object")
        else:
            try:
                result = evaluate_agent_check(request.app.state.agents, payload, request.app.state.settings.env)
            except Exception as exc:  # fail closed
                log.warning("agent-check failed: %s", type(exc).__name__)
                result = _deny("internal_error", "agent check failed")
    data = result["data"]
    if result["verdict"] and isinstance(payload, dict):
        # The agent passed the gateway check: record it as seen (database registry; throttled, never raises).
        meta = _metadata(payload) or {}
        host = meta.get("host") if isinstance(meta.get("host"), str) else None
        note_agent_seen(request.app.state, data.get("agent_id"), host or "")
    log.info(
        "agent-check verdict=%s reason=%s agent_id=%s event=%s",
        result["verdict"], data.get("reason"), data.get("agent_id", "-"),
        str(payload.get("eventType"))[:32] if isinstance(payload, dict) else "-",
    )
    return result
