"""Agent registry API (Phase 3 hooks; Phase 4 database registry and portal operations).

| Method | Path | Auth |
|---|---|---|
| GET   | /api/v1/agents?team=&status=&q=      | user Bearer token or ``x-aig-service-token`` |
| GET   | /api/v1/agents/{agent_id}           | user Bearer token or service token |
| POST  | /api/v1/agents                      | user (owner/team default to the caller; admins may set them) or service (gives owner, team) |
| PATCH | /api/v1/agents/{agent_id}           | the agent's owner or an admin |
| POST  | /api/v1/agents/{agent_id}/suspend   | admin or service token (telemetry-bridge reconciliation) |
| POST  | /api/v1/agents/{agent_id}/reinstate | admin or service token |
| GET   | /api/v1/agents/{agent_id}/versions  | service, admin, owner/team, or a user allowed to run the agent |
| POST  | /api/v1/agents/{agent_id}/versions  | service token (deploy workflow, any kind) or owner/admin (kind https only) |
| POST  | /api/v1/agents/{agent_id}/versions/{version}/verify?env= | owner, admin or service |
| POST  | /api/v1/agents/{agent_id}/versions/{version}/retire?env= | owner, admin or service |
| POST  | /api/v1/agents/{agent_id}/lifecycle | owner or admin (``{to}``; activation needs a verified version) |
| PUT   | /api/v1/agents/{agent_id}/access    | owner or admin (``visibility: org`` -> ``org_approval: pending``) |
| POST  | /api/v1/agents/{agent_id}/access/approve, /reject | admin |

Registry v2: new agents start as ``lifecycle: draft`` (admins/service may register ``active``); the
built-ins are ``active``. ``status`` (active|suspended) stays the gateway switch.

Responses keep the shapes the SDK registry clients and the machine callers rely on:
``{"agent": {...}}`` for GET-by-id / POST (201, 409 ``agent_exists``), and the list carries
``agents`` next to ``items``/``total``. Registration fires the agent-registered hooks
(``agent_hooks.py``; Fiddler application provisioning behind ``AIG_FIDDLER_AUTOPROVISION``) after
the response; a Fiddler application id returned by a hook is stored on the agent. Every change is
written to the audit log.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any
from urllib.parse import urlsplit

from fastapi import APIRouter, BackgroundTasks, Depends, Query, Request, Response

from ..agent_hooks import AgentHook, run_registered_hooks

from ..agent_secrets import valid_secret_ref
from ..agents import (
    AGENT_ID_RE,
    GROUP_RE,
    MAX_ALLOWED_GROUPS,
    TAG_RE,
    TEAM_RE,
    VERSION_RE,
    AgentRecord,
    AgentRegistryError,
    AgentVersion,
    lifecycle_transition_allowed,
)
from ..authz import Caller, forbidden, get_caller, get_user
from ..config import configured_url
from ..db import add_audit, utcnow
from ..errors import ApiError
from ..invoker import InvocationError, access_denial, check_json_schema
from ..schemas import (
    AccessBody,
    AccessDecision,
    AgentCreate,
    AgentEnvelope,
    AgentList,
    AgentPatch,
    AgentRegistered,
    AgentStatusBody,
    AgentStatusChanged,
    AgentStatusT,
    AgentVersionCreate,
    AgentVersionList,
    AgentVersionRegistered,
    LifecycleBody,
    LifecycleT,
    VerifyBody,
    VerifyResult,
)

router = APIRouter(prefix="/api/v1/agents", tags=["agents"])
log = logging.getLogger(__name__)

_ERROR_STATUS = {"invalid_agent": 400, "agent_exists": 409, "agent_not_found": 404, "version_not_found": 404}
AGENTCORE_ARN_RE = re.compile(r"^arn:aws[a-z-]*:bedrock-agentcore:[a-z0-9-]+:[0-9]{12}:runtime/[A-Za-z0-9_-]{1,100}$")
QUALIFIER_RE = re.compile(r"^[A-Za-z0-9_-]{1,128}$")
LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})
MAX_SCHEMA_BYTES = 64 * 1024


def _clean_tags(tags: list[str] | None) -> list[str]:
    out = list(dict.fromkeys(t.strip().lower() for t in (tags or []) if t.strip()))
    bad = [t for t in out if not TAG_RE.match(t)]
    if bad:
        raise ApiError(400, "invalid_request", f"tags must match [a-z0-9][a-z0-9._-]{{0,31}} (bad: {bad[:3]})")
    return out[:20]


def _clean_docs_url(url: str | None) -> str:
    url = (url or "").strip()
    if url and urlsplit(url).scheme not in ("https", "http"):
        raise ApiError(400, "invalid_request", "docs_url must be an http(s) URL")
    return url


def _registry_error(exc: AgentRegistryError) -> ApiError:
    return ApiError(_ERROR_STATUS.get(exc.code, 400), exc.code, str(exc))


def _mutable(request: Request):
    registry = request.app.state.agents
    if not hasattr(registry, "set_status") or not hasattr(registry, "register"):
        raise ApiError(501, "registry_read_only", "the configured agent registry does not support changes")
    return registry


def _link(template: str, values: dict[str, str | None]) -> str | None:
    needed = [k for k in values if "{" + k + "}" in template]
    if any(not values[k] for k in needed):
        return None
    try:
        return template.format(**{k: (v or "") for k, v in values.items()})
    except (KeyError, IndexError, ValueError):
        return None


def agent_view(agent: AgentRecord, state: Any) -> dict:
    cfg = state.env_config
    values = {
        "fiddler_url": configured_url(cfg.fiddler_url),
        "portkey_ui_url": configured_url(cfg.portkey_ui_url),
        "agent_id": agent.agent_id,
        "fiddler_application_id": agent.fiddler_application_id or None,
    }
    return {
        "agent_id": agent.agent_id,
        "name": agent.name or agent.agent_id,
        "description": agent.description,
        "team": agent.team,
        "owner": agent.owner,
        "status": agent.status,
        "builtin": bool(agent.builtin),
        "created_at": agent.created_at or None,
        "updated_at": agent.updated_at or None,
        "last_seen_at": agent.last_seen_at or None,
        "hosts_seen": list(agent.hosts_seen),
        "fiddler_application_id": agent.fiddler_application_id or None,
        "links": {"fiddler": _link(cfg.fiddler_agent_link, values), "portkey": _link(cfg.portkey_agent_link, values)},
        "shared": agent.shared,
        "status_reason": agent.status_reason,
        "status_changed_at": agent.status_changed_at or None,
        "lifecycle": agent.lifecycle,
        "lifecycle_changed_at": agent.lifecycle_changed_at or None,
        "tags": list(agent.tags),
        "docs_url": agent.docs_url or None,
        "data_classification": agent.data_classification or None,
        "visibility": agent.visibility,
        "allowed_groups": list(agent.allowed_groups),
        "org_approval": agent.org_approval,
        "org_approval_by": agent.org_approval_by or None,
        "org_approval_at": agent.org_approval_at or None,
    }


def version_view(v: AgentVersion) -> dict:
    d = v.to_dict()
    d["verified_at"] = v.verified_at or None
    d["updated_at"] = v.updated_at or None
    d["auth"] = {"type": (v.auth or {}).get("type", "none"), "secret_arn": (v.auth or {}).get("secret_arn")}
    return d


def _audit(request: Request, *, actor: str, action: str, agent_id: str, details: dict | None = None) -> None:
    db = getattr(request.app.state, "db", None)
    if db is None:
        return
    try:
        with db.session() as s:
            add_audit(s, actor=actor, action=action, entity_type="agent", entity_id=agent_id, details=details)
    except Exception as exc:  # the registry change already happened; never fail it on the audit write
        log.error("audit write failed for agent %s %s: %s", agent_id, action, type(exc).__name__)


def _application_id(results: list[dict]) -> str | None:
    for r in results:
        out = r.get("result")
        if r.get("status") == "ok" and isinstance(out, dict):
            for key in ("fiddler_application_id", "application_id"):
                if isinstance(out.get(key), str) and out[key].strip():
                    return out[key].strip()
    return None


def _run_hooks(hooks: list[AgentHook], agent: AgentRecord, registry: Any, *, env: str, context: dict) -> None:
    results = run_registered_hooks(hooks, agent, env=env, context=context)
    app_id = _application_id(results)
    if app_id and hasattr(registry, "set_fiddler_application_id"):
        try:
            registry.set_fiddler_application_id(agent.agent_id, app_id)
        except Exception as exc:
            log.warning("could not store the Fiddler application id for %s: %s", agent.agent_id, type(exc).__name__)


@router.get("", response_model=AgentList)
def list_agents(
    request: Request,
    team: str | None = Query(None, max_length=64),
    status: AgentStatusT | None = Query(None),
    q: str | None = Query(None, max_length=200, description="Case-insensitive match on id, name, description, owner"),
    _caller: Caller = Depends(get_caller),
) -> dict:
    agents = request.app.state.agents.all()
    if team:
        agents = [a for a in agents if a.team == team]
    if status:
        agents = [a for a in agents if a.status == status]
    if q:
        needle = q.lower()
        agents = [a for a in agents if any(needle in (v or "").lower() for v in (a.agent_id, a.name, a.description, a.owner))]
    items = [agent_view(a, request.app.state) for a in agents]
    return {"items": items, "total": len(items), "agents": items}


@router.get("/{agent_id}", response_model=AgentEnvelope)
def get_agent(agent_id: str, request: Request, _caller: Caller = Depends(get_caller)) -> dict:
    agent = request.app.state.agents.get(agent_id)
    if agent is None:
        raise ApiError(404, "agent_not_found", f"agent {agent_id!r} is not registered")
    return {"agent": agent_view(agent, request.app.state)}


@router.post("", status_code=201, response_model=AgentRegistered)
def register_agent(
    body: AgentCreate, request: Request, background: BackgroundTasks, caller: Caller = Depends(get_caller)
) -> dict:
    if not AGENT_ID_RE.match(body.agent_id):
        raise ApiError(400, "invalid_agent_id", "agent_id must match [A-Za-z0-9._-]{1,64}")
    if caller.is_service:
        if not body.owner or not body.team:
            raise ApiError(400, "invalid_request", "service callers must give owner and team")
        owner, team = body.owner.strip(), body.team.strip()
    elif caller.is_admin:
        owner = (body.owner or "").strip() or caller.email
        team = (body.team or "").strip() or (caller.team or "")
    else:
        # Users register for themselves and their directory team (body owner/team are ignored), so
        # nobody can create an agent that passes the gateway's team check for another team.
        owner, team = caller.email, caller.team or ""
    if not TEAM_RE.match(team):
        raise ApiError(400, "invalid_agent", "team must match [A-Za-z0-9._-]{1,64}")
    lifecycle = "draft"
    if body.lifecycle == "active":
        if not (caller.is_service or caller.is_admin):
            raise forbidden("only admins and the service token may register an agent as active")
        lifecycle = "active"
    tags = _clean_tags(body.tags)
    registry = _mutable(request)
    name = (body.name or "").strip() or body.agent_id
    try:
        agent = registry.register(
            AgentRecord(agent_id=body.agent_id, owner=owner, team=team, description=body.description, name=name,
                        lifecycle=lifecycle, tags=tuple(tags), docs_url=_clean_docs_url(body.docs_url),
                        data_classification=body.data_classification or "")
        )
    except AgentRegistryError as exc:
        raise _registry_error(exc) from None
    log.info("agent registered: %s team=%s", agent.agent_id, agent.team)
    _audit(request, actor=caller.email, action="agent.register", agent_id=agent.agent_id,
           details={"owner": owner, "team": team, "lifecycle": lifecycle})
    state = request.app.state
    hooks = state.agent_hooks
    if hooks:
        token = state.secrets.get("FIDDLER_API_KEY")
        context = {"fiddler_url": state.env_config.fiddler_url, "fiddler_api_key": token}
        background.add_task(_run_hooks, hooks, agent, registry, env=state.settings.env, context=context)
    return {"agent": agent_view(agent, state), "hooks": [{"hook": h.name, "status": "scheduled"} for h in hooks]}


@router.patch("/{agent_id}", response_model=AgentEnvelope)
def update_agent(agent_id: str, body: AgentPatch, request: Request, caller: Caller = Depends(get_user)) -> dict:
    registry = request.app.state.agents
    current = registry.get(agent_id)
    if current is None:
        raise ApiError(404, "agent_not_found", f"agent {agent_id!r} is not registered")
    is_owner = current.owner.lower() == caller.email.lower() and not current.builtin
    if not (caller.is_admin or is_owner):
        raise forbidden("only the agent's owner or an admin may change it")
    if not hasattr(registry, "update"):
        raise ApiError(501, "registry_read_only", "the configured agent registry does not support changes")
    changes = body.model_dump(exclude_none=True)
    if "tags" in changes:
        changes["tags"] = _clean_tags(changes["tags"])
    if "docs_url" in changes:
        changes["docs_url"] = _clean_docs_url(changes["docs_url"])
    try:
        agent = registry.update(agent_id, **changes)
    except AgentRegistryError as exc:
        raise _registry_error(exc) from None
    _audit(request, actor=caller.email, action="agent.update", agent_id=agent_id,
           details={k: v for k, v in changes.items() if k != "description"} | ({"description": True} if "description" in changes else {}))
    return {"agent": agent_view(agent, request.app.state)}


def _set_status(agent_id: str, body: AgentStatusBody, request: Request, caller: Caller, status: str) -> dict:
    if not caller.has("admin", "service"):
        raise forbidden("requires role admin or service")
    registry = _mutable(request)
    before = registry.get(agent_id)
    source = body.source if caller.is_service else (body.source if body.source != "manual" else f"admin:{caller.email}")
    try:
        agent = registry.set_status(agent_id, status, f"{source}: {body.reason}")
    except AgentRegistryError as exc:
        raise _registry_error(exc) from None
    changed = before is not None and before.status != agent.status
    if changed:
        log.warning("agent %s %s by %s", agent_id, status, source)
        _audit(request, actor=caller.email, action=f"agent.{'suspend' if status == 'suspended' else 'reinstate'}",
               agent_id=agent_id, details={"reason": body.reason, "source": source, "evidence": body.evidence or {}})
    return {"agent": agent_view(agent, request.app.state), "changed": changed}


@router.post("/{agent_id}/suspend", response_model=AgentStatusChanged)
def suspend_agent(agent_id: str, body: AgentStatusBody, request: Request, caller: Caller = Depends(get_caller)) -> dict:
    return _set_status(agent_id, body, request, caller, "suspended")


@router.post("/{agent_id}/reinstate", response_model=AgentStatusChanged)
def reinstate_agent(agent_id: str, body: AgentStatusBody, request: Request, caller: Caller = Depends(get_caller)) -> dict:
    return _set_status(agent_id, body, request, caller, "active")



# --- registry v2: versions, verification, lifecycle, access -------------------------------------


def _agent_or_404(request: Request, agent_id: str) -> AgentRecord:
    agent = request.app.state.agents.get(agent_id)
    if agent is None:
        raise ApiError(404, "agent_not_found", f"agent {agent_id!r} is not registered")
    return agent


def _is_owner(agent: AgentRecord, caller: Caller) -> bool:
    return caller.kind == "user" and not agent.builtin and agent.owner.lower() == caller.email.lower()


def _require_v2(registry, *methods: str) -> None:
    if not all(hasattr(registry, m) for m in methods):
        raise ApiError(501, "registry_read_only", "the configured agent registry does not support registry v2")


def _invocation_error(exc: InvocationError) -> ApiError:
    return exc.api_error()


def _version_problem(body: AgentVersionCreate, *, platform_env: str) -> str | None:
    if not VERSION_RE.match(body.version):
        return "version must match [A-Za-z0-9][A-Za-z0-9._+-]{0,127}"
    if body.env == "local" and platform_env != "local":
        return "env local is only accepted when platform-api runs with AIG_ENV=local"
    if body.kind == "https":
        if not body.endpoint or body.runtime_arn or body.qualifier:
            return "kind https needs endpoint and no runtime_arn/qualifier"
        parts = urlsplit(body.endpoint)
        if parts.username or parts.password or parts.query or parts.fragment:
            return "endpoint must not carry credentials, a query or a fragment"
        if not parts.hostname:
            return "endpoint must be an absolute URL"
        loopback = parts.hostname in LOOPBACK_HOSTS
        if parts.scheme == "http" and loopback and platform_env == "local":
            pass  # local testing only
        elif parts.scheme != "https":
            return "endpoint must be https:// (http://localhost only in AIG_ENV=local)"
        elif loopback and platform_env != "local":
            return "loopback endpoints are only accepted in AIG_ENV=local"
    else:
        if body.endpoint or not body.runtime_arn or not AGENTCORE_ARN_RE.match(body.runtime_arn):
            return "kind agentcore needs a bedrock-agentcore runtime_arn (arn:aws:bedrock-agentcore:<region>:<account>:runtime/<id>) and no endpoint"
        if body.qualifier and not QUALIFIER_RE.match(body.qualifier):
            return "qualifier must match [A-Za-z0-9_-]{1,128}"
        if body.auth.type != "none":
            return "kind agentcore is invoked with platform-api's IAM role (SigV4): auth.type must be none"
    if body.auth.type == "none":
        if body.auth.secret_arn:
            return "auth.secret_arn must be empty when auth.type is none"
    elif not body.auth.secret_arn or not valid_secret_ref(body.auth.secret_arn, platform_env):
        return "auth.secret_arn must be a Secrets Manager secret ARN (local:<NAME> only in AIG_ENV=local)"
    for name in ("input_schema", "output_schema"):
        schema = getattr(body, name)
        problem = check_json_schema(schema)
        if problem:
            return f"{name}: {problem}"
        if schema is not None and len(json.dumps(schema)) > MAX_SCHEMA_BYTES:
            return f"{name} exceeds {MAX_SCHEMA_BYTES} bytes"
    if (body.git_sha and not re.match(r"^[0-9a-fA-F]{7,64}$", body.git_sha)):
        return "git_sha must be 7..64 hex characters"
    if body.activate and (not body.verified or body.env != "prod"):
        return "activate needs verified=true and env prod"
    return None


@router.get("/{agent_id}/versions", response_model=AgentVersionList)
def list_versions(agent_id: str, request: Request, env: str | None = Query(None, pattern="^(local|dev|stage|prod)$"),
                  caller: Caller = Depends(get_caller)) -> dict:
    agent = _agent_or_404(request, agent_id)
    if caller.kind == "user" and not caller.is_admin and access_denial(agent, caller):
        raise ApiError(403, "agent_forbidden", "you may not see this agent's versions")
    items = [version_view(v) for v in request.app.state.agent_versions.list(agent_id, env=env)]
    return {"items": items, "total": len(items)}


@router.post("/{agent_id}/versions", response_model=AgentVersionRegistered, status_code=201,
             responses={200: {"model": AgentVersionRegistered, "description": "existing (agent, env, version) replaced"}})
def register_version(agent_id: str, body: AgentVersionCreate, request: Request, response: Response,
                     caller: Caller = Depends(get_caller)) -> dict:
    state = request.app.state
    agent = _agent_or_404(request, agent_id)
    if agent.builtin:
        raise ApiError(400, "version_invalid", "built-in agents have no versions")
    if not caller.is_service:
        if not (caller.is_admin or _is_owner(agent, caller)):
            raise forbidden("only the agent's owner, an admin or the deploy pipeline may register versions")
        if body.kind != "https":
            raise forbidden("AgentCore versions are registered by the deploy pipeline (service token)")
        if body.verified or body.activate:
            raise forbidden("verified/activate are reserved for the deploy pipeline; run verification instead")
    if agent.lifecycle == "retired":
        raise ApiError(409, "agent_not_invocable", "the agent is retired")
    problem = _version_problem(body, platform_env=state.settings.env)
    if problem:
        raise ApiError(400, "version_invalid", problem)
    fields = body.model_dump(include={"kind", "endpoint", "runtime_arn", "qualifier", "protocol", "input_schema",
                                      "output_schema", "git_sha", "image_digest"})
    fields["auth"] = {"type": body.auth.type, "secret_arn": body.auth.secret_arn}
    if fields.get("endpoint"):
        fields["endpoint"] = fields["endpoint"].rstrip("/")
    verification = None
    if body.verified:
        verification = {"passed": True, "code": None, "source": "deploy", "by": caller.email,
                        "at": utcnow().isoformat(timespec="seconds"),
                        "checks": [{"name": "invocation", "status": "passed",
                                    "detail": "registered by the deploy pipeline after its smoke test"}]}
    version, created = state.agent_versions.upsert(agent_id, body.version, body.env, fields=fields,
                                                   created_by=caller.email, verification=verification)
    activated = False
    if body.activate and agent.lifecycle in ("draft", "deprecated"):
        _require_v2(state.agents, "set_lifecycle")
        agent = state.agents.set_lifecycle(agent_id, "active")
        activated = True
    response.status_code = 201 if created else 200
    _audit(request, actor=caller.email, action="agent.version.register", agent_id=agent_id,
           details={"version": body.version, "env": body.env, "kind": body.kind, "created": created,
                    "endpoint": fields.get("endpoint"), "runtime_arn": fields.get("runtime_arn"),
                    "auth_type": body.auth.type, "verified": body.verified, "activated": activated})
    if activated:
        _audit(request, actor=caller.email, action="agent.lifecycle", agent_id=agent_id,
               details={"to": "active", "source": "deploy"})
    return {"version": version_view(version), "created": created, "activated": activated,
            "agent": agent_view(agent, state)}


def _resolve_env(request: Request, agent_id: str, version: str, env: str | None) -> str:
    if env:
        return env
    found = request.app.state.agent_versions.find(agent_id, version)
    if not found:
        raise ApiError(404, "version_not_found", f"version {version!r} is not registered")
    if len({v.env for v in found}) > 1:
        raise ApiError(400, "env_required", f"version {version!r} exists in several environments; pass env=")
    return found[0].env


def _owner_admin_or_service(agent: AgentRecord, caller: Caller) -> None:
    if not (caller.is_service or caller.is_admin or _is_owner(agent, caller)):
        raise forbidden("only the agent's owner, an admin or the service token may do this")


@router.post("/{agent_id}/versions/{version}/verify", response_model=VerifyResult)
async def verify_agent_version(agent_id: str, version: str, request: Request,
                               env: str | None = Query(None, pattern="^(local|dev|stage|prod)$"),
                               body: VerifyBody | None = None, caller: Caller = Depends(get_caller)) -> dict:
    from ..verification import verify_version

    agent = _agent_or_404(request, agent_id)
    _owner_admin_or_service(agent, caller)
    env = _resolve_env(request, agent_id, version, env)
    test_body = None
    if body is not None and (body.input is not None or body.messages is not None):
        test_body = {k: v for k, v in (("input", body.input), ("messages", body.messages)) if v is not None}
    try:
        result = await verify_version(request.app.state, caller, agent_id, version, env, test_body,
                                      activate=body.activate if body else None)
    except InvocationError as exc:
        raise _invocation_error(exc) from None
    result["version"] = version_view(result["version"])
    return result


@router.post("/{agent_id}/versions/{version}/retire", response_model=AgentVersionList)
def retire_version(agent_id: str, version: str, request: Request,
                   env: str | None = Query(None, pattern="^(local|dev|stage|prod)$"),
                   caller: Caller = Depends(get_caller)) -> dict:
    agent = _agent_or_404(request, agent_id)
    _owner_admin_or_service(agent, caller)
    env = _resolve_env(request, agent_id, version, env)
    try:
        request.app.state.agent_versions.set_status(agent_id, version, env, "retired")
    except AgentRegistryError as exc:
        raise _registry_error(exc) from None
    _audit(request, actor=caller.email, action="agent.version.retire", agent_id=agent_id,
           details={"version": version, "env": env})
    items = [version_view(v) for v in request.app.state.agent_versions.list(agent_id)]
    return {"items": items, "total": len(items)}


@router.post("/{agent_id}/lifecycle", response_model=AgentEnvelope)
def change_lifecycle(agent_id: str, body: LifecycleBody, request: Request, caller: Caller = Depends(get_user)) -> dict:
    state = request.app.state
    agent = _agent_or_404(request, agent_id)
    if not (caller.is_admin or _is_owner(agent, caller)):
        raise forbidden("only the agent's owner or an admin may change its lifecycle")
    _require_v2(state.agents, "set_lifecycle")
    target: LifecycleT = body.to
    if agent.builtin:
        raise ApiError(409, "invalid_transition", "built-in agents are always active")
    if agent.lifecycle == target:
        return {"agent": agent_view(agent, state)}
    if not lifecycle_transition_allowed(agent.lifecycle, target):
        raise ApiError(409, "invalid_transition", f"lifecycle {agent.lifecycle} -> {target} is not allowed")
    if target == "active" and not any(v.verified for v in state.agent_versions.list(agent_id, include_retired=False)):
        raise ApiError(409, "verification_required", "activation needs at least one active, verified version")
    updated = state.agents.set_lifecycle(agent_id, target)
    _audit(request, actor=caller.email, action="agent.lifecycle", agent_id=agent_id,
           details={"from": agent.lifecycle, "to": target, "reason": body.reason or ""})
    return {"agent": agent_view(updated, state)}


@router.put("/{agent_id}/access", response_model=AgentEnvelope)
def set_access(agent_id: str, body: AccessBody, request: Request, caller: Caller = Depends(get_user)) -> dict:
    state = request.app.state
    agent = _agent_or_404(request, agent_id)
    if not (caller.is_admin or _is_owner(agent, caller)):
        raise forbidden("only the agent's owner or an admin may change who can run it")
    if agent.builtin:
        raise ApiError(400, "invalid_request", "built-in agents have no access settings")
    _require_v2(state.agents, "set_access")
    groups = list(dict.fromkeys(g.strip() for g in body.allowed_groups if g.strip()))
    bad = [g for g in groups if not GROUP_RE.match(g)]
    if bad or len(groups) > MAX_ALLOWED_GROUPS:
        raise ApiError(400, "invalid_request", f"allowed_groups: at most {MAX_ALLOWED_GROUPS} ids/names matching [A-Za-z0-9 ._@:-]{{1,128}}")
    if body.visibility == "team":
        groups = []
    if body.visibility == "org":
        approval = "approved" if (agent.visibility == "org" and agent.org_approval == "approved") else "pending"
    else:
        approval = "none"
    updated = state.agents.set_access(agent_id, visibility=body.visibility, allowed_groups=groups, org_approval=approval)
    _audit(request, actor=caller.email, action="agent.access", agent_id=agent_id,
           details={"visibility": body.visibility, "allowed_groups": groups, "org_approval": approval,
                    "previous": {"visibility": agent.visibility, "allowed_groups": list(agent.allowed_groups)}})
    return {"agent": agent_view(updated, state)}


def _decide_access(agent_id: str, body: AccessDecision | None, request: Request, caller: Caller, decision: str) -> dict:
    state = request.app.state
    if not caller.is_admin:
        raise forbidden("requires role admin")
    agent = _agent_or_404(request, agent_id)
    if agent.visibility != "org" or agent.org_approval != "pending":
        raise ApiError(409, "invalid_transition", f"org-wide access is not pending (visibility={agent.visibility}, "
                                                  f"org_approval={agent.org_approval})")
    _require_v2(state.agents, "set_access")
    updated = state.agents.set_access(agent_id, visibility=agent.visibility, allowed_groups=list(agent.allowed_groups),
                                      org_approval=decision, org_approval_by=caller.email)
    _audit(request, actor=caller.email, action=f"agent.access.{'approve' if decision == 'approved' else 'reject'}",
           agent_id=agent_id, details={"reason": (body.reason if body else None) or ""})
    return {"agent": agent_view(updated, state)}


@router.post("/{agent_id}/access/approve", response_model=AgentEnvelope)
def approve_access(agent_id: str, request: Request, body: AccessDecision | None = None,
                   caller: Caller = Depends(get_user)) -> dict:
    return _decide_access(agent_id, body, request, caller, "approved")


@router.post("/{agent_id}/access/reject", response_model=AgentEnvelope)
def reject_access(agent_id: str, request: Request, body: AccessDecision | None = None,
                  caller: Caller = Depends(get_user)) -> dict:
    return _decide_access(agent_id, body, request, caller, "rejected")
