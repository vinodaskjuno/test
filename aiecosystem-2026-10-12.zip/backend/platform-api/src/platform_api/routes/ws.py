"""WebSocket endpoint for the VS Code extension and the web portal: chat streaming, live usage, keepalive.

GET /api/v1/ws  (Authorization: Bearer <token> on the upgrade request, or - for browsers, which
cannot set headers on a WebSocket - the subprotocols ["aig.bearer", "<token>"]; the server then
selects only "aig.bearer" and never echoes the token)

The socket is always accepted first; authentication / origin failures then close it
immediately with 4401 "unauthenticated" / 4403 "forbidden_origin" so clients can read
the reason. Protocol: JSON text frames, each with a "type" (see README "WebSocket").

Chat reuses the HTTP proxy's preparation (``prepare_llm_call``): same server-side key
injection, config id, server-built metadata, job-profile/agent-id validation and trace
ids. Usage reuses ``build_dashboard`` (and its cache). Secret values are redacted from
every outbound frame; nothing secret is ever logged.

Agent invocation (registry v2) reuses ``Invoker`` (same access, version and input checks as
``POST /api/v1/agents/{id}/invoke``): client frames ``agent.invoke`` / ``agent.cancel``; server
frames ``agent.invocation.status`` / ``agent.delta`` / ``agent.output`` / ``agent.error`` /
``agent.done``. Chats and foreground agent runs share the per-socket concurrency limit; background
runs continue after the socket closes and push ``agent.invocation.status`` to every socket of the
caller.
"""

from __future__ import annotations

import base64

import asyncio
import json
import logging
import re
import time
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import APIRouter, WebSocket
from starlette.websockets import WebSocketState

from ..auth import Principal, principal_from_header
from ..agents import AGENT_ID_RE, HOST_BY_BUILTIN_AGENT
from ..authz import user_caller
from ..errors import ApiError
from ..usage_events import cache_status, forward_chat_usage
from ..usage_limits import apply_usage_state
from ..redaction import TextRedactor as _TextRedactor
from .llm import HOST, LlmCall, note_agent_seen, prepare_llm_call, redact_text, route_info
from .usage import build_user_dashboard

router = APIRouter(prefix="/api/v1")
log = logging.getLogger(__name__)

MAX_FRAME_BYTES = 64 * 1024
MAX_CONCURRENT_CHATS = 4
CHAT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
USAGE_DAYS = (7, 30, 90)
ROLES = ("system", "user", "assistant", "tool", "developer")
MAX_UPSTREAM_ERROR_BODY = 8 * 1024
CLOSE_UNAUTHENTICATED = 4401
CLOSE_FORBIDDEN_ORIGIN = 4403
# Browser auth: Sec-WebSocket-Protocol: aig.bearer, <token>. Only "aig.bearer" is ever selected.
BEARER_SUBPROTOCOL = "aig.bearer"


class BadRequest(Exception):
    pass


def _origin_allowed(origin: str | None, allowed: list[str]) -> bool:
    if origin is None:
        return True  # non-browser clients (VS Code's Node `ws`) send no Origin
    return origin.rstrip("/") in {o.rstrip("/") for o in allowed}


def _subprotocols(ws: WebSocket) -> list[str]:
    """Offered subprotocols (never logged: the second entry may be a bearer token)."""
    raw = ws.headers.get("sec-websocket-protocol") or ""
    return [p.strip() for p in raw.split(",") if p.strip()]


B64U_PREFIX = "b64u."


def _subprotocol_token(offered: list[str]) -> str | None:
    """Token from ["aig.bearer", <token>]. Browsers only allow RFC 7230 token characters in
    subprotocols, so clients may send it base64url-encoded as "b64u.<base64url-no-padding>"."""
    if len(offered) < 2 or offered[0] != BEARER_SUBPROTOCOL:
        return None
    value = offered[1]
    if not value.startswith(B64U_PREFIX):
        return value
    enc = value[len(B64U_PREFIX):]
    if not enc or len(enc) > 16384:
        return None
    try:
        token = base64.urlsafe_b64decode(enc + "=" * (-len(enc) % 4)).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return None
    return token or None


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _is_num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _chat_body(msg: dict) -> dict:
    messages = msg.get("messages")
    if not isinstance(messages, list) or not messages:
        raise BadRequest("messages must be a non-empty array")
    clean = []
    for m in messages:
        if not isinstance(m, dict) or not isinstance(m.get("role"), str) or m["role"] not in ROLES:
            raise BadRequest(f"each message needs a role in {list(ROLES)}")
        if not isinstance(m.get("content"), (str, list)):
            raise BadRequest("each message needs content (string or array of parts)")
        clean.append({"role": m["role"], "content": m["content"]})
    body: dict[str, Any] = {"messages": clean, "stream": True, "stream_options": {"include_usage": True}}
    if "model" in msg and msg["model"] is not None:
        if not isinstance(msg["model"], str) or not msg["model"].strip() or len(msg["model"]) > 200:
            raise BadRequest("model must be a non-empty string")
        body["model"] = msg["model"]
    if "temperature" in msg and msg["temperature"] is not None:
        if not _is_num(msg["temperature"]) or not 0 <= msg["temperature"] <= 2:
            raise BadRequest("temperature must be a number between 0 and 2")
        body["temperature"] = msg["temperature"]
    if "max_tokens" in msg and msg["max_tokens"] is not None:
        if not _is_int(msg["max_tokens"]) or msg["max_tokens"] < 1:
            raise BadRequest("max_tokens must be a positive integer")
        body["max_tokens"] = msg["max_tokens"]
    for key in ("job_profile", "agent_id"):
        if msg.get(key) is not None and not isinstance(msg[key], str):
            raise BadRequest(f"{key} must be a string")
    return body


def _usage(obj: Any) -> dict | None:
    if not isinstance(obj, dict):
        return None
    out = {k: obj[k] for k in ("prompt_tokens", "completion_tokens", "total_tokens") if _is_int(obj.get(k))}
    return out or None


class _Session:
    def __init__(self, ws: WebSocket, principal: Principal):
        self.ws = ws
        self.state = ws.app.state
        self.principal = principal
        self.send_lock = asyncio.Lock()
        self.closed = False
        self.chats: dict[str, asyncio.Task] = {}
        self.usage_task: asyncio.Task | None = None
        self.usage_days: int | None = None
        self.background: set[asyncio.Task] = set()
        # Foreground agent runs: client request id -> (task, invocation id).
        self.agent_runs: dict[str, tuple[asyncio.Task, str]] = {}
        self._status_listener = None
        # Browsers (the web portal) always send Origin; VS Code's Node client never does.
        self.host = "web" if ws.headers.get("origin") else HOST

    # ---------- sending ----------

    async def send(self, frame: dict) -> None:
        if self.closed:
            return
        secrets = self.state.secrets.configured_values()
        text = json.dumps(frame, separators=(",", ":"))
        if secrets:
            text = redact_text(text, secrets)
        try:
            async with self.send_lock:
                if self.ws.application_state != WebSocketState.CONNECTED:
                    self.closed = True
                    return
                await self.ws.send_text(text)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # abrupt disconnect mid-send
            self.closed = True
            log.debug("ws send failed: %s", type(exc).__name__)

    async def bad_request(self, message: str) -> None:
        await self.send({"type": "error", "code": "bad_request", "message": message})

    async def chat_error(self, chat_id: str, code: str, message: str, **extra: Any) -> None:
        await self.send({"type": "chat.error", "id": chat_id, "code": code, "message": message, **extra})

    def spawn(self, coro) -> asyncio.Task:
        task = asyncio.create_task(coro)
        self.background.add(task)
        task.add_done_callback(self.background.discard)
        return task

    # ---------- lifecycle ----------

    async def ready(self) -> None:
        profile = self.state.users.lookup(self.principal.email, self.principal.name)
        await self.send(
            {
                "type": "ready",
                "user": {"email": profile.email, "name": profile.name},
                "team": profile.team,
                "env": self.state.settings.env,
                "user_tier": profile.user_tier,
                "allowed_job_profiles": list(self.state.env_config.allowed_job_profiles),
                "server_time": datetime.now(timezone.utc).isoformat(),
            }
        )

    async def keepalive(self) -> None:
        while not self.closed:
            await asyncio.sleep(self.state.settings.ws_ping_interval_seconds)
            await self.send({"type": "ping"})

    async def run(self) -> None:
        self.spawn(self.keepalive())
        runner = getattr(self.state, "invocation_runner", None)
        if runner is not None:
            self._status_listener = self.send
            runner.subscribe(self.principal.email, self._status_listener)
        await self.ready()
        while not self.closed:
            message = await self.ws.receive()
            if message["type"] == "websocket.disconnect":
                break
            if message.get("text") is not None:
                raw = message["text"]
                size = len(raw.encode("utf-8", "surrogatepass"))
            else:
                await self.bad_request("binary frames are not supported; send JSON text frames")
                continue
            if size > MAX_FRAME_BYTES:
                await self.bad_request(f"frame exceeds {MAX_FRAME_BYTES} bytes")
                continue
            try:
                msg = json.loads(raw)
            except ValueError:
                await self.bad_request("frame must be valid JSON")
                continue
            if not isinstance(msg, dict) or not isinstance(msg.get("type"), str):
                await self.bad_request('frame must be a JSON object with a "type"')
                continue
            await self.dispatch(msg)

    async def dispatch(self, msg: dict) -> None:
        kind = msg["type"]
        if kind == "ping":
            await self.send({"type": "pong"})
        elif kind == "pong":
            pass  # reply to our keepalive; ignored
        elif kind == "chat":
            await self.start_chat(msg)
        elif kind == "cancel":
            await self.cancel_chat(msg)
        elif kind == "usage.subscribe":
            await self.subscribe_usage(msg)
        elif kind == "usage.unsubscribe":
            self.stop_usage()
        elif kind == "agent.invoke":
            await self.start_agent(msg)
        elif kind == "agent.cancel":
            await self.cancel_agent(msg)
        else:
            await self.bad_request(f"unknown message type: {kind[:64]}")

    async def shutdown(self) -> None:
        self.closed = True
        runner = getattr(self.state, "invocation_runner", None)
        if runner is not None and self._status_listener is not None:
            runner.unsubscribe(self.principal.email, self._status_listener)
        tasks = [*self.chats.values(), *self.background, *(t for t, _ in self.agent_runs.values())]
        self.agent_runs.clear()
        if self.usage_task:
            tasks.append(self.usage_task)
        self.chats.clear()
        self.usage_task = None
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    # ---------- chat ----------

    async def start_chat(self, msg: dict) -> None:
        chat_id = msg.get("id")
        if not isinstance(chat_id, str) or not CHAT_ID_RE.match(chat_id):
            await self.bad_request("chat id must match [A-Za-z0-9_-]{1,64}")
            return
        if chat_id in self.chats:
            await self.chat_error(chat_id, "duplicate_id", "a chat with this id is already running")
            return
        if len(self.chats) + len(self.agent_runs) >= MAX_CONCURRENT_CHATS:
            await self.chat_error(
                chat_id, "too_many_requests", f"at most {MAX_CONCURRENT_CHATS} concurrent chats per connection"
            )
            return
        try:
            body = _chat_body(msg)
        except BadRequest as exc:
            await self.chat_error(chat_id, "bad_request", str(exc))
            return
        try:
            call = prepare_llm_call(
                self.state, self.principal, job_profile=msg.get("job_profile"), agent_id=msg.get("agent_id"),
                host=HOST_BY_BUILTIN_AGENT.get(msg.get("agent_id") or "", self.host),
            )
        except ApiError as exc:
            await self.chat_error(chat_id, exc.code, exc.message, trace_id=exc.headers.get("x-aig-trace-id"))
            return
        note_agent_seen(self.state, call.agent_id, self.host)
        task = asyncio.create_task(self.run_chat(chat_id, call, body))
        self.chats[chat_id] = task

    async def cancel_chat(self, msg: dict) -> None:
        chat_id = msg.get("id")
        if not isinstance(chat_id, str) or not CHAT_ID_RE.match(chat_id):
            await self.bad_request("cancel needs a valid chat id")
            return
        task = self.chats.pop(chat_id, None)
        if task is None:
            await self.chat_error(chat_id, "unknown_id", "no running chat with this id")
            return
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        await self.chat_error(chat_id, "cancelled", "cancelled")

    async def run_chat(self, chat_id: str, call: LlmCall, body: dict) -> None:
        me = asyncio.current_task()
        await apply_usage_state(self.state, call)  # usage-based routing: metadata.usage_state
        started = time.monotonic()
        status: int | str = "error"
        try:
            status = await self._stream_chat(chat_id, call, body)
        except Exception as exc:
            log.warning("ws chat failed trace_id=%s: %s", call.trace_id, type(exc).__name__)
            await self.chat_error(chat_id, "internal_error", "chat failed", trace_id=call.trace_id)
        finally:
            if self.chats.get(chat_id) is me:
                del self.chats[chat_id]
            log.info(
                "ws llm trace_id=%s user=%s job_profile=%s status=%s ms=%d",
                call.trace_id, call.profile.email, call.job_profile, status, (time.monotonic() - started) * 1000,
            )

    async def _stream_chat(self, chat_id: str, call: LlmCall, body: dict) -> int | str:
        """Stream one chat; returns the status for the log line (200 when chat.done was sent)."""
        client: httpx.AsyncClient = self.state.http_client
        trace = {"trace_id": call.trace_id}
        started = time.monotonic()
        try:
            req = client.build_request("POST", call.url, headers=call.headers(True), content=json.dumps(body).encode())
            upstream = await client.send(req, stream=True)
        except httpx.TimeoutException:
            await self.chat_error(chat_id, "upstream_timeout", "Portkey gateway timed out", **trace)
            return 504
        except httpx.RequestError as exc:
            log.warning("ws upstream error trace_id=%s: %s", call.trace_id, type(exc).__name__)
            await self.chat_error(chat_id, "upstream_unavailable", "Portkey gateway unreachable", **trace)
            return 502

        redactor = _TextRedactor(call.secrets)
        usage: dict | None = None
        model: str | None = None
        try:
            if upstream.status_code >= 400:
                detail = await self._upstream_error_message(upstream, call.secrets)
                await self.chat_error(
                    chat_id,
                    "upstream_error",
                    detail or f"Portkey gateway returned {upstream.status_code}",
                    status=upstream.status_code,
                    **trace,
                )
                return upstream.status_code

            async def emit(text: str) -> None:
                if text:
                    await self.send({"type": "chat.delta", "id": chat_id, "text": text})

            try:
                async for line in upstream.aiter_lines():
                    line = line.strip()
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        event = json.loads(data)
                    except ValueError:
                        continue
                    if not isinstance(event, dict):
                        continue
                    if isinstance(event.get("error"), dict):
                        await emit(redactor.flush())
                        err = event["error"]
                        message = redact_text(str(err.get("message") or "Portkey gateway error"), call.secrets)[:500]
                        code = err.get("code") if err.get("code") in ("upstream_timeout", "upstream_interrupted") else "upstream_error"
                        await self.chat_error(chat_id, code, message, **trace)
                        return code
                    usage = _usage(event.get("usage")) or usage
                    if model is None and isinstance(event.get("model"), str):
                        model = event["model"]
                    for choice in event.get("choices") or []:
                        if not isinstance(choice, dict):
                            continue
                        delta = choice.get("delta")
                        if isinstance(delta, dict) and isinstance(delta.get("content"), str):
                            await emit(redactor.feed(delta["content"]))
            except httpx.TimeoutException:
                log.warning("ws upstream stream timed out trace_id=%s", call.trace_id)
                await emit(redactor.flush())
                await self.chat_error(chat_id, "upstream_timeout", "Portkey gateway timed out", **trace)
                return 504
            except (httpx.ReadError, httpx.RemoteProtocolError) as exc:
                log.warning("ws upstream stream interrupted trace_id=%s: %s", call.trace_id, type(exc).__name__)
                await emit(redactor.flush())
                await self.chat_error(
                    chat_id, "upstream_interrupted", "Portkey gateway stream was interrupted", **trace
                )
                return "interrupted"
            await emit(redactor.flush())
            done: dict[str, Any] = {"type": "chat.done", "id": chat_id, "trace_id": call.trace_id}
            if usage:
                done["usage"] = usage
            if model:
                done["model"] = model  # the model Portkey actually served (routing visible to the user)
            done["route"] = route_info(call.metadata)
            await self.send(done)
            forward_chat_usage(
                self.state, metadata=call.metadata, usage=usage, model=model, trace_id=call.trace_id,
                latency_ms=(time.monotonic() - started) * 1000,
                cache=cache_status(upstream.headers.get("x-portkey-cache-status")),
            )
            return 200
        finally:
            await upstream.aclose()

    @staticmethod
    async def _upstream_error_message(upstream: httpx.Response, secrets: list[str]) -> str | None:
        raw = b""
        try:
            async for chunk in upstream.aiter_bytes():
                raw += chunk
                if len(raw) > MAX_UPSTREAM_ERROR_BODY:
                    break
            data = json.loads(raw[:MAX_UPSTREAM_ERROR_BODY])
        except (httpx.HTTPError, ValueError):
            return None
        err = data.get("error") if isinstance(data, dict) else None
        msg = err.get("message") if isinstance(err, dict) else err if isinstance(err, str) else None
        return redact_text(msg, secrets)[:500] if isinstance(msg, str) and msg else None

    # ---------- agents (registry v2) ----------

    async def agent_error(self, request_id: str, code: str, message: str, **extra: Any) -> None:
        await self.send({"type": "agent.error", "id": request_id, "code": code, "message": message, **extra})

    async def start_agent(self, msg: dict) -> None:
        from ..invoker import InvocationError

        request_id = msg.get("id")
        if not isinstance(request_id, str) or not CHAT_ID_RE.match(request_id):
            await self.bad_request("agent.invoke id must match [A-Za-z0-9_-]{1,64}")
            return
        if request_id in self.agent_runs or request_id in self.chats:
            await self.agent_error(request_id, "duplicate_id", "a run with this id is already running")
            return
        agent_id = msg.get("agent_id")
        if not isinstance(agent_id, str) or not AGENT_ID_RE.match(agent_id):
            await self.agent_error(request_id, "bad_request", "agent_id must match [A-Za-z0-9._-]{1,64}")
            return
        for key in ("env", "version"):
            if msg.get(key) is not None and not isinstance(msg[key], str):
                await self.agent_error(request_id, "bad_request", f"{key} must be a string")
                return
        if msg.get("env") is not None and msg["env"] not in ("local", "dev", "stage", "prod"):
            await self.agent_error(request_id, "bad_request", "env must be local, dev, stage or prod")
            return
        background = msg.get("background") is True
        if not background and len(self.chats) + len(self.agent_runs) >= MAX_CONCURRENT_CHATS:
            await self.agent_error(request_id, "too_many_requests",
                                   f"at most {MAX_CONCURRENT_CHATS} concurrent chats and agent runs per connection")
            return
        body = {k: msg[k] for k in ("input", "messages", "session_id") if k in msg}
        invoker = self.state.invoker
        caller = user_caller(self.state, self.principal)
        try:
            plan = invoker.prepare(caller, agent_id, body, env=msg.get("env"), version=msg.get("version"),
                                   mode="background" if background else "stream", trace_id=msg.get("trace_id"))
            handle = invoker.open(plan)
        except InvocationError as exc:
            await self.agent_error(request_id, exc.code, exc.message)
            return
        if background:
            self.state.invocation_runner.start(handle, request_id=request_id)
            await self.send({**self.state.invocation_runner.status_frame(handle, "queued", request_id=request_id),
                             "trace_id": handle.call.trace_id})
            return
        task = asyncio.create_task(self.run_agent(request_id, handle))
        self.agent_runs[request_id] = (task, handle.id)

    async def run_agent(self, request_id: str, handle) -> None:
        me = asyncio.current_task()
        base = {"id": request_id, "invocation_id": handle.id}
        try:
            await self.send({"type": "agent.invocation.status", **base, "agent_id": handle.plan.agent.agent_id,
                             "version": handle.plan.version.version, "env": handle.plan.version.env,
                             "mode": handle.plan.mode, "status": "running", "trace_id": handle.call.trace_id})
            async for event in self.state.invoker.run(handle):
                data = {k: v for k, v in event["data"].items() if k != "invocation_id"}
                await self.send({"type": f"agent.{event['event']}", **base, **data})
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("ws agent run failed %s: %s", handle.id, type(exc).__name__)
            await self.agent_error(request_id, "internal_error", "agent run failed", invocation_id=handle.id)
        finally:
            current = self.agent_runs.get(request_id)
            if current is not None and current[0] is me:
                del self.agent_runs[request_id]

    async def cancel_agent(self, msg: dict) -> None:
        request_id, invocation_id = msg.get("id"), msg.get("invocation_id")
        if isinstance(request_id, str) and request_id in self.agent_runs:
            _task, inv_id = self.agent_runs[request_id]
            if self.state.invoker.cancel(inv_id):  # the run sends agent.error invocation_cancelled + agent.done
                inv = self.state.invocations.get(inv_id)
                self.state.invoker.audit_cancel(self.principal.email, inv_id, inv.agent_id if inv else "", via="ws")
            return
        if isinstance(invocation_id, str):
            inv = self.state.invocations.get(invocation_id)
            if inv is not None and inv.caller.lower() == self.principal.email.lower() and not inv.final:
                self.state.invoker.cancel(invocation_id)
                self.state.invoker.audit_cancel(self.principal.email, invocation_id, inv.agent_id, via="ws")
                task = self.state.invocation_runner.tasks.get(invocation_id)
                if task is None:
                    self.state.invocations.finish(invocation_id, status="cancelled", error_code="invocation_cancelled",
                                                  error_message="cancelled by the caller")
                return
        rid = request_id if isinstance(request_id, str) and CHAT_ID_RE.match(request_id) else ""
        await self.agent_error(rid, "unknown_id", "no running agent invocation with this id")

    # ---------- usage ----------

    async def subscribe_usage(self, msg: dict) -> None:
        days = msg.get("days", 30)
        if not _is_int(days) or days not in USAGE_DAYS:
            await self.bad_request(f"days must be one of {list(USAGE_DAYS)}")
            return
        self.stop_usage()
        self.usage_days = days
        self.usage_task = asyncio.create_task(self.usage_loop(days))

    def stop_usage(self) -> None:
        self.usage_days = None
        if self.usage_task:
            self.usage_task.cancel()
            self.usage_task = None

    async def usage_loop(self, days: int) -> None:
        # One push per subscribe: the dashboards refresh only when the user asks (refresh button
        # re-subscribes or calls GET /api/v1/usage/dashboard). No periodic pushes.
        await self.push_usage(days)

    async def push_usage(self, days: int) -> None:
        try:
            data = await build_user_dashboard(self.state, self.principal.email, days)
        except ApiError as exc:
            await self.send({"type": "usage.error", "code": exc.code, "message": exc.message})
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("ws usage push failed: %s", type(exc).__name__)
            await self.send({"type": "usage.error", "code": "internal_error", "message": "usage lookup failed"})
            return
        if self.usage_days == days:  # skip if unsubscribed/replaced meanwhile
            await self.send({"type": "usage", "days": days, "data": data})


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket) -> None:
    state = ws.app.state
    offered = _subprotocols(ws)
    # Browsers fail the handshake unless one offered subprotocol is selected, so "aig.bearer" is
    # selected whenever it is offered first. The token entry is never selected or echoed.
    await ws.accept(subprotocol=BEARER_SUBPROTOCOL if offered[:1] == [BEARER_SUBPROTOCOL] else None)
    if not _origin_allowed(ws.headers.get("origin"), state.env_config.browser_origins):
        await ws.close(code=CLOSE_FORBIDDEN_ORIGIN, reason="forbidden_origin")
        return
    header = ws.headers.get("authorization")
    token = _subprotocol_token(offered)
    try:
        if header:
            principal = principal_from_header(state.authenticator, header)
        elif token:
            principal = principal_from_header(state.authenticator, f"Bearer {token}")
        else:
            raise ApiError(401, "unauthenticated")
    except ApiError:
        await ws.close(code=CLOSE_UNAUTHENTICATED, reason="unauthenticated")
        return

    session = _Session(ws, principal)
    try:
        await session.run()
    except Exception as exc:  # abrupt disconnects surface as various transport errors
        log.debug("ws session ended: %s", type(exc).__name__)
    finally:
        await session.shutdown()
        if ws.application_state == WebSocketState.CONNECTED and ws.client_state == WebSocketState.CONNECTED:
            try:
                await ws.close()
            except Exception:
                pass
