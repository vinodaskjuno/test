"""Model catalog and approval gate (Phase 4 data model; Phase 7 model harness drives it).

Lifecycle::

    requested -> sandbox -> evaluating -> approved -> canary -> promoted
                                       \\-> rejected          \\-> rolled_back

| Method | Path | Auth |
|---|---|---|
| GET  | /api/v1/models?status=             | any user or service |
| POST | /api/v1/models                     | any user (creates a ``requested`` entry) |
| GET  | /api/v1/models/{id}                | any user or service |
| POST | /api/v1/models/{id}/transition     | ``approved``/``rejected``/``promoted``/``rolled_back``: approver; other steps: admin or service |
| PUT  | /api/v1/models/{id}/scorecard      | admin or service (the Phase 7 model harness, ``aig-model eval``) |
| PUT  | /api/v1/models/{id}/canary-pr      | admin or service (the model-canary workflow records its PR) |

Phase 7:

- ``requested -> sandbox`` creates a sandbox-only Portkey key (``model_harness.create_sandbox_key``,
  ``AIG_MODEL_SANDBOX_SYNC``); the outcome is recorded, the transition never fails because of it.
- A scorecard write evaluates the approval gate (``model_gate``) for every requested tier and
  stores it as ``gate``. Scorecards from offline runs, or whose datasets are not ``synthetic`` /
  ``masked``, are refused.
- ``-> approved`` needs the approver role **and** a passing gate (re-evaluated now, with the
  configured thresholds): otherwise ``409 approval_gate_failed``. There is no bypass, not even for
  admins. Approve and reject are audit-logged with the scorecard snapshot and the gate result.
- ``-> canary | promoted | rolled_back`` emit a GitHub repository_dispatch
  (``model_harness.dispatch_canary``, ``AIG_CANARY_DISPATCH``) so the model-canary workflow opens the
  gateway manifest PR (``aigw canary set|promote|rollback``); the outcome is recorded.

Every transition, scorecard write and side effect is audit-logged with its note/evidence.
"""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import select

from ..authz import Caller, forbidden, get_caller, get_user, require_roles
from ..db import ModelRow, add_audit, iso, utcnow
from ..errors import ApiError
from ..model_gate import evaluate, failure_summary
from ..model_harness import DISPATCH_EVENTS, create_sandbox_key, dispatch_canary, model_alias, provider_model_id
from ..schemas import CanaryPr, Model, ModelCreate, ModelList, ModelStatus, ModelTransition, Scorecard

router = APIRouter(prefix="/api/v1/models", tags=["models"])

TRANSITIONS: dict[str, tuple[str, ...]] = {
    "requested": ("sandbox",),
    "sandbox": ("evaluating",),
    "evaluating": ("approved", "rejected"),
    "approved": ("canary",),
    "canary": ("promoted", "rolled_back"),
    "rejected": (),
    "promoted": (),
    "rolled_back": (),
}
APPROVER_STATES = frozenset({"approved", "rejected", "promoted", "rolled_back"})
DEFAULT_CANARY_SHARE = 10.0
SANDBOX_CLASSIFICATIONS = ("synthetic", "masked")


def view(row: ModelRow) -> dict:
    gate = row.gate
    return {
        "id": row.id, "name": row.name, "provider": row.provider, "version": row.version,
        "tiers": list(row.tiers or []), "job_profiles": list(row.job_profiles or []), "use_case": row.use_case or "",
        "data_classification": row.data_classification, "expected_monthly_cost_usd": row.expected_monthly_cost_usd,
        "status": row.status, "requested_by": row.requested_by, "scorecard": row.scorecard,
        "canary_share": row.canary_share, "canary_started_at": iso(row.canary_started_at),
        "decided_by": row.decided_by, "decided_at": iso(row.decided_at),
        "allowed_transitions": list(TRANSITIONS.get(row.status, ())),
        "created_at": iso(row.created_at), "updated_at": iso(row.updated_at),
        "routing_model_id": provider_model_id(row.name, row.version),
        "canary_alias": model_alias(row.name, row.version),
        "sandbox_key_status": row.sandbox_key_status or "not_created",
        "sandbox_key_id": row.sandbox_key_id, "sandbox_error": row.sandbox_error,
        "gate": gate,
        "ready_for_approval": row.status == "evaluating" and bool(gate and gate.get("passed")),
        "canary_dispatch_status": row.canary_dispatch_status or "not_sent",
        "canary_dispatch_error": row.canary_dispatch_error, "canary_pr_url": row.canary_pr_url,
    }


def _get(s, model_id: str) -> ModelRow:
    row = s.get(ModelRow, model_id)
    if row is None:
        raise ApiError(404, "model_not_found", f"model {model_id!r} not found")
    return row


def _gate(request: Request, scorecard: dict | None, tiers: list[str]) -> dict:
    result = evaluate(scorecard, tiers, getattr(request.app.state, "gate_thresholds", None))
    result["evaluated_at"] = iso(utcnow())
    return result


@router.get("", response_model=ModelList)
def list_models(request: Request, status: ModelStatus | None = Query(None), _caller: Caller = Depends(get_caller)) -> dict:
    with request.app.state.db.session() as s:
        stmt = select(ModelRow).order_by(ModelRow.created_at.desc(), ModelRow.id)
        if status:
            stmt = stmt.where(ModelRow.status == status)
        items = [view(r) for r in s.scalars(stmt)]
    return {"items": items, "total": len(items)}


@router.post("", status_code=201, response_model=Model)
def request_model(body: ModelCreate, request: Request, caller: Caller = Depends(get_user)) -> dict:
    name, provider, version = body.name.strip(), body.provider.strip(), body.version.strip()
    if not (name and provider and version):
        raise ApiError(400, "invalid_request", "name, provider and version are required")
    with request.app.state.db.session() as s:
        exists = s.scalars(
            select(ModelRow).where(ModelRow.provider == provider, ModelRow.name == name, ModelRow.version == version)
        ).first()
        if exists is not None:
            raise ApiError(409, "model_exists", f"{provider}/{name}@{version} is already in the catalog ({exists.id})")
        now = utcnow()
        row = ModelRow(
            id=str(uuid.uuid4()), name=name, provider=provider, version=version,
            tiers=list(dict.fromkeys(body.tiers)), job_profiles=list(dict.fromkeys(body.job_profiles)),
            use_case=body.use_case, data_classification=body.data_classification,
            expected_monthly_cost_usd=body.expected_monthly_cost_usd, status="requested",
            requested_by=caller.email, sandbox_key_status="not_created", canary_dispatch_status="not_sent",
            created_at=now, updated_at=now,
        )
        s.add(row)
        add_audit(s, actor=caller.email, action="model.request", entity_type="model", entity_id=row.id,
                  details={"name": name, "provider": provider, "version": version,
                           "data_classification": body.data_classification})
        s.flush()
        return view(row)


@router.get("/{model_id}", response_model=Model)
def get_model(model_id: str, request: Request, _caller: Caller = Depends(get_caller)) -> dict:
    with request.app.state.db.session() as s:
        return view(_get(s, model_id))


def _refuse_approval(request: Request, model_id: str, caller: Caller, gate: dict, note: str | None) -> None:
    """Record the refused approval (its own transaction), then answer 409."""
    with request.app.state.db.session() as s:
        row = _get(s, model_id)
        row.gate = gate
        add_audit(s, actor=caller.email, action="model.approval_refused", entity_type="model", entity_id=model_id,
                  details={"note": note, "gate": gate, "scorecard": row.scorecard})
    raise ApiError(409, "approval_gate_failed", f"approval gate not met: {failure_summary(gate)}")


def _apply_transition(request: Request, model_id: str, body: ModelTransition, caller: Caller) -> dict:
    target = body.to
    with request.app.state.db.session() as s:
        row = _get(s, model_id)
        current = row.status
        if target not in TRANSITIONS.get(current, ()):
            allowed = ", ".join(TRANSITIONS.get(current, ())) or "none (final state)"
            raise ApiError(409, "invalid_transition", f"cannot move a {current} model to {target}; allowed: {allowed}")
        gate = None
        if target in ("approved", "rejected"):
            gate = _gate(request, row.scorecard, list(row.tiers or []))
            if target == "approved" and not gate["passed"]:
                return {"refused": gate}  # nothing changes; the refusal is audit-logged separately
            row.gate = gate
        now = utcnow()
        row.status, row.updated_at = target, now
        if target in APPROVER_STATES:
            row.decided_by, row.decided_at = caller.email, now
        if target == "canary":
            row.canary_share = body.canary_share if body.canary_share is not None else DEFAULT_CANARY_SHARE
            row.canary_started_at = now
        elif target == "promoted":
            row.canary_share = 100.0
        elif target == "rolled_back":
            row.canary_share = 0.0
        details: dict[str, Any] = {
            "from": current, "to": target, "note": body.note, "canary_share": row.canary_share,
            "scorecard_passed": (row.scorecard or {}).get("passed"),
            "evidence_url": (row.scorecard or {}).get("evidence_url"),
        }
        if gate is not None:
            # Approval-gate evidence: the scorecard as it was decided on, and the gate result.
            details["scorecard"] = row.scorecard
            details["gate"] = gate
        add_audit(s, actor=caller.email, action="model.transition", entity_type="model", entity_id=row.id,
                  details=details)
        s.flush()
        return view(row)


@router.post("/{model_id}/transition", response_model=Model)
async def transition_model(model_id: str, body: ModelTransition, request: Request,
                           caller: Caller = Depends(get_caller)) -> dict:
    target = body.to
    if target in APPROVER_STATES:
        if not caller.has("approver"):
            raise forbidden(f"moving a model to {target} requires role approver")
    elif not caller.has("admin", "service"):
        raise forbidden(f"moving a model to {target} requires role admin or service")
    if body.canary_share is not None and target != "canary":
        raise ApiError(400, "invalid_request", "canary_share is only accepted with to=canary")
    result = _apply_transition(request, model_id, body, caller)
    if "refused" in result:
        _refuse_approval(request, model_id, caller, result["refused"], body.note)
    state: Any = request.app.state
    if target == "sandbox":
        status, key_id, error = await create_sandbox_key(state, result)
        return _record(request, model_id, caller, "model.sandbox_key",
                       {"sandbox_key_status": status, "sandbox_key_id": key_id, "sandbox_error": error},
                       audit=status != "disabled")
    if target in DISPATCH_EVENTS:
        status, error = await dispatch_canary(state, result, target, body.note)
        return _record(request, model_id, caller, "model.canary_dispatch",
                       {"canary_dispatch_status": status, "canary_dispatch_error": error,
                        **({"canary_pr_url": None} if target == "canary" else {})},
                       audit=status != "disabled", extra={"event": DISPATCH_EVENTS[target]})
    return result


def _record(request: Request, model_id: str, caller: Caller, action: str, fields: dict, *, audit: bool,
            extra: dict | None = None) -> dict:
    with request.app.state.db.session() as s:
        row = _get(s, model_id)
        for k, v in fields.items():
            setattr(row, k, v)
        row.updated_at = utcnow()
        if audit:
            add_audit(s, actor=caller.email, action=action, entity_type="model", entity_id=row.id,
                      details={**{k: v for k, v in fields.items() if k != "canary_pr_url"}, **(extra or {})})
        s.flush()
        return view(row)


def _check_policy(body: Scorecard) -> None:
    if body.mode == "offline":
        raise ApiError(400, "offline_scorecard_refused",
                       "offline harness runs (no Fiddler, no Portkey) are never recorded; run aig-model eval without --offline")
    bad = [f"{d.name} ({d.classification})" for d in body.datasets if d.classification not in SANDBOX_CLASSIFICATIONS]
    if bad:
        raise ApiError(400, "dataset_classification_refused",
                       f"sandbox eval datasets must be synthetic or masked: {', '.join(bad)}")


@router.put("/{model_id}/scorecard", response_model=Model)
def put_scorecard(
    model_id: str, body: Scorecard, request: Request, caller: Caller = Depends(require_roles("admin", "service"))
) -> dict:
    _check_policy(body)
    with request.app.state.db.session() as s:
        row = _get(s, model_id)
        if row.status in ("rejected", "promoted", "rolled_back"):
            raise ApiError(409, "invalid_transition", f"the scorecard of a {row.status} model cannot change")
        now = utcnow()
        card = body.model_dump()
        row.scorecard = {**card, "updated_at": iso(now), "updated_by": caller.email}
        row.gate = _gate(request, row.scorecard, list(row.tiers or []))
        row.updated_at = now
        add_audit(s, actor=caller.email, action="model.scorecard", entity_type="model", entity_id=row.id,
                  details={**card, "gate_passed": row.gate["passed"]})
        s.flush()
        return view(row)


@router.put("/{model_id}/canary-pr", response_model=Model)
def put_canary_pr(
    model_id: str, body: CanaryPr, request: Request, caller: Caller = Depends(require_roles("admin", "service"))
) -> dict:
    url = body.url.strip()
    if not url.startswith("https://"):
        raise ApiError(400, "invalid_request", "url must be an https:// pull request URL")
    with request.app.state.db.session() as s:
        row = _get(s, model_id)
        if row.status not in ("canary", "promoted", "rolled_back"):
            raise ApiError(409, "invalid_transition", f"a {row.status} model has no canary PR")
        row.canary_pr_url, row.updated_at = url, utcnow()
        add_audit(s, actor=caller.email, action="model.canary_pr", entity_type="model", entity_id=row.id,
                  details={"url": url, "note": body.note, "status": row.status})
        s.flush()
        return view(row)
