"""Token/cost usage from Portkey's analytics API (admin key, server-side only).

Endpoints:
  GET /api/v1/usage/me         - the caller's own requests/tokens/cost
  GET /api/v1/usage/dashboard  - the CALLER's own tokenomics (scope=user, default): requests / tokens /
                                 cost per model, daily series and the previous window, all filtered in
                                 Portkey by metadata `_user` = the caller's email. Platform admins may
                                 pass scope=org for the org-wide view (active user count + per model).
  GET /api/v1/usage/by-team    - users/requests/tokens/cost per team (metadata `team`)

Upstream calls (verify against your self-hosted Portkey version):
  GET {portkey_admin_api_url}/analytics/groups/users
  GET {portkey_admin_api_url}/analytics/groups/model
  GET {portkey_admin_api_url}/analytics/graphs/{requests,tokens,cost}   (scope=user; metadata filter)
  GET {portkey_admin_api_url}{portkey_usage_by_team_path}   (default /analytics/groups/metadata/team)
The proxy sends the caller's email as Portkey's reserved `_user` metadata key, which is
what groups/users aggregates on. Field names are read defensively because they differ
between Portkey versions. The dashboard never returns per-user rows, only a count.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from fastapi import APIRouter, Depends, Query, Request

from ..auth import Principal, require_principal
from ..config import has_placeholder
from ..errors import ApiError
from ..schemas import TeamUsageList

router = APIRouter(prefix="/api/v1/usage", tags=["usage"])
log = logging.getLogger(__name__)

PAGE_SIZE = 100
MAX_PAGES = 20
DASHBOARD_CACHE_SECONDS = 10.0  # short: the dashboard is near real time; it only shields Portkey from bursts


def _admin(state: Any) -> tuple[str, str]:
    admin_key = state.secrets.get("PORTKEY_ADMIN_API_KEY")
    base = state.env_config.admin_api_url
    if not admin_key or has_placeholder(base):
        raise ApiError(501, "usage_not_configured", "Portkey admin API key is not configured on the backend")
    return admin_key, base.rstrip("/")


def _window(days: int) -> tuple[datetime, datetime]:
    end = datetime.now(timezone.utc)
    return end - timedelta(days=days), end


async def _analytics_page(
    state: Any, path: str, start: datetime, end: datetime, page: int, *, metadata: dict[str, str] | None = None
) -> dict:
    admin_key, base = _admin(state)
    client: httpx.AsyncClient = state.http_client
    params: dict[str, Any] = {
        "time_of_generation_min": start.isoformat(),
        "time_of_generation_max": end.isoformat(),
        "current_page": page,
        "page_size": PAGE_SIZE,
    }
    if metadata:
        # Portkey analytics filter on request metadata (JSON object), e.g. {"_user": "<email>"}.
        params["metadata"] = json.dumps(metadata, separators=(",", ":"))
    try:
        resp = await client.get(
            f"{base}{path}", params=params, headers={"x-portkey-api-key": admin_key, "accept": "application/json"}
        )
    except httpx.TimeoutException:
        raise ApiError(504, "upstream_timeout", "Portkey analytics timed out") from None
    except httpx.RequestError as exc:
        log.warning("usage lookup failed: %s", type(exc).__name__)
        raise ApiError(502, "upstream_unavailable", "Portkey analytics unreachable") from None
    if resp.status_code in (401, 403):
        raise ApiError(502, "usage_forbidden", f"Portkey analytics returned {resp.status_code}: the PORTKEY_ADMIN_API_KEY lacks analytics read permission")
    if resp.status_code >= 400:
        raise ApiError(502, "usage_upstream_error", f"Portkey analytics returned {resp.status_code}")
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        raise ApiError(502, "usage_upstream_error", "Portkey analytics returned invalid JSON") from None
    return data if isinstance(data, dict) else {}


async def _analytics_rows(
    state: Any, path: str, start: datetime, end: datetime, *, metadata: dict[str, str] | None = None
) -> tuple[list[dict], int | None]:
    """All rows across pages (bounded by MAX_PAGES), plus the upstream `total` if it reports one."""
    rows: list[dict] = []
    total: int | None = None
    for page in range(MAX_PAGES):
        data = await _analytics_page(state, path, start, end, page, metadata=metadata)
        batch = [r for r in data.get("data", []) if isinstance(r, dict)] if isinstance(data.get("data"), list) else []
        rows.extend(batch)
        if isinstance(data.get("total"), int) and not isinstance(data.get("total"), bool):
            total = data["total"]
        if len(batch) < PAGE_SIZE or (total is not None and len(rows) >= total):
            break
    else:
        log.warning("analytics %s truncated at %d pages", path, MAX_PAGES)
    return rows, total


def _num(row: dict, *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        if isinstance(v, bool):
            continue
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            try:
                return float(v)
            except ValueError:
                continue
    return 0.0


def _to_usd(value: float, unit: str) -> float:
    return value / 100.0 if unit == "cents" else value


def summarize_models(rows: list[dict], cost_unit: str) -> list[dict]:
    """Normalise per-model analytics rows, merging duplicates, sorted by tokens (desc)."""
    merged: dict[str, dict[str, float]] = {}
    for row in rows:
        model = str(row.get("model") or row.get("ai_model") or row.get("name") or "unknown")
        prompt = _num(row, "prompt_tokens", "input_tokens", "req_units")
        completion = _num(row, "completion_tokens", "output_tokens", "res_units")
        tokens = _num(row, "total_tokens", "tokens", "units") or prompt + completion
        m = merged.setdefault(model, {"requests": 0.0, "tokens": 0.0, "prompt_tokens": 0.0, "completion_tokens": 0.0, "cost": 0.0})
        m["requests"] += _num(row, "requests", "total_requests", "count")
        m["tokens"] += tokens
        m["prompt_tokens"] += prompt
        m["completion_tokens"] += completion
        m["cost"] += _to_usd(_num(row, "cost", "total_cost"), cost_unit)
    total_tokens = sum(m["tokens"] for m in merged.values()) or 1.0
    out = [
        {
            "model": name,
            "requests": int(m["requests"]),
            "tokens": int(m["tokens"]),
            "prompt_tokens": int(m["prompt_tokens"]),
            "completion_tokens": int(m["completion_tokens"]),
            "cost_usd": round(m["cost"], 4),
            "share": round(m["tokens"] / total_tokens, 4),
        }
        for name, m in merged.items()
    ]
    return sorted(out, key=lambda r: (-r["tokens"], r["model"]))


def count_users(rows: list[dict], total: int | None) -> int:
    ids = {str(r.get("user") or r.get("_user") or r.get("user_id") or "").strip().lower() for r in rows}
    ids.discard("")
    return max(total or 0, len(ids))


def _dashboard_body(env: str, start: datetime, end: datetime, days: int, *, users: int, models: list[dict], source: str) -> dict:
    return {
        "env": env,
        "window": {"start": start.isoformat(), "end": end.isoformat(), "days": days},
        "totals": {
            "users": users,
            "requests": sum(m["requests"] for m in models),
            "tokens": sum(m["tokens"] for m in models),
            "prompt_tokens": sum(m["prompt_tokens"] for m in models),
            "completion_tokens": sum(m["completion_tokens"] for m in models),
            "cost_usd": round(sum(m["cost_usd"] for m in models), 4),
        },
        "models": models,
        "source": source,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


async def build_dashboard(state: Any, days: int) -> dict:
    """Dashboard body for `days`, shared by GET /api/v1/usage/dashboard and the WebSocket usage push.

    Raises ApiError (e.g. 501 usage_not_configured, 502 usage_upstream_error).
    """
    env = state.settings.env

    _admin(state)  # 501 before touching the cache when not configured
    cache: dict[int, tuple[float, dict]] = state.usage_cache
    hit = cache.get(days)
    if hit and hit[0] > time.monotonic():
        return hit[1]

    start, end = _window(days)
    (user_rows, user_total), (model_rows, _) = await asyncio.gather(
        _analytics_rows(state, "/analytics/groups/users", start, end),
        _analytics_rows(state, "/analytics/groups/model", start, end),
    )
    body = _dashboard_body(
        env,
        start,
        end,
        days,
        users=count_users(user_rows, user_total),
        models=summarize_models(model_rows, state.env_config.portkey_cost_unit),
        source="portkey_analytics",
    )
    cache[days] = (time.monotonic() + DASHBOARD_CACHE_SECONDS, body)
    return body


@router.get("/dashboard")
async def usage_dashboard(
    request: Request,
    days: int = Query(30, ge=1, le=90),
    scope: str = Query("user", pattern="^(user|org)$"),
    principal: Principal = Depends(require_principal),
) -> dict:
    """The caller's own usage (default). scope=org (org-wide) is for platform admins only."""
    state = request.app.state
    if scope == "org":
        profile = state.users.lookup(principal.email, principal.name)
        if "admin" not in getattr(profile, "roles", ()):
            raise ApiError(403, "forbidden", "the org-wide usage view is for platform admins")
        return await build_dashboard(state, days)
    return await build_user_dashboard(state, principal.email, days)


@router.get("/me")
async def usage_me(
    request: Request,
    days: int = Query(30, ge=1, le=90),
    principal: Principal = Depends(require_principal),
) -> dict:
    state = request.app.state
    start, end = _window(days)
    data = await _analytics_page(state, "/analytics/groups/users", start, end, 0)
    rows: list[Any] = data.get("data", []) if isinstance(data.get("data"), list) else []
    me = principal.email.lower()
    summary = next((r for r in rows if isinstance(r, dict) and str(r.get("user", "")).lower() == me), {})
    return {
        "user": principal.email,
        "env": state.settings.env,
        "window": {"start": start.isoformat(), "end": end.isoformat(), "days": days},
        "requests": summary.get("requests", 0),
        "tokens": summary.get("tokens", summary.get("total_tokens", 0)),
        # Raw Portkey value kept for compatibility; cost_usd applies the env's portkey_cost_unit
        # (cents by default) exactly like the dashboard does.
        "cost": summary.get("cost", 0),
        "cost_usd": round(_to_usd(_num(summary, "cost", "total_cost"), state.env_config.portkey_cost_unit), 4),
        "source": "portkey_analytics",
    }


# ---------- per-user dashboard (Portkey analytics filtered by metadata `_user`) ----------

GRAPH_METRICS = ("requests", "tokens", "cost")


def _graph_total(data: dict) -> float | None:
    summary = data.get("summary")
    if isinstance(summary, dict):
        v = _num(summary, "total", "value", "sum", "count")
        return v
    return None


def _graph_points(data: dict) -> dict[str, float]:
    """{YYYY-MM-DD: value} from a Portkey analytics graph (data_points[].timestamp + total)."""
    out: dict[str, float] = {}
    points = data.get("data_points") or data.get("data") or []
    if not isinstance(points, list):
        return out
    for p in points:
        if not isinstance(p, dict):
            continue
        ts = str(p.get("timestamp") or p.get("time") or p.get("date") or "")[:10]
        if len(ts) == 10:
            out[ts] = out.get(ts, 0.0) + _num(p, "total", "value", "count", "sum")
    return out


async def _graph(state: Any, metric: str, start: datetime, end: datetime, metadata: dict[str, str]) -> dict | None:
    """One analytics graph; None when the admin key lacks permission (reported as unavailable)."""
    try:
        return await _analytics_page(state, f"/analytics/graphs/{metric}", start, end, 0, metadata=metadata)
    except ApiError as exc:
        if exc.code == "usage_forbidden":
            return None
        raise


async def build_user_dashboard(state: Any, email: str, days: int) -> dict:
    """The caller's own dashboard, live from Portkey: per-model requests (groups/model) and, when the
    admin key may read analytics graphs, tokens / cost totals, a daily series and the previous window.
    Metrics Portkey refuses are listed in `unavailable` (never estimated, never sample data)."""
    env = state.settings.env
    _admin(state)
    unit = state.env_config.portkey_cost_unit
    md = {"_user": email.lower()}
    start, end = _window(days)
    prev_start = start - (end - start)
    (model_rows, _), (prev_rows, _), *graphs = await asyncio.gather(
        _analytics_rows(state, "/analytics/groups/model", start, end, metadata=md),
        _analytics_rows(state, "/analytics/groups/model", prev_start, start, metadata=md),
        *[_graph(state, m, start, end, md) for m in GRAPH_METRICS],
        *[_graph(state, m, prev_start, start, md) for m in GRAPH_METRICS],
    )
    cur = dict(zip(GRAPH_METRICS, graphs[: len(GRAPH_METRICS)]))
    prev = dict(zip(GRAPH_METRICS, graphs[len(GRAPH_METRICS):]))
    models = summarize_models(model_rows, unit)
    if not any(m["tokens"] for m in models):
        # groups/model reports requests only on some plans: share by requests instead of tokens.
        total_req = sum(m["requests"] for m in models) or 1
        for m in models:
            m["share"] = round(m["requests"] / total_req, 4)
        models.sort(key=lambda r: (-r["requests"], r["model"]))
    body = _dashboard_body(env, start, end, days, users=1 if models else 0, models=models, source="portkey_analytics")
    t = body["totals"]
    unavailable: list[str] = []
    if cur["tokens"] is not None:
        t["tokens"] = int(_graph_total(cur["tokens"]) or t["tokens"])
    elif not t["tokens"]:
        unavailable.append("tokens")
    if cur["cost"] is not None:
        t["cost_usd"] = round(_to_usd(_graph_total(cur["cost"]) or 0.0, unit), 4) or t["cost_usd"]
    elif not t["cost_usd"]:
        unavailable.append("cost")
    if cur["requests"] is not None and _graph_total(cur["requests"]):
        t["requests"] = int(_graph_total(cur["requests"]) or t["requests"])
    # Daily series (needs the graphs).
    series_maps = {m: _graph_points(cur[m]) if cur[m] is not None else {} for m in GRAPH_METRICS}
    if any(series_maps.values()):
        day0 = start.date()
        dates = [(day0 + timedelta(days=i)).isoformat() for i in range(days + 1)]
        body["series"] = [
            {
                "date": d,
                "requests": int(series_maps["requests"].get(d, 0)),
                "tokens": int(series_maps["tokens"].get(d, 0)),
                "cost_usd": round(_to_usd(series_maps["cost"].get(d, 0.0), unit), 4),
                "users": 1 if series_maps["requests"].get(d) or series_maps["tokens"].get(d) else 0,
            }
            for d in dates
        ]
    else:
        unavailable.append("series")
    prev_models = summarize_models(prev_rows, unit)
    previous = {
        "users": 1 if prev_models else 0,
        "requests": int(_graph_total(prev["requests"]) or sum(m["requests"] for m in prev_models)) if prev["requests"] is not None else sum(m["requests"] for m in prev_models),
        "tokens": int(_graph_total(prev["tokens"]) or 0) if prev["tokens"] is not None else 0,
        "cost_usd": round(_to_usd(_graph_total(prev["cost"]) or 0.0, unit), 4) if prev["cost"] is not None else 0.0,
    }
    body.update(scope="user", user=email, previous=previous, unavailable=unavailable)
    return body


TEAM_USAGE_DAYS = (7, 30, 90)


def summarize_teams(rows: list[dict], cost_unit: str) -> list[dict]:
    """Normalise per-team analytics rows (grouped by metadata `team`), merged, sorted by tokens (desc)."""
    merged: dict[str, dict[str, float]] = {}
    for row in rows:
        team = str(
            row.get("metadata_value") or row.get("team") or row.get("value") or row.get("group") or row.get("key") or "unassigned"
        ).strip() or "unassigned"
        prompt = _num(row, "prompt_tokens", "input_tokens", "req_units")
        completion = _num(row, "completion_tokens", "output_tokens", "res_units")
        tokens = _num(row, "total_tokens", "tokens", "units") or prompt + completion
        t = merged.setdefault(team, {"users": 0.0, "requests": 0.0, "tokens": 0.0, "cost": 0.0})
        t["users"] += _num(row, "users", "unique_users", "user_count", "total_users")
        t["requests"] += _num(row, "requests", "total_requests", "count")
        t["tokens"] += tokens
        t["cost"] += _to_usd(_num(row, "cost", "total_cost"), cost_unit)
    out = [
        {"team": team, "users": int(t["users"]), "requests": int(t["requests"]), "tokens": int(t["tokens"]),
         "cost_usd": round(t["cost"], 4)}
        for team, t in merged.items()
    ]
    return sorted(out, key=lambda r: (-r["tokens"], r["team"]))


@router.get("/by-team", response_model=TeamUsageList)
async def usage_by_team(
    request: Request,
    days: int = Query(30, description="7, 30 or 90", json_schema_extra={"enum": list(TEAM_USAGE_DAYS)}),
    _principal: Principal = Depends(require_principal),
) -> dict:
    """Live from Portkey analytics only (501 usage_not_configured without the admin key; no sample data)."""
    if days not in TEAM_USAGE_DAYS:
        raise ApiError(400, "invalid_request", "days must be 7, 30 or 90")
    state = request.app.state
    _admin(state)
    key = ("by-team", days)
    cache: dict = state.usage_cache
    hit = cache.get(key)
    if hit and hit[0] > time.monotonic():
        return hit[1]
    start, end = _window(days)
    path = "/" + state.env_config.portkey_usage_by_team_path.strip("/")
    rows, _ = await _analytics_rows(state, path, start, end)
    items = summarize_teams(rows, state.env_config.portkey_cost_unit)
    body = {
        "items": items, "total": len(items), "env": state.settings.env,
        "window": {"start": start.isoformat(), "end": end.isoformat(), "days": days}, "source": "portkey_analytics",
    }
    cache[key] = (time.monotonic() + DASHBOARD_CACHE_SECONDS, body)
    return body


@router.get("/limits")
async def usage_limits(
    request: Request,
    refresh: bool = Query(False),
    principal: Principal = Depends(require_principal),
) -> dict:
    """The caller's usage-based routing state: limits (tier defaults + overrides), live usage from
    Portkey per daily/monthly limit, and the resulting usage_state. refresh=true bypasses the cache."""
    from ..usage_limits import evaluate_usage  # local import: usage_limits imports this module

    state = request.app.state
    profile = state.users.lookup(principal.email, principal.name)
    return await evaluate_usage(state, profile, refresh=refresh)
