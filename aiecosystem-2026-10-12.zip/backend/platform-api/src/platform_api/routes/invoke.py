"""Agent catalog, invocation and invocation history (registry v2, backend/contracts/agent-invocation.md).

| Method | Path | Auth |
|---|---|---|
| GET  | /api/v1/catalog?q=&team=&tag= | user: only agents the caller may invoke |
| POST | /api/v1/agents/{agent_id}/invoke?env=&version=&mode=sync\\|stream\\|background | user |
| GET  | /api/v1/invocations?agent_id=&mine=1&status=&limit= | user (own runs + runs of agents they own; admins all) |
| GET  | /api/v1/invocations/summary?since=&until=&env= | service token or admin: per agent/version/env counts (reconciliation) |
| GET  | /api/v1/invocations/{id} | the caller, the agent's owner or an admin (output only for caller/owner) |
| POST | /api/v1/invocations/{id}/cancel | the caller, the agent's owner or an admin |
| GET  | /api/v1/caller-token/jwks | none (public keys for verifying x-aig-caller) |
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse, StreamingResponse

from ..authz import Caller, forbidden, get_caller, get_user
from ..errors import ApiError
from ..invocations import Invocation
from ..invoker import ENV_ORDER, InvocationError, access_denial, is_team_member
from ..schemas import (
    CatalogList,
    InvocationAccepted,
    InvocationList,
    InvocationOut,
    InvocationSummary,
    InvokeBody,
    InvokeResult,
    Jwks,
)
from .agents import agent_view

router = APIRouter(prefix="/api/v1", tags=["invocation"])
log = logging.getLogger(__name__)

KEEPALIVE_SECONDS = 15.0
ENV_PATTERN = "^(local|dev|stage|prod)$"


def _invoker(request: Request):
    return request.app.state.invoker


# --- catalog ------------------------------------------------------------------------------------


def _access_kind(agent, caller: Caller) -> str:
    if agent.owner.lower() == caller.email.lower():
        return "owner"
    if caller.team and caller.team == agent.team:
        return "team"
    if agent.visibility in ("groups", "org") and set(caller.groups) & set(agent.allowed_groups):
        return "group"
    return "org"


def _catalog_version(v) -> dict:
    return {"env": v.env, "version": v.version, "kind": v.kind, "verified": v.verified,
            "verified_at": v.verified_at or None, "input_schema": v.input_schema, "output_schema": v.output_schema}


@router.get("/catalog", response_model=CatalogList)
def catalog(
    request: Request,
    q: str | None = Query(None, max_length=200, description="Case-insensitive match on id, name, description, tags"),
    team: str | None = Query(None, max_length=64),
    tag: str | None = Query(None, max_length=32),
    caller: Caller = Depends(get_user),
) -> dict:
    """Agents the caller may invoke: lifecycle active or deprecated, not suspended, access allowed
    (team, allowed Entra groups, or org-wide once approved), with a verified active version in
    prod (owner/team also see verified dev/stage/local versions)."""
    state = request.app.state
    platform_env = state.settings.env
    candidates = [a for a in state.agents.all()
                  if not a.builtin and a.active and a.lifecycle in ("active", "deprecated")
                  and access_denial(a, caller) is None]
    if team:
        candidates = [a for a in candidates if a.team == team]
    if tag:
        candidates = [a for a in candidates if tag.lower() in a.tags]
    if q:
        needle = q.lower()
        candidates = [a for a in candidates
                      if any(needle in (v or "").lower() for v in (a.agent_id, a.name, a.description, " ".join(a.tags)))]
    by_agent = state.agent_versions.by_agents([a.agent_id for a in candidates])
    items = []
    for agent in candidates:
        member = is_team_member(agent, caller)
        eligible = []
        for env in ENV_ORDER:
            if env != "prod" and not member:
                continue
            if env == "local" and platform_env != "local":
                continue
            eligible += [v for v in by_agent.get(agent.agent_id, []) if v.env == env and v.verified]
        if not eligible:
            continue
        versions = [_catalog_version(v) for v in eligible]
        items.append({"agent": agent_view(agent, state), "versions": versions, "default": versions[0],
                      "access": _access_kind(agent, caller)})
    return {"items": items, "total": len(items),
            "teams": sorted({i["agent"]["team"] for i in items}),
            "tags": sorted({t for i in items for t in i["agent"]["tags"]})}


# --- invoke -------------------------------------------------------------------------------------


def _sse(event: dict) -> bytes:
    return f"event: {event['event']}\ndata: {json.dumps(event['data'], separators=(',', ':'))}\n\n".encode()


async def _with_keepalive(events: AsyncIterator[dict], interval: float) -> AsyncIterator[bytes]:
    """SSE bytes with ': keepalive' comments during silent periods. The run is consumed by an inner
    task; when the client goes away the task is cancelled, which records the run as cancelled."""
    queue: asyncio.Queue = asyncio.Queue(maxsize=64)
    sentinel = object()

    async def consume() -> None:
        try:
            async for event in events:
                await queue.put(event)
        finally:
            await queue.put(sentinel)

    task = asyncio.create_task(consume())
    try:
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=interval)
            except asyncio.TimeoutError:
                yield b": keepalive\n\n"
                continue
            if item is sentinel:
                break
            yield _sse(item)
        await task
    finally:
        if not task.done():
            task.cancel()  # not awaited: the run records itself as cancelled


@router.post(
    "/agents/{agent_id}/invoke",
    response_model=InvokeResult,
    responses={
        202: {"model": InvocationAccepted, "description": "mode=background: queued; poll Location"},
        200: {"content": {"text/event-stream": {}}, "description": "mode=stream: SSE events delta|output|error|done"},
    },
)
async def invoke_agent(
    agent_id: str,
    body: InvokeBody,
    request: Request,
    env: str | None = Query(None, pattern=ENV_PATTERN, description="Default: prod (owner/team: first of prod, stage, dev, local)"),
    version: str | None = Query(None, max_length=128),
    mode: str | None = Query(None, pattern="^(sync|stream|background)$",
                             description="Default sync; stream when body.stream is true or Accept is text/event-stream"),
    caller: Caller = Depends(get_user),
):
    invoker = _invoker(request)
    raw = body.model_dump(exclude_unset=True)
    if mode is None:
        accept = request.headers.get("accept", "")
        mode = "stream" if raw.get("stream") is True or "text/event-stream" in accept else "sync"
    try:
        plan = invoker.prepare(caller, agent_id, raw, env=env, version=version, mode=mode,
                               trace_id=request.headers.get("x-aig-trace-id"))
        handle = invoker.open(plan)
    except InvocationError as exc:
        raise exc.api_error() from None
    ids = {"x-aig-invocation-id": handle.id, "x-aig-trace-id": handle.call.trace_id}

    if mode == "background":
        request.app.state.invocation_runner.start(handle)
        location = f"/api/v1/invocations/{handle.id}"
        return JSONResponse(
            {"invocation_id": handle.id, "agent_id": agent_id, "version": plan.version.version,
             "env": plan.version.env, "status": "queued", "location": location},
            status_code=202, headers={**ids, "location": location},
        )
    if mode == "stream":
        return StreamingResponse(
            _with_keepalive(invoker.run(handle), KEEPALIVE_SECONDS),
            media_type="text/event-stream",
            headers={**ids, "cache-control": "no-cache", "x-accel-buffering": "no"},
        )
    outcome = await invoker.run_to_end(handle)
    if outcome.error is not None:
        raise ApiError(outcome.error.status, outcome.error.code, outcome.error.message, ids)
    events_output = invoker._redact_value(outcome.output, [s for s in request.app.state.secret_values() if s])
    result: dict[str, Any] = {"invocation_id": handle.id, "agent_id": agent_id, "version": plan.version.version,
                              "env": plan.version.env, "status": "succeeded", "output": events_output,
                              "usage": outcome.usage, "trace_id": handle.call.trace_id,
                              "duration_ms": outcome.duration_ms}
    return JSONResponse(result, headers=ids)


# --- invocation records -------------------------------------------------------------------------


def _owned_agent_ids(request: Request, caller: Caller) -> list[str]:
    email = caller.email.lower()
    return [a.agent_id for a in request.app.state.agents.all() if a.owner.lower() == email]


def _is_agent_owner(request: Request, agent_id: str, caller: Caller) -> bool:
    agent = request.app.state.agents.get(agent_id)
    return agent is not None and agent.owner.lower() == caller.email.lower()


def invocation_view(inv: Invocation, *, output: Any = None, output_visible: bool = False) -> dict:
    return {
        "id": inv.id, "agent_id": inv.agent_id, "version": inv.version, "env": inv.env, "caller": inv.caller,
        "team": inv.team, "mode": inv.mode, "purpose": inv.purpose, "status": inv.status,
        "session_id": inv.session_id, "trace_id": inv.trace_id, "created_at": inv.created_at,
        "started_at": inv.started_at, "finished_at": inv.finished_at, "duration_ms": inv.duration_ms,
        "usage": inv.usage, "error_code": inv.error_code, "error_message": inv.error_message,
        "output_available": inv.has_output and output_visible, "output": output if output_visible else None,
        "output_expires_at": inv.output_expires_at if output_visible else None, "retain_until": inv.retain_until,
    }


def _visible(request: Request, inv: Invocation, caller: Caller) -> tuple[bool, bool]:
    """(may see the record, may see the output)."""
    own = inv.caller.lower() == caller.email.lower()
    owner = _is_agent_owner(request, inv.agent_id, caller)
    return own or owner or caller.is_admin, own or owner


@router.get("/invocations", response_model=InvocationList)
def list_invocations(
    request: Request,
    agent_id: str | None = Query(None, max_length=64),
    mine: bool = Query(False, description="Only invocations the caller started"),
    status: str | None = Query(None, pattern="^(queued|running|succeeded|failed|cancelled|timeout)$"),
    limit: int = Query(50, ge=1, le=500),
    caller: Caller = Depends(get_user),
) -> dict:
    store = request.app.state.invocations
    if mine:
        rows = store.list(callers=[caller.email], agent_id=agent_id, status=status, limit=limit)
    elif caller.is_admin:
        rows = store.list(agent_id=agent_id, status=status, limit=limit)
    else:
        rows = store.list(callers=[caller.email], agent_ids=_owned_agent_ids(request, caller), agent_id=agent_id,
                          status=status, limit=limit)
    items = [invocation_view(r) for r in rows]
    return {"items": items, "total": len(items)}


@router.get("/invocations/summary", response_model=InvocationSummary)
def invocation_summary(
    request: Request,
    since: str = Query(..., description="ISO-8601 start (inclusive)"),
    until: str = Query(..., description="ISO-8601 end (exclusive)"),
    env: str | None = Query(None, pattern=ENV_PATTERN),
    caller: Caller = Depends(get_caller),
) -> dict:
    """Invocation counts per (agent, version, env) for user runs (verification runs excluded),
    metadata only. Service token (telemetry-bridge reconciliation) or admin."""
    if not (caller.is_service or caller.is_admin):
        raise forbidden("requires the service token or role admin")
    try:
        start, end = _parse_ts(since), _parse_ts(until)
    except ValueError:
        raise ApiError(400, "invalid_request", "since/until must be ISO-8601 timestamps") from None
    if end <= start:
        raise ApiError(400, "invalid_request", "until must be after since")
    items = request.app.state.invocations.summary(since=start, until=end, env=env)
    return {"since": start.isoformat(), "until": end.isoformat(), "items": items, "total": len(items)}


def _parse_ts(value: str):
    from datetime import datetime, timezone

    dt = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _get_visible(request: Request, invocation_id: str, caller: Caller) -> tuple[Invocation, bool]:
    inv = request.app.state.invocations.get(invocation_id)
    if inv is None:
        raise ApiError(404, "invocation_not_found", "no such invocation")
    see, see_output = _visible(request, inv, caller)
    if not see:
        raise ApiError(404, "invocation_not_found", "no such invocation")
    return inv, see_output


@router.get("/invocations/{invocation_id}", response_model=InvocationOut)
def get_invocation(invocation_id: str, request: Request, caller: Caller = Depends(get_user)) -> dict:
    state = request.app.state
    inv, see_output = _get_visible(request, invocation_id, caller)
    output = None
    if see_output and inv.has_output:
        token = state.invocations.encrypted_output(inv.id)
        cipher = state.invoker.cipher
        output = cipher.decrypt(token) if (token and cipher is not None) else None
    return invocation_view(inv, output=output, output_visible=see_output)


@router.post("/invocations/{invocation_id}/cancel", response_model=InvocationOut)
async def cancel_invocation(invocation_id: str, request: Request, caller: Caller = Depends(get_user)) -> dict:
    state = request.app.state
    inv, see_output = _get_visible(request, invocation_id, caller)
    if inv.final:
        raise ApiError(409, "invocation_finished", f"the invocation already ended ({inv.status})")
    local = state.invoker.cancel(invocation_id)
    task = state.invocation_runner.tasks.get(invocation_id)
    if task is not None:
        await asyncio.wait({task}, timeout=5)
    elif local:
        for _ in range(50):  # foreground run in this process: wait for it to close its record
            await asyncio.sleep(0.05)
            current = state.invocations.get(invocation_id)
            if current is None or current.final:
                break
    current = state.invocations.get(invocation_id)
    if current is not None and not current.final:
        # Not running in this process (another replica, or lost): close the record; the owning
        # replica's later finish is a no-op on a final record.
        state.invocations.finish(invocation_id, status="cancelled", error_code="invocation_cancelled",
                                 error_message=f"cancelled by {caller.email}")
    state.invoker.audit_cancel(caller.email, invocation_id, inv.agent_id, via="http")
    return invocation_view(state.invocations.get(invocation_id) or inv, output_visible=False)


# --- caller-token keys --------------------------------------------------------------------------


@router.get("/caller-token/jwks", response_model=Jwks, tags=["invocation"])
def caller_token_jwks(request: Request) -> JSONResponse:
    signer = request.app.state.invoker.signer
    if signer is None:
        raise ApiError(503, "agent_invocation_disabled", "no caller-token signing key is configured")
    return JSONResponse(signer.jwks(), headers={"cache-control": "public, max-age=3600"})
