"""Team workspace requests (Phase 4 API; Phase 6 workspace-orchestrator consumes it).

| Method | Path | Auth |
|---|---|---|
| GET   | /api/v1/workspaces?status=          | users see their own (admins and the service token see all) |
| POST  | /api/v1/workspaces                  | any user; created ``queued`` |
| GET   | /api/v1/workspaces/{id}             | requester, admin or service |
| POST  | /api/v1/workspaces/{id}/cancel      | requester, admin or service |
| POST  | /api/v1/workspaces/{id}/claim       | service token only: atomic queued -> provisioning (409 once claimed) |
| PATCH | /api/v1/workspaces/{id}/status      | service token only (the orchestrator) |

Statuses: queued, provisioning, running, testing, pr_opened, then completed | failed | cancelled
(final: no further change). Workspaces of other users answer 404 (existence is not revealed).
"""

from __future__ import annotations

import re
import uuid
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import select, update

from ..authz import Caller, get_caller, get_service, get_user
from ..db import WorkspaceRow, add_audit, iso, utcnow
from ..errors import ApiError
from ..schemas import Workspace, WorkspaceClaim, WorkspaceCreate, WorkspaceList, WorkspaceStatus, WorkspaceStatusUpdate

router = APIRouter(prefix="/api/v1/workspaces", tags=["workspaces"])

FINAL = frozenset({"completed", "failed", "cancelled"})
_SSH_REPO_RE = re.compile(r"^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+:[A-Za-z0-9._/-]+$")


def view(row: WorkspaceRow) -> dict:
    return {
        "id": row.id, "repo_url": row.repo_url, "work_item": row.work_item, "title": row.title,
        "description": row.description or "", "job_profile": row.job_profile, "status": row.status,
        "requested_by": row.requested_by, "team": row.team, "pr_url": row.pr_url, "log_url": row.log_url,
        "error": row.error, "created_at": iso(row.created_at), "updated_at": iso(row.updated_at),
    }


def _http_url(value: str) -> bool:
    try:
        parts = urlsplit(value)
    except ValueError:
        return False
    return parts.scheme.lower() in ("https", "http") and bool(parts.hostname) and not parts.password


def _visible(row: WorkspaceRow, caller: Caller) -> bool:
    return caller.is_service or caller.is_admin or row.requested_by.lower() == caller.email.lower()


def _get(s, workspace_id: str, caller: Caller) -> WorkspaceRow:
    row = s.get(WorkspaceRow, workspace_id)
    if row is None or not _visible(row, caller):
        raise ApiError(404, "workspace_not_found", f"workspace {workspace_id!r} not found")
    return row


@router.get("", response_model=WorkspaceList)
def list_workspaces(
    request: Request, status: WorkspaceStatus | None = Query(None), caller: Caller = Depends(get_caller)
) -> dict:
    with request.app.state.db.session() as s:
        stmt = select(WorkspaceRow).order_by(WorkspaceRow.created_at.desc(), WorkspaceRow.id)
        if not (caller.is_service or caller.is_admin):
            stmt = stmt.where(WorkspaceRow.requested_by == caller.email)
        if status:
            stmt = stmt.where(WorkspaceRow.status == status)
        items = [view(r) for r in s.scalars(stmt)]
    return {"items": items, "total": len(items)}


@router.post("", status_code=201, response_model=Workspace)
def create_workspace(body: WorkspaceCreate, request: Request, caller: Caller = Depends(get_user)) -> dict:
    repo_url = body.repo_url.strip()
    if not (_http_url(repo_url) or _SSH_REPO_RE.match(repo_url)):
        raise ApiError(400, "invalid_request", "repo_url must be an http(s) or git@host:org/repo URL")
    if not body.work_item.strip() or not body.title.strip():
        raise ApiError(400, "invalid_request", "work_item and title are required")
    allowed = request.app.state.env_config.allowed_job_profiles
    if body.job_profile is not None and body.job_profile not in allowed:
        raise ApiError(400, "invalid_job_profile", f"job profile must be one of {allowed}")
    with request.app.state.db.session() as s:
        now = utcnow()
        row = WorkspaceRow(
            id=str(uuid.uuid4()), repo_url=repo_url, work_item=body.work_item.strip(), title=body.title.strip(),
            description=body.description, job_profile=body.job_profile, status="queued",
            requested_by=caller.email, team=caller.team or "unassigned", created_at=now, updated_at=now,
        )
        s.add(row)
        add_audit(s, actor=caller.email, action="workspace.request", entity_type="workspace", entity_id=row.id,
                  details={"repo_url": repo_url, "work_item": row.work_item, "job_profile": body.job_profile})
        s.flush()
        return view(row)


@router.get("/{workspace_id}", response_model=Workspace)
def get_workspace(workspace_id: str, request: Request, caller: Caller = Depends(get_caller)) -> dict:
    with request.app.state.db.session() as s:
        return view(_get(s, workspace_id, caller))


@router.post("/{workspace_id}/cancel", response_model=Workspace)
def cancel_workspace(workspace_id: str, request: Request, caller: Caller = Depends(get_caller)) -> dict:
    with request.app.state.db.session() as s:
        row = _get(s, workspace_id, caller)
        if row.status in FINAL:
            raise ApiError(409, "invalid_transition", f"workspace is already {row.status}")
        before = row.status
        row.status, row.updated_at = "cancelled", utcnow()
        add_audit(s, actor=caller.email, action="workspace.cancel", entity_type="workspace", entity_id=row.id,
                  details={"from": before})
        s.flush()
        return view(row)


@router.post("/{workspace_id}/claim", response_model=Workspace)
def claim_workspace(
    workspace_id: str, request: Request, body: WorkspaceClaim | None = None, caller: Caller = Depends(get_service)
) -> dict:
    """Atomically move a ``queued`` workspace to ``provisioning`` for one orchestrator worker.

    A single conditional ``UPDATE ... WHERE status = 'queued'`` decides the race, so two workers
    (or two replicas) can never both claim the same request: the loser gets ``409``.
    """
    worker = (body.worker if body else None) or "orchestrator"
    with request.app.state.db.session() as s:
        result = s.execute(
            update(WorkspaceRow)
            .where(WorkspaceRow.id == workspace_id, WorkspaceRow.status == "queued")
            .values(status="provisioning", updated_at=utcnow())
            .execution_options(synchronize_session=False)
        )
        row = _get(s, workspace_id, caller)
        if result.rowcount != 1:
            raise ApiError(409, "invalid_transition", f"workspace is {row.status}, not queued (already claimed?)")
        s.refresh(row)
        add_audit(s, actor=caller.email, action="workspace.claim", entity_type="workspace", entity_id=row.id,
                  details={"from": "queued", "to": "provisioning", "worker": worker})
        s.flush()
        return view(row)


@router.patch("/{workspace_id}/status", response_model=Workspace)
def update_status(
    workspace_id: str, body: WorkspaceStatusUpdate, request: Request, caller: Caller = Depends(get_service)
) -> dict:
    for name in ("pr_url", "log_url"):
        value = getattr(body, name)
        if value is not None and not _http_url(value):
            raise ApiError(400, "invalid_request", f"{name} must be an http(s) URL")
    with request.app.state.db.session() as s:
        row = _get(s, workspace_id, caller)
        if row.status in FINAL and body.status != row.status:
            raise ApiError(409, "invalid_transition", f"workspace is already {row.status}")
        before = row.status
        row.status = body.status
        for name in ("pr_url", "log_url", "error"):
            value = getattr(body, name)
            if value is not None:
                setattr(row, name, value)
        row.updated_at = utcnow()
        add_audit(s, actor=caller.email, action="workspace.status", entity_type="workspace", entity_id=row.id,
                  details={"from": before, "to": body.status, "pr_url": body.pr_url, "error": body.error})
        s.flush()
        return view(row)
