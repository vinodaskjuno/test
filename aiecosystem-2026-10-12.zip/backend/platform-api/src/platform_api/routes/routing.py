"""Read-only routing view (Phase 4): GET /api/v1/routing.

Serves the rendered ``pc-aig-router`` config from the file named by ``AIG_ROUTING_CONFIG_FILE``,
written by ``aigw render --env <env> --kind configs > routing.json`` (backend/gateway). The render
output is ``{"env", "objects": {"configs": [{"slug", "workspace_id", "config"}, ...]}}``; a file that
holds ``{"env", "config_id", "config"}`` or a bare config object is accepted too. Secrets are already
masked by ``aigw render`` (``<secret:NAME>``); configured secret values are redacted again here.
``404 routing_not_available`` when the setting is unset or the file is missing or unreadable.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import replace as _replace
from pathlib import Path
from typing import Any

import httpx
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from ..auth import Principal, require_principal
from ..authz import Caller, get_user
from ..errors import ApiError
from ..schemas import Routing
from ..users import COST_MODES, USER_TIERS
from ..usage_limits import apply_usage_state
from .llm import build_metadata, extract_usage, prepare_llm_call, redact_text, route_info

router = APIRouter(prefix="/api/v1", tags=["routing"])
log = logging.getLogger(__name__)
MAX_BYTES = 2 * 1024 * 1024


def _unavailable(message: str) -> ApiError:
    return ApiError(404, "routing_not_available", message)


def extract_routing(doc: Any, config_id: str) -> tuple[str | None, str, dict]:
    if not isinstance(doc, dict):
        raise ValueError("routing file must hold a JSON object")
    objects = doc.get("objects")
    if isinstance(objects, dict):
        configs = [c for c in objects.get("configs") or [] if isinstance(c, dict) and isinstance(c.get("config"), dict)]
        match = next((c for c in configs if c.get("slug") == config_id), None)
        if match is None:
            raise ValueError(f"no rendered config {config_id!r} in the routing file")
        return doc.get("env"), config_id, match["config"]
    if isinstance(doc.get("config"), dict):
        return doc.get("env"), str(doc.get("config_id") or config_id), doc["config"]
    return doc.get("env"), config_id, doc


@router.get("/routing", response_model=Routing)
def routing(request: Request, _principal: Principal = Depends(require_principal)) -> dict:
    state = request.app.state
    path = state.settings.routing_config_file
    if not path:
        raise _unavailable("AIG_ROUTING_CONFIG_FILE is not configured")
    p = Path(path)
    if not p.is_file():
        raise _unavailable("the rendered routing config file does not exist (run aigw render)")
    try:
        raw = p.read_bytes()
        if len(raw) > MAX_BYTES:
            raise ValueError("routing file too large")
        text = raw.decode("utf-8")
        secrets = state.secrets.configured_values()
        if secrets:
            text = redact_text(text, secrets)
        env, config_id, config = extract_routing(json.loads(text), state.env_config.portkey_config_id)
    except (OSError, ValueError) as exc:
        log.warning("routing config unreadable: %s", type(exc).__name__)
        raise _unavailable(f"the rendered routing config is unreadable ({type(exc).__name__})") from None
    return {"env": str(env or state.settings.env), "config_id": config_id, "config": config}


# ---------- routing test (tier + cost-based routing, end to end through Portkey) ----------

TEST_PROMPT = "Reply with one short sentence naming the model you are."


class RoutingTestBody(BaseModel):
    job_profile: str | None = None
    # Overrides of the caller's own directory values: platform admins only (anyone may test their own route).
    user_tier: str | None = None
    cost_mode: str | None = None
    # Usage-based routing override (normal | soft | hard), admins only; otherwise the caller's live state.
    usage_state: str | None = None
    prompt: str | None = Field(default=None, max_length=500)


@router.post("/routing/test")
async def routing_test(request: Request, body: RoutingTestBody, caller: Caller = Depends(get_user)) -> dict:
    """Send one tiny chat through the Portkey config with the caller's (or, for admins, an overridden)
    tier and cost mode and report which model Portkey actually served. Never stored; the answer is
    truncated. Uses the same server-built metadata as real chats, so it exercises the real routing."""
    state = request.app.state
    if (body.user_tier or body.cost_mode or body.usage_state) and not caller.is_admin:
        raise ApiError(403, "forbidden", "only platform admins may test another tier, cost mode or usage state")
    if body.usage_state is not None and body.usage_state not in ("normal", "soft", "hard"):
        raise ApiError(400, "invalid_usage_state", "usage_state must be one of ['normal', 'soft', 'hard']")
    if body.user_tier is not None and body.user_tier not in USER_TIERS:
        raise ApiError(400, "invalid_user_tier", f"user_tier must be one of {list(USER_TIERS)}")
    if body.cost_mode is not None and body.cost_mode not in COST_MODES:
        raise ApiError(400, "invalid_cost_mode", f"cost_mode must be one of {list(COST_MODES)}")
    principal = type("P", (), {"email": caller.email, "name": caller.name})()
    call = prepare_llm_call(state, principal, job_profile=body.job_profile, agent_id=None, host="web")
    profile = call.profile
    if body.user_tier or body.cost_mode:
        profile = _replace(profile, user_tier=body.user_tier or profile.user_tier, cost_mode=body.cost_mode or profile.cost_mode)
        call.metadata = build_metadata(profile=profile, job_profile=call.job_profile, agent_id=call.agent_id,
                                       env=state.settings.env, host="web")
    usage = None
    if body.usage_state:
        call.metadata["usage_state"] = body.usage_state
    else:
        usage = await apply_usage_state(state, _replace(call, profile=profile) if profile is not call.profile else call)
        call.metadata["usage_state"] = usage["state"]
    payload = {"messages": [{"role": "user", "content": body.prompt or TEST_PROMPT}], "max_tokens": 60, "stream": False}
    started = time.monotonic()
    client: httpx.AsyncClient = state.http_client
    try:
        res = await client.post(call.url, headers=call.headers(False), content=json.dumps(payload).encode())
    except httpx.TimeoutException:
        raise ApiError(504, "upstream_timeout", "Portkey gateway timed out", {"x-aig-trace-id": call.trace_id}) from None
    except httpx.RequestError:
        raise ApiError(502, "upstream_unavailable", "Portkey gateway unreachable", {"x-aig-trace-id": call.trace_id}) from None
    latency_ms = int((time.monotonic() - started) * 1000)
    try:
        data = res.json()
    except ValueError:
        data = {}
    out: dict[str, Any] = {
        "route": route_info(call.metadata),
        "status": res.status_code,
        "latency_ms": latency_ms,
        "trace_id": call.trace_id,
        "provider": res.headers.get("x-portkey-provider"),
        "cache": res.headers.get("x-portkey-cache-status"),
    }
    if usage is not None:
        out["usage_status"] = {k: usage.get(k) for k in ("state", "configured", "checks", "note") if k in usage}
    if res.status_code < 400 and isinstance(data, dict):
        msg = ((data.get("choices") or [{}])[0] or {}).get("message") or {}
        out.update(ok=True, model=data.get("model"), usage=extract_usage(data.get("usage")),
                   answer=redact_text(str(msg.get("content") or "")[:300], call.secrets))
    else:
        err = data.get("error") if isinstance(data, dict) else None
        message = (err.get("message") if isinstance(err, dict) else None) or (data.get("message") if isinstance(data, dict) else None)
        out.update(ok=False, model=None, error=redact_text(str(message or f"HTTP {res.status_code}")[:400], call.secrets))
    return out
