"""Per-user portal preferences (Phase 4): GET/PUT /api/v1/me/preferences."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request

from ..authz import Caller, get_user
from ..db import UserPreferenceRow, utcnow
from ..schemas import Preferences

router = APIRouter(prefix="/api/v1/me", tags=["session"])
DEFAULT_PREFERENCES = {"theme": "system"}


def load_preferences(state: Any, email: str) -> dict:
    db = getattr(state, "db", None)
    if db is None:
        return dict(DEFAULT_PREFERENCES)
    with db.session() as s:
        row = s.get(UserPreferenceRow, email.lower())
        return {"theme": row.theme} if row else dict(DEFAULT_PREFERENCES)


@router.get("/preferences", response_model=Preferences)
def get_preferences(request: Request, caller: Caller = Depends(get_user)) -> dict:
    return load_preferences(request.app.state, caller.email)


@router.put("/preferences", response_model=Preferences)
def put_preferences(body: Preferences, request: Request, caller: Caller = Depends(get_user)) -> dict:
    with request.app.state.db.session() as s:
        row = s.get(UserPreferenceRow, caller.email.lower())
        if row is None:
            row = UserPreferenceRow(email=caller.email.lower(), theme=body.theme, updated_at=utcnow())
            s.add(row)
        else:
            row.theme, row.updated_at = body.theme, utcnow()
    return {"theme": body.theme}
