"""Audit log (Phase 4): GET /api/v1/audit?entity_type=&entity_id=&limit= (admin or approver).

``entity_type=invocation`` is an alias of ``agent_invocation`` (agent invocations: ``agent.invoke``,
``agent.invocation.cancel``); registry changes use ``entity_type=agent``."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select

from ..authz import Caller, require_roles
from ..db import AuditRow, iso
from ..schemas import AuditList

router = APIRouter(prefix="/api/v1/audit", tags=["audit"])
ENTITY_ALIASES = {"invocation": "agent_invocation"}


def view(row: AuditRow) -> dict:
    return {"id": row.id, "at": iso(row.at), "actor": row.actor, "action": row.action,
            "entity_type": row.entity_type, "entity_id": row.entity_id, "details": row.details or {}}


@router.get("", response_model=AuditList)
def list_audit(
    request: Request,
    entity_type: str | None = Query(None, max_length=32, description="e.g. agent, invocation (= agent_invocation), "
                                                                      "model, mcp_server, workspace, eval"),
    entity_id: str | None = Query(None, max_length=128),
    limit: int = Query(100, ge=1, le=1000),
    _caller: Caller = Depends(require_roles("admin", "approver")),
) -> dict:
    with request.app.state.db.session() as s:
        where = []
        if entity_type:
            where.append(AuditRow.entity_type == ENTITY_ALIASES.get(entity_type, entity_type))
        if entity_id:
            where.append(AuditRow.entity_id == entity_id)
        total = s.scalar(select(func.count()).select_from(AuditRow).where(*where)) or 0
        rows = s.scalars(select(AuditRow).where(*where).order_by(AuditRow.id.desc()).limit(limit))
        items = [view(r) for r in rows]
    return {"items": items, "total": total}
