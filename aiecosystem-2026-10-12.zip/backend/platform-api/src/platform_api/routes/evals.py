"""Eval run history (Phase 4 API; the Phase 5 evals gate posts runs).

GET  /api/v1/evals?agent_id=&limit=   any user or service (newest first)
POST /api/v1/evals                    service token only
"""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select

from ..agents import AGENT_ID_RE
from ..authz import Caller, get_caller, get_service
from ..db import EvalRunRow, add_audit, iso, utcnow
from ..errors import ApiError
from ..schemas import EvalCreate, EvalList, EvalRun

router = APIRouter(prefix="/api/v1/evals", tags=["evals"])


def view(row: EvalRunRow) -> dict:
    return {
        "id": row.id, "agent_id": row.agent_id, "dataset": row.dataset, "experiment_id": row.experiment_id,
        "scores": row.scores or {}, "baseline_scores": row.baseline_scores or {}, "passed": bool(row.passed),
        "fiddler_url": row.fiddler_url, "git_sha": row.git_sha, "pr": row.pr, "created_by": row.created_by,
        "created_at": iso(row.created_at),
    }


@router.get("", response_model=EvalList)
def list_evals(
    request: Request,
    agent_id: str | None = Query(None, max_length=64),
    limit: int = Query(50, ge=1, le=500),
    _caller: Caller = Depends(get_caller),
) -> dict:
    with request.app.state.db.session() as s:
        where = [EvalRunRow.agent_id == agent_id] if agent_id else []
        total = s.scalar(select(func.count()).select_from(EvalRunRow).where(*where)) or 0
        rows = s.scalars(
            select(EvalRunRow).where(*where).order_by(EvalRunRow.created_at.desc(), EvalRunRow.id).limit(limit)
        )
        items = [view(r) for r in rows]
    return {"items": items, "total": total}


@router.post("", status_code=201, response_model=EvalRun)
def create_eval(body: EvalCreate, request: Request, caller: Caller = Depends(get_service)) -> dict:
    if not AGENT_ID_RE.match(body.agent_id):
        raise ApiError(400, "invalid_agent_id", "agent_id must match [A-Za-z0-9._-]{1,64}")
    with request.app.state.db.session() as s:
        row = EvalRunRow(
            id=str(uuid.uuid4()), agent_id=body.agent_id, dataset=body.dataset, experiment_id=body.experiment_id,
            scores=dict(body.scores), baseline_scores=dict(body.baseline_scores), passed=body.passed,
            fiddler_url=body.fiddler_url, git_sha=body.git_sha, pr=body.pr, created_by=caller.email,
            created_at=utcnow(),
        )
        s.add(row)
        add_audit(s, actor=caller.email, action="eval.record", entity_type="eval", entity_id=row.id,
                  details={"agent_id": body.agent_id, "passed": body.passed, "experiment_id": body.experiment_id})
        s.flush()
        return view(row)
