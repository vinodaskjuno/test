"""Local-only browser sign-in for the VS Code extension and the web portal (no SSO).

Flow (AIG_ENV=local with AIG_AUTH_MODE=dev only; 404 everywhere else):
  1. The extension opens GET /auth/local/signin?redirect_uri=<vscode://aig.aig-ai-ecosystem/auth-callback>&state=<nonce>
     (the web portal uses redirect_uri=<origin>/auth/callback, where <origin> must be listed in the
     environment's web_allowed_origins; native clients such as the Eclipse plugin use an RFC 8252
     loopback redirect http://127.0.0.1:<port>/auth/callback or http://[::1]:<port>/auth/callback,
     any port)
  2. The user enters an email and submits (POST /auth/local/signin).
  3. The backend answers with a page that sends the browser back to
     <redirect_uri>?email=<email>&state=<nonce>; the extension checks the nonce it generated,
     then uses the `dev:<email>` token that local dev auth already accepts.
No secret is involved: this only stands in for SSO on a developer laptop.
"""

from __future__ import annotations

import html
import re
import secrets
from urllib.parse import parse_qsl, unquote, urlencode, urlsplit, urlunsplit

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

from ..auth import _EMAIL_RE
from ..errors import ApiError

router = APIRouter(prefix="/auth/local")

EXTENSION_AUTHORITY = "aig.aig-ai-ecosystem"
CALLBACK_PATH = "/auth-callback"
ALLOWED_SCHEMES = frozenset({"vscode", "vscode-insiders", "vscodium"})
WEB_CALLBACK_PATH = "/auth/callback"
# RFC 8252 section 7.3: native apps (the Eclipse plugin) listen on an ephemeral loopback port. Only the
# IP literals are accepted ("localhost" can be re-pointed by a hosts file), only plain http, any port.
LOOPBACK_HOSTS = frozenset({"127.0.0.1", "::1"})
_STATE_RE = re.compile(r"^[A-Za-z0-9_-]{16,128}$")
MAX_FORM_BYTES = 4096


def _require_local(request: Request) -> None:
    if not request.app.state.authenticator.dev_mode:
        raise ApiError(404, "not_found", "Not Found")


def normalize_redirect_uri(uri: str) -> str:
    """Undo a common client mangling where the callback's own query is percent-encoded into the path
    (e.g. vscode://aig.aig-ai-ecosystem/auth-callback%3FwindowId%3D6). Only that exact shape is
    rewritten; scheme and authority are untouched and still validated by valid_redirect_uri."""
    try:
        parts = urlsplit(uri)
    except ValueError:
        return uri
    path = parts.path
    for _ in range(2):  # tolerate single or double encoding (%3F or %253F)
        if path.lower().startswith(CALLBACK_PATH.lower() + "%"):
            path = unquote(path)
    if path.startswith(CALLBACK_PATH + "?"):
        extra = path[len(CALLBACK_PATH) + 1 :]
        query = "&".join(q for q in (extra, parts.query) if q)
        return urlunsplit((parts.scheme, parts.netloc, CALLBACK_PATH, query, parts.fragment))
    return uri


def _origin(scheme: str, netloc: str) -> str:
    return f"{scheme.lower()}://{netloc.lower()}"


def is_loopback_redirect(uri: str) -> bool:
    """RFC 8252 loopback redirect: ``http://127.0.0.1:<port>/auth/callback`` or
    ``http://[::1]:<port>/auth/callback`` (explicit port required, no userinfo, no fragment)."""
    try:
        parts = urlsplit(uri)
        port = parts.port
    except ValueError:
        return False
    return (
        parts.scheme.lower() == "http"
        and (parts.hostname or "") in LOOPBACK_HOSTS
        and port is not None
        and 0 < port < 65536
        and not parts.username
        and not parts.password
        and not parts.fragment
        and parts.path == WEB_CALLBACK_PATH
    )


def is_web_redirect(uri: str) -> bool:
    try:
        return urlsplit(uri).scheme.lower() in ("http", "https") and not is_loopback_redirect(uri)
    except ValueError:
        return False


def valid_redirect_uri(uri: str, web_origins: list[str] | tuple[str, ...] = ()) -> bool:
    """Only this extension's VS Code callback URI, ``<origin>/auth/callback`` for an origin listed
    in ``web_allowed_origins``, or an RFC 8252 loopback ``http://127.0.0.1|[::1]:<port>/auth/callback``
    (native IDE clients) is accepted (no open redirect). The route itself exists only with
    AIG_ENV=local and AIG_AUTH_MODE=dev."""
    try:
        parts = urlsplit(uri)
    except ValueError:
        return False
    if parts.fragment:
        return False
    scheme = parts.scheme.lower()
    if scheme in ALLOWED_SCHEMES:
        return parts.netloc.lower() == EXTENSION_AUTHORITY and parts.path == CALLBACK_PATH
    if is_loopback_redirect(uri):
        return True
    if scheme in ("http", "https"):
        allowed = {o.strip().rstrip("/").lower() for o in web_origins if o and o.strip()}
        return (
            not parts.username
            and not parts.password
            and _origin(scheme, parts.netloc) in allowed
            and parts.path == WEB_CALLBACK_PATH
        )
    return False


def callback_url(redirect_uri: str, email: str, state: str) -> str:
    parts = urlsplit(redirect_uri)
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True) if k not in {"email", "state"}]
    query += [("email", email), ("state", state)]
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), ""))


def _web_origins(request: Request) -> list[str]:
    return list(request.app.state.env_config.web_allowed_origins)


def _check(redirect_uri: str, state: str, web_origins: list[str] = ()) -> None:  # type: ignore[assignment]
    if not valid_redirect_uri(redirect_uri, web_origins):
        raise ApiError(
            400, "invalid_redirect_uri",
            "redirect_uri must be the AIG VS Code extension callback, <web origin>/auth/callback "
            "or a loopback http://127.0.0.1:<port>/auth/callback",
        )
    if not _STATE_RE.match(state):
        raise ApiError(400, "invalid_state", "state is missing or malformed")


_CSS = """
:root{--brand:#001871;--interactive:#1352de;--accent:#00a4e4;--ink:#343741;--muted:#5b5c60;--bg:#f5f7f9;--panel:#fff;--line:#dcdcdc;--danger:#e03c31;--tint:#e9f1fb}
@media (prefers-color-scheme:dark){:root{--brand:#000e45;--interactive:#6e9bff;--accent:#33b6ea;--ink:#eef2fa;--muted:#a9b4cc;--bg:#0a1230;--panel:#111b3f;--line:rgba(199,219,244,.16);--danger:#ff6b5e;--tint:#18244f}}
*{box-sizing:border-box;border-radius:0}
body{margin:0;background:var(--bg);color:var(--ink);font-family:"Source Sans 3","Source Sans Pro",Arial,sans-serif;font-size:16px;line-height:1.45}
header{background:#001871;color:#fff;padding:14px 24px;display:flex;align-items:center;gap:12px;border-bottom:3px solid var(--accent)}
.wm{font-family:"AIG Futura","Futura PT","Century Gothic",sans-serif;font-weight:700;font-size:24px;letter-spacing:.08em}
.env{margin-left:auto;border:1px solid currentColor;padding:2px 8px;font-size:12px;text-transform:uppercase;letter-spacing:.06em}
main{max-width:440px;margin:48px auto;padding:0 16px}
.card{background:var(--panel);border:1px solid var(--line);padding:28px}
h1{font-family:"AIG Futura","Futura PT","Century Gothic",sans-serif;font-weight:500;font-size:20px;text-transform:uppercase;letter-spacing:.04em;margin:0 0 6px}
p{color:var(--muted);margin:0 0 18px}
label{display:block;font-weight:600;margin-bottom:6px}
input[type=email]{width:100%;padding:10px 12px;font:inherit;color:var(--ink);background:var(--panel);border:1px solid var(--line)}
input[type=email]:focus{outline:2px solid var(--interactive);outline-offset:1px}
button,.btn{display:inline-block;margin-top:18px;width:100%;text-align:center;padding:14px 16px;border:0;background:#001871;color:#fff;font-family:"AIG Futura","Futura PT","Century Gothic",sans-serif;font-size:14px;text-transform:uppercase;letter-spacing:.04em;cursor:pointer;text-decoration:none}
button:hover,.btn:hover,button:focus-visible,.btn:focus-visible{background:#1352de}
.note{background:var(--tint);border-left:4px solid var(--interactive);padding:8px 12px;color:var(--ink);font-size:14px;margin-top:18px}
.err{color:var(--danger);font-weight:600;margin:0 0 12px}
"""


def _page(title: str, body: str, *, refresh_to: str | None = None) -> HTMLResponse:
    nonce = secrets.token_urlsafe(16)
    csp = f"default-src 'none'; style-src 'nonce-{nonce}'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"
    refresh = f'<meta http-equiv="refresh" content="0;url={html.escape(refresh_to, quote=True)}">' if refresh_to else ""
    doc = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="referrer" content="no-referrer">{refresh}
<title>{html.escape(title)}</title><style nonce="{nonce}">{_CSS}</style></head>
<body><header><span class="wm" aria-label="AIG">AIG</span><span>AI Ecosystem</span><span class="env">local</span></header>
<main><div class="card">{body}</div></main></body></html>"""
    return HTMLResponse(
        doc,
        headers={
            "Content-Security-Policy": csp,
            "Cache-Control": "no-store",
            "X-Frame-Options": "DENY",
            "Referrer-Policy": "no-referrer",
            "X-Content-Type-Options": "nosniff",
        },
    )


def _form(redirect_uri: str, state: str, email: str = "", error: str = "") -> HTMLResponse:
    e = lambda v: html.escape(v, quote=True)  # noqa: E731
    err = f'<p class="err" role="alert">{e(error)}</p>' if error else ""
    web = is_web_redirect(redirect_uri)
    loopback = is_loopback_redirect(redirect_uri)
    client = "AIG web portal" if web else "AIG IDE plugin" if loopback else "AIG VS Code extension"
    action = (
        "Sign in and return to the portal" if web
        else "Sign in and return to the IDE" if loopback
        else "Sign in and return to VS Code"
    )
    return _page(
        "Sign in - AIG AI Ecosystem (local)",
        f"""<h1>Sign in</h1>
<p>Local development sign-in for the {client}. SSO is skipped in the local environment.</p>
{err}<form method="post" action="/auth/local/signin">
<input type="hidden" name="redirect_uri" value="{e(redirect_uri)}">
<input type="hidden" name="state" value="{e(state)}">
<label for="email">Work email</label>
<input id="email" name="email" type="email" required autocomplete="email" autofocus value="{e(email)}" placeholder="name@aig.com">
<button type="submit">{action}</button>
</form>
<div class="note">Local only. This page does not exist in dev, stage or prod, which use Microsoft Entra ID sign-in.</div>""",
    )


@router.get("/signin")
async def signin_form(request: Request, redirect_uri: str = "", state: str = "", login_hint: str = "") -> HTMLResponse:
    _require_local(request)
    redirect_uri = normalize_redirect_uri(redirect_uri)
    _check(redirect_uri, state, _web_origins(request))
    hint = login_hint if _EMAIL_RE.match(login_hint or "") else ""
    return _form(redirect_uri, state, hint)


@router.post("/signin")
async def signin_submit(request: Request) -> HTMLResponse:
    _require_local(request)
    raw = await request.body()
    if len(raw) > MAX_FORM_BYTES:
        raise ApiError(413, "form_too_large", "form body too large")
    form = dict(parse_qsl(raw.decode("utf-8", "replace"), keep_blank_values=True))
    redirect_uri, state = normalize_redirect_uri(form.get("redirect_uri", "")), form.get("state", "")
    _check(redirect_uri, state, _web_origins(request))
    email = form.get("email", "").strip()
    if not _EMAIL_RE.match(email):
        return _form(redirect_uri, state, email, "Enter a valid email address.")
    target = callback_url(redirect_uri, email, state)
    t = html.escape(target, quote=True)
    if is_loopback_redirect(redirect_uri):
        body = f"""<h1>Signed in</h1>
<p>Signed in as <strong>{html.escape(email)}</strong>. Returning you to your IDE.</p>
<a class="btn" href="{t}">Return to the IDE</a>
<div class="note">If your IDE did not pick up the sign-in, click the button above. You can close this tab afterwards.</div>"""
    elif is_web_redirect(redirect_uri):
        body = f"""<h1>Signed in</h1>
<p>Signed in as <strong>{html.escape(email)}</strong>. Returning you to the AIG web portal.</p>
<a class="btn" href="{t}">Open the portal</a>
<div class="note">If the portal did not open, click the button above.</div>"""
    else:
        body = f"""<h1>Signed in</h1>
<p>Signed in as <strong>{html.escape(email)}</strong>. Returning you to the AIG dashboard in VS Code.</p>
<a class="btn" href="{t}">Open VS Code</a>
<div class="note">If VS Code did not open, click the button above. You can close this tab afterwards.</div>"""
    return _page("Signed in - AIG AI Ecosystem (local)", body, refresh_to=target)
