from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(tags=["health"])


@router.get("/healthz")
def healthz(request: Request) -> dict:
    state = request.app.state
    db = getattr(state, "db", None)
    database = {"backend": db.backend, "status": "ok" if db.ping() else "unavailable"} if db is not None else None
    return {"status": "ok", "env": state.settings.env, "secrets": state.secrets.statuses(), "database": database}
