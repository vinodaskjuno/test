from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from ..auth import Principal, require_principal
from ..config import configured_url
from .me import load_preferences

router = APIRouter(prefix="/api/v1", tags=["session"])


def public_base_url(request: Request) -> str:
    settings = request.app.state.settings
    configured = (settings.public_base_url or "").strip().strip("\"'").strip()
    if settings.env != "local":
        # Startup guarantees a valid https URL here; never fall back to the Host header.
        return configured.rstrip("/")
    return (configured or str(request.base_url)).rstrip("/")


@router.get("/session")
def session(request: Request, principal: Principal = Depends(require_principal)) -> dict:
    state = request.app.state
    cfg = state.env_config
    profile = state.users.lookup(principal.email, principal.name)
    return {
        "user": {"email": profile.email, "name": profile.name},
        "team": profile.team,
        "env": state.settings.env,
        "user_tier": profile.user_tier,
        "cost_mode": getattr(profile, "cost_mode", "balanced"),
        "allowed_job_profiles": list(cfg.allowed_job_profiles),
        "llm": {"base_url": f"{public_base_url(request)}/api/v1/llm", "config_id": cfg.portkey_config_id},
        "fiddler": {"url": cfg.fiddler_url},
        "roles": list(getattr(profile, "roles", ("user",))),
        "preferences": load_preferences(state, profile.email),
        "links": {"portkey_url": configured_url(cfg.portkey_ui_url), "fiddler_url": configured_url(cfg.fiddler_url)},
    }
