"""MCP registry (Phase 4): request, approve/reject and list MCP servers.

| Method | Path | Auth |
|---|---|---|
| GET  | /api/v1/mcp-servers?status=          | any user or service |
| POST | /api/v1/mcp-servers                  | any user (creates a ``pending`` request) |
| POST | /api/v1/mcp-servers/{id}/approve     | admin |
| POST | /api/v1/mcp-servers/{id}/reject      | admin |

An approved server is pushed to the Portkey MCP gateway (``mcp_sync.py``, ``AIG_MCP_SYNC``);
the outcome is stored as ``sync_status``/``sync_error`` and never fails the approval. Requests,
decisions and syncs are audit-logged.
"""

from __future__ import annotations

import re
import uuid
from typing import Any
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import select

from ..authz import Caller, get_caller, get_user, require_roles
from ..db import McpServerRow, add_audit, iso, utcnow
from ..errors import ApiError
from ..mcp_sync import sync_mcp_server
from ..schemas import McpDecision, McpServer, McpServerCreate, McpServerList, McpStatus

router = APIRouter(prefix="/api/v1/mcp-servers", tags=["mcp"])

WORKSPACE_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
IAM_ROLE_RE = re.compile(r"^[A-Za-z0-9+=,.@_/:-]{1,256}$")  # role name or arn:aws:iam::<acct>:role/<name>


def view(row: McpServerRow) -> dict:
    return {
        "id": row.id, "name": row.name, "url": row.url, "description": row.description or "",
        "iam_roles": list(row.iam_roles or []), "workspaces": list(row.workspaces or []), "status": row.status,
        "requested_by": row.requested_by, "decided_by": row.decided_by, "decided_at": iso(row.decided_at),
        "reason": row.reason, "sync_status": row.sync_status, "sync_error": row.sync_error,
        "synced_at": iso(row.synced_at), "created_at": iso(row.created_at), "updated_at": iso(row.updated_at),
    }


def _validate(body: McpServerCreate, env: str) -> None:
    try:
        parts = urlsplit(body.url.strip())
    except ValueError:
        parts = None
    schemes = {"https"} if env != "local" else {"https", "http"}
    if parts is None or parts.scheme.lower() not in schemes or not parts.hostname or parts.username or parts.password:
        raise ApiError(400, "invalid_request", f"url must be an absolute {' or '.join(sorted(schemes))} URL without credentials")
    bad = [w for w in body.workspaces if not WORKSPACE_RE.match(w)]
    if bad:
        raise ApiError(400, "invalid_request", "workspaces must be [A-Za-z0-9._-]{1,64} slugs")
    if any(not IAM_ROLE_RE.match(r) for r in body.iam_roles):
        raise ApiError(400, "invalid_request", "iam_roles must be IAM role names or role ARNs")
    if not body.name.strip():
        raise ApiError(400, "invalid_request", "name is required")


def _get(s, server_id: str) -> McpServerRow:
    row = s.get(McpServerRow, server_id)
    if row is None:
        raise ApiError(404, "mcp_server_not_found", f"MCP server {server_id!r} not found")
    return row


@router.get("", response_model=McpServerList)
def list_servers(request: Request, status: McpStatus | None = Query(None), _caller: Caller = Depends(get_caller)) -> dict:
    with request.app.state.db.session() as s:
        stmt = select(McpServerRow).order_by(McpServerRow.created_at.desc(), McpServerRow.id)
        if status:
            stmt = stmt.where(McpServerRow.status == status)
        items = [view(r) for r in s.scalars(stmt)]
    return {"items": items, "total": len(items)}


@router.post("", status_code=201, response_model=McpServer)
def request_server(body: McpServerCreate, request: Request, caller: Caller = Depends(get_user)) -> dict:
    _validate(body, request.app.state.settings.env)
    url = body.url.strip()
    with request.app.state.db.session() as s:
        dup = s.scalars(
            select(McpServerRow).where(McpServerRow.url == url, McpServerRow.status.in_(("pending", "approved")))
        ).first()
        if dup is not None:
            raise ApiError(409, "mcp_server_exists", f"an MCP server with this url is already {dup.status} ({dup.id})")
        now = utcnow()
        row = McpServerRow(
            id=str(uuid.uuid4()), name=body.name.strip(), url=url, description=body.description,
            iam_roles=list(dict.fromkeys(body.iam_roles)), workspaces=list(dict.fromkeys(body.workspaces)),
            status="pending", requested_by=caller.email, sync_status="not_synced", created_at=now, updated_at=now,
        )
        s.add(row)
        add_audit(s, actor=caller.email, action="mcp.request", entity_type="mcp_server", entity_id=row.id,
                  details={"name": row.name, "url": url, "workspaces": row.workspaces, "iam_roles": row.iam_roles})
        s.flush()
        return view(row)


def _decide(request: Request, server_id: str, caller: Caller, decision: str, reason: str | None) -> dict:
    with request.app.state.db.session() as s:
        row = _get(s, server_id)
        if row.status != "pending":
            raise ApiError(409, "invalid_transition", f"MCP server is {row.status}; only pending requests can be decided")
        now = utcnow()
        row.status, row.decided_by, row.decided_at, row.reason, row.updated_at = decision, caller.email, now, reason, now
        add_audit(s, actor=caller.email, action=f"mcp.{'approve' if decision == 'approved' else 'reject'}",
                  entity_type="mcp_server", entity_id=row.id, details={"reason": reason})
        s.flush()
        return view(row)


@router.post("/{server_id}/approve", response_model=McpServer)
async def approve_server(
    server_id: str, request: Request, body: McpDecision | None = None, caller: Caller = Depends(require_roles("admin"))
) -> dict:
    state: Any = request.app.state
    server = _decide(request, server_id, caller, "approved", body.reason if body else None)
    status, error = await sync_mcp_server(state, server)
    with state.db.session() as s:
        row = _get(s, server_id)
        row.sync_status, row.sync_error = status, error
        if status == "synced":
            row.synced_at = utcnow()
        row.updated_at = utcnow()
        if status != "disabled":
            add_audit(s, actor=caller.email, action="mcp.sync", entity_type="mcp_server", entity_id=row.id,
                      details={"sync_status": status, "sync_error": error})
        s.flush()
        return view(row)


@router.post("/{server_id}/reject", response_model=McpServer)
def reject_server(
    server_id: str, request: Request, body: McpDecision | None = None, caller: Caller = Depends(require_roles("admin"))
) -> dict:
    return _decide(request, server_id, caller, "rejected", body.reason if body else None)
