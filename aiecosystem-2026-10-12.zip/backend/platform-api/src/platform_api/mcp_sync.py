"""Push approved MCP servers to the Portkey MCP gateway (Phase 4, ``AIG_MCP_SYNC=true``).

Upsert through the Portkey admin API, the same object shape ``aigw`` renders from
``backend/gateway/manifests/mcp-servers.yaml``: ``POST {admin_url}{portkey_mcp_servers_path}``
and, when the slug already exists (409), ``PUT {admin_url}{path}/{slug}``. Base URL:
``AIG_PORTKEY_ADMIN_URL``, else the environment's ``portkey_admin_api_url``; key: the
``PORTKEY_ADMIN_API_KEY`` secret (header ``x-portkey-api-key``; it needs MCP-server write scope
when the sync is on). Paths and shapes are unverified against the self-hosted version (see
backend/gateway/README.md "Assumptions").

``sync_mcp_server`` never raises: the outcome is recorded on the registry object as
``sync_status`` (``synced`` | ``failed`` | ``disabled``) and ``sync_error`` (no response bodies, no
secrets).
"""

from __future__ import annotations

import logging
import re
from typing import Any

import httpx

from .config import configured_url

log = logging.getLogger(__name__)
SYNC_TIMEOUT_SECONDS = 10.0


def mcp_slug(name: str, server_id: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40] or "server"
    return f"aig-{base}-{server_id[:8]}"


def portkey_mcp_body(server: dict) -> dict:
    return {
        "slug": mcp_slug(server["name"], server["id"]),
        "name": server["name"],
        "description": server.get("description") or "",
        "url": server["url"],
        "transport": "streamable-http",
        "workspace_ids": list(server.get("workspaces") or []),
        "access": {"unregistered": "deny", "iam_roles": list(server.get("iam_roles") or [])},
    }


async def sync_mcp_server(state: Any, server: dict) -> tuple[str, str | None]:
    """Returns (sync_status, sync_error)."""
    if not state.settings.mcp_sync:
        return "disabled", None
    try:
        key = state.secrets.get("PORTKEY_ADMIN_API_KEY")
        base = configured_url(state.settings.portkey_admin_url) or configured_url(state.env_config.portkey_admin_api_url)
        if not key or not base:
            return "failed", "Portkey admin API is not configured (AIG_PORTKEY_ADMIN_URL / PORTKEY_ADMIN_API_KEY)"
        path = "/" + state.env_config.portkey_mcp_servers_path.strip("/")
        body = portkey_mcp_body(server)
        headers = {"x-portkey-api-key": key, "content-type": "application/json", "accept": "application/json"}
        client: httpx.AsyncClient = state.http_client
        try:
            resp = await client.post(f"{base}{path}", json=body, headers=headers, timeout=SYNC_TIMEOUT_SECONDS)
            if resp.status_code == 409:
                resp = await client.put(f"{base}{path}/{body['slug']}", json=body, headers=headers,
                                        timeout=SYNC_TIMEOUT_SECONDS)
        except httpx.TimeoutException:
            return "failed", "Portkey admin API timed out"
        except httpx.RequestError as exc:
            return "failed", f"Portkey admin API unreachable ({type(exc).__name__})"
        if resp.status_code >= 400:
            return "failed", f"Portkey admin API returned {resp.status_code}"
        log.info("mcp server %s synced to the Portkey MCP gateway as %s", server["id"], body["slug"])
        return "synced", None
    except Exception as exc:  # never fail the approval because of the sync
        log.warning("mcp sync failed for %s: %s", server.get("id"), type(exc).__name__)
        return "failed", f"sync failed ({type(exc).__name__})"
