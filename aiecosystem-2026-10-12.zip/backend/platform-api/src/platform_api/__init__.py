"""AIG AI Ecosystem platform API."""

__version__ = "0.1.0"
