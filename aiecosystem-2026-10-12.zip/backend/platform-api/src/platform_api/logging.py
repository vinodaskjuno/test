"""Logging setup with a redaction filter so secret values can never appear in logs."""

from __future__ import annotations

import logging
import sys
from typing import Callable, Iterable

REDACTED = "***redacted***"


class RedactSecretsFilter(logging.Filter):
    def __init__(self, values: Callable[[], Iterable[str]]):
        super().__init__()
        self._values = values

    def filter(self, record: logging.LogRecord) -> bool:
        secrets = [v for v in self._values() if v]
        if not secrets:
            return True
        try:
            msg = record.getMessage()
        except Exception:
            return True
        redacted = msg
        for s in secrets:
            redacted = redacted.replace(s, REDACTED)
        if redacted != msg:
            record.msg, record.args = redacted, None
        return True


_installed: list[tuple[logging.Handler | None, RedactSecretsFilter]] = []


def configure_logging(level: str, secret_values: Callable[[], Iterable[str]]) -> None:
    root = logging.getLogger()
    if not any(getattr(h, "_aig", False) for h in root.handlers):
        handler = logging.StreamHandler(sys.stderr)
        handler._aig = True  # type: ignore[attr-defined]
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        root.addHandler(handler)
    root.setLevel(level.upper())
    # Replace any previously installed redaction filter (e.g. app re-created in tests).
    for handler, flt in _installed:
        (handler or root).removeFilter(flt)
    _installed.clear()
    flt = RedactSecretsFilter(secret_values)
    for logger_name in ("", "platform_api", "uvicorn", "uvicorn.error", "uvicorn.access", "httpx"):
        lg = logging.getLogger(logger_name)
        lg.addFilter(flt)
        _installed.append((lg, flt))  # type: ignore[arg-type]
    for h in root.handlers:
        h.addFilter(flt)
        _installed.append((h, flt))
