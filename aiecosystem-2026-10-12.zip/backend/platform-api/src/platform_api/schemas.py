"""Request and response models for the Phase 4 portal API (also the source of
backend/contracts/platform-api.openapi.json). Timestamps are ISO-8601 UTC strings."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

Theme = Literal["system", "light", "dark"]
AgentStatusT = Literal["active", "suspended"]
LifecycleT = Literal["draft", "active", "deprecated", "retired"]
VisibilityT = Literal["team", "groups", "org"]
OrgApprovalT = Literal["none", "pending", "approved", "rejected"]
VersionEnvT = Literal["local", "dev", "stage", "prod"]
VersionKindT = Literal["agentcore", "https"]
AuthTypeT = Literal["none", "api_key", "oauth_client_credentials"]
InvocationModeT = Literal["sync", "stream", "background"]
InvocationStatusT = Literal["queued", "running", "succeeded", "failed", "cancelled", "timeout"]
McpStatus = Literal["pending", "approved", "rejected"]
SyncStatus = Literal["not_synced", "disabled", "synced", "failed"]
ModelStatus = Literal["requested", "sandbox", "evaluating", "approved", "rejected", "canary", "promoted", "rolled_back"]
DataClassification = Literal["public", "internal", "confidential", "restricted"]
UserTier = Literal["premium", "standard", "free"]
JobProfile = Literal["underwriting", "claims", "operations", "general"]
WorkspaceStatus = Literal["queued", "provisioning", "running", "testing", "pr_opened", "completed", "failed", "cancelled"]
Number = float | int


class _In(BaseModel):
    """Request bodies: finite numbers only (JSON NaN/Infinity are rejected)."""

    model_config = ConfigDict(allow_inf_nan=False)


class ErrorDetail(BaseModel):
    code: str
    message: str


class ErrorBody(BaseModel):
    error: ErrorDetail


# --- preferences / session ----------------------------------------------------------------------


class Preferences(_In):
    theme: Theme = "system"


# --- agents -------------------------------------------------------------------------------------


class AgentLinks(BaseModel):
    fiddler: str | None = None
    portkey: str | None = None


class Agent(BaseModel):
    agent_id: str
    name: str
    description: str
    team: str
    owner: str
    status: AgentStatusT
    builtin: bool
    created_at: str | None = None
    updated_at: str | None = None
    last_seen_at: str | None = None
    hosts_seen: list[str] = Field(default_factory=list)
    fiddler_application_id: str | None = None
    links: AgentLinks
    # Kept for the SDK, telemetry-bridge and fiddler-sync registry clients.
    shared: bool = False
    status_reason: str = ""
    status_changed_at: str | None = None
    # Registry v2 (backend/contracts/agent-record.schema.json).
    lifecycle: LifecycleT = "active"
    lifecycle_changed_at: str | None = None
    tags: list[str] = Field(default_factory=list)
    docs_url: str | None = None
    data_classification: DataClassification | None = None
    visibility: VisibilityT = "team"
    allowed_groups: list[str] = Field(default_factory=list)
    org_approval: OrgApprovalT = "none"
    org_approval_by: str | None = None
    org_approval_at: str | None = None


class AgentList(BaseModel):
    items: list[Agent]
    total: int
    agents: list[Agent] = Field(description="Same list as items (kept for telemetry-bridge and fiddler-sync)")


class AgentEnvelope(BaseModel):
    agent: Agent


class HookStatus(BaseModel):
    hook: str
    status: str


class AgentRegistered(BaseModel):
    agent: Agent
    hooks: list[HookStatus] = Field(default_factory=list)


class AgentStatusChanged(BaseModel):
    agent: Agent
    changed: bool


class AgentCreate(_In):
    agent_id: str = Field(min_length=1, max_length=64, description="[A-Za-z0-9._-]{1,64}")
    name: str | None = Field(None, max_length=200, description="Defaults to agent_id")
    description: str = Field("", max_length=500)
    team: str | None = Field(None, max_length=64, description="Defaults to the caller's team; only admins/service may set another")
    owner: str | None = Field(None, max_length=254, description="Defaults to the caller; only admins/service may set another")
    lifecycle: Literal["draft", "active"] | None = Field(
        None, description="Default draft. Only admins and the service token may register an agent directly as active")
    tags: list[str] = Field(default_factory=list, max_length=20, description="[a-z0-9][a-z0-9._-]{0,31}")
    docs_url: str | None = Field(None, max_length=2048)
    data_classification: DataClassification | None = None


class AgentPatch(_In):
    name: str | None = Field(None, min_length=1, max_length=200)
    description: str | None = Field(None, max_length=500)
    owner: str | None = Field(None, min_length=3, max_length=254)
    tags: list[str] | None = Field(None, max_length=20)
    docs_url: str | None = Field(None, max_length=2048)
    data_classification: DataClassification | None = None


# --- registry v2: versions, lifecycle, access, catalog -------------------------------------------


class VersionAuth(_In):
    """A reference to the agent's credentials, never the value (extra fields are refused)."""

    model_config = ConfigDict(allow_inf_nan=False, extra="forbid")
    type: AuthTypeT = "none"
    secret_arn: str | None = Field(
        None, max_length=2048,
        description="Secrets Manager ARN (aig/<env>/agents/<agent_id>/invoke-auth); local:<NAME> only in AIG_ENV=local")


class AgentVersionCreate(_In):
    model_config = ConfigDict(allow_inf_nan=False, extra="forbid")
    version: str = Field(min_length=1, max_length=128, description="[A-Za-z0-9][A-Za-z0-9._+-]{0,127}, e.g. 1.4.0 or sha-3f9c2e1")
    env: VersionEnvT
    kind: VersionKindT
    endpoint: str | None = Field(None, max_length=2048, description="kind https: base URL (https://; http://localhost only in AIG_ENV=local)")
    runtime_arn: str | None = Field(None, max_length=2048, description="kind agentcore: AgentCore runtime ARN")
    qualifier: str | None = Field(None, max_length=128, description="kind agentcore: runtime endpoint name (default endpoint when unset)")
    protocol: Literal["aig-http/1"] = "aig-http/1"
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    auth: VersionAuth = Field(default_factory=VersionAuth)
    git_sha: str | None = Field(None, max_length=64)
    image_digest: str | None = Field(None, max_length=128)
    verified: bool = Field(False, description="Service token only: the deploy pipeline's smoke test passed (records a passing verification)")
    activate: bool = Field(False, description="Service token only, env prod, needs verified=true: set the agent's lifecycle to active")


class AgentVersionOut(BaseModel):
    id: str
    agent_id: str
    version: str
    env: VersionEnvT
    kind: VersionKindT
    endpoint: str | None = None
    runtime_arn: str | None = None
    qualifier: str | None = None
    protocol: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    auth: dict[str, Any]
    git_sha: str | None = None
    image_digest: str | None = None
    verification_status: Literal["unverified", "passed", "failed"]
    verified_at: str | None = None
    verification: dict[str, Any] | None = None
    status: Literal["active", "retired"]
    created_by: str
    created_at: str
    updated_at: str | None = None


class AgentVersionList(BaseModel):
    items: list[AgentVersionOut]
    total: int


class AgentVersionRegistered(BaseModel):
    version: AgentVersionOut
    created: bool
    activated: bool = False
    agent: Agent


class VerifyBody(_In):
    input: dict[str, Any] | None = Field(None, description="Test input (else the schema's first example; chat 'ping' without a schema)")
    messages: list[dict[str, Any]] | None = None
    activate: bool | None = Field(None, description="Activate a draft agent when verification passes (default: true for prod)")


class VerifyCheck(BaseModel):
    name: Literal["health", "invocation", "gateway", "trace"]
    status: Literal["passed", "failed", "skipped"]
    detail: str = ""


class VerifyResult(BaseModel):
    passed: bool
    code: str | None = None
    checks: list[VerifyCheck]
    invocation_id: str
    trace_id: str
    activated: bool = False
    version: AgentVersionOut


class LifecycleBody(_In):
    to: LifecycleT
    reason: str | None = Field(None, max_length=500)


class AccessBody(_In):
    visibility: VisibilityT
    allowed_groups: list[str] = Field(default_factory=list, max_length=50,
                                      description="Entra group object ids or names ([A-Za-z0-9 ._@:-]{1,128})")


class AccessDecision(_In):
    reason: str | None = Field(None, max_length=1000)


class CatalogVersion(BaseModel):
    env: VersionEnvT
    version: str
    kind: VersionKindT
    verified: bool
    verified_at: str | None = None
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None


class CatalogItem(BaseModel):
    agent: Agent
    versions: list[CatalogVersion] = Field(description="Versions this caller may run, default first")
    default: CatalogVersion
    access: Literal["owner", "team", "group", "org"]


class CatalogList(BaseModel):
    items: list[CatalogItem]
    total: int
    teams: list[str] = Field(default_factory=list, description="Facet: teams of the listed agents")
    tags: list[str] = Field(default_factory=list, description="Facet: tags of the listed agents")


class InvokeBody(BaseModel):
    """Client body of POST /api/v1/agents/{id}/invoke (agent-invocation.schema.json#/$defs/request
    without aig_context). Validated by platform-api itself so every problem is input_invalid."""

    model_config = ConfigDict(extra="allow")
    input: Any = Field(None, json_schema_extra={"type": "object"},
                       description="Structured input, validated against the version's input_schema")
    messages: Any = Field(None, json_schema_extra={"type": "array", "items": {"type": "object"}},
                          description="Chat mode: [{role, content}] (exactly one of input / messages)")
    session_id: Any = Field(None, json_schema_extra={"type": "string"}, description="[A-Za-z0-9._:-]{1,128}")
    stream: Any = Field(None, json_schema_extra={"type": "boolean"}, description="true = SSE (same as mode=stream)")


class Usage(BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class InvokeResult(BaseModel):
    invocation_id: str
    agent_id: str
    version: str
    env: VersionEnvT
    status: Literal["succeeded"]
    output: Any = None
    usage: Usage | None = None
    trace_id: str
    duration_ms: int


class InvocationAccepted(BaseModel):
    invocation_id: str
    agent_id: str
    version: str
    env: VersionEnvT
    status: Literal["queued"]
    location: str


class InvocationOut(BaseModel):
    id: str
    agent_id: str
    version: str
    env: VersionEnvT
    caller: str
    team: str
    mode: InvocationModeT
    purpose: Literal["invoke", "verify"] = "invoke"
    status: InvocationStatusT
    session_id: str | None = None
    trace_id: str
    created_at: str
    started_at: str | None = None
    finished_at: str | None = None
    duration_ms: int | None = None
    usage: Usage | None = None
    error_code: str | None = None
    error_message: str | None = None
    output_available: bool = False
    output: Any = Field(None, description="Background runs only; only for the caller and the agent's owner")
    output_expires_at: str | None = None
    retain_until: str | None = None


class InvocationList(BaseModel):
    items: list[InvocationOut]
    total: int


class InvocationSummaryItem(BaseModel):
    agent_id: str
    version: str
    env: VersionEnvT
    invocations: int
    succeeded: int
    failed: int = Field(description="failed or timeout")


class InvocationSummary(BaseModel):
    since: str
    until: str
    items: list[InvocationSummaryItem]
    total: int


class Jwks(BaseModel):
    keys: list[dict[str, str]]


class AgentStatusBody(_In):
    reason: str = Field(min_length=1, max_length=500)
    source: str = Field("manual", max_length=64)
    evidence: dict[str, Any] | None = None


# --- MCP registry -------------------------------------------------------------------------------


class McpServerCreate(_In):
    name: str = Field(min_length=1, max_length=100)
    url: str = Field(min_length=1, max_length=2048)
    description: str = Field("", max_length=2000)
    iam_roles: list[str] = Field(default_factory=list, max_length=50)
    workspaces: list[str] = Field(default_factory=list, max_length=50)


class McpDecision(_In):
    reason: str | None = Field(None, max_length=1000)


class McpServer(BaseModel):
    id: str
    name: str
    url: str
    description: str
    iam_roles: list[str]
    workspaces: list[str]
    status: McpStatus
    requested_by: str
    decided_by: str | None = None
    decided_at: str | None = None
    reason: str | None = None
    sync_status: SyncStatus
    sync_error: str | None = None
    synced_at: str | None = None
    created_at: str
    updated_at: str


class McpServerList(BaseModel):
    items: list[McpServer]
    total: int


# --- model catalog ------------------------------------------------------------------------------


class ModelCreate(_In):
    name: str = Field(min_length=1, max_length=128)
    provider: str = Field(min_length=1, max_length=64)
    version: str = Field(min_length=1, max_length=64)
    tiers: list[UserTier] = Field(default_factory=list)
    job_profiles: list[JobProfile] = Field(default_factory=list)
    use_case: str = Field("", max_length=4000)
    data_classification: DataClassification
    expected_monthly_cost_usd: float = Field(0.0, ge=0)


class ModelTransition(_In):
    to: ModelStatus
    note: str | None = Field(None, max_length=2000)
    canary_share: float | None = Field(None, ge=0, le=100, description="Only with to=canary (default 10)")


ScalarMap = dict[str, float | int | str | bool | None]
DatasetClassificationT = Literal["synthetic", "masked"]
SandboxKeyStatus = Literal["not_created", "disabled", "created", "failed"]
DispatchStatus = Literal["not_sent", "disabled", "dispatched", "failed"]


class ScorecardTier(_In):
    """Per-tier result from the model harness (Phase 7): metrics may differ per tier (job profiles)."""

    passed: bool | None = None
    baseline_model: str | None = Field(None, max_length=256)
    baseline: ScalarMap = Field(default_factory=dict)
    accuracy: float | None = None
    faithfulness: float | None = None
    safety_critical_failures: int | None = Field(None, ge=0)
    latency_p95_ms: float | None = Field(None, ge=0)
    cost_per_1k_usd: float | None = Field(None, ge=0)
    failures: list[str] = Field(default_factory=list, max_length=100)


class ScorecardDataset(_In):
    name: str = Field(min_length=1, max_length=200)
    suite: Literal["benchmark", "safety"] | None = None
    classification: str = Field(min_length=1, max_length=32, description="Must be synthetic or masked (sandbox data policy)")
    cases: int | None = Field(None, ge=0)
    sha256: str | None = Field(None, max_length=64)


class ScorecardCase(_In):
    """One harness case result (kept so the next candidate gets a case-by-case diff vs this model)."""

    id: str = Field(min_length=1, max_length=128)
    suite: str = Field(min_length=1, max_length=64)
    suite_kind: Literal["benchmark", "safety"] | None = None
    profile: JobProfile | None = None
    passed: bool | None = None
    score: float | None = None
    severity: Literal["critical", "major", "minor"] | None = None
    latency_ms: float | None = Field(None, ge=0)
    blocked: bool | None = None


class Scorecard(_In):
    accuracy: float
    faithfulness: float
    safety_critical_failures: int = Field(ge=0)
    latency_p95_ms: float = Field(ge=0)
    cost_per_1k_usd: float = Field(ge=0)
    baseline: ScalarMap = Field(default_factory=dict)
    passed: bool
    evidence_url: str | None = Field(None, max_length=2048)
    # Phase 7 model harness (all optional, so Phase 4 callers keep working).
    tiers: dict[UserTier, ScorecardTier] = Field(default_factory=dict)
    datasets: list[ScorecardDataset] = Field(default_factory=list, max_length=200)
    mode: Literal["fiddler", "offline"] | None = None
    cost_source: str | None = Field(None, max_length=64)
    harness_version: str | None = Field(None, max_length=64)
    run_id: str | None = Field(None, max_length=128)
    report_url: str | None = Field(None, max_length=2048)
    profiles: dict[JobProfile, ScalarMap] = Field(default_factory=dict)
    cases: list[ScorecardCase] = Field(default_factory=list, max_length=5000)


class StoredScorecard(Scorecard):
    updated_at: str | None = None
    updated_by: str | None = None


class GateTier(BaseModel):
    passed: bool
    failures: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class GateResult(BaseModel):
    """Approval-gate evaluation of the latest scorecard against config/model-gate-thresholds.yaml."""

    passed: bool
    failures: list[str] = Field(default_factory=list)
    tiers: dict[str, GateTier] = Field(default_factory=dict)
    thresholds_version: int | str | None = None
    thresholds_status: str | None = None
    evaluated_at: str | None = None


class CanaryPr(_In):
    url: str = Field(min_length=1, max_length=2048, description="https URL of the manifest pull request")
    note: str | None = Field(None, max_length=500)


class Model(BaseModel):
    id: str
    name: str
    provider: str
    version: str
    tiers: list[str]
    job_profiles: list[str]
    use_case: str
    data_classification: DataClassification
    expected_monthly_cost_usd: float
    status: ModelStatus
    requested_by: str
    scorecard: StoredScorecard | None = None
    canary_share: float | None = None
    canary_started_at: str | None = None
    decided_by: str | None = None
    decided_at: str | None = None
    allowed_transitions: list[ModelStatus] = Field(default_factory=list)
    created_at: str
    updated_at: str
    # Phase 7 model harness.
    routing_model_id: str | None = None
    canary_alias: str | None = None
    sandbox_key_status: SandboxKeyStatus = "not_created"
    sandbox_key_id: str | None = None
    sandbox_error: str | None = None
    gate: GateResult | None = None
    ready_for_approval: bool = False
    canary_dispatch_status: DispatchStatus = "not_sent"
    canary_dispatch_error: str | None = None
    canary_pr_url: str | None = None


class ModelList(BaseModel):
    items: list[Model]
    total: int


# --- audit --------------------------------------------------------------------------------------


class AuditEntry(BaseModel):
    id: int
    at: str
    actor: str
    action: str
    entity_type: str
    entity_id: str
    details: dict[str, Any]


class AuditList(BaseModel):
    items: list[AuditEntry]
    total: int


# --- workspaces ---------------------------------------------------------------------------------


class WorkspaceCreate(_In):
    repo_url: str = Field(min_length=1, max_length=2048)
    work_item: str = Field(min_length=1, max_length=500, description="Issue/bug id or URL")
    title: str = Field(min_length=1, max_length=200)
    description: str = Field("", max_length=10000)
    job_profile: str | None = Field(None, max_length=32)


class WorkspaceClaim(_In):
    worker: str | None = Field(None, max_length=128, description="Orchestrator worker id (audit only)")


class WorkspaceStatusUpdate(_In):
    status: WorkspaceStatus
    pr_url: str | None = Field(None, max_length=2048)
    log_url: str | None = Field(None, max_length=2048)
    error: str | None = Field(None, max_length=4000)


class Workspace(BaseModel):
    id: str
    repo_url: str
    work_item: str
    title: str
    description: str
    job_profile: str | None = None
    status: WorkspaceStatus
    requested_by: str
    team: str
    pr_url: str | None = None
    log_url: str | None = None
    error: str | None = None
    created_at: str
    updated_at: str


class WorkspaceList(BaseModel):
    items: list[Workspace]
    total: int


# --- evals --------------------------------------------------------------------------------------


class EvalCreate(_In):
    agent_id: str = Field(min_length=1, max_length=64)
    dataset: str = Field(min_length=1, max_length=256)
    experiment_id: str = Field(min_length=1, max_length=256)
    scores: dict[str, float]
    baseline_scores: dict[str, float] = Field(default_factory=dict)
    passed: bool
    fiddler_url: str | None = Field(None, max_length=2048)
    git_sha: str | None = Field(None, max_length=64)
    pr: str | None = Field(None, max_length=256)


class EvalRun(BaseModel):
    id: str
    agent_id: str
    dataset: str
    experiment_id: str
    scores: dict[str, float]
    baseline_scores: dict[str, float]
    passed: bool
    fiddler_url: str | None = None
    git_sha: str | None = None
    pr: str | None = None
    created_by: str
    created_at: str


class EvalList(BaseModel):
    items: list[EvalRun]
    total: int


# --- usage / routing ----------------------------------------------------------------------------


class TeamUsage(BaseModel):
    team: str
    users: int
    requests: int
    tokens: int
    cost_usd: float


class UsageWindow(BaseModel):
    start: str
    end: str
    days: int


class TeamUsageList(BaseModel):
    items: list[TeamUsage]
    total: int
    env: str
    window: UsageWindow
    source: str = "portkey_analytics"


class Routing(BaseModel):
    env: str
    config_id: str
    config: dict[str, Any]
