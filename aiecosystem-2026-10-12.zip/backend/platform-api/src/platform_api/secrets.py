"""Server-side secret loading.

Secret values never leave this module except through ``SecretStore.get``. Nothing
here (or anywhere else) returns or logs a secret value; callers only see statuses.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Literal, Mapping

# Order only matters for gitleaks: a *_API_KEY name followed by a name that does not end in
# _KEY reads as "KEY_NAME, value" to the repo's custom rules, so the *_API_KEY names come last.
SECRET_NAMES: tuple[str, ...] = (
    "PORTKEY_WEBHOOK_SECRET",
    "PLATFORM_SERVICE_TOKEN",
    "TELEMETRY_BRIDGE_TOKEN",
    "GITHUB_DISPATCH_TOKEN",
    "AGENT_CALLER_SIGNING_KEY",
    "AGENT_OUTPUT_ENCRYPTION_KEY",
    "PORTKEY_API_KEY",
    "PORTKEY_ADMIN_API_KEY",
    "FIDDLER_API_KEY",
)
REQUIRED_SECRETS: tuple[str, ...] = ("PORTKEY_API_KEY",)
# Optional: the service starts without them; the feature that needs one is disabled
# (PORTKEY_WEBHOOK_SECRET: /api/v1/guardrails/agent-check answers 503 outside local;
# PLATFORM_SERVICE_TOKEN: the service endpoints answer 503; TELEMETRY_BRIDGE_TOKEN: IDE usage events
# are not forwarded to the telemetry bridge; GITHUB_DISPATCH_TOKEN: Phase 7 canary dispatches are
# recorded as failed; AGENT_CALLER_SIGNING_KEY: agent invocation is disabled outside local, where an
# ephemeral key is generated; AGENT_OUTPUT_ENCRYPTION_KEY: background invocations are refused
# outside local, where an ephemeral key is generated).
OPTIONAL_SECRETS: tuple[str, ...] = tuple(n for n in SECRET_NAMES if n not in REQUIRED_SECRETS)
PLACEHOLDER_PREFIX = "__REPLACE_ME"

SecretStatus = Literal["configured", "placeholder", "missing"]

log = logging.getLogger(__name__)


def placeholder_for(name: str, env: str) -> str:
    return f"__REPLACE_ME_{name}_{env.upper()}__"


def normalize_secret(value: str | None) -> str | None:
    """Strip whitespace, one pair of matching outer quotes, then whitespace again.

    Process env (Docker --env-file, Kubernetes, CI) and AWS JSON can keep quotes as
    part of the value, so this is applied to every source, not only the .env parser.
    """
    if value is None:
        return None
    v = str(value).strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        v = v[1:-1].strip()
    return v


def _looks_like_placeholder(normalized: str) -> bool:
    # Case-insensitive, and anywhere in the value: a real key never contains the marker.
    return PLACEHOLDER_PREFIX.lower() in normalized.lower()


def is_placeholder(value: str | None) -> bool:
    """Empty, missing, or __REPLACE_ME* values (quoted or not, any case) are placeholders."""
    return secret_status(value) != "configured"


def secret_status(value: str | None) -> SecretStatus:
    """Mask helper: describes a secret without revealing any part of it."""
    v = normalize_secret(value)
    if not v:
        return "missing"
    if _looks_like_placeholder(v):
        return "placeholder"
    return "configured"


class SecretStore:
    def __init__(self, values: Mapping[str, str | None], source: str = "env"):
        self.__values = {n: values.get(n) for n in SECRET_NAMES}
        self.source = source

    def get(self, name: str) -> str | None:
        """Return the secret value, or None if missing/placeholder."""
        value = self.__values.get(name)
        return None if is_placeholder(value) else normalize_secret(value)

    def status(self, name: str) -> SecretStatus:
        return secret_status(self.__values.get(name))

    def statuses(self) -> dict[str, SecretStatus]:
        return {n: self.status(n) for n in SECRET_NAMES}

    def is_configured(self, name: str) -> bool:
        return self.status(name) == "configured"

    def configured_values(self) -> list[str]:
        """Used only by the log/response redaction filter."""
        return [v for n in SECRET_NAMES if (v := self.get(n))]

    def __repr__(self) -> str:  # never show values
        return f"SecretStore(source={self.source!r}, statuses={self.statuses()!r})"

    __str__ = __repr__


def _parse_env_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export "):]
        key, _, val = line.partition("=")
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        out[key.strip()] = val
    return out


def load_env_secrets(env: str, secrets_dir: Path, environ: Mapping[str, str] | None = None) -> SecretStore:
    """Process env wins; falls back to gitignored secrets/.env.<env>."""
    environ = os.environ if environ is None else environ
    file_values: dict[str, str] = {}
    path = Path(secrets_dir) / f".env.{env}"
    if path.is_file():
        file_values = _parse_env_file(path)
        log.info("loaded secrets file for env=%s (%s)", env, path.name)
    values = {n: environ.get(n, file_values.get(n)) for n in SECRET_NAMES}
    return SecretStore(values, source="env")


def aws_secret_id(env: str) -> str:
    return f"aig/{env}/platform-api"


def load_aws_secrets(env: str, client=None) -> SecretStore:
    """Read JSON secret aig/<env>/platform-api from AWS Secrets Manager."""
    if client is None:
        import boto3  # lazy: optional dependency (pip install '.[aws]')

        client = boto3.client("secretsmanager")
    resp = client.get_secret_value(SecretId=aws_secret_id(env))
    data = json.loads(resp.get("SecretString") or "{}")
    if not isinstance(data, dict):
        data = {}
    return SecretStore({n: data.get(n) for n in SECRET_NAMES}, source="aws")


def load_secrets(provider: str, env: str, secrets_dir: Path) -> SecretStore:
    if provider == "aws":
        return load_aws_secrets(env)
    return load_env_secrets(env, secrets_dir)
