"""Finished agent invocations -> backend/telemetry-bridge (``POST /ingest/invocation``).

When an invocation record is closed (any mode, any outcome, also verification runs), platform-api
posts one event shaped by ``backend/contracts/invocation-event.schema.json`` to
``{AIG_TELEMETRY_BRIDGE_URL}/ingest/invocation`` with ``Authorization: Bearer
<TELEMETRY_BRIDGE_TOKEN>``, exactly like the IDE usage events (``usage_events.py``). The bridge
forwards it to Fiddler as one span in the agent's application, joined to the agent's own spans by
trace id / invocation id and tagged with the caller (``aig.caller_user`` / ``aig.caller_team``).

- Fire-and-forget (short timeout, never blocks or fails an invocation; failures logged by type).
- Metadata only: who, agent, version, env, mode, status, duration, tokens, trace id, error code.
  Inputs, messages, outputs and caller tokens are never part of the event.
- ``build_invocation_event`` drops an event whose required fields do not fit the contract.
- Disabled (no-op) unless both the URL and the token are configured.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any

from .config import configured_url
from .usage_events import TOKEN_SECRET, forwarding_enabled

log = logging.getLogger(__name__)

INGEST_PATH = "/ingest/invocation"
_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_VERSION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$")
_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")
_UUID4_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$")
_TRACE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$")
_SESSION_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
_CODE_RE = re.compile(r"^[a-z_]{1,64}$")
ENVS = ("local", "dev", "stage", "prod")
TIERS = ("premium", "standard", "free")
MODES = ("sync", "stream", "background")
PURPOSES = ("invoke", "verify")
STATUSES = ("succeeded", "failed", "cancelled", "timeout")


def agent_host(kind: str, platform_env: str) -> str:
    """Span tag ``host`` for the agent server: AgentCore, else an HTTPS agent (``ecs``), or a local
    test agent when platform-api itself runs in ``local``."""
    if kind == "agentcore":
        return "agentcore"
    return "laptop" if platform_env == "local" else "ecs"


def _int(v: Any) -> int | None:
    return v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None


def build_invocation_event(
    *, invocation_id: str, agent_id: str, team: str, version: str, env: str, kind: str, platform_env: str,
    mode: str, purpose: str, status: str, trace_id: str, caller_user: str, caller_team: str, caller_tier: str,
    duration_ms: int, usage: dict | None = None, error_code: str | None = None, session_id: str | None = None,
    finished_at: datetime | None = None,
) -> dict | None:
    """One contract-valid event, or None when a required field does not fit."""
    checks = (
        bool(_UUID4_RE.match(invocation_id or "")), bool(_ID_RE.match(agent_id or "")), bool(_ID_RE.match(team or "")),
        bool(_VERSION_RE.match(version or "")), env in ENVS, kind in ("agentcore", "https"), mode in MODES,
        purpose in PURPOSES, status in STATUSES, bool(_TRACE_RE.match(trace_id or "")),
        len(caller_user or "") <= 254 and bool(_EMAIL_RE.match(caller_user or "")),
        bool(_ID_RE.match(caller_team or "")), caller_tier in TIERS, _int(duration_ms) is not None,
    )
    if not all(checks):
        return None
    finished = finished_at or datetime.now(timezone.utc)
    event: dict[str, Any] = {
        "invocation_id": invocation_id,
        "timestamp": finished.isoformat(),
        "started_at": (finished - timedelta(milliseconds=duration_ms)).isoformat(),
        "agent_id": agent_id, "team": team, "version": version, "env": env,
        "agent_host": agent_host(kind, platform_env), "kind": kind, "mode": mode, "purpose": purpose,
        "status": status, "trace_id": trace_id, "caller_user": caller_user, "caller_team": caller_team,
        "caller_tier": caller_tier, "duration_ms": duration_ms,
    }
    usage = usage or {}
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        if _int(usage.get(key)) is not None:
            event[key] = usage[key]
    if error_code and status != "succeeded" and _CODE_RE.match(error_code):
        event["error_code"] = error_code
    if isinstance(session_id, str) and _SESSION_RE.match(session_id):
        event["session_id"] = session_id
    return event


def event_for_handle(handle: Any, platform_env: str) -> dict | None:
    """The event for a closed ``invoker.Handle`` (plan + outcome); metadata fields only."""
    plan, outcome = handle.plan, handle.outcome
    return build_invocation_event(
        invocation_id=handle.id, agent_id=plan.agent.agent_id, team=plan.agent.team, version=plan.version.version,
        env=plan.version.env, kind=plan.version.kind, platform_env=platform_env, mode=plan.mode,
        purpose=plan.purpose, status=outcome.status, trace_id=handle.call.trace_id,
        caller_user=plan.identity.email, caller_team=plan.identity.team, caller_tier=plan.identity.tier,
        duration_ms=int(outcome.duration_ms or 0), usage=outcome.usage,
        error_code=outcome.error.code if outcome.error else None, session_id=plan.body.get("session_id"),
    )


async def _post(state: Any, event: dict) -> None:
    url = configured_url(state.settings.telemetry_bridge_url)
    token = state.secrets.get(TOKEN_SECRET)
    client = state.http_client
    if not url or not token or client is None:
        return
    try:
        resp = await client.post(url + INGEST_PATH, json=event,
                                 headers={"authorization": f"Bearer {token}", "content-type": "application/json"},
                                 timeout=state.settings.telemetry_bridge_timeout_seconds)
        if resp.status_code >= 400:
            log.warning("invocation event rejected by the telemetry bridge: HTTP %s", resp.status_code)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        log.warning("invocation event not delivered: %s", type(exc).__name__)


def forward_invocation(state: Any, handle: Any) -> None:
    """Build and schedule the event for one closed invocation (fire-and-forget). Never raises."""
    try:
        if not forwarding_enabled(state):
            return
        event = event_for_handle(handle, state.settings.env)
        if event is None:
            log.warning("invocation event for %s not built (fields outside the contract)", handle.id)
            return
        tasks: set = state.usage_event_tasks
        task = asyncio.get_running_loop().create_task(_post(state, event))
        tasks.add(task)
        task.add_done_callback(tasks.discard)
    except Exception as exc:
        log.warning("invocation event not scheduled: %s", type(exc).__name__)
