"""Platform-signed caller token (``x-aig-caller``, backend/contracts/agent-invocation.md).

ES256 (ECDSA P-256): platform-api signs with the private key from the secret
``AGENT_CALLER_SIGNING_KEY``; agents verify with the public key from
``GET /api/v1/caller-token/jwks``. Agents never hold the signing key, so a compromised agent cannot
mint tokens for other agents or users (the reason HS256 was not chosen).

Key formats accepted for the secret: PEM (PKCS#8 ``BEGIN PRIVATE KEY`` or SEC1 ``BEGIN EC PRIVATE
KEY``), the same PEM with literal ``\\n`` escapes (single-line env files), or base64 of the PEM.
In ``local`` without the secret an ephemeral key is generated at startup (warning; tokens die
with the process). The key and the tokens are never logged.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import time
from dataclasses import dataclass
from typing import Any

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

log = logging.getLogger(__name__)

SECRET_NAME = "AGENT_CALLER_SIGNING_KEY"
TOKEN_TYPE = "aig-caller+jwt"
ALGORITHM = "ES256"


class SigningKeyError(ValueError):
    """The configured signing key is unusable (message never contains key material)."""


def _b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def load_private_key(value: str) -> ec.EllipticCurvePrivateKey:
    text = value.strip()
    if "-----BEGIN" not in text:
        try:
            text = base64.b64decode(text, validate=False).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            raise SigningKeyError(f"{SECRET_NAME} is neither PEM nor base64-encoded PEM") from None
    text = text.replace("\\n", "\n").strip() + "\n"
    try:
        key = serialization.load_pem_private_key(text.encode(), password=None)
    except (ValueError, TypeError):
        raise SigningKeyError(f"{SECRET_NAME} is not a readable unencrypted PEM private key") from None
    if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(key.curve, ec.SECP256R1):
        raise SigningKeyError(f"{SECRET_NAME} must be an EC P-256 (prime256v1) private key")
    return key


def public_jwk(key: ec.EllipticCurvePrivateKey) -> dict[str, str]:
    numbers = key.public_key().public_numbers()
    jwk = {"crv": "P-256", "kty": "EC", "x": _b64u(numbers.x.to_bytes(32, "big")),
           "y": _b64u(numbers.y.to_bytes(32, "big"))}
    # RFC 7638 thumbprint: SHA-256 over the required members, lexicographic order, no spaces.
    thumb = _b64u(hashlib.sha256(json.dumps(jwk, separators=(",", ":"), sort_keys=True).encode()).digest())
    return {**jwk, "kid": thumb, "alg": ALGORITHM, "use": "sig"}


@dataclass(frozen=True)
class CallerIdentity:
    email: str
    name: str
    team: str
    tier: str
    groups: tuple[str, ...] = ()


class CallerTokenSigner:
    def __init__(self, key: ec.EllipticCurvePrivateKey, *, env: str, ttl_seconds: int = 300, ephemeral: bool = False):
        self._key = key
        self.env = env
        self.ttl_seconds = max(30, int(ttl_seconds))
        self.ephemeral = ephemeral
        self.jwk = public_jwk(key)
        self.kid = self.jwk["kid"]

    @property
    def issuer(self) -> str:
        return f"aig-platform-api/{self.env}"

    @classmethod
    def generate(cls, *, env: str, ttl_seconds: int = 300) -> "CallerTokenSigner":
        return cls(ec.generate_private_key(ec.SECP256R1()), env=env, ttl_seconds=ttl_seconds, ephemeral=True)

    def jwks(self) -> dict[str, Any]:
        return {"keys": [dict(self.jwk)]}

    def claims(self, caller: CallerIdentity, *, agent_id: str, version: str, agent_env: str, invocation_id: str,
               trace_id: str, now: int | None = None) -> dict[str, Any]:
        iat = int(time.time() if now is None else now)
        return {
            "iss": self.issuer, "aud": agent_id, "sub": caller.email, "iat": iat, "nbf": iat,
            "exp": iat + self.ttl_seconds, "jti": invocation_id, "user": caller.email, "name": caller.name,
            "team": caller.team, "tier": caller.tier, "groups": sorted(set(caller.groups)), "agent_id": agent_id,
            "version": version, "env": agent_env, "invocation_id": invocation_id, "trace_id": trace_id,
        }

    def sign(self, claims: dict[str, Any]) -> str:
        return jwt.encode(claims, self._key, algorithm=ALGORITHM, headers={"kid": self.kid, "typ": TOKEN_TYPE})

    def verify(self, token: str, *, audience: str) -> dict[str, Any]:
        """Reference verification (what agents do); used by tests and the verify endpoint."""
        return jwt.decode(token, self._key.public_key(), algorithms=[ALGORITHM], audience=audience,
                          issuer=self.issuer, leeway=60,
                          options={"require": ["exp", "iat", "nbf", "iss", "aud", "jti"]})

    def __repr__(self) -> str:  # never show key material
        return f"CallerTokenSigner(env={self.env!r}, kid={self.kid!r}, ephemeral={self.ephemeral})"


def load_signer(secrets: Any, *, env: str, ttl_seconds: int) -> CallerTokenSigner | None:
    """Signer from the secret store; an ephemeral key in local when the secret is missing; None
    elsewhere (invocation disabled). A malformed configured key raises SigningKeyError."""
    value = secrets.get(SECRET_NAME)
    if value:
        return CallerTokenSigner(load_private_key(value), env=env, ttl_seconds=ttl_seconds)
    if env == "local":
        log.warning("AIG_ENV=local: %s not configured; using an ephemeral caller-token key", SECRET_NAME)
        return CallerTokenSigner.generate(env=env, ttl_seconds=ttl_seconds)
    return None
