"""Invocation records (``agent_invocations``) and the background-output cipher.

Records hold metadata only: who, agent, version, env, mode, status, timing, token usage, trace id
and error code (90 days, ``AIG_AGENT_INVOCATION_RETENTION_DAYS``). Output content is stored only for
background runs, encrypted with Fernet (secret ``AGENT_OUTPUT_ENCRYPTION_KEY``), for 30 days
(``AIG_AGENT_OUTPUT_RETENTION_DAYS``). Inputs are never stored.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass
from datetime import timedelta
from typing import Any

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import Integer, and_, delete, func, or_, select, update

from .db import AgentInvocationRow, Database, iso, utcnow

log = logging.getLogger(__name__)

OUTPUT_KEY_SECRET = "AGENT_OUTPUT_ENCRYPTION_KEY"
FINAL_STATUSES = frozenset({"succeeded", "failed", "cancelled", "timeout"})
OPEN_STATUSES = ("queued", "running")
PURGE_INTERVAL_SECONDS = 3600.0
MAX_ERROR_MESSAGE = 500


class OutputCipher:
    """Fernet encryption of background outputs. Never logs keys or plaintext."""

    def __init__(self, key: str | bytes, *, ephemeral: bool = False):
        self._fernet = Fernet(key)
        self.ephemeral = ephemeral

    @classmethod
    def generate(cls) -> "OutputCipher":
        return cls(Fernet.generate_key(), ephemeral=True)

    def encrypt(self, value: Any) -> str:
        return self._fernet.encrypt(json.dumps(value, separators=(",", ":")).encode()).decode()

    def decrypt(self, token: str) -> Any:
        try:
            return json.loads(self._fernet.decrypt(token.encode()))
        except (InvalidToken, ValueError):
            return None

    def __repr__(self) -> str:
        return f"OutputCipher(ephemeral={self.ephemeral})"


def load_cipher(secrets: Any, *, env: str) -> OutputCipher | None:
    value = secrets.get(OUTPUT_KEY_SECRET)
    if value:
        try:
            return OutputCipher(value)
        except (ValueError, TypeError):
            log.error("%s is not a valid Fernet key (32 url-safe base64 bytes); background runs are refused",
                      OUTPUT_KEY_SECRET)
            return None
    if env == "local":
        log.warning("AIG_ENV=local: %s not configured; background outputs use an ephemeral key", OUTPUT_KEY_SECRET)
        return OutputCipher.generate()
    return None


@dataclass(frozen=True)
class Invocation:
    id: str
    agent_id: str
    version: str
    env: str
    caller: str
    team: str
    mode: str
    purpose: str
    status: str
    session_id: str | None
    trace_id: str
    created_at: str
    started_at: str | None
    finished_at: str | None
    duration_ms: int | None
    usage: dict | None
    error_code: str | None
    error_message: str | None
    has_output: bool
    output_expires_at: str | None
    retain_until: str | None

    @property
    def final(self) -> bool:
        return self.status in FINAL_STATUSES


def _view(row: AgentInvocationRow) -> Invocation:
    usage = {k: v for k, v in (("prompt_tokens", row.prompt_tokens), ("completion_tokens", row.completion_tokens),
                               ("total_tokens", row.total_tokens)) if v is not None} or None
    return Invocation(
        id=row.id, agent_id=row.agent_id, version=row.version, env=row.env, caller=row.caller, team=row.team,
        mode=row.mode, purpose=row.purpose or "invoke", status=row.status, session_id=row.session_id,
        trace_id=row.trace_id, created_at=iso(row.created_at) or "", started_at=iso(row.started_at),
        finished_at=iso(row.finished_at), duration_ms=row.duration_ms, usage=usage, error_code=row.error_code,
        error_message=row.error_message, has_output=bool(row.output_encrypted),
        output_expires_at=iso(row.output_expires_at), retain_until=iso(row.retain_until),
    )


class InvocationStore:
    def __init__(self, db: Database, *, retention_days: int = 90, output_retention_days: int = 30):
        self.db = db
        self.retention = timedelta(days=max(1, retention_days))
        self.output_retention = timedelta(days=max(1, output_retention_days))
        self._last_purge = 0.0
        self._lock = threading.Lock()

    def create(self, *, invocation_id: str, agent_id: str, version: str, env: str, caller: str, team: str,
               mode: str, purpose: str, trace_id: str, session_id: str | None, status: str = "queued") -> Invocation:
        self.purge_expired()
        now = utcnow()
        with self.db.session() as s:
            row = AgentInvocationRow(
                id=invocation_id, agent_id=agent_id, version=version, env=env, caller=caller, team=team or "",
                mode=mode, purpose=purpose, status=status, session_id=session_id, trace_id=trace_id,
                created_at=now, started_at=now if status == "running" else None, retain_until=now + self.retention,
            )
            s.add(row)
            s.flush()
            return _view(row)

    def get(self, invocation_id: str) -> Invocation | None:
        with self.db.session() as s:
            row = s.get(AgentInvocationRow, invocation_id)
            return _view(row) if row else None

    def encrypted_output(self, invocation_id: str) -> str | None:
        with self.db.session() as s:
            row = s.get(AgentInvocationRow, invocation_id)
            return row.output_encrypted if row else None

    def mark_running(self, invocation_id: str) -> bool:
        with self.db.session() as s:
            res = s.execute(update(AgentInvocationRow).where(
                AgentInvocationRow.id == invocation_id, AgentInvocationRow.status == "queued"
            ).values(status="running", started_at=utcnow()))
            return (res.rowcount or 0) > 0

    def finish(self, invocation_id: str, *, status: str, usage: dict | None = None, error_code: str | None = None,
               error_message: str | None = None, output_encrypted: str | None = None) -> bool:
        """Close an open record (conditional: a record already cancelled elsewhere is kept)."""
        now = utcnow()
        with self.db.session() as s:
            row = s.get(AgentInvocationRow, invocation_id, with_for_update=True)
            if row is None or row.status in FINAL_STATUSES:
                return False
            started = row.started_at or row.created_at
            if started.tzinfo is None:
                started = started.replace(tzinfo=now.tzinfo)
            row.status, row.finished_at = status, now
            row.duration_ms = max(0, int((now - started).total_seconds() * 1000))
            usage = usage or {}
            row.prompt_tokens = usage.get("prompt_tokens")
            row.completion_tokens = usage.get("completion_tokens")
            row.total_tokens = usage.get("total_tokens")
            row.error_code = error_code
            row.error_message = (error_message or None) and error_message[:MAX_ERROR_MESSAGE]
            if output_encrypted is not None:
                row.output_encrypted = output_encrypted
                row.output_expires_at = now + self.output_retention
            return True

    def list(self, *, callers: list[str] | None = None, agent_ids: list[str] | None = None,
             agent_id: str | None = None, status: str | None = None, limit: int = 50) -> list[Invocation]:
        """Newest first. ``callers``/``agent_ids`` are OR-ed visibility filters (None = no filter)."""
        with self.db.session() as s:
            q = select(AgentInvocationRow)
            ors = []
            if callers is not None:
                ors.append(AgentInvocationRow.caller.in_(callers))
            if agent_ids is not None:
                ors.append(AgentInvocationRow.agent_id.in_(agent_ids))
            if ors:
                q = q.where(or_(*ors))
            if agent_id:
                q = q.where(AgentInvocationRow.agent_id == agent_id)
            if status:
                q = q.where(AgentInvocationRow.status == status)
            rows = s.scalars(q.order_by(AgentInvocationRow.created_at.desc()).limit(limit))
            return [_view(r) for r in rows]

    def summary(self, *, since, until, env: str | None = None, purpose: str | None = "invoke") -> list[dict]:
        """Per (agent, version, env) invocation counts created in [since, until): metadata only.
        Used by telemetry-bridge reconciliation (versions with invocations but no Fiddler traces)."""
        cols = (AgentInvocationRow.agent_id, AgentInvocationRow.version, AgentInvocationRow.env)
        failed = func.sum(func.cast(AgentInvocationRow.status.in_(("failed", "timeout")), Integer))
        ok = func.sum(func.cast(AgentInvocationRow.status == "succeeded", Integer))
        with self.db.session() as s:
            q = select(*cols, func.count(), ok, failed).where(
                AgentInvocationRow.created_at >= since, AgentInvocationRow.created_at < until)
            if env:
                q = q.where(AgentInvocationRow.env == env)
            if purpose:
                q = q.where(AgentInvocationRow.purpose == purpose)
            rows = s.execute(q.group_by(*cols).order_by(*cols)).all()
        return [{"agent_id": a, "version": v, "env": e, "invocations": int(n), "succeeded": int(o or 0),
                 "failed": int(f or 0)} for a, v, e, n, o, f in rows]

    def count_open(self, *, caller: str, mode: str) -> int:
        with self.db.session() as s:
            rows = s.scalars(select(AgentInvocationRow.id).where(
                AgentInvocationRow.caller == caller, AgentInvocationRow.mode == mode,
                AgentInvocationRow.status.in_(OPEN_STATUSES)))
            return len(list(rows))

    def mark_interrupted(self) -> int:
        """At startup: background runs a previous process left open cannot finish any more."""
        with self.db.session() as s:
            res = s.execute(update(AgentInvocationRow).where(
                AgentInvocationRow.mode == "background", AgentInvocationRow.status.in_(OPEN_STATUSES)
            ).values(status="cancelled", finished_at=utcnow(), error_code="invocation_cancelled",
                     error_message="platform-api restarted before the run finished"))
            return res.rowcount or 0

    def purge_expired(self, *, force: bool = False) -> None:
        """Drop records past retention and outputs past output retention (at most hourly). Never raises."""
        now_m = time.monotonic()
        with self._lock:
            if not force and now_m - self._last_purge < PURGE_INTERVAL_SECONDS:
                return
            self._last_purge = now_m
        try:
            now = utcnow()
            with self.db.session() as s:
                s.execute(delete(AgentInvocationRow).where(AgentInvocationRow.retain_until < now))
                s.execute(update(AgentInvocationRow).where(
                    AgentInvocationRow.output_expires_at < now, AgentInvocationRow.output_encrypted.is_not(None)
                ).values(output_encrypted=None))
        except Exception as exc:
            log.warning("invocation retention purge failed: %s", type(exc).__name__)

    def purge(self, *, retention_days: int | None = None, output_retention_days: int | None = None,
              dry_run: bool = False, now=None) -> dict[str, int]:
        """Retention job (``aig-platform-api invocations purge``, scheduled daily in ECS).

        Deletes invocation metadata older than ``retention_days`` (default: the store's 90 days) or
        past its ``retain_until``, and clears background outputs older than ``output_retention_days``
        (default 30) or past ``output_expires_at``. Open (queued/running) records are kept. The
        configured windows apply to existing rows too, so shortening retention takes effect at the
        next run. ``dry_run`` only counts. Returns ``{"invocations_deleted", "outputs_cleared"}``."""
        now = now or utcnow()
        keep = timedelta(days=max(1, retention_days)) if retention_days else self.retention
        keep_out = timedelta(days=max(1, output_retention_days)) if output_retention_days else self.output_retention
        old = and_(AgentInvocationRow.status.not_in(OPEN_STATUSES),
                   or_(AgentInvocationRow.retain_until < now, AgentInvocationRow.created_at < now - keep))
        expired_out = and_(AgentInvocationRow.output_encrypted.is_not(None),
                           or_(AgentInvocationRow.output_expires_at < now,
                               func.coalesce(AgentInvocationRow.finished_at, AgentInvocationRow.created_at) < now - keep_out))
        with self.db.session() as s:
            n_old = s.scalar(select(func.count()).select_from(AgentInvocationRow).where(old)) or 0
            n_out = s.scalar(select(func.count()).select_from(AgentInvocationRow).where(expired_out, ~old)) or 0
            if not dry_run:
                s.execute(delete(AgentInvocationRow).where(old))
                s.execute(update(AgentInvocationRow).where(expired_out).values(output_encrypted=None))
        return {"invocations_deleted": int(n_old), "outputs_cleared": int(n_out)}
