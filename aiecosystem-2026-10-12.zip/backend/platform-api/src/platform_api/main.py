"""App factory. Run with: uvicorn platform_api.main:create_app --factory --port 8080"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import __version__
from .auth import Authenticator, KeyResolver
from .config import EnvConfig, Settings, has_placeholder, load_env_config, public_base_url_problem
from .schemas import ErrorBody
from .errors import ApiError, StartupError, api_error_handler, error_body
from .logging import configure_logging
from .agent_hooks import AgentHook, load_agent_hooks
from .agents import AgentRegistry, read_agents_file, resolve_agents_file
from .agent_secrets import AgentAuthenticator, DefaultSecretResolver, SecretResolver
from .agents_db import DbAgentRegistry, DbAgentVersions
from .caller_token import SigningKeyError, load_signer
from .db import Database, open_database, resolve_database_url, url_password
from .invocation_events import forward_invocation
from .invocations import InvocationStore, load_cipher
from .invoker import AgentCoreInvoker, BackgroundRunner, HttpsInvoker, Invoker
from .routes import agents as agents_routes
from .routes import audit, evals, guardrails, health, invoke, llm, local_auth, mcp, me, models, routing, session, usage, workspaces, ws
from .secrets import REQUIRED_SECRETS, SecretStore, load_secrets
from .model_gate import default_thresholds_file, load_for_startup
from .users import UserDirectory, YamlUserDirectory, resolve_users_file

log = logging.getLogger("platform_api")


def enforce_startup_policy(settings: Settings, secrets: SecretStore, cfg: EnvConfig) -> None:
    """Fail closed outside local; warn (but start) in local."""
    if settings.auth_mode == "dev" and settings.env != "local":
        raise StartupError(f"AIG_AUTH_MODE=dev is not allowed in AIG_ENV={settings.env}")
    missing = [n for n in REQUIRED_SECRETS if not secrets.is_configured(n)]
    if missing:
        detail = ", ".join(f"{n}={secrets.status(n)}" for n in missing)
        if settings.env != "local":
            raise StartupError(
                f"refusing to start in AIG_ENV={settings.env}: required secrets not configured ({detail}). "
                f"Upload them to secrets/.env.{settings.env} or AWS Secrets Manager aig/{settings.env}/platform-api."
            )
        log.warning("AIG_ENV=local: required secrets not configured (%s); LLM proxy will return 503", detail)
    if settings.env != "local":
        # Without it /api/v1/session would derive llm.base_url from the (spoofable) Host header.
        problem = public_base_url_problem(settings.public_base_url)
        if problem:
            raise StartupError(
                f"refusing to start in AIG_ENV={settings.env}: AIG_PUBLIC_BASE_URL {problem}. "
                "Set it to this service's public https URL."
            )
    for key in ("portkey_gateway_url", "oidc_issuer", "oidc_audience", "oidc_jwks_url"):
        if has_placeholder(getattr(cfg, key)):
            log.warning("config %s for env=%s still contains a placeholder", key, settings.env)


def create_app(
    settings: Settings | None = None,
    *,
    secrets: SecretStore | None = None,
    users: UserDirectory | None = None,
    agents: AgentRegistry | None = None,
    http_client: httpx.AsyncClient | None = None,
    key_resolver: KeyResolver | None = None,
    agent_hooks: list[AgentHook] | None = None,
    database: Database | None = None,
    agent_http_client: httpx.AsyncClient | None = None,
    agentcore_client_factory=None,
    secret_resolver: SecretResolver | None = None,
) -> FastAPI:
    settings = settings or Settings()
    secrets = secrets if secrets is not None else load_secrets(settings.secret_provider, settings.env, settings.secrets_dir)
    extra_redactions: list[str] = []
    configure_logging(settings.log_level, lambda: [*secrets.configured_values(), *extra_redactions])
    cfg = load_env_config(settings)
    enforce_startup_policy(settings, secrets, cfg)
    if database is None:
        password = url_password(resolve_database_url(settings.env, settings.database_url))
        if password:
            extra_redactions.append(password)
        database = open_database(settings)

    authenticator = Authenticator(
        env=settings.env,
        auth_mode=settings.auth_mode,
        issuer=cfg.oidc_issuer,
        audience=cfg.oidc_audience,
        jwks_url=cfg.oidc_jwks_url,
        key_resolver=key_resolver,
    )
    if users is None:
        users = YamlUserDirectory.from_file(
            resolve_users_file(settings.env, settings.config_dir, settings.users_file),
            cfg.default_user_tier,
            env=settings.env,
        )
    if agents is None:
        registry = DbAgentRegistry(database)
        if registry.is_empty():
            # One-time seed on first start; later changes live only in the database
            # (re-import explicitly with `aig-platform-api agents import FILE`).
            seed = read_agents_file(
                resolve_agents_file(settings.env, settings.config_dir, settings.agents_file), env=settings.env
            )
            if seed:
                log.info("seeding the agent registry from the registry file (%d agents)", len(seed))
                registry.import_records(seed)
        registry.ensure_builtins()
        agents = registry

    if agent_hooks is None:
        agent_hooks = load_agent_hooks(
            fiddler_autoprovision=settings.fiddler_autoprovision, extra=settings.agent_hooks, env=settings.env
        )

    # --- registry v2 + agent invocation ---------------------------------------------------------
    def register_redaction(value: str) -> None:
        if value and value not in extra_redactions:
            extra_redactions.append(value)
            del extra_redactions[:-500]  # bounded: per-agent credentials and tokens

    def secret_values() -> list[str]:
        return [*secrets.configured_values(), *extra_redactions]

    signer, disabled_reason = build_signer(settings, secrets)
    agent_trace_check = load_trace_check(settings)
    versions = DbAgentVersions(database)
    invocation_store = InvocationStore(database, retention_days=settings.agent_invocation_retention_days,
                                       output_retention_days=settings.agent_output_retention_days)
    interrupted = invocation_store.mark_interrupted()
    if interrupted:
        log.warning("%d background invocation(s) from a previous run marked cancelled", interrupted)
    resolver = secret_resolver or DefaultSecretResolver(env=settings.env, secrets_dir=settings.secrets_dir,
                                                        register_redaction=register_redaction)
    holder: dict = {}
    https_invoker = HttpsInvoker(lambda: holder["app"].state.agent_http_client,
                                 AgentAuthenticator(resolver, register_redaction=register_redaction),
                                 connect_timeout=settings.agent_connect_timeout_seconds,
                                 max_bytes=settings.agent_max_response_bytes)
    agentcore_invoker = AgentCoreInvoker(region=settings.agentcore_region,
                                         read_timeout=max(settings.agent_stream_timeout_seconds,
                                                          settings.agent_background_timeout_seconds),
                                         connect_timeout=settings.agent_connect_timeout_seconds,
                                         max_bytes=settings.agent_max_response_bytes,
                                         client_factory=agentcore_client_factory)
    invoker = Invoker(settings=settings, registry=agents, versions=versions, store=invocation_store, db=database,
                      signer=signer, cipher=load_cipher(secrets, env=settings.env), https=https_invoker,
                      agentcore=agentcore_invoker, secrets_provider=secret_values, disabled_reason=disabled_reason,
                      on_finish=lambda handle: forward_invocation(holder["app"].state, handle))
    runner = BackgroundRunner(invoker)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        owned = app.state.http_client is None
        if owned:
            app.state.http_client = httpx.AsyncClient(
                timeout=httpx.Timeout(settings.upstream_timeout_seconds, connect=10.0)
            )
        owned_agent_client = app.state.agent_http_client is None
        if owned_agent_client:
            # Separate client for agent servers: no shared base timeout (Invoker enforces the
            # mode's deadline), never follows redirects.
            app.state.agent_http_client = httpx.AsyncClient(follow_redirects=False)
        log.info("platform-api starting env=%s secrets=%s", settings.env, secrets.statuses())
        try:
            yield
        finally:
            await app.state.invocation_runner.shutdown()
            pending = list(app.state.usage_event_tasks)
            if pending:  # give in-flight usage events their (short) timeout, then stop
                await asyncio.wait(pending, timeout=settings.telemetry_bridge_timeout_seconds)
            if owned:
                await app.state.http_client.aclose()
                app.state.http_client = None
            if owned_agent_client:
                await app.state.agent_http_client.aclose()
                app.state.agent_http_client = None

    app = FastAPI(
        title="AIG platform-api",
        version=__version__,
        lifespan=lifespan,
        description=(
            "AIG AI Ecosystem backend: key broker and LLM proxy, agent / MCP / model registries, audit log, "
            "team workspaces, evals, usage and routing. Errors use {\"error\": {\"code\", \"message\"}}; "
            "list endpoints return {\"items\": [...], \"total\": n}; timestamps are ISO-8601 UTC."
        ),
        responses={
            401: {"model": ErrorBody, "description": "unauthenticated / service_unauthenticated"},
            403: {"model": ErrorBody, "description": "forbidden (missing role)"},
            400: {"model": ErrorBody, "description": "invalid_request / invalid_json / ..."},
        },
    )
    app.state.settings = settings
    app.state.env_config = cfg
    app.state.secrets = secrets
    app.state.users = users
    app.state.agents = agents
    app.state.agent_hooks = agent_hooks
    app.state.authenticator = authenticator
    app.state.http_client = http_client
    app.state.usage_cache = {}
    app.state.usage_limit_cache = {}
    app.state.db = database
    app.state.usage_event_tasks = set()
    app.state.agent_versions = versions
    app.state.invocations = invocation_store
    app.state.invoker = invoker
    app.state.invocation_runner = runner
    app.state.agent_http_client = agent_http_client
    app.state.agent_trace_check = agent_trace_check
    app.state.secret_values = secret_values
    holder["app"] = app
    # Phase 7 approval-gate thresholds (fail closed outside local when missing or invalid).
    app.state.gate_thresholds = load_for_startup(
        settings.model_gate_thresholds_file or default_thresholds_file(settings.config_dir), settings.env
    )

    app.add_exception_handler(ApiError, api_error_handler)
    app.add_exception_handler(RequestValidationError, validation_error_handler)
    app.add_exception_handler(StarletteHTTPException, http_error_handler)
    origins = cfg.browser_origins
    if origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
            allow_headers=["authorization", "content-type", "x-aig-job-profile", "x-aig-agent-id", "x-aig-trace-id"],
            expose_headers=["x-aig-trace-id", "x-aig-invocation-id", "x-aig-route-user-tier", "x-aig-route-cost-mode", "x-aig-route-job-profile", "x-aig-route-usage-state"],
        )
    for module in (health, session, me, llm, usage, local_auth, ws, guardrails, agents_routes, invoke, mcp, models,
                   audit, workspaces, evals, routing):
        app.include_router(module.router)
    return app


def build_signer(settings: Settings, secrets: SecretStore):
    """(signer, disabled_reason). Fail closed: a malformed key stops startup everywhere;
    AIG_AGENT_INVOCATION=true without a key stops startup outside local."""
    if settings.agent_invocation is False:
        return None, "agent invocation is disabled (AIG_AGENT_INVOCATION=false)"
    try:
        signer = load_signer(secrets, env=settings.env, ttl_seconds=settings.agent_caller_token_ttl_seconds)
    except SigningKeyError as exc:
        raise StartupError(f"refusing to start in AIG_ENV={settings.env}: {exc}") from None
    if signer is None:
        if settings.agent_invocation:
            raise StartupError(
                f"refusing to start in AIG_ENV={settings.env}: AIG_AGENT_INVOCATION=true but AGENT_CALLER_SIGNING_KEY "
                "is not configured (EC P-256 private key, PEM)"
            )
        log.warning("AIG_ENV=%s: AGENT_CALLER_SIGNING_KEY not configured; agent invocation is disabled", settings.env)
        return None, "AGENT_CALLER_SIGNING_KEY is not configured; agent invocation is disabled"
    return signer, None


def load_trace_check(settings: Settings):
    """The verification trace-check hook (AIG_AGENT_TRACE_CHECK), or None (``not configured``)."""
    spec = (settings.agent_trace_check or "").strip()
    if not spec:
        return None
    from .agent_hooks import _import

    try:
        return _import(spec)
    except Exception as exc:
        if settings.env != "local":
            raise StartupError(f"refusing to start in AIG_ENV={settings.env}: trace check {spec} unavailable "
                               f"({type(exc).__name__})") from None
        log.warning("AIG_ENV=local: trace check %s unavailable (%s); verification reports not_configured",
                    spec, type(exc).__name__)
        return None


async def validation_error_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    """Request validation uses the shared envelope (400), never FastAPI's 422 detail list."""
    errors = exc.errors()
    if any(e.get("type") == "json_invalid" for e in errors):
        return JSONResponse(error_body("invalid_json", "body is not JSON"), status_code=400)
    parts = []
    for e in errors[:10]:
        loc = ".".join(str(p) for p in e.get("loc", ()) if p not in ("body",)) or "body"
        parts.append(f"{loc}: {e.get('msg', 'invalid')}")
    return JSONResponse(error_body("invalid_request", "invalid fields: " + "; ".join(parts)), status_code=400)


_HTTP_CODES = {404: "not_found", 405: "method_not_allowed", 413: "payload_too_large"}


async def http_error_handler(_: Request, exc: StarletteHTTPException) -> JSONResponse:
    code = _HTTP_CODES.get(exc.status_code, f"http_{exc.status_code}")
    message = exc.detail if isinstance(exc.detail, str) else code.replace("_", " ")
    return JSONResponse(error_body(code, message), status_code=exc.status_code, headers=getattr(exc, "headers", None))


# --- CLI: aig-platform-api [serve | db upgrade | db current | agents import FILE | invocations purge] -


def run(argv: list[str] | None = None) -> int:  # console entry point
    parser = argparse.ArgumentParser(prog="aig-platform-api", description="AIG platform-api")
    sub = parser.add_subparsers(dest="cmd")
    serve = sub.add_parser("serve", help="run the API (default)")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=8080)
    db = sub.add_parser("db", help="database schema (Alembic)")
    db_sub = db.add_subparsers(dest="db_cmd", required=True)
    up = db_sub.add_parser("upgrade", help="apply migrations (default: to head)")
    up.add_argument("revision", nargs="?", default="head")
    db_sub.add_parser("current", help="print the current and head revisions")
    agents_p = sub.add_parser("agents", help="agent registry")
    agents_sub = agents_p.add_subparsers(dest="agents_cmd", required=True)
    imp = agents_sub.add_parser("import", help="import (seed) agents from a registry YAML file")
    imp.add_argument("file", type=Path)
    imp.add_argument("--update", action="store_true", help="also update agents that already exist")
    inv_p = sub.add_parser("invocations", help="agent invocation records")
    inv_sub = inv_p.add_subparsers(dest="invocations_cmd", required=True)
    purge = inv_sub.add_parser("purge", help="retention: delete invocation metadata and background outputs past "
                                             "retention (scheduled daily)")
    purge.add_argument("--retention-days", type=int, default=None,
                       help="invocation metadata retention (default AIG_AGENT_INVOCATION_RETENTION_DAYS, 90)")
    purge.add_argument("--output-retention-days", type=int, default=None,
                       help="background output retention (default AIG_AGENT_OUTPUT_RETENTION_DAYS, 30)")
    purge.add_argument("--dry-run", action="store_true", help="only count what would be purged")
    args = parser.parse_args(argv)

    if args.cmd in (None, "serve"):
        import uvicorn

        uvicorn.run("platform_api.main:create_app", factory=True,
                    host=getattr(args, "host", "0.0.0.0"), port=getattr(args, "port", 8080))
        return 0

    settings = Settings()
    configure_logging(settings.log_level, lambda: [])
    try:
        if args.cmd == "db":
            from .db import current_revision, head_revision, make_engine, safe_url, upgrade

            url = resolve_database_url(settings.env, settings.database_url)
            engine = make_engine(url)
            try:
                if args.db_cmd == "upgrade":
                    upgrade(engine, Path(settings.migrations_dir), args.revision)
                    print(f"database {safe_url(url)} upgraded to {current_revision(engine)}")
                else:
                    print(f"current: {current_revision(engine) or '-'}  head: {head_revision(Path(settings.migrations_dir))}")
            finally:
                engine.dispose()
            return 0
        if args.cmd == "agents":
            if not args.file.is_file():
                print(f"error: {args.file} does not exist", file=sys.stderr)
                return 2
            database = open_database(settings)
            try:
                records = read_agents_file(args.file, env=settings.env)
                registry = DbAgentRegistry(database)
                counts = registry.import_records(records, update=args.update)
                registry.ensure_builtins()
                print(f"imported {args.file.name}: {counts['created']} created, {counts['updated']} updated, "
                      f"{counts['skipped']} skipped")
            finally:
                database.dispose()
            return 0
        if args.cmd == "invocations":
            return purge_invocations(settings, retention_days=args.retention_days,
                                     output_retention_days=args.output_retention_days, dry_run=args.dry_run)
    except StartupError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    parser.print_help()
    return 2


def purge_invocations(settings: Settings, *, retention_days: int | None = None, output_retention_days: int | None = None,
                      dry_run: bool = False, database: Database | None = None) -> int:
    """``aig-platform-api invocations purge``: one retention pass, then exit (ECS scheduled task).
    Prints one JSON line with the counts (never record contents)."""
    days = retention_days if retention_days is not None else settings.agent_invocation_retention_days
    out_days = output_retention_days if output_retention_days is not None else settings.agent_output_retention_days
    if days < 1 or out_days < 1:
        print("error: retention days must be >= 1", file=sys.stderr)
        return 2
    if out_days > days:
        print("error: output retention must not exceed invocation retention", file=sys.stderr)
        return 2
    owned = database is None
    database = database or open_database(settings)
    try:
        store = InvocationStore(database, retention_days=days, output_retention_days=out_days)
        counts = store.purge(retention_days=days, output_retention_days=out_days, dry_run=dry_run)
    finally:
        if owned:
            database.dispose()
    print(json.dumps({"command": "invocations purge", "dry_run": dry_run, "retention_days": days,
                      "output_retention_days": out_days, **counts}, sort_keys=True))
    log.info("invocation purge dry_run=%s deleted=%d outputs_cleared=%d", dry_run, counts["invocations_deleted"],
             counts["outputs_cleared"])
    return 0
