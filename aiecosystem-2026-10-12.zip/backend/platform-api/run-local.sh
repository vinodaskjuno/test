#!/usr/bin/env bash
# Start/stop the local AIG platform-api (AIG_ENV=local, browser sign-in) in the background.
# Token usage is always live from Portkey analytics: put PORTKEY_API_KEY and PORTKEY_ADMIN_API_KEY in
# secrets/.env.local and point config/environments/local.yaml at your self-hosted Portkey.
#   ./run-local.sh            start (or restart)
#   ./run-local.sh stop       stop
#   ./run-local.sh status     show health
#   ./run-local.sh logs       follow the log
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-8080}"
LOG=.run/backend.log
mkdir -p .run

stop() {
  lsof -nP -tiTCP:"$PORT" -sTCP:LISTEN | xargs -r kill 2>/dev/null || true
  # Wait until the old server has released the port, so a restart never talks to the old process.
  for _ in $(seq 1 40); do lsof -nP -tiTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1 || return 0; sleep 0.25; done
  lsof -nP -tiTCP:"$PORT" -sTCP:LISTEN | xargs -r kill -9 2>/dev/null || true
}
health() { curl -sf "http://localhost:$PORT/healthz" && echo; }

case "${1:-start}" in
  stop) stop; echo "stopped" ;;
  status) health || echo "not running on :$PORT" ;;
  logs) tail -f "$LOG" ;;
  start)
    [ -x .venv/bin/uvicorn ] || { python3 -m venv .venv && .venv/bin/pip install -q -e '.[dev]'; }
    stop
    override=""
    [ -f config/environments/local.override.yaml ] && override="$PWD/config/environments/local.override.yaml"
    AIG_ENV=local AIG_AUTH_MODE=dev AIG_CONFIG_OVERRIDE_FILE="$override" \
      nohup .venv/bin/uvicorn platform_api.main:create_app --factory --host 127.0.0.1 --port "$PORT" >"$LOG" 2>&1 </dev/null &
    disown
    for _ in $(seq 1 40); do health >/dev/null 2>&1 && break; sleep 0.25; done
    health || { echo "failed to start; see $LOG"; exit 1; }
    echo "platform-api running on http://localhost:$PORT (log: $LOG)"
    ;;
  *) echo "usage: $0 [start|stop|status|logs]"; exit 2 ;;
esac
