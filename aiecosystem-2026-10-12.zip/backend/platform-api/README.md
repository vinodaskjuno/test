# AIG platform-api

Backend for the AIG AI Ecosystem. It is the **only** component that holds the Portkey
enterprise API keys. The VS Code extension (and other clients) never receive, store or
log a Portkey key. They sign in with Microsoft Entra ID and call this service. The
service proxies model calls to the self-hosted Portkey gateway and adds the key, the
routing config (`pc-aig-router`) and the metadata on the server side.

It also hosts the **portal API** for `web` (Phase 4): the agent registry, MCP registry,
model catalog with approvals, audit log, team workspace requests, eval history, usage per team
and the routing view, persisted in a database (SQLite locally, Postgres elsewhere) with Alembic
migrations. The OpenAPI document is exported to `backend/contracts/platform-api.openapi.json`.

The repo contains **placeholders only**, one set per environment (`local`, `dev`,
`stage`, `prod`). The environment is chosen with `AIG_ENV` (default `local`).

## Secrets

| Name | Required | Used for |
|---|---|---|
| `PORTKEY_API_KEY` | yes | Portkey gateway key for proxied LLM calls |
| `PORTKEY_ADMIN_API_KEY` | no | Portkey analytics lookups (`/api/v1/usage/me`, `/dashboard`, `/by-team`) and, with `AIG_MCP_SYNC=true`, the MCP registry sync to the Portkey MCP gateway (then it needs MCP-server write scope) |
| `FIDDLER_API_KEY` | no | Forwarding usage events to Fiddler |
| `PORTKEY_WEBHOOK_SECRET` | no | Shared secret for Portkey's agent-check webhook guardrail (`x-aig-webhook-secret`); without it `/api/v1/guardrails/agent-check` answers 503 outside `local` |
| `PLATFORM_SERVICE_TOKEN` | no | Service token (`x-aig-service-token`, role `service`) for machine callers: telemetry-bridge reconciliation (agent suspend), fiddler-sync (agent list), the evals gate (`POST /api/v1/evals`), the model harness (transitions, scorecards) and the workspace orchestrator (`GET /api/v1/workspaces`, `POST /api/v1/workspaces/{id}/claim`, `PATCH /api/v1/workspaces/{id}/status`, agent registration of `workspace.<team>`). Without it those calls answer 503 in every env |
| `GITHUB_DISPATCH_TOKEN` | no | Phase 7: `repository_dispatch` to `AIG_GITHUB_REPO` on model canary / promote / rollback (`AIG_CANARY_DISPATCH=true`); without it the dispatch is recorded as `failed` |
| `TELEMETRY_BRIDGE_TOKEN` | no | Bearer token for `POST {AIG_TELEMETRY_BRIDGE_URL}/ingest/ide-usage` and `/ingest/invocation` (same value as the bridge's `AIG_BRIDGE_INGEST_TOKEN`). Without it IDE usage and invocation events are not forwarded |

Committed placeholders look like `__REPLACE_ME_PORTKEY_API_KEY_DEV__`. A value that is
empty or starts with `__REPLACE_ME` counts as **not configured**.

### Uploading keys manually

Option A: env file (`AIG_SECRET_PROVIDER=env`, the default)

```bash
cp secrets/dev.env.example secrets/.env.dev   # secrets/.env.* is gitignored
$EDITOR secrets/.env.dev                      # replace each __REPLACE_ME_..._DEV__ value
```

Real process environment variables with the same names take precedence over the file.
In containers, mount the file at `/app/secrets/.env.<env>` or pass the variables from
your orchestrator's secret store.

Option B: AWS Secrets Manager (`AIG_SECRET_PROVIDER=aws`, needs `pip install '.[aws]'`)

```bash
aws secretsmanager create-secret --name aig/dev/platform-api \
  --secret-string '{"PORTKEY_API_KEY":"...","PORTKEY_ADMIN_API_KEY":"...","FIDDLER_API_KEY":"...","PORTKEY_WEBHOOK_SECRET":"...","PLATFORM_SERVICE_TOKEN":"...","TELEMETRY_BRIDGE_TOKEN":"..."}'
```

The secret id is `aig/<env>/platform-api`. Region and credentials come from the
standard AWS environment and instance role.

### Fail-closed behaviour

- In `dev`, `stage` and `prod`, the service **refuses to start** if `PORTKEY_API_KEY`
  is missing or still a placeholder.
- In `local` it starts and logs a warning. The LLM proxy then returns
  `503 {"error":{"code":"portkey_key_not_configured"}}`.
- In `dev`, `stage` and `prod`, the service also refuses to start unless
  `AIG_PUBLIC_BASE_URL` is set to a real `https://` URL. This keeps a spoofed `Host`
  header from changing the LLM URL that `/api/v1/session` hands to clients.
- In `dev`, `stage` and `prod`, the service refuses to start unless `AIG_DATABASE_URL` is a
  Postgres URL (`postgresql+psycopg://...`, not a placeholder), the database is reachable and its
  schema is at the Alembic head (run `aig-platform-api db upgrade` first).
- Secret values are never returned by any endpoint. A log filter and a response filter
  also redact them if one ever slips through. `/healthz` reports only
  `configured`, `placeholder` or `missing`.

## Non-secret config

`config/environments/<env>.yaml` holds the gateway URLs, the Portkey config id, Fiddler
URL, OIDC issuer/audience/JWKS, CORS origins, the default user tier and the allowed job
profiles. Replace the `__PLACEHOLDER__` URLs for each environment. An extra optional key,
`portkey_admin_api_url`, sets the Portkey analytics API base (defaults to the gateway URL).
Phase 4 keys: `web_allowed_origins` (browser origins of `web`: CORS and WebSocket, plus the
local sign-in redirect), `portkey_ui_url` (deep links), `portkey_mcp_servers_path` (default
`/mcp-servers`), `portkey_usage_by_team_path` (default `/analytics/groups/metadata/team`) and the
agent deep-link templates `fiddler_agent_link` / `portkey_agent_link`. A URL that is unset or
still a `__PLACEHOLDER__` produces `null` links.

The user directory (tier and team per user) is read from the file named by
`AIG_USERS_FILE`, otherwise from `config/users.yaml`. Unknown users get
`default_user_tier`.

- `config/users.example.yaml` (which grants sample `premium` tiers) is used **only** with
  `AIG_ENV=local`, as the fallback when neither of the above exists.
- In `dev`, `stage` and `prod` the example file is never read, even if `AIG_USERS_FILE`
  points at it. If no user directory is found, the service logs a warning and every
  user gets `default_user_tier` and the `unassigned` team.
- The directory is **validated on load** against the contract: `tier` must be `premium`,
  `standard` or `free`, `team` (and `default_team`) a non-empty `[A-Za-z0-9._-]{1,64}` slug, and the
  optional `roles` a non-empty list drawn from `user`, `admin`, `approver` (default `[user]`).
  Outside `local` an invalid entry stops startup (`StartupError`); in `local` it is logged and
  ignored (that user gets the defaults).

### Roles

| Role | Who | May |
|---|---|---|
| `user` | everyone (default) | read the registries, register agents (for themselves and their team), edit agents they own, request MCP servers / models / workspaces, see their own workspaces, set preferences |
| `admin` | `roles: [admin]` in the user directory | everything a user may, plus register agents for any owner/team, edit any agent, suspend/reinstate agents, approve/reject MCP servers, model steps `sandbox`/`evaluating`/`canary`, scorecards, all workspaces, the audit log |
| `approver` | `roles: [approver]` | model `approved`/`rejected`/`promoted`/`rolled_back`, the audit log |
| `service` | the `x-aig-service-token` header (`PLATFORM_SERVICE_TOKEN`) | agent list/register/suspend/reinstate, model steps `sandbox`/`evaluating`/`canary` and scorecards, `POST /api/v1/evals`, workspace claim and status updates, all workspaces |

A request with the service header is always a service call (a wrong token is `401
service_unauthenticated`). A missing role is `403 forbidden`. Helpers: `src/platform_api/authz.py`
(`get_caller`, `get_user`, `get_service`, `require_roles`).

### Database

SQLAlchemy 2.x models in `src/platform_api/db.py`; the schema is owned by Alembic (`migrations/`).

| Env | `AIG_DATABASE_URL` | Schema |
|---|---|---|
| `local` | optional; default `sqlite:///.run/platform.db` | migrated automatically at startup |
| `dev`, `stage`, `prod` | **required**, `postgresql+psycopg://user:password@host:5432/db` (a plain `postgresql://` URL is switched to psycopg 3); startup fails without it | must already be at head: run `aig-platform-api db upgrade` (a one-off task before each rollout); `AIG_DB_AUTO_MIGRATE=true` migrates at startup instead |

```bash
.venv/bin/aig-platform-api db upgrade                 # apply migrations (AIG_DATABASE_URL / local default)
.venv/bin/aig-platform-api db current                 # current vs head revision
.venv/bin/aig-platform-api agents import config/agents.yaml [--update]   # seed/import registry YAML
.venv/bin/aig-platform-api invocations purge [--dry-run] [--retention-days 90] [--output-retention-days 30]
                                                      # retention job (ECS scheduled task, daily)
.venv/bin/alembic revision --autogenerate -m "..."    # new migration (alembic.ini; review the output)
```

The URL's password is never logged (it joins the log redaction filter, and URLs are printed with
the password hidden). Tables: `agents`, `user_preferences`, `mcp_servers`, `models`, `audit_log`,
`workspaces`, `eval_runs`. Tests run on in-memory SQLite; `tests/test_db.py` checks the migrations
produce exactly the models' schema (on Postgres too when `AIG_TEST_POSTGRES_URL` is set, as in CI).

### Agent registry

`AgentRegistry` (`src/platform_api/agents.py`) maps an `agent_id` to owner, team and status
(`active` | `suspended`), plus an optional `shared` flag (any team may use it). Since Phase 4 the
default implementation is the database (`agents_db.DbAgentRegistry`), behind the same interface;
it also keeps name, description, `builtin`, timestamps, `last_seen_at` / `hosts_seen` and the
Fiddler application id. `YamlAgentRegistry` remains for tests and tools.

- **YAML is a one-time seed**: when the `agents` table is empty (first start), the file
  `AIG_AGENTS_FILE`, else `config/agents.yaml` (gitignored), is imported (`config/agents.example.yaml`
  only with `AIG_ENV=local`, same rule as the user directory). Afterwards the database is the source
  of truth; import again explicitly with `aig-platform-api agents import FILE [--update]`.
- Built in and always registered (shared, team `aig-platform`, `builtin: true`): `ide.vscode`,
  `ide.eclipse`, `web.portal`. A seed file may override them (for example to suspend one).
- Entries are validated on import (id pattern, owner, team slug, status); invalid entries stop
  startup outside `local` and are ignored with a warning in `local`.
- `last_seen_at` / `hosts_seen` are updated (at most once a minute per agent unless a new host
  appears) when an agent passes the agent-check webhook and when platform-api proxies a call for it.
- **IDE traffic always carries an agent id**: when the client sends no `x-aig-agent-id` (or
  WebSocket `agent_id`), the proxy sends the host's pre-registered agent (`ide.vscode` for
  host `vscode`; `DEFAULT_AGENT_BY_HOST` already maps `eclipse` -> `ide.eclipse` and `web` ->
  `web.portal` for when those clients ship). The gateway requires `agent_id` on every call.

| Variable | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local`, `dev`, `stage` or `prod` |
| `AIG_SECRET_PROVIDER` | `env` | `env` or `aws` |
| `AIG_AUTH_MODE` | `oidc` | `dev` (accepts `Bearer dev:<email>`) is allowed **only** with `AIG_ENV=local` |
| `AIG_PUBLIC_BASE_URL` | none | Public `https://` URL of this service, returned as `llm.base_url` in `/api/v1/session`. **Required** in `dev`, `stage` and `prod` (startup fails if it is missing, a `__PLACEHOLDER__` or not https). Only `local` falls back to the request URL |
| `FORWARDED_ALLOW_IPS` | `127.0.0.1` | Docker image only: comma-separated IPs/CIDRs of the reverse proxies whose `X-Forwarded-*` headers uvicorn trusts. Set it to your load balancer or ingress range, never `*` |
| `AIG_CONFIG_DIR` / `AIG_SECRETS_DIR` | `./config` / `./secrets` | Config and secret file locations |
| `AIG_USERS_FILE` / `AIG_AGENTS_FILE` | `config/users.yaml` / `config/agents.yaml` | User directory and agent registry (the `*.example.yaml` files are read only in `local`) |
| `AIG_UPSTREAM_TIMEOUT_SECONDS` | `120` | Portkey request timeout (504 when exceeded) |
| `AIG_WS_USAGE_INTERVAL` | `15` | Seconds between WebSocket `usage` pushes (minimum 5; smaller values are raised to 5) |
| `AIG_WS_PING_INTERVAL_SECONDS` | `25` | Seconds between server keepalive `{"type":"ping"}` frames on the WebSocket |
| `AIG_FIDDLER_AUTOPROVISION` | `false` | Phase 3: create the agent's Fiddler application, trust scores and monitors right after `POST /api/v1/agents` (hook `aig_fiddler.hooks:on_agent_registered` from `backend/observability/tool`; needs that package and `FIDDLER_API_KEY`). If set but the package is missing, startup fails outside `local` |
| `AIG_AGENT_HOOKS` | none | Extra agent-registered hooks, comma-separated `module:function` |
| `AIG_DATABASE_URL` | local: `sqlite:///.run/platform.db` | Database URL; **required** Postgres (`postgresql+psycopg://...`) in `dev`, `stage`, `prod` |
| `AIG_DB_AUTO_MIGRATE` | `true` in local, else `false` | Run Alembic migrations at startup (otherwise the schema must be at head) |
| `AIG_MIGRATIONS_DIR` | `./migrations` | Alembic scripts (the image sets `/app/migrations`) |
| `AIG_MCP_SYNC` | `false` | Push approved MCP servers to the Portkey MCP gateway |
| `AIG_PORTKEY_ADMIN_URL` | env `portkey_admin_api_url` | Portkey admin API base for the MCP sync |
| `AIG_TELEMETRY_BRIDGE_URL` | none | telemetry-bridge base URL; IDE usage events go to `{url}/ingest/ide-usage` (needs `TELEMETRY_BRIDGE_TOKEN`) |
| `AIG_TELEMETRY_BRIDGE_TIMEOUT_SECONDS` | `5` | Timeout of one usage-event post (fire-and-forget) |
| `AIG_ROUTING_CONFIG_FILE` | none | Rendered Portkey config for `GET /api/v1/routing` (`aigw render --env <env> --kind configs > file`) |

### Registry v2 and agent invocation

Register, discover and invoke agents that run on servers (Bedrock AgentCore or any HTTPS endpoint).
Wire protocol: [`backend/contracts/agent-invocation.md`](../contracts/agent-invocation.md)
(`aig-http/1`); record shapes: `backend/contracts/agent-record.schema.json`. Migration
`0003_agent_registry_v2` adds the columns and tables.

- **Lifecycle** `draft -> active -> deprecated -> retired` (`retired` is final; `deprecated -> active`
  allowed), orthogonal to the gateway `status` (`active|suspended`), which SDK `init()` / `aig doctor`
  keep reading. New agents are `draft`; built-ins are `active`. Activation needs a verified version.
  Gateway (agent-check): `retired` denied (`agent_retired`); `draft` allowed only when platform-api
  runs in `local` or `dev` (`agent_draft` elsewhere), so developers can run an agent before its first
  deploy; `deprecated` allowed; `suspended` denied as before.
- **Versions** per environment (`local` only in `AIG_ENV=local`, `dev`, `stage`, `prod`): kind
  `agentcore` (runtime ARN + qualifier; registered by the deploy pipeline with the service token,
  invoked with platform-api's IAM role) or `https` (endpoint; https only, `http://localhost` in local;
  owner/admin may register). `auth` holds a Secrets Manager ARN (`local:<NAME>` in local), never a
  value. The deploy pipeline may pass `verified: true` (its smoke test) and `activate: true` (prod).
- **Verification** (`.../verify`): `GET /ping` (https), a test invocation through the invoker, the
  gateway agent-check saw the agent within `AIG_AGENT_VERIFY_SEEN_WINDOW_SECONDS`, and the pluggable
  trace check `AIG_AGENT_TRACE_CHECK` (not configured = `not_configured`, failing when
  `AIG_AGENT_VERIFY_REQUIRE_TRACE`, default true outside local/dev). A passing prod verification
  activates a draft (unless `activate: false`).
- **Access**: owner and owner's team always; `visibility: groups` adds `allowed_groups` (Entra
  `groups` token claim; in local dev auth `users.yaml` `groups`); `visibility: org` adds everyone
  once an admin approves (`org_approval`). Admins get no invoke bypass. Users invoke `prod`
  (verified versions only); owner/team may pick `dev`/`stage`/`local`, verified or not; drafts never
  run in prod.
- **Invocation** (`invoker.py`): access, lifecycle, version selection, jsonschema input validation,
  ES256 caller token (`AGENT_CALLER_SIGNING_KEY`; public keys at `/api/v1/caller-token/jwks`),
  `HttpsInvoker` (httpx, SSE parsing, api-key / OAuth client-credentials from Secrets Manager) and
  `AgentCoreInvoker` (boto3 `bedrock-agentcore` `invoke_agent_runtime`; contract headers as
  `X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-*` plus the `aig_context` body mirror; caller-scoped
  `runtimeSessionId`). Limits: sync 120 s, stream 900 s, background 3600 s. Background runs are
  app-level tasks (survive the client), output stored Fernet-encrypted (`AGENT_OUTPUT_ENCRYPTION_KEY`,
  30 days); records keep metadata only (90 days); a restart marks open background runs cancelled.
  Platform secrets and resolved agent credentials are redacted from every response, event and frame;
  inputs, outputs, tokens and credentials are never logged. Every registry change (register, update,
  version registration/retirement, lifecycle, suspend/reinstate), access change, org-wide approval or
  rejection, verification, invocation (`agent.invoke`) and cancellation is audited
  (`GET /api/v1/audit?entity_type=agent` / `entity_type=invocation`, an alias of `agent_invocation`).
- **Observability (W7)**: when a record closes, a metadata-only invocation event
  (`backend/contracts/invocation-event.schema.json`: agent, version, env, mode, purpose, status, error
  code, duration, tokens, trace id, caller user/team/tier, session id) is posted fire-and-forget to
  `{AIG_TELEMETRY_BRIDGE_URL}/ingest/invocation` (`TELEMETRY_BRIDGE_TOKEN`), like IDE usage events; the
  bridge forwards it to the agent's Fiddler application joined to its traces. Never inputs, outputs
  or caller tokens. `GET /api/v1/invocations/summary?since=&until=&env=` (service token or admin)
  gives per agent/version/env counts for the bridge's reconciliation (versions with invocations but
  no Fiddler traces).
- **Retention**: `aig-platform-api invocations purge` deletes closed invocation records older than
  `AIG_AGENT_INVOCATION_RETENTION_DAYS` (90) and clears background outputs older than
  `AIG_AGENT_OUTPUT_RETENTION_DAYS` (30), also for rows written under longer settings; open runs are
  kept; `--dry-run` only counts; prints one JSON line of counts. Terraform runs it daily
  (`modules/platform-services`, `invocation_purge_*`). The API also purges opportunistically (at most
  hourly) on new invocations.
- **Fail closed**: outside `local`, without `AGENT_CALLER_SIGNING_KEY` invocation answers 503
  `agent_invocation_disabled` (`AIG_AGENT_INVOCATION=true` then stops startup); a malformed key stops
  startup; background runs need `AGENT_OUTPUT_ENCRYPTION_KEY`.

WebSocket frames (same checks as HTTP): client `agent.invoke {id, agent_id, env?, version?, input |
messages, session_id?, background?}` and `agent.cancel {id}` (foreground) or `{invocation_id}`
(own background run); server `agent.invocation.status {id?, invocation_id, agent_id, version, env,
mode, status, duration_ms?, usage?, error_code?}`, `agent.delta {id, invocation_id, text}`,
`agent.output {id, invocation_id, output, usage?, trace_id}`, `agent.error {id, invocation_id?, code,
message}`, `agent.done {id, invocation_id, status, duration_ms}`. Chats and foreground agent runs
share the 4-per-socket limit; closing the socket cancels foreground runs; background runs push
status to every socket of the caller.

## Deploying to AWS (Phase 5)

`infra/terraform/modules/platform-services` runs this image on ECS Fargate (ARM64) behind an HTTPS
ALB. It sets:
- `AIG_SECRET_PROVIDER=aws` (the task role may read only `aig/<env>/platform-api`)
- `AIG_PUBLIC_BASE_URL=https://<api host>`
- `FORWARDED_ALLOW_IPS` = the ALB subnet CIDRs
- `AIG_DB_AUTO_MIGRATE=false`
- `AIG_DATABASE_URL`, built at start from the RDS-managed master secret

`config/environments/<env>.yaml` is written into the task from Terraform, so one image digest runs
in every env. `.github/workflows/deploy-platform.yml` runs `aig-platform-api db upgrade` as a
one-off ECS task before each rollout. The secret values are uploaded by hand: see
[docs/deploy.md](../../docs/deploy.md).

## Run

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[dev]'

# local, with dev auth and no real key (proxy returns 503 until you add one)
AIG_ENV=local AIG_AUTH_MODE=dev .venv/bin/uvicorn platform_api.main:create_app --factory --port 8080
curl localhost:8080/healthz
curl -H 'Authorization: Bearer dev:jane.doe@example.com' localhost:8080/api/v1/session

# tests
.venv/bin/pytest

# regenerate the OpenAPI contract after changing routes or schemas
.venv/bin/python scripts/export-openapi.py
```

Docker:

```bash
docker build -t aig-platform-api .
docker run -p 8080:8080 -e AIG_ENV=dev -e AIG_PUBLIC_BASE_URL=https://aig-api-dev.example.com \
  -e FORWARDED_ALLOW_IPS=10.0.0.0/8 -v "$PWD/secrets/.env.dev:/app/secrets/.env.dev:ro" aig-platform-api
```

## API (port 8080)

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/healthz` | none | `{"status","env","secrets":{NAME: configured\|placeholder\|missing},"database":{"backend","status"}}` |
| GET | `/api/v1/session` | Bearer | User, team, env, tier, allowed job profiles, LLM base URL and config id, Fiddler URL, `roles`, `preferences` (`{"theme"}`), `links` (`portkey_url`, `fiddler_url`; `null` when unset). No keys. |
| GET, PUT | `/api/v1/me/preferences` | Bearer (user) | `{"theme": "system"\|"light"\|"dark"}`, stored per user |
| POST | `/api/v1/llm/chat/completions` | Bearer | OpenAI-compatible proxy to Portkey, with SSE streaming when `"stream": true` |
| GET | `/api/v1/usage/me` | Bearer | Token and cost usage from Portkey analytics; `501 usage_not_configured` without an admin key |
| GET | `/api/v1/usage/dashboard?days=7\|30\|90` | Bearer | Tokenomics for the VS Code dashboard: active user count and token usage per model (see below) |
| GET | `/api/v1/usage/by-team?days=7\|30\|90` | Bearer | `{"items":[{team, users, requests, tokens, cost_usd}], "total", "env", "window", "source"}` from Portkey analytics grouped by metadata `team`; `501 usage_not_configured` without the admin key (never sample data) |
| GET (WebSocket) | `/api/v1/ws` | Bearer (upgrade header, or the `aig.bearer` subprotocol for browsers) | Chat streaming, live usage pushes and keepalive over one socket (see "WebSocket" below) |

> **Browser token encoding:** subprotocol values may only contain RFC 7230 token characters, so browsers send the bearer token as `b64u.<base64url, no padding>` in the second subprotocol entry (e.g. `["aig.bearer", "b64u.ZGV2Omphbm..."]`). platform-api decodes it; a raw token is still accepted for non-browser clients. This lets the local `dev:<email>` token use the WebSocket too.
| POST | `/api/v1/guardrails/agent-check` | `x-aig-webhook-secret` (shared secret) | Portkey webhook guardrail: registered-agent check (see below) |
| GET | `/api/v1/agents?team=&status=&q=` | Bearer or service token | `{"items", "total", "agents"}` (`agents` = `items`, kept for telemetry-bridge / fiddler-sync) |
| GET | `/api/v1/agents/{id}` | Bearer or service token | `{"agent": {...}}` |
| POST | `/api/v1/agents` | Bearer or service token | `{agent_id, name?, description?, team?, owner?, lifecycle?, tags?, docs_url?, data_classification?}` (new agents are `lifecycle: draft`; only admins/service may pass `active`); `201 {"agent", "hooks"}`, `409 agent_exists`. Users register for themselves and their team (body owner/team ignored); admins may set both (default: caller); the service token must give both. `name` defaults to `agent_id`. Runs the agent-registered hooks in the background |
| PATCH | `/api/v1/agents/{id}` | owner or admin | `{name?, description?, owner?}` -> `{"agent"}` (built-in agents: admin only) |
| POST | `/api/v1/agents/{id}/suspend` | admin or service token | `{reason, source?, evidence?}`; marks the agent `suspended` (the agent-check webhook then denies it). Idempotent (`changed: false`). Called by telemetry-bridge's daily reconciliation |
| POST | `/api/v1/agents/{id}/reinstate` | admin or service token | Same body; back to `active` |
| GET | `/api/v1/agents/{id}/versions?env=` | service, admin, owner/team, or a user allowed to run the agent | `{"items","total"}` per-environment versions (registry v2) |
| POST | `/api/v1/agents/{id}/versions` | service token (any kind) or owner/admin (kind `https` only) | `{version, env, kind, endpoint? \| runtime_arn?+qualifier?, input_schema?, output_schema?, auth:{type, secret_arn?}, git_sha?, image_digest?, verified?, activate?}` -> `201` (new) / `200` (same env+version replaced; verification reset). `verified`/`activate` service only (`activate` = prod + verified) |
| POST | `/api/v1/agents/{id}/versions/{version}/verify?env=` | owner, admin or service | `{input? \| messages?, activate?}` -> `{passed, code, checks[health,invocation,gateway,trace], invocation_id, trace_id, activated, version}` |
| POST | `/api/v1/agents/{id}/versions/{version}/retire?env=` | owner, admin or service | Version -> `retired` |
| POST | `/api/v1/agents/{id}/lifecycle` | owner or admin | `{to, reason?}`; `409 invalid_transition` / `verification_required` |
| PUT | `/api/v1/agents/{id}/access` | owner or admin | `{visibility: team\|groups\|org, allowed_groups[]}`; `org` -> `org_approval: pending` |
| POST | `/api/v1/agents/{id}/access/approve`, `/reject` | admin | `{reason?}`; only from `pending` |
| GET | `/api/v1/catalog?q=&team=&tag=` | Bearer (user) | `{"items":[{agent, versions[], default, access}], "total", "teams", "tags"}`: only agents the caller may invoke |
| POST | `/api/v1/agents/{id}/invoke?env=&version=&mode=sync\|stream\|background` | Bearer (user) | Body `{input \| messages, session_id?, stream?}`. sync `200 {invocation_id, agent_id, version, env, status, output, usage, trace_id, duration_ms}`; stream `200 text/event-stream` (`delta`/`output`/`error`/`done`); background `202 {invocation_id, status: queued, location}` + `Location` |
| GET | `/api/v1/invocations?agent_id=&mine=1&status=&limit=` | Bearer (user) | Own runs + runs of agents the caller owns (admins: all) |
| GET | `/api/v1/invocations/{id}` | caller, agent owner or admin | Record; `output` (background runs) only for the caller and the owner |
| POST | `/api/v1/invocations/{id}/cancel` | caller, agent owner or admin | `409 invocation_finished` once final |
| GET | `/api/v1/caller-token/jwks` | none | Public ES256 keys agents use to verify `x-aig-caller` |
| GET | `/api/v1/mcp-servers?status=` | Bearer or service token | MCP registry (`{"items","total"}`) |
| POST | `/api/v1/mcp-servers` | Bearer (any user) | `{name, url, description, iam_roles[], workspaces[]}` -> `201`, status `pending`; `409 mcp_server_exists` |
| POST | `/api/v1/mcp-servers/{id}/approve`, `/reject` | admin | `{reason?}` -> `approved` / `rejected` (only from `pending`, else `409 invalid_transition`); approval triggers the Portkey MCP gateway sync |
| GET | `/api/v1/models?status=`, `/api/v1/models/{id}` | Bearer or service token | Model catalog |
| POST | `/api/v1/models` | Bearer (any user) | `{name, provider, version, tiers[], job_profiles[], use_case, data_classification, expected_monthly_cost_usd}` -> `201`, status `requested`; `409 model_exists` |
| POST | `/api/v1/models/{id}/transition` | approver / admin / service (see below) | `{to, note?, canary_share?}` |
| PUT | `/api/v1/models/{id}/scorecard` | admin or service token | `{accuracy, faithfulness, safety_critical_failures, latency_p95_ms, cost_per_1k_usd, baseline:{...}, passed, evidence_url?}` |
| GET | `/api/v1/audit?entity_type=&entity_id=&limit=` (`entity_type=invocation` = `agent_invocation`) | admin or approver | `{"items":[{id, at, actor, action, entity_type, entity_id, details}], "total"}`, newest first (limit 1-1000, default 100) |
| GET | `/api/v1/workspaces?status=` | Bearer (own; admin all) or service token (all) | Team workspace requests |
| POST | `/api/v1/workspaces` | Bearer (any user) | `{repo_url, work_item, title, description?, job_profile?}` -> `201`, status `queued` |
| GET | `/api/v1/workspaces/{id}` | requester, admin or service | `404 workspace_not_found` for other users' workspaces |
| POST | `/api/v1/workspaces/{id}/cancel` | requester, admin or service | -> `cancelled` (`409 invalid_transition` once final) |
| POST | `/api/v1/workspaces/{id}/claim` | service token only (the orchestrator) | `{worker?}`; atomic `queued -> provisioning` (one conditional `UPDATE`), so concurrent orchestrator workers never start the same request twice; `409 invalid_transition` when it is no longer `queued` (already claimed or cancelled) |
| PATCH | `/api/v1/workspaces/{id}/status` | service token only (the orchestrator) | `{status, pr_url?, log_url?, error?}`; statuses `queued`, `provisioning`, `running`, `testing`, `pr_opened`, `completed`, `failed`, `cancelled` (the last three are final) |
| GET | `/api/v1/evals?agent_id=&limit=` | Bearer or service token | Eval runs, newest first (limit 1-500, default 50) |
| POST | `/api/v1/evals` | service token only (the evals gate) | `{agent_id, dataset, experiment_id, scores:{name:number}, baseline_scores:{...}, passed, fiddler_url?, git_sha?, pr?}` -> `201` with `id`, `created_at` |
| GET | `/api/v1/routing` | Bearer | `{"env", "config_id", "config"}`: the rendered `pc-aig-router` from `AIG_ROUTING_CONFIG_FILE`; `404 routing_not_available` without it |
| GET/POST | `/auth/local/signin` | none | Local-only browser sign-in page for the VS Code extension and the web portal; 404 unless `AIG_ENV=local` and `AIG_AUTH_MODE=dev` |

All JSON. Lists return `{"items": [...], "total": n}`; timestamps are ISO-8601 UTC. Request
validation errors are `400 invalid_request` (`invalid_json` for unparseable bodies), never 422.
The full machine-readable spec is `backend/contracts/platform-api.openapi.json` (regenerate with
`scripts/export-openapi.py`; `tests/test_openapi_contract.py` fails when it is stale). Every change to
agents, MCP servers, models, workspaces and evals is written to the audit log in the same
transaction.

Agent object: `{agent_id, name, description, team, owner, status, builtin, created_at, updated_at,
last_seen_at, hosts_seen[], fiddler_application_id, links: {fiddler, portkey}, shared, status_reason,
status_changed_at, lifecycle, lifecycle_changed_at, tags[], docs_url, data_classification, visibility,
allowed_groups[], org_approval, org_approval_by, org_approval_at}` (`backend/contracts/agent-record.schema.json`).

### Model lifecycle (`/api/v1/models/{id}/transition`)

`requested -> sandbox -> evaluating -> approved | rejected`, `approved -> canary -> promoted |
rolled_back`. Anything else is `409 invalid_transition`. `approved`, `rejected`, `promoted` and
`rolled_back` need the `approver` role (they record `decided_by`/`decided_at`); `sandbox`,
`evaluating` and `canary` need `admin` or the service token. `to=canary` sets `canary_share`
(0-100, default 10) and `canary_started_at`; `promoted` sets the share to 100 and `rolled_back` to 0.
Each transition's audit entry carries the note and the scorecard's `passed` / `evidence_url`.

### MCP registry sync (`AIG_MCP_SYNC=true`)

On approval the server is upserted into the Portkey MCP gateway through the admin API:
`POST {AIG_PORTKEY_ADMIN_URL or portkey_admin_api_url}{portkey_mcp_servers_path}` with the same
shape `aigw` renders (`slug`, `name`, `url`, `transport`, `workspace_ids`, `access.iam_roles`,
`access.unregistered: deny`), then `PUT .../{slug}` when it already exists (409). The outcome is
stored on the object (`sync_status`: `not_synced`, `disabled`, `synced`, `failed`; `sync_error`) and
audit-logged; a failure never fails the approval. Paths are unverified against the self-hosted
Portkey (see `backend/gateway/README.md`).

### IDE usage forwarding (telemetry bridge)

After every completed chat that reports token usage (HTTP proxy, streamed or not, and WebSocket
`chat.done`), platform-api posts one event per `backend/contracts/ide-usage-event.schema.json` to
`{AIG_TELEMETRY_BRIDGE_URL}/ingest/ide-usage` with `Authorization: Bearer <TELEMETRY_BRIDGE_TOKEN>`:
source/host, agent, team, tier, env, job profile, user, model, token counts, latency, cache status
and the Portkey trace id. **Never prompt or reply text.** It is fire-and-forget (background task,
`AIG_TELEMETRY_BRIDGE_TIMEOUT_SECONDS`), so it never blocks or fails the chat; values outside the
contract are dropped (and an event that cannot be valid is not sent). Disabled without the URL or
the token. Requests that carry an `Origin` header (the web portal) are sent as host `web` with the
pre-registered agent `web.portal`.

### Agent registry API and hooks (`/api/v1/agents`, Phases 3 and 4)

- Registry changes go through `MutableAgentRegistry.register` / `set_status` (plus `update`,
  `touch` and `set_fiddler_application_id` on the database registry). The database registry commits
  each change; the YAML registry (tests/tools) applies them in memory and writes them back
  atomically to its file (never to `agents.example.yaml`).
- Errors: `400 invalid_agent_id|invalid_agent|invalid_request|invalid_json`, `401 unauthenticated`
  (user token) / `service_unauthenticated`, `403 forbidden`, `404 agent_not_found`, `409 agent_exists`,
  `501 registry_read_only`, `503 service_token_not_configured` (see `backend/contracts/errors.md`).
- Hooks (`src/platform_api/agent_hooks.py`): with `AIG_FIDDLER_AUTOPROVISION=true` a
  registration calls `aig_fiddler.hooks:on_agent_registered(agent, env=..., fiddler_url=...,
  fiddler_api_key=...)` after the response; a failing hook is logged (exception type only) and
  never undoes the registration. If a hook returns `fiddler_application_id` (or `application_id`), it is
  stored on the agent and used for `links.fiddler`. Install the hook package with
  `pip install -e ../observability/tool` (or into the image) and set `AIG_FIDDLER_ROOT`
  when not running from a repo checkout.

### Agent-check webhook (`POST /api/v1/guardrails/agent-check`)

Called by Portkey's `aig-agent-check` input guardrail (`backend/gateway/manifests/guardrails.yaml`)
before every model call.

- Auth: header `x-aig-webhook-secret` must equal `PORTKEY_WEBHOOK_SECRET` (constant-time compare,
  else `401 webhook_unauthenticated`). Outside `local`, a missing/placeholder secret gives
  `503 webhook_not_configured` (the guardrail's `failOnError` then denies the call). In `local`
  without a secret the call is accepted with a warning.
- Request: Portkey's webhook payload (`request`, `response`, `provider`, `requestType`,
  `metadata`, `eventType`). `metadata` is the request's `x-portkey-metadata` (an object, a JSON
  string, or under `request.metadata`). Prompts and replies are never read or logged.
- Response (always 200 once authenticated): `{"verdict": true|false, "data": {"reason", ...}}`.
  Reasons: `agent_active` (allowed), `metadata_missing`, `required_metadata_missing` (`data.missing`),
  `invalid_agent_id`, `agent_unregistered`, `agent_suspended`, `team_mismatch` (a non-shared
  agent used with another team's metadata), `invalid_payload`, `internal_error`. Fail-closed:
  anything unexpected is `verdict: false`.
- Shared cases: `backend/gateway/simulation/agent-check-cases.json` (`tests/test_agent_check_cases.py`).

### Tokenomics dashboard

- Calls Portkey `GET {portkey_admin_api_url}/analytics/groups/users` and `/analytics/groups/models`
  with `PORTKEY_ADMIN_API_KEY` (server-side only), paging up to 20 pages of 100 rows.
- Returns `totals` (`users`, `requests`, `tokens`, `prompt_tokens`, `completion_tokens`, `cost_usd`) and
  `models[]` (same fields plus `share`), sorted by tokens. It returns a user **count**, never per-user rows.
- Cached for 10 seconds per range (only to absorb bursts); pushed over the WebSocket every 15 seconds. Field names are read defensively (`total_tokens`/`tokens`,
  `prompt_tokens`/`req_units`, ...). Portkey cost is converted to USD using `portkey_cost_unit`
  (`cents` by default) in the environment YAML. **Verify both against your self-hosted Portkey version.**
- There is **no sample-data mode**: usage is always live from Portkey analytics. Without `PORTKEY_ADMIN_API_KEY` the
  endpoint returns `501 usage_not_configured`, and the VS Code views show that message instead of numbers.

### WebSocket (`/api/v1/ws`)

One socket per VS Code window or browser tab. The Node `ws` client sends `Authorization: Bearer
<token>` on the upgrade request. Browsers cannot set headers on a WebSocket, so the web portal offers
the subprotocols `["aig.bearer", "<token>"]` (`Sec-WebSocket-Protocol`) instead; the server reads the
token from the second entry and selects **only** `aig.bearer` (the token is never echoed, and the
header is never logged). Either way the token is checked with the same authenticator as the HTTP
API (`dev:<email>` only with `AIG_ENV=local` + `AIG_AUTH_MODE=dev`, Entra ID JWTs everywhere else).
The `Authorization` header wins when both are present. The token is never sent in the URL.

Handshake: the server always **accepts** the upgrade (selecting `aig.bearer` when it was offered
first), then immediately closes with
- `4403 forbidden_origin` if an `Origin` header is present and not in `cors_allowed_origins` or
  `web_allowed_origins` (VS Code's Node client sends no `Origin`; browsers always do), or
- `4401 unauthenticated` if the bearer token (header or subprotocol) is missing or invalid.

All frames are JSON text frames with a `"type"`. Binary frames, invalid JSON, unknown types and frames
over 64 KiB get `{"type":"error","code":"bad_request","message"}`; the socket stays open.

Server to client:

| Frame | When |
|---|---|
| `{"type":"ready","user":{"email","name"},"team","env","user_tier","allowed_job_profiles":[...],"server_time"}` | Right after a successful connect |
| `{"type":"ping"}` | Keepalive every 25 s (`AIG_WS_PING_INTERVAL_SECONDS`). Clients may reply `{"type":"pong"}` (ignored) |
| `{"type":"pong"}` | Reply to a client `ping` |
| `{"type":"chat.delta","id","text"}` | Streamed assistant text |
| `{"type":"chat.done","id","trace_id","usage"?:{"prompt_tokens","completion_tokens","total_tokens"}}` | Chat finished; `usage` when Portkey reports it |
| `{"type":"chat.error","id","code","message","trace_id"?,"status"?}` | Chat failed or was cancelled (codes below) |
| `{"type":"usage","days","data":<body of GET /api/v1/usage/dashboard?days=N>}` | On subscribe, every `AIG_WS_USAGE_INTERVAL` s, and after each `chat.done` on this socket |
| `{"type":"usage.error","code","message"}` | Usage lookup failed (`usage_not_configured`, `usage_upstream_error`, `upstream_timeout`, `upstream_unavailable`, `internal_error`) |
| `{"type":"error","code":"bad_request","message"}` | Malformed frame (see above) |

Client to server:

| Frame | Effect |
|---|---|
| `{"type":"ping"}` | Server replies `{"type":"pong"}` |
| `{"type":"chat","id","messages":[{"role","content"}],"job_profile"?,"agent_id"?,"model"?,"temperature"?,"max_tokens"?}` | Starts a streamed chat. `id` must match `[A-Za-z0-9_-]{1,64}` (otherwise `error`/`bad_request`). `role` is one of `system`, `user`, `assistant`, `tool`, `developer`; `content` is a string or an array of parts. `temperature` 0-2, `max_tokens` >= 1. Any other fields are ignored |
| `{"type":"cancel","id"}` | Cancels that chat; server sends `chat.error` with `code:"cancelled"`. Unknown id: `chat.error` `unknown_id` |
| `{"type":"usage.subscribe","days":7\|30\|90}` | Pushes `usage` now and periodically (default `days` 30). Replaces any previous subscription |
| `{"type":"usage.unsubscribe"}` | Stops usage pushes |

Chat uses exactly the same server-side logic as `POST /api/v1/llm/chat/completions`: the Portkey key,
`x-portkey-config`, trace id and `x-portkey-metadata` (tier and team from the user directory,
validated `job_profile`/`agent_id`) are added by the server; nothing the client sends can override
them. The upstream body is built from the allowed fields only, with `"stream": true` and
`"stream_options": {"include_usage": true}`. Text deltas are scanned for secret values (a key split
across deltas is still caught) and every outbound frame is redacted before sending.

`chat.error` codes: `bad_request`, `duplicate_id` (that id is still running), `too_many_requests`
(more than 4 concurrent chats on one socket), `invalid_job_profile`, `invalid_agent_id`,
`portkey_key_not_configured`, `portkey_gateway_not_configured`, `upstream_error` (with `status`, the
upstream HTTP status), `upstream_timeout`, `upstream_unavailable` (gateway unreachable),
`upstream_interrupted` (stream broke mid-way), `cancelled`, `unknown_id`, `internal_error`.
Partial text already received is flushed as `chat.delta` before a mid-stream error.

`usage` data is the dashboard body itself (same 10 s cache); it contains a
user count, never per-user rows. On disconnect all chat, usage and keepalive tasks are cancelled and
upstream streams are closed.

### Local browser sign-in (no SSO)

Only when `AIG_ENV=local` and `AIG_AUTH_MODE=dev`. The extension opens
`/auth/local/signin?redirect_uri=vscode://aig.aig-ai-ecosystem/auth-callback&state=<nonce>`. The user enters an
email; the response sends the browser back to `<redirect_uri>?email=...&state=...`. Only this extension's
callback URI is accepted (schemes `vscode`, `vscode-insiders`, `vscodium`), or, for the web portal,
exactly `<origin>/auth/callback` where `<origin>` (scheme, host and port) is listed in the environment's
`web_allowed_origins` (local: `http://localhost:3000`), or, for native IDE clients such as the Eclipse
plugin, an RFC 8252 loopback redirect `http://127.0.0.1:<port>/auth/callback` or
`http://[::1]:<port>/auth/callback` (IP literals only, plain http, explicit port, any port; `localhost` is
not accepted because a hosts file can re-point it), so it cannot be used as an open redirect. The extension rejects any state it did not issue. The resulting `dev:<email>` token works only on a
local dev-mode backend.

### LLM proxy details

- Client headers it accepts: `x-aig-job-profile` (must be one of `allowed_job_profiles`,
  default `general`, otherwise 400), `x-aig-agent-id` (optional, `[A-Za-z0-9._-]{1,64}`;
  when absent the server sends `ide.vscode`),
  `x-aig-trace-id` (optional; a new UUID is generated if it is missing or invalid).
- Outbound headers are built from an allow-list. Client `x-portkey-*` and
  `Authorization` headers are never forwarded.
- The server sends `x-portkey-api-key`, `x-portkey-config`, `x-portkey-trace-id` and
  `x-portkey-metadata` (`user_tier`, `job_profile`, `agent_id`, `team`, `env`,
  `host="vscode"`, `user`, plus Portkey's reserved `_user`). `user_tier` and `team` come
  from the server-side user directory, never from the client. The metadata is encoded as
  canonical JSON (compact, keys sorted) and must validate against
  `backend/contracts/metadata.schema.json`; `tests/test_contracts.py` checks this against the golden
  fixtures in `backend/contracts/fixtures/`.
- Upstream errors are relayed with their status code. A timeout gives 504 and a
  connection failure gives 502. The response header `x-aig-trace-id` echoes the trace id.
- The request body is forwarded unchanged.
- Responses are scanned for configured secret values and redacted. For streams, the
  proxy holds back the last (longest secret length - 1) bytes of each chunk until the
  next chunk arrives, so a key split across chunks is still caught. The held bytes are
  flushed at the end of the stream and before any mid-stream error event.

Errors use `{"error": {"code": "...", "message": "..."}}`.

## Model harness (Phase 7)

See [`docs/model-harness.md`](../../docs/model-harness.md). In platform-api:

- `src/platform_api/model_harness.py`: on `requested -> sandbox` (with `AIG_MODEL_SANDBOX_SYNC=true`)
  creates the sandbox-only Portkey provider `aig-sbx-<id8>` in `model-sandbox`
  (`POST {admin}{portkey_sandbox_providers_path}`, referencing the sandbox integration; no provider
  key passes through); on `-> canary | promoted | rolled_back` (with `AIG_CANARY_DISPATCH=true`)
  sends the GitHub `repository_dispatch`. Outcomes are stored on the model
  (`sandbox_key_status`, `sandbox_key_id`, `sandbox_error`, `canary_dispatch_status`,
  `canary_dispatch_error`) and audit-logged; neither ever blocks or fails the transition.
- `src/platform_api/model_gate.py` + `config/model-gate-thresholds.yaml`
  (`AIG_MODEL_GATE_THRESHOLDS_FILE`): the gate is evaluated on every scorecard write (`gate`,
  `ready_for_approval`) and again on approve; a failing gate is `409 approval_gate_failed` for
  everyone. Approve / reject audit entries carry the scorecard snapshot and the gate result.
- Scorecards from `--offline` runs (`offline_scorecard_refused`) or with datasets not classified
  `synthetic` / `masked` (`dataset_classification_refused`) are refused.
- `PUT /api/v1/models/{id}/canary-pr` (admin / service): the model-canary workflow records its PR.
- Migration `0002_model_harness` adds the columns above plus `canary_pr_url` and `gate`.
