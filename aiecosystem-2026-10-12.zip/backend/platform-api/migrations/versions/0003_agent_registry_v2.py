"""Agent registry v2: lifecycle, catalog metadata and access on agents; agent_versions; agent_invocations.

Existing agents get lifecycle ``active`` (they were usable before v2), visibility ``team``, no
groups and org approval ``none`` through server defaults, so the upgrade is safe on a populated
database (SQLite via batch mode, Postgres natively).

Revision ID: 0003_agent_registry_v2
Revises: 0002_model_harness
Create Date: 2026-10-09
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0003_agent_registry_v2"
down_revision = "0002_model_harness"
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def _agent_columns() -> tuple[sa.Column, ...]:
    return (
        sa.Column("lifecycle", sa.String(16), nullable=False, server_default="active"),
        sa.Column("lifecycle_changed_at", TS, nullable=True),
        sa.Column("tags", sa.JSON(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("docs_url", sa.String(2048), nullable=True),
        sa.Column("data_classification", sa.String(16), nullable=True),
        sa.Column("visibility", sa.String(16), nullable=False, server_default="team"),
        sa.Column("allowed_groups", sa.JSON(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("org_approval", sa.String(16), nullable=False, server_default="none"),
        sa.Column("org_approval_by", sa.String(254), nullable=True),
        sa.Column("org_approval_at", TS, nullable=True),
    )


def upgrade() -> None:
    with op.batch_alter_table("agents") as batch:
        for column in _agent_columns():
            batch.add_column(column)
        batch.create_index("ix_agents_lifecycle", ["lifecycle"])

    op.create_table(
        "agent_versions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("agent_id", sa.String(64), sa.ForeignKey("agents.agent_id"), nullable=False),
        sa.Column("version", sa.String(128), nullable=False),
        sa.Column("env", sa.String(8), nullable=False),
        sa.Column("kind", sa.String(16), nullable=False),
        sa.Column("endpoint", sa.String(2048), nullable=True),
        sa.Column("runtime_arn", sa.String(2048), nullable=True),
        sa.Column("qualifier", sa.String(128), nullable=True),
        sa.Column("protocol", sa.String(32), nullable=False),
        sa.Column("input_schema", sa.JSON(), nullable=True),
        sa.Column("output_schema", sa.JSON(), nullable=True),
        sa.Column("auth", sa.JSON(), nullable=False),
        sa.Column("git_sha", sa.String(64), nullable=True),
        sa.Column("image_digest", sa.String(128), nullable=True),
        sa.Column("verified_at", TS, nullable=True),
        sa.Column("verification_status", sa.String(16), nullable=False),
        sa.Column("verification", sa.JSON(), nullable=True),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("created_by", sa.String(254), nullable=False),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("updated_at", TS, nullable=False),
        sa.UniqueConstraint("agent_id", "env", "version", name="uq_agent_versions_agent_env_version"),
    )
    op.create_index("ix_agent_versions_agent_id", "agent_versions", ["agent_id"])
    op.create_index("ix_agent_versions_status", "agent_versions", ["status"])

    op.create_table(
        "agent_invocations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("agent_id", sa.String(64), nullable=False),
        sa.Column("version", sa.String(128), nullable=False),
        sa.Column("env", sa.String(8), nullable=False),
        sa.Column("caller", sa.String(254), nullable=False),
        sa.Column("team", sa.String(64), nullable=False),
        sa.Column("mode", sa.String(16), nullable=False),
        sa.Column("purpose", sa.String(16), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("session_id", sa.String(128), nullable=True),
        sa.Column("trace_id", sa.String(128), nullable=False),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("started_at", TS, nullable=True),
        sa.Column("finished_at", TS, nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column("prompt_tokens", sa.Integer(), nullable=True),
        sa.Column("completion_tokens", sa.Integer(), nullable=True),
        sa.Column("total_tokens", sa.Integer(), nullable=True),
        sa.Column("error_code", sa.String(64), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("output_encrypted", sa.Text(), nullable=True),
        sa.Column("output_expires_at", TS, nullable=True),
        sa.Column("retain_until", TS, nullable=False),
    )
    op.create_index("ix_agent_invocations_agent_id", "agent_invocations", ["agent_id"])
    op.create_index("ix_agent_invocations_caller", "agent_invocations", ["caller"])
    op.create_index("ix_agent_invocations_status", "agent_invocations", ["status"])
    op.create_index("ix_agent_invocations_created_at", "agent_invocations", ["created_at"])
    op.create_index("ix_agent_invocations_retain_until", "agent_invocations", ["retain_until"])
    op.create_index("ix_agent_invocations_agent_created", "agent_invocations", ["agent_id", "created_at"])


def downgrade() -> None:
    op.drop_table("agent_invocations")
    op.drop_table("agent_versions")
    with op.batch_alter_table("agents") as batch:
        batch.drop_index("ix_agents_lifecycle")
        for column in reversed(_agent_columns()):
            batch.drop_column(column.name)
