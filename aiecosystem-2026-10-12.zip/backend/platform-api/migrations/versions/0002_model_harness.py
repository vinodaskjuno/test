"""Phase 7 model harness: sandbox key, canary dispatch / PR and approval-gate result on models.

Revision ID: 0002_model_harness
Revises: 0001_initial
Create Date: 2026-10-09
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0002_model_harness"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

COLUMNS = (
    ("sandbox_key_status", sa.String(16)),
    ("sandbox_key_id", sa.String(128)),
    ("sandbox_error", sa.Text()),
    ("canary_dispatch_status", sa.String(16)),
    ("canary_dispatch_error", sa.Text()),
    ("canary_pr_url", sa.String(2048)),
    ("gate", sa.JSON()),
)


def upgrade() -> None:
    with op.batch_alter_table("models") as batch:
        for name, type_ in COLUMNS:
            batch.add_column(sa.Column(name, type_, nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("models") as batch:
        for name, _ in reversed(COLUMNS):
            batch.drop_column(name)
