"""Phase 4 initial schema: agents, preferences, MCP registry, model catalog, audit log, workspaces, evals.

Revision ID: 0001_initial
Revises:
Create Date: 2026-10-09
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        "agents",
        sa.Column("agent_id", sa.String(64), primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("team", sa.String(64), nullable=False),
        sa.Column("owner", sa.String(254), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("shared", sa.Boolean(), nullable=False),
        sa.Column("builtin", sa.Boolean(), nullable=False),
        sa.Column("status_reason", sa.Text(), nullable=False),
        sa.Column("status_changed_at", TS, nullable=True),
        sa.Column("fiddler_application_id", sa.String(128), nullable=True),
        sa.Column("last_seen_at", TS, nullable=True),
        sa.Column("hosts_seen", sa.JSON(), nullable=False),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("updated_at", TS, nullable=False),
    )
    op.create_index("ix_agents_team", "agents", ["team"])
    op.create_index("ix_agents_owner", "agents", ["owner"])
    op.create_index("ix_agents_status", "agents", ["status"])

    op.create_table(
        "user_preferences",
        sa.Column("email", sa.String(254), primary_key=True),
        sa.Column("theme", sa.String(16), nullable=False),
        sa.Column("updated_at", TS, nullable=False),
    )

    op.create_table(
        "mcp_servers",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("url", sa.String(2048), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("iam_roles", sa.JSON(), nullable=False),
        sa.Column("workspaces", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("requested_by", sa.String(254), nullable=False),
        sa.Column("decided_by", sa.String(254), nullable=True),
        sa.Column("decided_at", TS, nullable=True),
        sa.Column("reason", sa.Text(), nullable=True),
        sa.Column("sync_status", sa.String(16), nullable=False),
        sa.Column("sync_error", sa.Text(), nullable=True),
        sa.Column("synced_at", TS, nullable=True),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("updated_at", TS, nullable=False),
    )
    op.create_index("ix_mcp_servers_name", "mcp_servers", ["name"])
    op.create_index("ix_mcp_servers_status", "mcp_servers", ["status"])

    op.create_table(
        "models",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("provider", sa.String(64), nullable=False),
        sa.Column("version", sa.String(64), nullable=False),
        sa.Column("tiers", sa.JSON(), nullable=False),
        sa.Column("job_profiles", sa.JSON(), nullable=False),
        sa.Column("use_case", sa.Text(), nullable=False),
        sa.Column("data_classification", sa.String(16), nullable=False),
        sa.Column("expected_monthly_cost_usd", sa.Float(), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("requested_by", sa.String(254), nullable=False),
        sa.Column("scorecard", sa.JSON(), nullable=True),
        sa.Column("canary_share", sa.Float(), nullable=True),
        sa.Column("canary_started_at", TS, nullable=True),
        sa.Column("decided_by", sa.String(254), nullable=True),
        sa.Column("decided_at", TS, nullable=True),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("updated_at", TS, nullable=False),
        sa.UniqueConstraint("provider", "name", "version", name="uq_models_provider_name_version"),
    )
    op.create_index("ix_models_status", "models", ["status"])

    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("at", TS, nullable=False),
        sa.Column("actor", sa.String(254), nullable=False),
        sa.Column("action", sa.String(64), nullable=False),
        sa.Column("entity_type", sa.String(32), nullable=False),
        sa.Column("entity_id", sa.String(128), nullable=False),
        sa.Column("details", sa.JSON(), nullable=False),
    )
    op.create_index("ix_audit_log_at", "audit_log", ["at"])
    op.create_index("ix_audit_log_entity", "audit_log", ["entity_type", "entity_id"])

    op.create_table(
        "workspaces",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("repo_url", sa.String(2048), nullable=False),
        sa.Column("work_item", sa.String(500), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("job_profile", sa.String(32), nullable=True),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("requested_by", sa.String(254), nullable=False),
        sa.Column("team", sa.String(64), nullable=False),
        sa.Column("pr_url", sa.String(2048), nullable=True),
        sa.Column("log_url", sa.String(2048), nullable=True),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("updated_at", TS, nullable=False),
    )
    op.create_index("ix_workspaces_status", "workspaces", ["status"])
    op.create_index("ix_workspaces_requested_by", "workspaces", ["requested_by"])

    op.create_table(
        "eval_runs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("agent_id", sa.String(64), nullable=False),
        sa.Column("dataset", sa.String(256), nullable=False),
        sa.Column("experiment_id", sa.String(256), nullable=False),
        sa.Column("scores", sa.JSON(), nullable=False),
        sa.Column("baseline_scores", sa.JSON(), nullable=False),
        sa.Column("passed", sa.Boolean(), nullable=False),
        sa.Column("fiddler_url", sa.String(2048), nullable=True),
        sa.Column("git_sha", sa.String(64), nullable=True),
        sa.Column("pr", sa.String(256), nullable=True),
        sa.Column("created_by", sa.String(254), nullable=False),
        sa.Column("created_at", TS, nullable=False),
    )
    op.create_index("ix_eval_runs_agent_id", "eval_runs", ["agent_id"])
    op.create_index("ix_eval_runs_created_at", "eval_runs", ["created_at"])


def downgrade() -> None:
    for table in ("eval_runs", "workspaces", "audit_log", "models", "mcp_servers", "user_preferences", "agents"):
        op.drop_table(table)
