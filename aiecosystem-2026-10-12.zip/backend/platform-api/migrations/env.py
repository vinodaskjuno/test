"""Alembic environment for platform-api.

Used by `aig-platform-api db upgrade` (which passes a live connection) and by plain `alembic`
commands run from backend/platform-api (alembic.ini), where the URL comes from AIG_DATABASE_URL /
AIG_ENV exactly as at runtime (platform_api.db.resolve_database_url, fail closed outside local).
"""

from __future__ import annotations

from alembic import context
from sqlalchemy import pool

from platform_api.db import Base, make_engine, resolve_database_url

config = context.config
target_metadata = Base.metadata


def _url() -> str:
    url = config.attributes.get("url")
    if url:
        return url
    from platform_api.config import Settings

    settings = Settings()
    return resolve_database_url(settings.env, settings.database_url)


def run_migrations_offline() -> None:
    context.configure(url=_url(), target_metadata=target_metadata, literal_binds=True,
                      dialect_opts={"paramstyle": "named"}, render_as_batch=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connection = config.attributes.get("connection")
    if connection is not None:
        context.configure(connection=connection, target_metadata=target_metadata, render_as_batch=True)
        with context.begin_transaction():
            context.run_migrations()
        return
    engine = make_engine(_url())
    try:
        with engine.connect() as conn:
            context.configure(connection=conn, target_metadata=target_metadata, render_as_batch=True)
            with context.begin_transaction():
                context.run_migrations()
    finally:
        engine.dispose()


_ = pool  # keep the import for autogenerate templates
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
