from __future__ import annotations

import json
import logging

import httpx
import pytest

from cache_compress.compressor import (
    Compressor,
    LargeContextCompressor,
    NoopCompressor,
    build_compressor,
)

BODY = b'{"model":"claude-sonnet-4-5","messages":[{"role":"user","content":"hello world"}]}'


class ModelSwapCompressor:
    name = "model-swap"

    async def compress_request(self, *, route, path, headers, body):
        doc = json.loads(body)
        doc["model"] = "cheaper-model"
        return json.dumps(doc).encode()


class ShrinkCompressor:
    name = "shrink"

    async def compress_request(self, *, route, path, headers, body):
        doc = json.loads(body)
        doc["messages"] = [{"role": "user", "content": "hi"}]
        return json.dumps(doc, separators=(",", ":")).encode()


class GarbageCompressor:
    name = "garbage"

    async def compress_request(self, *, route, path, headers, body):
        return b"{not json"


class RaisingCompressor:
    name = "raising"

    async def compress_request(self, *, route, path, headers, body):
        raise RuntimeError("nope")


def test_build_compressor():
    assert isinstance(build_compressor("noop"), NoopCompressor)
    lc = build_compressor("large-context", 10)
    assert isinstance(lc, LargeContextCompressor) and lc.threshold_bytes == 10
    assert isinstance(build_compressor("noop"), Compressor)


def test_build_compressor_unknown_raises():
    with pytest.raises(ValueError):
        build_compressor("magic")


async def test_noop_identity():
    assert await NoopCompressor().compress_request(route="r", path="p", headers={}, body=BODY) is BODY


async def test_large_context_stub_returns_identical_bytes(caplog):
    caplog.set_level(logging.DEBUG, logger="cache_compress")
    c = LargeContextCompressor(threshold_bytes=10)
    out = await c.compress_request(route="anthropic", path="v1/messages", headers={}, body=BODY)
    assert out == BODY
    assert "would apply" in caplog.text
    assert "hello world" not in caplog.text
    small = await LargeContextCompressor(10_000).compress_request(
        route="r", path="p", headers={}, body=BODY
    )
    assert small == BODY


def _post(make_client, mock_upstream, compressor, body=BODY):
    route = mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(200, content=b'{"usage":{"input_tokens":1}}')
    )
    c = make_client(compressor=compressor)
    resp = c.post("/anthropic/v1/messages", content=body)
    assert resp.status_code == 200
    assert resp.content == b'{"usage":{"input_tokens":1}}'
    return route.calls.last.request.content


def test_guard_model_change_uses_original(make_client, mock_upstream, caplog):
    caplog.set_level(logging.WARNING, logger="cache_compress")
    assert _post(make_client, mock_upstream, ModelSwapCompressor()) == BODY
    assert "changed the model field" in caplog.text


def test_guard_invalid_json_uses_original(make_client, mock_upstream):
    assert _post(make_client, mock_upstream, GarbageCompressor()) == BODY


def test_guard_compressor_exception_uses_original(make_client, mock_upstream):
    assert _post(make_client, mock_upstream, RaisingCompressor()) == BODY


def test_compressed_body_with_same_model_is_forwarded(make_client, mock_upstream):
    sent = _post(make_client, mock_upstream, ShrinkCompressor())
    assert sent != BODY
    assert json.loads(sent) == {
        "model": "claude-sonnet-4-5",
        "messages": [{"role": "user", "content": "hi"}],
    }


def test_large_context_end_to_end_identical(make_client, mock_upstream):
    assert _post(make_client, mock_upstream, LargeContextCompressor(10)) == BODY
