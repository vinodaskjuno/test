from __future__ import annotations

import logging

import httpx

SECRETS = ("sk-ant-SUPERSECRET-123", "sk-SUPERSECRET-456", "PROMPT-SECRET-789", "QUERY-SECRET-000")


def test_secrets_and_bodies_never_logged(make_client, mock_upstream, caplog, capfd):
    caplog.set_level(logging.DEBUG)
    mock_upstream.post(url__startswith="https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(
            200,
            content=b'{"model":"m","content":[{"text":"PROMPT-SECRET-789 echoed"}]}',
            headers={"content-type": "application/json"},
        )
    )
    from cache_compress.compressor import LargeContextCompressor

    for compressor in (None, LargeContextCompressor(threshold_bytes=1)):
        kwargs = {} if compressor is None else {"compressor": compressor}
        c = make_client(**kwargs)
        resp = c.post(
            "/anthropic/v1/messages?token=QUERY-SECRET-000",
            content=b'{"model":"m","messages":[{"role":"user","content":"PROMPT-SECRET-789"}]}',
            headers={
                "x-api-key": "sk-ant-SUPERSECRET-123",
                "authorization": "Bearer sk-SUPERSECRET-456",
            },
        )
        assert resp.status_code == 200

    # error paths log too
    mock_upstream.post("https://api.openai.test/v1/chat/completions").mock(
        side_effect=httpx.ConnectError("refused sk-SUPERSECRET-456")
    )
    c.post(
        "/openai-a/v1/chat/completions",
        content=b"PROMPT-SECRET-789",
        headers={"authorization": "Bearer sk-SUPERSECRET-456"},
    )

    out, err = capfd.readouterr()
    logged = caplog.text + out + err
    assert "request method=POST route=anthropic status=200 stream=false" in caplog.text
    assert "status=502" in caplog.text
    for secret in SECRETS:
        assert secret not in logged, secret
