from __future__ import annotations

import json

import httpx
import pytest

ANTHROPIC_BODY = (
    '{ "model" : "claude-sonnet-4-5",\n\t"max_tokens":  1024 ,'
    '"messages":[{"role":"user","content":"h\\u00e9llo  ünïcødé 漢字 🚀  "}] ,"x":1.0e0}  \n'
).encode("utf-8")

ANTHROPIC_RESPONSE = (
    '{"id":"msg_01","type":"message","model":"claude-sonnet-4-5",'
    '"content":[{"type":"text","text":"héllo  🚀"}],'
    '"usage":{"input_tokens":12,"output_tokens":34,"cache_read_input_tokens":0}}\n'
).encode("utf-8")


def test_non_stream_byte_identical(client, mock_upstream):
    route = mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(
            200,
            content=ANTHROPIC_RESPONSE,
            headers={"content-type": "application/json", "request-id": "req_123"},
        )
    )
    resp = client.post(
        "/anthropic/v1/messages",
        content=ANTHROPIC_BODY,
        headers={"content-type": "application/json"},
    )
    assert resp.status_code == 200
    assert route.call_count == 1
    assert route.calls.last.request.content == ANTHROPIC_BODY
    assert resp.content == ANTHROPIC_RESPONSE
    assert resp.headers["request-id"] == "req_123"
    assert resp.headers["content-type"] == "application/json"
    assert resp.headers["content-length"] == str(len(ANTHROPIC_RESPONSE))
    data = resp.json()
    assert data["model"] == "claude-sonnet-4-5"
    assert data["usage"] == {"input_tokens": 12, "output_tokens": 34, "cache_read_input_tokens": 0}


def test_headers_forwarded_and_hop_by_hop_stripped(client, mock_upstream):
    route = mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(
            200,
            content=b"{}",
            headers={"content-type": "application/json", "keep-alive": "timeout=5", "x-up": "1"},
        )
    )
    resp = client.post(
        "/anthropic/v1/messages",
        content=b'{"model":"m"}',
        headers={
            "x-api-key": "test-key-not-real",
            "anthropic-version": "2023-06-01",
            "anthropic-beta": "prompt-caching-2024-07-31",
            "x-portkey-trace-id": "trace-1",
            "connection": "keep-alive, x-drop-me",
            "x-drop-me": "1",
            "keep-alive": "timeout=5",
            "te": "trailers",
            "upgrade": "h2c",
            "proxy-authorization": "Basic Zm9vOmJhcg==",
            "host": "cache-compress.internal",
        },
    )
    assert resp.status_code == 200
    sent = route.calls.last.request.headers
    assert sent["x-api-key"] == "test-key-not-real"
    assert sent["anthropic-version"] == "2023-06-01"
    assert sent["anthropic-beta"] == "prompt-caching-2024-07-31"
    assert sent["x-portkey-trace-id"] == "trace-1"
    for h in ("connection", "keep-alive", "te", "upgrade", "proxy-authorization", "x-drop-me"):
        assert h not in sent, h
    assert sent["host"] == "api.anthropic.test"
    assert sent["content-length"] == str(len(b'{"model":"m"}'))
    assert resp.headers["x-up"] == "1"
    assert "keep-alive" not in resp.headers


def test_openai_bearer_forwarded(client, mock_upstream):
    route = mock_upstream.post("https://api.openai.test/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    resp = client.post(
        "/openai-a/v1/chat/completions",
        content=b'{"model":"gpt-x","messages":[]}',
        headers={"authorization": "Bearer test-token-not-real"},
    )
    assert resp.status_code == 200
    assert route.calls.last.request.headers["authorization"] == "Bearer test-token-not-real"
    # trailing slash on the upstream base does not produce a double slash
    assert route.calls.last.request.url.path == "/v1/chat/completions"


def test_query_string_preserved(client, mock_upstream):
    route = mock_upstream.get(url__startswith="https://api.anthropic.test/v1/models").mock(
        return_value=httpx.Response(200, json={"data": []})
    )
    resp = client.get("/anthropic/v1/models?limit=5&after_id=a%2Fb&x=1&x=2")
    assert resp.status_code == 200
    req = route.calls.last.request
    assert req.url.raw_path == b"/v1/models?limit=5&after_id=a%2Fb&x=1&x=2"


@pytest.mark.parametrize("method", ["GET", "PUT", "PATCH", "DELETE"])
def test_methods(client, mock_upstream, method):
    route = mock_upstream.route(method=method, url="https://api.anthropic.test/v1/thing/1").mock(
        return_value=httpx.Response(200, content=b"ok")
    )
    resp = client.request(method, "/anthropic/v1/thing/1")
    assert resp.status_code == 200
    assert route.call_count == 1


def test_sse_streaming_passthrough(client, mock_upstream):
    chunks = [
        b'event: message_start\ndata: {"type":"message_start","message":{"model":"claude-sonnet-4-5","usage":{"input_tokens":10}}}\n\n',
        b'event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"text":"h\xc3\xa9"}}\n\n',
        b'event: message_delta\ndata: {"type":"message_delta","usage":{"output_tokens":7}}\n\n',
        b'event: message_stop\ndata: {"type":"message_stop"}\n\n',
    ]
    mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(
            200,
            headers={"content-type": "text/event-stream; charset=utf-8"},
            stream=_Chunks(chunks),
        )
    )
    with client.stream(
        "POST", "/anthropic/v1/messages", content=b'{"model":"m","stream":true}'
    ) as resp:
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "text/event-stream; charset=utf-8"
        received = b"".join(resp.iter_raw())
    assert received == b"".join(chunks)


class _Chunks(httpx.AsyncByteStream):
    def __init__(self, chunks):
        self._chunks = chunks

    async def __aiter__(self):
        for c in self._chunks:
            yield c


class _Boom(httpx.AsyncByteStream):
    async def __aiter__(self):
        yield b"data: first\n\n"
        raise httpx.ReadError("boom")


def test_mid_stream_error_ends_stream(client, mock_upstream):
    mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(
            200, headers={"content-type": "text/event-stream"}, stream=_Boom()
        )
    )
    resp = client.post("/anthropic/v1/messages", content=b"{}")
    assert resp.status_code == 200
    assert resp.content == b"data: first\n\n"


@pytest.mark.parametrize(
    "status,body",
    [
        (429, b'{"type":"error","error":{"type":"rate_limit_error","message":"slow down"}}'),
        (500, b'{"error":{"message":"internal"}}'),
        (400, b"not json at all"),
    ],
)
def test_upstream_status_relayed(client, mock_upstream, status, body):
    mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(
            status, content=body, headers={"retry-after": "3", "content-type": "application/json"}
        )
    )
    resp = client.post("/anthropic/v1/messages", content=b"{}")
    assert resp.status_code == status
    assert resp.content == body
    assert resp.headers["retry-after"] == "3"


def test_unknown_route_404(client, mock_upstream):
    resp = client.post("/nope/v1/messages", content=b"{}")
    assert resp.status_code == 404
    assert resp.json()["error"]["code"] == "unknown_route"


def test_placeholder_route_503_in_local(client, mock_upstream):
    resp = client.post("/openai-b/v1/chat/completions", content=b"{}")
    assert resp.status_code == 503
    assert resp.json()["error"]["code"] == "upstream_not_configured"
    assert mock_upstream.calls.call_count == 0


def test_timeout_504(client, mock_upstream):
    mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        side_effect=httpx.ReadTimeout("slow")
    )
    resp = client.post("/anthropic/v1/messages", content=b"{}")
    assert resp.status_code == 504
    assert resp.json()["error"]["code"] == "upstream_timeout"


def test_connect_error_502(client, mock_upstream):
    mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        side_effect=httpx.ConnectError("refused")
    )
    resp = client.post("/anthropic/v1/messages", content=b"{}")
    assert resp.status_code == 502
    assert resp.json()["error"]["code"] == "upstream_unavailable"


def test_healthz(client):
    resp = client.get("/healthz")
    assert resp.status_code == 200
    assert resp.json() == {
        "status": "ok",
        "env": "local",
        "compressor": "noop",
        "routes": {"anthropic": "configured", "openai-a": "configured", "openai-b": "placeholder"},
    }
    assert "api.anthropic.test" not in resp.text


def test_healthz_not_proxied(client, mock_upstream):
    # A route literally named healthz would still not capture GET /healthz.
    assert client.get("/healthz").json()["status"] == "ok"
    assert mock_upstream.calls.call_count == 0


def test_injected_http_client_is_used(make_client, mock_upstream):
    route = mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(200, content=b"{}")
    )
    http_client = httpx.AsyncClient()
    c = make_client(http_client=http_client)
    assert c.post("/anthropic/v1/messages", content=b"{}").status_code == 200
    assert route.call_count == 1
    assert c.app.state.http_client is http_client


def test_body_json_dump_roundtrip_unchanged(client, mock_upstream):
    # Large-ish body with odd formatting is forwarded verbatim.
    body = json.dumps({"model": "m", "messages": [{"c": "x" * 50_000}]}, indent=3).encode()
    route = mock_upstream.post("https://api.anthropic.test/v1/messages").mock(
        return_value=httpx.Response(200, content=b"{}")
    )
    client.post("/anthropic/v1/messages", content=body)
    assert route.calls.last.request.content == body
