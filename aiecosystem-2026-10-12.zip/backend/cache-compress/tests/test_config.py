from __future__ import annotations

import json

import pytest

from cache_compress.config import (
    DEFAULT_UPSTREAMS_FILE,
    Settings,
    StartupError,
    load_upstreams,
    validate_upstreams,
)
from cache_compress.main import create_app


def test_defaults():
    s = Settings.from_env({})
    assert s.env == "local"
    assert s.timeout_seconds == 300
    assert s.compressor == "noop"
    assert s.large_context_threshold_bytes == 200_000
    assert s.upstreams_file == DEFAULT_UPSTREAMS_FILE


def test_default_file_loads_and_has_placeholder():
    ups = load_upstreams(Settings.from_env({}))
    assert ups["anthropic"] == "https://api.anthropic.com"
    assert ups["openai-a"] == "https://api.openai.com"
    assert "__" in ups["openai-b"]
    assert validate_upstreams(ups, "local")["openai-b"] == "placeholder"


def test_invalid_env_rejected():
    with pytest.raises(StartupError):
        Settings.from_env({"AIG_ENV": "qa"})


@pytest.mark.parametrize("env", ["dev", "stage", "prod"])
def test_placeholder_outside_local_refuses_start(env):
    with pytest.raises(StartupError):
        create_app(
            Settings(env=env),
            upstreams={"anthropic": "https://api.anthropic.com", "openai-b": "https://__X__"},
        )


def test_default_file_refuses_start_in_prod():
    with pytest.raises(StartupError):
        create_app(Settings.from_env({"AIG_ENV": "prod"}))


def test_http_outside_local_refuses_start():
    with pytest.raises(StartupError):
        create_app(Settings(env="prod"), upstreams={"anthropic": "http://api.anthropic.com"})


def test_http_allowed_in_local():
    app = create_app(Settings(env="local"), upstreams={"mock": "http://127.0.0.1:9999"})
    assert app.state.route_statuses == {"mock": "configured"}


@pytest.mark.parametrize("route", ["Anthropic", "-x", "a_b", "a" * 65, ""])
def test_invalid_route_name(route):
    with pytest.raises(StartupError):
        validate_upstreams({route: "https://x.test"}, "local")


def test_env_json_override(monkeypatch, tmp_path):
    monkeypatch.setenv("AIG_ENV", "prod")
    monkeypatch.setenv(
        "AIG_CC_UPSTREAMS",
        json.dumps({"anthropic": "https://a.test", "openai-b": "https://b.test"}),
    )
    app = create_app()
    assert app.state.upstreams == {"anthropic": "https://a.test", "openai-b": "https://b.test"}
    assert app.state.route_statuses == {"anthropic": "configured", "openai-b": "configured"}


def test_env_json_override_routes_requests(monkeypatch, mock_upstream):
    import httpx
    from fastapi.testclient import TestClient

    monkeypatch.setenv("AIG_CC_UPSTREAMS", json.dumps({"openai-b": "https://b.test/base"}))
    route = mock_upstream.post("https://b.test/base/v1/chat/completions").mock(
        return_value=httpx.Response(200, content=b"{}")
    )
    with TestClient(create_app()) as c:
        assert c.post("/openai-b/v1/chat/completions", content=b"{}").status_code == 200
    assert route.call_count == 1


@pytest.mark.parametrize("value", ["not json", "[1,2]", '{"a": 1}'])
def test_env_json_invalid(monkeypatch, value):
    monkeypatch.setenv("AIG_CC_UPSTREAMS", value)
    with pytest.raises(StartupError):
        create_app()


def test_upstreams_file_env(monkeypatch, tmp_path):
    f = tmp_path / "u.yaml"
    f.write_text("upstreams:\n  anthropic: https://alt.test\n")
    monkeypatch.setenv("AIG_CC_UPSTREAMS_FILE", str(f))
    monkeypatch.setenv("AIG_ENV", "stage")
    assert create_app().state.upstreams == {"anthropic": "https://alt.test"}


def test_missing_file(monkeypatch, tmp_path):
    monkeypatch.setenv("AIG_CC_UPSTREAMS_FILE", str(tmp_path / "missing.yaml"))
    with pytest.raises(StartupError):
        create_app()


def test_unknown_compressor_env_refuses_start(monkeypatch):
    monkeypatch.setenv("AIG_CC_COMPRESSOR", "zstd-magic")
    with pytest.raises(StartupError):
        create_app()


def test_large_context_via_env(monkeypatch):
    monkeypatch.setenv("AIG_CC_COMPRESSOR", "large-context")
    monkeypatch.setenv("AIG_CC_LARGE_CONTEXT_THRESHOLD_BYTES", "1234")
    app = create_app()
    assert app.state.compressor.name == "large-context"
    assert app.state.compressor.threshold_bytes == 1234
