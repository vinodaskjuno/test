from __future__ import annotations

from collections.abc import Iterator

import pytest
import respx
from fastapi.testclient import TestClient

from cache_compress.config import Settings
from cache_compress.main import create_app

UPSTREAMS = {
    "anthropic": "https://api.anthropic.test",
    "openai-a": "https://api.openai.test/",
    "openai-b": "https://__OPENAI_DEPLOYMENT_B_HOST__",
}


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in (
        "AIG_ENV",
        "AIG_CC_UPSTREAMS_FILE",
        "AIG_CC_UPSTREAMS",
        "AIG_CC_TIMEOUT_SECONDS",
        "AIG_CC_COMPRESSOR",
        "AIG_CC_LARGE_CONTEXT_THRESHOLD_BYTES",
        "AIG_LOG_LEVEL",
    ):
        monkeypatch.delenv(var, raising=False)


@pytest.fixture
def make_client():
    clients: list[TestClient] = []

    def _make(**kwargs) -> TestClient:
        kwargs.setdefault("upstreams", UPSTREAMS)
        settings = kwargs.pop("settings", None) or Settings(env="local", log_level="DEBUG")
        app = create_app(settings, **kwargs)
        client = TestClient(app, raise_server_exceptions=True)
        client.__enter__()
        clients.append(client)
        return client

    yield _make
    for c in clients:
        c.__exit__(None, None, None)


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client()


@pytest.fixture
def mock_upstream() -> Iterator[respx.MockRouter]:
    with respx.mock(assert_all_called=False) as router:
        yield router
