# aig-cache-compress

The **caching & compression layer** of the AIG AI Ecosystem.

**Phase 1 is a pure pass-through.** The self-hosted Portkey gateway sends each
model call here. This service picks the real provider upstream from the first
path segment and forwards the request byte for byte. It streams the response
back as it arrives.

- **Caching is owned by Portkey** (exact + semantic). This service does no caching.
- **Compression comes later.** This layer will compress large contexts and keep
  prompt prefixes byte-stable so provider prompt caches stay warm. The hook for
  this (the `Compressor` interface) exists today. Its only active implementation
  is the identity no-op.

## How Portkey points at it

Config `pc-aig-router` routes each call to a leaf target. That target's
`custom_host` points at this service, with the route name as the first path
segment:

| Portkey leaf          | `custom_host`                              | Upstream (default)          |
|-----------------------|--------------------------------------------|-----------------------------|
| Anthropic             | `https://<cache-compress-host>/anthropic/v1`  | `https://api.anthropic.com` |
| OpenAI deployment A   | `https://<cache-compress-host>/openai-a/v1`   | `https://api.openai.com`    |
| OpenAI deployment B   | `https://<cache-compress-host>/openai-b/v1`   | placeholder: set per env    |

Both OpenAI deployments sit behind one Portkey virtual key, which load-balances
between them. The leaves (backend/gateway/configs/pc-aig-router.json) end in `/v1`
because Portkey treats `custom_host` as the provider's base URL (like
`https://api.anthropic.com/v1`) and appends the endpoint (`/messages`,
`/chat/completions`), so the request arrives as, for example:

```
POST https://<cache-compress-host>/anthropic/v1/messages      (x-api-key, anthropic-version)
  -> POST https://api.anthropic.com/v1/messages
POST https://<cache-compress-host>/openai-a/v1/chat/completions (Authorization: Bearer ...)
  -> POST https://api.openai.com/v1/chat/completions
```

## Configuration

| Env var | Default | Meaning |
|---|---|---|
| `AIG_ENV` | `local` | `local` \| `dev` \| `stage` \| `prod` |
| `AIG_CC_UPSTREAMS_FILE` | `<project>/config/upstreams.yaml` | YAML upstream map |
| `AIG_CC_UPSTREAMS` | unset | JSON object `{"route": "https://base"}`. When set, it **replaces** the file map |
| `AIG_CC_TIMEOUT_SECONDS` | `300` | httpx timeout (connect, write, pool, and read **per chunk**, so long SSE streams are fine) |
| `AIG_CC_COMPRESSOR` | `noop` | `noop` or `large-context` (stub) |
| `AIG_CC_LARGE_CONTEXT_THRESHOLD_BYTES` | `200000` | Body size above which the large-context stub would act |
| `AIG_LOG_LEVEL` | `INFO` | Log level for the `cache_compress` loggers |
| `PORT` / `HOST` | `8090` / `0.0.0.0` | Used by `run-local.sh`, the Docker image and the `aig-cache-compress` script |

### Upstream map (`config/upstreams.yaml`)

```yaml
upstreams:
  anthropic: https://api.anthropic.com
  openai-a: https://api.openai.com
  openai-b: https://__OPENAI_DEPLOYMENT_B_HOST__
```

- Route names must match `^[a-z0-9][a-z0-9-]{0,63}$`.
- Upstream URLs are base URLs. The forwarded URL is
  `base.rstrip('/') + '/' + <rest of path>`, plus the original query string.
  A base may include a path prefix, such as `https://host/openai`.
- **Placeholders.** Any URL containing `__` is a placeholder.
  - Outside `local`, the service refuses to start (`StartupError`) if any
    upstream is a placeholder or does not use `https://`.
  - In `local`, it starts with a warning, and the placeholder route returns
    `503 upstream_not_configured`. Plain `http://` is also allowed in `local`
    (for mock upstreams).
- **Per-environment override.** Mount a different file and point
  `AIG_CC_UPSTREAMS_FILE` at it, or set `AIG_CC_UPSTREAMS`, for example
  `'{"anthropic":"https://api.anthropic.com","openai-a":"https://api.openai.com","openai-b":"https://<deployment-b-host>"}'`.
- The map holds no secrets. Provider keys travel in the request headers that
  Portkey sends.

## Run

```bash
# venv + uvicorn
python3.12 -m venv .venv && .venv/bin/pip install -e '.[dev]'
.venv/bin/uvicorn cache_compress.main:create_app --factory --port 8090 \
  --no-access-log --no-server-header --no-date-header
# or: .venv/bin/aig-cache-compress

# background helper (creates .venv if missing, logs in .run/)
./run-local.sh start | stop | status | logs      # PORT=8090 by default

# tests
.venv/bin/pytest -q

# Docker (AIG_ENV=prod by default in the image, so override openai-b)
docker build -t aig-cache-compress .
docker run --rm -p 8090:8090 \
  -e AIG_CC_UPSTREAMS='{"anthropic":"https://api.anthropic.com","openai-a":"https://api.openai.com","openai-b":"https://<deployment-b-host>"}' \
  aig-cache-compress
```

The image is based on `python:3.12-slim`, runs as non-root uid 10001, exposes
port 8090, and has a `/healthz` HEALTHCHECK.

Always run uvicorn with `--no-access-log`, because uvicorn access logs include
query strings. Use `--no-server-header --no-date-header` so the upstream's
`server`/`date` headers are relayed instead of being duplicated.

## Compressor interface

`src/cache_compress/compressor.py`:

```python
class Compressor(Protocol):
    name: str
    async def compress_request(self, *, route: str, path: str,
                               headers: Mapping[str, str], body: bytes) -> bytes: ...
```

- `NoopCompressor` (`noop`, the default) returns the body unchanged (identity).
- `LargeContextCompressor(threshold_bytes)` (`large-context`) is a
  **disabled-by-default stub**. Enable it with `AIG_CC_COMPRESSOR=large-context`.
  It marks where context compression will go for bodies over the threshold:
  dedupe or summarise older turns, while keeping the system prompt and recent
  turns byte-stable. Today it returns the body unchanged and logs at DEBUG that
  compression would apply. That log contains only the route and sizes, never
  body content.
- `build_compressor(name, threshold)` builds a compressor by name. It raises
  `ValueError` on unknown names, which becomes a `StartupError` at boot.
- `create_app(..., compressor=...)` accepts any object that implements the
  protocol.

**Safety guard.** If a compressor raises, returns invalid JSON for a JSON body,
or changes the JSON `model` field, the proxy discards its output, forwards the
original bytes, and logs a warning. Responses are never passed to a compressor.

## Guarantees

- **Byte-identical with `noop`.**
  - The request body reaches the upstream exactly as received, with any
    whitespace, key order and unicode escapes untouched.
  - The response body reaches the client exactly as the upstream sent it,
    relayed with `aiter_raw()`, so the upstream `content-encoding` is kept.
- **`model` and `usage` are preserved.** The request `model` field cannot be
  changed by the compression layer (guard above). Responses, including `usage`
  and SSE usage events, are never modified.
- **Headers are forwarded unchanged**, including `x-api-key`, `authorization`,
  `anthropic-version`, `anthropic-beta`, `openai-*` and `x-portkey-*`. The
  exceptions are hop-by-hop headers (connection, keep-alive,
  proxy-authenticate, proxy-authorization, te, trailer, transfer-encoding,
  upgrade, and any header named in `Connection:`), `host` and
  `content-length`. httpx recomputes `host` and `content-length`. No client
  default headers or cookies are added.
- **Upstream status and headers are preserved**, minus hop-by-hop headers.
  Upstream `content-length` is kept unless the response was chunked.
- **SSE streams pass through chunk by chunk.**
- **No sensitive logging.** Request/response bodies, header values, keys and
  query strings are never logged. The service logs one line per request:
  `request method=POST route=anthropic status=200 stream=false ms=123`. It also
  sets the `httpx`/`httpcore` loggers to WARNING, because httpx logs full URLs
  at INFO.

## Endpoints

| Endpoint | Description |
|---|---|
| `GET /healthz` | `{"status":"ok","env":"local","compressor":"noop","routes":{"anthropic":"configured","openai-b":"placeholder",...}}`. Returns statuses only, never URLs |
| `GET\|POST\|PUT\|PATCH\|DELETE /{route}/{path}` | Proxy to `upstreams[route]` + `/{path}` + `?query` |

## Errors

All errors produced by this layer use the shape
`{"error":{"code":"...","message":"..."}}`. Provider errors are relayed
unchanged.

| Status | Code | When |
|---|---|---|
| 404 | `unknown_route` | First path segment is not in the upstream map |
| 503 | `upstream_not_configured` | Route's upstream is a placeholder (only possible in `local`) |
| 504 | `upstream_timeout` | httpx timeout before response headers |
| 502 | `upstream_unavailable` | Connect or other transport error before response headers |
| (upstream) | (upstream) | Any upstream status (such as 400, 429 or 500) is relayed unchanged |

A failure in the middle of a stream ends the response stream. The service logs
a warning that names only the exception type.

## Assumptions to verify

1. **Portkey appends the endpoint path to `custom_host`.** With the leaves'
   `custom_host = https://<host>/<route>/v1` it calls `.../anthropic/v1/messages`
   and `.../openai-a/v1/chat/completions`. If Portkey adds or strips the `/v1`
   segment differently, adjust either the leaves in pc-aig-router or the upstream
   base URLs here.
2. **Portkey forwards provider auth headers to the custom host:** `x-api-key`
   and `anthropic-version` for Anthropic, `Authorization: Bearer` for OpenAI.
   It must resolve virtual keys into real provider keys before calling
   `custom_host`. This service never holds provider keys.
3. **The deployment B host is unknown.** `openai-b` is a placeholder that must
   be set per environment. If deployment B is Azure OpenAI, its path and auth
   scheme differ (`api-key` header, `/openai/deployments/...`). The proxy
   forwards those unchanged, but the Portkey leaf provider type must match.
4. **Portkey `x-portkey-*` headers are forwarded to the provider unchanged**,
   as specified. Providers ignore unknown headers.
