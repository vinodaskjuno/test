#!/usr/bin/env bash
# Run aig-cache-compress locally in the background.
# Usage: ./run-local.sh start|stop|status|logs   (PORT defaults to 8090)
set -euo pipefail

cd "$(dirname "$0")"
PORT="${PORT:-8090}"
RUN_DIR=".run"
PID_FILE="$RUN_DIR/cache-compress.pid"
LOG_FILE="$RUN_DIR/cache-compress.log"
export AIG_ENV="${AIG_ENV:-local}"

pick_python() {
  for p in python3.12 python3.13 python3.11 python3; do
    if command -v "$p" >/dev/null 2>&1 && "$p" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
      echo "$p"; return 0
    fi
  done
  echo "error: Python >= 3.11 not found" >&2; return 1
}

ensure_venv() {
  if [[ ! -x .venv/bin/uvicorn ]]; then
    echo "creating .venv ..."
    "$(pick_python)" -m venv .venv
    .venv/bin/pip install -q -e '.[dev]'
  fi
}

is_running() {
  [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null
}

case "${1:-}" in
  start)
    if is_running; then echo "already running (pid $(cat "$PID_FILE"))"; exit 0; fi
    ensure_venv
    mkdir -p "$RUN_DIR"
    nohup .venv/bin/uvicorn cache_compress.main:create_app --factory \
      --host 127.0.0.1 --port "$PORT" --no-access-log --no-server-header --no-date-header >>"$LOG_FILE" 2>&1 &
    echo $! >"$PID_FILE"
    for _ in $(seq 1 50); do
      if curl -fsS "http://127.0.0.1:$PORT/healthz" >/dev/null 2>&1; then
        echo "started on http://127.0.0.1:$PORT (pid $(cat "$PID_FILE")), logs: $LOG_FILE"; exit 0
      fi
      if ! is_running; then echo "failed to start; see $LOG_FILE" >&2; tail -n 20 "$LOG_FILE" >&2; exit 1; fi
      sleep 0.2
    done
    echo "started (pid $(cat "$PID_FILE")) but /healthz not responding yet; see $LOG_FILE"
    ;;
  stop)
    if is_running; then
      kill "$(cat "$PID_FILE")"; rm -f "$PID_FILE"; echo "stopped"
    else
      rm -f "$PID_FILE"; echo "not running"
    fi
    ;;
  status)
    if is_running; then
      echo "running (pid $(cat "$PID_FILE")) on port $PORT"
      curl -fsS "http://127.0.0.1:$PORT/healthz" 2>/dev/null && echo || true
    else
      echo "not running"; exit 1
    fi
    ;;
  logs)
    mkdir -p "$RUN_DIR"; touch "$LOG_FILE"; tail -n 100 -f "$LOG_FILE"
    ;;
  *)
    echo "usage: $0 start|stop|status|logs" >&2; exit 2
    ;;
esac
