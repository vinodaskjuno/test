"""Settings and upstream-map loading."""

from __future__ import annotations

import json
import logging
import os
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

import yaml
from pydantic import BaseModel, Field, ValidationError

logger = logging.getLogger("cache_compress.config")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_UPSTREAMS_FILE = PROJECT_ROOT / "config" / "upstreams.yaml"

ROUTE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
PLACEHOLDER_MARKER = "__"

Env = Literal["local", "dev", "stage", "prod"]


class StartupError(RuntimeError):
    """Raised when the service configuration is not safe to start with."""


class Settings(BaseModel):
    env: Env = "local"
    upstreams_file: Path = DEFAULT_UPSTREAMS_FILE
    upstreams_json: str | None = None
    timeout_seconds: float = Field(default=300.0, gt=0)
    compressor: str = "noop"
    large_context_threshold_bytes: int = Field(default=200_000, gt=0)
    log_level: str = "INFO"

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> "Settings":
        env = os.environ if environ is None else environ
        data: dict[str, object] = {}
        mapping = {
            "AIG_ENV": "env",
            "AIG_CC_UPSTREAMS_FILE": "upstreams_file",
            "AIG_CC_UPSTREAMS": "upstreams_json",
            "AIG_CC_TIMEOUT_SECONDS": "timeout_seconds",
            "AIG_CC_COMPRESSOR": "compressor",
            "AIG_CC_LARGE_CONTEXT_THRESHOLD_BYTES": "large_context_threshold_bytes",
            "AIG_LOG_LEVEL": "log_level",
        }
        for var, field in mapping.items():
            value = env.get(var)
            if value is not None and value.strip() != "":
                data[field] = value.strip()
        try:
            return cls(**data)
        except ValidationError as exc:
            raise StartupError(f"invalid configuration: {exc}") from exc


def is_placeholder(url: str) -> bool:
    return PLACEHOLDER_MARKER in url


def load_upstreams(settings: Settings) -> dict[str, str]:
    """Return the raw route -> base URL map (env JSON overrides the file)."""
    if settings.upstreams_json:
        try:
            raw = json.loads(settings.upstreams_json)
        except json.JSONDecodeError as exc:
            raise StartupError("AIG_CC_UPSTREAMS is not valid JSON") from exc
        if not isinstance(raw, dict):
            raise StartupError("AIG_CC_UPSTREAMS must be a JSON object of route -> base URL")
        return _coerce(raw, source="AIG_CC_UPSTREAMS")

    path = Path(settings.upstreams_file)
    try:
        doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except FileNotFoundError as exc:
        raise StartupError(f"upstreams file not found: {path}") from exc
    except yaml.YAMLError as exc:
        raise StartupError(f"upstreams file is not valid YAML: {path}") from exc
    if not isinstance(doc, dict) or not isinstance(doc.get("upstreams"), dict):
        raise StartupError(f"upstreams file must contain an 'upstreams' mapping: {path}")
    return _coerce(doc["upstreams"], source=str(path))


def _coerce(raw: Mapping[object, object], *, source: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for route, url in raw.items():
        if not isinstance(route, str) or not isinstance(url, str):
            raise StartupError(f"{source}: route names and URLs must be strings")
        out[route] = url.strip()
    return out


def validate_upstreams(upstreams: Mapping[str, str], env: str) -> dict[str, str]:
    """Validate the map and return route -> "configured" | "placeholder".

    Outside ``local`` any placeholder or non-https upstream is fatal.
    """
    statuses: dict[str, str] = {}
    if not upstreams:
        raise StartupError("no upstreams configured")
    for route, url in upstreams.items():
        if not ROUTE_NAME_RE.match(route):
            raise StartupError(f"invalid route name {route!r} (must match {ROUTE_NAME_RE.pattern})")
        if is_placeholder(url):
            if env != "local":
                raise StartupError(f"upstream for route {route!r} is a placeholder (AIG_ENV={env})")
            logger.warning("upstream for route %s is a placeholder; it will return 503", route)
            statuses[route] = "placeholder"
            continue
        parts = urlsplit(url)
        if parts.scheme not in ("http", "https") or not parts.netloc:
            raise StartupError(f"upstream for route {route!r} is not an absolute http(s) URL")
        if parts.query or parts.fragment:
            raise StartupError(f"upstream for route {route!r} must not contain a query or fragment")
        if parts.scheme != "https" and env != "local":
            raise StartupError(f"upstream for route {route!r} must use https (AIG_ENV={env})")
        statuses[route] = "configured"
    return statuses
