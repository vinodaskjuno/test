"""AIG AI Ecosystem caching & compression layer.

Phase 1: a byte-identical pass-through proxy that sits between the Portkey
gateway and the model providers. Exact/semantic caching is owned by Portkey;
this layer will later compress context and keep prompt prefixes stable.
"""

__version__ = "0.1.0"
