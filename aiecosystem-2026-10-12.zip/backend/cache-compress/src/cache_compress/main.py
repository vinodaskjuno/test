"""App factory and entrypoint.

Run: uvicorn cache_compress.main:create_app --factory --port 8090 --no-access-log \
         --no-server-header --no-date-header
"""

from __future__ import annotations

import asyncio
import http.cookiejar
import logging
import os
from collections.abc import AsyncIterator, Mapping
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI

from . import __version__
from .compressor import Compressor, build_compressor
from .config import Settings, StartupError, load_upstreams, validate_upstreams
from .proxy import router as proxy_router

logger = logging.getLogger("cache_compress")


def _configure_logging(level: str) -> None:
    pkg = logging.getLogger("cache_compress")
    pkg.setLevel(level.upper())
    if not pkg.handlers and not logging.getLogger().handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        pkg.addHandler(handler)
    # httpx logs full request URLs (incl. query strings) at INFO and httpcore
    # traces at DEBUG; keep them quiet so nothing sensitive reaches the logs.
    for noisy in ("httpx", "httpcore", "hpack"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def _new_http_client(timeout_seconds: float) -> httpx.AsyncClient:
    # A cookie jar that never stores cookies: responses for one caller must
    # never influence another caller's requests.
    jar = http.cookiejar.CookieJar(policy=http.cookiejar.DefaultCookiePolicy(allowed_domains=[]))
    return httpx.AsyncClient(
        timeout=httpx.Timeout(timeout_seconds),
        follow_redirects=False,
        cookies=jar,
        limits=httpx.Limits(max_connections=200, max_keepalive_connections=50),
    )


def create_app(
    settings: Settings | None = None,
    *,
    upstreams: Mapping[str, str] | None = None,
    compressor: Compressor | None = None,
    http_client: httpx.AsyncClient | None = None,
) -> FastAPI:
    settings = settings or Settings.from_env()
    _configure_logging(settings.log_level)

    upstream_map = dict(upstreams) if upstreams is not None else load_upstreams(settings)
    statuses = validate_upstreams(upstream_map, settings.env)
    if compressor is None:
        try:
            compressor = build_compressor(
                settings.compressor, settings.large_context_threshold_bytes
            )
        except ValueError as exc:
            raise StartupError(str(exc)) from exc

    owns_client = http_client is None
    client_lock = asyncio.Lock()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        try:
            yield
        finally:
            client = app.state.http_client
            if owns_client and client is not None:
                await client.aclose()
                app.state.http_client = None

    app = FastAPI(
        title="aig-cache-compress",
        version=__version__,
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )
    app.state.settings = settings
    app.state.upstreams = upstream_map
    app.state.route_statuses = statuses
    app.state.compressor = compressor
    app.state.http_client = http_client

    async def get_http_client() -> httpx.AsyncClient:
        if app.state.http_client is None:
            async with client_lock:
                if app.state.http_client is None:
                    app.state.http_client = _new_http_client(settings.timeout_seconds)
        return app.state.http_client

    app.state.get_http_client = get_http_client

    # Registered before the proxy route. "/healthz" is a single segment, so it
    # cannot match "/{route}/{path:path}" (which requires a second "/").
    @app.get("/healthz")
    async def healthz() -> dict[str, object]:
        return {
            "status": "ok",
            "env": settings.env,
            "compressor": compressor.name,
            "routes": dict(statuses),
        }

    app.include_router(proxy_router)

    logger.info(
        "cache-compress started env=%s compressor=%s routes=%s",
        settings.env,
        compressor.name,
        ",".join(f"{r}:{s}" for r, s in statuses.items()),
    )
    return app


def run() -> None:
    """Console script: aig-cache-compress."""
    import uvicorn

    uvicorn.run(
        "cache_compress.main:create_app",
        factory=True,
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "8090")),
        access_log=False,  # access logs would include query strings
        proxy_headers=True,
        server_header=False,  # relay the upstream's server/date headers, not ours
        date_header=False,
    )


if __name__ == "__main__":
    run()
