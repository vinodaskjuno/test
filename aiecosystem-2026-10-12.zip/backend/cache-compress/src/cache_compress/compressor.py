"""Request compressors.

A compressor may rewrite the outgoing request body (never the response).
Phase 1 ships only the identity ``NoopCompressor``; ``LargeContextCompressor``
is a disabled-by-default stub marking where context compression will go.
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Protocol, runtime_checkable

logger = logging.getLogger("cache_compress.compressor")


@runtime_checkable
class Compressor(Protocol):
    name: str

    async def compress_request(
        self, *, route: str, path: str, headers: Mapping[str, str], body: bytes
    ) -> bytes:
        """Return the (possibly compressed) request body.

        Implementations must keep the JSON ``model`` field unchanged; the proxy
        enforces this and falls back to the original bytes otherwise.
        """
        ...


class NoopCompressor:
    """Identity compressor: returns the exact same bytes object."""

    name = "noop"

    async def compress_request(
        self, *, route: str, path: str, headers: Mapping[str, str], body: bytes
    ) -> bytes:
        return body


class LargeContextCompressor:
    """Stub for large-context compression (disabled by default).

    Enable with ``AIG_CC_COMPRESSOR=large-context``. For bodies larger than
    ``threshold_bytes`` this is where context compression will happen, e.g.
    de-duplicating / summarising older conversation turns while keeping the
    system prompt and the most recent turns byte-stable so provider prompt
    caches (Anthropic cache_control, OpenAI automatic prefix caching) stay
    warm. Today it returns the body unchanged and only logs (at DEBUG, without
    any body content) that compression would apply.
    """

    name = "large-context"

    def __init__(self, threshold_bytes: int = 200_000) -> None:
        if threshold_bytes <= 0:
            raise ValueError("threshold_bytes must be positive")
        self.threshold_bytes = threshold_bytes

    async def compress_request(
        self, *, route: str, path: str, headers: Mapping[str, str], body: bytes
    ) -> bytes:
        if len(body) > self.threshold_bytes:
            logger.debug(
                "large-context compression would apply route=%s size_bytes=%d threshold_bytes=%d",
                route,
                len(body),
                self.threshold_bytes,
            )
        return body


def build_compressor(name: str, threshold: int = 200_000) -> Compressor:
    key = (name or "").strip().lower()
    if key == "noop":
        return NoopCompressor()
    if key == "large-context":
        return LargeContextCompressor(threshold)
    raise ValueError(f"unknown compressor {name!r} (expected 'noop' or 'large-context')")
