"""Pass-through proxy: route -> upstream, byte-identical bodies, streamed responses."""

from __future__ import annotations

import json
import logging
import time
from collections.abc import AsyncIterator, Mapping

import httpx
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from starlette.background import BackgroundTask

from .compressor import Compressor

logger = logging.getLogger("cache_compress.proxy")

HOP_BY_HOP = frozenset(
    {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailer",
        "transfer-encoding",
        "upgrade",
    }
)
# Recomputed by httpx for the outgoing request.
STRIP_REQUEST = HOP_BY_HOP | {"host", "content-length"}

router = APIRouter()


def error_response(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


def _connection_tokens(raw_headers: list[tuple[bytes, bytes]]) -> set[str]:
    """Header names listed in Connection: are hop-by-hop too (RFC 9110 7.6.1)."""
    tokens: set[str] = set()
    for k, v in raw_headers:
        if k.lower() == b"connection":
            tokens.update(t.strip().lower() for t in v.decode("latin-1").split(",") if t.strip())
    return tokens


def filter_request_headers(raw_headers: list[tuple[bytes, bytes]]) -> list[tuple[bytes, bytes]]:
    extra = _connection_tokens(raw_headers)
    return [
        (k, v)
        for k, v in raw_headers
        if (name := k.decode("latin-1").lower()) not in STRIP_REQUEST and name not in extra
    ]


def filter_response_headers(raw_headers: list[tuple[bytes, bytes]]) -> list[tuple[bytes, bytes]]:
    extra = _connection_tokens(raw_headers)
    chunked = any(
        k.lower() == b"transfer-encoding" and b"chunked" in v.lower() for k, v in raw_headers
    )
    out = []
    for k, v in raw_headers:
        name = k.decode("latin-1").lower()
        if name in HOP_BY_HOP or name in extra:
            continue
        # aiter_raw() yields the exact wire bytes (still content-encoded), so an
        # upstream Content-Length stays correct unless the body was chunked.
        if name == "content-length" and chunked:
            continue
        out.append((k, v))
    return out


def _json_model(body: bytes) -> tuple[bool, object]:
    """Return (is_json, model) for a request body."""
    try:
        doc = json.loads(body)
    except (ValueError, UnicodeDecodeError):
        return False, None
    return True, doc.get("model") if isinstance(doc, dict) else None


async def apply_compressor(
    compressor: Compressor, *, route: str, path: str, headers: Mapping[str, str], body: bytes
) -> bytes:
    """Run the compressor with a safety guard; on any doubt use the original bytes."""
    try:
        new_body = await compressor.compress_request(
            route=route, path=path, headers=headers, body=body
        )
    except Exception as exc:  # noqa: BLE001 - a compressor must never break a call
        logger.warning(
            "compressor %s failed (%s); forwarding original body",
            compressor.name,
            type(exc).__name__,
        )
        return body
    if new_body is body or new_body == body:
        return body
    if not isinstance(new_body, (bytes, bytearray)):
        logger.warning("compressor %s returned non-bytes; forwarding original body", compressor.name)
        return body
    orig_is_json, orig_model = _json_model(body)
    if orig_is_json:
        new_is_json, new_model = _json_model(bytes(new_body))
        if not new_is_json:
            logger.warning(
                "compressor %s produced invalid JSON; forwarding original body", compressor.name
            )
            return body
        if new_model != orig_model:
            logger.warning(
                "compressor %s changed the model field; forwarding original body", compressor.name
            )
            return body
    return bytes(new_body)


def _upstream_path(request: Request, route: str, path: str) -> str:
    """Use the raw (still percent-encoded) path when the server provides it."""
    raw_path = request.scope.get("raw_path")
    if raw_path:
        decoded = raw_path.decode("latin-1")
        prefix = f"/{route}/"
        if decoded.startswith(prefix):
            return decoded[len(prefix):]
    return path


def _log_request(method: str, route: str, status: int, stream: bool, started: float) -> None:
    logger.info(
        "request method=%s route=%s status=%d stream=%s ms=%d",
        method,
        route,
        status,
        str(stream).lower(),
        int((time.perf_counter() - started) * 1000),
    )


@router.api_route("/{route}/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def proxy(route: str, path: str, request: Request) -> Response:
    started = time.perf_counter()
    state = request.app.state
    method = request.method

    upstreams: Mapping[str, str] = state.upstreams
    statuses: Mapping[str, str] = state.route_statuses
    if route not in upstreams:
        _log_request(method, "-", 404, False, started)
        return error_response(404, "unknown_route", "unknown route")
    if statuses.get(route) != "configured":
        _log_request(method, route, 503, False, started)
        return error_response(
            503, "upstream_not_configured", f"upstream for route '{route}' is not configured"
        )

    upstream_path = _upstream_path(request, route, path)
    url = upstreams[route].rstrip("/") + "/" + upstream_path
    query = request.scope.get("query_string", b"")
    if query:
        url += "?" + query.decode("latin-1")

    body = await request.body()
    compressor: Compressor = state.compressor
    body = await apply_compressor(
        compressor, route=route, path=upstream_path, headers=request.headers, body=body
    )

    out_headers = filter_request_headers(list(request.headers.raw))
    # Build the Request directly (not client.build_request) so no client default
    # headers (accept-encoding, user-agent, ...) or cookies are merged in.
    upstream_req = httpx.Request(method, url, headers=out_headers, content=body)

    client: httpx.AsyncClient = await state.get_http_client()
    try:
        upstream = await client.send(upstream_req, stream=True)
    except httpx.TimeoutException as exc:
        logger.warning("upstream timeout route=%s (%s)", route, type(exc).__name__)
        _log_request(method, route, 504, False, started)
        return error_response(504, "upstream_timeout", "upstream request timed out")
    except httpx.HTTPError as exc:
        logger.warning("upstream unavailable route=%s (%s)", route, type(exc).__name__)
        _log_request(method, route, 502, False, started)
        return error_response(502, "upstream_unavailable", "upstream request failed")

    is_stream = upstream.headers.get("content-type", "").lower().startswith("text/event-stream")
    status = upstream.status_code

    async def relay() -> AsyncIterator[bytes]:
        try:
            async for chunk in upstream.aiter_raw():
                yield chunk
        except Exception as exc:  # noqa: BLE001 - end the stream, never leak details
            logger.warning("upstream stream ended early route=%s (%s)", route, type(exc).__name__)
        finally:
            _log_request(method, route, status, is_stream, started)

    response = StreamingResponse(
        relay(), status_code=status, background=BackgroundTask(upstream.aclose)
    )
    # Replace headers wholesale to keep duplicates (e.g. set-cookie) and upstream order.
    response.raw_headers = filter_response_headers(list(upstream.headers.raw))
    return response
