from __future__ import annotations

import csv
import importlib.util
import shutil
from pathlib import Path

import pytest
import yaml

HARNESS = Path(__file__).resolve().parents[1]
REPO = HARNESS.parents[1]
GATEWAY = REPO / "backend" / "gateway"
PLATFORM = REPO / "backend" / "platform-api"
DATASETS = HARNESS / "datasets"

CONCRETE_MODELS = {"opus": "claude-opus-test", "sonnet": "claude-sonnet-test", "openai": "gpt-test",
                   "sandbox_claude_candidate": "claude-candidate-test", "sandbox_openai_candidate": "gpt-candidate-test"}


def load_fiddler_fakes():
    """sdk/python's FakeFiddler (fiddler-evals patched at its HTTP boundary), loaded by path."""
    spec = importlib.util.spec_from_file_location("aig_sdk_fiddler_fakes", REPO / "sdk" / "python" / "tests" / "fiddler_fakes.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture
def gateway_root(tmp_path):
    """A copy of backend/gateway with concrete model ids (the manifests are edited by aigw canary)."""
    dst = tmp_path / "gateway"
    shutil.copytree(GATEWAY, dst, ignore=shutil.ignore_patterns("tool", ".venv", "__pycache__"))
    shutil.copytree(REPO / "backend" / "contracts", tmp_path / "contracts", ignore=shutil.ignore_patterns(".venv", "__pycache__"))
    for env in ("local", "dev", "stage", "prod"):
        p = dst / "envs" / f"{env}.yaml"
        doc = yaml.safe_load(p.read_text())
        doc["models"] = dict(CONCRETE_MODELS)
        doc["cache_compress"] = {"host": "https://cache-compress.aig.example.com"}
        p.write_text(yaml.safe_dump(doc, sort_keys=False))
    return dst


def expected_answers() -> dict[str, str]:
    out = {}
    for f in (DATASETS / "benchmarks").glob("*.csv"):
        for row in csv.DictReader(f.open()):
            out[row["input"]] = row["expected_output"].split("|")[0]
    return out
