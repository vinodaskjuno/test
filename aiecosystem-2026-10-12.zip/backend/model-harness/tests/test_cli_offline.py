"""aig-model eval --offline: no network, clearly labelled, never posted."""

from __future__ import annotations

import json
import shutil

import respx
from aig_model_harness import cli
from conftest import DATASETS


def test_offline_eval_writes_labelled_reports_and_touches_no_network(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("AIG_PLATFORM_API_URL", raising=False)
    out = tmp_path / "card.json"
    with respx.mock(assert_all_mocked=True, assert_all_called=False) as router:
        code = cli.main(["eval", "--model", "anthropic/claude-sonnet-next@2026-10", "--offline", "--tiers",
                         "standard,premium", "--out", str(out)])
        assert not router.calls
    printed = capsys.readouterr().out
    assert code == 0 and printed.startswith("OFFLINE scorecard: PASSED") and "not posted" in printed
    report = json.loads(out.read_text())
    assert report["offline"] is True and report["mode"] == "offline" and report["scorecard"]["mode"] == "offline"
    card = report["scorecard"]
    assert card["accuracy"] == 1.0 and card["safety_critical_failures"] == 0 and set(card["tiers"]) == {"premium", "standard"}
    assert len(card["cases"]) == 34 + 32 and {d["classification"] for d in card["datasets"]} == {"synthetic"}
    assert card["tiers"]["standard"]["baseline_model"] == "<claude-sonnet-model-id>"  # dev routing (placeholders)
    md = out.with_suffix(".md").read_text()
    assert md.startswith("> **OFFLINE RUN**") and "Case-by-case vs baseline" in md


def test_offline_profiles_suites_and_baseline_file(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("AIG_PLATFORM_API_URL", raising=False)
    base = tmp_path / "baseline.json"
    base.write_text(json.dumps({"<claude-sonnet-model-id>": {
        "accuracy": 1.0, "faithfulness": 0.99, "latency_p95_ms": 100, "cost_per_1k_usd": 0.001,
        "safety_critical_failures": 0, "cases": [{"id": "cl-01", "suite": "claims", "suite_kind": "benchmark",
                                                  "profile": "claims", "passed": True}]}}))
    out = tmp_path / "c.json"
    code = cli.main(["eval", "--model", "anthropic/x@1", "--offline", "--profiles", "claims", "--suites", "benchmark",
                     "--baseline-file", str(base), "--out", str(out)])
    report = json.loads(out.read_text())
    assert code == 1  # faithfulness below the baseline's 0.99
    assert [d["name"] for d in report["scorecard"]["datasets"]] == ["claims"]
    assert any("faithfulness" in f for f in report["gate"]["tiers"]["standard"]["failures"])
    assert report["case_diff"]["standard"]["unchanged"] == 1
    capsys.readouterr()


def test_offline_post_and_bad_arguments_exit_2(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("AIG_PLATFORM_API_URL", raising=False)
    assert cli.main(["eval", "--model", "anthropic/x@1", "--offline", "--post"]) == 2
    assert cli.main(["eval", "--model", "not-a-spec", "--offline"]) == 2
    assert cli.main(["eval", "--model", "anthropic/x@1", "--offline", "--profiles", "hr"]) == 2
    root = tmp_path / "ds"
    shutil.copytree(DATASETS, root)
    (root / "benchmarks" / "general.meta.yaml").write_text("classification: confidential\n")
    assert cli.main(["eval", "--model", "anthropic/x@1", "--offline", "--datasets", str(root),
                     "--out", str(tmp_path / "x.json")]) == 2
    assert "dataset_classification_refused" in capsys.readouterr().err


def test_online_needs_platform_api(capsys, monkeypatch):
    monkeypatch.delenv("AIG_PLATFORM_API_URL", raising=False)
    assert cli.main(["eval", "--model", "m-1"]) == 2
    assert "AIG_PLATFORM_API_URL" in capsys.readouterr().err
