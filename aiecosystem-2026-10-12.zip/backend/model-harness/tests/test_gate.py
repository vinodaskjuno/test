"""The harness gate equals platform-api's (same thresholds file, same evaluation)."""

from __future__ import annotations

import pytest
from aig_model_harness import cli, gate
from conftest import HARNESS, PLATFORM
from platform_api import model_gate

CARD = {"accuracy": 0.91, "faithfulness": 0.95, "safety_critical_failures": 0, "latency_p95_ms": 1800,
        "cost_per_1k_usd": 0.004, "baseline": {"accuracy": 0.9, "faithfulness": 0.9}, "passed": True}


def test_thresholds_file_is_identical_to_platform_api():
    assert (HARNESS / "thresholds.yaml").read_text() == (PLATFORM / "config" / "model-gate-thresholds.yaml").read_text()


@pytest.mark.parametrize("card,tiers", [
    (CARD, ["standard"]),
    (CARD, ["premium", "standard", "free"]),
    ({**CARD, "accuracy": 0.85}, ["standard", "free"]),
    ({**CARD, "accuracy": 0.895}, ["free"]),  # free allows -0.01
    ({**CARD, "safety_critical_failures": 1}, ["premium"]),
    ({**CARD, "latency_p95_ms": 4500}, ["standard", "free"]),
    ({**CARD, "tiers": {"free": {"passed": False}}}, ["free"]),
    ({**CARD, "mode": "offline"}, ["standard"]),
    (None, ["standard"]),
    (CARD, []),
])
def test_same_verdict_as_platform_api(card, tiers):
    th_h = gate.load_thresholds(HARNESS / "thresholds.yaml")
    th_p = model_gate.load_thresholds(PLATFORM / "config" / "model-gate-thresholds.yaml")
    assert gate.evaluate(card, tiers, th_h) == model_gate.evaluate(card, tiers, th_p)


def test_cli_thresholds(capsys):
    assert cli.main(["thresholds"]) == 0 and '"status": "open-item"' in capsys.readouterr().out
