"""Synthetic datasets and the sandbox data policy (synthetic | masked only)."""

from __future__ import annotations

import shutil

import pytest
from aig_model_harness import cli
from aig_model_harness.datasets import (JOB_PROFILES, SAFETY_CATEGORIES, DatasetPolicyError, check_policy,
                                        classification_of, load_suites)
from aig_sdk.evals.config import EvalConfigError
from conftest import DATASETS


def test_committed_datasets_meet_the_minimums(tmp_path):
    suites = load_suites(None, profiles=list(JOB_PROFILES), suites=["benchmark", "safety"], tmp_dir=tmp_path)
    counts = {(s.kind, s.name): s.cases for s in suites}
    for p in JOB_PROFILES:
        assert counts[("benchmark", p)] >= 8
    for c in SAFETY_CATEGORIES:
        assert counts[("safety", c)] >= 10
    assert {s.classification for s in suites} == {"synthetic"}
    ids = [i.extras["case_id"] for s in suites for i in s.loaded.items]
    assert len(ids) == len(set(ids))
    for s in suites:
        if s.kind == "safety":
            assert all(i.extras["severity"] in ("critical", "major", "minor") for i in s.loaded.items)


def _copy(tmp_path):
    dst = tmp_path / "datasets"
    shutil.copytree(DATASETS, dst)
    return dst


@pytest.mark.parametrize("meta", ["classification: confidential\n", "classification: internal\n", "owner: x\n"])
def test_unclassified_or_production_data_is_refused(tmp_path, meta):
    root = _copy(tmp_path)
    (root / "benchmarks" / "claims.meta.yaml").write_text(meta)
    with pytest.raises(DatasetPolicyError, match="dataset_classification_refused"):
        load_suites(root, profiles=["claims"], suites=["benchmark"], tmp_dir=tmp_path / "t")


def test_missing_sidecar_without_header_is_refused(tmp_path):
    root = _copy(tmp_path)
    (root / "safety" / "jailbreak.meta.yaml").unlink()
    with pytest.raises(DatasetPolicyError):
        check_policy(root / "safety" / "jailbreak.csv")


def test_first_line_header_is_accepted_and_stripped(tmp_path):
    root = _copy(tmp_path)
    csv_path = root / "benchmarks" / "general.csv"
    (root / "benchmarks" / "general.meta.yaml").unlink()
    csv_path.write_text("# aig-data-classification: masked\n" + csv_path.read_text())
    assert classification_of(csv_path) == ("masked", True)
    (suite,) = load_suites(root, profiles=["general"], suites=["benchmark"], tmp_dir=tmp_path / "t")
    assert suite.classification == "masked" and suite.cases == 8


def test_bad_rows_are_configuration_errors(tmp_path):
    root = _copy(tmp_path)
    p = root / "safety" / "jailbreak.csv"
    p.write_text(p.read_text().replace(",critical\n", ",catastrophic\n", 1))
    with pytest.raises(EvalConfigError, match="severity"):
        load_suites(root, profiles=[], suites=["safety"], categories=["jailbreak"], tmp_dir=tmp_path / "t")


def test_cli_datasets_and_policy_exit_code(tmp_path, capsys):
    assert cli.main(["datasets"]) == 0 and "every one synthetic or masked" in capsys.readouterr().out
    root = _copy(tmp_path)
    (root / "safety" / "data_leakage.meta.yaml").write_text("classification: restricted\n")
    assert cli.main(["datasets", "--datasets", str(root)]) == 2
    assert "dataset_classification_refused" in capsys.readouterr().err
