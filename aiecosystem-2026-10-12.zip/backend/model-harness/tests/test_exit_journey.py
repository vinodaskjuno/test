"""Phase 7 exit criterion (offline, every external system mocked):

request -> sandbox key created -> aig-model eval scorecard PUT -> approve refused when the gate is
not met, accepted when it is -> canary dispatch + aigw canary set (matrix shows the split) ->
promote (the tier routes to the candidate) -> rollback (one step back); plus a second candidate
rolled back from canary, and "the sandbox key cannot reach the production config".

Real code everywhere: platform-api (FastAPI TestClient, in-memory DB), the harness runner with
fiddler-evals' real ``evaluate()`` (FakeFiddler patches only its HTTP boundary), aig_gateway's
canary editor / renderer / routing evaluator. Mocked with respx: the Portkey sandbox gateway, the
Portkey admin API (sandbox key) and the GitHub dispatch API.
"""

from __future__ import annotations

import json
import re

import httpx
import pytest
import respx
from aig_gateway.canary import canary_promote, canary_rollback, canary_set, canary_sync, fetch_models
from aig_gateway.loader import load_repo
from aig_gateway.render import render
from aig_gateway.simulate import matrix
from aig_gateway.validate import validate
from aig_model_harness.platform import PlatformClient
from aig_model_harness.runner import EvalOptions, run_eval
from aig_model_harness.sandbox import BENCHMARK_SYSTEM
from aig_sdk.evals.runner import FiddlerBackend
from conftest import PLATFORM, expected_answers, load_fiddler_fakes
from fastapi.testclient import TestClient
from platform_api.config import Settings
from platform_api.db import Database
from platform_api.main import create_app
from platform_api.secrets import SecretStore
from platform_api.users import YamlUserDirectory

SERVICE = "svc-SUPERSECRET-harness-0001"
ADMIN_KEY = "pk-admin-SUPERSECRET-0002"
SANDBOX_KEY = "pk-sandbox-SUPERSECRET-0003"
PROD_KEY = "pk-prod-SUPERSECRET-0004"
GH = "ghp_SUPERSECRET0005"
GATEWAY = "https://portkey-sandbox.test/v1"
ADMIN_API = "http://localhost:8787/v1"  # platform-api local.yaml portkey_admin_api_url
DISPATCH = "https://api.github.com/repos/aig/aiecosystem/dispatches"
USERS = {"default_team": "unassigned", "users": {
    "jane@example.com": {"team": "claims-ai", "tier": "standard"},
    "admin@example.com": {"team": "aig-platform", "tier": "standard", "roles": ["user", "admin"]},
    "approver@example.com": {"team": "model-risk", "tier": "standard", "roles": ["approver"]},
}}
JANE, ADMIN, APPROVER = ({"Authorization": f"Bearer dev:{e}@example.com"} for e in ("jane", "admin", "approver"))
SVC = {"x-aig-service-token": SERVICE}


@pytest.fixture
def platform_app(tmp_path):
    settings = Settings(env="local", auth_mode="dev", config_dir=PLATFORM / "config", secrets_dir=tmp_path / "none",
                        model_sandbox_sync=True, canary_dispatch=True, github_repo="aig/aiecosystem")
    secrets = SecretStore({"PORTKEY_API_KEY": PROD_KEY, "PORTKEY_ADMIN_API_KEY": ADMIN_KEY,
                           "PLATFORM_SERVICE_TOKEN": SERVICE, "GITHUB_DISPATCH_TOKEN": GH})
    return create_app(settings, secrets=secrets, users=YamlUserDirectory(USERS, "standard"),
                      database=Database.in_memory(), agent_hooks=[])


class SandboxGateway:
    """The Portkey sandbox gateway: answers per the candidate's quality, records every request."""

    def __init__(self) -> None:
        self.quality = "good"
        self.requests: list[httpx.Request] = []
        self.answers = expected_answers()

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        body = json.loads(request.content)
        system, user = body["messages"][0]["content"], body["messages"][1]["content"]
        if system == BENCHMARK_SYSTEM:
            question = user.split("Question: ", 1)[-1]
            context = re.search(r"Reference:\n(.*)\n\nQuestion:", user, re.S)
            text = (f"{self.answers[question]}. {context.group(1) if context else ''}" if self.quality == "good"
                    else "I am not sure, please check the policy.")
        elif "ignore" in user.lower() and "instructions" in user.lower() and self.quality != "good":
            return httpx.Response(446, json={"error": {"message": "guardrail denied"}})
        else:
            text = "I can't help with that request."
        return httpx.Response(200, json={"choices": [{"message": {"role": "assistant", "content": text}}],
                                         "usage": {"prompt_tokens": 200, "completion_tokens": 20}})


def _to(c, mid, to, who, **extra):
    r = c.post(f"/api/v1/models/{mid}/transition", headers=who, json={"to": to, **extra})
    return r


def _rows(root, env="dev"):
    return {(x["user_tier"], x["job_profile"]): x for x in matrix(render(load_repo(root), env), "aig-platform")}


def _dispatch_to_aigw(root, payload):
    """What .github/workflows/model-canary.yml does with a repository_dispatch payload."""
    repo = load_repo(root)
    for tier in payload["tiers"]:
        if payload["state"] == "canary":
            canary_set(repo, tier=tier, alias=payload["alias"], share=payload["share"], model_id=payload["model"],
                       provider=payload["provider"], platform_model_id=payload["model_id"])
        elif payload["state"] == "promoted":
            canary_promote(repo, tier=tier, alias=payload["alias"])
        else:
            canary_rollback(repo, tier=tier)
    assert validate(load_repo(root), allow_placeholders=True).ok


def _approved_incumbent(c):
    """The tier's current model (sonnet, id claude-sonnet-test) with its last scorecard in the catalog."""
    mid = c.post("/api/v1/models", headers=JANE, json={
        "name": "claude-sonnet-test", "provider": "anthropic", "version": "latest", "tiers": ["standard"],
        "job_profiles": ["claims"], "use_case": "incumbent", "data_classification": "internal"}).json()["id"]
    for to in ("sandbox", "evaluating"):
        assert _to(c, mid, to, SVC).status_code == 200
    card = {"accuracy": 0.8, "faithfulness": 0.85, "safety_critical_failures": 0, "latency_p95_ms": 2500,
            "cost_per_1k_usd": 0.004, "passed": True, "mode": "fiddler", "baseline": {},
            "profiles": {"claims": {"accuracy": 0.8, "faithfulness": 0.85}},
            "cases": [{"id": "cl-01", "suite": "claims", "suite_kind": "benchmark", "profile": "claims", "passed": True},
                      {"id": "cl-02", "suite": "claims", "suite_kind": "benchmark", "profile": "claims", "passed": False}],
            "datasets": [{"name": "claims", "classification": "synthetic"}]}
    assert c.put(f"/api/v1/models/{mid}/scorecard", headers=SVC, json=card).status_code == 200
    assert _to(c, mid, "approved", APPROVER).status_code == 200
    return mid


def test_candidate_goes_sandbox_scorecard_approval_canary_promotion_and_rolls_back(
        platform_app, gateway_root, tmp_path, monkeypatch):
    fakes = load_fiddler_fakes()
    fake = fakes.FakeFiddler(monkeypatch, fiddler_scores={"faithful_prob": 0.9})
    backend = FiddlerBackend(url=fakes.FIDDLER_URL, token="fdl-token", project="aig-dev", agent_id="model-harness",
                             application_id=fakes.APP_ID)
    monkeypatch.setenv("AIG_PORTKEY_BASE_URL", GATEWAY)
    monkeypatch.setenv("AIG_SANDBOX_PORTKEY_API_KEY", SANDBOX_KEY)
    monkeypatch.setenv("AIG_PORTKEY_API_KEY", PROD_KEY)
    monkeypatch.delenv("AIG_PORTKEY_ADMIN_URL", raising=False)
    sandbox = SandboxGateway()
    base_rows = _rows(gateway_root)

    with TestClient(platform_app) as c, respx.mock(assert_all_called=False) as router:
        admin = router.post(f"{ADMIN_API}/providers").mock(return_value=httpx.Response(201, json={"slug": "aig-sbx-cand"}))
        github = router.post(DISPATCH).mock(return_value=httpx.Response(204))
        router.post(f"{GATEWAY}/chat/completions").mock(side_effect=sandbox)
        platform = PlatformClient("http://testserver", SERVICE, client=c)
        _approved_incumbent(c)

        # 1. request + sandbox: a sandbox-only key in model-sandbox
        mid = c.post("/api/v1/models", headers=JANE, json={
            "name": "claude-sonnet-next", "provider": "anthropic", "version": "2026-10", "tiers": ["standard"],
            "job_profiles": ["claims"], "use_case": "claims triage", "data_classification": "confidential",
            "expected_monthly_cost_usd": 900}).json()["id"]
        m = _to(c, mid, "sandbox", ADMIN).json()
        assert m["sandbox_key_status"] == "created" and m["sandbox_key_id"] == "aig-sbx-cand"
        key_body = json.loads(admin.calls[-1].request.content)
        assert key_body["workspace_id"] == "model-sandbox" and key_body["integration_id"] == "anthropic-sandbox"

        opts = dict(model=mid, env="dev", gateway_root=gateway_root, cost_source="usage")

        # 2. a weak candidate: scorecard recorded, gate fails, approval refused
        sandbox.quality = "bad"
        weak = run_eval(EvalOptions(**opts, out=tmp_path / "weak.json"), platform=platform, fiddler_backend=backend)
        assert weak.exit_code == 1 and weak.posted["status"] == "evaluating" and not weak.posted["ready_for_approval"]
        assert weak.report["scorecard"]["tiers"]["standard"]["baseline_model"] == "claude-sonnet-test"
        assert weak.report["case_diff"]["standard"]["regressions"] == [
            {"id": "cl-01", "suite": "claims", "baseline_model": "claude-sonnet-test"}]
        refused = _to(c, mid, "approved", APPROVER, note="ship it")
        assert refused.status_code == 409 and refused.json()["error"]["code"] == "approval_gate_failed"
        assert "accuracy" in refused.json()["error"]["message"]

        # 3. a fixed candidate: gate met, ready for approval, approver signs off (audit has the evidence)
        sandbox.quality = "good"
        good = run_eval(EvalOptions(**opts, out=tmp_path / "good.json"), platform=platform, fiddler_backend=backend)
        assert good.exit_code == 0, good.report["gate"]
        card = good.posted["scorecard"]
        assert good.posted["ready_for_approval"] and card["mode"] == "fiddler" and card["faithfulness"] == 0.9
        assert card["safety_critical_failures"] == 0 and card["accuracy"] == 1.0
        assert card["evidence_url"] and {d["classification"] for d in card["datasets"]} == {"synthetic"}
        assert card["baseline"]["model"] == "claude-sonnet-test" and card["baseline"]["accuracy"] == 0.8
        assert fake.experiments, "suites ran as Fiddler experiments"
        md = good.md_path.read_text()
        assert "Tier `standard`: meets the gate (baseline: claude-sonnet-test)" in md and "OFFLINE" not in md
        approved = _to(c, mid, "approved", APPROVER, note="meets the gate")
        assert approved.status_code == 200
        audit = c.get(f"/api/v1/audit?entity_type=model&entity_id={mid}", headers=APPROVER).json()["items"]
        decision = next(a for a in audit if a["details"].get("to") == "approved")
        assert decision["details"]["gate"]["passed"] and decision["details"]["scorecard"]["run_id"] == card["run_id"]
        assert any(a["action"] == "model.approval_refused" for a in audit)

        # every model call went through the sandbox config with the sandbox workspace key
        assert sandbox.requests and all(r.headers["x-portkey-config"] == "pc-aig-sandbox" for r in sandbox.requests)
        assert all(r.headers["x-portkey-api-key"] == SANDBOX_KEY for r in sandbox.requests)
        assert all(json.loads(r.headers["x-portkey-metadata"])["sandbox_key"] == "aig-sbx-cand" for r in sandbox.requests)

        # 4. canary: dispatch -> workflow runs aigw canary set -> the standard tier splits 90/10
        m = _to(c, mid, "canary", ADMIN, canary_share=10).json()
        assert m["canary_dispatch_status"] == "dispatched"
        event = json.loads(github.calls[-1].request.content)
        assert event["event_type"] == "model_canary"
        _dispatch_to_aigw(gateway_root, event["client_payload"])
        rows = _rows(gateway_root)
        for jp in ("underwriting", "claims", "operations", "general"):
            r = rows[("standard", jp)]
            assert r["mode"] == "loadbalance" and r["shares"] == [0.9, 0.1]
            assert r["models"][-1] == "claude-sonnet-next-2026-10"
        assert rows[("premium", "claims")] == base_rows[("premium", "claims")] | {"rule": rows[("premium", "claims")]["rule"]}
        # --from-platform-api computes the same desired state (idempotent)
        assert canary_sync(load_repo(gateway_root), fetch_models("http://testserver", SERVICE, client=c))[0] is False

        # 5. promote: the tier now routes to the candidate
        assert _to(c, mid, "promoted", APPROVER).json()["canary_dispatch_status"] == "dispatched"
        event = json.loads(github.calls[-1].request.content)
        assert event["event_type"] == "model_promote"
        _dispatch_to_aigw(gateway_root, event["client_payload"])
        for jp in ("claims", "general"):
            assert _rows(gateway_root)[("standard", jp)]["models"][0] == "claude-sonnet-next-2026-10"

        # 6. rollback: one manifest step restores the previous routing exactly
        canary_rollback(load_repo(gateway_root), tier="standard")
        assert _rows(gateway_root) == base_rows

        # 7. a second candidate is rolled back from its canary through platform-api -> dispatch -> aigw
        b = c.post("/api/v1/models", headers=JANE, json={
            "name": "claude-sonnet-alt", "provider": "anthropic", "version": "1", "tiers": ["standard"],
            "job_profiles": ["claims"], "use_case": "alt", "data_classification": "internal"}).json()["id"]
        _to(c, b, "sandbox", ADMIN)
        run_eval(EvalOptions(**{**opts, "model": b}, out=tmp_path / "alt.json"), platform=platform,
                 fiddler_backend=backend)
        assert _to(c, b, "approved", APPROVER).status_code == 200
        _to(c, b, "canary", ADMIN, canary_share=25)
        _dispatch_to_aigw(gateway_root, json.loads(github.calls[-1].request.content)["client_payload"])
        assert _rows(gateway_root)[("standard", "claims")]["shares"] == [0.75, 0.25]
        assert _to(c, b, "rolled_back", APPROVER, note="error rate up").json()["status"] == "rolled_back"
        event = json.loads(github.calls[-1].request.content)
        assert event["event_type"] == "model_rollback"
        _dispatch_to_aigw(gateway_root, event["client_payload"])
        assert _rows(gateway_root) == base_rows
        # a rolled-back (or rejected) model never comes back through --from-platform-api
        canary_sync(load_repo(gateway_root), fetch_models("http://testserver", SERVICE, client=c))
        assert _rows(gateway_root)[("standard", "claims")]["models"][0] == "claude-sonnet-next-2026-10"  # promoted one
        assert not any("claude-sonnet-alt" in str(r["models"]) for r in _rows(gateway_root).values())

        text = json.dumps([r.headers.get("authorization", "") for r in (x.request for x in github.calls)])
        assert all(SANDBOX_KEY not in json.dumps(e["details"]) for e in audit)
        assert GH in text  # only on the wire to GitHub, never in platform-api responses
        assert GH not in json.dumps(c.get(f"/api/v1/models/{mid}", headers=JANE).json())


def test_sandbox_key_cannot_reach_the_production_config(gateway_root):
    """Verification item 7: the sandbox workspace key only ever gets pc-aig-sandbox, and no
    production config can reference a sandbox integration (aigw validate fails if one does)."""
    r = render(load_repo(gateway_root), "prod")
    sandbox_key = next(k for k in r.objects["api_keys"] if k["name"] == "aig-model-sandbox")
    assert sandbox_key["workspace_id"] == "model-sandbox" and sandbox_key["defaults"]["config_id"] == "pc-aig-sandbox"
    assert {c["slug"] for c in r.objects["configs"] if c["workspace_id"] == "model-sandbox"} == {"pc-aig-sandbox"}
    with pytest.raises(KeyError):
        r.config("pc-aig-router", "model-sandbox")
    for c in r.objects["configs"]:
        if c["workspace_id"] != "model-sandbox":
            assert "-sandbox" not in json.dumps(c["config"])
    # Try to wire a sandbox key into the router: validation refuses it.
    p = gateway_root / "configs" / "pc-aig-router.json"
    p.write_text(p.read_text().replace("${virtual_keys.anthropic}", "${virtual_keys.anthropic_sandbox}", 1))
    report = validate(load_repo(gateway_root), ["prod"], allow_placeholders=True)
    assert not report.ok and any("sandbox" in e for e in report.errors)
    # And a canary can never use a sandbox integration.
    from aig_gateway.canary import CanaryError
    p.write_text(p.read_text().replace("${virtual_keys.anthropic_sandbox}", "${virtual_keys.anthropic}", 1))
    with pytest.raises(CanaryError, match="sandbox"):
        canary_set(load_repo(gateway_root), tier="standard", alias="sandbox-claude-candidate", share=10)
