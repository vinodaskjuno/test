"""aig-model: the AIG model harness CLI.

  aig-model eval --model ID [--profiles all|underwriting,...] [--suites benchmark,safety]
                 [--offline] [--no-post] [--env ENV] [--out F.json] [--md F.md] ...
  aig-model datasets [--datasets DIR]          check the sandbox data policy and list the suites
  aig-model thresholds [--thresholds FILE]     validate and print the gate thresholds

Exit codes (eval): 0 every requested tier meets its thresholds; 1 the gate fails; 2 nothing was
judged (configuration, data policy, infrastructure). ``--offline`` uses a simulated model (no
Portkey, no Fiddler), is labelled OFFLINE everywhere and never posts (``--offline --post`` = 2).
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

from aig_sdk.evals.config import EvalConfigError

from .datasets import JOB_PROFILES, DatasetPolicyError, load_suites
from .gate import DEFAULT_THRESHOLDS, load_thresholds
from .platform import HarnessError
from .sandbox import SandboxError


def cmd_eval(args) -> int:
    from .runner import EvalOptions, run_eval

    if args.offline and args.post:
        print("error: --offline results are never posted (drop --post)", file=sys.stderr)
        return 2
    opts = EvalOptions(model=args.model, profiles=args.profiles, suites=args.suites, categories=args.categories,
                       offline=args.offline, post=not args.no_post and not args.offline, env=args.env or "dev",
                       tiers=args.tiers, datasets=args.datasets, thresholds=args.thresholds, prices=args.prices,
                       gateway_root=args.gateway_root, routing_config=args.routing_config,
                       baseline_file=args.baseline_file, out=args.out, md=args.md, cost_source=args.cost_source,
                       platform_api_url=args.platform_api_url)
    result = run_eval(opts)
    gate = result.report["gate"]
    label = "OFFLINE " if result.report["offline"] else ""
    tiers = ", ".join(f"{t}={'ok' if r['passed'] else 'fail'}" for t, r in gate["tiers"].items())
    print(f"{label}scorecard: {'PASSED' if gate['passed'] else 'FAILED'} (tiers: {tiers})")
    print(f"report: {result.json_path} / {result.md_path}")
    if result.posted is not None:
        print(f"posted to platform-api: model {result.posted['id']} is {result.posted['status']}"
              f"{' (ready for approval)' if result.posted.get('ready_for_approval') else ''}")
    elif result.report["offline"]:
        print("OFFLINE run: not posted to platform-api")
    return result.exit_code


def cmd_datasets(args) -> int:
    suites = load_suites(args.datasets, profiles=list(JOB_PROFILES), suites=["benchmark", "safety"],
                         tmp_dir=Path(tempfile.mkdtemp(prefix="aig-model-")))
    for s in suites:
        print(f"{s.kind:<10} {s.name:<18} {s.classification:<10} {s.cases:>3} cases  {s.path.name}")
    print(f"datasets: OK ({len(suites)} suites, every one synthetic or masked)")
    return 0


def cmd_thresholds(args) -> int:
    print(json.dumps(load_thresholds(args.thresholds or DEFAULT_THRESHOLDS), indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="aig-model", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("eval", help="evaluate a candidate model in the sandbox and record its scorecard")
    e.add_argument("--model", required=True, help="platform-api model id (offline without platform-api: provider/name@version)")
    e.add_argument("--profiles", help="all | comma list of job profiles (default: the model's job profiles, else all)")
    e.add_argument("--suites", default="benchmark,safety")
    e.add_argument("--categories", help="safety categories (default: prompt_injection,jailbreak,data_leakage)")
    e.add_argument("--tiers", help="override the tiers to gate (default: the model's tiers)")
    e.add_argument("--offline", action="store_true", help="simulated model, no Portkey/Fiddler, never posted")
    e.add_argument("--post", action="store_true", help=argparse.SUPPRESS)
    e.add_argument("--no-post", action="store_true", help="do not record the scorecard in platform-api")
    e.add_argument("--env", help="gateway env whose routing gives the baseline (default AIG_ENV or dev)")
    e.add_argument("--datasets", type=Path)
    e.add_argument("--thresholds", type=Path)
    e.add_argument("--prices", type=Path)
    e.add_argument("--gateway-root", type=Path, help="backend/gateway (default: auto / AIGW_ROOT)")
    e.add_argument("--routing-config", type=Path, help="JSON from `aigw render --env ENV --kind configs`")
    e.add_argument("--baseline-file", type=Path, help="JSON {routing_model_id: scorecard} (offline baselines)")
    e.add_argument("--out", type=Path)
    e.add_argument("--md", type=Path)
    e.add_argument("--cost-source", choices=("auto", "portkey", "usage"), default="auto")
    e.add_argument("--platform-api-url")
    e.set_defaults(func=cmd_eval)
    d = sub.add_parser("datasets", help="check the sandbox data policy for every dataset")
    d.add_argument("--datasets", type=Path)
    d.set_defaults(func=cmd_datasets)
    t = sub.add_parser("thresholds", help="validate and print the gate thresholds")
    t.add_argument("--thresholds", type=Path)
    t.set_defaults(func=cmd_thresholds)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if getattr(args, "env", None) is None and args.cmd == "eval":
        import os

        args.env = os.environ.get("AIG_ENV", "dev")
    try:
        return args.func(args)
    except DatasetPolicyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except (HarnessError, SandboxError, EvalConfigError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # noqa: BLE001 - infrastructure (Fiddler run errors, ...): nothing judged
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
