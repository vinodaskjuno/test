"""The baseline: the model each tier routes to today, and its latest scorecard.

1. Routing: the rendered production router (``pc-aig-router`` for ``--env``) from
   backend/gateway via ``aig_gateway`` (or ``--routing-config``, the JSON ``aigw render --env X
   --kind configs`` prints). For a tier and job profile, the baseline model is the first leaf
   Portkey would try (for a tier with a running canary: the incumbent).
2. Scorecard: platform-api's latest scorecard of the catalog model whose ``routing_model_id``
   equals that model id (promoted > canary > approved, newest first), including its per-case
   results for the case-by-case diff; offline, ``--baseline-file`` (``{model_id: scorecard}``).
   No scorecard = first run for that model: only absolute limits apply (reported).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from aig_gateway.routing import resolve

ROUTER = "pc-aig-router"
STATUS_RANK = {"promoted": 0, "canary": 1, "approved": 2}


def default_gateway_root() -> Path:
    env = os.environ.get("AIGW_ROOT")
    return Path(env) if env else Path(__file__).resolve().parents[3] / "gateway"


def routing_config(env: str, *, gateway_root: Path | None = None, routing_file: Path | None = None) -> dict:
    if routing_file:
        data = json.loads(Path(routing_file).read_text())
        if "strategy" in data:
            return data
        for obj in (data.get("objects") or {}).get("configs") or []:
            if obj.get("slug") == ROUTER:
                return obj["config"]
        raise ValueError(f"{routing_file}: no {ROUTER} config")
    from aig_gateway.loader import load_repo
    from aig_gateway.render import render

    return render(load_repo(gateway_root or default_gateway_root()), env).config(ROUTER, "aig-platform")


def baseline_models(config: dict, tier: str, profiles: list[str]) -> dict[str, str | None]:
    out: dict[str, str | None] = {}
    for p in profiles:
        chain = resolve(config, {"user_tier": tier, "job_profile": p}).plan.chain()
        out[p] = chain[0].model if chain else None
    return out


def latest_cards(models: list[dict]) -> dict[str, dict]:
    """routing_model_id -> {model: catalog entry, card: scorecard} for the best catalog match."""
    usable = [m for m in models
              if m.get("routing_model_id") and m.get("scorecard") and m.get("status") in STATUS_RANK]
    usable.sort(key=lambda m: str(m["scorecard"].get("updated_at") or ""), reverse=True)  # newest first
    usable.sort(key=lambda m: STATUS_RANK[m["status"]])  # stable: best status, then newest
    out: dict[str, dict] = {}
    for m in usable:
        out.setdefault(m["routing_model_id"], {"catalog_id": m["id"], "card": m["scorecard"]})
    return out


def load_baseline_file(path: Path | None) -> dict[str, dict]:
    if not path:
        return {}
    data = json.loads(Path(path).read_text())
    return {k: {"catalog_id": None, "card": v} for k, v in data.items() if isinstance(v, dict)}


def tier_baseline(models_by_profile: dict[str, str | None], cards: dict[str, dict]) -> dict[str, Any]:
    """Baseline metrics for a tier: per-profile values of each profile's baseline model, averaged."""
    acc, faith, lat, cost, crit = [], [], [], [], []
    names = [m for m in dict.fromkeys(models_by_profile.values()) if m]
    for profile, model in models_by_profile.items():
        card = (cards.get(model or "") or {}).get("card")
        if not card:
            continue
        prof = (card.get("profiles") or {}).get(profile) or {}
        for bucket, key in ((acc, "accuracy"), (faith, "faithfulness")):
            v = prof.get(key, card.get(key))
            if isinstance(v, (int, float)):
                bucket.append(float(v))
    for model in names:
        card = (cards.get(model) or {}).get("card")
        if card:
            for bucket, key in ((lat, "latency_p95_ms"), (cost, "cost_per_1k_usd"), (crit, "safety_critical_failures")):
                if isinstance(card.get(key), (int, float)):
                    bucket.append(float(card[key]))
    mean = lambda xs: round(sum(xs) / len(xs), 6) if xs else None  # noqa: E731
    return {
        "model": ", ".join(names) or None,
        "accuracy": mean(acc), "faithfulness": mean(faith),
        "latency_p95_ms": max(lat) if lat else None, "cost_per_1k_usd": mean(cost),
        "safety_critical_failures": int(max(crit)) if crit else None,
        "has_scorecard": bool(acc or faith or lat),
    }


def baseline_cases(models_by_profile: dict[str, str | None], cards: dict[str, dict]) -> dict[str, dict]:
    """case id -> the baseline model's result for that case (benchmarks by profile, safety from the first model)."""
    out: dict[str, dict] = {}
    first = next((m for m in models_by_profile.values() if m), None)
    for model in dict.fromkeys(m for m in models_by_profile.values() if m):
        card = (cards.get(model) or {}).get("card") or {}
        for case in card.get("cases") or []:
            kind = case.get("suite_kind") or ("benchmark" if case.get("profile") else "safety")
            if kind == "benchmark" and models_by_profile.get(case.get("profile")) != model:
                continue
            if kind == "safety" and model != first:
                continue
            out[f"{case.get('suite')}:{case.get('id')}"] = {**case, "model": model}
    return out
