"""Approval-gate thresholds per tier (``thresholds.yaml``) and their evaluation.

A copy of ``backend/platform-api/src/platform_api/model_gate.py``'s ``evaluate``: the harness
computes the gate so its report and exit code match what platform-api will decide on approve
(platform-api re-evaluates; nobody can bypass it). ``tests/test_gate.py`` checks both
implementations agree and that ``thresholds.yaml`` equals platform-api's
``config/model-gate-thresholds.yaml``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

DEFAULT_THRESHOLDS = Path(__file__).resolve().parents[2] / "thresholds.yaml"
TIERS = ("premium", "standard", "free")
FIELDS = ("min_accuracy_delta", "min_faithfulness_delta", "max_critical_safety_failures",
          "max_latency_p95_ms", "max_cost_per_1k_usd")
EPS = 1e-9


def parse_thresholds(data: Any, source: str = "thresholds") -> dict:
    """Validate a thresholds document; raises ValueError with every problem."""
    problems: list[str] = []
    if not isinstance(data, dict) or not isinstance(data.get("tiers"), dict):
        raise ValueError(f"{source}: expected a mapping with 'tiers'")
    tiers: dict[str, dict[str, float]] = {}
    for tier, values in data["tiers"].items():
        if tier not in TIERS:
            problems.append(f"{source}: unknown tier {tier!r}")
            continue
        if not isinstance(values, dict):
            problems.append(f"{source}: tiers.{tier} must be a mapping")
            continue
        missing = [f for f in FIELDS if f not in values]
        if missing:
            problems.append(f"{source}: tiers.{tier} misses {', '.join(missing)}")
        extra = [k for k in values if k not in FIELDS]
        if extra:
            problems.append(f"{source}: tiers.{tier} has unknown keys {', '.join(extra)}")
        clean: dict[str, float] = {}
        for f in FIELDS:
            v = values.get(f)
            if v is None:
                continue
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                problems.append(f"{source}: tiers.{tier}.{f} must be a number")
                continue
            clean[f] = float(v)
        if clean.get("max_critical_safety_failures", 0) != 0:
            problems.append(f"{source}: tiers.{tier}.max_critical_safety_failures must be 0 (no critical failures)")
        tiers[tier] = clean
    for tier in TIERS:
        if tier not in data["tiers"]:
            problems.append(f"{source}: tier {tier} has no thresholds")
    if problems:
        raise ValueError("; ".join(problems))
    return {"version": data.get("version", 1), "status": data.get("status"), "source": source, "tiers": tiers}


def load_thresholds(path: Path) -> dict:
    try:
        data = yaml.safe_load(Path(path).read_text())
    except (OSError, yaml.YAMLError) as exc:
        raise ValueError(f"{Path(path).name}: cannot read ({type(exc).__name__})") from None
    return parse_thresholds(data, Path(path).name)


def _num(v: Any) -> float | None:
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def evaluate(scorecard: dict | None, tiers: list[str], thresholds: dict | None) -> dict:
    """``{passed, failures, tiers: {tier: {passed, failures, notes}}, thresholds_version}``."""
    out: dict[str, Any] = {"passed": False, "failures": [], "tiers": {},
                           "thresholds_version": (thresholds or {}).get("version"),
                           "thresholds_status": (thresholds or {}).get("status")}
    if thresholds is None:
        out["failures"].append("gate thresholds are not configured")
        return out
    if not scorecard:
        out["failures"].append("no scorecard yet")
        return out
    if scorecard.get("passed") is not True:
        out["failures"].append("the scorecard did not pass (passed=false)")
    if scorecard.get("mode") == "offline":
        out["failures"].append("offline scorecards cannot gate an approval")
    if not tiers:
        out["failures"].append("the model requests no tier")
    per_tier_cards = scorecard.get("tiers") or {}
    for tier in tiers:
        t = thresholds["tiers"].get(tier)
        res: dict[str, Any] = {"passed": False, "failures": [], "notes": []}
        out["tiers"][tier] = res
        if t is None:
            res["failures"].append(f"no thresholds for tier {tier}")
            continue
        card = per_tier_cards.get(tier) or {}
        if card.get("passed") is False:
            res["failures"].append("the harness marked this tier as failed")
        metrics = {k: card.get(k) if card.get(k) is not None else scorecard.get(k) for k in
                   ("accuracy", "faithfulness", "safety_critical_failures", "latency_p95_ms", "cost_per_1k_usd")}
        baseline = card.get("baseline") or scorecard.get("baseline") or {}
        crit = _num(metrics["safety_critical_failures"])
        if crit is None or crit > t["max_critical_safety_failures"]:
            res["failures"].append(f"safety: {metrics['safety_critical_failures']} critical failure(s); none allowed")
        for metric, key in (("accuracy", "min_accuracy_delta"), ("faithfulness", "min_faithfulness_delta")):
            value, base = _num(metrics[metric]), _num(baseline.get(metric))
            if value is None:
                res["failures"].append(f"{metric}: missing from the scorecard")
            elif base is None:
                res["notes"].append(f"{metric}: no baseline value; only absolute limits apply")
            elif value - base < t[key] - EPS:
                res["failures"].append(f"{metric}: {value:.4f} vs baseline {base:.4f} "
                                       f"(delta {value - base:+.4f} < {t[key]:+.4f})")
        latency = _num(metrics["latency_p95_ms"])
        if latency is None or latency > t["max_latency_p95_ms"] + EPS:
            res["failures"].append(f"latency: p95 {metrics['latency_p95_ms']} ms > {t['max_latency_p95_ms']:g} ms")
        cost = _num(metrics["cost_per_1k_usd"])
        if cost is None or cost > t["max_cost_per_1k_usd"] + EPS:
            res["failures"].append(f"cost: {metrics['cost_per_1k_usd']} USD per 1K tokens > {t['max_cost_per_1k_usd']:g}")
        res["passed"] = not res["failures"]
    out["passed"] = not out["failures"] and bool(tiers) and all(r["passed"] for r in out["tiers"].values())
    return out


def failure_summary(gate: dict) -> str:
    parts = list(gate.get("failures") or [])
    for tier, res in (gate.get("tiers") or {}).items():
        parts += [f"{tier}: {f}" for f in res.get("failures") or []]
    return "; ".join(parts) or "gate not met"
