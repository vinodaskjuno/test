"""Scorecard: metrics from the suite runs, per-tier baseline comparison, gate, JSON + Markdown.

Metrics (blueprint "Model scorecard"):

| Metric | From |
|---|---|
| accuracy | mean ``accuracy`` over benchmark cases (a failed call scores 0) |
| faithfulness | mean Fiddler ``faithful_prob`` (FTLResponseFaithfulness) when present, else local ``grounding`` |
| safety_critical_failures | red-team cases of severity ``critical`` whose answer matched the forbidden pattern (or failed) |
| latency_p95_ms | nearest-rank p95 of the sandbox call latencies |
| cost_per_1k_usd | Portkey analytics cost of the run (sandbox workspace, metadata run_id) / tokens, else usage x price table |
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import yaml

from .baseline import baseline_cases, tier_baseline
from .gate import evaluate, failure_summary

METRICS = ("accuracy", "faithfulness", "safety_critical_failures", "latency_p95_ms", "cost_per_1k_usd")
LOWER_IS_BETTER = {"safety_critical_failures", "latency_p95_ms", "cost_per_1k_usd"}
DEFAULT_PRICES = Path(__file__).resolve().parents[2] / "prices.yaml"


def p95(values: list[float]) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    return round(ordered[max(0, math.ceil(0.95 * len(ordered)) - 1)], 1)


def load_prices(path: Path | None) -> dict:
    return yaml.safe_load(Path(path or DEFAULT_PRICES).read_text()) or {}


def usage_cost(records: list, model: str, prices: dict) -> tuple[float, int]:
    price = (prices.get("models") or {}).get(model) or prices.get("default") or {"input_per_1k": 0, "output_per_1k": 0}
    cost = sum(r.prompt_tokens * price["input_per_1k"] + r.completion_tokens * price["output_per_1k"] for r in records) / 1000
    tokens = sum(r.prompt_tokens + r.completion_tokens for r in records)
    return cost, tokens


def _score(item, name: str) -> float | None:
    for s in item.scores:
        status = str(getattr(s.status, "value", s.status)).upper()
        if s.name == name and status == "SUCCESS" and s.value is not None:
            return float(s.value)
    return None


def _mean(xs: list[float]) -> float | None:
    return round(sum(xs) / len(xs), 6) if xs else None


def collect_cases(runs: list[tuple[Any, Any]], log) -> list[dict]:
    """[(Suite, DatasetRun)] -> one dict per case."""
    cases: list[dict] = []
    for suite, run in runs:
        by_source = {i.source_id: i for i in suite.loaded.items}
        for item in run.items:
            src = by_source.get(item.source_id)
            extras = src.extras if src else {}
            ok = str(item.status).upper() == "SUCCESS"
            rec = log.records.get(f"{suite.name}:{item.source_id}")
            case: dict[str, Any] = {"id": item.source_id, "suite": suite.name, "suite_kind": suite.kind,
                                    "latency_ms": round(rec.latency_ms, 1) if rec else None,
                                    "blocked": bool(rec and rec.blocked), "error": item.error}
            if suite.kind == "benchmark":
                acc = _score(item, "accuracy") if ok else 0.0
                case.update(profile=suite.name, score=acc, passed=bool(acc == 1.0),
                            grounding=_score(item, "grounding") if ok else None,
                            faithful_prob=_score(item, "faithful_prob") if ok else None)
            else:
                safe = _score(item, "safety") if ok else 0.0
                case.update(profile=None, score=safe, passed=bool(safe == 1.0), severity=extras.get("severity"),
                            category=suite.name)
            cases.append(case)
    return cases


def candidate_metrics(cases: list[dict], log, *, cost_usd: float | None, tokens: int) -> dict[str, Any]:
    bench = [c for c in cases if c["suite_kind"] == "benchmark"]
    safety = [c for c in cases if c["suite_kind"] == "safety"]
    faithful = [c["faithful_prob"] for c in bench if c.get("faithful_prob") is not None]
    grounding = [c["grounding"] for c in bench if c.get("grounding") is not None]
    latencies = [r.latency_ms for r in log.records.values() if not r.error]
    profiles: dict[str, dict] = {}
    for c in bench:
        profiles.setdefault(c["profile"], []).append(c)
    return {
        "accuracy": _mean([c["score"] or 0.0 for c in bench]) or 0.0,
        "faithfulness": _mean(faithful) if faithful else (_mean(grounding) or 0.0),
        "faithfulness_source": "fiddler:faithful_prob" if faithful else "local:grounding",
        "safety_critical_failures": sum(1 for c in safety if not c["passed"] and c.get("severity") == "critical"),
        "safety_failures": sum(1 for c in safety if not c["passed"]),
        "latency_p95_ms": p95(latencies),
        "cost_per_1k_usd": round(cost_usd / tokens * 1000, 6) if cost_usd is not None and tokens else 0.0,
        "tokens": tokens,
        "cost_usd": round(cost_usd, 6) if cost_usd is not None else None,
        "profiles": {p: {"accuracy": _mean([c["score"] or 0.0 for c in cs]),
                         "faithfulness": _mean([c["faithful_prob"] if c.get("faithful_prob") is not None
                                                else (c.get("grounding") or 0.0) for c in cs]),
                         "cases": len(cs)} for p, cs in profiles.items()},
    }


def case_diff(cases: list[dict], base: dict[str, dict]) -> dict[str, Any]:
    regressions, improvements, same, new = [], [], 0, 0
    for c in cases:
        b = base.get(f"{c['suite']}:{c['id']}")
        if b is None or b.get("passed") is None:
            new += 1
        elif b["passed"] and not c["passed"]:
            regressions.append({"id": c["id"], "suite": c["suite"], "baseline_model": b.get("model")})
        elif c["passed"] and not b["passed"]:
            improvements.append({"id": c["id"], "suite": c["suite"], "baseline_model": b.get("model")})
        else:
            same += 1
    return {"regressions": regressions, "improvements": improvements, "unchanged": same, "no_baseline": new}


def build(*, model: dict, tiers: list[str], profiles: list[str], suites: list, runs: list, log, metrics: dict,
          routing: dict[str, dict[str, str | None]], cards: dict[str, dict], thresholds: dict, mode: str,
          run_id: str, cost_source: str, evidence_url: str | None, version: str) -> dict:
    """The full report (written as JSON) and the platform-api body (``report['scorecard']``)."""
    cases = collect_cases(runs, log)
    tier_results: dict[str, dict] = {}
    diffs: dict[str, dict] = {}
    for tier in tiers:
        b = tier_baseline(routing[tier], cards)
        baseline = {k: b[k] for k in METRICS if b.get(k) is not None}
        tier_results[tier] = {"baseline_model": b["model"], "baseline": {"model": b["model"], **baseline}}
        diffs[tier] = case_diff(cases, baseline_cases(routing[tier], cards))
    card = {k: metrics[k] for k in METRICS}
    first = tier_results[tiers[0]]["baseline"] if tiers else {}
    card.update({
        "baseline": first, "passed": False, "evidence_url": evidence_url, "mode": mode, "cost_source": cost_source,
        "harness_version": version, "run_id": run_id,
        "tiers": {t: {**r} for t, r in tier_results.items()},
        "datasets": [{"name": s.name, "suite": s.kind, "classification": s.classification, "cases": s.cases,
                      "sha256": s.loaded.sha256} for s in suites],
        "profiles": metrics["profiles"],
        "cases": [{k: c.get(k) for k in ("id", "suite", "suite_kind", "profile", "passed", "score", "severity",
                                         "latency_ms", "blocked")} for c in cases],
    })
    # The verdict on the metrics alone (platform-api additionally refuses offline scorecards).
    gate = evaluate({**card, "passed": True, "mode": None}, tiers, thresholds)
    for t, res in gate["tiers"].items():
        card["tiers"][t].update(passed=res["passed"], failures=res["failures"])
    card["passed"] = bool(gate["passed"])
    return {
        "kind": "aig-model-harness-report", "version": version, "run_id": run_id, "mode": mode,
        "offline": mode == "offline",
        "model": {k: model.get(k) for k in ("id", "name", "provider", "version", "routing_model_id", "status",
                                            "sandbox_key_id", "sandbox_key_status")},
        "tiers": tiers, "profiles": profiles, "routing_baselines": routing, "metrics": metrics,
        "gate": gate, "case_diff": diffs, "cases": cases, "scorecard": card,
    }


def write_json(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, sort_keys=False, default=str) + "\n")


def _fmt(metric: str, v: Any) -> str:
    if not isinstance(v, (int, float)):
        return "—"
    if metric in ("accuracy", "faithfulness"):
        return f"{v:.3f}"
    if metric == "latency_p95_ms":
        return f"{v:.0f} ms"
    if metric == "cost_per_1k_usd":
        return f"${v:.4f}"
    return str(int(v))


def markdown(report: dict) -> str:
    card, gate, m = report["scorecard"], report["gate"], report["model"]
    lines: list[str] = []
    if report["offline"]:
        lines += ["> **OFFLINE RUN**: simulated model, no Portkey, no Fiddler. These numbers are NOT a scorecard "
                  "and are never posted to platform-api.", ""]
    verdict = "PASSED" if gate["passed"] else "FAILED"
    lines += [f"# Model scorecard: {m.get('provider')}/{m.get('name')}@{m.get('version')} ({verdict})", "",
              f"- Run `{report['run_id']}`, mode `{report['mode']}`, harness {report['version']}",
              f"- Routing model id `{m.get('routing_model_id')}`; sandbox key `{m.get('sandbox_key_id') or '-'}`",
              f"- Cost source: {card['cost_source']}; faithfulness from {report['metrics']['faithfulness_source']}",
              f"- Evidence: {card.get('evidence_url') or '-'}", ""]
    if gate["failures"]:
        lines += ["**Gate failures:** " + "; ".join(gate["failures"]), ""]
    for tier in report["tiers"]:
        t = card["tiers"][tier]
        res = gate["tiers"].get(tier, {})
        lines += [f"## Tier `{tier}`: {'meets' if res.get('passed') else 'misses'} the gate "
                  f"(baseline: {t.get('baseline_model') or 'none'})", "",
                  "| Metric | Candidate | Baseline | Change |", "|---|---:|---:|---:|"]
        for metric in METRICS:
            v, b = card.get(metric), t["baseline"].get(metric)
            change = "—"
            if isinstance(v, (int, float)) and isinstance(b, (int, float)):
                d = v - b
                better = d <= 0 if metric in LOWER_IS_BETTER else d >= 0
                change = "no change" if d == 0 else f"{'▲' if better else '▼'} {d:+.4g}"
            lines.append(f"| {metric} | {_fmt(metric, v)} | {_fmt(metric, b)} | {change} |")
        lines.append("")
        for f in res.get("failures") or []:
            lines.append(f"- FAIL: {f}")
        for n in res.get("notes") or []:
            lines.append(f"- note: {n}")
        diff = report["case_diff"][tier]
        lines += ["", f"Case-by-case vs baseline: {len(diff['regressions'])} regression(s), "
                      f"{len(diff['improvements'])} improvement(s), {diff['unchanged']} unchanged, "
                      f"{diff['no_baseline']} without a baseline result."]
        for r in diff["regressions"]:
            lines.append(f"- regression: `{r['suite']}:{r['id']}` (passed on {r['baseline_model']})")
        for r in diff["improvements"]:
            lines.append(f"- improvement: `{r['suite']}:{r['id']}`")
        lines.append("")
    lines += ["## Datasets (sandbox data policy)", "", "| Dataset | Suite | Classification | Cases |", "|---|---|---|---:|"]
    lines += [f"| {d['name']} | {d['suite']} | {d['classification']} | {d['cases']} |" for d in card["datasets"]]
    failing = [c for c in report["cases"] if not c["passed"]]
    lines += ["", f"## Failing cases ({len(failing)})", ""]
    if not failing:
        lines.append("None.")
    for c in failing:
        sev = f", severity {c['severity']}" if c.get("severity") else ""
        lines.append(f"- `{c['suite']}:{c['id']}`{sev}" + (f" (error: {c['error']})" if c.get("error") else ""))
    lines += ["", f"Gate summary: {failure_summary(gate) if not gate['passed'] else 'all requested tiers meet their thresholds'}"
              f" (thresholds v{gate.get('thresholds_version')}, status {gate.get('thresholds_status')})", ""]
    return "\n".join(lines)
