"""``aig-model eval``: run the suites for one candidate in the model sandbox and build its scorecard.

Steps: thresholds -> model (platform-api, or ``provider/name@version`` offline) -> datasets
(data policy) -> baseline (routing + latest scorecards) -> suites through fiddler-evals
(Fiddler experiments online, local runner offline) -> metrics + cost -> scorecard + gate ->
JSON/Markdown -> (online) ``sandbox -> evaluating`` and ``PUT /api/v1/models/{id}/scorecard``.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

from . import __version__
from .baseline import baseline_models, latest_cards, load_baseline_file, routing_config
from .datasets import JOB_PROFILES, SAFETY_CATEGORIES, load_suites
from .evaluators import benchmark_evaluators, safety_evaluators
from .gate import DEFAULT_THRESHOLDS, load_thresholds
from .platform import HarnessError, PlatformClient
from .sandbox import CallLog, OfflineModel, SandboxModel, make_task
from .scorecard import build, candidate_metrics, collect_cases, load_prices, markdown, usage_cost, write_json

TIERS = ("premium", "standard", "free")
SPEC_RE = re.compile(r"^(?P<provider>[A-Za-z0-9_.-]+)/(?P<name>[^@\s]+)@(?P<version>\S+)$")
HARNESS_APP = "model-harness"


@dataclass
class EvalOptions:
    model: str
    profiles: str | None = None
    suites: str = "benchmark,safety"
    categories: str | None = None
    offline: bool = False
    post: bool = True
    env: str = field(default_factory=lambda: os.environ.get("AIG_ENV", "dev"))
    tiers: str | None = None
    datasets: Path | None = None
    thresholds: Path | None = None
    prices: Path | None = None
    gateway_root: Path | None = None
    routing_config: Path | None = None
    baseline_file: Path | None = None
    out: Path | None = None
    md: Path | None = None
    cost_source: str = "auto"
    platform_api_url: str | None = None


@dataclass
class EvalResult:
    report: dict
    exit_code: int
    json_path: Path
    md_path: Path
    posted: dict | None = None


def _csv(value: str | None, allowed: tuple[str, ...], what: str) -> list[str] | None:
    if not value or value == "all":
        return None
    items = [v.strip() for v in value.split(",") if v.strip()]
    bad = [v for v in items if v not in allowed]
    if bad:
        raise HarnessError(f"unknown {what}: {', '.join(bad)} (allowed: {', '.join(allowed)})")
    return items


def _offline_model(spec: str, tiers: list[str] | None) -> dict:
    m = SPEC_RE.match(spec)
    if not m:
        raise HarnessError("offline without platform-api: --model must be provider/name@version")
    from aig_gateway.canary import provider_model_id

    return {"id": f"offline-{m['name']}", "name": m["name"], "provider": m["provider"], "version": m["version"],
            "routing_model_id": provider_model_id(m["name"], m["version"]), "tiers": tiers or ["standard"],
            "job_profiles": [], "status": "offline", "sandbox_key_status": "offline", "sandbox_key_id": None}


def portkey_cost(run_id: str, started: datetime, ended: datetime, *, client: httpx.Client | None = None) -> float:
    """Total cost (USD) of the run from Portkey analytics for the sandbox workspace (metadata run_id).
    ASSUMED endpoint/shape (verify on the self-hosted version): GET {AIG_PORTKEY_ADMIN_URL}
    {AIG_PORTKEY_COST_PATH or /analytics/graphs/cost} -> {"summary": {"total": <cents>}}."""
    base = (os.environ.get("AIG_PORTKEY_ADMIN_URL") or "").rstrip("/")
    key = os.environ.get("AIG_SANDBOX_PORTKEY_API_KEY")
    if not base or "<" in base or "__" in base or not key:
        raise HarnessError("Portkey analytics not configured (AIG_PORTKEY_ADMIN_URL, AIG_SANDBOX_PORTKEY_API_KEY)")
    path = os.environ.get("AIG_PORTKEY_COST_PATH", "/analytics/graphs/cost")
    params = {"workspace_slug": "model-sandbox", "metadata": json.dumps({"run_id": run_id}),
              "time_of_generation_min": started.isoformat(), "time_of_generation_max": ended.isoformat()}
    own = client is None
    client = client or httpx.Client(timeout=30.0)
    try:
        resp = client.get(f"{base}{path}", params=params, headers={"x-portkey-api-key": key})
    except httpx.HTTPError as exc:
        raise HarnessError(f"Portkey analytics unreachable ({type(exc).__name__})") from None
    finally:
        if own:
            client.close()
    if resp.status_code >= 400:
        raise HarnessError(f"Portkey analytics answered {resp.status_code}")
    total = ((resp.json() or {}).get("summary") or {}).get("total")
    if not isinstance(total, (int, float)):
        raise HarnessError("Portkey analytics returned no cost total")
    unit = os.environ.get("AIG_PORTKEY_COST_UNIT", "cents")
    return float(total) / 100 if unit == "cents" else float(total)


def run_eval(opts: EvalOptions, *, platform: PlatformClient | None = None, http_client: httpx.Client | None = None,
             fiddler_backend: Any = None) -> EvalResult:
    thresholds = load_thresholds(opts.thresholds or DEFAULT_THRESHOLDS)
    if platform is None:
        platform = None if opts.offline and not opts.platform_api_url and not os.environ.get("AIG_PLATFORM_API_URL") \
            else PlatformClient(opts.platform_api_url)
    requested_tiers = _csv(opts.tiers, TIERS, "tiers")
    if platform is not None:
        model = platform.get_model(opts.model)
        if requested_tiers:
            model["tiers"] = requested_tiers
    else:
        model = _offline_model(opts.model, requested_tiers)
    tiers = [t for t in TIERS if t in (model.get("tiers") or [])]
    if not tiers:
        raise HarnessError(f"model {opts.model} requests no tier")
    if not opts.offline:
        if model.get("status") not in ("sandbox", "evaluating"):
            raise HarnessError(f"model {opts.model} is {model.get('status')}: only sandbox/evaluating models are evaluated")
        if model.get("sandbox_key_status") != "created":
            raise HarnessError(f"model {opts.model} has no sandbox key (sandbox_key_status="
                               f"{model.get('sandbox_key_status')}); it never runs outside the model sandbox")
    profiles = _csv(opts.profiles, JOB_PROFILES, "job profiles") or \
        ([p for p in JOB_PROFILES if p in (model.get("job_profiles") or [])] if opts.profiles is None else None) or \
        list(JOB_PROFILES)
    suites_wanted = _csv(opts.suites, ("benchmark", "safety"), "suites") or ["benchmark", "safety"]
    categories = _csv(opts.categories, SAFETY_CATEGORIES, "safety categories")

    run_id = f"mh-{uuid.uuid4().hex[:12]}"
    tmp = Path(tempfile.mkdtemp(prefix="aig-model-"))
    suites = load_suites(opts.datasets, profiles=profiles, suites=suites_wanted, categories=categories, tmp_dir=tmp)

    config = routing_config(opts.env, gateway_root=opts.gateway_root, routing_file=opts.routing_config)
    routing = {t: baseline_models(config, t, profiles) for t in tiers}
    cards = load_baseline_file(opts.baseline_file)
    if platform is not None:
        cards = {**latest_cards(platform.list_models()), **cards}

    online = not opts.offline
    model_id = model.get("routing_model_id") or model["name"]
    if online:
        caller = SandboxModel(
            base_url=os.environ.get("AIG_PORTKEY_BASE_URL", ""), api_key=os.environ.get("AIG_SANDBOX_PORTKEY_API_KEY", ""),
            production_key=os.environ.get("AIG_PORTKEY_API_KEY"), provider=model["provider"], model=model_id,
            model_id=model["id"], sandbox_key=model.get("sandbox_key_id"), run_id=run_id, env=opts.env,
            client=http_client)
        if fiddler_backend is None:
            from aig_sdk.evals.runner import FiddlerBackend

            url, token = os.environ.get("AIG_FIDDLER_URL"), os.environ.get("AIG_FIDDLER_API_KEY")
            if not url or not token or "<" in url or "__" in url:
                raise HarnessError("Fiddler is not configured (AIG_FIDDLER_URL, AIG_FIDDLER_API_KEY)")
            fiddler_backend = FiddlerBackend(url=url, token=token, project=os.environ.get("AIG_FIDDLER_PROJECT", f"aig-{opts.env}"),
                                             agent_id=HARNESS_APP, application_id=os.environ.get("AIG_FIDDLER_APPLICATION_ID"))
    else:
        caller = OfflineModel()

    from aig_sdk.evals.runner import run_offline

    log = CallLog()
    runs = []
    evidence = None
    alias = re.sub(r"[^a-z0-9]+", "-", model_id.lower()).strip("-")[:40]
    started = datetime.now(timezone.utc)
    for suite in suites:
        if not online:
            for item in suite.loaded.items:
                item.extras["_expected"] = (item.expected_outputs or {}).get("expected_output")
        task = make_task(caller, suite.kind, log, offline=not online)
        evs = benchmark_evaluators(online) if suite.kind == "benchmark" else safety_evaluators(online)
        name = f"{alias}-{suite.name}"
        if online:
            run = fiddler_backend.run(suite.loaded.spec, suite.loaded, task, evs, name_prefix=name,
                                      description=f"model harness {suite.kind} {suite.name} for {model_id}",
                                      metadata={"run_id": run_id, "model_id": model["id"], "suite": suite.kind,
                                                "classification": suite.classification})
            evidence = evidence or run.fiddler_url
        else:
            run = run_offline(suite.loaded, task, evs, name=name)
        runs.append((suite, run))
    ended = datetime.now(timezone.utc)

    prices = load_prices(opts.prices)
    usage_usd, tokens = usage_cost(list(log.records.values()), model_id, prices)
    source = opts.cost_source
    if source == "auto":
        source = "portkey" if online and os.environ.get("AIG_PORTKEY_ADMIN_URL") else "usage"
    if source == "portkey":
        cost_usd = portkey_cost(run_id, started, ended)
        cost_label = "portkey analytics (model-sandbox, run_id)"
    else:
        cost_usd = usage_usd
        cost_label = "usage x prices.yaml" + (" (offline estimate)" if not online else "")

    metrics = candidate_metrics(collect_cases(runs, log), log, cost_usd=cost_usd, tokens=tokens)
    report = build(model=model, tiers=tiers, profiles=profiles, suites=suites, runs=runs, log=log, metrics=metrics,
                   routing=routing, cards=cards, thresholds=thresholds, mode="fiddler" if online else "offline",
                   run_id=run_id, cost_source=cost_label, evidence_url=evidence, version=__version__)
    out = Path(opts.out or Path("model-harness-reports") / f"{alias}-{run_id}.json")
    md = Path(opts.md or out.with_suffix(".md"))
    write_json(report, out)
    md.parent.mkdir(parents=True, exist_ok=True)
    md.write_text(markdown(report))

    posted = None
    if online and opts.post and platform is not None:
        if model["status"] == "sandbox":
            platform.transition(model["id"], "evaluating", note=f"model harness run {run_id}")
        posted = platform.put_scorecard(model["id"], report["scorecard"])
    return EvalResult(report, 0 if report["gate"]["passed"] else 1, out, md, posted)
