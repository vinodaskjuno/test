"""Harness datasets: benchmark suites per job profile and safety (red-team) suites, with the
sandbox data policy.

Layout (``datasets/`` next to this package's project, or ``--datasets DIR``)::

    benchmarks/<job_profile>.csv      id, input, expected_output, context
    safety/<category>.csv             id, input, expected_behavior, forbidden, severity

**Data policy** (the model sandbox is isolated and takes no production data): every file must
declare ``classification: synthetic`` or ``masked``, either in a sidecar ``<file>.meta.yaml``
or in a first-line header ``# aig-data-classification: synthetic``. Anything else (missing,
``internal``, ``confidential`` ...) is refused with ``dataset_classification_refused``.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

import yaml
from aig_sdk.evals.config import DatasetSpec, EvalConfigError
from aig_sdk.evals.datasets import LoadedDataset, load_csv

ALLOWED_CLASSIFICATIONS = ("synthetic", "masked")
JOB_PROFILES = ("underwriting", "claims", "operations", "general")
SAFETY_CATEGORIES = ("prompt_injection", "jailbreak", "data_leakage")
SEVERITIES = ("critical", "major", "minor")
HEADER_RE = re.compile(r"^#\s*aig-data-classification:\s*([A-Za-z_-]+)\s*$")
DEFAULT_DIR = Path(__file__).resolve().parents[2] / "datasets"


class DatasetPolicyError(ValueError):
    """``dataset_classification_refused``: the sandbox only takes synthetic or masked data."""

    code = "dataset_classification_refused"

    def __init__(self, message: str):
        super().__init__(f"{self.code}: {message}")


@dataclass
class Suite:
    name: str  # benchmark profile or safety category
    kind: str  # "benchmark" | "safety"
    path: Path
    classification: str
    loaded: LoadedDataset

    @property
    def cases(self) -> int:
        return len(self.loaded.items)


def classification_of(path: Path) -> tuple[str | None, bool]:
    """(classification, has_header_line)."""
    sidecar = path.with_suffix(".meta.yaml")
    if sidecar.is_file():
        meta = yaml.safe_load(sidecar.read_text()) or {}
        value = meta.get("classification") if isinstance(meta, dict) else None
        return (str(value).strip().lower() if value else None), False
    first = path.read_text(encoding="utf-8-sig").splitlines()[:1]
    m = HEADER_RE.match(first[0]) if first else None
    return (m.group(1).lower() if m else None), bool(m)


def check_policy(path: Path) -> str:
    value, _ = classification_of(path)
    if value not in ALLOWED_CLASSIFICATIONS:
        raise DatasetPolicyError(
            f"{path.name} is classified {value or 'nowhere'!s}; sandbox datasets must be synthetic or masked "
            f"(add {path.with_suffix('.meta.yaml').name} with 'classification: synthetic|masked')"
        )
    return value


def _load(path: Path, name: str, tmp_dir: Path) -> LoadedDataset:
    _, header = classification_of(path)
    source = path
    if header:  # strip the classification comment line before the CSV parser sees it
        tmp_dir.mkdir(parents=True, exist_ok=True)
        source = tmp_dir / path.name
        source.write_text("\n".join(path.read_text(encoding="utf-8-sig").splitlines()[1:]) + "\n")
    loaded = load_csv(DatasetSpec(name=name, paths=[source], pattern=str(path)))
    for item in loaded.items:  # the task sees extras, so the case id and suite travel there
        item.extras["case_id"] = item.source_id or item.id
        item.extras["suite"] = name
    return loaded


def load_suites(root: Path | None, *, profiles: list[str], suites: list[str], categories: list[str] | None = None,
                tmp_dir: Path) -> list[Suite]:
    root = Path(root or DEFAULT_DIR)
    out: list[Suite] = []
    wanted: list[tuple[str, str, Path]] = []
    if "benchmark" in suites:
        wanted += [(p, "benchmark", root / "benchmarks" / f"{p}.csv") for p in profiles]
    if "safety" in suites:
        wanted += [(c, "safety", root / "safety" / f"{c}.csv") for c in (categories or SAFETY_CATEGORIES)]
    for name, kind, path in wanted:
        if not path.is_file():
            raise EvalConfigError(f"dataset {path} not found")
        classification = check_policy(path)
        loaded = _load(path, name, tmp_dir)
        _check_columns(kind, loaded, path)
        out.append(Suite(name, kind, path, classification, loaded))
    return out


def _check_columns(kind: str, loaded: LoadedDataset, path: Path) -> None:
    for item in loaded.items:
        cid = item.extras.get("case_id")
        if kind == "benchmark" and not item.expected_outputs:
            raise EvalConfigError(f"{path.name}: case {cid} has no expected_output")
        if kind == "safety":
            forbidden = item.extras.get("forbidden")
            if not forbidden:
                raise EvalConfigError(f"{path.name}: case {cid} has no forbidden pattern")
            try:
                re.compile(forbidden)
            except re.error as exc:
                raise EvalConfigError(f"{path.name}: case {cid} has an invalid forbidden regex: {exc}") from None
            if item.extras.get("severity") not in SEVERITIES:
                raise EvalConfigError(f"{path.name}: case {cid} severity must be one of {', '.join(SEVERITIES)}")


def digest(suites: list[Suite]) -> str:
    h = hashlib.sha256()
    for s in suites:
        h.update(s.loaded.sha256.encode())
    return h.hexdigest()
