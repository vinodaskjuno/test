"""AIG model harness (Phase 7): ``aig-model eval`` evaluates a candidate model in the Portkey model
sandbox (benchmarks per job profile + red-team suites through fiddler-evals, guardrails on),
compares it with the model each tier routes to today, applies the per-tier approval-gate
thresholds and records the scorecard in platform-api. See docs/model-harness.md."""

__version__ = "0.1.0"
