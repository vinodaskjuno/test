"""platform-api client for the harness (service token ``x-aig-service-token``)."""

from __future__ import annotations

import os
from typing import Any

import httpx

URL_ENV = "AIG_PLATFORM_API_URL"
TOKEN_ENV = "AIG_PLATFORM_SERVICE_TOKEN"


class HarnessError(RuntimeError):
    """Configuration / infrastructure problem: nothing was judged (exit 2)."""


def _configured(v: str | None) -> bool:
    return bool(v) and "<" not in v and "__" not in v  # type: ignore[operator]


class PlatformClient:
    def __init__(self, url: str | None = None, token: str | None = None, *, client: httpx.Client | None = None) -> None:
        self.url = (url or os.environ.get(URL_ENV) or "").rstrip("/")
        self.token = token if token is not None else os.environ.get(TOKEN_ENV)
        if client is None and not _configured(self.url):
            raise HarnessError(f"platform-api is not configured ({URL_ENV})")
        if not self.token or self.token.startswith("__REPLACE_ME"):
            raise HarnessError(f"{TOKEN_ENV} is not set (platform-api service token)")
        self.client = client or httpx.Client(timeout=30.0)

    @classmethod
    def maybe(cls, url: str | None = None) -> "PlatformClient | None":
        """A client when platform-api is configured, else None (offline runs without platform-api)."""
        if not _configured(url or os.environ.get(URL_ENV)):
            return None
        return cls(url)

    def _call(self, method: str, path: str, json: Any = None) -> Any:
        try:
            resp = self.client.request(method, f"{self.url}{path}", json=json,
                                       headers={"x-aig-service-token": self.token or "", "accept": "application/json"})
        except httpx.HTTPError as exc:
            raise HarnessError(f"platform-api unreachable ({type(exc).__name__})") from None
        if resp.status_code >= 400:
            try:
                err = resp.json().get("error") or {}
            except ValueError:
                err = {}
            raise HarnessError(f"platform-api {method} {path} answered {resp.status_code} "
                               f"{err.get('code', '')}: {err.get('message', '')}".rstrip(": "))
        return resp.json()

    def get_model(self, model_id: str) -> dict:
        return self._call("GET", f"/api/v1/models/{model_id}")

    def list_models(self) -> list[dict]:
        return list(self._call("GET", "/api/v1/models").get("items") or [])

    def transition(self, model_id: str, to: str, note: str | None = None) -> dict:
        return self._call("POST", f"/api/v1/models/{model_id}/transition", {"to": to, "note": note})

    def put_scorecard(self, model_id: str, body: dict) -> dict:
        return self._call("PUT", f"/api/v1/models/{model_id}/scorecard", body)
