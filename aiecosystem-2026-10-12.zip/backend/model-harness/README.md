# backend/model-harness: `aig-model` (Phase 7)

Evaluates a candidate model in the **Portkey model sandbox** before it can be approved:
benchmark suites per job profile and red-team suites (prompt injection, jailbreak, data
leakage) through `fiddler-evals` with guardrails on, a scorecard compared with the model each
tier routes to today, the per-tier approval-gate thresholds, and the scorecard recorded in
platform-api. The full flow (sandbox key, approval, canary, rollback) is in
[`docs/model-harness.md`](../../docs/model-harness.md).

## Setup

```bash
make harness-setup        # .venv with aig-sdk[evals] (sdk/python), aig-gateway (backend/gateway/tool),
                          # platform-api (tests only) and this package, all editable
make harness-test         # datasets + policy, gate parity with platform-api, sandbox calls, offline CLI,
                          # exit-criterion journey
```

## Usage

```bash
.venv/bin/aig-model datasets                      # every dataset synthetic or masked? (exit 2 if not)
.venv/bin/aig-model thresholds                    # validate + print thresholds.yaml
.venv/bin/aig-model eval --model <platform-api model id> [--env dev] [--profiles all|claims,...]
                         [--suites benchmark,safety] [--categories prompt_injection,...]
                         [--tiers standard,...] [--out card.json] [--md card.md]
                         [--cost-source auto|portkey|usage] [--no-post]
.venv/bin/aig-model eval --model anthropic/claude-x@2026-10 --offline --tiers standard   # no network
```

Online, the model must be `sandbox` or `evaluating` in platform-api and have
`sandbox_key_status: created`; every call goes to `{AIG_PORTKEY_BASE_URL}/chat/completions` with
the model-sandbox workspace key and `x-portkey-config: pc-aig-sandbox` (not configurable). After
the run the harness moves the model `sandbox -> evaluating` and PUTs the scorecard; platform-api
computes the gate (`ready_for_approval`).

Exit codes: `0` gate met for every requested tier, `1` gate failed, `2` nothing judged.

## Layout

| Path | What |
|---|---|
| `datasets/benchmarks/<job_profile>.csv` | Synthetic insurance-flavoured cases (`id, input, expected_output, context`; `\|` separates accepted answers), 8-9 per profile |
| `datasets/safety/{prompt_injection,jailbreak,data_leakage}.csv` | Synthetic red-team cases (`id, input, expected_behavior, forbidden` regex, `severity` critical/major/minor), 10-11 each; the target is the synthetic customer record in `sandbox.py` |
| `datasets/**/<name>.meta.yaml` | Data policy sidecar: `classification: synthetic` (or `masked`) |
| `thresholds.yaml` | Gate thresholds per tier (**open item**; identical to platform-api's `config/model-gate-thresholds.yaml`) |
| `prices.yaml` | USD per 1K tokens for `--cost-source usage` (**open item**) |
| `src/aig_model_harness/` | `cli` (aig-model), `runner` (orchestration, Portkey cost), `sandbox` (sandbox-only model calls, offline model), `datasets` (suites + policy), `evaluators` (accuracy, grounding, safety + Fiddler built-ins), `baseline` (routing + baseline scorecards), `scorecard` (metrics, report), `gate`, `platform` |

## Environment

| Variable | Used for |
|---|---|
| `AIG_PLATFORM_API_URL`, `AIG_PLATFORM_SERVICE_TOKEN` | model lookup, baselines, transition, scorecard PUT |
| `AIG_PORTKEY_BASE_URL`, `AIG_SANDBOX_PORTKEY_API_KEY` | sandbox gateway + the model-sandbox workspace key (`aig-model-sandbox`) |
| `AIG_PORTKEY_API_KEY` | only compared: the harness refuses to run when the sandbox key equals it |
| `AIG_FIDDLER_URL`, `AIG_FIDDLER_API_KEY`, `AIG_FIDDLER_PROJECT`, `AIG_FIDDLER_APPLICATION_ID` | Fiddler experiments (application `model-harness`) |
| `AIG_PORTKEY_ADMIN_URL`, `AIG_PORTKEY_COST_PATH`, `AIG_PORTKEY_COST_UNIT` | cost from Portkey analytics (`--cost-source portkey`/`auto`) |
| `AIG_ENV`, `AIGW_ROOT` | gateway env / root for the baseline routing |
