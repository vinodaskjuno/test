# AIG telemetry-bridge (Phase 3)

Moves gateway telemetry into Fiddler and enforces "no gateway, no Fiddler, no agent":

1. **Gateway events -> Fiddler.** Pulls Portkey logs (Logs Export API, high-water mark in the
   DB) and accepts pushes (Portkey log push / webhook at `POST /ingest/portkey`, OTel export at
   `POST /v1/traces`). Each log becomes one OTLP span in the agent's Fiddler application,
   carrying prompt, reply (redacted per config), model, tokens, cost, cache hit/miss,
   guardrail results, latency, the shared tags (`agent`, `team`, `tier`, `model`, `env`,
   `host`, validated against `backend/contracts/tags.schema.json`) and the Portkey trace id as the
   OTel trace id, so it joins the SDK's spans for the same call.
2. **IDE token usage -> Fiddler.** `POST /ingest/ide-usage` (from platform-api for VS Code,
   Eclipse and the web portal; schema `backend/contracts/ide-usage-event.schema.json`).
2b. **Agent invocations -> Fiddler (W7).** `POST /ingest/invocation` (from platform-api when an
   invocation record closes; schema `backend/contracts/invocation-event.schema.json`, metadata
   only: never inputs, outputs or caller tokens). One span `aig.agent.invocation`
   (`aig.event_kind = invocation`, `fiddler.span.type = chain`, ERROR status for `failed`/`timeout`)
   in the agent's application, trace id = the invocation's trace id, tagged `aig.invocation_id`,
   `aig.caller_user`, `aig.caller_team` (+ `aig.session_id`), with `aig.invocation.*` status, mode,
   duration and token attributes. Gateway logs of model calls an agent makes while serving an
   invocation carry `caller_user`/`caller_team`/`invocation_id` in their metadata; the bridge copies
   them to the same `aig.*` tags, so `backend/observability` invocation monitors can group cost by
   caller team. Invalid events are dead-lettered (`invalid_event`), duplicates (same
   `invocation_id`) skipped.
3. **Daily reconciliation.** `telemetry-bridge reconcile` compares Portkey traffic per
   `agent_id` with the agent's own Fiddler traces and suspends agents that use the gateway
   without tracing (registry + Portkey key + owner alert).
4. **Feedback loop.** `export-failing` writes failing traces into eval-dataset CSVs for the
   Phase 5 evals; `guardrail-tickets` writes suggested guardrail tightenings for review.

Nothing has been run against a real Portkey or Fiddler yet (no credentials). Every external
path lives in [`src/telemetry_bridge/endpoints.py`](src/telemetry_bridge/endpoints.py) and can
be overridden with a YAML file (`AIG_BRIDGE_ENDPOINTS_FILE`); see "Verification" below.

## Run

```bash
cd backend/telemetry-bridge
python3 -m venv .venv && .venv/bin/pip install -e '.[dev]'     # or: make setup (repo root)
cp .env.example .env && $EDITOR .env                             # placeholders only in git
./run-local.sh start          # uvicorn on :8095 (stop|status|logs)
.venv/bin/pytest              # all external APIs mocked with respx

# one-shot jobs (same settings)
.venv/bin/telemetry-bridge pull                     # Portkey logs since the high-water mark
.venv/bin/telemetry-bridge reconcile --dry-run      # yesterday (UTC); report in ./reports
.venv/bin/telemetry-bridge export-failing --since 2026-10-01
.venv/bin/telemetry-bridge guardrail-tickets --since 2026-10-01 --with-fiddler
.venv/bin/telemetry-bridge dead-letters list
.venv/bin/telemetry-bridge dead-letters replay --reason fiddler_application_missing
```

Docker (build from the repo root, the image also needs `backend/contracts/` and
`backend/observability/`):

```bash
docker build -f backend/telemetry-bridge/Dockerfile -t aig-telemetry-bridge .
docker run -p 8095:8095 --env-file backend/telemetry-bridge/.env aig-telemetry-bridge   # serve --worker
docker run --env-file ... aig-telemetry-bridge telemetry-bridge reconcile             # scheduled job
```

[`deploy/schedules.example.yaml`](deploy/schedules.example.yaml) has CronJob examples (daily
reconciliation at 01:30 UTC, weekly feedback export).

## HTTP API (port 8095)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/healthz` | none | status, env, DB, pull mode, Fiddler/Portkey configured, secret statuses (`configured`/`placeholder`/`missing`, never values) |
| GET | `/metrics` | none | Prometheus text (`aig_bridge_*`: received, forwarded, duplicate, quarantined{reason}, pending, forward errors/latency, pull runs/lag, dead letters) |
| POST | `/ingest/portkey` | `x-aig-bridge-secret: <AIG_BRIDGE_PUSH_SECRET>` | One Portkey log, a list, `{"logs": [...]}` or `{"data": [...]}` (max `AIG_BRIDGE_MAX_BATCH`, 1000) |
| POST | `/ingest/ide-usage` | `Authorization: Bearer <AIG_BRIDGE_INGEST_TOKEN>` | One event or `{"events": [...]}` (max 500), per `backend/contracts/ide-usage-event.schema.json` |
| POST | `/ingest/invocation` | `Authorization: Bearer <AIG_BRIDGE_INGEST_TOKEN>` | One event or `{"events": [...]}` (max 500), per `backend/contracts/invocation-event.schema.json` (platform-api invocation records, metadata only) |
| POST | `/v1/traces` | `x-aig-bridge-secret` | Optional OTLP/HTTP **JSON** passthrough (Portkey OTel export). The application comes from resource `application.id` or the `agent` + `env` attributes |

Ingest responses are `202 {"counts": {...}, "results": [{"key", "status", "reason"?}]}` with
status `forwarded`, `duplicate`, `pending` (delivery deferred) or `quarantined`. Outside
`local`, an ingest endpoint whose secret is not configured answers `503 ingest_not_configured`;
secrets are compared in constant time.

Configure Portkey to push logs (log export / webhook integration of the self-hosted version)
to `https://<bridge>/ingest/portkey` with the header `x-aig-bridge-secret`. Pull and push can
run together: events are deduplicated by Portkey log id.

## How an event is processed

```
Portkey log / IDE event
  -> dedupe (bridge_events.key = portkey:<log id> | ide:<event id>)          duplicate
  -> normalize (fields read defensively; no metadata / no id)                quarantined
  -> validate tags against backend/contracts/tags.schema.json                        quarantined (invalid_tags)
  -> record guardrail stats (bridge_guardrail_stats, no content)
  -> resolve Fiddler application: project FIDDLER_PROJECT_TEMPLATE(env tag),
     application = agent id (fallback FIDDLER_FALLBACK_APPLICATION)          quarantined, retryable
  -> OTLP span (protobuf by default) -> POST {FIDDLER_URL}/v1/traces
     with fiddler-application-id; retries with exponential backoff + jitter
       429/408/5xx/network after retries                                      pending -> worker
       other 4xx                                                              quarantined (fiddler_rejected)
```

- **Idempotent**: one row per key; the span id is derived from the key, so a redelivered event
  is the same span.
- **Never dropped silently**: unusable events go to `bridge_dead_letters` with a reason and the
  raw event (request/response bodies redacted). `dead-letters replay` re-processes them (for
  example after `fiddler-sync apply` created a missing application).
- **Pending**: transient failures are retried by the worker (`serve --worker` or
  `AIG_BRIDGE_WORKER=true`, or `telemetry-bridge retry-pending`) until
  `AIG_BRIDGE_MAX_DELIVERY_ATTEMPTS`, then dead-lettered as `delivery_exhausted`.
- **Content**: `AIG_BRIDGE_REDACT_MODE` = `pii` (default: masks emails, phone numbers, SSNs,
  card numbers, IBANs, key-shaped tokens), `hash`, `drop` or `none`; truncated at
  `AIG_BRIDGE_MAX_CONTENT_CHARS`. Delivered events keep no content in the DB.
- **Logging**: keys, reasons and counts only; prompts and replies are never logged, and every
  configured secret value is masked by a log filter.

Span attributes: the AIG tags plus `aig.trace_id`, `aig.user`; fiddler-otel names
`fiddler.span.type=llm`, `gen_ai.agent.id`, `gen_ai.llm.input.system`,
`gen_ai.llm.input.user`, `gen_ai.llm.output`, `gen_ai.request.model`, `gen_ai.system`,
`gen_ai.usage.{input,output,total}_tokens`; and `aig.source=telemetry-bridge`,
`aig.event_kind` (`gateway`/`ide_usage`), `aig.cost_usd`, `aig.latency_ms`,
`aig.cache_status` (`hit`/`semantic_hit`/`miss`/`disabled`/`unknown`), `aig.status_code`,
`aig.guardrail.verdict`, `aig.guardrail.failed_checks`, `aig.guardrail.denied`,
`aig.guardrail.results` (JSON), `aig.portkey.log_id`. Resource: `application.id`.

## Pull (high-water mark)

`AIG_BRIDGE_PULL_MODE=export` (default) runs Portkey's Logs Export flow: create an export for
`[hwm - overlap, min(now - lag, hwm + max_window)]`, start it, poll until done, download the
signed URL (the admin key is never sent to it), process JSONL/JSON. The cursor
(`bridge_cursors.portkey_logs`) advances to the window end only after the run succeeds.
`list` uses a synchronous log listing endpoint instead; `off` disables pulling (push only).

## Reconciliation

```bash
telemetry-bridge reconcile [--date 2026-10-08] [--dry-run] [--output report.json] [--exit-code]
```

For the UTC day: Portkey analytics grouped by metadata `agent_id` gives requests per agent;
Fiddler `/v3/spans/fields` gives the spans in the agent's application in each project of
`AIG_BRIDGE_RECONCILE_PROJECTS` (default `aig-<env>`), minus the spans this bridge wrote
(`aig.source = telemetry-bridge`) = the agent's own (SDK) traces.

| Verdict | Meaning |
|---|---|
| `violation` | active agent, requests >= `AIG_BRIDGE_RECONCILE_MIN_REQUESTS` (1) and SDK spans < `AIG_BRIDGE_RECONCILE_MIN_SPANS` (1), or SDK spans / requests < `AIG_BRIDGE_RECONCILE_MIN_TRACE_RATIO` (0 = off) |
| `ok`, `no_traffic`, `already_suspended`, `exempt` | `AIG_BRIDGE_RECONCILE_EXEMPT_AGENTS` (default the IDE/web agents, whose Fiddler data comes from this bridge by design) |
| `unregistered_traffic` | traffic for an id the registry does not know (the gateway agent-check already denies these) |
| `error` | the Fiddler lookup failed; never suspended |

On a violation (skipped with `--dry-run`):
1. **Registry**: `POST {AIG_PLATFORM_API_URL}/api/v1/agents/{id}/suspend` with
   `x-aig-service-token` (platform-api then denies the agent in the gateway's agent-check
   webhook). With `AIG_BRIDGE_REGISTRY_FILE` the bridge edits the registry YAML instead
   (platform-api reads it on restart), useful for a shared file or offline runs.
2. **Portkey key**: the key id in the registry record (`portkey_api_key_id`), else the key named
   `AIG_BRIDGE_AGENT_KEY_NAME_TEMPLATE` (`aig-agent-{agent_id}`), is suspended through the admin
   API (`api_key_suspend` endpoint). Team keys (`backend/gateway/manifests/api-keys.yaml` has one
   per team) are only touched with `AIG_BRIDGE_SUSPEND_TEAM_KEY_FALLBACK=true`, since that
   blocks every agent of the team. If no key is found the report says `key_not_found`; the
   registry suspension still blocks the agent at the gateway.
3. **Alert**: routed as event `agent_suspended` by `backend/observability/manifests/alerts.yaml`
   (Slack platform channel + team channel, platform email, owner email), with links to the
   agent's Fiddler application and failing traces.

**Registered versions with invocations but no traces (W7).** The run also reads platform-api's
invocation records for the day (`GET /api/v1/invocations/summary?env=prod`, service token;
`AIG_BRIDGE_RECONCILE_INVOCATION_ENV`) and lists them in the report's `invocations` section per
agent (with the versions and counts). An active agent with >= `AIG_BRIDGE_RECONCILE_MIN_INVOCATIONS`
(1) invocations but fewer than `AIG_BRIDGE_RECONCILE_MIN_SPANS` SDK spans gets verdict
`untraced_invocations` (summary `untraced_invocations`). This is **report-only** by default; with
`AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS=true` the same suspension path as above runs
(registry, Portkey key, alert; still nothing with `--dry-run`). Other verdicts: `ok`,
`below_threshold`, `already_suspended` (also when the gateway rule suspended it in the same run),
`exempt`, `unregistered`, `error`. A YAML registry has no invocation records (section notes it).
The catalog never lists suspended, retired or draft agents (platform-api), so a suspended agent
disappears from every surface at once.

Fail safe: if Portkey analytics or the registry cannot be read, nothing is suspended and the
command exits 1 (an unreadable invocation summary is an error too, never a suspension). The JSON report goes to `--output` or `$AIG_BRIDGE_REPORTS_DIR`.
Exit codes: 0 ok, 1 errors, 3 with `--exit-code` when an agent was (or would be) suspended.

## Feedback loop

- `export-failing --since D [--until D] [--project P] [--agent A] [--output-dir DIR]`: spans in
  each agent application that have an error status or a trust score past its threshold
  (`backend/observability/manifests/trust.yaml` + env overrides) -> one CSV per agent,
  `<agent>.failing.<since>-<until>.csv`, columns `input, expected_output` (blank, for a
  reviewer), `metadata` (JSON: tags, project, span id, scores), `trace_id`, `reason` (for
  example `jailbreak 0.91 >= 0.5`, `error (HTTP 500)`), plus a summary JSON. Inputs are redacted
  per `AIG_BRIDGE_REDACT_MODE`.
- `guardrail-tickets --since D [--with-fiddler]`: from the guardrail stats recorded per gateway
  event: checks that flagged calls without blocking them (log mode) -> "enforce" tickets;
  checks with a very high failure rate -> "review threshold"; with `--with-fiddler`, Fiddler
  trust failures the gateway let through -> "tighten" tickets for the matching guardrail. Writes
  `guardrail-tickets.<since>-<until>.md` and `.json` for review; nothing is changed
  automatically.

## Storage

SQLAlchemy 2.0, portable types only. Default `sqlite:///services/telemetry-bridge/state/bridge.db`
(gitignored). For several replicas or separate job containers use Postgres:
`pip install '.[postgres]'` and `AIG_BRIDGE_DATABASE_URL=postgresql+psycopg://user@host/aig_bridge`.
Tables: `bridge_cursors`, `bridge_events`, `bridge_dead_letters`, `bridge_guardrail_stats`
(created on start; add Alembic when the schema first changes).

## Configuration

All variables are listed in [`backend/contracts/env-vars.md`](../contracts/env-vars.md#telemetry-bridge-servicestelemetry-bridge);
placeholders in [`.env.example`](.env.example). Secrets: `FIDDLER_API_KEY`,
`AIG_PORTKEY_ADMIN_API_KEY`, `AIG_PLATFORM_SERVICE_TOKEN`, `AIG_BRIDGE_PUSH_SECRET`,
`AIG_BRIDGE_INGEST_TOKEN`, `AIG_BRIDGE_SMTP_PASSWORD` and the alert channel variables named in
`alerts.yaml` (`AIG_ALERT_SLACK_WEBHOOK_*`, `AIG_ALERT_PAGERDUTY_ROUTING_KEY`).

## Verification status

Verified by reading the installed packages `fiddler-client` 3.14.1, `fiddler-evals` 0.6.0 and
`fiddler-otel` 1.4.1:
- OTLP/HTTP ingestion at `{url}/v1/traces`, headers `authorization: Bearer <key>` and
  `fiddler-application-id: <uuid>`, protobuf encoding; attribute names (`gen_ai.*`,
  `fiddler.span.type`, resource `application.id`).
- `/v3/projects` and `/v3/applications` lookups with the JSON `filter` parameter and
  `data.items` paging; `/v3/spans/fields` -> `data.total_spans` / `data.sampled`; the span
  filter DSL (`Span::...`, `SpanAttribute::...`, `Evaluator::<rule>::<output>`, operators
  `equal`, `greater_or_equal`, `less`, condition `AND`/`OR`).
- Trust evaluator outputs `ftl_prompt_safety` (`jailbreaking_prob`, `hateful_prob`, ...) and
  `ftl_response_faithfulness` (`faithful_prob`).

Assumed (confirm with AIG's Portkey / Fiddler teams; override in the endpoints file):
- Portkey Logs Export paths and fields, the synchronous log list, `cache_status` and
  `hook_results` field names, `/analytics/groups/metadata/{key}`, and the API-key suspension
  body `{"status": "disabled"}`.
- Fiddler `POST /v3/spans/query` (span search used by `export-failing`) and its response shape;
  `Span::status` as a filter field; that Fiddler accepts OTLP JSON (only for
  `FIDDLER_OTLP_ENCODING=json` and the `/v1/traces` passthrough).
- That Fiddler's GenAI trust evaluators run on spans ingested through OTLP from this bridge, as
  they do for SDK spans.
