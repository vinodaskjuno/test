from __future__ import annotations

import json
import logging
import uuid

from fakes import (
    FIDDLER_KEY,
    INGEST_TOKEN,
    PORTKEY_KEY,
    PUSH_SECRET,
    SERVICE_TOKEN,
    portkey_log,
)
from fastapi.testclient import TestClient
from telemetry_bridge.app import create_app
from telemetry_bridge.otlp import attr_dict

PUSH = {"x-aig-bridge-secret": PUSH_SECRET}
SECRETS = (FIDDLER_KEY, PORTKEY_KEY, SERVICE_TOKEN, PUSH_SECRET, INGEST_TOKEN)


def client(bridge):
    return TestClient(create_app(bridge=bridge, start_worker=False))


def span_attrs(trace):
    return attr_dict(trace["body"]["resourceSpans"][0]["scopeSpans"][0]["spans"][0]["attributes"])


def ide_event(**kw):
    ev = {"event_id": str(uuid.uuid4()), "timestamp": "2026-10-08T10:00:00Z", "source": "vscode", "agent_id": "ide.vscode",
          "team": "underwriting-ai", "user_tier": "premium", "env": "local", "user": "jane.doe@example.com",
          "model": "claude-opus-4-1", "prompt_tokens": 100, "completion_tokens": 40, "cost_usd": 0.02, "latency_ms": 900,
          "cache": "hit", "status": "ok", "trace_id": "0af7651916cd43dd8448eb211c80319c"}
    ev.update(kw)
    return ev


def test_healthz_reports_statuses_never_values(bridge, world):
    with client(bridge) as c:
        r = c.get("/healthz")
    assert r.status_code == 200
    body = r.json()
    assert body["secrets"]["FIDDLER_API_KEY"] == "configured" and body["secrets"]["AIG_BRIDGE_SMTP_PASSWORD"] == "missing"
    assert body["fiddler"] == "configured" and body["database"] == "ok"
    assert not any(s in r.text for s in SECRETS)


def test_push_auth(make_bridge, world):
    with client(make_bridge()) as c:
        assert c.post("/ingest/portkey", json=portkey_log()).status_code == 401
        assert c.post("/ingest/portkey", json=portkey_log(), headers={"x-aig-bridge-secret": "nope"}).status_code == 401
    with client(make_bridge(AIG_ENV="dev", AIG_BRIDGE_PUSH_SECRET=None)) as c:
        r = c.post("/ingest/portkey", json=portkey_log())
        assert r.status_code == 503 and r.json()["error"]["code"] == "ingest_not_configured"
    with client(make_bridge(AIG_BRIDGE_PUSH_SECRET="__REPLACE_ME_PUSH__")) as c:  # local: allowed with a warning
        assert c.post("/ingest/portkey", json=portkey_log()).status_code == 202


def test_gateway_event_reaches_fiddler_with_tags_trace_and_application(bridge, world):
    app_id = world.add_app("aig-local", "uw-quote-assistant")
    with client(bridge) as c:
        r = c.post("/ingest/portkey", json={"logs": [portkey_log(hooks={"before_request_hooks": []})]}, headers=PUSH)
    assert r.status_code == 202 and r.json()["counts"] == {"forwarded": 1}
    [t] = world.traces
    assert t["headers"]["fiddler-application-id"] == app_id
    assert t["headers"]["content-type"] == "application/x-protobuf"
    span = t["body"]["resourceSpans"][0]["scopeSpans"][0]["spans"][0]
    assert span["traceId"] == "0af7651916cd43dd8448eb211c80319c"  # joins the SDK span / Portkey log
    attrs = span_attrs(t)
    assert attrs["env"] == "local" and attrs["host"] == "laptop" and attrs["agent"] == "uw-quote-assistant"
    assert attrs["aig.source"] == "telemetry-bridge" and attrs["aig.cache_status"] == "miss"
    assert "[REDACTED_EMAIL]" in attrs["gen_ai.llm.input.user"]  # default AIG_BRIDGE_REDACT_MODE=pii


def test_idempotent_by_portkey_log_id(bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    with client(bridge) as c:
        c.post("/ingest/portkey", json=portkey_log(), headers=PUSH)
        r = c.post("/ingest/portkey", json=[portkey_log(), portkey_log()], headers=PUSH)
    assert r.json()["counts"] == {"duplicate": 2}
    assert len(world.traces) == 1


def test_invalid_tags_are_quarantined_not_dropped(bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    with client(bridge) as c:
        r = c.post("/ingest/portkey", json=[portkey_log("bad1", tier="gold"), portkey_log("bad2", host="mainframe"),
                                             {"no": "id"}], headers=PUSH)
    res = r.json()["results"]
    assert [x["status"] for x in res] == ["quarantined"] * 3
    assert [x["reason"] for x in res] == ["invalid_tags", "invalid_tags", "missing_log_id"]
    assert world.traces == []
    dls = bridge.store.dead_letters()
    assert len(dls) == 3
    stored = json.dumps([d.payload for d in dls])
    assert "jane.doe@example.com" not in json.dumps([d.payload.get("request") for d in dls if isinstance(d.payload, dict)])
    assert "gold" in stored  # metadata kept for debugging
    assert bridge.store.dead_letter_counts() == {"invalid_tags": 2, "missing_log_id": 1}


def test_missing_application_is_retryable_and_replayed(bridge, world):
    with client(bridge) as c:
        r = c.post("/ingest/portkey", json=portkey_log(), headers=PUSH)
    assert r.json()["results"][0]["reason"] == "fiddler_application_missing"
    world.add_app("aig-local", "uw-quote-assistant")
    bridge.fiddler._apps.clear()  # negative cache expiry
    [dl] = bridge.store.dead_letters()
    assert bridge.pipeline.replay(dl.id).status == "forwarded"
    assert len(world.traces) == 1
    assert bridge.pipeline.replay(dl.id) is None


def test_fallback_application(make_bridge, world):
    b = make_bridge(FIDDLER_FALLBACK_APPLICATION="aig-gateway-unmapped")
    app_id = world.add_app("aig-local", "aig-gateway-unmapped")
    with client(b) as c:
        assert c.post("/ingest/portkey", json=portkey_log(), headers=PUSH).json()["counts"] == {"forwarded": 1}
    assert world.traces[0]["headers"]["fiddler-application-id"] == app_id


def test_transient_failures_retry_with_backoff_then_pending_then_redelivered(bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    world.trace_statuses = [503, 429]
    with client(bridge) as c:
        assert c.post("/ingest/portkey", json=portkey_log("a"), headers=PUSH).json()["counts"] == {"forwarded": 1}
        world.trace_statuses = [503] * 10
        assert c.post("/ingest/portkey", json=portkey_log("b"), headers=PUSH).json()["counts"] == {"pending": 1}
    assert bridge.store.event_status("portkey:b") == "pending"
    from datetime import datetime, timedelta, timezone
    later = datetime.now(timezone.utc) + timedelta(hours=1)
    world.trace_statuses = []
    assert bridge.pipeline.retry_pending(now=later) == {"forwarded": 1}
    assert bridge.store.event_status("portkey:b") == "forwarded"
    assert len(world.traces) == 2


def test_delivery_exhausted_goes_to_dead_letters(make_bridge, world):
    b = make_bridge(AIG_BRIDGE_MAX_DELIVERY_ATTEMPTS="1")
    world.add_app("aig-local", "uw-quote-assistant")
    world.trace_statuses = [500] * 20
    with client(b) as c:
        c.post("/ingest/portkey", json=portkey_log("c"), headers=PUSH)
    from datetime import datetime, timedelta, timezone
    assert b.pipeline.retry_pending(now=datetime.now(timezone.utc) + timedelta(hours=1)) == {"quarantined": 1}
    assert b.store.dead_letter_counts() == {"delivery_exhausted": 1}


def test_permanent_rejection_is_quarantined(bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    world.trace_statuses = [400]
    with client(bridge) as c:
        r = c.post("/ingest/portkey", json=portkey_log(), headers=PUSH)
    assert r.json()["results"][0]["reason"] == "fiddler_rejected"


def test_fiddler_lookup_outage_defers(bridge, world):
    world.fiddler_lookup_status = 503
    with client(bridge) as c:
        assert c.post("/ingest/portkey", json=portkey_log(), headers=PUSH).json()["counts"] == {"pending": 1}
    world.fiddler_lookup_status = 200
    world.add_app("aig-local", "uw-quote-assistant")
    from datetime import datetime, timedelta, timezone
    assert bridge.pipeline.retry_pending(now=datetime.now(timezone.utc) + timedelta(hours=1)) == {"forwarded": 1}


def test_ide_usage_events(bridge, world):
    app_id = world.add_app("aig-local", "ide.vscode")
    bad = ide_event(prompt_tokens=-1)
    del bad["model"]
    with client(bridge) as c:
        assert c.post("/ingest/ide-usage", json=ide_event()).status_code == 401
        assert c.post("/ingest/ide-usage", json=ide_event(), headers={"authorization": "Bearer nope"}).status_code == 401
        auth = {"authorization": f"Bearer {INGEST_TOKEN}"}
        r = c.post("/ingest/ide-usage", json={"events": [ide_event(), bad]}, headers=auth)
        assert r.status_code == 202
        assert [x["status"] for x in r.json()["results"]] == ["forwarded", "quarantined"]
        assert r.json()["results"][1]["reason"] == "invalid_event"
        assert c.post("/ingest/ide-usage", json=[1, 2], headers=auth).status_code == 400
    [t] = world.traces
    attrs = span_attrs(t)
    assert t["headers"]["fiddler-application-id"] == app_id
    assert attrs["host"] == "vscode" and attrs["aig.event_kind"] == "ide_usage" and attrs["gen_ai.usage.total_tokens"] == "140"  # OTLP intValue is a string
    assert "gen_ai.llm.input.user" not in attrs


def test_metrics_endpoint(bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    with client(bridge) as c:
        c.post("/ingest/portkey", json=[portkey_log("m1"), portkey_log("m1"), portkey_log("m2", tier="x")], headers=PUSH)
        text = c.get("/metrics").text
    assert 'aig_bridge_events_forwarded_total{source="portkey"} 1.0' in text
    assert 'aig_bridge_events_duplicate_total{source="portkey"} 1.0' in text
    assert 'aig_bridge_events_quarantined_total{reason="invalid_tags",source="portkey"} 1.0' in text
    assert "aig_bridge_dead_letters 1.0" in text


def test_logs_never_contain_prompts_or_secrets(bridge, world, caplog):
    caplog.set_level(logging.DEBUG, logger="telemetry_bridge")
    world.add_app("aig-local", "uw-quote-assistant")
    world.trace_statuses = [401]
    with client(bridge) as c:
        c.post("/ingest/portkey", json=[portkey_log("p1", prompt="TOP-SECRET-PROMPT"), portkey_log("p2", tier="bad")], headers=PUSH)
    text = caplog.text
    assert "TOP-SECRET-PROMPT" not in text and "Quote for" not in text
    assert not any(s in text for s in SECRETS)


def test_otlp_json_passthrough(bridge, world):
    app_id = world.add_app("aig-local", "uw-quote-assistant")
    span = {"traceId": "0af7651916cd43dd8448eb211c80319c", "spanId": "b7ad6b7169203331", "name": "llm",
            "startTimeUnixNano": "1", "endTimeUnixNano": "2",
            "attributes": [{"key": "agent", "value": {"stringValue": "uw-quote-assistant"}},
                           {"key": "env", "value": {"stringValue": "local"}}]}
    body = {"resourceSpans": [{"resource": {"attributes": []}, "scopeSpans": [{"spans": [span]}]}]}
    with client(bridge) as c:
        r = c.post("/v1/traces", json=body, headers=PUSH)
        assert r.status_code == 200, r.text
        assert c.post("/v1/traces", content=b"\x00", headers={**PUSH, "content-type": "application/x-protobuf"}).status_code == 415
        span["attributes"] = []
        assert c.post("/v1/traces", json=body, headers=PUSH).status_code == 422
    assert world.traces[0]["headers"]["fiddler-application-id"] == app_id
    assert world.traces[0]["headers"]["content-type"] == "application/json"


def test_json_encoding_setting(make_bridge, world):
    b = make_bridge(FIDDLER_OTLP_ENCODING="json")
    world.add_app("aig-local", "uw-quote-assistant")
    with client(b) as c:
        c.post("/ingest/portkey", json=portkey_log(), headers=PUSH)
    assert world.traces[0]["headers"]["content-type"] == "application/json"
