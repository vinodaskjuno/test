from __future__ import annotations

import json

import pytest
from conftest import make_env
from fakes import FIDDLER_KEY, portkey_log
from telemetry_bridge.cli import main
from telemetry_bridge.settings import Secrets, Settings


def test_placeholders_are_unset_and_repr_hides_values():
    s = Secrets({"FIDDLER_API_KEY": "__REPLACE_ME_FIDDLER_API_KEY_DEV__", "AIG_BRIDGE_PUSH_SECRET": "real-SUPERSECRET"})
    assert s.get("FIDDLER_API_KEY") is None and s.status("FIDDLER_API_KEY") == "placeholder"
    assert s.get("AIG_BRIDGE_PUSH_SECRET") == "real-SUPERSECRET"
    assert "SUPERSECRET" not in repr(s) and "SUPERSECRET" not in str(Settings(secrets=s))


def test_env_file_is_read_and_process_env_wins(tmp_path):
    f = tmp_path / ".env"
    f.write_text("FIDDLER_API_KEY=from-file\nAIG_BRIDGE_REDACT_MODE=hash\nexport AIG_ENV=dev\n")
    s = Settings.from_env({"AIG_BRIDGE_ENV_FILE": str(f), "AIG_BRIDGE_REDACT_MODE": "drop"})
    assert s.secrets.get("FIDDLER_API_KEY") == "from-file" and s.redact_mode == "drop" and s.env == "dev"
    assert s.projects_to_reconcile == ["aig-dev"]


@pytest.mark.parametrize("var,value", [("AIG_ENV", "qa"), ("AIG_BRIDGE_PULL_MODE", "push"), ("AIG_BRIDGE_REDACT_MODE", "x"),
                                       ("FIDDLER_OTLP_ENCODING", "xml"), ("AIG_PORTKEY_COST_UNIT", "eur")])
def test_invalid_settings_raise(var, value):
    with pytest.raises(ValueError):
        Settings.from_env({var: value})


def test_endpoint_override_file(tmp_path, make_bridge):
    f = tmp_path / "ep.yaml"
    f.write_text("portkey:\n  api_key_suspend: {method: DELETE, path: \"/api-keys/{id}\", body: {}}\nfiddler:\n  spans_query: {path: /v3/spans/search}\n")
    b = make_bridge(AIG_BRIDGE_ENDPOINTS_FILE=str(f))
    assert b.endpoints["portkey"]["api_key_suspend"].method == "DELETE"
    assert b.endpoints["fiddler"]["spans_query"].path == "/v3/spans/search"
    bad = tmp_path / "bad.yaml"
    bad.write_text("nope: {}\n")
    with pytest.raises(ValueError):
        make_bridge(AIG_BRIDGE_ENDPOINTS_FILE=str(bad))


def test_cli_pull_dead_letters_and_replay(world, tmp_path, monkeypatch, capsys):
    for k, v in make_env(tmp_path).items():
        monkeypatch.setenv(k, v)
    world.portkey_logs = [portkey_log("c1")]  # no Fiddler application yet -> dead letter
    world.export_status = ["success"]
    assert main(["pull"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["counts"] == {"quarantined": 1}
    assert main(["dead-letters", "list"]) == 0
    [dl] = json.loads(capsys.readouterr().out)
    assert dl["reason"] == "fiddler_application_missing" and dl["retryable"] is True
    world.add_app("aig-local", "uw-quote-assistant")
    assert main(["dead-letters", "replay", "--reason", "fiddler_application_missing"]) == 0
    assert json.loads(capsys.readouterr().out)[0]["status"] == "forwarded"
    assert main(["retry-pending"]) == 0
    assert FIDDLER_KEY not in capsys.readouterr().out
    assert main(["dead-letters", "replay"]) == 1


def test_cli_export_and_tickets(world, tmp_path, monkeypatch, capsys):
    for k, v in make_env(tmp_path).items():
        monkeypatch.setenv(k, v)
    assert main(["export-failing", "--since", "2026-10-01", "--until", "2026-10-09", "--output-dir", str(tmp_path / "d")]) == 0
    assert json.loads(capsys.readouterr().out)["rows"] == 0
    assert main(["guardrail-tickets", "--since", "2026-10-01", "--output-dir", str(tmp_path / "t")]) == 0
    assert json.loads(capsys.readouterr().out)["tickets"] == 0


def test_cli_bad_settings_exit_1(monkeypatch, capsys):
    monkeypatch.setenv("AIG_ENV", "qa")
    assert main(["retry-pending"]) == 1
