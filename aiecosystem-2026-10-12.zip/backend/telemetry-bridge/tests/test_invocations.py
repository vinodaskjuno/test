"""Agent invocations (W7): caller tags on gateway events, platform-api invocation events
(POST /ingest/invocation, backend/contracts/invocation-event.schema.json)."""

from __future__ import annotations

import json

from fakes import INGEST_TOKEN, PUSH_SECRET, portkey_log
from fastapi.testclient import TestClient
from telemetry_bridge.app import create_app
from telemetry_bridge.otlp import attr_dict

PUSH = {"x-aig-bridge-secret": PUSH_SECRET}
BEARER = {"authorization": f"Bearer {INGEST_TOKEN}"}
INV_ID = "0b6f1d2e-6c1a-4a8e-9c7d-1f2e3d4c5b6a"


def client(bridge):
    return TestClient(create_app(bridge=bridge, start_worker=False))


def span_of(trace):
    return trace["body"]["resourceSpans"][0]["scopeSpans"][0]["spans"][0]


def invocation_event(**kw):
    ev = {"invocation_id": INV_ID, "timestamp": "2026-10-09T10:00:03.200000+00:00",
          "started_at": "2026-10-09T10:00:00+00:00", "agent_id": "claims-triage", "team": "claims-ai",
          "version": "1.4.0", "env": "local", "agent_host": "laptop", "kind": "https", "mode": "sync",
          "purpose": "invoke", "status": "succeeded", "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
          "session_id": "s-42", "caller_user": "bob@example.com", "caller_team": "uw-platform",
          "caller_tier": "standard", "duration_ms": 3200, "prompt_tokens": 412, "completion_tokens": 168,
          "total_tokens": 580}
    ev.update(kw)
    return {k: v for k, v in ev.items() if v is not None}


def test_gateway_log_with_caller_metadata_is_forwarded_with_caller_tags(bridge, world):
    """A model call made by an agent while serving an invocation carries caller_user/caller_team/
    invocation_id in x-portkey-metadata; the bridge maps them to the aig.* span tags (accepted by
    tags.schema.json, not quarantined)."""
    world.add_app("aig-local", "claims-triage")
    log = portkey_log("inv_log", agent="claims-triage", team="claims-ai", tier="standard", host="agentcore")
    log["metadata"].update({"caller_user": "bob@example.com", "caller_team": "uw-platform", "invocation_id": INV_ID})
    with client(bridge) as c:
        r = c.post("/ingest/portkey", json=log, headers=PUSH)
    assert r.json()["counts"] == {"forwarded": 1}, r.json()
    attrs = attr_dict(span_of(world.traces[0])["attributes"])
    assert attrs["aig.caller_user"] == "bob@example.com" and attrs["aig.caller_team"] == "uw-platform"
    assert attrs["aig.invocation_id"] == INV_ID
    assert bridge.store.dead_letters() == []


def test_gateway_log_with_half_caller_metadata_is_quarantined(bridge, world):
    world.add_app("aig-local", "claims-triage")
    log = portkey_log("half", agent="claims-triage", team="claims-ai")
    log["metadata"]["caller_user"] = "bob@example.com"  # caller_team missing: schema dependentRequired
    with client(bridge) as c:
        r = c.post("/ingest/portkey", json=log, headers=PUSH)
    assert r.json()["results"][0]["reason"] == "invalid_tags"
    assert world.traces == []


def test_invocation_event_reaches_fiddler_joined_by_trace_id(bridge, world):
    app_id = world.add_app("aig-local", "claims-triage")
    with client(bridge) as c:
        r = c.post("/ingest/invocation", json={"events": [invocation_event()]}, headers=BEARER)
    assert r.status_code == 202 and r.json()["counts"] == {"forwarded": 1}, r.json()
    [t] = world.traces
    assert t["headers"]["fiddler-application-id"] == app_id
    span = span_of(t)
    assert span["traceId"] == "4bf92f3577b34da6a3ce929d0e0e4736"  # = the agent's Portkey trace id
    assert span["name"] == "aig.agent.invocation"
    assert int(span["endTimeUnixNano"]) - int(span["startTimeUnixNano"]) == 3200 * 1_000_000
    attrs = attr_dict(span["attributes"])
    assert attrs["aig.event_kind"] == "invocation" and attrs["fiddler.span.type"] == "chain"
    assert attrs["agent"] == "claims-triage" and attrs["team"] == "claims-ai" and attrs["tier"] == "standard"
    assert attrs["env"] == "local" and attrs["host"] == "laptop"
    assert attrs["aig.invocation_id"] == INV_ID and attrs["aig.trace_id"] == "4bf92f3577b34da6a3ce929d0e0e4736"
    assert attrs["aig.caller_user"] == "bob@example.com" and attrs["aig.caller_team"] == "uw-platform"
    assert attrs["aig.session_id"] == "s-42" and attrs["aig.agent.version"] == "1.4.0"
    assert attrs["aig.invocation.status"] == "succeeded" and attrs["aig.invocation.mode"] == "sync"
    assert attrs["gen_ai.usage.total_tokens"] == "580"
    assert not any(k.startswith("gen_ai.llm.") for k in attrs)  # never content


def test_failed_invocation_is_an_error_span(bridge, world):
    world.add_app("aig-local", "claims-triage")
    with client(bridge) as c:
        c.post("/ingest/invocation", headers=BEARER, json=invocation_event(
            status="timeout", error_code="invocation_timeout", prompt_tokens=None, completion_tokens=None,
            total_tokens=None, started_at=None))
    span = span_of(world.traces[0])
    assert span["status"]["code"] in (2, "STATUS_CODE_ERROR")
    attrs = attr_dict(span["attributes"])
    assert attrs["aig.error_code"] == "invocation_timeout" and "gen_ai.usage.total_tokens" not in attrs


def test_invocation_events_are_idempotent(bridge, world):
    world.add_app("aig-local", "claims-triage")
    with client(bridge) as c:
        c.post("/ingest/invocation", json=invocation_event(), headers=BEARER)
        r = c.post("/ingest/invocation", json=invocation_event(), headers=BEARER)
    assert r.json()["counts"] == {"duplicate": 1}
    assert len(world.traces) == 1


def test_invalid_invocation_events_are_dead_lettered(bridge, world):
    world.add_app("aig-local", "claims-triage")
    bad = [invocation_event(invocation_id="11111111-1111-4111-8111-111111111111", output="the answer"),  # content
           invocation_event(invocation_id="22222222-2222-4222-8222-222222222222", caller_user=None),
           invocation_event(invocation_id="33333333-3333-4333-8333-333333333333", status="exploded")]
    with client(bridge) as c:
        r = c.post("/ingest/invocation", json={"events": bad}, headers=BEARER)
    assert [x["reason"] for x in r.json()["results"]] == ["invalid_event"] * 3
    assert world.traces == []
    assert bridge.store.dead_letter_counts() == {"invalid_event": 3}
    assert {d.source for d in bridge.store.dead_letters()} == {"invocation"}


def test_invocation_ingest_auth(make_bridge, world):
    with client(make_bridge()) as c:
        assert c.post("/ingest/invocation", json=invocation_event()).status_code == 401
        assert c.post("/ingest/invocation", json=invocation_event(), headers=PUSH).status_code == 401
        assert c.post("/ingest/invocation", json=[1, 2], headers=BEARER).status_code == 400
    with client(make_bridge(AIG_ENV="dev", AIG_BRIDGE_INGEST_TOKEN=None)) as c:
        r = c.post("/ingest/invocation", json=invocation_event(), headers=BEARER)
        assert r.status_code == 503 and r.json()["error"]["code"] == "ingest_not_configured"


def test_invocation_for_missing_application_is_replayed(bridge, world):
    with client(bridge) as c:
        r = c.post("/ingest/invocation", json=invocation_event(), headers=BEARER)
    assert r.json()["results"][0]["reason"] == "fiddler_application_missing"
    world.add_app("aig-local", "claims-triage")
    bridge.fiddler._apps.clear()
    [dl] = bridge.store.dead_letters()
    assert json.dumps(dl.payload).count("bob@example.com") == 1  # metadata only, kept for replay
    assert bridge.pipeline.replay(dl.id).status == "forwarded"
    assert attr_dict(span_of(world.traces[0])["attributes"])["aig.invocation_id"] == INV_ID
