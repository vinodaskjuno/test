from __future__ import annotations

import json

import pytest
from fakes import portkey_log
from telemetry_bridge.normalize import (
    NormalizeError,
    cache_status,
    guardrail_results,
    normalize_portkey_log,
    otel_trace_id,
)
from telemetry_bridge.otlp import attr_dict, build_request, decode_protobuf, encode
from telemetry_bridge.redact import Redactor

HOOKS = {
    "before_request_hooks": [{"id": "aig-input-pii", "verdict": False, "deny": False,
                              "checks": [{"id": "portkey.pii", "verdict": False}]},
                             {"id": "aig-agent-check", "verdict": True, "checks": [{"id": "default.webhook", "verdict": True}]}],
    "after_request_hooks": [{"id": "aig-output-policy", "verdict": True, "checks": [{"id": "portkey.moderateContent", "verdict": True}]}],
}


def test_portkey_log_normalizes_to_contract_tags_and_metrics():
    ev = normalize_portkey_log(portkey_log(hooks=HOOKS, cache="SEMANTIC HIT"), cost_unit="cents")
    assert ev.key == "portkey:log_1"
    assert ev.tags == {"agent": "uw-quote-assistant", "team": "underwriting-ai", "tier": "premium", "model": "claude-opus-4-1",
                       "env": "local", "host": "laptop", "aig.trace_id": "0af7651916cd43dd8448eb211c80319c",
                       "aig.user": "jane.doe@example.com"}
    a = ev.attributes
    assert (a["gen_ai.usage.input_tokens"], a["gen_ai.usage.output_tokens"], a["gen_ai.usage.total_tokens"]) == (20, 8, 28)
    assert a["aig.cost_usd"] == 0.015 and a["aig.cache_status"] == "semantic_hit" and a["aig.latency_ms"] == 850
    assert a["aig.guardrail.verdict"] == "fail" and a["aig.guardrail.failed_checks"] == ["aig-input-pii:portkey.pii"]
    assert ev.system == "You are a quoting assistant." and ev.prompt.startswith("Quote for") and ev.reply == "Here is the quote."
    assert not ev.is_error
    assert [g["stage"] for g in ev.guardrails] == ["input", "input", "output"]


def test_metadata_string_anthropic_reply_error_and_usd_cost():
    raw = portkey_log(metadata_as_string=True, status=529, response={"model": "claude-x", "content": [{"type": "text", "text": "hi"}]})
    ev = normalize_portkey_log(raw, cost_unit="usd")
    assert ev.tags["agent"] == "uw-quote-assistant" and ev.reply == "hi"
    assert ev.is_error and ev.status_code == 529 and ev.attributes["aig.cost_usd"] == 1.5


def test_metadata_from_request_headers_and_bad_model_becomes_auto():
    raw = portkey_log(model="x")
    meta = raw.pop("metadata")
    raw["request"]["headers"] = {"X-Portkey-Metadata": json.dumps(meta), "x-portkey-trace-id": "trace-from-header-1"}
    raw.pop("trace_id")
    raw["response"]["model"] = "bad model id!"
    raw["ai_model"] = None
    ev = normalize_portkey_log(raw)
    assert ev.trace_id == "trace-from-header-1"
    assert ev.tags["model"] == "auto"


@pytest.mark.parametrize("raw,reason", [
    ({"metadata": {}}, "missing_log_id"),
    ({"id": "x"}, "missing_metadata"),
    ("not-a-dict", "invalid_payload"),
])
def test_unusable_logs_raise_with_reason(raw, reason):
    with pytest.raises(NormalizeError) as e:
        normalize_portkey_log(raw)
    assert e.value.reason == reason


@pytest.mark.parametrize("value,expected", [("HIT", "hit"), ("MISS", "miss"), ("SEMANTIC_HIT", "semantic_hit"),
                                            ("DISABLED", "disabled"), (None, "unknown")])
def test_cache_status(value, expected):
    assert cache_status({"cache_status": value}) == expected


def test_trace_id_mapping_keeps_portkey_join():
    assert otel_trace_id("0af7651916cd43dd8448eb211c80319c", "k") == "0af7651916cd43dd8448eb211c80319c"
    assert otel_trace_id("6f1c9e0a-7c1d-4c3e-9a55-2b0c9b7f4a10", "k") == "6f1c9e0a7c1d4c3e9a552b0c9b7f4a10"
    other = otel_trace_id("trace-from-header-1", "k")
    assert len(other) == 32 and other == otel_trace_id("trace-from-header-1", "different-seed")


def test_flat_guardrail_list():
    out = guardrail_results({"guardrail_results": [{"id": "g1", "verdict": False, "deny": True, "stage": "output"}]})
    assert out == [{"hook_id": "g1", "stage": "output", "verdict": False, "denied": True, "checks": []}]


def _span(req):
    return req["resourceSpans"][0]["scopeSpans"][0]["spans"][0]


def test_protobuf_round_trip_carries_tags_trace_and_application():
    ev = normalize_portkey_log(portkey_log())
    req = build_request(ev, "11111111-2222-4333-8444-555555555555", Redactor("none"))
    body, ctype = encode(req, "protobuf")
    assert ctype == "application/x-protobuf"
    doc = decode_protobuf(body)
    span = _span(doc)
    assert span["traceId"] == "0af7651916cd43dd8448eb211c80319c"
    attrs = attr_dict(span["attributes"])
    for k in ("agent", "team", "tier", "model", "env", "host"):
        assert attrs[k] == ev.tags[k]
    assert attrs["fiddler.span.type"] == "llm" and attrs["gen_ai.llm.output"] == "Here is the quote."
    assert attr_dict(doc["resourceSpans"][0]["resource"]["attributes"])["application.id"].startswith("11111111")
    body_json, ctype_json = encode(req, "json")
    assert ctype_json == "application/json" and json.loads(body_json) == req


@pytest.mark.parametrize("mode,check", [
    ("pii", lambda a: "[REDACTED_EMAIL]" in a["gen_ai.llm.input.user"] and "jane.doe" not in a["gen_ai.llm.input.user"]),
    ("hash", lambda a: a["gen_ai.llm.input.user"].startswith("sha256:")),
    ("drop", lambda a: "gen_ai.llm.input.user" not in a and "gen_ai.llm.output" not in a),
    ("none", lambda a: "jane.doe@example.com" in a["gen_ai.llm.input.user"]),
])
def test_redaction_modes(mode, check):
    ev = normalize_portkey_log(portkey_log())
    attrs = attr_dict(_span(build_request(ev, "app", Redactor(mode)))["attributes"])
    assert check(attrs)


def test_redactor_masks_keys_cards_and_truncates():
    r = Redactor("pii", max_chars=40)
    out = r.text("key sk-abcdefghijklmnop1234 card 4111 1111 1111 1111 " + "x" * 100)
    assert "sk-abc" not in out and "4111" not in out and out.endswith("[truncated]")
