from __future__ import annotations

import sys
from pathlib import Path

import pytest
import respx

sys.path.insert(0, str(Path(__file__).parent))

import fakes  # noqa: E402
from fakes import FIDDLER_KEY, PORTKEY_KEY  # noqa: E402
from telemetry_bridge.service import Bridge  # noqa: E402
from telemetry_bridge.settings import Settings  # noqa: E402

REPO = Path(__file__).resolve().parents[3]


def make_env(tmp_path: Path, **overrides) -> dict[str, str]:
    env = {
        "AIG_ENV": "local",
        "AIG_BRIDGE_DATABASE_URL": f"sqlite:///{tmp_path / 'bridge.db'}",
        "FIDDLER_URL": fakes.FIDDLER,
        "FIDDLER_API_KEY": FIDDLER_KEY,
        "AIG_PORTKEY_ADMIN_URL": fakes.PORTKEY,
        "AIG_PORTKEY_ADMIN_API_KEY": PORTKEY_KEY,
        "AIG_PLATFORM_API_URL": fakes.PLATFORM,
        "AIG_PLATFORM_SERVICE_TOKEN": fakes.SERVICE_TOKEN,
        "AIG_BRIDGE_PUSH_SECRET": fakes.PUSH_SECRET,
        "AIG_BRIDGE_INGEST_TOKEN": fakes.INGEST_TOKEN,
        "AIG_BRIDGE_RETRY_BACKOFF_SECONDS": "0",
        "AIG_BRIDGE_EVAL_DATASET_DIR": str(tmp_path / "datasets"),
        "AIG_BRIDGE_REPORTS_DIR": str(tmp_path / "reports"),
        "AIG_ALERT_SLACK_WEBHOOK_PLATFORM": fakes.SLACK,
        "AIG_ALERT_SLACK_WEBHOOK_UNDERWRITING": fakes.SLACK,
        "AIG_ALERT_SLACK_WEBHOOK_CLAIMS": fakes.SLACK,
        "AIG_ALERT_PAGERDUTY_ROUTING_KEY": "pd-SUPERSECRET-routing",
    }
    env.update(overrides)
    return {k: v for k, v in env.items() if v is not None}


@pytest.fixture
def world():
    w = fakes.World()
    with respx.mock(assert_all_called=False) as router:
        w.mount(router)
        yield w


class FakeSMTP:
    sent: list = []

    def __init__(self, host, port, timeout=None):
        self.host = host

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self):
        pass

    def login(self, user, password):
        pass

    def send_message(self, msg):
        FakeSMTP.sent.append(msg)


@pytest.fixture
def make_bridge(tmp_path):
    made = []

    def _make(**overrides):
        b = Bridge(Settings.from_env(make_env(tmp_path, **overrides)), sleep=lambda _s: None, smtp_factory=FakeSMTP)
        made.append(b)
        return b

    yield _make
    for b in made:
        b.close()


@pytest.fixture
def bridge(make_bridge):
    return make_bridge()
