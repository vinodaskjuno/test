"""respx-mounted fakes of Fiddler, the Portkey admin API, platform-api and Slack/PagerDuty."""

from __future__ import annotations

import json
import re
import uuid

import httpx
from telemetry_bridge.otlp import decode_protobuf

FIDDLER = "https://fiddler.test"
PORTKEY = "https://portkey-admin.test/v1"
PLATFORM = "https://platform.test"
SLACK = "https://hooks.slack.test/services/T0/B0/SUPERSECRETSLACK"
FIDDLER_KEY = "fdl-SUPERSECRET-key-1234567890"
PORTKEY_KEY = "pk-admin-SUPERSECRET-0987654321"
SERVICE_TOKEN = "svc-SUPERSECRET-token-55555"
PUSH_SECRET = "push-SUPERSECRET-66666"
INGEST_TOKEN = "ingest-SUPERSECRET-77777"


def page(items):
    return {"data": {"items": items, "total": len(items), "page_index": 1, "page_count": 1, "offset": 0}}


class World:
    def __init__(self):
        self.projects = {"aig-local": str(uuid.uuid4()), "aig-dev": str(uuid.uuid4())}
        self.apps: dict[tuple[str, str], str] = {}
        self.traces: list[dict] = []          # decoded OTLP + headers
        self.trace_statuses: list[int] = []   # queued responses for /v1/traces (default 200)
        self.span_counts: dict[str, tuple[int, int]] = {}  # app_id -> (total, bridge)
        self.failing_spans: dict[str, list[dict]] = {}
        self.fiddler_lookup_status = 200
        self.portkey_logs: list[dict] = []
        self.export_status = ["in_progress", "success"]
        self.export_requests: list[dict] = []
        self.download_headers: list[dict] = []
        self.traffic: dict[str, int] = {}
        self.analytics_status = 200
        self.api_keys = [{"id": "key_untraced", "name": "aig-agent-untraced-bot"}]
        self.suspended_keys: list[tuple[str, dict]] = []
        self.agents: dict[str, dict] = {}
        self.suspend_calls: list[tuple[str, dict, dict]] = []
        self.invocations: list[dict] = []  # platform-api GET /api/v1/invocations/summary items
        self.summary_params: list[dict] = []
        self.summary_status = 200
        self.slack: list[dict] = []
        self.pagerduty: list[dict] = []

    def add_app(self, project: str, name: str) -> str:
        app_id = str(uuid.uuid4())
        self.apps[(project, name)] = app_id
        return app_id

    # -- Fiddler -------------------------------------------------------------------------
    def fiddler(self, request: httpx.Request) -> httpx.Response:
        if request.headers.get("authorization") != f"Bearer {FIDDLER_KEY}":
            return httpx.Response(401)
        path = request.url.path
        if path in ("/v3/projects", "/v3/applications") and self.fiddler_lookup_status != 200:
            return httpx.Response(self.fiddler_lookup_status)
        flt = {r["field"]: r["value"] for r in json.loads(request.url.params.get("filter", '{"rules": []}'))["rules"]}
        if path == "/v3/projects":
            return httpx.Response(200, json=page([{"id": i, "name": n} for n, i in self.projects.items() if flt.get("name", n) == n]))
        if path == "/v3/applications":
            pname = next((n for n, i in self.projects.items() if i == flt.get("project_id")), None)
            items = [{"id": i, "name": a} for (p, a), i in self.apps.items() if p == pname and flt.get("name", a) == a]
            return httpx.Response(200, json=page(items))
        if path == "/v1/traces":
            status = self.trace_statuses.pop(0) if self.trace_statuses else 200
            if status == 200:
                ctype = request.headers["content-type"]
                body = decode_protobuf(request.content) if ctype == "application/x-protobuf" else json.loads(request.content)
                self.traces.append({"headers": dict(request.headers), "body": body})
            return httpx.Response(status, json={} if status == 200 else {"error": "x"})
        if path == "/v3/spans/fields":
            body = json.loads(request.content)
            total, bridge = self.span_counts.get(body["application_id"], (0, 0))
            n = bridge if "filter" in body else total
            return httpx.Response(200, json={"data": {"total_spans": n, "sampled": False, "span_attributes": []}})
        if path == "/v3/spans/query":
            body = json.loads(request.content)
            items = self.failing_spans.get(body["application_id"], [])
            self.last_query_filter = body["filter"]
            return httpx.Response(200, json={"data": {"items": items, "page_index": 1, "page_count": 1}})
        return httpx.Response(404)

    # -- Portkey -------------------------------------------------------------------------
    def portkey(self, request: httpx.Request) -> httpx.Response:
        if request.headers.get("x-portkey-api-key") != PORTKEY_KEY:
            return httpx.Response(401, text="bad key")
        path = request.url.path.removeprefix("/v1")
        if path == "/logs/exports" and request.method == "POST":
            self.export_requests.append(json.loads(request.content))
            return httpx.Response(200, json={"id": "exp_1", "total": len(self.portkey_logs)})
        if path == "/logs/exports/exp_1/start":
            return httpx.Response(200, json={"message": "started"})
        if path == "/logs/exports/exp_1":
            status = self.export_status.pop(0) if len(self.export_status) > 1 else self.export_status[0]
            return httpx.Response(200, json={"id": "exp_1", "status": status})
        if path == "/logs/exports/exp_1/download":
            return httpx.Response(200, json={"signed_url": "https://exports.s3.test/exp_1.jsonl?sig=abc"})
        if path == "/logs":
            page_no = int(request.url.params.get("current_page", 0))
            return httpx.Response(200, json={"data": self.portkey_logs if page_no == 0 else []})
        if path == "/analytics/groups/metadata/agent_id":
            if self.analytics_status != 200:
                return httpx.Response(self.analytics_status, text="boom")
            rows = [{"metadata_value": k, "requests": v, "cost": 1} for k, v in self.traffic.items()]
            return httpx.Response(200, json={"total": len(rows), "data": rows})
        if path == "/api-keys" and request.method == "GET":
            return httpx.Response(200, json={"data": self.api_keys})
        if m := re.fullmatch(r"/api-keys/([^/]+)", path):
            self.suspended_keys.append((m.group(1), json.loads(request.content or b"{}")))
            return httpx.Response(200, json={"success": True})
        return httpx.Response(404)

    def download(self, request: httpx.Request) -> httpx.Response:
        self.download_headers.append(dict(request.headers))
        return httpx.Response(200, text="\n".join(json.dumps(entry) for entry in self.portkey_logs) + "\n")

    # -- platform-api --------------------------------------------------------------------
    def platform(self, request: httpx.Request) -> httpx.Response:
        if request.headers.get("x-aig-service-token") != SERVICE_TOKEN:
            return httpx.Response(401, json={"error": {"code": "service_unauthenticated"}})
        if request.url.path == "/api/v1/invocations/summary":
            self.summary_params.append(dict(request.url.params))
            if self.summary_status != 200:
                return httpx.Response(self.summary_status, json={"error": {"code": "x"}})
            return httpx.Response(200, json={"since": request.url.params["since"], "until": request.url.params["until"],
                                             "items": self.invocations, "total": len(self.invocations)})
        if request.url.path == "/api/v1/agents":
            return httpx.Response(200, json={"agents": list(self.agents.values())})
        if m := re.fullmatch(r"/api/v1/agents/([^/]+)/suspend", request.url.path):
            aid = m.group(1)
            if aid not in self.agents:
                return httpx.Response(404)
            body = json.loads(request.content)
            self.suspend_calls.append((aid, body, dict(request.headers)))
            changed = self.agents[aid]["status"] != "suspended"
            self.agents[aid]["status"] = "suspended"
            return httpx.Response(200, json={"agent": self.agents[aid], "changed": changed})
        return httpx.Response(404)

    def mount(self, router) -> None:
        router.route(host="fiddler.test").mock(side_effect=self.fiddler)
        router.route(host="portkey-admin.test").mock(side_effect=self.portkey)
        router.route(host="exports.s3.test").mock(side_effect=self.download)
        router.route(host="platform.test").mock(side_effect=self.platform)
        router.route(host="hooks.slack.test").mock(side_effect=lambda r: (self.slack.append(json.loads(r.content)), httpx.Response(200))[1])
        router.route(host="events.pagerduty.com").mock(side_effect=lambda r: (self.pagerduty.append(json.loads(r.content)), httpx.Response(202))[1])


def portkey_log(log_id: str = "log_1", *, agent: str = "uw-quote-assistant", team: str = "underwriting-ai", tier: str = "premium",
                env: str = "local", host: str = "laptop", trace_id: str = "0af7651916cd43dd8448eb211c80319c",
                prompt: str = "Quote for jane.doe@example.com please", reply: str = "Here is the quote.",
                status: int = 200, cache: str = "MISS", hooks: dict | None = None, created_at: str = "2026-10-08T10:00:00.000Z",
                metadata_as_string: bool = False, **extra) -> dict:
    metadata = {"agent_id": agent, "team": team, "user_tier": tier, "job_profile": "underwriting", "env": env, "host": host,
                "user": "jane.doe@example.com", "_user": "jane.doe@example.com"}
    log = {
        "id": log_id, "trace_id": trace_id, "created_at": created_at,
        "request": {"model": "claude-opus", "messages": [{"role": "system", "content": "You are a quoting assistant."},
                                                          {"role": "user", "content": prompt}]},
        "response": {"model": "claude-opus-4-1", "choices": [{"message": {"role": "assistant", "content": reply}}],
                     "usage": {"prompt_tokens": 20, "completion_tokens": 8, "total_tokens": 28}},
        "ai_org": "anthropic", "ai_model": "claude-opus-4-1", "req_units": 20, "res_units": 8, "total_units": 28,
        "cost": 1.5, "cost_currency": "USD", "response_time": 850, "response_status_code": status, "is_success": status < 400,
        "metadata": json.dumps(metadata) if metadata_as_string else metadata, "cache_status": cache,
    }
    if hooks is not None:
        log["hook_results"] = hooks
    log.update(extra)
    return log
