from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fakes import PORTKEY_KEY, portkey_log
from telemetry_bridge.puller import CURSOR, pull_once

NOW = datetime(2026, 10, 8, 12, 0, tzinfo=timezone.utc)


def test_export_pull_forwards_and_advances_high_water_mark(bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    world.portkey_logs = [portkey_log("l1"), portkey_log("l2"), portkey_log("l3", tier="bogus")]
    out = pull_once(bridge, now=NOW)
    assert out["status"] == "ok", out
    assert out["counts"] == {"forwarded": 2, "quarantined": 1}
    assert len(world.traces) == 2
    req = world.export_requests[0]
    assert "metadata" in req["requested_data"] and "hook_results" in req["requested_data"]
    assert req["filters"]["time_of_generation_max"] == (NOW - timedelta(seconds=60)).isoformat()
    # the signed download URL never receives the Portkey admin key
    assert all("x-portkey-api-key" not in h and PORTKEY_KEY not in str(h) for h in world.download_headers)
    assert bridge.store.get_cursor(CURSOR) == (NOW - timedelta(seconds=60)).isoformat()

    # Next run overlaps the previous window: already-seen logs are duplicates, new ones forwarded.
    world.portkey_logs.append(portkey_log("l4"))
    world.export_status = ["success"]
    out2 = pull_once(bridge, now=NOW + timedelta(minutes=5))
    assert out2["counts"] == {"duplicate": 3, "forwarded": 1}
    start = datetime.fromisoformat(world.export_requests[1]["filters"]["time_of_generation_min"])
    assert start == NOW - timedelta(seconds=60) - timedelta(seconds=300)


def test_failed_export_keeps_cursor(bridge, world):
    world.export_status = ["failed"]
    out = pull_once(bridge, now=NOW)
    assert out["status"] == "error"
    assert bridge.store.get_cursor(CURSOR) is None


def test_list_mode_and_off(make_bridge, world):
    world.add_app("aig-local", "uw-quote-assistant")
    world.portkey_logs = [portkey_log("x1")]
    b = make_bridge(AIG_BRIDGE_PULL_MODE="list")
    assert pull_once(b, now=NOW)["counts"] == {"forwarded": 1}
    assert pull_once(make_bridge(AIG_BRIDGE_PULL_MODE="off"), now=NOW) == {"status": "disabled"}


def test_up_to_date_window(bridge, world):
    bridge.store.set_cursor(CURSOR, NOW.isoformat())
    assert pull_once(bridge, now=NOW)["status"] == "up_to_date"


def test_unconfigured_portkey_is_an_error_not_a_crash(make_bridge, world):
    out = pull_once(make_bridge(AIG_PORTKEY_ADMIN_API_KEY="__REPLACE_ME_X__"), now=NOW)
    assert out["status"] == "error" and "not configured" in out["error"]
