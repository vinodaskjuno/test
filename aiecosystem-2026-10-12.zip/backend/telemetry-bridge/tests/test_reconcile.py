"""Exit criterion (Phase 3): a reconciliation run suspends a deliberately untraced agent."""

from __future__ import annotations

import json
from datetime import date

import yaml
from conftest import FakeSMTP
from fakes import SERVICE_TOKEN
from telemetry_bridge.cli import main
from telemetry_bridge.reconcile import run_reconcile

DAY = date(2026, 10, 8)


def seed(world):
    world.agents = {
        "uw-quote-assistant": {"agent_id": "uw-quote-assistant", "owner": "jane.doe@example.com", "team": "underwriting-ai", "status": "active"},
        "untraced-bot": {"agent_id": "untraced-bot", "owner": "bob@example.com", "team": "claims-ai", "status": "active"},
        "quiet-bot": {"agent_id": "quiet-bot", "owner": "bob@example.com", "team": "claims-ai", "status": "active"},
        "legacy-bot": {"agent_id": "legacy-bot", "owner": "bob@example.com", "team": "claims-ai", "status": "suspended"},
        "ide.vscode": {"agent_id": "ide.vscode", "owner": "platform-team@aig.example.com", "team": "aig-platform", "status": "active", "shared": True},
    }
    world.traffic = {"uw-quote-assistant": 40, "untraced-bot": 12, "legacy-bot": 3, "ide.vscode": 900, "ghost-agent": 5}
    traced = world.add_app("aig-dev", "uw-quote-assistant")
    untraced = world.add_app("aig-dev", "untraced-bot")
    world.span_counts = {traced: (55, 15), untraced: (12, 12)}  # untraced: only the bridge's gateway spans


def row(report, agent_id):
    return next(r for r in report["agents"] if r["agent_id"] == agent_id)


def test_untraced_agent_is_suspended_key_disabled_and_owner_alerted(make_bridge, world):
    seed(world)
    FakeSMTP.sent.clear()
    b = make_bridge(AIG_ENV="dev", AIG_BRIDGE_SMTP_HOST="smtp.test")
    report = run_reconcile(b, day=DAY)

    assert report["summary"]["suspended"] == ["untraced-bot"]
    assert report["summary"]["errors"] == 0
    r = row(report, "untraced-bot")
    assert r["verdict"] == "violation" and r["spans_sdk"] == 0 and r["spans_total"] == 12
    assert {a["type"]: a["status"] for a in r["actions"]} == {"registry_suspend": "done", "portkey_key_suspend": "done", "alert": "done"}
    # registry: platform-api admin endpoint with the service token
    [(aid, body, headers)] = world.suspend_calls
    assert aid == "untraced-bot" and headers["x-aig-service-token"] == SERVICE_TOKEN
    assert body["source"] == "reconciliation" and body["evidence"]["gateway_requests"] == 12
    assert world.agents["untraced-bot"]["status"] == "suspended"
    # Portkey admin API: the agent's key
    assert world.suspended_keys == [("key_untraced", {"status": "disabled"})]
    # alerts: Slack (platform + claims team) with links, email to owner + platform team; no PagerDuty for this event
    assert len(world.slack) == 2 and "untraced-bot" in world.slack[0]["text"]
    assert "/applications/untraced-bot" in world.slack[0]["text"]
    assert world.pagerduty == []
    rcpts = sorted(m["To"] for m in FakeSMTP.sent)
    assert any("bob@example.com" in t for t in rcpts) and any("platform-team@aig.example.com" in t for t in rcpts)

    assert row(report, "uw-quote-assistant")["verdict"] == "ok" and row(report, "uw-quote-assistant")["spans_sdk"] == 40
    assert row(report, "ide.vscode")["verdict"] == "exempt"
    assert row(report, "legacy-bot")["verdict"] == "already_suspended"
    assert row(report, "quiet-bot")["verdict"] == "no_traffic"
    assert row(report, "ghost-agent")["verdict"] == "unregistered_traffic"

    # Next day the agent is already suspended: nothing more happens.
    again = run_reconcile(b, day=DAY)
    assert again["summary"]["suspended"] == [] and row(again, "untraced-bot")["verdict"] == "already_suspended"
    assert len(world.suspend_calls) == 1


def test_dry_run_changes_nothing(make_bridge, world):
    seed(world)
    report = run_reconcile(make_bridge(AIG_ENV="dev"), day=DAY, dry_run=True)
    assert report["dry_run"] and report["summary"]["suspended"] == ["untraced-bot"]
    assert {a["status"] for a in row(report, "untraced-bot")["actions"] if a["type"] != "alert"} == {"dry_run"}
    assert world.suspend_calls == [] and world.suspended_keys == [] and world.slack == []


def test_portkey_analytics_failure_suspends_nothing(make_bridge, world):
    seed(world)
    world.analytics_status = 500
    report = run_reconcile(make_bridge(AIG_ENV="dev", AIG_BRIDGE_RETRY_ATTEMPTS="1"), day=DAY)
    assert report["errors"] and report["agents"] == [] and world.suspend_calls == []


def test_fiddler_error_is_reported_not_punished(make_bridge, world):
    seed(world)
    world.fiddler_lookup_status = 500
    report = run_reconcile(make_bridge(AIG_ENV="dev"), day=DAY)
    assert row(report, "untraced-bot")["verdict"] == "error"
    assert report["summary"]["errors"] >= 1 and world.suspend_calls == []


def test_missing_agent_key_still_suspends_in_registry(make_bridge, world):
    seed(world)
    world.api_keys = []
    report = run_reconcile(make_bridge(AIG_ENV="dev"), day=DAY)
    acts = {a["type"]: a for a in row(report, "untraced-bot")["actions"]}
    assert acts["portkey_key_suspend"]["status"] == "key_not_found"
    assert acts["registry_suspend"]["status"] == "done"


def test_trace_ratio_tolerance(make_bridge, world):
    seed(world)
    traced = world.apps[("aig-dev", "uw-quote-assistant")]
    world.span_counts[traced] = (19, 15)  # 4 SDK spans for 40 requests
    lenient = run_reconcile(make_bridge(AIG_ENV="dev"), day=DAY, dry_run=True)
    assert row(lenient, "uw-quote-assistant")["verdict"] == "ok"
    strict = run_reconcile(make_bridge(AIG_ENV="dev", AIG_BRIDGE_RECONCILE_MIN_TRACE_RATIO="0.5"), day=DAY, dry_run=True)
    assert row(strict, "uw-quote-assistant")["verdict"] == "violation"


def test_yaml_registry_mode(make_bridge, world, tmp_path):
    seed(world)
    reg = tmp_path / "agents.yaml"
    reg.write_text(yaml.safe_dump({"agents": {k: {kk: vv for kk, vv in v.items() if kk != "agent_id"} for k, v in world.agents.items()}}))
    report = run_reconcile(make_bridge(AIG_ENV="dev", AIG_BRIDGE_REGISTRY_FILE=str(reg), AIG_PLATFORM_API_URL=None), day=DAY)
    assert report["summary"]["suspended"] == ["untraced-bot"]
    doc = yaml.safe_load(reg.read_text())
    assert doc["agents"]["untraced-bot"]["status"] == "suspended"
    assert doc["agents"]["untraced-bot"]["status_reason"].startswith("reconciliation: gateway traffic")
    assert doc["agents"]["uw-quote-assistant"]["status"] == "active"
    assert world.suspend_calls == []


def test_cli_reconcile_dry_run_exit_code_and_report(world, tmp_path, monkeypatch, capsys):
    from conftest import make_env

    seed(world)
    for k, v in make_env(tmp_path, AIG_ENV="dev").items():
        monkeypatch.setenv(k, v)
    out = tmp_path / "r.json"
    assert main(["reconcile", "--date", DAY.isoformat(), "--dry-run", "--exit-code", "--output", str(out)]) == 3
    report = json.loads(out.read_text())
    assert report["summary"]["suspended"] == ["untraced-bot"] and world.suspend_calls == []
    assert SERVICE_TOKEN not in capsys.readouterr().out


# --- W7: registered versions with invocations but no Fiddler traces ---------------------------


def seed_invocations(world):
    seed(world)
    world.agents["invoked-untraced"] = {"agent_id": "invoked-untraced", "owner": "bob@example.com", "team": "claims-ai",
                                        "status": "active"}
    world.add_app("aig-dev", "invoked-untraced")  # no SDK spans at all
    world.invocations = [
        {"agent_id": "invoked-untraced", "version": "1.4.0", "env": "prod", "invocations": 7, "succeeded": 7, "failed": 0},
        {"agent_id": "invoked-untraced", "version": "1.5.0", "env": "prod", "invocations": 2, "succeeded": 1, "failed": 1},
        {"agent_id": "uw-quote-assistant", "version": "2.0", "env": "prod", "invocations": 30, "succeeded": 30, "failed": 0},
        {"agent_id": "legacy-bot", "version": "0.1", "env": "prod", "invocations": 1, "succeeded": 1, "failed": 0},
    ]


def inv_row(report, agent_id):
    return next(r for r in report["invocations"]["agents"] if r["agent_id"] == agent_id)


def test_versions_with_invocations_but_no_traces_are_reported_not_suspended_by_default(make_bridge, world):
    seed_invocations(world)
    report = run_reconcile(make_bridge(AIG_ENV="dev"), day=DAY)
    assert world.summary_params[0]["env"] == "prod" and world.summary_params[0]["since"].startswith("2026-10-08")
    r = inv_row(report, "invoked-untraced")
    assert r["verdict"] == "untraced_invocations" and r["invocations"] == 9 and r["spans_sdk"] == 0
    assert [v["version"] for v in r["versions"]] == ["1.4.0", "1.5.0"]
    assert r["actions"] == [{"type": "report", "status": "report_only",
                             "note": "set AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS=true to suspend"}]
    assert inv_row(report, "uw-quote-assistant")["verdict"] == "ok"
    assert inv_row(report, "legacy-bot")["verdict"] == "already_suspended"
    assert report["summary"]["untraced_invocations"] == ["invoked-untraced"]
    assert report["summary"]["suspended"] == ["untraced-bot"]  # gateway rule only
    assert world.agents["invoked-untraced"]["status"] == "active"


def test_untraced_invocations_suspend_when_enabled_and_respect_dry_run(make_bridge, world):
    seed_invocations(world)
    b = make_bridge(AIG_ENV="dev", AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS="true")
    dry = run_reconcile(b, day=DAY, dry_run=True)
    assert {a["type"]: a["status"] for a in inv_row(dry, "invoked-untraced")["actions"]}["registry_suspend"] == "dry_run"
    assert world.agents["invoked-untraced"]["status"] == "active"
    report = run_reconcile(b, day=DAY)
    assert {a["type"]: a["status"] for a in inv_row(report, "invoked-untraced")["actions"]}["registry_suspend"] == "done"
    assert world.agents["invoked-untraced"]["status"] == "suspended"
    body = next(body for aid, body, _ in world.suspend_calls if aid == "invoked-untraced")
    assert body["evidence"]["invocations"] == 9 and "invocations without Fiddler traces" in body["reason"]
    assert "invoked-untraced" in report["summary"]["suspended"]


def test_invocation_summary_failure_is_an_error_not_a_suspension(make_bridge, world):
    seed_invocations(world)
    b = make_bridge(AIG_ENV="dev", AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS="true")
    world.summary_status = 503
    report = run_reconcile(b, day=DAY)
    assert world.agents["invoked-untraced"]["status"] == "active"
    assert any(e.startswith("invocation summary") for e in report["errors"]) and report["summary"]["errors"] >= 1
    assert report["invocations"]["agents"] == []
