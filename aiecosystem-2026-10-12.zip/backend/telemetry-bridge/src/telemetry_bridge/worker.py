"""Background loop: Portkey pull + redelivery of pending events, every AIG_BRIDGE_PULL_INTERVAL_SECONDS."""

from __future__ import annotations

import logging
import threading

from .puller import pull_once

log = logging.getLogger(__name__)


class Worker:
    def __init__(self, bridge, interval: float):
        self.bridge = bridge
        self.interval = interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def run_once(self) -> dict:
        out = {"pull": pull_once(self.bridge)}
        try:
            out["retry"] = self.bridge.pipeline.retry_pending()
        except Exception as exc:  # keep the loop alive
            log.error("retry_pending failed: %s", type(exc).__name__)
            out["retry"] = {"error": type(exc).__name__}
        self.bridge.pipeline.refresh_gauges()
        return out

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.run_once()
            except Exception as exc:
                log.error("worker iteration failed: %s", type(exc).__name__)
            self._stop.wait(self.interval)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop, name="bridge-worker", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=10)
