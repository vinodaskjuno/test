"""Build OTLP/HTTP trace export requests for Fiddler.

One gateway event = one span (``fiddler.span.type = llm``) in a trace whose id is the
Portkey trace id (see ``normalize.otel_trace_id``), so the SDK's spans for the same call and
the gateway event share a trace. Attribute names follow fiddler-otel 1.4.1
(``gen_ai.llm.input.user``, ``gen_ai.llm.input.system``, ``gen_ai.llm.output``,
``gen_ai.usage.*``, ``gen_ai.agent.id``, resource ``application.id``) plus the AIG tag set.

fiddler-otel exports protobuf (``application/x-protobuf``), which is the default here
(FIDDLER_OTLP_ENCODING=protobuf); ``json`` sends OTLP/JSON (spec-compliant, but whether
Fiddler accepts it is unverified).
"""

from __future__ import annotations

import base64
import copy
from typing import Any

from google.protobuf import json_format
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import (
    ExportTraceServiceRequest,
)

from . import __version__
from .normalize import GatewayEvent, otel_trace_id, span_id
from .redact import Redactor

SPAN_KIND_CLIENT = 3
SPAN_NAMES = {"portkey": "portkey.gateway", "ide": "ide.usage", "invocation": "aig.agent.invocation"}
STATUS_OK, STATUS_ERROR = 1, 2


def _value(v: Any) -> dict:
    if isinstance(v, bool):
        return {"boolValue": v}
    if isinstance(v, int):
        return {"intValue": str(v)}
    if isinstance(v, float):
        return {"doubleValue": v}
    if isinstance(v, (list, tuple)):
        return {"arrayValue": {"values": [_value(x) for x in v]}}
    return {"stringValue": str(v)}


def attributes(d: dict[str, Any]) -> list[dict]:
    return [{"key": k, "value": _value(v)} for k, v in sorted(d.items()) if v is not None]


def attr_dict(attrs: list[dict]) -> dict[str, Any]:
    """OTLP JSON attribute list -> plain dict (string/int/double/bool only)."""
    out = {}
    for a in attrs or []:
        v = a.get("value") or {}
        for k in ("stringValue", "intValue", "doubleValue", "boolValue"):
            if k in v:
                out[a.get("key")] = v[k]
                break
    return out


def build_span(event: GatewayEvent, redactor: Redactor) -> dict:
    start_ns = int(event.start.timestamp() * 1e9)
    end_ns = start_ns + int((event.latency_ms or 0) * 1e6)
    attrs: dict[str, Any] = {**event.attributes, **event.tags}
    attrs["fiddler.span.type"] = "chain" if event.source == "invocation" else "llm"
    attrs["gen_ai.agent.id"] = event.agent
    attrs["gen_ai.agent.name"] = event.agent
    for key, text in (("gen_ai.llm.input.system", event.system), ("gen_ai.llm.input.user", event.prompt),
                      ("gen_ai.llm.output", event.reply)):
        red = redactor.text(text)
        if red:
            attrs[key] = red
    if event.prompt or event.reply:
        attrs["aig.content_redaction"] = redactor.mode
    span = {
        "traceId": otel_trace_id(event.trace_id, event.key),
        "spanId": span_id(event.key),
        "name": SPAN_NAMES.get(event.source, "ide.usage"),
        "kind": SPAN_KIND_CLIENT,
        "startTimeUnixNano": str(start_ns),
        "endTimeUnixNano": str(max(end_ns, start_ns)),
        "attributes": attributes(attrs),
        "status": {"code": STATUS_ERROR if event.is_error else STATUS_OK},
    }
    if event.is_error and event.status_code:
        span["status"]["message"] = f"HTTP {event.status_code}"
    return span


def build_request(event: GatewayEvent, application_id: str, redactor: Redactor) -> dict:
    resource = {"application.id": application_id, "service.name": "aig-telemetry-bridge",
                "service.version": __version__, "env": event.env, "agent": event.agent}
    return {
        "resourceSpans": [{
            "resource": {"attributes": attributes(resource)},
            "scopeSpans": [{"scope": {"name": "aig.telemetry_bridge", "version": __version__},
                            "spans": [build_span(event, redactor)]}],
        }]
    }


def _hex_to_b64(h: str) -> str:
    return base64.b64encode(bytes.fromhex(h)).decode()


def encode(request: dict, encoding: str) -> tuple[bytes, str]:
    if encoding == "json":
        import json

        return json.dumps(request, separators=(",", ":")).encode(), "application/json"
    doc = copy.deepcopy(request)
    for rs in doc.get("resourceSpans", []):
        for ss in rs.get("scopeSpans", []):
            for sp in ss.get("spans", []):
                for k in ("traceId", "spanId", "parentSpanId"):
                    if sp.get(k):
                        sp[k] = _hex_to_b64(sp[k])
    msg = json_format.ParseDict(doc, ExportTraceServiceRequest(), ignore_unknown_fields=False)
    return msg.SerializeToString(), "application/x-protobuf"


def decode_protobuf(data: bytes) -> dict:
    """Test helper: protobuf bytes -> OTLP JSON dict (ids as hex)."""
    msg = ExportTraceServiceRequest()
    msg.ParseFromString(data)
    doc = json_format.MessageToDict(msg)
    for rs in doc.get("resourceSpans", []):
        for ss in rs.get("scopeSpans", []):
            for sp in ss.get("spans", []):
                for k in ("traceId", "spanId"):
                    if sp.get(k):
                        sp[k] = base64.b64decode(sp[k]).hex()
    return doc
