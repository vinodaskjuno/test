"""Event pipeline: dedupe -> validate tags -> resolve the Fiddler application -> OTLP ->
deliver with retries. Nothing is dropped silently: invalid or undeliverable events go to the
dead-letter table (``bridge_dead_letters``) with a reason, and transient delivery failures stay
``pending`` for the worker to retry with backoff until AIG_BRIDGE_MAX_DELIVERY_ATTEMPTS.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

from .normalize import (
    GatewayEvent,
    NormalizeError,
    normalize_ide_usage,
    normalize_invocation,
    normalize_portkey_log,
)
from .otlp import build_request, encode
from .retry import PermanentError, TransientError, backoff_delay, call_with_retries

if TYPE_CHECKING:
    from .service import Bridge

log = logging.getLogger(__name__)


@dataclass
class Result:
    key: str
    status: str  # forwarded | duplicate | quarantined | pending
    reason: str | None = None
    details: Any = None
    extra: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        d = {"key": self.key, "status": self.status}
        if self.reason:
            d["reason"] = self.reason
        if self.details is not None:
            d["details"] = self.details
        return d


def _fingerprint(raw: Any) -> str:
    try:
        blob = json.dumps(raw, sort_keys=True, default=str)
    except (TypeError, ValueError):
        blob = repr(raw)
    return "sha256:" + hashlib.sha256(blob.encode()).hexdigest()[:32]


def set_application_id(otlp: dict, app_id: str) -> dict:
    for rs in otlp.get("resourceSpans", []):
        attrs = rs.setdefault("resource", {}).setdefault("attributes", [])
        for a in attrs:
            if a.get("key") == "application.id":
                a["value"] = {"stringValue": app_id}
                break
        else:
            attrs.append({"key": "application.id", "value": {"stringValue": app_id}})
    return otlp


class Pipeline:
    def __init__(self, bridge: "Bridge"):
        self.b = bridge
        self.s = bridge.settings

    # -- entry points --------------------------------------------------------------------
    def ingest_portkey(self, raw: Any) -> Result:
        self.b.metrics.received.labels("portkey").inc()
        try:
            event = normalize_portkey_log(raw, cost_unit=self.s.portkey_cost_unit)
        except NormalizeError as exc:
            log_id = raw.get("id") if isinstance(raw, dict) else None
            key = f"portkey:{log_id}" if log_id else f"portkey:{_fingerprint(raw)}"
            return self._quarantine(key, "portkey", exc.reason, exc.details, raw)
        return self._process(event, raw)

    def ingest_ide(self, raw: Any) -> Result:
        self.b.metrics.received.labels("ide").inc()
        event_id = raw.get("event_id") if isinstance(raw, dict) else None
        key = f"ide:{event_id}" if isinstance(event_id, str) and event_id else f"ide:{_fingerprint(raw)}"
        errors = self.b.contracts.ide_usage_errors(raw)
        if errors:
            return self._quarantine(key, "ide", "invalid_event", errors, raw)
        return self._process(normalize_ide_usage(raw), raw)

    def ingest_invocation(self, raw: Any) -> Result:
        """platform-api invocation records (metadata only). Invalid ones are dead-lettered."""
        self.b.metrics.received.labels("invocation").inc()
        inv_id = raw.get("invocation_id") if isinstance(raw, dict) else None
        key = f"invocation:{inv_id}" if isinstance(inv_id, str) and inv_id else f"invocation:{_fingerprint(raw)}"
        errors = self.b.contracts.invocation_errors(raw)
        if errors:
            return self._quarantine(key, "invocation", "invalid_event", errors, raw)
        return self._process(normalize_invocation(raw), raw)

    # -- core ----------------------------------------------------------------------------
    def _quarantine(self, key: str, source: str, reason: str, details: Any, raw: Any, retryable: bool = False) -> Result:
        if self.b.store.event_status(key) == "quarantined" and not retryable:
            self.b.metrics.duplicates.labels(source).inc()
            return Result(key, "duplicate", reason)
        self.b.store.quarantine(key, source=source, reason=reason, details=details,
                                payload=self.b.redactor.payload(raw), retryable=retryable)
        self.b.metrics.quarantined.labels(source, reason).inc()
        log.warning("quarantined %s: %s", key, reason)
        return Result(key, "quarantined", reason, details)

    def _process(self, event: GatewayEvent, raw: Any) -> Result:
        store, metrics = self.b.store, self.b.metrics
        if store.event_status(event.key) is not None:
            metrics.duplicates.labels(event.source).inc()
            return Result(event.key, "duplicate")
        errors = self.b.contracts.tag_errors(event.tags)
        if errors:
            return self._quarantine(event.key, event.source, "invalid_tags", {"errors": errors, "tags": event.tags}, raw)
        if event.guardrails:
            rows = []
            for g in event.guardrails:
                checks = g["checks"] or [{"id": "-", "verdict": g["verdict"]}]
                rows += [{"hook_id": g["hook_id"], "check_id": c["id"], "stage": g["stage"], "verdict": c["verdict"],
                          "denied": g["denied"]} for c in checks]
            store.add_guardrail_stats(event.start.date().isoformat(), event.agent, rows)
        project = self.s.project_for(event.env)
        application = event.agent
        try:
            app_id = self.b.fiddler.application_id(project, application)
            if not app_id and self.s.fiddler_fallback_application:
                application = self.s.fiddler_fallback_application
                app_id = self.b.fiddler.application_id(project, application)
        except TransientError as exc:
            otlp = build_request(event, "", self.b.redactor)
            return self._defer(event.key, event.source, otlp, str(exc), project=project, application=application,
                               trace_id=event.trace_id)
        except PermanentError as exc:
            return self._quarantine(event.key, event.source, "fiddler_not_configured" if "not configured" in str(exc)
                                    else "fiddler_lookup_failed", str(exc), raw, retryable=True)
        if not app_id:
            return self._quarantine(event.key, event.source, "fiddler_application_missing",
                                    {"project": project, "application": application,
                                     "hint": "run fiddler-sync apply (or enable AIG_FIDDLER_AUTOPROVISION) then replay"},
                                    raw, retryable=True)
        otlp = build_request(event, app_id, self.b.redactor)
        return self._deliver(event.key, event.source, otlp, app_id, raw=raw, project=project, application=application,
                             trace_id=event.trace_id)

    def _defer(self, key: str, source: str, otlp: dict, error: str, attempts_so_far: int = 0, **cols) -> Result:
        delay = backoff_delay(attempts_so_far + 1, max(self.s.retry_backoff_seconds, 1.0), cap=900.0)
        self.b.store.save_event(key, source=source, status="pending", payload=otlp, error=error[:500],
                                next_attempt_at=datetime.now(timezone.utc) + timedelta(seconds=delay), attempts_inc=1, **cols)
        self.b.metrics.pending.labels(source).inc()
        return Result(key, "pending", "delivery_deferred", error[:200])

    def _deliver(self, key: str, source: str, otlp: dict, app_id: str, *, raw: Any = None, attempts_so_far: int = 0,
                 **cols) -> Result:
        body, ctype = encode(otlp, self.s.fiddler_otlp_encoding)
        try:
            with self.b.metrics.forward_latency.time():
                call_with_retries(lambda: self.b.fiddler.export(body, ctype, app_id), attempts=self.s.retry_attempts,
                                  base=self.s.retry_backoff_seconds, sleep=self.b.sleep)
        except TransientError as exc:
            self.b.metrics.forward_errors.labels("transient").inc()
            return self._defer(key, source, otlp, str(exc), attempts_so_far, application_id=app_id, **cols)
        except PermanentError as exc:
            self.b.metrics.forward_errors.labels("permanent").inc()
            return self._quarantine(key, source, "fiddler_rejected", {"status": exc.status, "error": str(exc)[:300]},
                                    raw if raw is not None else otlp)
        self.b.store.save_event(key, source=source, status="forwarded", payload=None, error=None,
                                next_attempt_at=None, attempts_inc=1, application_id=app_id, **cols)
        self.b.metrics.forwarded.labels(source).inc()
        return Result(key, "forwarded")

    # -- worker --------------------------------------------------------------------------
    def retry_pending(self, now: datetime | None = None, limit: int = 200) -> dict[str, int]:
        now = now or datetime.now(timezone.utc)
        counts: dict[str, int] = {}
        for e in self.b.store.due_pending(now, limit):
            if e.attempts >= self.s.max_delivery_attempts:
                r = self._quarantine(e.key, e.source, "delivery_exhausted", {"attempts": e.attempts, "last_error": e.last_error},
                                     e.payload, retryable=True)
            else:
                app_id = e.application_id
                if not app_id:
                    try:
                        app_id = self.b.fiddler.application_id(e.project or "", e.application or "")
                    except (TransientError, PermanentError) as exc:
                        r = self._defer(e.key, e.source, e.payload, str(exc), e.attempts)
                        counts[r.status] = counts.get(r.status, 0) + 1
                        continue
                    if not app_id:
                        r = self._quarantine(e.key, e.source, "fiddler_application_missing",
                                             {"project": e.project, "application": e.application}, e.payload, retryable=True)
                        counts[r.status] = counts.get(r.status, 0) + 1
                        continue
                otlp = set_application_id(e.payload, app_id)
                r = self._deliver(e.key, e.source, otlp, app_id, attempts_so_far=e.attempts,
                                  project=e.project, application=e.application, trace_id=e.trace_id)
            counts[r.status] = counts.get(r.status, 0) + 1
        return counts

    def replay(self, dl_id: int) -> Result | None:
        dl = self.b.store.release_for_replay(dl_id)
        if dl is None:
            return None
        payload = dl.payload
        if isinstance(payload, dict) and "resourceSpans" in payload:
            app = None
            try:
                attrs = payload["resourceSpans"][0]["resource"]["attributes"]
                app = next((a["value"].get("stringValue") for a in attrs if a["key"] == "application.id"), None)
            except (KeyError, IndexError, TypeError):
                pass
            if app:
                return self._deliver(dl.key, dl.source, payload, app)
        if dl.source == "ide":
            return self.ingest_ide(payload)
        if dl.source == "invocation":
            return self.ingest_invocation(payload)
        return self.ingest_portkey(payload)

    def refresh_gauges(self) -> None:
        self.b.metrics.pending_gauge.set(self.b.store.event_counts().get("pending", 0))
        self.b.metrics.dead_letters_gauge.set(sum(self.b.store.dead_letter_counts().values()))
