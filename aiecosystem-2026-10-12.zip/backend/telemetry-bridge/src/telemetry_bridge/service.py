"""Wires settings, storage and clients together (shared by the HTTP app, worker and CLI)."""

from __future__ import annotations

import time
from functools import cached_property
from typing import Callable

import httpx

from .alerts import Notifier
from .contracts import Contracts
from .db import Store
from .endpoints import load_endpoints
from .fiddler import FiddlerRuntime
from .manifests import FiddlerManifests
from .metrics import Metrics
from .pipeline import Pipeline
from .portkey import PortkeyAdmin
from .redact import Redactor
from .registry import PlatformApiRegistry, Registry, YamlRegistry
from .settings import Settings


class Bridge:
    def __init__(self, settings: Settings, *, transport: httpx.BaseTransport | None = None,
                 sleep: Callable[[float], None] = time.sleep, smtp_factory=None):
        self.settings = settings
        self.transport = transport
        self.sleep = sleep
        self.smtp_factory = smtp_factory
        self.endpoints = load_endpoints(settings.endpoints_file)
        self.store = Store(settings.database_url)
        self.contracts = Contracts(settings.contracts_dir)
        self.redactor = Redactor(settings.redact_mode, settings.max_content_chars)
        self.metrics = Metrics()
        sec = settings.secrets
        self.fiddler = FiddlerRuntime(settings.fiddler_url, sec.get("FIDDLER_API_KEY"), self.endpoints["fiddler"],
                                      encoding=settings.fiddler_otlp_encoding, timeout=settings.fiddler_timeout_seconds,
                                      transport=transport)
        self.portkey = PortkeyAdmin(settings.portkey_admin_url, sec.get("AIG_PORTKEY_ADMIN_API_KEY"), self.endpoints["portkey"],
                                    transport=transport, sleep=sleep, retry_attempts=settings.retry_attempts,
                                    retry_backoff=settings.retry_backoff_seconds)
        self.pipeline = Pipeline(self)

    def registry(self) -> Registry:
        s = self.settings
        if s.registry_file:
            return YamlRegistry(s.registry_file)
        return PlatformApiRegistry(s.platform_api_url, s.secrets.get("AIG_PLATFORM_SERVICE_TOKEN"), self.endpoints["platform"],
                                   transport=self.transport)

    @cached_property
    def manifests(self) -> FiddlerManifests:
        return FiddlerManifests.load(self.settings.fiddler_root, self.settings.env)

    def notifier(self) -> Notifier:
        return Notifier(self.settings, self.manifests, self.endpoints["pagerduty"]["enqueue"], transport=self.transport,
                        smtp_factory=self.smtp_factory)

    @property
    def fiddler_ui_url(self) -> str:
        return self.settings.fiddler_url or self.manifests.fiddler_url

    def close(self) -> None:
        self.fiddler.close()
        self.portkey.close()
        self.store.engine.dispose()
