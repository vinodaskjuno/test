"""telemetry-bridge CLI.

  telemetry-bridge serve [--host H] [--port P] [--worker]
  telemetry-bridge pull [--loop]                     Portkey logs -> Fiddler from the high-water mark
  telemetry-bridge retry-pending                     redeliver deferred events now
  telemetry-bridge reconcile [--date YYYY-MM-DD] [--dry-run] [--output FILE] [--exit-code]
  telemetry-bridge export-failing --since DATE [--until DATE] [--project P ...] [--agent A ...] [--output-dir DIR]
  telemetry-bridge guardrail-tickets --since DATE [--until DATE] [--with-fiddler] [--output-dir DIR]
  telemetry-bridge dead-letters list [--all] | replay (--id N ... | --reason R)

Exit codes: 0 ok, 1 errors, 3 violations found (reconcile --exit-code).
Settings come from the environment (backend/contracts/env-vars.md, .env.example).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path

from .settings import Settings


def _dt(value: str) -> datetime:
    v = value.strip()
    if len(v) == 10:
        return datetime.fromisoformat(v).replace(tzinfo=timezone.utc)
    dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _bridge(args):
    from .logs import configure_logging
    from .service import Bridge

    settings = Settings.from_env()
    configure_logging(settings.log_level, settings.secrets.values)
    return Bridge(settings)


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def cmd_serve(args) -> int:
    import os

    import uvicorn

    if args.worker:
        os.environ["AIG_BRIDGE_WORKER"] = "true"
    uvicorn.run("telemetry_bridge.app:create_app", factory=True, host=args.host, port=args.port,
                access_log=False, server_header=False)
    return 0


def cmd_pull(args) -> int:
    from .puller import pull_once

    b = _bridge(args)
    try:
        while True:
            out = pull_once(b)
            out["retry"] = b.pipeline.retry_pending()
            _print(out)
            if not args.loop:
                return 1 if out.get("status") == "error" else 0
            time.sleep(b.settings.pull_interval_seconds)
    finally:
        b.close()


def cmd_retry(args) -> int:
    b = _bridge(args)
    try:
        _print(b.pipeline.retry_pending())
        return 0
    finally:
        b.close()


def cmd_reconcile(args) -> int:
    from .reconcile import run_reconcile

    b = _bridge(args)
    try:
        report = run_reconcile(b, day=date.fromisoformat(args.date) if args.date else None, dry_run=args.dry_run)
    finally:
        b.close()
    out = Path(args.output) if args.output else b.settings.reports_dir / f"reconcile-{report['day']}{'-dry-run' if args.dry_run else ''}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n")
    _print(report)
    print(f"report: {out}", file=sys.stderr)
    if report["summary"]["errors"]:
        return 1
    if args.exit_code and report["summary"]["suspended"]:
        return 3
    return 0


def cmd_export_failing(args) -> int:
    from .feedback import export_failing

    b = _bridge(args)
    try:
        _print(export_failing(b, since=_dt(args.since), until=_dt(args.until) if args.until else None,
                              projects=args.project, agents=args.agent,
                              output_dir=Path(args.output_dir) if args.output_dir else None, limit=args.limit))
        return 0
    finally:
        b.close()


def cmd_guardrail_tickets(args) -> int:
    from .feedback import guardrail_tickets, trust_failure_counts

    b = _bridge(args)
    try:
        since = _dt(args.since)
        until = _dt(args.until) if args.until else datetime.now(timezone.utc)
        trust = trust_failure_counts(b, since=since, until=until, projects=args.project) if args.with_fiddler else None
        doc = guardrail_tickets(b, since=since, until=until, trust_failures=trust,
                                output_dir=Path(args.output_dir) if args.output_dir else None, min_count=args.min_count)
        _print({"tickets": len(doc["tickets"]), "files": doc["files"]})
        return 0
    finally:
        b.close()


def cmd_dead_letters(args) -> int:
    b = _bridge(args)
    try:
        if args.action == "list":
            rows = b.store.dead_letters(include_replayed=args.all, limit=args.limit)
            _print([{"id": r.id, "key": r.key, "source": r.source, "reason": r.reason, "retryable": bool(r.retryable),
                     "details": r.details, "created_at": r.created_at, "replayed_at": r.replayed_at} for r in rows])
            return 0
        ids = list(args.id or [])
        if args.reason:
            ids += [r.id for r in b.store.dead_letters(limit=10000) if r.reason == args.reason]
        if not ids:
            print("error: pass --id or --reason", file=sys.stderr)
            return 1
        results = []
        for i in ids:
            r = b.pipeline.replay(i)
            results.append({"id": i, **(r.as_dict() if r else {"status": "not_found_or_already_replayed"})})
        _print(results)
        return 0
    finally:
        b.close()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="telemetry-bridge", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve")
    s.add_argument("--host", default="0.0.0.0")
    s.add_argument("--port", type=int, default=8095)
    s.add_argument("--worker", action="store_true", help="also run the pull/redelivery loop")
    s.set_defaults(fn=cmd_serve)
    pl = sub.add_parser("pull")
    pl.add_argument("--loop", action="store_true")
    pl.set_defaults(fn=cmd_pull)
    sub.add_parser("retry-pending").set_defaults(fn=cmd_retry)
    r = sub.add_parser("reconcile")
    r.add_argument("--date", help="UTC day to check (default: yesterday)")
    r.add_argument("--dry-run", action="store_true", help="report only: no suspension, no alerts sent")
    r.add_argument("--output", help="report path (default: $AIG_BRIDGE_REPORTS_DIR/reconcile-<day>.json)")
    r.add_argument("--exit-code", action="store_true", help="exit 3 when an agent was (or would be) suspended")
    r.set_defaults(fn=cmd_reconcile)
    e = sub.add_parser("export-failing")
    e.add_argument("--since", required=True)
    e.add_argument("--until")
    e.add_argument("--project", action="append")
    e.add_argument("--agent", action="append")
    e.add_argument("--output-dir")
    e.add_argument("--limit", type=int, default=5000, help="max spans per application")
    e.set_defaults(fn=cmd_export_failing)
    g = sub.add_parser("guardrail-tickets")
    g.add_argument("--since", required=True)
    g.add_argument("--until")
    g.add_argument("--with-fiddler", action="store_true", help="also count Fiddler trust failures the gateway let through")
    g.add_argument("--project", action="append")
    g.add_argument("--output-dir")
    g.add_argument("--min-count", type=int, default=5)
    g.set_defaults(fn=cmd_guardrail_tickets)
    d = sub.add_parser("dead-letters")
    d.add_argument("action", choices=["list", "replay"])
    d.add_argument("--all", action="store_true", help="list: include replayed")
    d.add_argument("--limit", type=int, default=100)
    d.add_argument("--id", type=int, action="append")
    d.add_argument("--reason")
    d.set_defaults(fn=cmd_dead_letters)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args)
    except ValueError as exc:  # bad settings
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
