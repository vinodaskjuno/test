"""Send platform alerts through the routing in backend/observability/manifests/alerts.yaml.

Channels: Slack incoming webhook (URL from the env var the channel names), PagerDuty Events
API v2 (routing key from the env var the channel names), email via SMTP
(AIG_BRIDGE_SMTP_*; ``to_owner`` adds the agent owner). Secrets are never logged or returned.
"""

from __future__ import annotations

import logging
import smtplib
from email.message import EmailMessage
from typing import Any, Callable, Mapping

import httpx

from .endpoints import Endpoint
from .manifests import FiddlerManifests
from .settings import Settings, is_placeholder

log = logging.getLogger(__name__)


class Notifier:
    def __init__(self, settings: Settings, manifests: FiddlerManifests, pagerduty: Endpoint, *,
                 transport: httpx.BaseTransport | None = None,
                 smtp_factory: Callable[..., Any] | None = None, environ: Mapping[str, str] | None = None):
        self.s = settings
        self.m = manifests
        self.pd = pagerduty
        self.environ = environ if environ is not None else settings.environ
        self._http = httpx.Client(timeout=15.0, transport=transport)
        self._smtp_factory = smtp_factory or smtplib.SMTP

    def close(self) -> None:
        self._http.close()

    def notify(self, *, event: str | None = None, priority: str | None = None, team: str | None = None,
               owner: str | None = None, subject: str, text: str, links: dict[str, str] | None = None,
               dedup_key: str | None = None, dry_run: bool = False) -> list[dict]:
        results = []
        body = text + ("\n" + "\n".join(f"{k}: {v}" for k, v in (links or {}).items()) if links else "")
        for name in self.m.channels_for(event=event, priority=priority, team=team):
            ch = (self.m.routing.get("channels") or {}).get(name) or {}
            kind = ch.get("type")
            res = {"channel": name, "type": kind}
            if dry_run:
                res["status"] = "dry_run"
                results.append(res)
                continue
            try:
                if kind == "slack":
                    url = self.environ.get(ch.get("webhook_env", ""), "")
                    if is_placeholder(url):
                        res["status"] = f"skipped: {ch.get('webhook_env')} not set"
                    else:
                        r = self._http.post(url, json={"text": f"*{subject}*\n{body}"})
                        res["status"] = "sent" if r.status_code < 400 else f"error: HTTP {r.status_code}"
                elif kind == "pagerduty":
                    key = self.environ.get(ch.get("routing_key_env", ""), "")
                    if is_placeholder(key):
                        res["status"] = f"skipped: {ch.get('routing_key_env')} not set"
                    else:
                        payload = {"routing_key": key, "event_action": "trigger", "dedup_key": dedup_key or subject,
                                   "payload": {"summary": subject[:1024], "source": "aig-telemetry-bridge",
                                               "severity": self.m.routing.get("pagerduty_severity", "critical"),
                                               "custom_details": {"text": text}},
                                   "links": [{"href": v, "text": k} for k, v in (links or {}).items()]}
                        r = self._http.post(self.pd.path, json=payload)
                        res["status"] = "sent" if r.status_code < 400 else f"error: HTTP {r.status_code}"
                elif kind == "email":
                    to = list(ch.get("to", []))
                    if ch.get("to_owner") and owner:
                        to.append(owner)
                    res["to"] = to
                    if not to:
                        res["status"] = "skipped: no recipients"
                    elif not self.s.smtp_host:
                        res["status"] = "skipped: AIG_BRIDGE_SMTP_HOST not set"
                    else:
                        self._send_email(to, subject, body)
                        res["status"] = "sent"
                else:
                    res["status"] = "skipped: unknown channel type"
            except Exception as exc:  # never let one channel stop the others
                res["status"] = f"error: {type(exc).__name__}"
            log.info("alert %s via %s: %s", event or priority, name, res["status"])
            results.append(res)
        return results

    def _send_email(self, to: list[str], subject: str, body: str) -> None:
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = self.s.smtp_from, ", ".join(sorted(set(to))), subject
        msg.set_content(body)
        with self._smtp_factory(self.s.smtp_host, self.s.smtp_port, timeout=15) as smtp:
            if self.s.smtp_starttls:
                smtp.starttls()
            password = self.s.secrets.get("AIG_BRIDGE_SMTP_PASSWORD")
            if self.s.smtp_user and password:
                smtp.login(self.s.smtp_user, password)
            smtp.send_message(msg)
