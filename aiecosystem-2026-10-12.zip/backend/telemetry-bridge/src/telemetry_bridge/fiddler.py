"""Fiddler runtime client: application lookup (cached), OTLP ingestion, span counts and the
failing-span query. Paths come from endpoints.py; the token is never logged or echoed."""

from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any

import httpx

from .endpoints import Endpoint
from .retry import PermanentError, TransientError, classify

APP_TTL_SECONDS = 300.0
MISSING_TTL_SECONDS = 60.0
PAGE = 100


def eq_filter(**fields: str) -> str:
    return json.dumps({"condition": "AND", "rules": [{"field": k, "operator": "equal", "value": str(v)} for k, v in fields.items()]},
                      separators=(",", ":"))


class FiddlerRuntime:
    def __init__(self, base_url: str, token: str | None, endpoints: dict[str, Endpoint], *, encoding: str = "protobuf",
                 timeout: float = 30.0, transport: httpx.BaseTransport | None = None, clock=time.monotonic):
        self.configured = bool(base_url and token and "<" not in base_url)
        self._token = token or ""
        self.ep = endpoints
        self.encoding = encoding
        self._clock = clock
        self._apps: dict[tuple[str, str], tuple[str | None, float]] = {}
        self._projects: dict[str, tuple[str | None, float]] = {}
        self._http = httpx.Client(base_url=base_url or "http://fiddler.invalid", timeout=timeout, transport=transport,
                                  headers={"authorization": f"Bearer {self._token}", "accept": "application/json"})

    def close(self) -> None:
        self._http.close()

    def _scrub(self, text: str) -> str:
        return text.replace(self._token, "***") if self._token else text

    def _req(self, ep: Endpoint, *, path: str | None = None, **kw) -> httpx.Response:
        if not self.configured:
            raise PermanentError("FIDDLER_URL / FIDDLER_API_KEY not configured")
        try:
            r = self._http.request(ep.method, path or ep.path, **kw)
        except httpx.HTTPError as exc:
            raise TransientError(f"fiddler {ep.path}: {type(exc).__name__}") from None
        if r.status_code >= 400:
            raise classify(r.status_code, f"fiddler {ep.path}: HTTP {r.status_code}: {self._scrub(r.text[:200])}")
        return r

    @staticmethod
    def _data(r: httpx.Response) -> Any:
        try:
            body = r.json() if r.content else {}
        except ValueError:
            return {}
        return body.get("data", body) if isinstance(body, dict) else body

    def _items(self, ep: Endpoint, flt: str) -> list[dict]:
        data = self._data(self._req(ep, params={"filter": flt, "limit": PAGE, "offset": 0}))
        items = data.get("items", []) if isinstance(data, dict) else data if isinstance(data, list) else []
        return [i for i in items if isinstance(i, dict)]

    def _cached(self, cache: dict, key, ttl_hit: float) -> tuple[bool, str | None]:
        hit = cache.get(key)
        if hit and self._clock() < hit[1]:
            return True, hit[0]
        return False, None

    def project_id(self, project: str) -> str | None:
        ok, val = self._cached(self._projects, project, APP_TTL_SECONDS)
        if ok:
            return val
        items = self._items(self.ep["projects_list"], eq_filter(name=project))
        pid = str(items[0]["id"]) if items else None
        self._projects[project] = (pid, self._clock() + (APP_TTL_SECONDS if pid else MISSING_TTL_SECONDS))
        return pid

    def application_id(self, project: str, application: str) -> str | None:
        ok, val = self._cached(self._apps, (project, application), APP_TTL_SECONDS)
        if ok:
            return val
        pid = self.project_id(project)
        app_id = None
        if pid:
            items = self._items(self.ep["applications_list"], eq_filter(name=application, project_id=pid))
            app_id = str(items[0]["id"]) if items else None
        self._apps[(project, application)] = (app_id, self._clock() + (APP_TTL_SECONDS if app_id else MISSING_TTL_SECONDS))
        return app_id

    def list_applications(self, project: str) -> list[dict]:
        pid = self.project_id(project)
        return self._items(self.ep["applications_list"], eq_filter(project_id=pid)) if pid else []

    def export(self, body: bytes, content_type: str, application_id: str) -> None:
        self._req(self.ep["otlp_traces"], content=body,
                  headers={"content-type": content_type, "fiddler-application-id": application_id})

    def span_count(self, application_id: str, start: datetime, end: datetime, flt: dict | None = None) -> tuple[int, bool]:
        payload: dict[str, Any] = {"application_id": application_id, "start_time": start.isoformat(), "end_time": end.isoformat()}
        if flt:
            payload["filter"] = flt
        data = self._data(self._req(self.ep["span_fields"], json=payload))
        return int(data.get("total_spans", 0)), bool(data.get("sampled", False))

    def query_spans(self, application_id: str, start: datetime, end: datetime, flt: dict, *, limit: int = 1000) -> list[dict]:
        out: list[dict] = []
        offset = 0
        while len(out) < limit:
            payload = {"application_id": application_id, "start_time": start.isoformat(), "end_time": end.isoformat(),
                       "filter": flt, "limit": min(PAGE, limit - len(out)), "offset": offset}
            data = self._data(self._req(self.ep["spans_query"], json=payload))
            items = data.get("items", []) if isinstance(data, dict) else data if isinstance(data, list) else []
            out += [i for i in items if isinstance(i, dict)]
            if not items or not isinstance(data, dict) or data.get("page_index", 1) >= data.get("page_count", 1):
                break
            offset += len(items)
        return out
