"""JSON Schema validators for the shared contracts (backend/contracts/ at the repo root)."""

from __future__ import annotations

import json
from functools import cached_property
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


class Contracts:
    def __init__(self, contracts_dir: Path):
        self.dir = Path(contracts_dir)
        if not (self.dir / "tags.schema.json").is_file():
            raise FileNotFoundError(f"{self.dir} has no tags.schema.json (set AIG_BRIDGE_CONTRACTS_DIR)")

    @cached_property
    def _registry(self) -> tuple[Registry, dict[str, dict]]:
        schemas = {p.name: json.loads(p.read_text()) for p in self.dir.glob("*.schema.json")}
        reg = Registry().with_resources((s["$id"], Resource.from_contents(s)) for s in schemas.values())
        return reg, schemas

    def _validator(self, name: str) -> Draft202012Validator:
        reg, schemas = self._registry
        return Draft202012Validator(schemas[name], registry=reg, format_checker=FormatChecker())

    @cached_property
    def tags(self) -> Draft202012Validator:
        return self._validator("tags.schema.json")

    @cached_property
    def ide_usage(self) -> Draft202012Validator:
        return self._validator("ide-usage-event.schema.json")

    @cached_property
    def invocation(self) -> Draft202012Validator:
        return self._validator("invocation-event.schema.json")

    @staticmethod
    def errors(validator: Draft202012Validator, doc: Any) -> list[str]:
        return sorted(f"{'/'.join(map(str, e.absolute_path)) or '<root>'}: {e.message}" for e in validator.iter_errors(doc))

    def tag_errors(self, tags: dict) -> list[str]:
        return self.errors(self.tags, tags)

    def ide_usage_errors(self, event: Any) -> list[str]:
        return self.errors(self.ide_usage, event)

    def invocation_errors(self, event: Any) -> list[str]:
        return self.errors(self.invocation, event)
