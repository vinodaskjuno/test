"""Pull Portkey logs since the persisted high-water mark (cursor ``portkey_logs``).

Each run reads the window [hwm - overlap, min(now - lag, hwm + max_window)] so late-arriving
logs are picked up (the overlap is harmless: events are deduplicated by Portkey log id), then
advances the cursor to the window end. On any error the cursor is left unchanged.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

from .normalize import parse_time

if TYPE_CHECKING:
    from .service import Bridge

log = logging.getLogger(__name__)
CURSOR = "portkey_logs"


def pull_once(bridge: "Bridge", now: datetime | None = None) -> dict:
    s, m = bridge.settings, bridge.metrics
    if s.pull_mode == "off":
        return {"status": "disabled"}
    now = now or datetime.now(timezone.utc)
    hwm = parse_time(bridge.store.get_cursor(CURSOR)) or now - timedelta(seconds=s.pull_initial_lookback_seconds)
    end = min(now - timedelta(seconds=s.pull_lag_seconds), hwm + timedelta(seconds=s.pull_max_window_seconds))
    if end <= hwm:
        return {"status": "up_to_date", "cursor": hwm.isoformat()}
    start = hwm - timedelta(seconds=s.pull_overlap_seconds)
    counts: dict[str, int] = {}
    try:
        if s.pull_mode == "export":
            logs = bridge.portkey.export_logs(start, end, workspace_id=s.portkey_workspace_id, max_wait=s.export_max_wait_seconds)
        else:
            logs = bridge.portkey.list_logs(start, end)
        for raw in logs:
            r = bridge.pipeline.ingest_portkey(raw)
            counts[r.status] = counts.get(r.status, 0) + 1
    except Exception as exc:
        m.pull_runs.labels("error").inc()
        log.error("portkey pull failed (cursor unchanged): %s", exc)
        return {"status": "error", "error": str(exc)[:300], "window": [start.isoformat(), end.isoformat()], "counts": counts}
    bridge.store.set_cursor(CURSOR, end.isoformat())
    m.pull_runs.labels("ok").inc()
    m.pull_last_success.set(now.timestamp())
    m.pull_lag.set((now - end).total_seconds())
    log.info("portkey pull %s..%s: %s", start.isoformat(), end.isoformat(), counts)
    return {"status": "ok", "window": [start.isoformat(), end.isoformat()], "cursor": end.isoformat(), "counts": counts}
