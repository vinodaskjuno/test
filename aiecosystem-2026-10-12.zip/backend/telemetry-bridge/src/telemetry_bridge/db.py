"""Bridge state: pull cursors (high-water marks), delivered/pending events (dedupe by Portkey
log id / IDE event id), the dead-letter table and guardrail statistics.

SQLite locally (``sqlite:///state/bridge.db``); any SQLAlchemy URL works, e.g.
``postgresql+psycopg://...`` with the ``postgres`` extra. Only portable column types are used.
Prompts are stored only for events waiting for redelivery (already redacted per
AIG_BRIDGE_REDACT_MODE) and in dead letters (redacted); delivered events keep no content.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from sqlalchemy import (
    JSON,
    DateTime,
    Integer,
    String,
    Text,
    create_engine,
    func,
    select,
)
from sqlalchemy.engine import make_url
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


class Base(DeclarativeBase):
    pass


class Cursor(Base):
    __tablename__ = "bridge_cursors"
    name: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Event(Base):
    __tablename__ = "bridge_events"
    key: Mapped[str] = mapped_column(String(200), primary_key=True)
    source: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16), index=True)  # forwarded | pending | quarantined
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    project: Mapped[str | None] = mapped_column(String(128), nullable=True)
    application: Mapped[str | None] = mapped_column(String(128), nullable=True)
    application_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    trace_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    payload: Mapped[Any] = mapped_column(JSON, nullable=True)  # OTLP JSON while pending
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class DeadLetter(Base):
    __tablename__ = "bridge_dead_letters"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(200), index=True)
    source: Mapped[str] = mapped_column(String(32))
    reason: Mapped[str] = mapped_column(String(64), index=True)
    details: Mapped[Any] = mapped_column(JSON, nullable=True)
    payload: Mapped[Any] = mapped_column(JSON, nullable=True)  # redacted raw event
    retryable: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    replayed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class GuardrailStat(Base):
    __tablename__ = "bridge_guardrail_stats"
    day: Mapped[str] = mapped_column(String(10), primary_key=True)
    agent: Mapped[str] = mapped_column(String(64), primary_key=True)
    hook_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    check_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    stage: Mapped[str] = mapped_column(String(16), primary_key=True)
    evaluated: Mapped[int] = mapped_column(Integer, default=0)
    failed: Mapped[int] = mapped_column(Integer, default=0)
    failed_not_denied: Mapped[int] = mapped_column(Integer, default=0)


class Store:
    def __init__(self, url: str):
        u = make_url(url)
        kwargs: dict[str, Any] = {"future": True}
        if u.get_backend_name() == "sqlite":
            kwargs["connect_args"] = {"check_same_thread": False}
            if u.database and u.database != ":memory:":
                Path(u.database).parent.mkdir(parents=True, exist_ok=True)
            else:
                from sqlalchemy.pool import StaticPool
                kwargs["poolclass"] = StaticPool
        self.engine = create_engine(url, **kwargs)
        Base.metadata.create_all(self.engine)
        self._session = sessionmaker(self.engine, expire_on_commit=False)

    def session(self) -> Session:
        return self._session()

    def ping(self) -> bool:
        try:
            with self.session() as s:
                s.execute(select(1))
            return True
        except Exception:
            return False

    # -- cursors -------------------------------------------------------------------------
    def get_cursor(self, name: str) -> str | None:
        with self.session() as s:
            c = s.get(Cursor, name)
            return c.value if c else None

    def set_cursor(self, name: str, value: str) -> None:
        with self.session() as s, s.begin():
            c = s.get(Cursor, name)
            if c:
                c.value, c.updated_at = value, utcnow()
            else:
                s.add(Cursor(name=name, value=value, updated_at=utcnow()))

    # -- events --------------------------------------------------------------------------
    def event_status(self, key: str) -> str | None:
        with self.session() as s:
            e = s.get(Event, key)
            return e.status if e else None

    def save_event(self, key: str, *, source: str, status: str, payload: Any = None, error: str | None = None,
                   next_attempt_at: datetime | None = None, attempts_inc: int = 0, **cols: Any) -> None:
        with self.session() as s, s.begin():
            e = s.get(Event, key)
            if e is None:
                e = Event(key=key, source=source, attempts=0, created_at=utcnow())
                s.add(e)
            e.status, e.payload, e.last_error, e.next_attempt_at = status, payload, error, next_attempt_at
            e.attempts = (e.attempts or 0) + attempts_inc
            e.updated_at = utcnow()
            for k, v in cols.items():
                setattr(e, k, v)

    def due_pending(self, now: datetime, limit: int = 100) -> list[Event]:
        with self.session() as s:
            rows = s.scalars(select(Event).where(Event.status == "pending").order_by(Event.next_attempt_at).limit(limit)).all()
            return [r for r in rows if (_aware(r.next_attempt_at) or now) <= now]

    def event_counts(self) -> dict[str, int]:
        with self.session() as s:
            return {status: n for status, n in s.execute(select(Event.status, func.count()).group_by(Event.status))}

    # -- dead letters --------------------------------------------------------------------
    def quarantine(self, key: str, *, source: str, reason: str, details: Any, payload: Any, retryable: bool = False) -> int:
        with self.session() as s, s.begin():
            dl = DeadLetter(key=key, source=source, reason=reason, details=details, payload=payload,
                            retryable=int(retryable), created_at=utcnow())
            s.add(dl)
            e = s.get(Event, key)
            if e is None:
                s.add(Event(key=key, source=source, status="quarantined", attempts=0, last_error=reason,
                            created_at=utcnow(), updated_at=utcnow()))
            else:
                e.status, e.last_error, e.payload, e.updated_at = "quarantined", reason, None, utcnow()
            s.flush()
            return dl.id

    def dead_letters(self, *, include_replayed: bool = False, limit: int = 100) -> list[DeadLetter]:
        with self.session() as s:
            q = select(DeadLetter).order_by(DeadLetter.id.desc()).limit(limit)
            if not include_replayed:
                q = q.where(DeadLetter.replayed_at.is_(None))
            return list(s.scalars(q).all())

    def dead_letter(self, dl_id: int) -> DeadLetter | None:
        with self.session() as s:
            return s.get(DeadLetter, dl_id)

    def release_for_replay(self, dl_id: int) -> DeadLetter | None:
        """Mark a dead letter replayed and forget its event key so it can be processed again."""
        with self.session() as s, s.begin():
            dl = s.get(DeadLetter, dl_id)
            if dl is None or dl.replayed_at is not None:
                return None
            dl.replayed_at = utcnow()
            e = s.get(Event, dl.key)
            if e is not None and e.status == "quarantined":
                s.delete(e)
            return dl

    def dead_letter_counts(self) -> dict[str, int]:
        with self.session() as s:
            q = select(DeadLetter.reason, func.count()).where(DeadLetter.replayed_at.is_(None)).group_by(DeadLetter.reason)
            return {r: n for r, n in s.execute(q)}

    # -- guardrail stats -----------------------------------------------------------------
    def add_guardrail_stats(self, day: str, agent: str, rows: list[dict]) -> None:
        if not rows:
            return
        with self.session() as s, s.begin():
            for r in rows:
                pk = (day, agent, r["hook_id"], r["check_id"], r["stage"])
                st = s.get(GuardrailStat, pk)
                if st is None:
                    st = GuardrailStat(day=day, agent=agent, hook_id=r["hook_id"], check_id=r["check_id"], stage=r["stage"],
                                       evaluated=0, failed=0, failed_not_denied=0)
                    s.add(st)
                st.evaluated += 1
                if not r["verdict"]:
                    st.failed += 1
                    if not r.get("denied"):
                        st.failed_not_denied += 1

    def guardrail_stats(self, since_day: str, until_day: str | None = None) -> Iterator[GuardrailStat]:
        with self.session() as s:
            q = select(GuardrailStat).where(GuardrailStat.day >= since_day)
            if until_day:
                q = q.where(GuardrailStat.day <= until_day)
            yield from s.scalars(q).all()
