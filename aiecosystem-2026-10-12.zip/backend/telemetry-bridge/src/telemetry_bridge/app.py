"""HTTP API. Run: uvicorn telemetry_bridge.app:create_app --factory --port 8095

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET  | /healthz | none | status, env, secret statuses (configured/placeholder/missing only), DB, pull mode |
| GET  | /metrics | none | Prometheus text |
| POST | /ingest/portkey | header ``x-aig-bridge-secret`` = AIG_BRIDGE_PUSH_SECRET | Portkey log push / webhook: one log, a list, ``{"logs": [...]}`` or ``{"data": [...]}`` |
| POST | /ingest/ide-usage | ``Authorization: Bearer <AIG_BRIDGE_INGEST_TOKEN>`` | IDE token-usage events (backend/contracts/ide-usage-event.schema.json), one or ``{"events": [...]}`` |
| POST | /ingest/invocation | ``Authorization: Bearer <AIG_BRIDGE_INGEST_TOKEN>`` | platform-api agent invocation records, metadata only (backend/contracts/invocation-event.schema.json), one or ``{"events": [...]}`` |
| POST | /v1/traces | ``x-aig-bridge-secret`` | OTLP/HTTP JSON passthrough (Portkey OTel export) to Fiddler |

Outside ``local`` an ingest endpoint whose secret is not configured answers 503 (fail closed);
in ``local`` it accepts calls with a warning. Secrets are compared in constant time.
"""

from __future__ import annotations

import hmac
import json
import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from starlette.concurrency import run_in_threadpool

from . import __version__
from .logs import configure_logging
from .otlp import attr_dict
from .retry import PermanentError, TransientError, call_with_retries
from .service import Bridge
from .settings import Settings
from .worker import Worker

log = logging.getLogger("telemetry_bridge.app")
PUSH_HEADER = "x-aig-bridge-secret"
MAX_BODY_BYTES = 20 * 1024 * 1024
MAX_IDE_EVENTS = 500


class HttpError(Exception):
    def __init__(self, status: int, code: str, message: str):
        self.status, self.code, self.message = status, code, message


def _error(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "message": message}}, status_code=status)


def _check_secret(bridge: Bridge, name: str, supplied: str, endpoint: str) -> None:
    expected = bridge.settings.secrets.get(name)
    if not expected:
        if bridge.settings.env != "local":
            raise HttpError(503, "ingest_not_configured", f"{name} is not configured")
        log.warning("%s called without %s configured (allowed only in AIG_ENV=local)", endpoint, name)
        return
    if not hmac.compare_digest(supplied.encode(), expected.encode()):
        bridge.metrics.auth_failures.labels(endpoint).inc()
        raise HttpError(401, "unauthenticated", "missing or invalid credentials")


async def _json_body(request: Request) -> Any:
    body = await request.body()
    if len(body) > MAX_BODY_BYTES:
        raise HttpError(413, "payload_too_large", "body over 20 MiB")
    try:
        return json.loads(body or b"null")
    except ValueError:
        raise HttpError(400, "invalid_json", "body is not JSON") from None


def _portkey_items(body: Any) -> list:
    if isinstance(body, list):
        return body
    if isinstance(body, dict):
        for k in ("logs", "data", "events"):
            if isinstance(body.get(k), list):
                return body[k]
        return [body]
    raise HttpError(400, "invalid_request", "expected a log object or a list of logs")


def create_app(settings: Settings | None = None, *, bridge: Bridge | None = None, start_worker: bool | None = None) -> FastAPI:
    settings = settings or (bridge.settings if bridge else Settings.from_env())
    bridge = bridge or Bridge(settings)
    configure_logging(settings.log_level, settings.secrets.values)
    run_worker = settings.worker_enabled if start_worker is None else start_worker

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        worker = Worker(bridge, settings.pull_interval_seconds) if run_worker else None
        if worker:
            worker.start()
        log.info("telemetry-bridge starting env=%s pull=%s worker=%s secrets=%s", settings.env, settings.pull_mode,
                 bool(worker), settings.secrets.statuses())
        try:
            yield
        finally:
            if worker:
                worker.stop()

    app = FastAPI(title="AIG telemetry-bridge", version=__version__, lifespan=lifespan)
    app.state.bridge = bridge

    @app.exception_handler(HttpError)
    async def _http_error(_: Request, exc: HttpError):
        return _error(exc.status, exc.code, exc.message)

    @app.get("/healthz")
    def healthz():
        db_ok = bridge.store.ping()
        return JSONResponse({
            "status": "ok" if db_ok else "degraded", "env": settings.env, "version": __version__,
            "database": "ok" if db_ok else "error", "pull_mode": settings.pull_mode,
            "fiddler": "configured" if bridge.fiddler.configured else "not_configured",
            "portkey_admin": "configured" if bridge.portkey.configured else "not_configured",
            "secrets": settings.secrets.statuses(),
        }, status_code=200 if db_ok else 503)

    @app.get("/metrics")
    def metrics():
        bridge.pipeline.refresh_gauges()
        return Response(bridge.metrics.render(), media_type="text/plain; version=0.0.4; charset=utf-8")

    @app.post("/ingest/portkey", status_code=202)
    async def ingest_portkey(request: Request):
        _check_secret(bridge, "AIG_BRIDGE_PUSH_SECRET", request.headers.get(PUSH_HEADER, ""), "portkey")
        items = _portkey_items(await _json_body(request))
        if len(items) > settings.max_batch:
            raise HttpError(413, "too_many_events", f"at most {settings.max_batch} logs per call")
        results = await run_in_threadpool(lambda: [bridge.pipeline.ingest_portkey(i) for i in items])
        return _summary(results)

    async def _bearer_events(request: Request, endpoint: str) -> list:
        scheme, _, token = request.headers.get("authorization", "").partition(" ")
        _check_secret(bridge, "AIG_BRIDGE_INGEST_TOKEN", token.strip() if scheme.lower() == "bearer" else "", endpoint)
        body = await _json_body(request)
        if isinstance(body, dict) and isinstance(body.get("events"), list):
            items = body["events"]
        elif isinstance(body, dict):
            items = [body]
        else:
            raise HttpError(400, "invalid_request", "expected an event object or {\"events\": [...]}")
        if len(items) > MAX_IDE_EVENTS:
            raise HttpError(413, "too_many_events", f"at most {MAX_IDE_EVENTS} events per call")
        return items

    @app.post("/ingest/ide-usage", status_code=202)
    async def ingest_ide(request: Request):
        items = await _bearer_events(request, "ide-usage")
        results = await run_in_threadpool(lambda: [bridge.pipeline.ingest_ide(i) for i in items])
        return _summary(results)

    @app.post("/ingest/invocation", status_code=202)
    async def ingest_invocation(request: Request):
        items = await _bearer_events(request, "invocation")
        results = await run_in_threadpool(lambda: [bridge.pipeline.ingest_invocation(i) for i in items])
        return _summary(results)

    @app.post("/v1/traces")
    async def otlp_passthrough(request: Request):
        _check_secret(bridge, "AIG_BRIDGE_PUSH_SECRET", request.headers.get(PUSH_HEADER, ""), "otlp")
        ctype = request.headers.get("content-type", "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise HttpError(415, "unsupported_media_type", "only OTLP/HTTP JSON is accepted")
        body = await _json_body(request)
        if not isinstance(body, dict) or not isinstance(body.get("resourceSpans"), list):
            raise HttpError(400, "invalid_request", "expected an OTLP ExportTraceServiceRequest")
        return await run_in_threadpool(_passthrough, bridge, body)

    return app


def _summary(results) -> JSONResponse:
    counts: dict[str, int] = {}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1
    return JSONResponse({"counts": counts, "results": [r.as_dict() for r in results]}, status_code=202)


def _passthrough(bridge: Bridge, body: dict) -> JSONResponse:
    """Forward each resourceSpans group to the application it belongs to: resource attribute
    ``application.id``, else the AIG tags ``agent`` + ``env`` (resource or first span)."""
    s = bridge.settings
    out = []
    for rs in body["resourceSpans"]:
        res = attr_dict((rs.get("resource") or {}).get("attributes", []))
        first = {}
        for ss in rs.get("scopeSpans", []):
            for sp in ss.get("spans", []):
                first = attr_dict(sp.get("attributes", []))
                break
            if first:
                break
        app_id = res.get("application.id")
        agent = res.get("agent") or first.get("agent")
        env = res.get("env") or first.get("env")
        try:
            if not app_id and agent and env:
                app_id = bridge.fiddler.application_id(s.project_for(env), agent)
            if not app_id:
                out.append({"status": "rejected", "reason": "application_unresolved"})
                continue
            payload = json.dumps({"resourceSpans": [rs]}, separators=(",", ":")).encode()
            call_with_retries(lambda p=payload, a=app_id: bridge.fiddler.export(p, "application/json", a),
                              attempts=s.retry_attempts, base=s.retry_backoff_seconds, sleep=bridge.sleep)
            out.append({"status": "forwarded", "application_id": app_id})
        except (TransientError, PermanentError) as exc:
            out.append({"status": "error", "reason": str(exc)[:200]})
    ok = all(r["status"] == "forwarded" for r in out)
    status = 200 if ok else (422 if all(r["status"] == "rejected" for r in out) else 502)
    return JSONResponse({"results": out}, status_code=status)
