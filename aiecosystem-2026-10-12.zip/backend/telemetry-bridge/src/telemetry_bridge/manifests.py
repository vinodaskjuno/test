"""Reads the parts of backend/observability the bridge needs at runtime: trust-score
thresholds (export-failing) and alert routing (reconciliation alerts). Same precedence as
fiddler-sync: manifest < env overlay."""

from __future__ import annotations

import copy
from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass
class FiddlerManifests:
    trust: list[dict]
    routing: dict
    disabled_channels: set[str]
    fiddler_url: str

    @classmethod
    def load(cls, root: Path, env: str) -> "FiddlerManifests":
        root = Path(root)

        def spec(name: str) -> dict:
            return (yaml.safe_load((root / "manifests" / name).read_text()) or {}).get("spec", {})

        env_path = root / "envs" / f"{env}.yaml"
        envdoc = yaml.safe_load(env_path.read_text()) if env_path.is_file() else {}
        overrides = envdoc.get("trust_overrides") or {}
        trust = [{**copy.deepcopy(s), **overrides.get(s["name"], {})} for s in spec("trust.yaml").get("scores", [])]
        return cls(trust=trust, routing=spec("alerts.yaml"), disabled_channels=set(envdoc.get("disabled_channels") or []),
                   fiddler_url=str(envdoc.get("fiddler_url") or ""))

    def channels_for(self, *, event: str | None = None, priority: str | None = None, team: str | None = None) -> list[str]:
        chosen: list[str] = []
        for route in self.routing.get("routes", []):
            m = route.get("match", {})
            if ("priority" in m and m["priority"] != priority) or ("event" in m and m["event"] != event):
                continue
            chosen = list(route.get("channels", []))
            break
        if chosen and team:
            chosen += (self.routing.get("team_channels") or {}).get(team, [])
        return [c for c in dict.fromkeys(chosen) if c not in self.disabled_channels]

    def link(self, kind: str, *, fiddler_url: str, project: str, application: str, trace_id: str = "") -> str:
        tpl = (self.routing.get("links") or {}).get(kind, "")
        return tpl.format(fiddler_url=fiddler_url.rstrip("/"), project=project, application=application,
                          application_id="", trace_id=trace_id, agent_id=application)
