"""Agent registry access for reconciliation.

- ``PlatformApiRegistry`` (default when AIG_PLATFORM_API_URL is set): ``GET /api/v1/agents``
  and ``POST /api/v1/agents/{id}/suspend`` with ``x-aig-service-token``. This is the only
  mode that affects the running platform-api (and therefore the gateway's agent-check webhook).
- ``YamlRegistry`` (AIG_BRIDGE_REGISTRY_FILE): reads/writes platform-api's agents YAML file
  directly, for a registry file shared with platform-api (it reloads on restart) or for tests.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

import httpx
import yaml

from .endpoints import Endpoint
from .retry import PermanentError, TransientError, classify

BUILTINS = ("ide.vscode", "ide.eclipse", "web.portal")


@dataclass(frozen=True)
class AgentInfo:
    agent_id: str
    owner: str
    team: str
    status: str = "active"
    shared: bool = False
    portkey_api_key_id: str | None = None

    @classmethod
    def from_dict(cls, d: dict, agent_id: str | None = None) -> "AgentInfo":
        return cls(str(agent_id or d.get("agent_id")), str(d.get("owner") or ""), str(d.get("team") or ""),
                   str(d.get("status") or "active"), bool(d.get("shared", False)), d.get("portkey_api_key_id"))


class Registry(Protocol):
    def list_agents(self) -> list[AgentInfo]: ...

    def suspend(self, agent_id: str, reason: str, evidence: dict[str, Any]) -> dict: ...

    def invocation_summary(self, since: datetime, until: datetime, env: str) -> list[dict] | None:
        """Per (agent, version, env) invocation counts, or None when the source has none."""
        ...


class PlatformApiRegistry:
    def __init__(self, base_url: str, token: str | None, endpoints: dict[str, Endpoint], *,
                 transport: httpx.BaseTransport | None = None, timeout: float = 30.0):
        if not base_url or "<" in base_url:
            raise PermanentError("AIG_PLATFORM_API_URL is not configured")
        if not token:
            raise PermanentError("AIG_PLATFORM_SERVICE_TOKEN is not configured")
        self._token = token
        self.ep = endpoints
        self._http = httpx.Client(base_url=base_url, timeout=timeout, transport=transport,
                                  headers={"x-aig-service-token": token, "accept": "application/json"})

    def _call(self, ep: Endpoint, path: str, **kw) -> dict:
        try:
            r = self._http.request(ep.method, path, **kw)
        except httpx.HTTPError as exc:
            raise TransientError(f"platform-api {ep.path}: {type(exc).__name__}") from None
        if r.status_code >= 400:
            raise classify(r.status_code, f"platform-api {ep.path}: HTTP {r.status_code}: {r.text[:200].replace(self._token, '***')}")
        return r.json() if r.content else {}

    def list_agents(self) -> list[AgentInfo]:
        data = self._call(self.ep["agents_list"], self.ep["agents_list"].path)
        return [AgentInfo.from_dict(a) for a in data.get("agents", []) if isinstance(a, dict)]

    def suspend(self, agent_id: str, reason: str, evidence: dict[str, Any]) -> dict:
        ep = self.ep["agent_suspend"]
        return self._call(ep, ep.url(agent_id=agent_id), json={"reason": reason, "source": "reconciliation", "evidence": evidence})

    def invocation_summary(self, since: datetime, until: datetime, env: str) -> list[dict] | None:
        ep = self.ep["invocation_summary"]
        data = self._call(ep, ep.path, params={"since": since.isoformat(), "until": until.isoformat(), "env": env})
        return [i for i in data.get("items", []) if isinstance(i, dict)]

    def close(self) -> None:
        self._http.close()


class YamlRegistry:
    def __init__(self, path: Path):
        self.path = Path(path)

    def _load(self) -> dict:
        data = yaml.safe_load(self.path.read_text()) if self.path.is_file() else None
        return data if isinstance(data, dict) else {"agents": {}}

    def list_agents(self) -> list[AgentInfo]:
        entries = self._load().get("agents") or {}
        agents = {aid: AgentInfo.from_dict(e or {}, aid) for aid, e in entries.items()}
        for b in BUILTINS:
            agents.setdefault(b, AgentInfo(b, "platform-team@aig.example.com", "aig-platform", "active", True))
        return sorted(agents.values(), key=lambda a: a.agent_id)

    def invocation_summary(self, since: datetime, until: datetime, env: str) -> list[dict] | None:
        return None  # invocation records live only in platform-api

    def suspend(self, agent_id: str, reason: str, evidence: dict[str, Any]) -> dict:
        doc = self._load()
        entries = doc.setdefault("agents", {})
        if agent_id not in entries:
            raise PermanentError(f"agent {agent_id!r} not in {self.path.name}", 404)
        e = entries[agent_id]
        changed = e.get("status") != "suspended"
        if changed:
            e.update(status="suspended", status_reason=f"reconciliation: {reason}"[:500],
                     status_changed_at=datetime.now(timezone.utc).replace(microsecond=0).isoformat())
            fd, tmp = tempfile.mkstemp(dir=str(self.path.parent), suffix=".yaml")
            with os.fdopen(fd, "w") as fh:
                yaml.safe_dump(doc, fh, sort_keys=False)
            os.replace(tmp, self.path)
        return {"agent": {"agent_id": agent_id, **e}, "changed": changed}
