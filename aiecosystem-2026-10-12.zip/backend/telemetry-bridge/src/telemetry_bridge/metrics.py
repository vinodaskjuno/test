"""Prometheus metrics (GET /metrics). One registry per app instance."""

from __future__ import annotations

from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)


class Metrics:
    def __init__(self):
        self.registry = CollectorRegistry()
        r = self.registry
        self.received = Counter("aig_bridge_events_received_total", "Events received", ["source"], registry=r)
        self.forwarded = Counter("aig_bridge_events_forwarded_total", "Events delivered to Fiddler", ["source"], registry=r)
        self.duplicates = Counter("aig_bridge_events_duplicate_total", "Events skipped as already seen", ["source"], registry=r)
        self.quarantined = Counter("aig_bridge_events_quarantined_total", "Events moved to the dead-letter table", ["source", "reason"], registry=r)
        self.pending = Counter("aig_bridge_events_pending_total", "Deliveries deferred for retry", ["source"], registry=r)
        self.forward_errors = Counter("aig_bridge_forward_errors_total", "Failed Fiddler deliveries", ["kind"], registry=r)
        self.forward_latency = Histogram("aig_bridge_forward_seconds", "Fiddler delivery latency", registry=r)
        self.pull_runs = Counter("aig_bridge_pull_runs_total", "Portkey pull runs", ["result"], registry=r)
        self.pull_last_success = Gauge("aig_bridge_pull_last_success_timestamp_seconds", "Last successful Portkey pull", registry=r)
        self.pull_lag = Gauge("aig_bridge_pull_cursor_lag_seconds", "Now minus the Portkey high-water mark", registry=r)
        self.pending_gauge = Gauge("aig_bridge_pending_events", "Events waiting for redelivery", registry=r)
        self.dead_letters_gauge = Gauge("aig_bridge_dead_letters", "Unreplayed dead letters", registry=r)
        self.auth_failures = Counter("aig_bridge_ingest_auth_failures_total", "Rejected ingest calls", ["endpoint"], registry=r)

    def render(self) -> bytes:
        return generate_latest(self.registry)
