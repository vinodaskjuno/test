"""AIG telemetry-bridge (Phase 3)."""

__version__ = "0.1.0"
