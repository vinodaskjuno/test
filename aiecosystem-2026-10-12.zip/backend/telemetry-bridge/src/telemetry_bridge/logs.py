"""Logging setup with a filter that masks configured secret values in every record.
Prompts and replies are never logged at INFO (the pipeline logs keys and reasons only)."""

from __future__ import annotations

import logging
from typing import Callable


class RedactingFilter(logging.Filter):
    def __init__(self, secrets: Callable[[], list[str]]):
        super().__init__()
        self._secrets = secrets

    def filter(self, record: logging.LogRecord) -> bool:
        values = [v for v in self._secrets() if v and len(v) >= 6]
        if not values:
            return True
        msg = record.getMessage()
        for v in values:
            msg = msg.replace(v, "***")
        record.msg, record.args = msg, None
        return True


def configure_logging(level: str, secrets: Callable[[], list[str]]) -> None:
    root = logging.getLogger("telemetry_bridge")
    root.setLevel(level.upper())
    if not any(isinstance(f, RedactingFilter) for f in root.filters):
        root.addFilter(RedactingFilter(secrets))
    if not root.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        h.addFilter(RedactingFilter(secrets))
        root.addHandler(h)
