"""Portkey admin API client: log export / listing, analytics grouped by metadata, API keys.
The admin key (header ``x-portkey-api-key``) is never sent to the signed download URL and is
scrubbed from errors."""

from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any, Callable, Iterator

import httpx

from .endpoints import PORTKEY_EXPORT_FIELDS, Endpoint
from .retry import PermanentError, TransientError, call_with_retries, classify

PAGE_SIZE = 100
MAX_PAGES = 200


class PortkeyAdmin:
    def __init__(self, base_url: str, api_key: str | None, endpoints: dict[str, Endpoint], *, timeout: float = 60.0,
                 transport: httpx.BaseTransport | None = None, sleep: Callable[[float], None] = time.sleep,
                 retry_attempts: int = 4, retry_backoff: float = 0.5):
        self.configured = bool(base_url and api_key and "<" not in base_url)
        self._key = api_key or ""
        self.ep = endpoints
        self._sleep = sleep
        self._attempts, self._backoff = retry_attempts, retry_backoff
        self._http = httpx.Client(base_url=base_url or "http://portkey.invalid", timeout=timeout, transport=transport,
                                  headers={"x-portkey-api-key": self._key, "accept": "application/json"})
        self._download = httpx.Client(timeout=timeout, transport=transport, follow_redirects=True)

    def close(self) -> None:
        self._http.close()
        self._download.close()

    def _scrub(self, s: str) -> str:
        return s.replace(self._key, "***") if self._key else s

    def _call(self, ep: Endpoint, path: str | None = None, **kw) -> Any:
        if not self.configured:
            raise PermanentError("AIG_PORTKEY_ADMIN_URL / AIG_PORTKEY_ADMIN_API_KEY not configured")

        def once():
            try:
                r = self._http.request(ep.method, path or ep.path, **kw)
            except httpx.HTTPError as exc:
                raise TransientError(f"portkey {ep.path}: {type(exc).__name__}") from None
            if r.status_code >= 400:
                raise classify(r.status_code, f"portkey {ep.path}: HTTP {r.status_code}: {self._scrub(r.text[:200])}")
            try:
                return r.json() if r.content else {}
            except ValueError:
                raise PermanentError(f"portkey {ep.path}: invalid JSON") from None

        return call_with_retries(once, attempts=self._attempts, base=self._backoff, sleep=self._sleep)

    # -- logs ----------------------------------------------------------------------------
    def export_logs(self, start: datetime, end: datetime, *, workspace_id: str | None = None,
                    max_wait: float = 300.0, poll: float = 2.0) -> Iterator[dict]:
        body: dict[str, Any] = {
            "filters": {"time_of_generation_min": start.isoformat(), "time_of_generation_max": end.isoformat()},
            "requested_data": PORTKEY_EXPORT_FIELDS,
        }
        if workspace_id:
            body["workspace_id"] = workspace_id
        created = self._call(self.ep["logs_export_create"], json=body)
        export_id = str(created.get("id") or (created.get("data") or {}).get("id") or "")
        if not export_id:
            raise PermanentError("portkey log export: no export id in response")
        self._call(self.ep["logs_export_start"], self.ep["logs_export_start"].url(export_id=export_id))
        waited = 0.0
        while True:
            st = self._call(self.ep["logs_export_get"], self.ep["logs_export_get"].url(export_id=export_id))
            status = str(st.get("status") or (st.get("data") or {}).get("status") or "").lower()
            if status in ("success", "completed", "complete", "done"):
                break
            if status in ("failed", "error", "cancelled", "stopped"):
                raise PermanentError(f"portkey log export {export_id} {status}")
            if waited >= max_wait:
                raise TransientError(f"portkey log export {export_id} not ready after {max_wait:.0f}s")
            self._sleep(poll)
            waited += poll
        dl = self._call(self.ep["logs_export_download"], self.ep["logs_export_download"].url(export_id=export_id))
        url = dl.get("signed_url") or dl.get("url") or (dl.get("data") or {}).get("signed_url")
        if not url:
            raise PermanentError("portkey log export: no signed_url")
        try:
            r = self._download.get(url)  # signed URL: no Portkey key on this request
        except httpx.HTTPError as exc:
            raise TransientError(f"portkey export download: {type(exc).__name__}") from None
        if r.status_code >= 400:
            raise classify(r.status_code, f"portkey export download: HTTP {r.status_code}")
        yield from parse_log_file(r.text)

    def list_logs(self, start: datetime, end: datetime) -> Iterator[dict]:
        for page in range(MAX_PAGES):
            params = {"time_of_generation_min": start.isoformat(), "time_of_generation_max": end.isoformat(),
                      "page_size": PAGE_SIZE, "current_page": page}
            data = self._call(self.ep["logs_list"], params=params)
            rows = data.get("data", data) if isinstance(data, dict) else data
            rows = [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []
            yield from rows
            if len(rows) < PAGE_SIZE:
                return

    # -- analytics -----------------------------------------------------------------------
    def requests_by_metadata(self, key: str, start: datetime, end: datetime) -> dict[str, int]:
        ep = self.ep["analytics_group_metadata"]
        out: dict[str, int] = {}
        total = None
        seen = 0
        for page in range(MAX_PAGES):
            params = {"time_of_generation_min": start.isoformat(), "time_of_generation_max": end.isoformat(),
                      "current_page": page, "page_size": PAGE_SIZE}
            data = self._call(ep, ep.url(key=key), params=params)
            rows = [r for r in (data.get("data") or []) if isinstance(r, dict)] if isinstance(data, dict) else []
            if isinstance(data, dict) and isinstance(data.get("total"), int):
                total = data["total"]
            for r in rows:
                value = r.get("metadata_value") or r.get("value") or r.get(key) or r.get("name")
                if value is None:
                    continue
                n = r.get("requests", r.get("total_requests", r.get("count", 0)))
                try:
                    out[str(value)] = out.get(str(value), 0) + int(float(n))
                except (TypeError, ValueError):
                    continue
            seen += len(rows)
            if len(rows) < PAGE_SIZE or (total is not None and seen >= total):
                break
        return out

    # -- API keys ------------------------------------------------------------------------
    def find_api_key(self, name: str) -> dict | None:
        data = self._call(self.ep["api_keys_list"])
        rows = data.get("data", data) if isinstance(data, dict) else data
        for k in rows if isinstance(rows, list) else []:
            if isinstance(k, dict) and k.get("name") == name:
                return k
        return None

    def suspend_api_key(self, key_id: str) -> None:
        ep = self.ep["api_key_suspend"]
        self._call(ep, ep.url(id=key_id), json=ep.body or None)


def parse_log_file(text: str) -> Iterator[dict]:
    """A Portkey export file: JSON array, {"data": [...]} or JSON Lines."""
    s = text.strip()
    if not s:
        return
    if s[0] in "[{":
        try:
            doc = json.loads(s)
        except ValueError:
            doc = None
        if isinstance(doc, list):
            yield from (d for d in doc if isinstance(d, dict))
            return
        if isinstance(doc, dict):
            rows = doc.get("data") or doc.get("logs")
            if isinstance(rows, list):
                yield from (d for d in rows if isinstance(d, dict))
            else:
                yield doc
            return
    for line in s.splitlines():
        line = line.strip()
        if line:
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if isinstance(d, dict):
                yield d
