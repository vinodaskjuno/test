"""Every external API path telemetry-bridge calls: the ONE module to adjust per deployment.

Override without code changes: ``AIG_BRIDGE_ENDPOINTS_FILE`` = YAML with any of the sections
below, for example::

    portkey:
      logs_list: {method: GET, path: /v1/logs}
      api_key_suspend: {method: PUT, path: "/api-keys/{id}", body: {status: archived}}   # quote paths with {}
    fiddler:
      spans_query: {method: POST, path: /v3/spans/search}

Status of each default (no AIG credentials were available; see README "Verification"):

Portkey (admin API, header ``x-portkey-api-key``):
- ``logs_export_*``: Portkey's documented Logs Export flow (create -> start -> poll ->
  download a signed URL). Field names (``filters.time_of_generation_min/max``,
  ``requested_data``, ``status``, ``signed_url``) are ASSUMED from Portkey's public docs.
- ``logs_list``: ASSUMED synchronous listing (some self-hosted versions); pull mode ``list``.
- ``analytics_group_metadata``: Portkey analytics "group by metadata key", ASSUMED
  ``/analytics/groups/metadata/{key}`` with the same paging/time params platform-api already
  uses for ``/analytics/groups/users`` (equally unverified there).
- ``api_keys_list`` / ``api_key_suspend``: same paths as backend/gateway/tool's ``api_keys``
  endpoint (``/api-keys``, ``/api-keys/{id}``). The suspension BODY is ASSUMED
  (``{"status": "disabled"}``); confirm how the self-hosted version disables a key (status
  field, ``expires_at`` in the past, or delete) and override ``api_key_suspend`` accordingly.

Fiddler (header ``Authorization: Bearer``), verified in fiddler-client 3.14.1 /
fiddler-evals 0.6.0 / fiddler-otel 1.4.1 unless marked:
- ``projects_list`` ``/v3/projects``, ``applications_list`` ``/v3/applications`` (JSON
  ``filter`` query param, ``data.items``), ``span_fields`` ``/v3/spans/fields``
  (``data.total_spans``), ``otlp_traces`` ``/v1/traces`` + ``fiddler-application-id``.
- ``spans_query``: ASSUMED span search endpoint (same filter DSL as ``/v3/spans/fields``),
  used only by ``export-failing``.

platform-api (header ``x-aig-service-token``): implemented in this repo
(backend/platform-api/src/platform_api/routes/agents.py).

PagerDuty Events API v2 ``https://events.pagerduty.com/v2/enqueue`` (public, stable).
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class Endpoint:
    method: str
    path: str
    body: dict[str, Any] = field(default_factory=dict)

    def url(self, **params: Any) -> str:
        return self.path.format(**params)


DEFAULTS: dict[str, dict[str, Endpoint]] = {
    "portkey": {
        "logs_export_create": Endpoint("POST", "/logs/exports"),
        "logs_export_start": Endpoint("POST", "/logs/exports/{export_id}/start"),
        "logs_export_get": Endpoint("GET", "/logs/exports/{export_id}"),
        "logs_export_download": Endpoint("GET", "/logs/exports/{export_id}/download"),
        "logs_list": Endpoint("GET", "/logs"),
        "analytics_group_metadata": Endpoint("GET", "/analytics/groups/metadata/{key}"),
        "api_keys_list": Endpoint("GET", "/api-keys"),
        "api_key_suspend": Endpoint("PUT", "/api-keys/{id}", {"status": "disabled"}),
    },
    "fiddler": {
        "projects_list": Endpoint("GET", "/v3/projects"),
        "applications_list": Endpoint("GET", "/v3/applications"),
        "span_fields": Endpoint("POST", "/v3/spans/fields"),
        "spans_query": Endpoint("POST", "/v3/spans/query"),
        "otlp_traces": Endpoint("POST", "/v1/traces"),
    },
    "platform": {
        "agents_list": Endpoint("GET", "/api/v1/agents"),
        "agent_suspend": Endpoint("POST", "/api/v1/agents/{agent_id}/suspend"),
        "invocation_summary": Endpoint("GET", "/api/v1/invocations/summary"),
    },
    "pagerduty": {
        "enqueue": Endpoint("POST", "https://events.pagerduty.com/v2/enqueue"),
    },
}

# Requested columns for the Portkey log export (ASSUMED names from Portkey's docs).
PORTKEY_EXPORT_FIELDS: list[str] = [
    "id", "trace_id", "created_at", "request", "response", "is_success", "ai_org", "ai_model",
    "req_units", "res_units", "total_units", "cost", "cost_currency", "response_time",
    "response_status_code", "metadata", "cache_status", "hook_results",
]


def load_endpoints(path: str | None = None) -> dict[str, dict[str, Endpoint]]:
    eps = {k: dict(v) for k, v in DEFAULTS.items()}
    if not path:
        return eps
    data = yaml.safe_load(Path(path).read_text()) or {}
    for section, items in data.items():
        if section not in eps:
            raise ValueError(f"{path}: unknown section {section!r}")
        for name, values in (items or {}).items():
            if name not in eps[section]:
                raise ValueError(f"{path}: unknown endpoint {section}.{name}")
            eps[section][name] = replace(eps[section][name], **{k: v for k, v in (values or {}).items()})
    return eps
