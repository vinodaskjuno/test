"""Settings from environment variables (documented in backend/contracts/env-vars.md).

Secrets are held in ``Secrets`` (values never in repr, logs or responses). Values come from the
process environment, then from the optional env file ``AIG_BRIDGE_ENV_FILE`` (process env wins;
see .env.example). A value that is empty or contains ``__REPLACE_ME`` / ``<...>`` is unset.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping

SERVICE_ROOT = Path(__file__).resolve().parents[2]  # backend/telemetry-bridge
REPO_ROOT = SERVICE_ROOT.parents[1]

# Order matters only for gitleaks: a *_API_KEY name followed by another name that does not end
# in _KEY would look like "KEY_NAME, value" to the repo's custom rules.
SECRET_NAMES: tuple[str, ...] = (
    "AIG_PLATFORM_SERVICE_TOKEN",
    "AIG_BRIDGE_PUSH_SECRET",
    "AIG_BRIDGE_INGEST_TOKEN",
    "AIG_BRIDGE_SMTP_PASSWORD",
    "FIDDLER_API_KEY",
    "AIG_PORTKEY_ADMIN_API_KEY",
)
ENVS = ("local", "dev", "stage", "prod")


def is_placeholder(value: str | None) -> bool:
    v = (value or "").strip()
    return not v or "REPLACE_ME" in v.upper() or ("<" in v and ">" in v)


class Secrets:
    def __init__(self, values: Mapping[str, str | None]):
        self.__values = {n: (values.get(n) or "").strip() for n in SECRET_NAMES}

    def get(self, name: str) -> str | None:
        v = self.__values.get(name)
        return None if is_placeholder(v) else v

    def status(self, name: str) -> str:
        v = self.__values.get(name)
        if not v:
            return "missing"
        return "placeholder" if is_placeholder(v) else "configured"

    def statuses(self) -> dict[str, str]:
        return {n: self.status(n) for n in SECRET_NAMES}

    def values(self) -> list[str]:
        return [v for n in SECRET_NAMES if (v := self.get(n))]

    def __repr__(self) -> str:
        return f"Secrets({self.statuses()!r})"

    __str__ = __repr__


def parse_env_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:]
        k, _, v = line.partition("=")
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        out[k.strip()] = v
    return out


def _bool(v: str | None, default: bool = False) -> bool:
    if v is None or v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _list(v: str | None, default: list[str]) -> list[str]:
    if v is None:
        return list(default)
    return [x.strip() for x in v.split(",") if x.strip()]


def _default_dir(*candidates: Path) -> Path:
    for c in candidates:
        if c.is_dir():
            return c
    return candidates[0]


@dataclass
class Settings:
    env: str = "local"
    log_level: str = "INFO"
    database_url: str = ""
    contracts_dir: Path = field(default_factory=lambda: _default_dir(REPO_ROOT / "backend" / "contracts", Path("/app/contracts")))
    fiddler_root: Path = field(default_factory=lambda: _default_dir(REPO_ROOT / "backend" / "observability", Path("/app/observability/fiddler")))
    endpoints_file: str | None = None
    # Fiddler
    fiddler_url: str = ""
    fiddler_project_template: str = "aig-{env}"
    fiddler_otlp_encoding: str = "protobuf"
    fiddler_fallback_application: str | None = None
    fiddler_timeout_seconds: float = 30.0
    # Portkey admin / analytics API
    portkey_admin_url: str = ""
    portkey_workspace_id: str | None = None
    portkey_cost_unit: str = "cents"
    # Agent registry
    platform_api_url: str = ""
    registry_file: Path | None = None
    # Pull worker
    pull_mode: str = "export"
    pull_interval_seconds: float = 60.0
    pull_overlap_seconds: float = 300.0
    pull_lag_seconds: float = 60.0
    pull_max_window_seconds: float = 3600.0
    pull_initial_lookback_seconds: float = 3600.0
    export_max_wait_seconds: float = 300.0
    worker_enabled: bool = False
    # Content handling
    redact_mode: str = "pii"
    max_content_chars: int = 32000
    # Delivery
    retry_attempts: int = 4
    retry_backoff_seconds: float = 0.5
    max_delivery_attempts: int = 20
    max_batch: int = 1000
    # Reconciliation
    reconcile_projects: list[str] = field(default_factory=list)
    reconcile_min_requests: int = 1
    reconcile_min_spans: int = 1
    reconcile_min_trace_ratio: float = 0.0
    reconcile_min_invocations: int = 1
    reconcile_invocation_env: str = "prod"
    reconcile_suspend_untraced_invocations: bool = False
    reconcile_exempt_agents: list[str] = field(default_factory=lambda: ["ide.vscode", "ide.eclipse", "web.portal"])
    agent_key_name_template: str = "aig-agent-{agent_id}"
    team_key_name_template: str = "aig-{team}-agents"
    suspend_team_key_fallback: bool = False
    # Alerts (email; Slack/PagerDuty secrets are named in backend/observability/manifests/alerts.yaml)
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_user: str | None = None
    smtp_from: str = "aig-telemetry-bridge@aig.example.com"
    smtp_starttls: bool = True
    # Feedback loop
    eval_dataset_dir: Path = Path("eval-datasets")
    reports_dir: Path = Path("reports")
    secrets: Secrets = field(default_factory=lambda: Secrets({}))

    def project_for(self, env: str) -> str:
        return self.fiddler_project_template.format(env=env)

    @property
    def projects_to_reconcile(self) -> list[str]:
        return self.reconcile_projects or [self.project_for(self.env)]

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> "Settings":
        environ = dict(os.environ if environ is None else environ)
        env_file = environ.get("AIG_BRIDGE_ENV_FILE")
        if env_file and Path(env_file).is_file():
            environ = {**parse_env_file(Path(env_file)), **environ}
        g = environ.get
        s = cls()
        s.env = g("AIG_ENV", "local")
        if s.env not in ENVS:
            raise ValueError(f"AIG_ENV must be one of {ENVS}")
        s.log_level = g("AIG_LOG_LEVEL", "INFO")
        s.database_url = g("AIG_BRIDGE_DATABASE_URL") or f"sqlite:///{SERVICE_ROOT / 'state' / 'bridge.db'}"
        if g("AIG_BRIDGE_CONTRACTS_DIR"):
            s.contracts_dir = Path(g("AIG_BRIDGE_CONTRACTS_DIR"))
        if g("AIG_FIDDLER_ROOT"):
            s.fiddler_root = Path(g("AIG_FIDDLER_ROOT"))
        s.endpoints_file = g("AIG_BRIDGE_ENDPOINTS_FILE") or None
        s.fiddler_url = (g("FIDDLER_URL") or "").rstrip("/")
        s.fiddler_project_template = g("FIDDLER_PROJECT_TEMPLATE", s.fiddler_project_template)
        s.fiddler_otlp_encoding = g("FIDDLER_OTLP_ENCODING", s.fiddler_otlp_encoding)
        if s.fiddler_otlp_encoding not in ("protobuf", "json"):
            raise ValueError("FIDDLER_OTLP_ENCODING must be protobuf or json")
        s.fiddler_fallback_application = g("FIDDLER_FALLBACK_APPLICATION") or None
        s.fiddler_timeout_seconds = float(g("FIDDLER_TIMEOUT_SECONDS", s.fiddler_timeout_seconds))
        s.portkey_admin_url = (g("AIG_PORTKEY_ADMIN_URL") or "").rstrip("/")
        s.portkey_workspace_id = g("AIG_PORTKEY_WORKSPACE_ID") or None
        s.portkey_cost_unit = g("AIG_PORTKEY_COST_UNIT", s.portkey_cost_unit)
        if s.portkey_cost_unit not in ("cents", "usd"):
            raise ValueError("AIG_PORTKEY_COST_UNIT must be cents or usd")
        s.platform_api_url = (g("AIG_PLATFORM_API_URL") or "").rstrip("/")
        s.registry_file = Path(g("AIG_BRIDGE_REGISTRY_FILE")) if g("AIG_BRIDGE_REGISTRY_FILE") else None
        s.pull_mode = g("AIG_BRIDGE_PULL_MODE", s.pull_mode)
        if s.pull_mode not in ("export", "list", "off"):
            raise ValueError("AIG_BRIDGE_PULL_MODE must be export, list or off")
        for attr, var in (("pull_interval_seconds", "AIG_BRIDGE_PULL_INTERVAL_SECONDS"),
                          ("pull_overlap_seconds", "AIG_BRIDGE_PULL_OVERLAP_SECONDS"),
                          ("pull_lag_seconds", "AIG_BRIDGE_PULL_LAG_SECONDS"),
                          ("pull_max_window_seconds", "AIG_BRIDGE_PULL_MAX_WINDOW_SECONDS"),
                          ("pull_initial_lookback_seconds", "AIG_BRIDGE_PULL_INITIAL_LOOKBACK_SECONDS"),
                          ("export_max_wait_seconds", "AIG_BRIDGE_EXPORT_MAX_WAIT_SECONDS"),
                          ("retry_backoff_seconds", "AIG_BRIDGE_RETRY_BACKOFF_SECONDS"),
                          ("reconcile_min_trace_ratio", "AIG_BRIDGE_RECONCILE_MIN_TRACE_RATIO")):
            if g(var):
                setattr(s, attr, float(g(var)))
        for attr, var in (("max_content_chars", "AIG_BRIDGE_MAX_CONTENT_CHARS"),
                          ("retry_attempts", "AIG_BRIDGE_RETRY_ATTEMPTS"),
                          ("max_delivery_attempts", "AIG_BRIDGE_MAX_DELIVERY_ATTEMPTS"),
                          ("max_batch", "AIG_BRIDGE_MAX_BATCH"),
                          ("reconcile_min_requests", "AIG_BRIDGE_RECONCILE_MIN_REQUESTS"),
                          ("reconcile_min_spans", "AIG_BRIDGE_RECONCILE_MIN_SPANS"),
                          ("reconcile_min_invocations", "AIG_BRIDGE_RECONCILE_MIN_INVOCATIONS"),
                          ("smtp_port", "AIG_BRIDGE_SMTP_PORT")):
            if g(var):
                setattr(s, attr, int(g(var)))
        s.worker_enabled = _bool(g("AIG_BRIDGE_WORKER"))
        s.redact_mode = g("AIG_BRIDGE_REDACT_MODE", s.redact_mode)
        if s.redact_mode not in ("none", "pii", "hash", "drop"):
            raise ValueError("AIG_BRIDGE_REDACT_MODE must be none, pii, hash or drop")
        s.reconcile_projects = _list(g("AIG_BRIDGE_RECONCILE_PROJECTS"), [])
        s.reconcile_invocation_env = g("AIG_BRIDGE_RECONCILE_INVOCATION_ENV", s.reconcile_invocation_env)
        if s.reconcile_invocation_env not in ("local", "dev", "stage", "prod"):
            raise ValueError("AIG_BRIDGE_RECONCILE_INVOCATION_ENV must be local, dev, stage or prod")
        s.reconcile_suspend_untraced_invocations = _bool(g("AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS"))
        s.reconcile_exempt_agents = _list(g("AIG_BRIDGE_RECONCILE_EXEMPT_AGENTS"), s.reconcile_exempt_agents)
        s.agent_key_name_template = g("AIG_BRIDGE_AGENT_KEY_NAME_TEMPLATE", s.agent_key_name_template)
        s.team_key_name_template = g("AIG_BRIDGE_TEAM_KEY_NAME_TEMPLATE", s.team_key_name_template)
        s.suspend_team_key_fallback = _bool(g("AIG_BRIDGE_SUSPEND_TEAM_KEY_FALLBACK"))
        s.smtp_host = g("AIG_BRIDGE_SMTP_HOST") or None
        s.smtp_user = g("AIG_BRIDGE_SMTP_USER") or None
        s.smtp_from = g("AIG_BRIDGE_SMTP_FROM", s.smtp_from)
        s.smtp_starttls = _bool(g("AIG_BRIDGE_SMTP_STARTTLS"), True)
        s.eval_dataset_dir = Path(g("AIG_BRIDGE_EVAL_DATASET_DIR", str(s.eval_dataset_dir)))
        s.reports_dir = Path(g("AIG_BRIDGE_REPORTS_DIR", str(s.reports_dir)))
        s.secrets = Secrets(environ)
        # Alert channel secrets (named in alerts.yaml) are read from this mapping at send time.
        s.environ = environ
        return s

    environ: Mapping[str, str] = field(default_factory=dict)
