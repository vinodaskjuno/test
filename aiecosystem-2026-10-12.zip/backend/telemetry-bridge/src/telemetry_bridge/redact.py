"""Prompt/reply handling before anything leaves the bridge or is stored (AIG_BRIDGE_REDACT_MODE).

- ``none``: forward as is (truncated to AIG_BRIDGE_MAX_CONTENT_CHARS).
- ``pii`` (default): mask emails, phone numbers, US SSNs, payment-card-like numbers, IBANs and
  key-shaped tokens; Fiddler's own PII trust score still runs on what remains.
- ``hash``: replace content with ``sha256:<hex>`` (joins identical prompts without content).
- ``drop``: send no content at all.
"""

from __future__ import annotations

import hashlib
import re
from typing import Any

_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\b(?:sk|pk|rk|xox[abp])-[A-Za-z0-9_-]{12,}\b"), "[REDACTED_KEY]"),
    (re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{16,}"), "Bearer [REDACTED_KEY]"),
    (re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}"), "[REDACTED_EMAIL]"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[REDACTED_SSN]"),
    (re.compile(r"\b(?:\d[ -]?){13,19}\b"), "[REDACTED_NUMBER]"),
    (re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b"), "[REDACTED_IBAN]"),
    (re.compile(r"(?<!\w)\+?\d{1,3}?[ .-]?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4}\b"), "[REDACTED_PHONE]"),
]
MODES = ("none", "pii", "hash", "drop")


class Redactor:
    def __init__(self, mode: str = "pii", max_chars: int = 32000):
        if mode not in MODES:
            raise ValueError(f"redact mode must be one of {MODES}")
        self.mode = mode
        self.max_chars = max_chars

    def text(self, value: str | None) -> str | None:
        if value is None or value == "":
            return value
        if self.mode == "drop":
            return None
        if self.mode == "hash":
            return "sha256:" + hashlib.sha256(value.encode()).hexdigest()
        if self.mode == "pii":
            for pat, repl in _PATTERNS:
                value = pat.sub(repl, value)
        if len(value) > self.max_chars:
            value = value[: self.max_chars] + "...[truncated]"
        return value

    def tree(self, value: Any) -> Any:
        """Apply ``text`` to every string in a JSON-like structure (dead-letter payloads)."""
        if isinstance(value, str):
            return self.text(value)
        if isinstance(value, list):
            return [self.tree(v) for v in value]
        if isinstance(value, dict):
            return {k: self.tree(v) for k, v in value.items()}
        return value

    def payload(self, raw: Any) -> Any:
        """Raw event for the dead-letter table: request/response bodies redacted, rest kept."""
        if not isinstance(raw, dict):
            return self.tree(raw)
        out = dict(raw)
        for k in ("request", "response", "prompt", "reply", "messages", "body"):
            if k in out:
                out[k] = None if self.mode == "drop" else self.tree(out[k])
        return out
