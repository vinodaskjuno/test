"""Retries with exponential backoff and full jitter."""

from __future__ import annotations

import random
import time
from typing import Callable, TypeVar

T = TypeVar("T")


class TransientError(RuntimeError):
    """Worth retrying (network error, timeout, 408/425/429/5xx)."""


class PermanentError(RuntimeError):
    """Not worth retrying (4xx other than 408/425/429)."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


RETRY_STATUSES = {408, 425, 429}


def classify(status: int, message: str) -> Exception:
    if status in RETRY_STATUSES or status >= 500:
        return TransientError(message)
    return PermanentError(message, status)


def backoff_delay(attempt: int, base: float, cap: float = 30.0) -> float:
    return random.uniform(0, min(cap, base * (2 ** attempt)))


def call_with_retries(fn: Callable[[], T], *, attempts: int, base: float, sleep: Callable[[float], None] = time.sleep) -> T:
    last: Exception | None = None
    for attempt in range(max(1, attempts)):
        try:
            return fn()
        except TransientError as exc:
            last = exc
            if attempt + 1 < attempts:
                sleep(backoff_delay(attempt, base))
    assert last is not None
    raise last
