"""Feedback loop (Phase 3 -> Phase 5 evals).

``export_failing``: failing traces (error status or a trust score past its threshold in
backend/observability/manifests/trust.yaml) from Fiddler into eval dataset CSVs, one file per
agent: columns ``input, expected_output (blank), metadata (JSON), trace_id, reason``.

``guardrail_tickets``: suggested guardrail tightenings for human review, from the guardrail
statistics the bridge records for every gateway event (Portkey ``hook_results``) and,
optionally, from Fiddler trust-score failures that the gateway guardrails let through.
"""

from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .otlp import attr_dict

if TYPE_CHECKING:
    from .service import Bridge

CSV_COLUMNS = ["input", "expected_output", "metadata", "trace_id", "reason"]
TAG_KEYS = ("agent", "team", "tier", "model", "env", "host")
# Which Portkey guardrail (backend/gateway/manifests/guardrails.yaml) should catch what a Fiddler
# trust score flags.
SCORE_TO_GUARDRAILS = {
    "jailbreak": ["aig-input-injection"],
    "pii": ["aig-input-pii", "aig-output-pii"],
    "toxicity": ["aig-input-policy", "aig-output-policy"],
    "hallucination": ["aig-output-schema"],
}


def failing_filter(trust: list[dict]) -> dict:
    rules: list[dict] = [
        {"field": "Span::status", "operator": "equal", "value": "error"},
        {"field": "SpanAttribute::aig.status_code", "operator": "greater_or_equal", "value": 400},
    ]
    for s in trust:
        if not s.get("enabled", True):
            continue
        op = "greater_or_equal" if s["direction"] == "fail_above" else "less"
        for out in s["outputs"]:
            rules.append({"field": f"Evaluator::aig-trust-{s['name']}::{out}", "operator": op, "value": s["threshold"]})
    return {"condition": "OR", "rules": rules}


def _attrs(span: dict) -> dict:
    a = span.get("attributes") or span.get("span_attributes") or {}
    return attr_dict(a) if isinstance(a, list) else dict(a)


def _scores(span: dict) -> dict[tuple[str, str], float]:
    raw = span.get("evaluator_outputs") or span.get("evaluations") or []
    out: dict[tuple[str, str], float] = {}
    if isinstance(raw, dict):
        raw = [{"rule_name": r, "output_name": o, "value": v} for r, outs in raw.items() if isinstance(outs, dict) for o, v in outs.items()]
    for e in raw if isinstance(raw, list) else []:
        try:
            out[(str(e["rule_name"]), str(e["output_name"]))] = float(e["value"])
        except (KeyError, TypeError, ValueError):
            continue
    return out


def failure_reasons(span: dict, trust: list[dict]) -> tuple[list[str], dict[str, float]]:
    attrs = _attrs(span)
    reasons: list[str] = []
    status = str(span.get("status") or span.get("status_code") or "").lower()
    code = attrs.get("aig.status_code")
    if status in ("error", "status_code_error", "2") or (code is not None and int(float(code)) >= 400):
        reasons.append(f"error{f' (HTTP {int(float(code))})' if code is not None else ''}")
    scores = _scores(span)
    flat: dict[str, float] = {}
    for s in trust:
        if not s.get("enabled", True):
            continue
        vals = [scores[(f"aig-trust-{s['name']}", o)] for o in s["outputs"] if (f"aig-trust-{s['name']}", o) in scores]
        if not vals:
            continue
        v = max(vals) if s["aggregate"] == "max" else min(vals)
        flat[s["name"]] = round(v, 4)
        failed = v >= s["threshold"] if s["direction"] == "fail_above" else v < s["threshold"]
        if failed:
            op = ">=" if s["direction"] == "fail_above" else "<"
            reasons.append(f"{s['name']} {v:.2f} {op} {s['threshold']}")
    return reasons, flat


def _query_failing(bridge: "Bridge", since: datetime, until: datetime, projects: list[str], agents: list[str] | None,
                   limit: int):
    trust = bridge.manifests.trust
    flt = failing_filter(trust)
    for project in projects:
        for app in bridge.fiddler.list_applications(project):
            name = str(app.get("name"))
            if agents and name not in agents:
                continue
            for span in bridge.fiddler.query_spans(str(app["id"]), since, until, flt, limit=limit):
                reasons, scores = failure_reasons(span, trust)
                yield project, name, span, reasons or ["matched_failing_filter"], scores


def export_failing(bridge: "Bridge", *, since: datetime, until: datetime | None = None, projects: list[str] | None = None,
                   agents: list[str] | None = None, output_dir: Path | None = None, limit: int = 5000) -> dict:
    until = until or datetime.now(timezone.utc)
    projects = projects or [bridge.settings.project_for(bridge.settings.env)]
    out_dir = Path(output_dir or bridge.settings.eval_dataset_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows: dict[str, list[dict]] = defaultdict(list)
    seen: set[tuple[str, str]] = set()
    reasons_count: Counter = Counter()
    skipped = 0
    for project, agent, span, reasons, scores in _query_failing(bridge, since, until, projects, agents, limit):
        attrs = _attrs(span)
        trace_id = str(attrs.get("aig.trace_id") or span.get("trace_id") or "")
        sid = str(span.get("span_id") or span.get("id") or "")
        if (trace_id, sid) in seen:
            continue
        seen.add((trace_id, sid))
        text = attrs.get("gen_ai.llm.input.user") or attrs.get("gen_ai.input.messages") or span.get("input")
        if not text:
            skipped += 1
            continue
        meta = {k: attrs[k] for k in TAG_KEYS if k in attrs}
        meta.update(project=project, application=agent, span_id=sid, source=attrs.get("aig.source", "sdk"), scores=scores)
        for r in reasons:
            reasons_count[r.split(" ")[0]] += 1
        rows[agent].append({"input": bridge.redactor.text(str(text)) or "", "expected_output": "",
                            "metadata": json.dumps(meta, sort_keys=True, separators=(",", ":")),
                            "trace_id": trace_id, "reason": "; ".join(reasons)})
    stamp = f"{since:%Y%m%d}-{until:%Y%m%d}"
    files = {}
    for agent, items in sorted(rows.items()):
        path = out_dir / f"{agent}.failing.{stamp}.csv"
        with path.open("w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
            w.writeheader()
            w.writerows(items)
        files[agent] = str(path)
    summary = {"kind": "aig.failing_traces_export", "since": since.isoformat(), "until": until.isoformat(),
               "projects": projects, "rows": sum(len(v) for v in rows.values()), "skipped_no_input": skipped,
               "by_agent": {a: len(v) for a, v in sorted(rows.items())}, "by_reason": dict(reasons_count), "files": files}
    (out_dir / f"failing-summary.{stamp}.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def guardrail_tickets(bridge: "Bridge", *, since: datetime, until: datetime | None = None, output_dir: Path | None = None,
                      trust_failures: dict[str, int] | None = None, min_count: int = 5) -> dict:
    until = until or datetime.now(timezone.utc)
    agg: dict[tuple[str, str, str], dict[str, Any]] = {}
    for st in bridge.store.guardrail_stats(since.date().isoformat(), until.date().isoformat()):
        a = agg.setdefault((st.hook_id, st.check_id, st.stage), {"evaluated": 0, "failed": 0, "failed_not_denied": 0, "agents": Counter()})
        a["evaluated"] += st.evaluated
        a["failed"] += st.failed
        a["failed_not_denied"] += st.failed_not_denied
        if st.failed:
            a["agents"][st.agent] += st.failed
    tickets: list[dict] = []
    for (hook, check, stage), a in sorted(agg.items(), key=lambda kv: -kv[1]["failed"]):
        ev = a["evaluated"] or 1
        top = [f"{ag} ({n})" for ag, n in a["agents"].most_common(5)]
        evidence = {"evaluated": a["evaluated"], "failed": a["failed"], "failed_not_denied": a["failed_not_denied"],
                    "fail_rate": round(a["failed"] / ev, 4), "top_agents": top}
        if a["failed_not_denied"] >= min_count:
            rate = a["failed_not_denied"] / ev
            tickets.append({
                "type": "enforce", "guardrail": hook, "check": check, "stage": stage,
                "priority": "HIGH" if rate >= 0.05 else "MEDIUM", "evidence": evidence,
                "title": f"{hook}/{check} flagged {a['failed_not_denied']} {stage} calls without blocking them",
                "suggestion": (f"Switch {hook} from log to deny/redact (mode_override in backend/gateway/manifests/guardrails.yaml) "
                               f"for env {bridge.settings.env}, or tighten the check's parameters; review the top agents first."),
            })
        elif a["evaluated"] >= 20 and a["failed"] / ev >= 0.2:
            tickets.append({
                "type": "review_threshold", "guardrail": hook, "check": check, "stage": stage, "priority": "MEDIUM",
                "evidence": evidence, "title": f"{hook}/{check} fails {a['failed'] / ev:.0%} of {stage} calls",
                "suggestion": "High failure rate: confirm these are true positives, then keep or adjust the threshold; "
                              "consider agent-specific allow-lists before loosening.",
            })
    for score, n in sorted((trust_failures or {}).items(), key=lambda kv: -kv[1]):
        if n < min_count:
            continue
        tickets.append({
            "type": "tighten_from_trust", "guardrail": ", ".join(SCORE_TO_GUARDRAILS.get(score, [])) or "(none)",
            "check": score, "stage": "input" if score in ("jailbreak",) else "input/output",
            "priority": "HIGH" if score in ("jailbreak", "pii") else "MEDIUM", "evidence": {"fiddler_failures": n},
            "title": f"Fiddler {score} trust score failed on {n} spans that passed the gateway guardrails",
            "suggestion": f"Tighten {', '.join(SCORE_TO_GUARDRAILS.get(score, ['a new guardrail']))}: lower its threshold or "
                          "enforce it; add the exported failing traces to the eval dataset (export-failing).",
        })
    for i, t in enumerate(tickets, 1):
        t["id"] = f"GRT-{since:%Y%m%d}-{i:03d}"
    out_dir = Path(output_dir or bridge.settings.reports_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = f"{since:%Y%m%d}-{until:%Y%m%d}"
    doc = {"kind": "aig.guardrail_tickets", "env": bridge.settings.env, "since": since.isoformat(), "until": until.isoformat(),
           "tickets": tickets}
    json_path = out_dir / f"guardrail-tickets.{stamp}.json"
    md_path = out_dir / f"guardrail-tickets.{stamp}.md"
    json_path.write_text(json.dumps(doc, indent=2) + "\n")
    md_path.write_text(render_markdown(doc))
    return {**doc, "files": {"json": str(json_path), "markdown": str(md_path)}}


def render_markdown(doc: dict) -> str:
    lines = [f"# Guardrail tightening suggestions ({doc['env']})", "",
             f"Window: {doc['since']} to {doc['until']}. Generated by `telemetry-bridge guardrail-tickets` for human review; "
             "nothing is changed automatically.", ""]
    if not doc["tickets"]:
        lines.append("No suggestions for this window.")
    for t in doc["tickets"]:
        lines += [f"## {t['id']} [{t['priority']}] {t['title']}", "",
                  f"- Guardrail: `{t['guardrail']}` check `{t['check']}` ({t['stage']})",
                  f"- Type: {t['type']}",
                  f"- Evidence: `{json.dumps(t['evidence'], sort_keys=True)}`",
                  f"- Suggestion: {t['suggestion']}", ""]
    return "\n".join(lines) + "\n"


def trust_failure_counts(bridge: "Bridge", *, since: datetime, until: datetime, projects: list[str] | None = None) -> dict[str, int]:
    counts: Counter = Counter()
    projects = projects or [bridge.settings.project_for(bridge.settings.env)]
    for _, _, span, reasons, _ in _query_failing(bridge, since, until, projects, None, 5000):
        attrs = _attrs(span)
        if attrs.get("aig.guardrail.verdict") == "fail":
            continue  # the gateway already flagged it
        for r in reasons:
            name = r.split(" ")[0]
            if name in SCORE_TO_GUARDRAILS:
                counts[name] += 1
    return dict(counts)
