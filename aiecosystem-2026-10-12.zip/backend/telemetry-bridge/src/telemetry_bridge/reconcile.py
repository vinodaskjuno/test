"""Daily reconciliation: "no gateway, no Fiddler, no agent".

For the given UTC day, compare per-agent Portkey traffic (analytics grouped by metadata
``agent_id``) with the agent's own Fiddler traces (SDK spans, i.e. all spans in the agent's
application minus the ones telemetry-bridge itself wrote, ``aig.source = telemetry-bridge``).
An active, non-exempt agent with gateway traffic (>= AIG_BRIDGE_RECONCILE_MIN_REQUESTS) and
fewer than AIG_BRIDGE_RECONCILE_MIN_SPANS SDK spans (or a trace/request ratio below
AIG_BRIDGE_RECONCILE_MIN_TRACE_RATIO) is a violation, and unless ``dry_run``:

1. it is marked ``suspended`` in the registry (platform-api ``POST /api/v1/agents/{id}/suspend``
   or the registry YAML) -> the gateway's agent-check webhook denies it from then on;
2. its Portkey API key is suspended through the admin API (key ``portkey_api_key_id`` from the
   registry, else the key named AIG_BRIDGE_AGENT_KEY_NAME_TEMPLATE; the team key only with
   AIG_BRIDGE_SUSPEND_TEAM_KEY_FALLBACK=true, because it is shared by the whole team);
3. the owner (and the routed channels for event ``agent_suspended``) is alerted with links.

Registered versions with invocations but no traces: platform-api's invocation records
(``GET /api/v1/invocations/summary``, env AIG_BRIDGE_RECONCILE_INVOCATION_ENV, default ``prod``) are
compared with the agent's SDK spans for the same day. An active agent whose versions served >=
AIG_BRIDGE_RECONCILE_MIN_INVOCATIONS invocations but reported fewer than
AIG_BRIDGE_RECONCILE_MIN_SPANS SDK spans is listed in ``invocations`` with verdict
``untraced_invocations``. It is report-only unless AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS
is true, in which case the same suspension path as above runs (and still only without ``dry_run``).

Fail safe: if Portkey analytics or the registry cannot be read nothing is suspended, and an
agent whose Fiddler lookup fails is reported as ``error``, never suspended.
"""

from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from typing import TYPE_CHECKING, Any

from .retry import PermanentError, TransientError

if TYPE_CHECKING:
    from .service import Bridge

BRIDGE_SPANS_FILTER = {"condition": "AND", "rules": [
    {"field": "SpanAttribute::aig.source", "operator": "equal", "value": "telemetry-bridge"}]}


def day_window(day: date) -> tuple[datetime, datetime]:
    start = datetime.combine(day, time.min, tzinfo=timezone.utc)
    return start, start + timedelta(days=1)


def _fiddler_counts(bridge: "Bridge", agent_id: str, start: datetime, end: datetime) -> dict[str, Any]:
    total = from_bridge = 0
    per_project = {}
    for project in bridge.settings.projects_to_reconcile:
        app_id = bridge.fiddler.application_id(project, agent_id)
        if not app_id:
            per_project[project] = {"application": "missing"}
            continue
        t, sampled = bridge.fiddler.span_count(app_id, start, end)
        b, _ = bridge.fiddler.span_count(app_id, start, end, BRIDGE_SPANS_FILTER) if t else (0, False)
        per_project[project] = {"application_id": app_id, "spans": t, "bridge_spans": b, "sampled": sampled}
        total += t
        from_bridge += b
    return {"spans_total": total, "spans_bridge": from_bridge, "spans_sdk": max(0, total - from_bridge), "projects": per_project}


def _suspend(bridge: "Bridge", registry, agent, evidence: dict, dry_run: bool) -> list[dict]:
    s = bridge.settings
    actions: list[dict] = []
    if "invocations" in evidence:
        reason = (f"agent invocations without Fiddler traces on {evidence['day']}: {evidence['invocations']} invocations, "
                  f"{evidence['spans_sdk']} SDK spans")
    else:
        reason = (f"gateway traffic without Fiddler traces on {evidence['day']}: {evidence['gateway_requests']} requests, "
                  f"{evidence['spans_sdk']} SDK spans")
    # 1. registry
    if dry_run:
        actions.append({"type": "registry_suspend", "status": "dry_run"})
    else:
        try:
            out = registry.suspend(agent.agent_id, reason, evidence)
            actions.append({"type": "registry_suspend", "status": "done" if out.get("changed", True) else "already_suspended"})
        except (TransientError, PermanentError) as exc:
            actions.append({"type": "registry_suspend", "status": "error", "error": str(exc)[:200]})
    # 2. Portkey key
    key_name = s.agent_key_name_template.format(agent_id=agent.agent_id, team=agent.team)
    try:
        key = {"id": agent.portkey_api_key_id, "name": key_name} if agent.portkey_api_key_id else bridge.portkey.find_api_key(key_name)
        if key is None and s.suspend_team_key_fallback:
            key_name = s.team_key_name_template.format(team=agent.team, agent_id=agent.agent_id)
            key = bridge.portkey.find_api_key(key_name)
        if key is None:
            actions.append({"type": "portkey_key_suspend", "status": "key_not_found", "key_name": key_name,
                            "note": "the registry suspension still makes the gateway agent-check deny this agent"})
        elif dry_run:
            actions.append({"type": "portkey_key_suspend", "status": "dry_run", "key_name": key.get("name", key_name)})
        else:
            bridge.portkey.suspend_api_key(str(key.get("id")))
            actions.append({"type": "portkey_key_suspend", "status": "done", "key_name": key.get("name", key_name),
                            "key_id": str(key.get("id"))})
    except (TransientError, PermanentError) as exc:
        actions.append({"type": "portkey_key_suspend", "status": "error", "error": str(exc)[:200]})
    # 3. alert
    project = s.project_for(s.env)
    links = {"application": bridge.manifests.link("application", fiddler_url=bridge.fiddler_ui_url, project=project, application=agent.agent_id),
             "failing_traces": bridge.manifests.link("failing_traces", fiddler_url=bridge.fiddler_ui_url, project=project, application=agent.agent_id)}
    notifier = bridge.notifier()
    try:
        sent = notifier.notify(
            event="agent_suspended", team=agent.team, owner=agent.owner, dry_run=dry_run,
            subject=f"[AIG] Agent {agent.agent_id} suspended: gateway traffic without Fiddler traces",
            text=(f"Agent {agent.agent_id} (team {agent.team}, owner {agent.owner}): {reason}. "
                  "It has been suspended (no gateway, no Fiddler, no agent). Fix the SDK tracing (aig doctor), then ask "
                  "the platform team to reinstate it (POST /api/v1/agents/{id}/reinstate)."),
            links=links, dedup_key=f"aig-suspend-{agent.agent_id}-{evidence['day']}",
        )
    finally:
        notifier.close()
    actions.append({"type": "alert", "status": "dry_run" if dry_run else "done", "channels": sent})
    return actions


def run_reconcile(bridge: "Bridge", *, day: date | None = None, dry_run: bool = False) -> dict:
    s = bridge.settings
    day = day or (datetime.now(timezone.utc).date() - timedelta(days=1))
    start, end = day_window(day)
    report: dict[str, Any] = {
        "kind": "aig.reconciliation", "env": s.env, "day": day.isoformat(), "window": [start.isoformat(), end.isoformat()],
        "dry_run": dry_run, "projects": s.projects_to_reconcile,
        "thresholds": {"min_requests": s.reconcile_min_requests, "min_spans": s.reconcile_min_spans,
                       "min_trace_ratio": s.reconcile_min_trace_ratio, "exempt_agents": s.reconcile_exempt_agents},
        "agents": [], "errors": [],
    }
    try:
        traffic = bridge.portkey.requests_by_metadata("agent_id", start, end)
    except (TransientError, PermanentError) as exc:
        report["errors"].append(f"portkey analytics: {exc}"[:300])
        return _finish(report)
    try:
        registry = bridge.registry()
        agents = {a.agent_id: a for a in registry.list_agents()}
    except (TransientError, PermanentError) as exc:
        report["errors"].append(f"agent registry: {exc}"[:300])
        return _finish(report)

    for agent_id in sorted(set(traffic) | set(agents)):
        requests = int(traffic.get(agent_id, 0))
        a = agents.get(agent_id)
        row: dict[str, Any] = {"agent_id": agent_id, "gateway_requests": requests}
        if a is None:
            row["verdict"] = "unregistered_traffic" if requests else "unknown"
            report["agents"].append(row)
            continue
        row.update(team=a.team, owner=a.owner, status=a.status)
        if agent_id in s.reconcile_exempt_agents:
            row["verdict"] = "exempt"
        elif requests < s.reconcile_min_requests:
            row["verdict"] = "no_traffic"
        elif a.status != "active":
            row["verdict"] = "already_suspended"
        else:
            try:
                row.update(_fiddler_counts(bridge, agent_id, start, end))
            except (TransientError, PermanentError) as exc:
                row.update(verdict="error", error=str(exc)[:200])
                report["agents"].append(row)
                continue
            sdk = row["spans_sdk"]
            ratio = sdk / requests if requests else 1.0
            row["trace_ratio"] = round(ratio, 4)
            violation = sdk < s.reconcile_min_spans or (s.reconcile_min_trace_ratio > 0 and ratio < s.reconcile_min_trace_ratio)
            row["verdict"] = "violation" if violation else "ok"
            if violation:
                evidence = {"day": day.isoformat(), "gateway_requests": requests, "spans_sdk": sdk,
                            "spans_total": row["spans_total"], "projects": s.projects_to_reconcile}
                row["actions"] = _suspend(bridge, registry, a, evidence, dry_run)
        report["agents"].append(row)
    _reconcile_invocations(bridge, registry, agents, report, day, start, end, dry_run)
    return _finish(report)


def _reconcile_invocations(bridge: "Bridge", registry, agents: dict, report: dict, day: date, start: datetime,
                           end: datetime, dry_run: bool) -> None:
    """Registered versions with invocations (platform-api records) but no Fiddler traces."""
    s = bridge.settings
    section: dict[str, Any] = {"env": s.reconcile_invocation_env, "min_invocations": s.reconcile_min_invocations,
                               "suspend": s.reconcile_suspend_untraced_invocations, "agents": []}
    report["invocations"] = section
    try:
        summary = registry.invocation_summary(start, end, s.reconcile_invocation_env)
    except (TransientError, PermanentError) as exc:
        report["errors"].append(f"invocation summary: {exc}"[:300])
        return
    if summary is None:
        section["note"] = "registry source has no invocation records (YAML registry)"
        return
    per_agent: dict[str, dict] = {}
    for item in summary:
        aid = str(item.get("agent_id") or "")
        if not aid:
            continue
        entry = per_agent.setdefault(aid, {"invocations": 0, "versions": []})
        entry["invocations"] += int(item.get("invocations") or 0)
        entry["versions"].append({"version": item.get("version"), "env": item.get("env"),
                                  "invocations": int(item.get("invocations") or 0)})
    rows_by_id = {r["agent_id"]: r for r in report["agents"]}
    for aid in sorted(per_agent):
        entry = per_agent[aid]
        a = agents.get(aid)
        row: dict[str, Any] = {"agent_id": aid, "invocations": entry["invocations"], "versions": entry["versions"]}
        gw = rows_by_id.get(aid, {})
        if a is None:
            row["verdict"] = "unregistered"
        elif aid in s.reconcile_exempt_agents:
            row["verdict"] = "exempt"
        elif entry["invocations"] < s.reconcile_min_invocations:
            row["verdict"] = "below_threshold"
        elif a.status != "active" or gw.get("verdict") == "violation":
            row["verdict"] = "already_suspended"
        else:
            try:
                counts = ({k: gw[k] for k in ("spans_total", "spans_bridge", "spans_sdk")} if "spans_sdk" in gw
                          else _fiddler_counts(bridge, aid, start, end))
            except (TransientError, PermanentError) as exc:
                row.update(verdict="error", error=str(exc)[:200])
                section["agents"].append(row)
                continue
            row.update({k: counts[k] for k in ("spans_total", "spans_bridge", "spans_sdk")})
            untraced = row["spans_sdk"] < s.reconcile_min_spans
            row["verdict"] = "untraced_invocations" if untraced else "ok"
            if untraced:
                evidence = {"day": day.isoformat(), "invocations": entry["invocations"], "versions": entry["versions"],
                            "spans_sdk": row["spans_sdk"], "spans_total": row["spans_total"],
                            "projects": s.projects_to_reconcile}
                if s.reconcile_suspend_untraced_invocations:
                    row["actions"] = _suspend(bridge, registry, a, evidence, dry_run)
                else:
                    row["actions"] = [{"type": "report", "status": "report_only",
                                       "note": "set AIG_BRIDGE_RECONCILE_SUSPEND_UNTRACED_INVOCATIONS=true to suspend"}]
        section["agents"].append(row)


def _finish(report: dict) -> dict:
    verdicts: dict[str, int] = {}
    for r in report["agents"]:
        verdicts[r["verdict"]] = verdicts.get(r["verdict"], 0) + 1
    inv_rows = (report.get("invocations") or {}).get("agents", [])
    suspended = [r["agent_id"] for r in report["agents"] if r.get("verdict") == "violation"]
    suspended += [r["agent_id"] for r in inv_rows if r.get("verdict") == "untraced_invocations"
                  and any(a.get("type") == "registry_suspend" for a in r.get("actions", []))]
    report["summary"] = {
        "agents": len(report["agents"]), "verdicts": verdicts,
        "suspended": suspended,
        "untraced_invocations": [r["agent_id"] for r in inv_rows if r.get("verdict") == "untraced_invocations"],
        "errors": len(report["errors"]) + verdicts.get("error", 0)
        + sum(1 for r in inv_rows if r.get("verdict") == "error")
        + sum(1 for r in [*report["agents"], *inv_rows] for a in r.get("actions", []) if a.get("status") == "error"),
    }
    return report
