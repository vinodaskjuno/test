"""Turn a Portkey log (pull export, webhook or log push), an IDE usage event or a platform-api
invocation event into one ``GatewayEvent`` with the shared AIG tags
(backend/contracts/tags.schema.json).

Portkey field names differ between versions and between the export, the logs API and webhook
payloads, so every field is read defensively from the known alternatives (ASSUMED names are
listed next to each reader; verify against the self-hosted version with a real export).
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

MODEL_RE = re.compile(r"^[A-Za-z0-9._:/@-]{1,128}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")


class NormalizeError(Exception):
    def __init__(self, reason: str, details: Any = None):
        super().__init__(reason)
        self.reason = reason
        self.details = details


@dataclass
class GatewayEvent:
    key: str
    source: str  # portkey | ide | invocation
    event_id: str
    trace_id: str | None
    start: datetime
    latency_ms: float | None
    tags: dict[str, str]
    attributes: dict[str, Any] = field(default_factory=dict)
    system: str | None = None
    prompt: str | None = None
    reply: str | None = None
    is_error: bool = False
    status_code: int | None = None
    guardrails: list[dict] = field(default_factory=list)

    @property
    def agent(self) -> str:
        return self.tags.get("agent", "")

    @property
    def env(self) -> str:
        return self.tags.get("env", "")


def _first(d: Any, *keys: str) -> Any:
    if not isinstance(d, dict):
        return None
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


def _num(v: Any) -> float | None:
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v))
    except ValueError:
        return None


def _json(v: Any) -> Any:
    if isinstance(v, str):
        try:
            return json.loads(v)
        except ValueError:
            return v
    return v


def parse_time(v: Any) -> datetime | None:
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        ts = float(v)
        return datetime.fromtimestamp(ts / 1000 if ts > 1e11 else ts, tz=timezone.utc)
    s = str(v).strip().replace("Z", "+00:00")
    if " " in s and "T" not in s:
        s = s.replace(" ", "T", 1)
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _content_text(content: Any) -> str:
    """OpenAI string content, or a list of parts (OpenAI/Anthropic) -> plain text."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for p in content:
            if isinstance(p, str):
                parts.append(p)
            elif isinstance(p, dict) and isinstance(p.get("text"), str):
                parts.append(p["text"])
        return "\n".join(parts)
    return ""


def _body(v: Any) -> dict:
    v = _json(v)
    if isinstance(v, dict) and isinstance(_json(v.get("body")), dict):
        return _json(v["body"])
    return v if isinstance(v, dict) else {}


def extract_prompt(request: dict) -> tuple[str | None, str | None]:
    messages = request.get("messages")
    system = request.get("system") if isinstance(request.get("system"), str) else None
    if isinstance(messages, list):
        sys_parts, user_parts = [], []
        for m in messages:
            if not isinstance(m, dict):
                continue
            text = _content_text(m.get("content"))
            if m.get("role") in ("system", "developer"):
                sys_parts.append(text)
            elif m.get("role") in ("user", "tool"):
                user_parts.append(text)
        return ("\n".join(sys_parts) or system or None), ("\n\n".join(user_parts) or None)
    if isinstance(request.get("prompt"), str):
        return system, request["prompt"]
    if isinstance(request.get("input"), (str, list)):
        return system, _content_text(request["input"]) if isinstance(request["input"], list) else request["input"]
    return system, None


def extract_reply(response: dict) -> str | None:
    choices = response.get("choices")
    if isinstance(choices, list) and choices:
        c = choices[0] if isinstance(choices[0], dict) else {}
        msg = c.get("message") or c.get("delta") or {}
        text = _content_text(msg.get("content")) if isinstance(msg, dict) else ""
        return text or (c.get("text") if isinstance(c.get("text"), str) else None) or None
    if isinstance(response.get("content"), list):  # Anthropic messages
        return _content_text(response["content"]) or None
    if isinstance(response.get("output_text"), str):
        return response["output_text"]
    return None


def cache_status(raw: dict, response_headers: dict | None = None) -> str:
    v = _first(raw, "cache_status", "cacheStatus", "cache_type", "cache")
    if v is None and response_headers:
        v = response_headers.get("x-portkey-cache-status")
    s = str(v or "").strip().upper().replace("_", " ")
    if not s:
        return "unknown"
    if "SEMANTIC" in s and "HIT" in s:
        return "semantic_hit"
    if "HIT" in s:
        return "hit"
    if "MISS" in s:
        return "miss"
    if "DISABLED" in s or s == "NONE" or s == "FALSE":
        return "disabled"
    return "unknown"


def guardrail_results(raw: dict) -> list[dict]:
    """Portkey ``hook_results`` ({before_request_hooks: [...], after_request_hooks: [...]}) or a
    flat ``guardrail_results`` list -> [{hook_id, stage, verdict, denied, checks: [{id, verdict}]}]."""
    hooks = _json(_first(raw, "hook_results", "hookResults", "guardrail_results", "guardrails"))
    items: list[tuple[str, dict]] = []
    if isinstance(hooks, dict):
        for key, stage in (("before_request_hooks", "input"), ("beforeRequestHooks", "input"),
                           ("after_request_hooks", "output"), ("afterRequestHooks", "output")):
            for h in hooks.get(key) or []:
                if isinstance(h, dict):
                    items.append((stage, h))
    elif isinstance(hooks, list):
        for h in hooks:
            if isinstance(h, dict):
                stage = "output" if str(h.get("eventType") or h.get("stage") or "").lower().startswith("after") or h.get("stage") == "output" else "input"
                items.append((stage, h))
    out = []
    for stage, h in items:
        checks = [{"id": str(c.get("id") or c.get("name") or "check"), "verdict": bool(c.get("verdict", True))}
                  for c in h.get("checks") or [] if isinstance(c, dict)]
        verdict = h.get("verdict")
        verdict = all(c["verdict"] for c in checks) if verdict is None else bool(verdict)
        out.append({"hook_id": str(h.get("id") or h.get("name") or "guardrail"), "stage": stage, "verdict": verdict,
                    "denied": bool(h.get("deny", False)) and not verdict, "checks": checks})
    return out


def otel_trace_id(trace_id: str | None, seed: str) -> str:
    """32-hex OTel trace id. A 32-hex Portkey trace id (the SDK contract) or a UUID is used as is,
    so Fiddler spans and Portkey logs join; anything else is hashed (original kept in aig.trace_id)."""
    t = (trace_id or "").strip().lower()
    compact = t.replace("-", "")
    if re.fullmatch(r"[0-9a-f]{32}", compact) and compact != "0" * 32:
        return compact
    return hashlib.sha256((trace_id or seed).encode()).hexdigest()[:32]


def span_id(seed: str) -> str:
    return hashlib.sha256(("span:" + seed).encode()).hexdigest()[:16]


def _tag_model(model: Any) -> str:
    m = str(model or "").strip()
    return m if MODEL_RE.match(m) else "auto"


def build_tags(metadata: dict, model: Any, trace_id: str | None) -> dict[str, str]:
    """Tags exactly as tags.schema.json names them; values are validated afterwards (invalid
    values are quarantined, never silently fixed)."""
    tags: dict[str, Any] = {
        "agent": metadata.get("agent_id"),
        "team": metadata.get("team"),
        "tier": metadata.get("user_tier"),
        "model": _tag_model(model),
        "env": metadata.get("env"),
        "host": metadata.get("host"),
    }
    tags = {k: v for k, v in tags.items() if v is not None}
    if trace_id:
        tags["aig.trace_id"] = trace_id
    user = metadata.get("user") or metadata.get("_user")
    if isinstance(user, str) and EMAIL_RE.match(user):
        tags["aig.user"] = user
    # Agent mode inside an aig-http/1 invocation: the serve helpers put the verified caller and the
    # invocation id into x-portkey-metadata; carried as is (validated, never fixed) so Fiddler can
    # join the gateway event with the invocation and group cost by caller team.
    for meta_key, tag in (("caller_user", "aig.caller_user"), ("caller_team", "aig.caller_team"),
                          ("invocation_id", "aig.invocation_id"), ("session_id", "aig.session_id")):
        if metadata.get(meta_key) is not None:
            tags[tag] = metadata[meta_key]
    return tags


def normalize_portkey_log(raw: Any, *, cost_unit: str = "cents") -> GatewayEvent:
    if not isinstance(raw, dict):
        raise NormalizeError("invalid_payload", "log entry is not an object")
    log_id = _first(raw, "id", "log_id", "request_id", "requestId")
    if not log_id:
        raise NormalizeError("missing_log_id", "no id/log_id/request_id; cannot deduplicate")
    log_id = str(log_id)
    request = _body(_first(raw, "request", "request_body", "requestBody"))
    response = _body(_first(raw, "response", "response_body", "responseBody"))
    raw_request = _json(raw.get("request"))
    req_headers: dict[str, Any] = {}
    if isinstance(raw_request, dict) and isinstance(_json(raw_request.get("headers")), dict):
        req_headers = {str(k).lower(): v for k, v in _json(raw_request["headers"]).items()}
    metadata = _json(_first(raw, "metadata"))
    if not isinstance(metadata, dict):
        metadata = _json(req_headers.get("x-portkey-metadata"))
    if not isinstance(metadata, dict):
        metadata = _json(request.get("metadata")) if isinstance(request.get("metadata"), (dict, str)) else None
    if not isinstance(metadata, dict) or not metadata:
        raise NormalizeError("missing_metadata", "log has no x-portkey-metadata; cannot tag")
    trace_id = _first(raw, "trace_id", "traceId") or req_headers.get("x-portkey-trace-id") or metadata.get("trace_id")
    trace_id = str(trace_id) if trace_id else None
    model = _first(response, "model") or _first(raw, "ai_model", "model") or _first(request, "model")
    created = parse_time(_first(raw, "created_at", "createdAt", "timestamp", "time_of_generation")) or datetime.now(timezone.utc)
    latency = _num(_first(raw, "response_time", "responseTime", "latency_ms", "latency"))
    usage = response.get("usage") if isinstance(response.get("usage"), dict) else {}
    prompt_tokens = _num(_first(raw, "req_units", "prompt_tokens")) or _num(_first(usage, "prompt_tokens", "input_tokens")) or 0
    completion_tokens = _num(_first(raw, "res_units", "completion_tokens")) or _num(_first(usage, "completion_tokens", "output_tokens")) or 0
    total_tokens = _num(_first(raw, "total_units", "total_tokens")) or _num(_first(usage, "total_tokens")) or prompt_tokens + completion_tokens
    cost = _num(_first(raw, "cost", "total_cost"))
    cost_usd = None if cost is None else (cost / 100.0 if cost_unit == "cents" else cost)
    status = _num(_first(raw, "response_status_code", "status_code", "status"))
    status_code = int(status) if status is not None else None
    success = raw.get("is_success")
    is_error = (status_code is not None and status_code >= 400) or success is False
    system, prompt = extract_prompt(request)
    reply = extract_reply(response)
    guards = guardrail_results(raw)
    tags = build_tags(metadata, model, trace_id)
    attrs: dict[str, Any] = {
        "aig.source": "telemetry-bridge",
        "aig.event_kind": "gateway",
        "aig.portkey.log_id": log_id,
        "gen_ai.request.model": str(_first(request, "model") or model or "auto"),
        "gen_ai.response.model": str(model or ""),
        "gen_ai.system": str(_first(raw, "ai_org", "provider", "ai_provider") or ""),
        "gen_ai.usage.input_tokens": int(prompt_tokens),
        "gen_ai.usage.output_tokens": int(completion_tokens),
        "gen_ai.usage.total_tokens": int(total_tokens),
        "aig.cache_status": cache_status(raw),
        "aig.job_profile": str(metadata.get("job_profile") or ""),
        "aig.guardrail.verdict": "fail" if any(not g["verdict"] for g in guards) else ("pass" if guards else "none"),
        "aig.guardrail.failed_checks": sorted({f"{g['hook_id']}:{c['id']}" for g in guards for c in g["checks"] if not c["verdict"]}
                                              | {g["hook_id"] for g in guards if not g["verdict"] and not g["checks"]}),
        "aig.guardrail.denied": any(g["denied"] for g in guards),
    }
    if guards:
        attrs["aig.guardrail.results"] = json.dumps(guards, separators=(",", ":"), sort_keys=True)
    if cost_usd is not None:
        attrs["aig.cost_usd"] = round(cost_usd, 8)
    if latency is not None:
        attrs["aig.latency_ms"] = latency
    if status_code is not None:
        attrs["aig.status_code"] = status_code
    return GatewayEvent(
        key=f"portkey:{log_id}", source="portkey", event_id=log_id, trace_id=trace_id, start=created,
        latency_ms=latency, tags=tags, attributes={k: v for k, v in attrs.items() if v not in ("", None)},
        system=system, prompt=prompt, reply=reply, is_error=is_error, status_code=status_code, guardrails=guards,
    )


def normalize_ide_usage(ev: dict) -> GatewayEvent:
    """``ev`` must already validate against backend/contracts/ide-usage-event.schema.json."""
    metadata = {"agent_id": ev["agent_id"], "team": ev["team"], "user_tier": ev["user_tier"], "env": ev["env"],
                "host": ev["source"], "user": ev.get("user")}
    tags = build_tags(metadata, ev.get("model"), ev.get("trace_id"))
    total = ev.get("total_tokens", ev["prompt_tokens"] + ev["completion_tokens"])
    attrs: dict[str, Any] = {
        "aig.source": "telemetry-bridge",
        "aig.event_kind": "ide_usage",
        "aig.ide.event_id": ev["event_id"],
        "gen_ai.request.model": ev.get("model") or "auto",
        "gen_ai.usage.input_tokens": ev["prompt_tokens"],
        "gen_ai.usage.output_tokens": ev["completion_tokens"],
        "gen_ai.usage.total_tokens": total,
        "aig.cache_status": ev.get("cache", "unknown"),
        "aig.job_profile": ev.get("job_profile", ""),
        "aig.request_kind": ev.get("request_kind", ""),
        "aig.error_code": ev.get("error_code", ""),
    }
    if "cost_usd" in ev:
        attrs["aig.cost_usd"] = ev["cost_usd"]
    if "latency_ms" in ev:
        attrs["aig.latency_ms"] = ev["latency_ms"]
    return GatewayEvent(
        key=f"ide:{ev['event_id']}", source="ide", event_id=ev["event_id"], trace_id=ev.get("trace_id"),
        start=parse_time(ev["timestamp"]) or datetime.now(timezone.utc), latency_ms=ev.get("latency_ms"), tags=tags,
        attributes={k: v for k, v in attrs.items() if v not in ("", None)}, is_error=ev.get("status") == "error",
    )


def normalize_invocation(ev: dict) -> GatewayEvent:
    """``ev`` must already validate against backend/contracts/invocation-event.schema.json
    (metadata only: no input, messages or output ever reach this function)."""
    metadata = {"agent_id": ev["agent_id"], "team": ev["team"], "user_tier": ev["caller_tier"], "env": ev["env"],
                "host": ev["agent_host"], "caller_user": ev["caller_user"], "caller_team": ev["caller_team"],
                "invocation_id": ev["invocation_id"], "session_id": ev.get("session_id")}
    tags = build_tags(metadata, None, ev["trace_id"])
    prompt, completion = ev.get("prompt_tokens"), ev.get("completion_tokens")
    total = ev.get("total_tokens")
    if total is None and prompt is not None and completion is not None:
        total = prompt + completion
    finished = parse_time(ev["timestamp"]) or datetime.now(timezone.utc)
    started = parse_time(ev.get("started_at")) if ev.get("started_at") else None
    if started is None:
        started = finished - timedelta(milliseconds=ev["duration_ms"])
    attrs: dict[str, Any] = {
        "aig.source": "telemetry-bridge",
        "aig.event_kind": "invocation",
        "aig.invocation.status": ev["status"],
        "aig.invocation.mode": ev["mode"],
        "aig.invocation.purpose": ev["purpose"],
        "aig.invocation.duration_ms": ev["duration_ms"],
        "aig.invocation.kind": ev.get("kind", ""),
        "aig.agent.version": ev["version"],
        "aig.latency_ms": float(ev["duration_ms"]),
        "aig.error_code": ev.get("error_code", ""),
        "gen_ai.usage.input_tokens": prompt,
        "gen_ai.usage.output_tokens": completion,
        "gen_ai.usage.total_tokens": total,
    }
    return GatewayEvent(
        key=f"invocation:{ev['invocation_id']}", source="invocation", event_id=ev["invocation_id"],
        trace_id=ev["trace_id"], start=started, latency_ms=float(ev["duration_ms"]), tags=tags,
        attributes={k: v for k, v in attrs.items() if v not in ("", None)}, is_error=ev["status"] in ("failed", "timeout"),  # cancelled is not an agent error
    )
