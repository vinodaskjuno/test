# infra/terraform: AWS infrastructure for AIG (Phase 5, Phase 6 workspaces)

Terraform for the cloud half of the platform: Bedrock AgentCore runtimes for agents, ECS Fargate
for the platform services and the Phase 6 team workspaces (orchestrator, workspace tasks, Teams
bot), and the network, secrets, registries and alarms around them.
Procedures (bootstrap, secret upload, promotion, rollback, runbook) are in
[`docs/deploy.md`](../../docs/deploy.md).

**Status:** nothing has been applied to a real AWS account yet. Every root validates offline
(`terraform validate`) and has offline plan tests against a mocked AWS provider
(`terraform test`). Nothing here needs credentials to check, and CI never runs `plan` or `apply`
outside the deploy workflows.

## Versions

| | Version | Where it is pinned |
|---|---|---|
| Terraform CLI | 1.9.8 | `scripts/tools.sh` (downloads into `.tools/`), `ci.yml`, `deploy-*-env.yml` (`hashicorp/setup-terraform`) |
| `hashicorp/aws` | `~> 6.0` (locked at 6.68.0) | `versions.tf` in each module and root, `.terraform.lock.hcl` in each root (linux/darwin, amd64/arm64) |
| `hashicorp/awscc` | not used | see below |

**Bedrock AgentCore resource type.** `terraform providers schema -json` (aws 6.68.0, awscc 1.105.0)
lists `aws_bedrockagentcore_agent_runtime` and `aws_bedrockagentcore_agent_runtime_endpoint` in
`hashicorp/aws`, and `awscc_bedrockagentcore_runtime` / `_runtime_endpoint` in `hashicorp/awscc`.
The modules use the **`hashicorp/aws` resources**, so a single provider is enough. The arguments
in use are `agent_runtime_name`, `role_arn`, `agent_runtime_artifact.container_configuration.container_uri`,
`network_configuration { network_mode = "VPC", network_mode_config { subnets, security_groups } }`,
`environment_variables`, `protocol_configuration`, `lifecycle_configuration` and
`authorizer_configuration.custom_jwt_authorizer`. AgentCore has no native secret injection: see
[agentcore-runtime](#agentcore-runtime).

## Layout

```
infra/terraform/
  envs/{dev,stage,prod}/       root stack per environment (state aig/<env>/env.tfstate)
    env.tf                     the only .tf file that differs between envs (local.env)
    backend.hcl.example        S3 + DynamoDB remote state (copy to backend.hcl, gitignored)
    terraform.tfvars.example   every per-env value as a placeholder (copy to terraform.tfvars)
    tests/                     (dev) offline plan of the whole env with the mock provider
  stacks/agent-runtime/        root stack per agent per env (state aig/<env>/agents/<id>.tfstate)
  modules/
    environment/               composes everything below for one env
    network/                   VPC, subnets, NAT, VPC endpoints, egress allow-list, flow logs
    secrets/                   KMS key, Secrets Manager aig/<env>/<name> (placeholders only)
    ecr/                       repositories: immutable tags, scan on push, KMS, lifecycle
    agentcore-runtime/         one AgentCore runtime + endpoint + role + secret + log group
    platform-services/         ECS cluster + 4 services, ALBs, RDS Postgres, scheduled reconcile
    workspaces/                Phase 6: workspace task definitions (per team), orchestrator, relay ALB, Teams bot
    observability/             SNS alarm topic, ECS/ALB/RDS alarms, reconcile-failure rule, workspace alarms
  scripts/validate.sh          offline: fmt -check, init -backend=false, validate, test
```

The env roots are identical apart from `env.tf`, and `scripts/validate.sh` fails if they drift.
Per-env differences live in `terraform.tfvars`.

## Modules

### network
- VPC with one private and one public subnet per AZ (two AZs minimum). NAT is one per AZ, or one
  per VPC with `single_nat_gateway` for dev. The default security group has no rules.
- Interface VPC endpoints for `ecr.api`, `ecr.dkr`, `logs`, `secretsmanager`, `sts`, `kms`,
  `monitoring`, `xray` and `ssm`, plus an S3 gateway endpoint (ECR image layers). AWS API calls
  never leave the VPC.
- **Egress allow-list (default deny)**:
  - `aws_ec2_managed_prefix_list.egress_allow` holds `portkey_egress_cidrs` and
    `fiddler_egress_cidrs` (plus optional `additional_egress_cidrs`, e.g. a corporate egress proxy).
    `0.0.0.0/0` is refused by validation.
  - The `egress-allowlist` security group is attached to every AgentCore runtime and ECS service.
    The Phase 6 workspace tasks get their own, stricter group instead (see [workspaces](#workspaces)). It
    allows HTTPS only to that prefix list, to the VPC endpoint security group and to the S3 prefix
    list. It has no other egress rule, so nothing else can leave.
  - `egress_mode = "firewall"` (recommended for prod) adds AWS Network Firewall on the NAT path.
    It runs a domain allow-list (TLS SNI and HTTP Host, `egress_allowed_domains`) with
    `aws:drop_established` as the default action. Only the `internet-via-firewall` group may send
    HTTPS to `0.0.0.0/0`. That group is attached to the platform services that need FQDN
    destinations (Entra ID JWKS, provider APIs behind Portkey, Slack/PagerDuty), and never to agents.
- **Phase 6 workspaces** (only when the env sets `workspaces`):
  - a separate `workspace-egress-allow` prefix list (`workspace_egress_cidrs`: GitHub / GHES and
    the package mirror) that only the workspace task security group uses, so agents and platform
    services still cannot reach GitHub
  - `workspace_egress_domains` added to the firewall domain list (`github.com`, `api.github.com`,
    Bot Framework hosts)
  - an `ecs` interface endpoint (`extra_interface_endpoints`) for the orchestrator's `ecs:RunTask`
- VPC flow logs (ALL) go to a KMS-encrypted log group.

### secrets
- One customer-managed KMS key per env (`alias/aig-<env>`, rotation on). Its key policy covers
  CloudWatch Logs and the encrypted SNS alarm topic.
- Secrets `aig/<env>/platform-api` (the key broker, read by platform-api itself with
  `AIG_SECRET_PROVIDER=aws`), `aig/<env>/telemetry-bridge` (injected by ECS) and
  `aig/<env>/deploy-pipeline` (`PLATFORM_SERVICE_TOKEN` for the deploy workflow's agent
  auto-registration; the GitHub deploy role reads only this one). Each is created
  with a placeholder JSON version (`"__REPLACE_ME_<KEY>_<ENV>__"`) and
  `ignore_changes = [secret_string]`, so Terraform state never holds a real value and a later apply
  never overwrites one that was uploaded by hand.
- `additional_secrets` (same rules) carries the Phase 6 secrets that the environment adds when
  `workspaces` is set:
  - `aig/<env>/workspace-orchestrator`: `AIG_PLATFORM_SERVICE_TOKEN`, `AIG_WS_RELAY_SECRET`,
    `AIG_WS_NOTIFY_SECRET`
  - `aig/<env>/teams-bot`: `MicrosoftAppId`, `MicrosoftAppPassword`, `AIG_BOT_NOTIFY_SECRET`
  - `aig/<env>/workspaces/shared`: `fiddler_api_key`, `github_app_private_key`
  - `aig/<env>/workspaces/<team>`: `portkey_api_key`

### ecr
`aig/platform-api`, `aig/telemetry-bridge`, `aig/cache-compress`, `aig/web`, the Phase 6
`aig/workspace`, `aig/workspace-orchestrator` and `aig/teams-bot`, and `aig/agents/<agent_id>`. Each repository has immutable tags, scan on push, KMS encryption, expiry
of untagged images, and optional cross-account pull (`ecr_pull_account_ids`) so stage and prod can
run the digest that was built once.

### agentcore-runtime
- `image_uri` must be an ECR reference pinned by digest. Tags are refused.
- VPC network mode in the private subnets, with the egress allow-list group. HTTP protocol.
  Session lifecycle limits. An optional inbound JWT authorizer (Entra ID).
- The runtime gets the non-secret `AIG_*` environment from `backend/contracts/env-vars.md`
  (`AIG_HOST=agentcore`, `AIG_ENV`, `AIG_AGENT_ID`, `AIG_TEAM`, the Portkey/Fiddler/platform-api
  URLs, ...). For secrets it gets **only** `AIG_RUNTIME_SECRET_ARN`: the secret
  `aig/<env>/agents/<agent_id>` holds `AIG_PORTKEY_API_KEY`, `AIG_FIDDLER_API_KEY` and
  `AIG_PLATFORM_API_TOKEN` (placeholders until uploaded). The image entrypoint
  (`infra/ci/docker/agentcore_shim.py` / `agentcore-shim.mjs`) reads the secret at start, then calls the
  SDK's fail-closed `init()`.
- The least-privilege role may pull from this agent's repository only, write its logs, traces and
  `bedrock-agentcore` metrics, get its workload token, and read and decrypt its own secret. It has
  no `bedrock:InvokeModel`: models are reached only through Portkey.
- A runtime endpoint (`live`) is pinned to the runtime version produced by the apply. Its log group
  is created with retention and KMS.
- Agent registry: runtime and endpoint are tagged `aig:registered=true` (`registry_invocable`,
  default `true`) so platform-api's task role may invoke them, and the three `aig-http/1` headers
  `X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller|Invocation-Id|Trace-Id` are allow-listed
  (`request_header_configuration`). The deploy workflow then registers the version with platform-api
  (`docs/deploy.md`, "Auto-registration").

### platform-services
- An ECS Fargate (ARM64) cluster with `platform-api`, `telemetry-bridge`, `cache-compress` and
  `web`. Every container runs non-root with a read-only root filesystem, all capabilities dropped
  and an init process. A `prepare` init container writes each env's config into task volumes, so
  the **same image digest runs in every env**:
  - platform-api: `config/environments/<env>.yaml` (from `platform_api_config`) and an optional
    `users.yaml`
  - web: `config.json` (from `web_config`)
- **platform-api wiring**: `AIG_ENV`, `AIG_SECRET_PROVIDER=aws`, `AIG_AUTH_MODE=oidc`,
  `AIG_PUBLIC_BASE_URL=https://<api host>`, `FORWARDED_ALLOW_IPS` = the ALB subnet CIDRs (never `*`),
  `AIG_DB_AUTO_MIGRATE=false`, `AIG_TELEMETRY_BRIDGE_URL`.
  - `AIG_DATABASE_URL` is built at start from the RDS-managed master secret: ECS injects
    `AIG_DB_USERNAME`/`AIG_DB_PASSWORD`, and a small Python launcher URL-encodes them and execs uvicorn.
  - Its task role may read `aig/<env>/platform-api`, and (agent invocation, `agent_invocation_enabled`,
    default `true`) call `bedrock-agentcore:InvokeAgentRuntime` only on this account/region's runtimes
    (and endpoints) tagged `aig:registered=true` and `aig:env=<env>`, and read
    `aig/<env>/agents/*/invoke-auth` (HTTPS agents' credentials), never the agents' runtime secrets.
    Tested in `modules/platform-services/tests` (no wildcard actions/resources, no model access).
- **Migrations**: the `platform-api-migrate` task definition runs `aig-platform-api db upgrade`.
  `deploy-platform-env.yml` runs it as a one-off task and requires exit 0 before rolling out.
- **ALBs** (TLS 1.2/1.3 policy, ACM `certificate_arn`, HTTP to HTTPS redirect, invalid headers dropped):
  - public (internal by default) for web and api
  - internal for telemetry-bridge and cache-compress (Portkey CIDRs are allowed in)
  - Target groups check `/healthz`
- **RDS Postgres 16**: private, encrypted with the env key, `rds.force_ssl=1`. The master password
  is managed by RDS in Secrets Manager. Multi-AZ, deletion protection, backups and Performance
  Insights are all configurable. platform-api and telemetry-bridge share the database (the
  bridge's tables are prefixed `bridge_`).
- Services use CPU target-tracking autoscaling, a deployment circuit breaker with rollback, and
  `wait_for_steady_state`.
- **Daily `telemetry-bridge reconcile`**: an EventBridge Scheduler ECS task at
  `cron(30 1 * * ? *)` UTC. `reconcile_dry_run` makes it report-only for the first rollout.
- **Daily `aig-platform-api invocations purge`**: an EventBridge Scheduler ECS task at
  `cron(30 3 * * ? *)` UTC (`invocation_purge_schedule`) that runs the platform-api task with only the
  command changed. It deletes invocation metadata older than `agent_invocation_retention_days` (90)
  and background outputs older than `agent_output_retention_days` (30; must be <= the first).
  `invocation_purge_enabled = false` removes it.

### workspaces
Phase 6 team workspaces ([docs/workspaces.md](../../docs/workspaces.md),
`backend/workspace-orchestrator`, `backend/teams-bot`, `infra/ci/docker/workspace.Dockerfile`). It is
created when the env sets `workspaces`, `workspace_images` and `platform_images`. It needs the
platform's portal/API ALB.

```
Teams --443--> portal/API ALB, host teams_bot_hostname: /api/messages, /healthz -> teams-bot
                                                        /api/notify            -> 403
orchestrator (1 task) --443--> platform-api (portal/API ALB, service token)
             --ecs:RunTask--> workspace task (family aig-<env>-workspace-<team>)
             --3978, HMAC--> teams-bot.workspaces.aig-<env>.internal/api/notify (Cloud Map)
workspace task --443--> relay ALB (internal, HTTPS, ingress from the workspace SG only) -> relay :8090
               --443--> Portkey + Fiddler (egress prefix list), GitHub + package mirror
                        (workspace prefix list), VPC endpoints, S3. Nothing else, no ingress
```

- **Cluster** `aig-<env>-workspaces` (Fargate + Fargate Spot, Container Insights enhanced).
- **Workspace task definitions**: a base family `aig-<env>-workspace` with no Portkey key (a team
  without its own definition fails closed), plus one family per team
  (`aig-<env>-workspace-<team>`). The orchestrator gets the families as
  `AIG_WS_ECS_TEAM_TASK_DEFINITIONS`, so it never registers task definitions. Each is:
  - X86_64 (the image is linux/amd64), uid 10001, read-only root filesystem, all capabilities
    dropped, tini as PID 1 (no second init)
  - task volumes `/workspace`, `/home/aig` and `/tmp` on the ephemeral storage (default 50 GiB),
    made writable by a `prepare` init container
  - CPU, memory and storage from variables (2 vCPU / 8 GiB by default; sizing is an open item)
  - logs to `/aig/<env>/workspaces` with stream prefix `workspace` and container `workspace`, which
    is exactly what the orchestrator's CloudWatch links expect
  - secrets: `AIG_PORTKEY_API_KEY` (the team's own), `AIG_FIDDLER_API_KEY` and
    `GITHUB_APP_PRIVATE_KEY`. Static environment: `HOME`, `TMPDIR`, `AIG_WS_WORKDIR`. The
    per-workspace values come as RunTask overrides
- **IAM**:
  - workspace task role: deny-all
  - workspace execution role, one per team: pull `aig/workspace`, write the workspace log group,
    read that team's secret and `workspaces/shared`, and nothing else
  - orchestrator task role:
    - `ecs:RunTask` on the workspace families only (condition `ecs:cluster`)
    - `ecs:StopTask`, `ecs:DescribeTasks` and `ecs:TagResource` (only when the create action is
      `RunTask`) on tasks in that cluster
    - `ecs:ListTasks` (cluster condition)
    - `iam:PassRole` on the workspace roles only (to `ecs-tasks`)
  - orchestrator and bot execution roles: their image, their log group, their own secret. The
    bot's task role has no policy
- **Orchestrator** ECS service, ARM64, desired count 1. Deployment max 100 % / min 0 % means two
  orchestrators never run at once (the single active instance the README requires). Running
  workspaces are adopted on restart (`AIG_WS_RECOVER`). Its environment follows the README:
  - `AIG_WS_RUNNER=ecs`, the `AIG_WS_ECS_*` cluster, subnets, workspace SG and log settings
  - `AIG_WS_RELAY_PUBLIC_URL=https://<relay_hostname>`
  - `AIG_WS_NOTIFY_URLS` (the bot's Cloud Map name)
  - `AIG_PORTKEY_BASE_URL` and `AIG_FIDDLER_URL`
  - anything in `orchestrator_environment` (GitHub App id/installation, Fiddler project, limits)
  - its secrets from `aig/<env>/workspace-orchestrator`
- **Relay**: an internal ALB with an HTTPS listener (`certificate_arn` must cover
  `relay_hostname`). It forwards only `/relay/v1/*` and `/healthz` to port 8090, and accepts
  connections from the workspace SG only.
- **Teams bot** ECS service, ARM64, 1 replica (conversation references live in a task-local
  file), behind the portal/API ALB on `teams_bot_hostname`:
  - Only `/api/messages` and `/healthz` are forwarded. A higher-priority rule answers 403 on
    `/api/notify`
  - Bot SG ingress: the ALB and the orchestrator only
  - Environment: `AIG_BOT_AUTH_MODE=oauth`, `AIG_BOT_OAUTH_CONNECTION`, `MicrosoftAppType`,
    `MicrosoftAppTenantId` and `AIG_WEB_URL`; secrets from `aig/<env>/teams-bot`
  - Teams must reach the ALB: set `alb_internal = false` (with `teams_bot_ingress_cidrs` for the
    Bot Framework ranges) or put a corporate reverse proxy in front of it
  - The bot's own egress (Bot Framework, Entra ID) needs firewall mode or an egress proxy

### observability
One KMS-encrypted SNS topic per env (optional email subscriptions) with these alarms:
- ECS CPU and memory
- ALB target 5xx and unhealthy targets (the `/healthz` failures)
- RDS CPU and free storage
- EventBridge rules for a reconcile or invocation purge task that stops with a non-zero exit code
- workspaces (`workspaces.tf`, when enabled):
  - `<service>-down`: no running orchestrator or bot task for 3 minutes (Container Insights
    `RunningTaskCount`)
  - `workspaces-failed`: more than `failed_alarm_per_hour` failed workspaces in an hour. A log
    metric filter on the orchestrator log counts `-> failed` and `reported failed`

## Bootstrap order (per account/env)

1. Create the state bucket (versioned, SSE-KMS, public access blocked) and the DynamoDB lock
   table, outside these stacks.
2. Create the GitHub OIDC deploy roles (`AWS_DEPLOY_ROLE_ARN` per env, `AWS_ECR_PUSH_ROLE_ARN`).
   They trust `token.actions.githubusercontent.com` for this repo and environment only.
3. `cd envs/<env> && cp backend.hcl.example backend.hcl && cp terraform.tfvars.example terraform.tfvars`
   and fill both in.
4. `terraform init -backend-config=backend.hcl && terraform apply` with `platform_images` unset.
   This creates the network, KMS, secrets, ECR and the SSM parameter for agent stacks.
5. Upload the real secret values by hand (`docs/deploy.md`, "Secrets upload").
6. Run `deploy-platform.yml`, then `deploy-agent.yml` per agent.
7. Phase 6 workspaces: set `workspaces` in the env's tfvars (teams, relay/bot hosts, GitHub CIDRs)
   and apply. This creates the workspace secrets, the GitHub prefix list and the ECS endpoint.
   Upload the workspace secrets, create the DNS records, then run `deploy-platform.yml`. It passes
   `workspace_images`, which creates the cluster, task definitions and services. Until the
   orchestrator secret is uploaded, the orchestrator fails closed and the rollout does not
   stabilise.

## Offline validation

```bash
make tools            # pinned terraform 1.9.8 + actionlint into .tools/ (checksum verified)
make infra-validate   # fmt -check, init -backend=false, validate (all roots), terraform test (mock provider)
make infra-fmt        # rewrite formatting
```

The `terraform test` files (`modules/{network,agentcore-runtime,platform-services,workspaces}/tests`,
`envs/dev/tests`) plan against `mock_provider "aws"` (20 runs). They check that:
- egress allows only Portkey, Fiddler and the endpoints, and refuses `0.0.0.0/0`
- firewall mode drops by default
- AgentCore runtimes take digests only, run in VPC mode, have every required `AIG_*` name and no
  secret in their environment
- platform-api's public URL, proxy trust and DB launcher are wired, every target group checks
  `/healthz`, RDS is private and encrypted with a managed password, and reconcile runs daily
- the env plans both without and with images, and with workspaces (secrets only at bootstrap, the
  whole stack once the images are set)
- workspaces:
  - the workspace SG egress has no CIDR rule (so no `0.0.0.0/0`) and only reaches
    Portkey/Fiddler, GitHub/mirror, S3, the VPC endpoints and the relay
  - GitHub CIDRs never enter the shared prefix list, and `0.0.0.0/0` is refused there too
  - no task environment carries a key/token/secret/password variable, and every secret is a
    Secrets Manager `valueFrom`
  - each team's task definition holds only that team's Portkey key
  - the orchestrator can run only the workspace task definition families: no wildcard actions, no
    `RegisterTaskDefinition`, PassRole limited to ECS tasks
  - `/api/notify` answers 403 on the public listener ahead of the forward rule, and the bot accepts
    traffic only from the ALB and the orchestrator SGs
