variable "env" {
  description = "dev, stage or prod."
  type        = string
  validation {
    condition     = contains(["dev", "stage", "prod"], var.env)
    error_message = "env must be dev, stage or prod."
  }
}

# --- Network ----------------------------------------------------------------------------------
variable "vpc_cidr" {
  type = string
}

variable "azs" {
  type = list(string)
}

variable "private_subnet_cidrs" {
  type = list(string)
}

variable "public_subnet_cidrs" {
  type = list(string)
}

variable "firewall_subnet_cidrs" {
  type    = list(string)
  default = []
}

variable "single_nat_gateway" {
  type    = bool
  default = false
}

variable "egress_mode" {
  description = "\"cidr\" or \"firewall\" (see modules/network)."
  type        = string
  default     = "cidr"
}

variable "portkey_egress_cidrs" {
  type = list(string)
}

variable "fiddler_egress_cidrs" {
  type = list(string)
}

variable "additional_egress_cidrs" {
  type = list(object({
    cidr        = string
    description = string
  }))
  default = []
}

variable "egress_allowed_domains" {
  type    = list(string)
  default = []
}

# --- Endpoints shared by agents and services --------------------------------------------------
variable "portkey_base_url" {
  description = "Self-hosted Portkey gateway, e.g. https://portkey.<corp>/v1 (AIG_PORTKEY_BASE_URL for agents)."
  type        = string
}

variable "portkey_mcp_url" {
  type    = string
  default = null
}

variable "fiddler_url" {
  type = string
}

# --- Registries -------------------------------------------------------------------------------
variable "agent_ids" {
  description = "Agents deployed to AgentCore in this account: one ECR repository aig/agents/<id> each."
  type        = list(string)
  default     = []
}

variable "ecr_pull_account_ids" {
  description = "Accounts allowed to pull (stage/prod when the registry lives in a shared/dev account)."
  type        = list(string)
  default     = []
}

variable "create_ecr" {
  description = "Create the ECR repositories in this env (true for the account that owns the registry)."
  type        = bool
  default     = true
}

# --- Platform services ------------------------------------------------------------------------
variable "platform_images" {
  description = "Image digests for the platform services. null = do not create the ECS services yet (first apply: network, secrets, ECR only)."
  type = object({
    platform_api     = string
    telemetry_bridge = string
    cache_compress   = string
    web              = string
  })
  default = null
}

variable "certificate_arn" {
  type = string
}

variable "hostnames" {
  type = object({
    web            = string
    api            = string
    bridge         = string
    cache_compress = string
  })
}

variable "alb_internal" {
  type    = bool
  default = true
}

variable "alb_ingress_cidrs" {
  type = list(string)
}

variable "platform_api_config" {
  type = any
}

variable "platform_api_users_yaml" {
  type    = string
  default = null
}

variable "platform_api_environment" {
  type    = map(string)
  default = {}
}

variable "telemetry_bridge_environment" {
  type    = map(string)
  default = {}
}

variable "cache_compress_upstreams" {
  type = map(string)
}

variable "web_config" {
  type = any
}

variable "service_sizing" {
  type = map(object({
    cpu     = number
    memory  = number
    desired = number
    min     = number
    max     = number
  }))
  default = null
}

variable "db_instance_class" {
  type    = string
  default = "db.t4g.medium"
}

variable "db_multi_az" {
  type    = bool
  default = true
}

variable "deletion_protection" {
  description = "RDS + ALB deletion protection."
  type        = bool
  default     = true
}

variable "reconcile_dry_run" {
  type    = bool
  default = false
}

variable "invocation_purge_enabled" {
  description = "Daily `aig-platform-api invocations purge` scheduled task (modules/platform-services)."
  type        = bool
  default     = true
}

variable "agent_invocation_retention_days" {
  description = "Invocation metadata retention in days (AIG_AGENT_INVOCATION_RETENTION_DAYS, >= 1)."
  type        = number
  default     = 90
}

variable "agent_output_retention_days" {
  description = "Background invocation output retention in days (AIG_AGENT_OUTPUT_RETENTION_DAYS, >= 1, <= agent_invocation_retention_days)."
  type        = number
  default     = 30
}

# --- Phase 6 team workspaces (modules/workspaces) ---------------------------------------------
variable "workspaces" {
  description = <<-EOT
    Team workspaces (backend/workspace-orchestrator, backend/teams-bot). null = not deployed in this
    env. Setting it creates the secrets (aig/<env>/workspace-orchestrator, aig/<env>/teams-bot,
    aig/<env>/workspaces/shared, aig/<env>/workspaces/<team>), the GitHub egress prefix list and the
    ECS VPC endpoint; the ECS services follow once workspace_images (and platform_images) are set.
  EOT
  type = object({
    teams                           = list(string) # one task definition + Portkey key secret per team
    relay_hostname                  = string       # internal relay ALB host (certificate_arn must cover it)
    github_egress_cidrs             = list(string) # GitHub "git"/"api" ranges (api.github.com/meta) or the GHES CIDR
    package_mirror_egress_cidrs     = optional(list(string), [])
    egress_domains                  = optional(list(string), ["github.com", "api.github.com"]) # firewall mode
    orchestrator_environment        = optional(map(string), {})
    workspace_cpu                   = optional(number, 2048) # open item: sizing
    workspace_memory                = optional(number, 8192) # open item: sizing
    workspace_ephemeral_storage_gib = optional(number, 50)
    use_fargate_spot                = optional(bool, false)
    failed_alarm_per_hour           = optional(number, 3)
    teams_bot_enabled               = optional(bool, true)
    teams_bot_hostname              = optional(string) # on the portal/API ALB (certificate_arn must cover it)
    teams_bot_ingress_cidrs         = optional(list(string), [])
    teams_bot_oauth_connection      = optional(string, "aig-platform")
    teams_bot_app_type              = optional(string, "SingleTenant")
    teams_bot_tenant_id             = optional(string)
    teams_bot_environment           = optional(map(string), {})
    teams_bot_egress_domains = optional(list(string), [
      "login.microsoftonline.com", "login.botframework.com", "api.botframework.com",
      "token.botframework.com", "smba.trafficmanager.net",
    ]) # firewall mode
  })
  default = null
  validation {
    condition     = var.workspaces == null ? true : (length(var.workspaces.teams) > 0 && length(var.workspaces.github_egress_cidrs) > 0)
    error_message = "workspaces needs at least one team and the GitHub egress CIDRs."
  }
}

variable "workspace_images" {
  description = "Workspace, orchestrator and Teams bot images by digest (set by deploy-platform.yml). null = no workspace ECS resources yet."
  type = object({
    workspace    = string
    orchestrator = string
    teams_bot    = string
  })
  default = null
}

variable "alarm_emails" {
  type    = list(string)
  default = []
}

variable "log_retention_days" {
  type    = number
  default = 90
}

variable "tags" {
  type    = map(string)
  default = {}
}
