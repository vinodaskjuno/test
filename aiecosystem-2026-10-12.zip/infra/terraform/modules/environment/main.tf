# One AIG environment (dev, stage or prod): network with the egress allow-list, KMS + secrets,
# ECR, the platform services on ECS Fargate, the Phase 6 team workspaces (optional) and basic
# alarms. Agent runtimes are separate root stacks (infra/terraform/stacks/agent-runtime) that read
# this env's outputs from SSM.

locals {
  name = "aig-${var.env}"
  tags = merge(var.tags, { "aig:env" = var.env, "aig:managed-by" = "terraform" })
  # Phase 6 images (workspace, workspace-orchestrator, teams-bot) are built by deploy-platform.yml
  # in every run, so their repositories exist even where workspaces are not enabled.
  platform_repos = ["platform-api", "telemetry-bridge", "cache-compress", "web", "workspace", "workspace-orchestrator", "teams-bot"]

  # Phase 6 team workspaces. Secrets, ECR, the GitHub prefix list and the ECS endpoint exist as
  # soon as `workspaces` is set (so values can be uploaded before the first rollout); the ECS
  # resources need the platform (its ALB) and the workspace images as well.
  ws_configured = var.workspaces != null
  ws_enabled    = local.ws_configured && var.workspace_images != null && var.platform_images != null
  ws_bot        = local.ws_configured ? var.workspaces.teams_bot_enabled : false
  ws_teams      = local.ws_configured ? toset(var.workspaces.teams) : toset([])

  workspace_secrets = local.ws_configured ? merge(
    {
      "workspace-orchestrator" = {
        description = "AIG workspace-orchestrator (platform service token, relay HMAC key, notification HMAC key)"
        keys        = ["AIG_PLATFORM_SERVICE_TOKEN", "AIG_WS_RELAY_SECRET", "AIG_WS_NOTIFY_SECRET"]
      }
      "workspaces/shared" = {
        description = "AIG workspace tasks, all teams (Fiddler token, GitHub App private key)"
        keys        = ["fiddler_api_key", "github_app_private_key"]
      }
    },
    local.ws_bot ? {
      "teams-bot" = {
        description = "AIG Teams bot (Azure Bot app id/password, notification HMAC key = AIG_WS_NOTIFY_SECRET)"
        keys        = ["MicrosoftAppId", "MicrosoftAppPassword", "AIG_BOT_NOTIFY_SECRET"]
      }
    } : {},
    { for t in local.ws_teams : "workspaces/${t}" => {
      description = "AIG workspace tasks of team ${t} (scoped Portkey workspace key)"
      keys        = ["portkey_api_key"]
    } },
  ) : {}

  workspace_egress_cidrs = local.ws_configured ? concat(
    [for c in var.workspaces.github_egress_cidrs : { cidr = c, description = "Git host (GitHub)" }],
    [for c in var.workspaces.package_mirror_egress_cidrs : { cidr = c, description = "Package mirror" }],
  ) : []
  workspace_egress_domains = local.ws_configured ? distinct(concat(
    var.workspaces.egress_domains,
    local.ws_bot ? var.workspaces.teams_bot_egress_domains : [],
  )) : []
}

module "secrets" {
  source             = "../secrets"
  env                = var.env
  additional_secrets = local.workspace_secrets
  tags               = local.tags
}

module "network" {
  source                  = "../network"
  name                    = local.name
  cidr_block              = var.vpc_cidr
  azs                     = var.azs
  private_subnet_cidrs    = var.private_subnet_cidrs
  public_subnet_cidrs     = var.public_subnet_cidrs
  firewall_subnet_cidrs   = var.firewall_subnet_cidrs
  single_nat_gateway      = var.single_nat_gateway
  egress_mode             = var.egress_mode
  portkey_egress_cidrs    = var.portkey_egress_cidrs
  fiddler_egress_cidrs    = var.fiddler_egress_cidrs
  additional_egress_cidrs = var.additional_egress_cidrs
  egress_allowed_domains  = var.egress_allowed_domains
  kms_key_arn             = module.secrets.kms_key_arn

  workspace_egress_cidrs    = local.workspace_egress_cidrs
  workspace_egress_domains  = local.workspace_egress_domains
  extra_interface_endpoints = local.ws_configured ? ["ecs"] : [] # orchestrator: ecs:RunTask
  tags                      = local.tags
}

module "ecr" {
  count            = var.create_ecr ? 1 : 0
  source           = "../ecr"
  repositories     = concat(local.platform_repos, [for a in var.agent_ids : "agents/${a}"])
  kms_key_arn      = module.secrets.kms_key_arn
  pull_account_ids = var.ecr_pull_account_ids
  force_delete     = var.env == "dev"
  tags             = local.tags
}

module "platform" {
  count  = var.platform_images == null ? 0 : 1
  source = "../platform-services"
  env    = var.env
  name   = local.name

  vpc_id                            = module.network.vpc_id
  vpc_cidr                          = module.network.vpc_cidr
  private_subnet_ids                = module.network.private_subnet_ids
  alb_internal                      = var.alb_internal
  alb_subnet_ids                    = var.alb_internal ? module.network.private_subnet_ids : module.network.public_subnet_ids
  alb_subnet_cidrs                  = var.alb_internal ? var.private_subnet_cidrs : var.public_subnet_cidrs
  internal_alb_subnet_cidrs         = var.private_subnet_cidrs
  alb_ingress_cidrs                 = var.alb_ingress_cidrs
  internal_alb_ingress_cidrs        = var.portkey_egress_cidrs
  egress_security_group_ids         = [module.network.egress_allowlist_security_group_id]
  internet_egress_security_group_id = module.network.internet_via_firewall_security_group_id
  certificate_arn                   = var.certificate_arn

  web_hostname            = var.hostnames.web
  api_hostname            = var.hostnames.api
  bridge_hostname         = var.hostnames.bridge
  cache_compress_hostname = var.hostnames.cache_compress

  images                       = var.platform_images
  kms_key_arn                  = module.secrets.kms_key_arn
  platform_api_secret_arn      = module.secrets.secret_arns["platform-api"]
  telemetry_bridge_secret_arn  = module.secrets.secret_arns["telemetry-bridge"]
  telemetry_bridge_secret_keys = module.secrets.secret_keys["telemetry-bridge"]

  platform_api_config          = var.platform_api_config
  platform_api_users_yaml      = var.platform_api_users_yaml
  platform_api_environment     = var.platform_api_environment
  telemetry_bridge_environment = merge({ FIDDLER_URL = var.fiddler_url }, var.telemetry_bridge_environment)
  cache_compress_upstreams     = var.cache_compress_upstreams
  web_config                   = var.web_config
  reconcile_dry_run            = var.reconcile_dry_run

  invocation_purge_enabled        = var.invocation_purge_enabled
  agent_invocation_retention_days = var.agent_invocation_retention_days
  agent_output_retention_days     = var.agent_output_retention_days

  service_sizing         = coalesce(var.service_sizing, local.default_sizing)
  db_instance_class      = var.db_instance_class
  db_multi_az            = var.db_multi_az
  db_deletion_protection = var.deletion_protection
  log_retention_days     = var.log_retention_days
  tags                   = local.tags
}

locals {
  default_sizing = {
    platform_api     = { cpu = 512, memory = 1024, desired = 2, min = 2, max = 6 }
    telemetry_bridge = { cpu = 512, memory = 1024, desired = 1, min = 1, max = 1 }
    cache_compress   = { cpu = 512, memory = 1024, desired = 2, min = 2, max = 6 }
    web              = { cpu = 256, memory = 512, desired = 2, min = 2, max = 4 }
  }
}

module "workspaces" {
  count  = local.ws_enabled ? 1 : 0
  source = "../workspaces"
  env    = var.env
  name   = local.name

  vpc_id                            = module.network.vpc_id
  private_subnet_ids                = module.network.private_subnet_ids
  egress_prefix_list_id             = module.network.egress_prefix_list_id
  workspace_egress_prefix_list_id   = module.network.workspace_egress_prefix_list_id
  vpc_endpoints_security_group_id   = module.network.vpc_endpoints_security_group_id
  s3_prefix_list_id                 = module.network.s3_prefix_list_id
  egress_security_group_ids         = [module.network.egress_allowlist_security_group_id]
  internet_egress_security_group_id = module.network.internet_via_firewall_security_group_id

  platform_api_url               = "https://${var.hostnames.api}"
  platform_alb_security_group_id = module.platform[0].public_alb_security_group_id
  platform_https_listener_arn    = module.platform[0].public_https_listener_arn
  web_url                        = "https://${var.hostnames.web}"
  certificate_arn                = var.certificate_arn
  relay_hostname                 = var.workspaces.relay_hostname

  images                  = var.workspace_images
  kms_key_arn             = module.secrets.kms_key_arn
  team_secret_arns        = { for t in local.ws_teams : t => module.secrets.secret_arns["workspaces/${t}"] }
  shared_secret_arn       = module.secrets.secret_arns["workspaces/shared"]
  orchestrator_secret_arn = module.secrets.secret_arns["workspace-orchestrator"]
  teams_bot_secret_arn    = local.ws_bot ? module.secrets.secret_arns["teams-bot"] : null

  portkey_base_url         = var.portkey_base_url
  fiddler_url              = var.fiddler_url
  orchestrator_environment = var.workspaces.orchestrator_environment

  workspace_cpu                   = var.workspaces.workspace_cpu
  workspace_memory                = var.workspaces.workspace_memory
  workspace_ephemeral_storage_gib = var.workspaces.workspace_ephemeral_storage_gib
  use_fargate_spot                = var.workspaces.use_fargate_spot

  teams_bot_enabled          = local.ws_bot
  teams_bot_hostname         = var.workspaces.teams_bot_hostname
  teams_bot_ingress_cidrs    = var.workspaces.teams_bot_ingress_cidrs
  teams_bot_oauth_connection = var.workspaces.teams_bot_oauth_connection
  teams_bot_app_type         = var.workspaces.teams_bot_app_type
  teams_bot_tenant_id        = var.workspaces.teams_bot_tenant_id
  teams_bot_environment      = var.workspaces.teams_bot_environment

  log_retention_days = var.log_retention_days
  tags               = local.tags
}

module "observability" {
  count                        = var.platform_images == null ? 0 : 1
  source                       = "../observability"
  name                         = local.name
  kms_key_arn                  = module.secrets.kms_key_arn
  alarm_emails                 = var.alarm_emails
  cluster_name                 = module.platform[0].cluster_name
  service_names                = module.platform[0].service_names
  public_alb_arn_suffix        = module.platform[0].public_alb_arn_suffix
  internal_alb_arn_suffix      = module.platform[0].internal_alb_arn_suffix
  target_group_arn_suffixes    = module.platform[0].target_group_arn_suffixes
  db_identifier                = module.platform[0].db_identifier
  reconcile_task_family        = "${local.name}-telemetry-bridge-reconcile"
  invocation_purge_task_family = module.platform[0].invocation_purge_task_family
  workspaces = local.ws_enabled ? {
    cluster_name           = module.workspaces[0].cluster_name
    service_names          = module.workspaces[0].service_names
    orchestrator_log_group = module.workspaces[0].log_group_names["orchestrator"]
    failed_per_hour        = var.workspaces.failed_alarm_per_hour
  } : null
  tags = local.tags
}

# Inputs for the per-agent stacks (stacks/agent-runtime), so they need no access to this state.
resource "aws_ssm_parameter" "agent_runtime_inputs" {
  name        = "/aig/${var.env}/infra/agent-runtime-inputs"
  description = "AIG ${var.env}: network, KMS and endpoint settings for AgentCore agent stacks (non-secret)"
  type        = "String"
  value = jsonencode({
    env                = var.env
    private_subnet_ids = module.network.private_subnet_ids
    security_group_ids = [module.network.egress_allowlist_security_group_id]
    kms_key_arn        = module.secrets.kms_key_arn
    portkey_base_url   = var.portkey_base_url
    portkey_mcp_url    = var.portkey_mcp_url
    fiddler_url        = var.fiddler_url
    platform_api_url   = "https://${var.hostnames.api}"
  })
  tags = local.tags
}
