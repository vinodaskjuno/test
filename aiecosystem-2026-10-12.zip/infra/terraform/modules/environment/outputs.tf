output "vpc_id" {
  value = module.network.vpc_id
}

output "private_subnet_ids" {
  value = module.network.private_subnet_ids
}

output "egress_allowlist_security_group_id" {
  value = module.network.egress_allowlist_security_group_id
}

output "egress_prefix_list_id" {
  value = module.network.egress_prefix_list_id
}

output "kms_key_arn" {
  value = module.secrets.kms_key_arn
}

output "secret_names" {
  description = "Secrets to fill by hand: aws secretsmanager put-secret-value --secret-id <name> (docs/deploy.md)."
  value       = module.secrets.secret_names
}

output "ecr_repository_urls" {
  value = var.create_ecr ? module.ecr[0].repository_urls : {}
}

output "platform" {
  description = "null until platform_images is set."
  value = var.platform_images == null ? null : {
    cluster               = module.platform[0].cluster_name
    services              = module.platform[0].service_names
    migrate_task          = module.platform[0].migrate_task
    public_alb_dns_name   = module.platform[0].public_alb_dns_name
    internal_alb_dns_name = module.platform[0].internal_alb_dns_name
    urls                  = module.platform[0].urls
    db_endpoint           = module.platform[0].db_endpoint
  }
}

output "alarm_topic_arn" {
  value = var.platform_images == null ? null : module.observability[0].alarm_topic_arn
}

output "agent_runtime_inputs_parameter" {
  value = aws_ssm_parameter.agent_runtime_inputs.name
}

output "workspaces" {
  description = "Phase 6 workspaces: null until workspaces, workspace_images and platform_images are set."
  value = local.ws_enabled ? {
    cluster                      = module.workspaces[0].cluster_name
    services                     = module.workspaces[0].service_names
    workspace_task_families      = module.workspaces[0].workspace_task_families
    relay_url                    = module.workspaces[0].relay_url
    relay_alb_dns_name           = module.workspaces[0].relay_alb_dns_name
    teams_bot_messaging_endpoint = module.workspaces[0].teams_bot_messaging_endpoint
    log_groups                   = module.workspaces[0].log_group_names
  } : null
}
