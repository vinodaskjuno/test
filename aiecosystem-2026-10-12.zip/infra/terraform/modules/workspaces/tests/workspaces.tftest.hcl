# Offline plan tests (mock AWS provider, no credentials) for the Phase 6 workspace infrastructure:
# restricted workspace egress, no secret values in any task environment, the orchestrator may only
# run the workspace task definitions, and the bot's /api/notify is never public.
mock_provider "aws" {
  mock_data "aws_region" {
    defaults = { region = "us-east-1" }
  }
  mock_data "aws_caller_identity" {
    defaults = { account_id = "123456789012" }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
}

variables {
  env                             = "dev"
  name                            = "aig-dev"
  vpc_id                          = "vpc-test"
  private_subnet_ids              = ["subnet-a", "subnet-b"]
  egress_prefix_list_id           = "pl-egress"
  workspace_egress_prefix_list_id = "pl-workspace"
  vpc_endpoints_security_group_id = "sg-endpoints"
  s3_prefix_list_id               = "pl-s3"
  egress_security_group_ids       = ["sg-egress-allowlist"]
  platform_api_url                = "https://aig-api-dev.example.com"
  platform_alb_security_group_id  = "sg-alb-public"
  platform_https_listener_arn     = "arn:aws:elasticloadbalancing:us-east-1:123456789012:listener/app/aig-dev-public/abc/def"
  web_url                         = "https://aig-portal-dev.example.com"
  certificate_arn                 = "arn:aws:acm:us-east-1:123456789012:certificate/test"
  relay_hostname                  = "aig-ws-relay-dev.example.com"
  portkey_base_url                = "https://portkey.corp.example.com/v1"
  fiddler_url                     = "https://aig.fiddler.example.com"
  kms_key_arn                     = "arn:aws:kms:us-east-1:123456789012:key/test"
  images = {
    workspace    = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/workspace@sha256:5555555555555555555555555555555555555555555555555555555555555555"
    orchestrator = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/workspace-orchestrator@sha256:6666666666666666666666666666666666666666666666666666666666666666"
    teams_bot    = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/teams-bot@sha256:7777777777777777777777777777777777777777777777777777777777777777"
  }
  team_secret_arns = {
    underwriting = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/workspaces/underwriting-AbCdEf"
    claims       = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/workspaces/claims-AbCdEf"
  }
  shared_secret_arn       = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/workspaces/shared-AbCdEf"
  orchestrator_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/workspace-orchestrator-AbCdEf"
  teams_bot_secret_arn    = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/teams-bot-AbCdEf"
  teams_bot_hostname      = "aig-teams-bot-dev.example.com"
  orchestrator_environment = {
    AIG_FIDDLER_PROJECT = "aig-workspace"
    GITHUB_APP_ID       = "123456"
  }
}

run "workspace_egress_is_an_allow_list" {
  command = plan

  assert {
    condition     = alltrue([for r in aws_vpc_security_group_egress_rule.workspace : r.cidr_ipv4 == null && r.cidr_ipv6 == null])
    error_message = "workspace egress must go to prefix lists / security groups only, never to a CIDR (no 0.0.0.0/0)"
  }
  assert {
    condition     = alltrue([for r in aws_vpc_security_group_egress_rule.workspace : r.ip_protocol == "tcp" && r.from_port == 443 && r.to_port == 443])
    error_message = "workspace egress is HTTPS only"
  }
  assert {
    condition     = toset(keys(aws_vpc_security_group_egress_rule.workspace)) == toset(["portkey_fiddler", "git_and_mirror", "s3_gateway", "vpc_endpoints", "relay"])
    error_message = "workspace egress: Portkey/Fiddler, GitHub/mirror, S3, VPC endpoints and the relay, nothing else"
  }
  assert {
    condition     = aws_vpc_security_group_egress_rule.workspace["git_and_mirror"].prefix_list_id == "pl-workspace" && aws_vpc_security_group_egress_rule.workspace["portkey_fiddler"].prefix_list_id == "pl-egress"
    error_message = "GitHub goes through the workspace prefix list, Portkey/Fiddler through the shared one"
  }
  assert {
    condition     = aws_lb.relay.internal && aws_lb_listener.relay.protocol == "HTTPS"
    error_message = "the relay is internal and TLS-terminated"
  }
}

run "no_secret_values_in_task_environments" {
  command = plan

  assert {
    condition = alltrue(flatten([
      for c in concat(flatten(values(local.workspace_containers)), [local.orchestrator_container, local.teams_bot_prepare, local.teams_bot_container]) : [
        for e in c.environment : !can(regex(local.secret_regex, e.name))
      ]
    ]))
    error_message = "no key/token/secret/password variable may be in a container environment"
  }
  assert {
    condition = alltrue(flatten([
      for c in concat(flatten(values(local.workspace_containers)), [local.orchestrator_container, local.teams_bot_container]) : [
        for s in try(c.secrets, []) : startswith(s.valueFrom, "arn:aws:secretsmanager:")
      ]
    ]))
    error_message = "every secret is a Secrets Manager reference (valueFrom), never a value"
  }
  assert {
    condition     = [for s in local.workspace_secrets["underwriting"] : s.valueFrom if s.name == "AIG_PORTKEY_API_KEY"] == ["arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/workspaces/underwriting-AbCdEf:portkey_api_key::"]
    error_message = "a team's task definition carries only that team's Portkey key"
  }
  assert {
    condition     = length([for s in local.workspace_secrets["_base"] : s if s.name == "AIG_PORTKEY_API_KEY"]) == 0
    error_message = "the base task definition has no Portkey key (unknown teams fail closed)"
  }
  assert {
    condition     = toset([for s in local.orchestrator_secrets : s.name]) == toset(["AIG_PLATFORM_SERVICE_TOKEN", "AIG_WS_RELAY_SECRET", "AIG_WS_NOTIFY_SECRET"])
    error_message = "the orchestrator gets its three secrets from aig/<env>/workspace-orchestrator"
  }
  assert {
    condition     = alltrue([for c in flatten(values(local.workspace_containers)) : c.readonlyRootFilesystem && !c.privileged]) && alltrue([for k, v in local.workspace_containers : v[1].user == "10001"])
    error_message = "workspace containers: non-root (10001), read-only root filesystem"
  }
  assert {
    condition     = alltrue([for t in aws_ecs_task_definition.workspace : t.runtime_platform[0].cpu_architecture == "X86_64" && t.ephemeral_storage[0].size_in_gib == 50])
    error_message = "workspace tasks run X86_64 (linux/amd64 image) with 50 GiB ephemeral storage"
  }
  assert {
    condition     = local.orchestrator_environment["AIG_WS_ECS_LOG_GROUP"] == "/aig/dev/workspaces" && local.log_config["workspaces"].options["awslogs-stream-prefix"] == "workspace" && local.workspace_container == "workspace"
    error_message = "log group / stream prefix / container must match the orchestrator's CloudWatch links"
  }
  assert {
    condition     = jsondecode(local.orchestrator_environment["AIG_WS_ECS_TEAM_TASK_DEFINITIONS"]) == { underwriting = "aig-dev-workspace-underwriting", claims = "aig-dev-workspace-claims" }
    error_message = "the orchestrator maps every team to its own task definition"
  }
  assert {
    condition     = local.orchestrator_environment["AIG_WS_RELAY_PUBLIC_URL"] == "https://aig-ws-relay-dev.example.com" && local.orchestrator_environment["AIG_WS_NOTIFY_URLS"] == "http://teams-bot.workspaces.aig-dev.internal:3978/api/notify"
    error_message = "relay over the internal HTTPS ALB, notifications over the private name"
  }
  assert {
    condition     = aws_ecs_service.orchestrator.desired_count == 1 && aws_ecs_service.orchestrator.deployment_maximum_percent == 100
    error_message = "exactly one orchestrator runs at any time"
  }
}

run "orchestrator_can_only_run_workspace_tasks" {
  command = plan

  assert {
    condition = local.orchestrator_run_task_resources == sort([
      "arn:aws:ecs:us-east-1:123456789012:task-definition/aig-dev-workspace:*",
      "arn:aws:ecs:us-east-1:123456789012:task-definition/aig-dev-workspace-claims:*",
      "arn:aws:ecs:us-east-1:123456789012:task-definition/aig-dev-workspace-underwriting:*",
    ])
    error_message = "ecs:RunTask is limited to the workspace task definition families"
  }
  assert {
    condition     = length([for s in local.orchestrator_task_statements : s if contains(s.Action, "ecs:RunTask")]) == 1
    error_message = "only one statement grants ecs:RunTask"
  }
  assert {
    condition     = alltrue([for s in local.orchestrator_task_statements : s.Effect == "Allow" && !contains(s.Action, "*") && !contains(s.Action, "ecs:*") && !contains(s.Action, "ecs:RegisterTaskDefinition")])
    error_message = "no wildcard actions and no RegisterTaskDefinition"
  }
  assert {
    condition     = alltrue([for r in flatten([for s in local.orchestrator_task_statements : s.Resource if s.Sid != "ListWorkspaceTasks" && s.Sid != "PassWorkspaceRoles"]) : r != "*"])
    error_message = "only ecs:ListTasks (no task-level resource) may use Resource *, and only with the cluster condition"
  }
  assert {
    condition     = length(one([for s in local.orchestrator_task_statements : s.Resource if s.Sid == "PassWorkspaceRoles"])) == 4
    error_message = "iam:PassRole covers exactly the workspace task role and the three workspace execution roles"
  }
  assert {
    condition     = one([for s in local.orchestrator_task_statements : s.Condition.StringEquals["iam:PassedToService"] if contains(s.Action, "iam:PassRole")]) == "ecs-tasks.amazonaws.com"
    error_message = "iam:PassRole is limited to ECS tasks"
  }
}

run "bot_notify_is_not_public" {
  command = plan

  assert {
    condition     = aws_lb_listener_rule.teams_bot_notify_deny[0].action[0].type == "fixed-response" && aws_lb_listener_rule.teams_bot_notify_deny[0].action[0].fixed_response[0].status_code == "403"
    error_message = "the public listener answers 403 on /api/notify"
  }
  assert {
    condition     = aws_lb_listener_rule.teams_bot_notify_deny[0].priority < aws_lb_listener_rule.teams_bot[0].priority
    error_message = "the /api/notify deny rule is evaluated before the bot forward rule"
  }
  assert {
    condition     = contains(flatten([for c in aws_lb_listener_rule.teams_bot_notify_deny[0].condition : try(tolist(c.path_pattern[0].values), [])]), "/api/notify")
    error_message = "the deny rule matches /api/notify"
  }
  assert {
    condition     = !anytrue([for p in flatten([for c in aws_lb_listener_rule.teams_bot[0].condition : try(tolist(c.path_pattern[0].values), [])]) : startswith(p, "/api/notify") || p == "/*" || p == "*"])
    error_message = "the public forward rule never covers /api/notify"
  }
  assert {
    condition     = alltrue([for r in aws_vpc_security_group_ingress_rule.teams_bot : r.cidr_ipv4 == null]) && toset(keys(aws_vpc_security_group_ingress_rule.teams_bot)) == toset(["platform_alb", "orchestrator"])
    error_message = "the bot accepts traffic only from the portal/API ALB and the orchestrator security groups"
  }
}

run "refuses_image_tags" {
  command = plan
  variables {
    images = {
      workspace    = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/workspace:latest"
      orchestrator = "x@sha256:6666666666666666666666666666666666666666666666666666666666666666"
      teams_bot    = "x@sha256:7777777777777777777777777777777777777777777777777777777777777777"
    }
  }
  expect_failures = [var.images]
}

run "refuses_invalid_team_name" {
  command = plan
  variables {
    team_secret_arns = { shared = "arn:aws:secretsmanager:us-east-1:123456789012:secret:x" }
  }
  expect_failures = [var.team_secret_arns]
}
