variable "env" {
  description = "dev, stage or prod (AIG_ENV of the orchestrator and the bot; aig/<env>/... secrets)."
  type        = string
  validation {
    condition     = contains(["dev", "stage", "prod"], var.env)
    error_message = "env must be dev, stage or prod."
  }
}

variable "name" {
  description = "Name prefix, e.g. aig-dev."
  type        = string
}

# --- Network ----------------------------------------------------------------------------------
variable "vpc_id" {
  type = string
}

variable "private_subnet_ids" {
  description = "Private subnets (no public IP) for the workspace tasks, the orchestrator, the bot and the relay ALB."
  type        = list(string)
}

variable "egress_prefix_list_id" {
  description = "Network module egress prefix list (Portkey + Fiddler CIDRs)."
  type        = string
}

variable "workspace_egress_prefix_list_id" {
  description = "Network module workspace prefix list (GitHub / GHES and the package mirror CIDRs)."
  type        = string
}

variable "vpc_endpoints_security_group_id" {
  description = "Security group of the interface VPC endpoints (ECR, Logs, Secrets Manager, ECS, ...)."
  type        = string
}

variable "s3_prefix_list_id" {
  description = "Prefix list of the S3 gateway endpoint (ECR image layers)."
  type        = string
}

variable "egress_security_group_ids" {
  description = "Shared egress allow-list group(s) attached to the orchestrator and the bot (HTTPS to Portkey, Fiddler, VPC endpoints). Never attached to workspace tasks: they get their own group."
  type        = list(string)
}

variable "internet_egress_security_group_id" {
  description = "Firewall mode: the internet-via-firewall group (domain allow-list), attached to the Teams bot only (Bot Framework / Entra ID hosts). null in cidr mode."
  type        = string
  default     = null
}

# --- Platform (from modules/platform-services) -------------------------------------------------
variable "platform_api_url" {
  description = "platform-api base URL the orchestrator and the bot call (https://<api host>)."
  type        = string
}

variable "platform_alb_security_group_id" {
  description = "Security group of the portal/API ALB: the orchestrator and the bot reach platform-api through it, and it forwards Teams traffic to the bot."
  type        = string
}

variable "platform_https_listener_arn" {
  description = "HTTPS listener of the portal/API ALB; the bot host rules are added here."
  type        = string
}

variable "web_url" {
  description = "AIG portal URL (AIG_WEB_URL of the bot: card links)."
  type        = string
  default     = null
}

variable "certificate_arn" {
  description = "ACM certificate covering relay_hostname (and teams_bot_hostname on the portal/API ALB listener)."
  type        = string
}

variable "ssl_policy" {
  type    = string
  default = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

variable "relay_hostname" {
  description = "Host of the orchestrator relay on the internal relay ALB (AIG_WS_RELAY_PUBLIC_URL = https://<this>). Point it (private zone) at the relay_alb_dns_name output."
  type        = string
}

# --- Images -----------------------------------------------------------------------------------
variable "images" {
  description = "Images pinned by digest (<repo>@sha256:<64 hex>): workspace (infra/ci/docker/workspace.Dockerfile, linux/amd64), orchestrator and teams_bot (linux/arm64)."
  type = object({
    workspace    = string
    orchestrator = string
    teams_bot    = string
  })
  validation {
    condition     = alltrue([for v in values(var.images) : can(regex("@sha256:[0-9a-f]{64}$", v))])
    error_message = "Every image must be pinned by digest (...@sha256:<64 hex>); tags are refused."
  }
}

# --- Secrets (created by modules/secrets with placeholders) -----------------------------------
variable "kms_key_arn" {
  description = "Environment KMS key (secrets, log groups)."
  type        = string
}

variable "team_secret_arns" {
  description = <<-EOT
    team -> ARN of aig/<env>/workspaces/<team> (JSON key portkey_api_key: that team's scoped Portkey
    workspace key). One workspace task definition and one execution role per team: a team's tasks
    can only ever receive that team's key.
  EOT
  type        = map(string)
  validation {
    condition     = length(var.team_secret_arns) > 0 && alltrue([for t in keys(var.team_secret_arns) : can(regex("^[A-Za-z0-9][A-Za-z0-9_-]{0,31}$", t)) && t != "shared"])
    error_message = "team_secret_arns needs at least one team; team names are 1-32 of [A-Za-z0-9_-], starting with a letter or digit (ECS family / IAM role safe), and not \"shared\"."
  }
}

variable "shared_secret_arn" {
  description = "ARN of aig/<env>/workspaces/shared (fiddler_api_key, github_app_private_key), injected into every workspace task."
  type        = string
}

variable "orchestrator_secret_arn" {
  description = "ARN of aig/<env>/workspace-orchestrator (AIG_PLATFORM_SERVICE_TOKEN, AIG_WS_RELAY_SECRET, AIG_WS_NOTIFY_SECRET)."
  type        = string
}

variable "teams_bot_secret_arn" {
  description = "ARN of aig/<env>/teams-bot (MicrosoftAppId, MicrosoftAppPassword, AIG_BOT_NOTIFY_SECRET). Required when teams_bot_enabled."
  type        = string
  default     = null
}

# --- Workspace task ---------------------------------------------------------------------------
variable "workspace_cpu" {
  description = "Fargate CPU units of a workspace task (open item: sizing; 2048 = 2 vCPU)."
  type        = number
  default     = 2048
}

variable "workspace_memory" {
  description = "Fargate memory (MiB) of a workspace task (open item: sizing)."
  type        = number
  default     = 8192
}

variable "workspace_ephemeral_storage_gib" {
  description = "Fargate ephemeral storage (GiB, 21-200): the clone, the repo's dependencies and ~/.claude live on it."
  type        = number
  default     = 50
  validation {
    condition     = var.workspace_ephemeral_storage_gib >= 21 && var.workspace_ephemeral_storage_gib <= 200
    error_message = "workspace_ephemeral_storage_gib must be between 21 and 200."
  }
}

variable "use_fargate_spot" {
  description = "Run workspace tasks on FARGATE_SPOT (AIG_WS_ECS_CAPACITY_PROVIDER). A reclaimed task fails the workspace."
  type        = bool
  default     = false
}

# --- Orchestrator -----------------------------------------------------------------------------
variable "orchestrator_environment" {
  description = <<-EOT
    Extra non-secret orchestrator variables, also forwarded to every job when they are on the
    orchestrator's pass-through list: AIG_FIDDLER_PROJECT, AIG_FIDDLER_APPLICATION_ID,
    AIG_OTLP_ENDPOINT, GITHUB_API_URL, GITHUB_APP_ID, GITHUB_APP_INSTALLATION_ID,
    AIG_WS_MAX_CONCURRENT, AIG_WS_IDLE_TIMEOUT_MINUTES, AIG_WS_USER_TIER, PIP_INDEX_URL, ...
    (backend/workspace-orchestrator/README.md "Configuration"). No secrets here.
  EOT
  type        = map(string)
  default     = {}
  validation {
    condition     = alltrue([for k in keys(var.orchestrator_environment) : !can(regex("(?i)(api_key|token|secret|password|private_key)", k))])
    error_message = "orchestrator_environment must not carry secrets (they come from aig/<env>/workspace-orchestrator or the workspace secrets)."
  }
}

variable "portkey_base_url" {
  description = "AIG_PORTKEY_BASE_URL forwarded to the jobs (Claude Code's ANTHROPIC_BASE_URL is derived from it)."
  type        = string
}

variable "fiddler_url" {
  description = "AIG_FIDDLER_URL forwarded to the jobs."
  type        = string
}

variable "orchestrator_cpu" {
  type    = number
  default = 256
}

variable "orchestrator_memory" {
  type    = number
  default = 512
}

# --- Teams bot --------------------------------------------------------------------------------
variable "teams_bot_enabled" {
  description = "Run the Teams bot on ECS behind the portal/API ALB."
  type        = bool
  default     = true
}

variable "teams_bot_hostname" {
  description = "Bot host on the portal/API ALB (Azure Bot messaging endpoint https://<this>/api/messages). Required when teams_bot_enabled."
  type        = string
  default     = null
}

variable "teams_bot_ingress_cidrs" {
  description = "Extra sources allowed to the portal/API ALB on 443 for the bot (Bot Framework / Teams service ranges, or the corporate reverse proxy that fronts it)."
  type        = list(string)
  default     = []
}

variable "teams_bot_oauth_connection" {
  description = "AIG_BOT_OAUTH_CONNECTION: Azure Bot OAuth connection name (Teams SSO to platform-api)."
  type        = string
  default     = "aig-platform"
}

variable "teams_bot_app_type" {
  description = "MicrosoftAppType: SingleTenant, MultiTenant or UserAssignedMSI."
  type        = string
  default     = "SingleTenant"
}

variable "teams_bot_tenant_id" {
  description = "MicrosoftAppTenantId (Entra tenant of the bot app)."
  type        = string
  default     = null
}

variable "teams_bot_environment" {
  description = "Extra non-secret bot variables. No secrets here."
  type        = map(string)
  default     = {}
  validation {
    condition     = alltrue([for k in keys(var.teams_bot_environment) : !can(regex("(?i)(api_key|token|secret|password|private_key)", k))])
    error_message = "teams_bot_environment must not carry secrets (they come from aig/<env>/teams-bot)."
  }
}

variable "teams_bot_cpu" {
  type    = number
  default = 256
}

variable "teams_bot_memory" {
  type    = number
  default = 512
}

variable "log_retention_days" {
  type    = number
  default = 90
}

variable "tags" {
  type    = map(string)
  default = {}
}
