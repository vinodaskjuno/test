# Task definitions and services.
#   workspace (one family per team + a key-less base): X86_64 (infra/ci/docker/workspace.Dockerfile is
#     built for linux/amd64), uid 10001, read-only root FS; /workspace (clone, venv), /home/aig
#     (~/.claude) and /tmp are task volumes on the Fargate ephemeral storage. Started by the
#     orchestrator with ecs:RunTask; never a service.
#   workspace-orchestrator: ECS service, exactly one task (single active instance), ARM64.
#   teams-bot: ECS service, one task (conversation references in a task-local file), ARM64.

locals {
  log_config = {
    for k, lg in aws_cloudwatch_log_group.this : k => {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = lg.name
        "awslogs-region"        = local.region
        "awslogs-stream-prefix" = k == "workspaces" ? local.workspace_log_prefix : replace(k, "_", "-")
        "mode"                  = "non-blocking"
      }
    }
  }

  # --- workspace ------------------------------------------------------------------------------
  workspace_volumes = { workspace = "/workspace", home = "/home/aig", tmp = "/tmp" }

  # Makes the task volumes writable for uid 10001 (they are created root-owned); every capability
  # is dropped, so it can chmod its own volumes and nothing else.
  workspace_prepare = merge(local.hardened, {
    name             = "prepare"
    image            = var.images.workspace
    essential        = false
    user             = "0"
    entryPoint       = ["/bin/sh", "-c"]
    command          = ["chmod 1777 ${join(" ", [for v in keys(local.workspace_volumes) : "/w/${v}"])}"]
    environment      = []
    mountPoints      = [for v in keys(local.workspace_volumes) : { sourceVolume = v, containerPath = "/w/${v}", readOnly = false }]
    logConfiguration = local.log_config["workspaces"]
  })

  # Static, non-secret settings only. The orchestrator adds the per-workspace values (WORKSPACE_ID,
  # REPO_URL, AIG_WS_STATUS_URL/TOKEN, AIG_AGENT_ID, ...) as container overrides at RunTask.
  workspace_environment = {
    HOME           = "/home/aig"
    TMPDIR         = "/tmp"
    AIG_WS_WORKDIR = "/workspace"
  }

  workspace_secrets = {
    for k, v in local.workspace_variants : k => concat(
      [
        { name = "AIG_FIDDLER_API_KEY", valueFrom = "${var.shared_secret_arn}:fiddler_api_key::" },
        { name = "GITHUB_APP_PRIVATE_KEY", valueFrom = "${var.shared_secret_arn}:github_app_private_key::" },
      ],
      v.team_secret_arn == null ? [] : [{ name = "AIG_PORTKEY_API_KEY", valueFrom = "${v.team_secret_arn}:portkey_api_key::" }],
    )
  }

  workspace_containers = {
    for k, v in local.workspace_variants : k => [
      local.workspace_prepare,
      merge(local.hardened, {
        name        = local.workspace_container
        image       = var.images.workspace
        essential   = true
        user        = "10001"
        environment = [for n, val in local.workspace_environment : { name = n, value = val }]
        secrets     = local.workspace_secrets[k]
        mountPoints = [for vol, path in local.workspace_volumes : { sourceVolume = vol, containerPath = path, readOnly = false }]
        dependsOn   = [{ containerName = "prepare", condition = "SUCCESS" }]
        # The image's ENTRYPOINT is tini (forwards SIGTERM from ecs:StopTask so the job flushes its
        # spans); no second init process.
        linuxParameters  = merge(local.hardened.linuxParameters, { initProcessEnabled = false })
        stopTimeout      = 30
        logConfiguration = local.log_config["workspaces"]
      }),
    ]
  }

  # --- orchestrator ---------------------------------------------------------------------------
  orchestrator_environment = merge({
    AIG_ENV                          = var.env
    AIG_PLATFORM_API_URL             = var.platform_api_url
    AIG_WS_RUNNER                    = "ecs"
    AIG_WS_RELAY_HOST                = "0.0.0.0"
    AIG_WS_RELAY_PORT                = tostring(local.relay_port)
    AIG_WS_RELAY_PUBLIC_URL          = "https://${var.relay_hostname}"
    AIG_WS_RECOVER                   = "true"
    AIG_WS_ECS_CLUSTER               = local.cluster_name
    AIG_WS_ECS_TASK_DEFINITION       = local.base_family
    AIG_WS_ECS_TEAM_TASK_DEFINITIONS = jsonencode(local.team_families)
    AIG_WS_ECS_SUBNETS               = join(",", var.private_subnet_ids)
    AIG_WS_ECS_SECURITY_GROUPS       = aws_security_group.workspace.id
    AIG_WS_ECS_CONTAINER_NAME        = local.workspace_container
    AIG_WS_ECS_ASSIGN_PUBLIC_IP      = "false"
    AIG_WS_ECS_PLATFORM_VERSION      = "LATEST"
    AIG_WS_ECS_LOG_GROUP             = local.workspace_log_group
    AIG_WS_ECS_LOG_STREAM_PREFIX     = local.workspace_log_prefix
    AIG_PORTKEY_BASE_URL             = var.portkey_base_url
    AIG_FIDDLER_URL                  = var.fiddler_url
    AWS_REGION                       = local.region
    AWS_DEFAULT_REGION               = local.region
    },
    var.use_fargate_spot ? { AIG_WS_ECS_CAPACITY_PROVIDER = "FARGATE_SPOT" } : {},
    var.teams_bot_enabled ? { AIG_WS_NOTIFY_URLS = local.teams_bot_notify_url } : {},
  var.orchestrator_environment)

  orchestrator_secrets = [
    for k in ["AIG_PLATFORM_SERVICE_TOKEN", "AIG_WS_RELAY_SECRET", "AIG_WS_NOTIFY_SECRET"] :
    { name = k, valueFrom = "${var.orchestrator_secret_arn}:${k}::" }
  ]

  orchestrator_container = merge(local.hardened, {
    name         = "workspace-orchestrator"
    image        = var.images.orchestrator
    essential    = true
    user         = "10001"
    portMappings = [{ containerPort = local.relay_port, protocol = "tcp", name = "relay" }]
    environment  = [for n, val in local.orchestrator_environment : { name = n, value = val }]
    secrets      = local.orchestrator_secrets
    mountPoints  = [{ sourceVolume = "tmp", containerPath = "/tmp", readOnly = false }]
    healthCheck = {
      command     = ["CMD", "python", "-c", "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:${local.relay_port}/healthz', timeout=3).status == 200 else 1)"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 30
    }
    stopTimeout      = 30
    logConfiguration = local.log_config["orchestrator"]
  })

  # --- teams-bot ------------------------------------------------------------------------------
  teams_bot_environment = merge({
    AIG_ENV                  = var.env
    PORT                     = tostring(local.teams_bot_port)
    AIG_PLATFORM_API_URL     = var.platform_api_url
    AIG_BOT_AUTH_MODE        = "oauth"
    AIG_BOT_OAUTH_CONNECTION = var.teams_bot_oauth_connection
    AIG_BOT_STATE_FILE       = "/app/state/conversations.json"
    MicrosoftAppType         = var.teams_bot_app_type
    },
    var.web_url == null ? {} : { AIG_WEB_URL = var.web_url },
    var.teams_bot_tenant_id == null ? {} : { MicrosoftAppTenantId = var.teams_bot_tenant_id },
  var.teams_bot_environment)

  teams_bot_secrets = [
    for k in ["MicrosoftAppId", "MicrosoftAppPassword", "AIG_BOT_NOTIFY_SECRET"] :
    { name = k, valueFrom = "${coalesce(var.teams_bot_secret_arn, "unset")}:${k}::" }
  ]

  teams_bot_prepare = merge(local.hardened, {
    name             = "prepare"
    image            = var.images.teams_bot
    essential        = false
    user             = "0"
    entryPoint       = ["/bin/sh", "-c"]
    command          = ["chmod 1777 /w/state /w/tmp"]
    environment      = []
    mountPoints      = [{ sourceVolume = "state", containerPath = "/w/state", readOnly = false }, { sourceVolume = "tmp", containerPath = "/w/tmp", readOnly = false }]
    logConfiguration = local.log_config["teams_bot"]
  })

  teams_bot_container = merge(local.hardened, {
    name         = "teams-bot"
    image        = var.images.teams_bot
    essential    = true
    user         = "1000:1000" # "node" in the official Node image
    portMappings = [{ containerPort = local.teams_bot_port, protocol = "tcp", name = "http" }]
    environment  = [for n, val in local.teams_bot_environment : { name = n, value = val }]
    secrets      = local.teams_bot_secrets
    mountPoints = [
      { sourceVolume = "state", containerPath = "/app/state", readOnly = false },
      { sourceVolume = "tmp", containerPath = "/tmp", readOnly = false },
    ]
    dependsOn = [{ containerName = "prepare", condition = "SUCCESS" }]
    healthCheck = {
      command     = ["CMD", "node", "-e", "fetch('http://127.0.0.1:${local.teams_bot_port}/healthz').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 20
    }
    stopTimeout      = 30
    logConfiguration = local.log_config["teams_bot"]
  })
}

# --- Workspace task definitions (one per team + base) -----------------------------------------
resource "aws_ecs_task_definition" "workspace" {
  for_each                 = local.workspace_variants
  family                   = each.value.family
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = tostring(var.workspace_cpu)
  memory                   = tostring(var.workspace_memory)
  execution_role_arn       = aws_iam_role.workspace_execution[each.key].arn
  task_role_arn            = aws_iam_role.workspace_task.arn
  container_definitions    = jsonencode(local.workspace_containers[each.key])

  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "X86_64"
  }

  ephemeral_storage {
    size_in_gib = var.workspace_ephemeral_storage_gib
  }

  dynamic "volume" {
    for_each = toset(keys(local.workspace_volumes))
    content {
      name = volume.value
    }
  }

  tags = merge(local.tags, { "aig:component" = "workspace", "aig:team" = each.key })
}

# --- Orchestrator -------------------------------------------------------------------------------
resource "aws_ecs_task_definition" "orchestrator" {
  family                   = "${var.name}-workspace-orchestrator"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = tostring(var.orchestrator_cpu)
  memory                   = tostring(var.orchestrator_memory)
  execution_role_arn       = aws_iam_role.orchestrator_execution.arn
  task_role_arn            = aws_iam_role.orchestrator_task.arn
  container_definitions    = jsonencode([local.orchestrator_container])

  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "ARM64"
  }

  volume {
    name = "tmp"
  }

  tags = merge(local.tags, { "aig:service" = "workspace-orchestrator" })
}

resource "aws_ecs_service" "orchestrator" {
  name                              = "workspace-orchestrator"
  cluster                           = aws_ecs_cluster.this.id
  task_definition                   = aws_ecs_task_definition.orchestrator.arn
  desired_count                     = 1
  launch_type                       = "FARGATE"
  platform_version                  = "LATEST"
  enable_execute_command            = false
  propagate_tags                    = "SERVICE"
  health_check_grace_period_seconds = 60
  wait_for_steady_state             = true

  # Single active instance (idle tracking is per process): stop the old task before starting the
  # new one; never two orchestrators at once. Running workspaces are adopted on start
  # (AIG_WS_RECOVER, ecs:ListTasks startedBy=aig-ws/<id>).
  deployment_minimum_healthy_percent = 0
  deployment_maximum_percent         = 100

  network_configuration {
    subnets          = var.private_subnet_ids
    assign_public_ip = false
    security_groups  = concat([aws_security_group.orchestrator.id], var.egress_security_group_ids)
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.relay.arn
    container_name   = "workspace-orchestrator"
    container_port   = local.relay_port
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  depends_on = [aws_lb_listener_rule.relay]
  tags       = merge(local.tags, { "aig:service" = "workspace-orchestrator" })
}

# --- Teams bot ----------------------------------------------------------------------------------
resource "aws_ecs_task_definition" "teams_bot" {
  count                    = var.teams_bot_enabled ? 1 : 0
  family                   = "${var.name}-teams-bot"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = tostring(var.teams_bot_cpu)
  memory                   = tostring(var.teams_bot_memory)
  execution_role_arn       = aws_iam_role.teams_bot_execution[0].arn
  task_role_arn            = aws_iam_role.teams_bot_task[0].arn
  container_definitions    = jsonencode([local.teams_bot_prepare, local.teams_bot_container])

  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "ARM64"
  }

  volume {
    name = "state"
  }
  volume {
    name = "tmp"
  }

  lifecycle {
    precondition {
      condition     = var.teams_bot_secret_arn != null && var.teams_bot_hostname != null
      error_message = "teams_bot_enabled needs teams_bot_secret_arn and teams_bot_hostname."
    }
  }

  tags = merge(local.tags, { "aig:service" = "teams-bot" })
}

resource "aws_ecs_service" "teams_bot" {
  count                             = var.teams_bot_enabled ? 1 : 0
  name                              = "teams-bot"
  cluster                           = aws_ecs_cluster.this.id
  task_definition                   = aws_ecs_task_definition.teams_bot[0].arn
  desired_count                     = 1
  launch_type                       = "FARGATE"
  platform_version                  = "LATEST"
  enable_execute_command            = false
  propagate_tags                    = "SERVICE"
  health_check_grace_period_seconds = 60
  wait_for_steady_state             = true

  # One replica: conversation references live in a task-local file (backend/teams-bot README).
  deployment_minimum_healthy_percent = 0
  deployment_maximum_percent         = 100

  network_configuration {
    subnets          = var.private_subnet_ids
    assign_public_ip = false
    security_groups  = concat([aws_security_group.teams_bot[0].id], var.egress_security_group_ids, var.internet_egress_security_group_id == null ? [] : [var.internet_egress_security_group_id])
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.teams_bot[0].arn
    container_name   = "teams-bot"
    container_port   = local.teams_bot_port
  }

  service_registries {
    registry_arn = aws_service_discovery_service.teams_bot[0].arn
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  depends_on = [aws_lb_listener_rule.teams_bot]
  tags       = merge(local.tags, { "aig:service" = "teams-bot" })
}
