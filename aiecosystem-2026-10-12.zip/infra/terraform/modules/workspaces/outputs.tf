output "cluster_name" {
  value = aws_ecs_cluster.this.name
}

output "service_names" {
  description = "key (orchestrator, teams_bot) -> ECS service name in the workspaces cluster."
  value = merge(
    { orchestrator = aws_ecs_service.orchestrator.name },
    var.teams_bot_enabled ? { teams_bot = aws_ecs_service.teams_bot[0].name } : {},
  )
}

output "workspace_task_families" {
  description = "team -> workspace task definition family (_base = the key-less default)."
  value       = local.workspace_families
}

output "workspace_security_group_id" {
  value = aws_security_group.workspace.id
}

output "log_group_names" {
  value = { for k, lg in aws_cloudwatch_log_group.this : k => lg.name }
}

output "relay_url" {
  value = "https://${var.relay_hostname}"
}

output "relay_alb_dns_name" {
  description = "Point relay_hostname (private zone) here."
  value       = aws_lb.relay.dns_name
}

output "relay_alb_arn_suffix" {
  value = aws_lb.relay.arn_suffix
}

output "teams_bot_messaging_endpoint" {
  description = "Azure Bot messaging endpoint (point teams_bot_hostname at the portal/API ALB)."
  value       = var.teams_bot_enabled ? "https://${var.teams_bot_hostname}/api/messages" : null
}

output "teams_bot_notify_url" {
  description = "AIG_WS_NOTIFY_URLS of the orchestrator (private Cloud Map name)."
  value       = var.teams_bot_enabled ? local.teams_bot_notify_url : null
}

output "orchestrator_task_role_arn" {
  value = aws_iam_role.orchestrator_task.arn
}
