# Security groups, the internal relay ALB and the bot rules on the portal/API ALB.
#
#   workspace tasks : NO ingress. Egress HTTPS only to the egress prefix list (Portkey, Fiddler),
#                     the workspace prefix list (GitHub / package mirror), the VPC endpoints, S3
#                     (ECR layers) and the relay ALB. No 0.0.0.0/0 rule, in either egress mode.
#   relay ALB       : internal; ingress 443 from the workspace SG only; forwards to the relay (8090).
#   orchestrator    : ingress 8090 from the relay ALB; egress 443 to the portal/API ALB
#                     (platform-api) and 3978 to the bot (/api/notify), plus the shared allow-list.
#   teams-bot       : ingress 3978 from the portal/API ALB and from the orchestrator only.

resource "aws_security_group" "workspace" {
  name        = "${var.name}-workspace-tasks"
  description = "AIG workspace tasks: no ingress; HTTPS only to Portkey, Fiddler, GitHub/package mirror, VPC endpoints and the relay"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-workspace-tasks" })
}

resource "aws_security_group" "relay_alb" {
  name        = "${var.name}-ws-relay-alb"
  description = "Workspace relay ALB (internal): HTTPS from workspace tasks only"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-ws-relay-alb" })
}

resource "aws_security_group" "orchestrator" {
  name        = "${var.name}-ws-orchestrator"
  description = "Workspace orchestrator: relay ingress from the relay ALB only"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-ws-orchestrator" })
}

resource "aws_security_group" "teams_bot" {
  count       = var.teams_bot_enabled ? 1 : 0
  name        = "${var.name}-teams-bot"
  description = "Teams bot: ingress from the portal/API ALB (/api/messages) and the orchestrator (/api/notify) only"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-teams-bot" })
}

# --- Workspace task egress (allow-list) ---------------------------------------------------------
locals {
  workspace_egress = {
    portkey_fiddler = { description = "HTTPS to Portkey and Fiddler (egress prefix list)", prefix_list_id = var.egress_prefix_list_id, sg = null }
    git_and_mirror  = { description = "HTTPS to GitHub / GHES and the package mirror (workspace prefix list)", prefix_list_id = var.workspace_egress_prefix_list_id, sg = null }
    s3_gateway      = { description = "HTTPS to S3 through the gateway endpoint (ECR image layers)", prefix_list_id = var.s3_prefix_list_id, sg = null }
    vpc_endpoints   = { description = "HTTPS to the interface VPC endpoints (ECR, Logs, Secrets Manager)", prefix_list_id = null, sg = var.vpc_endpoints_security_group_id }
    relay           = { description = "HTTPS to the orchestrator relay (internal ALB)", prefix_list_id = null, sg = aws_security_group.relay_alb.id }
  }
}

resource "aws_vpc_security_group_egress_rule" "workspace" {
  for_each                     = local.workspace_egress
  security_group_id            = aws_security_group.workspace.id
  description                  = each.value.description
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  prefix_list_id               = each.value.prefix_list_id
  referenced_security_group_id = each.value.sg
}

# --- Relay ALB ----------------------------------------------------------------------------------
resource "aws_vpc_security_group_ingress_rule" "relay_alb_from_workspaces" {
  security_group_id            = aws_security_group.relay_alb.id
  description                  = "HTTPS from workspace tasks"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = aws_security_group.workspace.id
}

resource "aws_vpc_security_group_egress_rule" "relay_alb_to_orchestrator" {
  security_group_id            = aws_security_group.relay_alb.id
  description                  = "To the relay port of the orchestrator tasks"
  ip_protocol                  = "tcp"
  from_port                    = local.relay_port
  to_port                      = local.relay_port
  referenced_security_group_id = aws_security_group.orchestrator.id
}

resource "aws_lb" "relay" {
  name                       = "${var.name}-ws-relay"
  load_balancer_type         = "application"
  internal                   = true
  subnets                    = var.private_subnet_ids
  security_groups            = [aws_security_group.relay_alb.id]
  drop_invalid_header_fields = true
  idle_timeout               = 120
  tags                       = local.tags
}

resource "aws_lb_target_group" "relay" {
  name                 = "${var.name}-ws-relay"
  port                 = local.relay_port
  protocol             = "HTTP"
  target_type          = "ip"
  vpc_id               = var.vpc_id
  deregistration_delay = 30
  health_check {
    path                = "/healthz"
    matcher             = "200"
    interval            = 15
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }
  tags = merge(local.tags, { "aig:service" = "workspace-orchestrator" })
}

# The relay token never crosses the VPC in clear text: TLS terminates on the internal ALB.
resource "aws_lb_listener" "relay" {
  load_balancer_arn = aws_lb.relay.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.ssl_policy
  certificate_arn   = var.certificate_arn
  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = "not found"
      status_code  = "404"
    }
  }
  tags = local.tags
}

resource "aws_lb_listener_rule" "relay" {
  listener_arn = aws_lb_listener.relay.arn
  priority     = 10
  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.relay.arn
  }
  condition {
    host_header {
      values = [var.relay_hostname]
    }
  }
  condition {
    path_pattern {
      values = ["/relay/v1/*", "/healthz"]
    }
  }
  tags = local.tags
}

# --- Orchestrator -------------------------------------------------------------------------------
resource "aws_vpc_security_group_ingress_rule" "orchestrator_from_relay_alb" {
  security_group_id            = aws_security_group.orchestrator.id
  description                  = "Relay from the internal relay ALB"
  ip_protocol                  = "tcp"
  from_port                    = local.relay_port
  to_port                      = local.relay_port
  referenced_security_group_id = aws_security_group.relay_alb.id
}

resource "aws_vpc_security_group_egress_rule" "orchestrator_to_platform_alb" {
  security_group_id            = aws_security_group.orchestrator.id
  description                  = "HTTPS to platform-api (portal/API ALB)"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = var.platform_alb_security_group_id
}

resource "aws_vpc_security_group_egress_rule" "orchestrator_to_teams_bot" {
  count                        = var.teams_bot_enabled ? 1 : 0
  security_group_id            = aws_security_group.orchestrator.id
  description                  = "Signed status notifications to the Teams bot (/api/notify)"
  ip_protocol                  = "tcp"
  from_port                    = local.teams_bot_port
  to_port                      = local.teams_bot_port
  referenced_security_group_id = aws_security_group.teams_bot[0].id
}

# --- Portal/API ALB (owned by platform-services): who may use it for the workspace flow ---------
resource "aws_vpc_security_group_ingress_rule" "platform_alb_from_workspace_services" {
  for_each = merge(
    { orchestrator = aws_security_group.orchestrator.id },
    var.teams_bot_enabled ? { teams_bot = aws_security_group.teams_bot[0].id } : {},
  )
  security_group_id            = var.platform_alb_security_group_id
  description                  = "HTTPS from ${replace(each.key, "_", "-")} (platform-api calls)"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = each.value
}

resource "aws_vpc_security_group_ingress_rule" "platform_alb_from_bot_framework" {
  for_each          = var.teams_bot_enabled ? toset(var.teams_bot_ingress_cidrs) : toset([])
  security_group_id = var.platform_alb_security_group_id
  description       = "HTTPS from Bot Framework / the reverse proxy in front of the bot"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = each.value
}

resource "aws_vpc_security_group_egress_rule" "platform_alb_to_teams_bot" {
  count                        = var.teams_bot_enabled ? 1 : 0
  security_group_id            = var.platform_alb_security_group_id
  description                  = "To teams-bot tasks"
  ip_protocol                  = "tcp"
  from_port                    = local.teams_bot_port
  to_port                      = local.teams_bot_port
  referenced_security_group_id = aws_security_group.teams_bot[0].id
}

# --- Teams bot ----------------------------------------------------------------------------------
resource "aws_vpc_security_group_ingress_rule" "teams_bot" {
  for_each = var.teams_bot_enabled ? {
    platform_alb = { sg = var.platform_alb_security_group_id, description = "Teams traffic (/api/messages) from the portal/API ALB" }
    orchestrator = { sg = aws_security_group.orchestrator.id, description = "Signed /api/notify from the workspace orchestrator" }
  } : {}
  security_group_id            = aws_security_group.teams_bot[0].id
  description                  = each.value.description
  ip_protocol                  = "tcp"
  from_port                    = local.teams_bot_port
  to_port                      = local.teams_bot_port
  referenced_security_group_id = each.value.sg
}

resource "aws_vpc_security_group_egress_rule" "teams_bot_to_platform_alb" {
  count                        = var.teams_bot_enabled ? 1 : 0
  security_group_id            = aws_security_group.teams_bot[0].id
  description                  = "HTTPS to platform-api (portal/API ALB), on behalf of the user"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = var.platform_alb_security_group_id
}

resource "aws_lb_target_group" "teams_bot" {
  count                = var.teams_bot_enabled ? 1 : 0
  name                 = "${var.name}-teams-bot"
  port                 = local.teams_bot_port
  protocol             = "HTTP"
  target_type          = "ip"
  vpc_id               = var.vpc_id
  deregistration_delay = 30
  health_check {
    path                = "/healthz"
    matcher             = "200"
    interval            = 15
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }
  tags = merge(local.tags, { "aig:service" = "teams-bot" })
}

# Bot host on the portal/API listener. /api/notify is never served publicly: the orchestrator
# reaches it over the private Cloud Map name (bot SG ingress from the orchestrator SG only) and
# signs every request (HMAC, AIG_BOT_NOTIFY_SECRET). The deny rule has the lower priority number,
# so it wins over the forward rule even if the forward paths are widened later.
resource "aws_lb_listener_rule" "teams_bot_notify_deny" {
  count        = var.teams_bot_enabled ? 1 : 0
  listener_arn = var.platform_https_listener_arn
  priority     = 5
  action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = "forbidden"
      status_code  = "403"
    }
  }
  condition {
    host_header {
      values = [var.teams_bot_hostname]
    }
  }
  condition {
    path_pattern {
      values = ["/api/notify", "/api/notify/*"]
    }
  }
  tags = local.tags
}

resource "aws_lb_listener_rule" "teams_bot" {
  count        = var.teams_bot_enabled ? 1 : 0
  listener_arn = var.platform_https_listener_arn
  priority     = 6
  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.teams_bot[0].arn
  }
  condition {
    host_header {
      values = [var.teams_bot_hostname]
    }
  }
  condition {
    path_pattern {
      values = ["/api/messages", "/healthz"]
    }
  }
  tags = local.tags
}
