# AIG Phase 6 team workspaces (backend/workspace-orchestrator, backend/teams-bot,
# infra/ci/docker/workspace.Dockerfile; docs/workspaces.md):
#
#   Teams --HTTPS--> portal/API ALB (host teams_bot_hostname: /api/messages, /healthz only)
#                       --> teams-bot (ECS service, 1 replica) --> platform-api (as the user)
#   orchestrator (ECS service, 1 active replica) --> platform-api (service token)
#                --ecs:RunTask--> workspace task (one task definition per team, restricted egress)
#                --http + HMAC--> teams-bot /api/notify (Cloud Map name, bot SG allows the
#                                 orchestrator only; the public ALB answers 403 on /api/notify)
#   workspace task --HTTPS--> relay ALB (internal, ingress from the workspace SG only) --> relay
#                  --HTTPS--> Portkey, Fiddler, GitHub (+ package mirror), nothing else
#
# The workspace image and the ECR repositories come from the environment module (modules/ecr:
# aig/workspace, aig/workspace-orchestrator, aig/teams-bot), so stage/prod can pull the digest
# that was built once. Secrets are created with placeholders by modules/secrets.

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_partition" "current" {}

locals {
  region    = data.aws_region.current.region
  account   = data.aws_caller_identity.current.account_id
  partition = data.aws_partition.current.partition
  tags      = merge(var.tags, { "aig:module" = "workspaces", "aig:env" = var.env })

  cluster_name = "${var.name}-workspaces"
  cluster_arn  = "arn:${local.partition}:ecs:${local.region}:${local.account}:cluster/${local.cluster_name}"

  # Workspace task definitions: "_base" (no Portkey key: a team without its own definition fails
  # closed in aig_sdk.init) plus one per team with that team's Portkey key. Families follow the
  # orchestrator's own derived naming (<base family>-<team>).
  base_family = "${var.name}-workspace"
  workspace_variants = merge(
    { "_base" = { family = local.base_family, team_secret_arn = null } },
    { for team, arn in var.team_secret_arns : team => { family = "${local.base_family}-${team}", team_secret_arn = arn } },
  )
  workspace_families = { for k, v in local.workspace_variants : k => v.family }
  team_families      = { for team in keys(var.team_secret_arns) : team => local.workspace_families[team] }

  # The orchestrator builds CloudWatch links as <group>/<prefix>/<container>/<task id>.
  workspace_log_group     = "/aig/${var.env}/workspaces"
  workspace_log_prefix    = "workspace"
  workspace_container     = "workspace"
  orchestrator_log_group  = "/aig/${var.env}/workspace-orchestrator"
  teams_bot_log_group     = "/aig/${var.env}/teams-bot"
  relay_port              = 8090
  teams_bot_port          = 3978
  discovery_namespace     = "workspaces.${var.name}.internal"
  teams_bot_internal_host = "teams-bot.${local.discovery_namespace}"
  teams_bot_notify_url    = "http://${local.teams_bot_internal_host}:${local.teams_bot_port}/api/notify"

  secret_regex = "(?i)(api_key|token|secret|password|private_key)"

  # Every container: no privilege escalation, all Linux capabilities dropped, read-only root FS
  # (scratch paths are task volumes).
  hardened = {
    readonlyRootFilesystem = true
    privileged             = false
    linuxParameters = {
      initProcessEnabled = true
      capabilities       = { drop = ["ALL"] }
    }
  }
}

# --- Cluster and logs -------------------------------------------------------------------------
resource "aws_ecs_cluster" "this" {
  name = local.cluster_name
  setting {
    name  = "containerInsights"
    value = "enhanced"
  }
  tags = local.tags
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]
  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
  }
}

resource "aws_cloudwatch_log_group" "this" {
  for_each = {
    workspaces   = local.workspace_log_group
    orchestrator = local.orchestrator_log_group
    teams_bot    = local.teams_bot_log_group
  }
  name              = each.value
  retention_in_days = var.log_retention_days
  kms_key_id        = var.kms_key_arn
  tags              = merge(local.tags, { "aig:service" = replace(each.key, "_", "-") })
}

# Private DNS for the orchestrator -> bot notification path (never through the public ALB).
resource "aws_service_discovery_private_dns_namespace" "this" {
  name        = local.discovery_namespace
  description = "AIG ${var.env} workspaces: internal names (teams-bot /api/notify)"
  vpc         = var.vpc_id
  tags        = local.tags
}

resource "aws_service_discovery_service" "teams_bot" {
  count = var.teams_bot_enabled ? 1 : 0
  name  = "teams-bot"
  dns_config {
    namespace_id   = aws_service_discovery_private_dns_namespace.this.id
    routing_policy = "MULTIVALUE"
    dns_records {
      type = "A"
      ttl  = 10
    }
  }
  tags = local.tags
}
