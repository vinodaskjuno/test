# IAM (least privilege; policies are built as locals so the offline tests can assert on them):
#   workspace task role        - no AWS permissions at all (explicit deny-all)
#   workspace execution roles  - one per team: pull the workspace image, write the workspace log
#                                group, read aig/<env>/workspaces/<team> + aig/<env>/workspaces/shared
#   orchestrator task role     - ecs:RunTask on the workspace task definitions only (in the
#                                workspaces cluster), Stop/Describe/List/Tag its tasks, PassRole on
#                                the workspace roles only
#   orchestrator / bot execution roles - their image, their log group, their own secret

locals {
  ecs_tasks_assume_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Condition = {
        ArnLike      = { "aws:SourceArn" = "arn:${local.partition}:ecs:${local.region}:${local.account}:*" }
        StringEquals = { "aws:SourceAccount" = local.account }
      }
    }]
  })

  # ECR repository ARN from "<acct>.dkr.ecr.<region>.amazonaws.com/<repo>@sha256:..." (the registry
  # may live in another account). Anything else falls back to this account's repositories.
  image_repo_arn = {
    for k, img in var.images : k => (
      can(regex("^([0-9]{12})\\.dkr\\.ecr\\.([a-z0-9-]+)\\.amazonaws\\.com/([^@:]+)@", img))
      ? format("arn:%s:ecr:%s:%s:repository/%s", local.partition,
        regex("^([0-9]{12})\\.dkr\\.ecr\\.([a-z0-9-]+)\\.amazonaws\\.com/([^@:]+)@", img)[1],
        regex("^([0-9]{12})\\.dkr\\.ecr\\.([a-z0-9-]+)\\.amazonaws\\.com/([^@:]+)@", img)[0],
      regex("^([0-9]{12})\\.dkr\\.ecr\\.([a-z0-9-]+)\\.amazonaws\\.com/([^@:]+)@", img)[2])
      : "arn:${local.partition}:ecr:${local.region}:${local.account}:repository/*"
    )
  }

  decrypt_via_secretsmanager = {
    Sid       = "DecryptInjectedSecrets"
    Effect    = "Allow"
    Action    = "kms:Decrypt"
    Resource  = var.kms_key_arn
    Condition = { StringEquals = { "kms:ViaService" = "secretsmanager.${local.region}.amazonaws.com" } }
  }

  # Execution role policy per workspace variant: image pull, its log group, its secrets only.
  workspace_execution_policies = {
    for k, v in local.workspace_variants : k => jsonencode({
      Version = "2012-10-17"
      Statement = [
        { Sid = "EcrAuth", Effect = "Allow", Action = "ecr:GetAuthorizationToken", Resource = "*" },
        {
          Sid      = "PullWorkspaceImage"
          Effect   = "Allow"
          Action   = ["ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer", "ecr:BatchCheckLayerAvailability"]
          Resource = local.image_repo_arn.workspace
        },
        {
          Sid      = "WorkspaceLogs"
          Effect   = "Allow"
          Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
          Resource = "${aws_cloudwatch_log_group.this["workspaces"].arn}:*"
        },
        {
          Sid      = "WorkspaceSecrets"
          Effect   = "Allow"
          Action   = "secretsmanager:GetSecretValue"
          Resource = compact([var.shared_secret_arn, v.team_secret_arn])
        },
        local.decrypt_via_secretsmanager,
      ]
    })
  }

  orchestrator_execution_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      { Sid = "EcrAuth", Effect = "Allow", Action = "ecr:GetAuthorizationToken", Resource = "*" },
      {
        Sid      = "PullImage"
        Effect   = "Allow"
        Action   = ["ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer", "ecr:BatchCheckLayerAvailability"]
        Resource = local.image_repo_arn.orchestrator
      },
      {
        Sid      = "Logs"
        Effect   = "Allow"
        Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "${aws_cloudwatch_log_group.this["orchestrator"].arn}:*"
      },
      { Sid = "OrchestratorSecret", Effect = "Allow", Action = "secretsmanager:GetSecretValue", Resource = var.orchestrator_secret_arn },
      local.decrypt_via_secretsmanager,
    ]
  })

  teams_bot_execution_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      { Sid = "EcrAuth", Effect = "Allow", Action = "ecr:GetAuthorizationToken", Resource = "*" },
      {
        Sid      = "PullImage"
        Effect   = "Allow"
        Action   = ["ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer", "ecr:BatchCheckLayerAvailability"]
        Resource = local.image_repo_arn.teams_bot
      },
      {
        Sid      = "Logs"
        Effect   = "Allow"
        Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "${aws_cloudwatch_log_group.this["teams_bot"].arn}:*"
      },
      { Sid = "BotSecret", Effect = "Allow", Action = "secretsmanager:GetSecretValue", Resource = coalesce(var.teams_bot_secret_arn, var.orchestrator_secret_arn) },
      local.decrypt_via_secretsmanager,
    ]
  })

  # What the orchestrator (EcsRunner) calls: run_task, describe_tasks, stop_task, list_tasks
  # (recovery, startedBy=aig-ws/<id>), tags on run. No RegisterTaskDefinition: the per-team task
  # definitions are explicit (AIG_WS_ECS_TEAM_TASK_DEFINITIONS), not derived at runtime.
  orchestrator_run_task_resources = sort([for f in values(local.workspace_families) : "arn:${local.partition}:ecs:${local.region}:${local.account}:task-definition/${f}:*"])
  orchestrator_task_arn_pattern   = "arn:${local.partition}:ecs:${local.region}:${local.account}:task/${local.cluster_name}/*"
  orchestrator_pass_role_arns     = concat([aws_iam_role.workspace_task.arn], [for k in sort(keys(local.workspace_variants)) : aws_iam_role.workspace_execution[k].arn])

  orchestrator_task_statements = [
    {
      Sid       = "RunWorkspaceTasks"
      Effect    = "Allow"
      Action    = ["ecs:RunTask"]
      Resource  = local.orchestrator_run_task_resources
      Condition = { ArnEquals = { "ecs:cluster" = local.cluster_arn } }
    },
    {
      Sid       = "ManageWorkspaceTasks"
      Effect    = "Allow"
      Action    = ["ecs:StopTask", "ecs:DescribeTasks"]
      Resource  = [local.orchestrator_task_arn_pattern]
      Condition = { ArnEquals = { "ecs:cluster" = local.cluster_arn } }
    },
    {
      Sid       = "ListWorkspaceTasks"
      Effect    = "Allow"
      Action    = ["ecs:ListTasks"]
      Resource  = ["*"] # ListTasks has no task-level resource; scoped to the cluster by condition
      Condition = { ArnEquals = { "ecs:cluster" = local.cluster_arn } }
    },
    {
      Sid       = "TagOnRun"
      Effect    = "Allow"
      Action    = ["ecs:TagResource"]
      Resource  = [local.orchestrator_task_arn_pattern]
      Condition = { StringEquals = { "ecs:CreateAction" = "RunTask" } }
    },
    {
      Sid       = "PassWorkspaceRoles"
      Effect    = "Allow"
      Action    = ["iam:PassRole"]
      Resource  = local.orchestrator_pass_role_arns
      Condition = { StringEquals = { "iam:PassedToService" = "ecs-tasks.amazonaws.com" } }
    },
  ]
}

# --- Workspace task role: nothing ---------------------------------------------------------------
resource "aws_iam_role" "workspace_task" {
  name               = "${var.name}-workspace-task"
  description        = "AIG workspace tasks: no AWS API access (deny-all)"
  assume_role_policy = local.ecs_tasks_assume_policy
  tags               = merge(local.tags, { "aig:service" = "workspace" })
}

resource "aws_iam_role_policy" "workspace_task_deny_all" {
  name = "deny-all"
  role = aws_iam_role.workspace_task.id
  policy = jsonencode({
    Version   = "2012-10-17"
    Statement = [{ Sid = "NoAwsAccess", Effect = "Deny", Action = "*", Resource = "*" }]
  })
}

# --- Workspace execution roles: one per team ----------------------------------------------------
resource "aws_iam_role" "workspace_execution" {
  for_each           = local.workspace_variants
  name               = each.key == "_base" ? "${var.name}-ws-exec" : "${var.name}-ws-${each.key}-exec"
  description        = each.key == "_base" ? "AIG workspace (no team key): image, logs, shared secret" : "AIG workspace team ${each.key}: image, logs, its own Portkey key + shared secret"
  assume_role_policy = local.ecs_tasks_assume_policy
  tags               = merge(local.tags, { "aig:service" = "workspace", "aig:team" = each.key })
}

resource "aws_iam_role_policy" "workspace_execution" {
  for_each = local.workspace_variants
  name     = "workspace-execution"
  role     = aws_iam_role.workspace_execution[each.key].id
  policy   = local.workspace_execution_policies[each.key]
}

# --- Orchestrator -------------------------------------------------------------------------------
resource "aws_iam_role" "orchestrator_execution" {
  name               = "${var.name}-ws-orchestrator-exec"
  assume_role_policy = local.ecs_tasks_assume_policy
  tags               = merge(local.tags, { "aig:service" = "workspace-orchestrator" })
}

resource "aws_iam_role_policy" "orchestrator_execution" {
  name   = "orchestrator-execution"
  role   = aws_iam_role.orchestrator_execution.id
  policy = local.orchestrator_execution_policy
}

resource "aws_iam_role" "orchestrator_task" {
  name               = "${var.name}-ws-orchestrator-task"
  assume_role_policy = local.ecs_tasks_assume_policy
  tags               = merge(local.tags, { "aig:service" = "workspace-orchestrator" })
}

resource "aws_iam_role_policy" "orchestrator_task" {
  name   = "run-workspace-tasks"
  role   = aws_iam_role.orchestrator_task.id
  policy = jsonencode({ Version = "2012-10-17", Statement = local.orchestrator_task_statements })
}

# --- Teams bot ----------------------------------------------------------------------------------
resource "aws_iam_role" "teams_bot_execution" {
  count              = var.teams_bot_enabled ? 1 : 0
  name               = "${var.name}-teams-bot-exec"
  assume_role_policy = local.ecs_tasks_assume_policy
  tags               = merge(local.tags, { "aig:service" = "teams-bot" })
}

resource "aws_iam_role_policy" "teams_bot_execution" {
  count  = var.teams_bot_enabled ? 1 : 0
  name   = "teams-bot-execution"
  role   = aws_iam_role.teams_bot_execution[0].id
  policy = local.teams_bot_execution_policy
}

# The bot calls only platform-api and Bot Framework: no AWS permissions.
resource "aws_iam_role" "teams_bot_task" {
  count              = var.teams_bot_enabled ? 1 : 0
  name               = "${var.name}-teams-bot-task"
  assume_role_policy = local.ecs_tasks_assume_policy
  tags               = merge(local.tags, { "aig:service" = "teams-bot" })
}
