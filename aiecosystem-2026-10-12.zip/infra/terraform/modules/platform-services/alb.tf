# Two HTTPS load balancers (TLS 1.2+/1.3 policy, HTTP -> HTTPS redirect, invalid headers dropped):
#   public   - portal (web) and platform-api; internal by default (corporate network), see alb_internal.
#   internal - telemetry-bridge and cache-compress, reached by platform-api and the Portkey gateway.
# Target groups check /healthz on every service (the same endpoint the images' HEALTHCHECK uses).

locals {
  target_groups = {
    platform_api     = { name = "api", port = 8080, lb = "public", host = var.api_hostname }
    web              = { name = "web", port = 8080, lb = "public", host = var.web_hostname }
    telemetry_bridge = { name = "bridge", port = 8095, lb = "internal", host = var.bridge_hostname }
    cache_compress   = { name = "cc", port = 8090, lb = "internal", host = var.cache_compress_hostname }
  }
}

# --- Security groups --------------------------------------------------------------------------
resource "aws_security_group" "alb_public" {
  name        = "${var.name}-alb-public"
  description = "Portal/API ALB: HTTPS from the allowed client ranges"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-alb-public" })
}

resource "aws_security_group" "alb_internal" {
  name        = "${var.name}-alb-internal"
  description = "Internal ALB (telemetry-bridge, cache-compress): HTTPS from the VPC and the Portkey gateway"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-alb-internal" })
}

resource "aws_vpc_security_group_ingress_rule" "alb_public" {
  for_each          = { for pair in setproduct(var.alb_ingress_cidrs, [80, 443]) : "${pair[0]}-${pair[1]}" => pair }
  security_group_id = aws_security_group.alb_public.id
  description       = each.value[1] == 80 ? "HTTP (redirected to HTTPS)" : "HTTPS"
  ip_protocol       = "tcp"
  from_port         = each.value[1]
  to_port           = each.value[1]
  cidr_ipv4         = each.value[0]
}

resource "aws_vpc_security_group_ingress_rule" "alb_internal" {
  for_each          = toset(distinct(concat([var.vpc_cidr], var.internal_alb_ingress_cidrs)))
  security_group_id = aws_security_group.alb_internal.id
  description       = "HTTPS"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = each.value
}

resource "aws_security_group" "service" {
  for_each    = local.target_groups
  name        = "${var.name}-${replace(each.key, "_", "-")}"
  description = "ECS service ${replace(each.key, "_", "-")}: ingress from its ALB only"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-${replace(each.key, "_", "-")}" })
}

resource "aws_vpc_security_group_ingress_rule" "service_from_alb" {
  for_each                     = local.target_groups
  security_group_id            = aws_security_group.service[each.key].id
  description                  = "From the ${each.value.lb} ALB"
  ip_protocol                  = "tcp"
  from_port                    = each.value.port
  to_port                      = each.value.port
  referenced_security_group_id = each.value.lb == "public" ? aws_security_group.alb_public.id : aws_security_group.alb_internal.id
}

resource "aws_vpc_security_group_egress_rule" "alb_to_service" {
  for_each                     = local.target_groups
  security_group_id            = each.value.lb == "public" ? aws_security_group.alb_public.id : aws_security_group.alb_internal.id
  description                  = "To ${replace(each.key, "_", "-")} tasks"
  ip_protocol                  = "tcp"
  from_port                    = each.value.port
  to_port                      = each.value.port
  referenced_security_group_id = aws_security_group.service[each.key].id
}

# Service-to-service calls go through the ALBs over HTTPS:
#   platform-api -> telemetry-bridge (internal ALB), telemetry-bridge -> platform-api (public ALB).
resource "aws_vpc_security_group_egress_rule" "service_to_albs" {
  for_each = {
    platform_api_to_internal     = { svc = "platform_api", sg = aws_security_group.alb_internal.id }
    telemetry_bridge_to_public   = { svc = "telemetry_bridge", sg = aws_security_group.alb_public.id }
    telemetry_bridge_to_internal = { svc = "telemetry_bridge", sg = aws_security_group.alb_internal.id }
  }
  security_group_id            = aws_security_group.service[each.value.svc].id
  description                  = "HTTPS to the platform ALBs"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = each.value.sg
}

resource "aws_vpc_security_group_ingress_rule" "alb_public_from_services" {
  security_group_id            = aws_security_group.alb_public.id
  description                  = "HTTPS from telemetry-bridge (registry/reconciliation calls)"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = aws_security_group.service["telemetry_bridge"].id
}

# --- Load balancers ---------------------------------------------------------------------------
resource "aws_lb" "public" {
  name                       = "${var.name}-public"
  load_balancer_type         = "application"
  internal                   = var.alb_internal
  subnets                    = var.alb_subnet_ids
  security_groups            = [aws_security_group.alb_public.id]
  drop_invalid_header_fields = true
  enable_deletion_protection = var.db_deletion_protection
  idle_timeout               = 120 # SSE / WebSocket chat streams
  dynamic "access_logs" {
    for_each = var.alb_access_logs_bucket == null ? [] : [var.alb_access_logs_bucket]
    content {
      bucket  = access_logs.value
      prefix  = "${var.name}/public"
      enabled = true
    }
  }
  tags = local.tags
}

resource "aws_lb" "internal" {
  name                       = "${var.name}-internal"
  load_balancer_type         = "application"
  internal                   = true
  subnets                    = var.private_subnet_ids
  security_groups            = [aws_security_group.alb_internal.id]
  drop_invalid_header_fields = true
  enable_deletion_protection = var.db_deletion_protection
  idle_timeout               = 300 # long streaming completions through cache-compress
  dynamic "access_logs" {
    for_each = var.alb_access_logs_bucket == null ? [] : [var.alb_access_logs_bucket]
    content {
      bucket  = access_logs.value
      prefix  = "${var.name}/internal"
      enabled = true
    }
  }
  tags = local.tags
}

resource "aws_lb_target_group" "this" {
  for_each             = local.target_groups
  name                 = "${var.name}-${each.value.name}"
  port                 = each.value.port
  protocol             = "HTTP"
  target_type          = "ip"
  vpc_id               = var.vpc_id
  deregistration_delay = 30
  health_check {
    path                = "/healthz"
    matcher             = "200"
    interval            = 15
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }
  tags = merge(local.tags, { "aig:service" = replace(each.key, "_", "-") })
}

resource "aws_lb_listener" "https_public" {
  load_balancer_arn = aws_lb.public.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.ssl_policy
  certificate_arn   = var.certificate_arn
  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = "not found"
      status_code  = "404"
    }
  }
  tags = local.tags
}

resource "aws_lb_listener" "https_internal" {
  load_balancer_arn = aws_lb.internal.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.ssl_policy
  certificate_arn   = var.certificate_arn
  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = "not found"
      status_code  = "404"
    }
  }
  tags = local.tags
}

resource "aws_lb_listener" "http_redirect" {
  load_balancer_arn = aws_lb.public.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
  tags = local.tags
}

resource "aws_lb_listener_rule" "host" {
  for_each     = local.target_groups
  listener_arn = each.value.lb == "public" ? aws_lb_listener.https_public.arn : aws_lb_listener.https_internal.arn
  priority     = index(keys(local.target_groups), each.key) + 10
  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.this[each.key].arn
  }
  condition {
    host_header {
      values = [each.value.host]
    }
  }
  tags = local.tags
}
