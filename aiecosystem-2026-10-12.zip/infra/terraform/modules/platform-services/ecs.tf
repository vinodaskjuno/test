# ECS Fargate (ARM64/Graviton): platform-api, telemetry-bridge, cache-compress and web, plus the
# one-off platform-api migration task, the platform-api daily invocation purge task and the
# telemetry-bridge daily reconcile task.

resource "aws_ecs_cluster" "this" {
  name = var.name
  setting {
    name  = "containerInsights"
    value = "enhanced"
  }
  tags = local.tags
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE"]
  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
  }
}

resource "aws_cloudwatch_log_group" "service" {
  for_each          = toset(["platform-api", "telemetry-bridge", "cache-compress", "web"])
  name              = "/aig/${var.env}/${each.value}"
  retention_in_days = var.log_retention_days
  kms_key_id        = var.kms_key_arn
  tags              = merge(local.tags, { "aig:service" = each.value })
}

locals {
  log_config = {
    for svc, lg in aws_cloudwatch_log_group.service : svc => {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = lg.name
        "awslogs-region"        = local.region
        "awslogs-stream-prefix" = svc
        "mode"                  = "non-blocking"
      }
    }
  }

  env_list = {
    platform_api     = [for k, v in local.platform_api_environment : { name = k, value = v }]
    telemetry_bridge = [for k, v in local.telemetry_bridge_environment : { name = k, value = v }]
    cache_compress   = [for k, v in local.cache_compress_environment : { name = k, value = v }]
    web              = [for k, v in local.web_environment : { name = k, value = v }]
  }

  # --- platform-api -------------------------------------------------------------------------
  platform_api_prepare = merge(local.hardened, {
    name        = "prepare"
    image       = var.images.platform_api
    essential   = false
    user        = "0" # writes into root-owned task volumes only; every capability is dropped
    entryPoint  = ["python", "-c", local.prepare_script]
    command     = []
    environment = [{ name = "AIG_RENDERED_FILES", value = jsonencode(local.platform_api_rendered_files) }, { name = "AIG_WRITABLE_DIRS", value = "/tmp" }]
    mountPoints = [
      { sourceVolume = "config", containerPath = "/app/config-rendered", readOnly = false },
      { sourceVolume = "tmp", containerPath = "/tmp", readOnly = false },
    ]
    logConfiguration = local.log_config["platform-api"]
  })

  platform_api_container = merge(local.hardened, {
    name         = "platform-api"
    image        = var.images.platform_api
    essential    = true
    user         = "10001"
    portMappings = [{ containerPort = 8080, protocol = "tcp", name = "http" }]
    environment  = local.env_list.platform_api
    secrets      = local.db_secrets
    entryPoint   = ["python", "-c", local.db_url_launcher, "AIG_DATABASE_URL"]
    command = ["uvicorn", "platform_api.main:create_app", "--factory", "--host", "0.0.0.0", "--port", "8080",
    "--proxy-headers", "--forwarded-allow-ips", local.forwarded_allowed]
    mountPoints = [
      { sourceVolume = "config", containerPath = "/app/config-rendered", readOnly = true },
      { sourceVolume = "tmp", containerPath = "/tmp", readOnly = false },
    ]
    dependsOn        = [{ containerName = "prepare", condition = "SUCCESS" }]
    healthCheck      = local.python_healthcheck.platform_api
    stopTimeout      = 30
    logConfiguration = local.log_config["platform-api"]
  })

  # --- telemetry-bridge ---------------------------------------------------------------------
  bridge_scratch = ["/app/state", "/app/reports", "/app/eval-datasets", "/tmp"]
  bridge_mounts  = [for p in local.bridge_scratch : { sourceVolume = replace(trimprefix(p, "/"), "/", "-"), containerPath = p, readOnly = false }]

  bridge_prepare = merge(local.hardened, {
    name             = "prepare"
    image            = var.images.telemetry_bridge
    essential        = false
    user             = "0"
    entryPoint       = ["python", "-c", local.prepare_script]
    command          = []
    environment      = [{ name = "AIG_WRITABLE_DIRS", value = join(",", local.bridge_scratch) }]
    mountPoints      = local.bridge_mounts
    logConfiguration = local.log_config["telemetry-bridge"]
  })

  bridge_container = merge(local.hardened, {
    name             = "telemetry-bridge"
    image            = var.images.telemetry_bridge
    essential        = true
    user             = "10001"
    portMappings     = [{ containerPort = 8095, protocol = "tcp", name = "http" }]
    environment      = local.env_list.telemetry_bridge
    secrets          = local.telemetry_bridge_secrets
    entryPoint       = ["python", "-c", local.db_url_launcher, "AIG_BRIDGE_DATABASE_URL"]
    command          = ["telemetry-bridge", "serve", "--host", "0.0.0.0", "--port", "8095", "--worker"]
    mountPoints      = local.bridge_mounts
    dependsOn        = [{ containerName = "prepare", condition = "SUCCESS" }]
    healthCheck      = local.python_healthcheck.telemetry_bridge
    stopTimeout      = 60
    logConfiguration = local.log_config["telemetry-bridge"]
  })

  # Daily invocation retention (schedule.tf): the platform-api container (same env, DB secrets and
  # DB URL launcher) with only the command and the two retention env vars changed.
  invocation_purge_command = ["aig-platform-api", "invocations", "purge"]
  invocation_purge_retention_env = {
    AIG_AGENT_INVOCATION_RETENTION_DAYS = tostring(var.agent_invocation_retention_days)
    AIG_AGENT_OUTPUT_RETENTION_DAYS     = tostring(var.agent_output_retention_days)
  }
  invocation_purge_container = merge(local.platform_api_container, {
    portMappings = []
    healthCheck  = null
    command      = local.invocation_purge_command
    environment = concat(
      [for e in local.env_list.platform_api : e if !contains(keys(local.invocation_purge_retention_env), e.name)],
      [for k, v in local.invocation_purge_retention_env : { name = k, value = v }],
    )
  })

  reconcile_command = concat(["telemetry-bridge", "reconcile"], var.reconcile_dry_run ? ["--dry-run"] : [])

  # --- cache-compress -----------------------------------------------------------------------
  cache_compress_container = merge(local.hardened, {
    name             = "cache-compress"
    image            = var.images.cache_compress
    essential        = true
    user             = "10001:10001"
    portMappings     = [{ containerPort = 8090, protocol = "tcp", name = "http" }]
    environment      = local.env_list.cache_compress
    mountPoints      = [{ sourceVolume = "tmp", containerPath = "/tmp", readOnly = false }]
    healthCheck      = local.python_healthcheck.cache_compress
    stopTimeout      = 120 # let streaming responses finish
    logConfiguration = local.log_config["cache-compress"]
  })

  # --- web ----------------------------------------------------------------------------------
  # nginx-unprivileged renders its config into /etc/nginx/conf.d at start and needs writable
  # cache/tmp dirs; the prepare step copies the built SPA plus this env's config.json into a task
  # volume served read-only (the same image digest runs in every env).
  web_prepare = merge(local.hardened, {
    name       = "prepare"
    image      = var.images.web
    essential  = false
    user       = "0"
    entryPoint = ["sh", "-c"]
    command = [join(" && ", [
      "cp -R /usr/share/nginx/html/. /srv/www/",
      "printf '%s' \"$AIG_WEB_CONFIG_JSON\" > /srv/www/config.json",
      "chmod 0644 /srv/www/config.json",
      "chmod 1777 /w/conf.d /w/cache /w/tmp",
    ])]
    environment = [{ name = "AIG_WEB_CONFIG_JSON", value = jsonencode(var.web_config) }]
    mountPoints = [
      { sourceVolume = "www", containerPath = "/srv/www", readOnly = false },
      { sourceVolume = "nginx-conf", containerPath = "/w/conf.d", readOnly = false },
      { sourceVolume = "nginx-cache", containerPath = "/w/cache", readOnly = false },
      { sourceVolume = "tmp", containerPath = "/w/tmp", readOnly = false },
    ]
    logConfiguration = local.log_config["web"]
  })

  web_container = merge(local.hardened, {
    name         = "web"
    image        = var.images.web
    essential    = true
    user         = "101"
    portMappings = [{ containerPort = 8080, protocol = "tcp", name = "http" }]
    environment  = [for e in local.env_list.web : e if e.name != "AIG_WEB_CONFIG_JSON"]
    mountPoints = [
      { sourceVolume = "www", containerPath = "/usr/share/nginx/html", readOnly = true },
      { sourceVolume = "nginx-conf", containerPath = "/etc/nginx/conf.d", readOnly = false },
      { sourceVolume = "nginx-cache", containerPath = "/var/cache/nginx", readOnly = false },
      { sourceVolume = "tmp", containerPath = "/tmp", readOnly = false },
    ]
    dependsOn = [{ containerName = "prepare", condition = "SUCCESS" }]
    healthCheck = {
      command     = ["CMD-SHELL", "wget -qO- http://127.0.0.1:8080/healthz || exit 1"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 15
    }
    logConfiguration = local.log_config["web"]
  })

  # Optional job tasks are dropped when switched off (no idle task definition revisions).
  task_enabled = { platform_api_invocation_purge = var.invocation_purge_enabled }
  task_defs    = { for k, v in local.all_task_defs : k => v if lookup(local.task_enabled, k, true) }
  all_task_defs = {
    platform_api = {
      family     = "${var.name}-platform-api"
      task_role  = aws_iam_role.task["platform_api"].arn
      containers = [local.platform_api_prepare, local.platform_api_container]
      volumes    = ["config", "tmp"]
    }
    platform_api_migrate = {
      family    = "${var.name}-platform-api-migrate"
      task_role = aws_iam_role.task["platform_api"].arn
      containers = [local.platform_api_prepare, merge(local.platform_api_container, {
        portMappings = []
        healthCheck  = null
        command      = ["aig-platform-api", "db", "upgrade"]
      })]
      volumes = ["config", "tmp"]
    }
    platform_api_invocation_purge = {
      family     = "${var.name}-platform-api-invocation-purge"
      task_role  = aws_iam_role.task["platform_api"].arn
      containers = [local.platform_api_prepare, local.invocation_purge_container]
      volumes    = ["config", "tmp"]
    }
    telemetry_bridge = {
      family     = "${var.name}-telemetry-bridge"
      task_role  = aws_iam_role.task["telemetry_bridge"].arn
      containers = [local.bridge_prepare, local.bridge_container]
      volumes    = [for m in local.bridge_mounts : m.sourceVolume]
    }
    telemetry_bridge_reconcile = {
      family    = "${var.name}-telemetry-bridge-reconcile"
      task_role = aws_iam_role.task["telemetry_bridge"].arn
      containers = [local.bridge_prepare, merge(local.bridge_container, {
        portMappings = []
        healthCheck  = null
        command      = local.reconcile_command
      })]
      volumes = [for m in local.bridge_mounts : m.sourceVolume]
    }
    cache_compress = {
      family     = "${var.name}-cache-compress"
      task_role  = aws_iam_role.task["cache_compress"].arn
      containers = [local.cache_compress_container]
      volumes    = ["tmp"]
    }
    web = {
      family     = "${var.name}-web"
      task_role  = aws_iam_role.task["web"].arn
      containers = [local.web_prepare, local.web_container]
      volumes    = ["www", "nginx-conf", "nginx-cache", "tmp"]
    }
  }

  task_size = {
    platform_api                  = var.service_sizing.platform_api
    platform_api_migrate          = var.service_sizing.platform_api
    platform_api_invocation_purge = var.service_sizing.platform_api
    telemetry_bridge              = var.service_sizing.telemetry_bridge
    telemetry_bridge_reconcile    = var.service_sizing.telemetry_bridge
    cache_compress                = var.service_sizing.cache_compress
    web                           = var.service_sizing.web
  }
}

resource "aws_ecs_task_definition" "this" {
  for_each                 = local.task_defs
  family                   = each.value.family
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = tostring(local.task_size[each.key].cpu)
  memory                   = tostring(local.task_size[each.key].memory)
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = each.value.task_role
  container_definitions    = jsonencode(each.value.containers) # null fields (e.g. healthCheck on job tasks) mean "unset"

  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "ARM64"
  }

  dynamic "volume" {
    for_each = toset(each.value.volumes)
    content {
      name = volume.value
    }
  }

  tags = merge(local.tags, { "aig:task" = each.key })
}

# --- Services ---------------------------------------------------------------------------------
locals {
  services = {
    platform_api = {
      name     = "platform-api"
      port     = 8080
      tg       = aws_lb_target_group.this["platform_api"].arn
      sg       = aws_security_group.service["platform_api"].id
      internet = true # Entra ID JWKS (firewall mode)
    }
    telemetry_bridge = {
      name     = "telemetry-bridge"
      port     = 8095
      tg       = aws_lb_target_group.this["telemetry_bridge"].arn
      sg       = aws_security_group.service["telemetry_bridge"].id
      internet = true # Slack / PagerDuty / SMTP alerts (firewall mode)
    }
    cache_compress = {
      name     = "cache-compress"
      port     = 8090
      tg       = aws_lb_target_group.this["cache_compress"].arn
      sg       = aws_security_group.service["cache_compress"].id
      internet = true # provider APIs behind Portkey (firewall mode)
    }
    web = {
      name     = "web"
      port     = 8080
      tg       = aws_lb_target_group.this["web"].arn
      sg       = aws_security_group.service["web"].id
      internet = false
    }
  }
}

resource "aws_ecs_service" "this" {
  for_each                          = local.services
  name                              = each.value.name
  cluster                           = aws_ecs_cluster.this.id
  task_definition                   = aws_ecs_task_definition.this[each.key].arn
  desired_count                     = var.service_sizing[each.key].desired
  launch_type                       = "FARGATE"
  platform_version                  = "LATEST"
  enable_execute_command            = false
  propagate_tags                    = "SERVICE"
  health_check_grace_period_seconds = 60
  wait_for_steady_state             = true

  network_configuration {
    subnets          = var.private_subnet_ids
    assign_public_ip = false
    security_groups  = concat([each.value.sg], var.egress_security_group_ids, each.value.internet ? local.internet_sg : [])
  }

  load_balancer {
    target_group_arn = each.value.tg
    container_name   = each.value.name
    container_port   = each.value.port
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  lifecycle {
    ignore_changes = [desired_count] # owned by autoscaling
  }

  depends_on = [aws_lb_listener.https_public, aws_lb_listener.https_internal]
  tags       = merge(local.tags, { "aig:service" = each.value.name })
}

resource "aws_appautoscaling_target" "this" {
  for_each           = { for k, v in local.services : k => v if var.service_sizing[k].max > var.service_sizing[k].min }
  service_namespace  = "ecs"
  resource_id        = "service/${aws_ecs_cluster.this.name}/${aws_ecs_service.this[each.key].name}"
  scalable_dimension = "ecs:service:DesiredCount"
  min_capacity       = var.service_sizing[each.key].min
  max_capacity       = var.service_sizing[each.key].max
}

resource "aws_appautoscaling_policy" "cpu" {
  for_each           = aws_appautoscaling_target.this
  name               = "${var.name}-${local.services[each.key].name}-cpu"
  policy_type        = "TargetTrackingScaling"
  service_namespace  = each.value.service_namespace
  resource_id        = each.value.resource_id
  scalable_dimension = each.value.scalable_dimension
  target_tracking_scaling_policy_configuration {
    target_value       = var.cpu_target_percent
    scale_in_cooldown  = 300
    scale_out_cooldown = 60
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
  }
}
