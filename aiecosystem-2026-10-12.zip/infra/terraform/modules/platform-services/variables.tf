variable "env" {
  description = "dev, stage or prod (AIG_ENV of every service)."
  type        = string
  validation {
    condition     = contains(["dev", "stage", "prod"], var.env)
    error_message = "env must be dev, stage or prod."
  }
}

variable "name" {
  description = "Name prefix, e.g. aig-dev."
  type        = string
}

# --- Network ----------------------------------------------------------------------------------
variable "vpc_id" {
  type = string
}

variable "vpc_cidr" {
  type = string
}

variable "private_subnet_ids" {
  description = "Subnets for the ECS tasks, RDS and the internal ALB."
  type        = list(string)
}

variable "alb_subnet_ids" {
  description = "Subnets for the portal/API ALB: private subnets when alb_internal = true (default), public subnets otherwise."
  type        = list(string)
}

variable "alb_subnet_cidrs" {
  description = "CIDRs of alb_subnet_ids. platform-api trusts X-Forwarded-For/-Proto only from them (FORWARDED_ALLOW_IPS), never \"*\"."
  type        = list(string)
}

variable "internal_alb_subnet_cidrs" {
  description = "CIDRs of the private subnets (the internal ALB lives there); trusted proxies for platform-api too."
  type        = list(string)
}

variable "alb_internal" {
  description = "Portal/API ALB is internal (reached over the corporate network). false = internet-facing."
  type        = bool
  default     = true
}

variable "alb_ingress_cidrs" {
  description = "Who may reach the portal/API ALB on 443 (corporate ranges / VPN)."
  type        = list(string)
}

variable "internal_alb_ingress_cidrs" {
  description = "Extra sources for the internal ALB (telemetry-bridge push, cache-compress): the self-hosted Portkey gateway CIDRs."
  type        = list(string)
  default     = []
}

variable "egress_security_group_ids" {
  description = "Shared egress allow-list security group(s) from the network module (HTTPS only to Portkey, Fiddler, VPC endpoints)."
  type        = list(string)
}

variable "internet_egress_security_group_id" {
  description = "Firewall mode: security group whose HTTPS egress is filtered by the Network Firewall domain allow-list (Entra ID, provider APIs, Slack...). null in cidr mode."
  type        = string
  default     = null
}

variable "certificate_arn" {
  description = "ACM certificate covering every hostname below (both ALBs terminate TLS with it)."
  type        = string
}

variable "ssl_policy" {
  type    = string
  default = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

variable "alb_access_logs_bucket" {
  description = "S3 bucket for ALB access logs (null = off)."
  type        = string
  default     = null
}

# --- Hostnames --------------------------------------------------------------------------------
variable "web_hostname" {
  description = "Portal host, e.g. aig-portal-dev.example.com."
  type        = string
}

variable "api_hostname" {
  description = "platform-api host, e.g. aig-api-dev.example.com (AIG_PUBLIC_BASE_URL = https://<this>)."
  type        = string
}

variable "bridge_hostname" {
  description = "telemetry-bridge host on the internal ALB."
  type        = string
}

variable "cache_compress_hostname" {
  description = "cache-compress host on the internal ALB (backend/gateway envs: cache_compress.host)."
  type        = string
}

variable "platform_api_internal_url" {
  description = "URL services in the VPC use for platform-api (telemetry-bridge reconciliation). Default https://<api_hostname>; set it when the portal ALB is internet-facing."
  type        = string
  default     = null
}

# --- Images and secrets -----------------------------------------------------------------------
variable "images" {
  description = "Image per service, pinned by digest (<repo>@sha256:<64 hex>). The deploy workflow passes the digests it built and checked."
  type = object({
    platform_api     = string
    telemetry_bridge = string
    cache_compress   = string
    web              = string
  })
  validation {
    condition     = alltrue([for v in values(var.images) : can(regex("@sha256:[0-9a-f]{64}$", v))])
    error_message = "Every image must be pinned by digest (...@sha256:<64 hex>); tags are refused."
  }
}

variable "kms_key_arn" {
  description = "Environment KMS key (RDS storage, RDS master secret, log groups)."
  type        = string
}

variable "platform_api_secret_arn" {
  description = "ARN of aig/<env>/platform-api (platform-api reads it itself, AIG_SECRET_PROVIDER=aws)."
  type        = string
}

variable "telemetry_bridge_secret_arn" {
  description = "ARN of aig/<env>/telemetry-bridge (keys injected into the containers by ECS)."
  type        = string
}

variable "telemetry_bridge_secret_keys" {
  description = "JSON keys of aig/<env>/telemetry-bridge, each injected as the env var of the same name."
  type        = list(string)
}

# --- Service configuration (non-secret) -------------------------------------------------------
variable "platform_api_config" {
  description = "Content of config/environments/<env>.yaml for platform-api (portkey/fiddler URLs, OIDC issuer/audience/JWKS, web origins...). Rendered into the task at start, so the same image digest runs in every env."
  type        = any
}

variable "platform_api_users_yaml" {
  description = "Optional user directory (config/users.yaml content: tier/team/roles per user). null = every user gets default_user_tier."
  type        = string
  default     = null
}

variable "platform_api_environment" {
  description = "Extra non-secret platform-api env vars (AIG_MCP_SYNC, AIG_FIDDLER_AUTOPROVISION, ...)."
  type        = map(string)
  default     = {}
}

variable "telemetry_bridge_environment" {
  description = "Non-secret telemetry-bridge env vars: FIDDLER_URL, AIG_PORTKEY_ADMIN_URL, AIG_PORTKEY_WORKSPACE_ID, AIG_BRIDGE_PULL_MODE, ... (backend/contracts/env-vars.md)."
  type        = map(string)
  default     = {}
}

variable "cache_compress_upstreams" {
  description = "AIG_CC_UPSTREAMS: route -> provider base URL (anthropic, openai-a, openai-b). https only outside local."
  type        = map(string)
}

variable "web_config" {
  description = "web config.json for this env (apiBaseUrl, oidc authority/clientId/scopes/redirects). Served as /config.json."
  type        = any
}

variable "web_idp_origin" {
  description = "AIG_IDP_ORIGIN for the portal's CSP."
  type        = string
  default     = "https://login.microsoftonline.com"
}

variable "reconcile_schedule" {
  description = "EventBridge Scheduler expression for `telemetry-bridge reconcile` (daily; checks the previous UTC day)."
  type        = string
  default     = "cron(30 1 * * ? *)"
}

variable "reconcile_dry_run" {
  description = "Report-only reconciliation (no suspensions), for the first rollout of an env."
  type        = bool
  default     = false
}

variable "invocation_purge_enabled" {
  description = "Run `aig-platform-api invocations purge` daily (agent invocation retention). false = no task definition, scheduler role or schedule."
  type        = bool
  default     = true
}

variable "invocation_purge_schedule" {
  description = "EventBridge Scheduler expression for `aig-platform-api invocations purge` (daily, UTC)."
  type        = string
  default     = "cron(30 3 * * ? *)"
}

variable "agent_invocation_retention_days" {
  description = "AIG_AGENT_INVOCATION_RETENTION_DAYS: invocation metadata older than this many days is purged."
  type        = number
  default     = 90
  validation {
    condition     = var.agent_invocation_retention_days >= 1 && floor(var.agent_invocation_retention_days) == var.agent_invocation_retention_days
    error_message = "agent_invocation_retention_days must be a whole number >= 1."
  }
}

variable "agent_output_retention_days" {
  description = "AIG_AGENT_OUTPUT_RETENTION_DAYS: background invocation outputs older than this many days are purged (<= agent_invocation_retention_days)."
  type        = number
  default     = 30
  validation {
    condition     = var.agent_output_retention_days >= 1 && floor(var.agent_output_retention_days) == var.agent_output_retention_days
    error_message = "agent_output_retention_days must be a whole number >= 1."
  }
  validation {
    condition     = var.agent_output_retention_days <= var.agent_invocation_retention_days
    error_message = "agent_output_retention_days must not exceed agent_invocation_retention_days."
  }
}

# --- Sizing -----------------------------------------------------------------------------------
variable "service_sizing" {
  description = "Fargate size and autoscaling bounds per service (cpu units, memory MiB)."
  type = map(object({
    cpu     = number
    memory  = number
    desired = number
    min     = number
    max     = number
  }))
  default = {
    platform_api     = { cpu = 512, memory = 1024, desired = 2, min = 2, max = 6 }
    telemetry_bridge = { cpu = 512, memory = 1024, desired = 1, min = 1, max = 1 } # one pull worker
    cache_compress   = { cpu = 512, memory = 1024, desired = 2, min = 2, max = 6 }
    web              = { cpu = 256, memory = 512, desired = 2, min = 2, max = 4 }
  }
}

variable "cpu_target_percent" {
  description = "Target-tracking CPU utilisation for autoscaling."
  type        = number
  default     = 60
}

# --- Database ---------------------------------------------------------------------------------
variable "db_instance_class" {
  type    = string
  default = "db.t4g.medium"
}

variable "db_engine_version" {
  description = "Postgres major version (minor upgrades are automatic)."
  type        = string
  default     = "16"
}

variable "db_allocated_storage" {
  type    = number
  default = 50
}

variable "db_max_allocated_storage" {
  type    = number
  default = 200
}

variable "db_multi_az" {
  type    = bool
  default = true
}

variable "db_deletion_protection" {
  type    = bool
  default = true
}

variable "db_backup_retention_days" {
  type    = number
  default = 14
}

variable "db_name" {
  description = "Database shared by platform-api (Alembic, schema at head) and telemetry-bridge (bridge_* tables)."
  type        = string
  default     = "aig_platform"
}

variable "log_retention_days" {
  type    = number
  default = 90
}

variable "tags" {
  type    = map(string)
  default = {}
}

# --- Agent invocation (registry v2) ------------------------------------------------------------
variable "agent_invocation_enabled" {
  description = "Let platform-api invoke registered agents: bedrock-agentcore:InvokeAgentRuntime on this env's runtimes tagged <agent_runtime_tag_key>=true, and read aig/<env>/agents/*/invoke-auth (HTTPS agents' credentials)."
  type        = bool
  default     = true
}

variable "agent_runtime_tag_key" {
  description = "Tag that marks an AgentCore runtime as invocable through platform-api (set to \"true\" by modules/agentcore-runtime)."
  type        = string
  default     = "aig:registered"
  validation {
    condition     = can(regex("^aig:[a-z0-9_.-]{1,60}$", var.agent_runtime_tag_key))
    error_message = "agent_runtime_tag_key must be an aig:-prefixed tag key."
  }
}
