data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_partition" "current" {}

locals {
  region    = data.aws_region.current.region
  account   = data.aws_caller_identity.current.account_id
  partition = data.aws_partition.current.partition
  tags      = merge(var.tags, { "aig:module" = "platform-services", "aig:env" = var.env })

  api_url           = "https://${var.api_hostname}"
  api_internal_url  = coalesce(var.platform_api_internal_url, local.api_url)
  bridge_url        = "https://${var.bridge_hostname}"
  forwarded_allowed = join(",", distinct(concat(var.alb_subnet_cidrs, var.internal_alb_subnet_cidrs)))

  # Services that need FQDN egress (only usable in firewall mode): platform-api (Entra ID JWKS),
  # telemetry-bridge (Slack/PagerDuty/SMTP alerts), cache-compress (provider APIs).
  internet_sg = var.internet_egress_security_group_id == null ? [] : [var.internet_egress_security_group_id]

  # Composes a Postgres URL from the RDS-managed master secret (username/password injected by ECS
  # as AIG_DB_USERNAME/AIG_DB_PASSWORD) and execs the real command. URL-encodes the credentials and
  # removes the parts from the environment. Usage: python -c LAUNCHER <TARGET_ENV_VAR> <cmd> [args...]
  db_url_launcher = <<-PY
    import os, sys, urllib.parse as u
    e = os.environ
    user = u.quote(e.pop("AIG_DB_USERNAME"), safe="")
    password = u.quote(e.pop("AIG_DB_PASSWORD"), safe="")
    e[sys.argv[1]] = "postgresql+psycopg://%s:%s@%s:%s/%s?sslmode=require" % (user, password, e["AIG_DB_HOST"], e.get("AIG_DB_PORT", "5432"), e["AIG_DB_NAME"])
    os.execvp(sys.argv[2], sys.argv[2:])
  PY

  # Init container for the Python images: writes per-env config files (same image digest in every
  # env) and makes the scratch volumes writable for the non-root app user. Runs before the app.
  prepare_script = <<-PY
    import json, os, pathlib
    for path, content in json.loads(os.environ.get("AIG_RENDERED_FILES", "{}")).items():
        f = pathlib.Path(path)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(content)
        f.chmod(0o644)
    for d in filter(None, os.environ.get("AIG_WRITABLE_DIRS", "").split(",")):
        pathlib.Path(d).mkdir(parents=True, exist_ok=True)
        os.chmod(d, 0o1777)
  PY

  db_environment = {
    AIG_DB_HOST = aws_db_instance.this.address
    AIG_DB_PORT = tostring(aws_db_instance.this.port)
    AIG_DB_NAME = var.db_name
  }
  db_secrets = [
    { name = "AIG_DB_USERNAME", valueFrom = "${aws_db_instance.this.master_user_secret[0].secret_arn}:username::" },
    { name = "AIG_DB_PASSWORD", valueFrom = "${aws_db_instance.this.master_user_secret[0].secret_arn}:password::" },
  ]

  platform_api_environment = merge({
    AIG_ENV                  = var.env
    AIG_SECRET_PROVIDER      = "aws"
    AIG_AUTH_MODE            = "oidc"
    AIG_PUBLIC_BASE_URL      = local.api_url
    AIG_CONFIG_DIR           = "/app/config-rendered"
    AIG_DB_AUTO_MIGRATE      = "false" # migrations run as a one-off task before rollout
    AIG_TELEMETRY_BRIDGE_URL = local.bridge_url
    FORWARDED_ALLOW_IPS      = local.forwarded_allowed
    AWS_REGION               = local.region
    AWS_DEFAULT_REGION       = local.region
    }, var.platform_api_users_yaml == null ? {} : { AIG_USERS_FILE = "/app/config-rendered/users.yaml" },
  var.platform_api_environment, local.db_environment)

  platform_api_rendered_files = merge(
    { "/app/config-rendered/environments/${var.env}.yaml" = yamlencode(var.platform_api_config) },
    var.platform_api_users_yaml == null ? {} : { "/app/config-rendered/users.yaml" = var.platform_api_users_yaml },
  )

  telemetry_bridge_environment = merge({
    AIG_ENV              = var.env
    AIG_PLATFORM_API_URL = local.api_internal_url
    AIG_BRIDGE_WORKER    = "true"
    AWS_REGION           = local.region
  }, var.telemetry_bridge_environment, local.db_environment)

  telemetry_bridge_secrets = concat(
    [for k in var.telemetry_bridge_secret_keys : { name = k, valueFrom = "${var.telemetry_bridge_secret_arn}:${k}::" }],
    local.db_secrets,
  )

  cache_compress_environment = {
    AIG_ENV           = var.env
    AIG_CC_UPSTREAMS  = jsonencode(var.cache_compress_upstreams)
    AIG_CC_COMPRESSOR = "noop"
    PORT              = "8090"
  }

  web_environment = {
    AIG_API_ORIGIN      = local.api_url
    AIG_WS_ORIGIN       = "wss://${var.api_hostname}"
    AIG_IDP_ORIGIN      = var.web_idp_origin
    AIG_WEB_CONFIG_JSON = jsonencode(var.web_config)
  }

  python_healthcheck = {
    for svc, port in { platform_api = 8080, telemetry_bridge = 8095, cache_compress = 8090 } : svc => {
      command                       = ["CMD", "python", "-c", "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:${port}/healthz', timeout=3).status == 200 else 1)"]
      interval                      = 30
      timeout                       = 5
      retries                       = 3
      startPeriod                   = 30
    }
  }

  # Every container: no privilege escalation, all Linux capabilities dropped, read-only root FS
  # (scratch paths are task volumes), PID 1 init for signal handling.
  hardened = {
    readonlyRootFilesystem = true
    privileged             = false
    linuxParameters = {
      initProcessEnabled = true
      capabilities       = { drop = ["ALL"] }
    }
  }
}
