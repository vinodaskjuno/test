# Daily telemetry-bridge reconciliation (docs/IMPLEMENTATION_PLAN.md Phase 3): agents with Portkey
# traffic but no Fiddler traces are suspended. Runs the same image as the bridge service as an ECS
# task from EventBridge Scheduler (backend/telemetry-bridge/deploy/schedules.example.yaml).

data "aws_iam_policy_document" "scheduler_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["scheduler.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [local.account]
    }
  }
}

resource "aws_iam_role" "scheduler" {
  name               = "${var.name}-bridge-scheduler"
  assume_role_policy = data.aws_iam_policy_document.scheduler_assume.json
  tags               = local.tags
}

data "aws_iam_policy_document" "scheduler" {
  statement {
    actions   = ["ecs:RunTask"]
    resources = ["${trimsuffix(aws_ecs_task_definition.this["telemetry_bridge_reconcile"].arn, ":${aws_ecs_task_definition.this["telemetry_bridge_reconcile"].revision}")}:*"]
    condition {
      test     = "ArnEquals"
      variable = "ecs:cluster"
      values   = [aws_ecs_cluster.this.arn]
    }
  }
  statement {
    actions   = ["iam:PassRole"]
    resources = [aws_iam_role.execution.arn, aws_iam_role.task["telemetry_bridge"].arn]
    condition {
      test     = "StringLike"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role_policy" "scheduler" {
  name   = "run-reconcile-task"
  role   = aws_iam_role.scheduler.id
  policy = data.aws_iam_policy_document.scheduler.json
}

resource "aws_scheduler_schedule" "reconcile" {
  name                         = "${var.name}-bridge-reconcile"
  description                  = "telemetry-bridge reconcile${var.reconcile_dry_run ? " --dry-run" : ""} (daily, previous UTC day)"
  schedule_expression          = var.reconcile_schedule
  schedule_expression_timezone = "UTC"

  flexible_time_window {
    mode = "OFF"
  }

  target {
    arn      = aws_ecs_cluster.this.arn
    role_arn = aws_iam_role.scheduler.arn

    ecs_parameters {
      task_definition_arn = aws_ecs_task_definition.this["telemetry_bridge_reconcile"].arn
      launch_type         = "FARGATE"
      platform_version    = "LATEST"
      task_count          = 1
      propagate_tags      = "TASK_DEFINITION"
      network_configuration {
        subnets          = var.private_subnet_ids
        security_groups  = concat([aws_security_group.service["telemetry_bridge"].id], var.egress_security_group_ids, local.internet_sg)
        assign_public_ip = false
      }
    }

    retry_policy {
      maximum_retry_attempts       = 2
      maximum_event_age_in_seconds = 3600
    }
  }
}

# --- Daily agent invocation retention ---------------------------------------------------------
# `aig-platform-api invocations purge` deletes invocation metadata older than
# agent_invocation_retention_days and background outputs older than agent_output_retention_days.
# Same pattern as reconcile: its own task definition (platform-api container, command and the two
# retention env vars overridden), its own scheduler role limited to that task family on this cluster.

resource "aws_iam_role" "invocation_purge_scheduler" {
  count              = var.invocation_purge_enabled ? 1 : 0
  name               = "${var.name}-purge-scheduler"
  assume_role_policy = data.aws_iam_policy_document.scheduler_assume.json
  tags               = local.tags
}

data "aws_iam_policy_document" "invocation_purge_scheduler" {
  count = var.invocation_purge_enabled ? 1 : 0
  statement {
    actions   = ["ecs:RunTask"]
    resources = ["${trimsuffix(aws_ecs_task_definition.this["platform_api_invocation_purge"].arn, ":${aws_ecs_task_definition.this["platform_api_invocation_purge"].revision}")}:*"]
    condition {
      test     = "ArnEquals"
      variable = "ecs:cluster"
      values   = [aws_ecs_cluster.this.arn]
    }
  }
  statement {
    actions   = ["iam:PassRole"]
    resources = [aws_iam_role.execution.arn, aws_iam_role.task["platform_api"].arn]
    condition {
      test     = "StringLike"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role_policy" "invocation_purge_scheduler" {
  count  = var.invocation_purge_enabled ? 1 : 0
  name   = "run-invocation-purge-task"
  role   = aws_iam_role.invocation_purge_scheduler[0].id
  policy = data.aws_iam_policy_document.invocation_purge_scheduler[0].json
}

resource "aws_scheduler_schedule" "invocation_purge" {
  count                        = var.invocation_purge_enabled ? 1 : 0
  name                         = "${var.name}-invocation-purge"
  description                  = "aig-platform-api invocations purge (daily; metadata > ${var.agent_invocation_retention_days}d, background outputs > ${var.agent_output_retention_days}d)"
  schedule_expression          = var.invocation_purge_schedule
  schedule_expression_timezone = "UTC"

  flexible_time_window {
    mode = "OFF"
  }

  target {
    arn      = aws_ecs_cluster.this.arn
    role_arn = aws_iam_role.invocation_purge_scheduler[0].arn

    ecs_parameters {
      task_definition_arn = aws_ecs_task_definition.this["platform_api_invocation_purge"].arn
      launch_type         = "FARGATE"
      platform_version    = "LATEST"
      task_count          = 1
      propagate_tags      = "TASK_DEFINITION"
      network_configuration {
        subnets          = var.private_subnet_ids
        security_groups  = concat([aws_security_group.service["platform_api"].id], var.egress_security_group_ids)
        assign_public_ip = false
      }
    }

    retry_policy {
      maximum_retry_attempts       = 2
      maximum_event_age_in_seconds = 3600
    }
  }
}
