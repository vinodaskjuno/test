# Postgres for platform-api (Alembic-managed schema) and telemetry-bridge (bridge_* tables):
# private, encrypted with the env KMS key, TLS enforced, master password generated and rotated by
# RDS in Secrets Manager (manage_master_user_password) - it never appears in Terraform state.

resource "aws_db_subnet_group" "this" {
  name       = "${var.name}-platform"
  subnet_ids = var.private_subnet_ids
  tags       = local.tags
}

resource "aws_db_parameter_group" "this" {
  name   = "${var.name}-postgres${var.db_engine_version}"
  family = "postgres${var.db_engine_version}"
  parameter {
    name  = "rds.force_ssl"
    value = "1"
  }
  parameter {
    name  = "log_min_duration_statement"
    value = "1000"
  }
  tags = local.tags
}

resource "aws_security_group" "db" {
  name        = "${var.name}-platform-db"
  description = "Postgres: only from platform-api and telemetry-bridge tasks"
  vpc_id      = var.vpc_id
  tags        = merge(local.tags, { Name = "${var.name}-platform-db" })
}

resource "aws_vpc_security_group_ingress_rule" "db" {
  for_each                     = toset(["platform_api", "telemetry_bridge"])
  security_group_id            = aws_security_group.db.id
  description                  = "Postgres from ${replace(each.value, "_", "-")}"
  ip_protocol                  = "tcp"
  from_port                    = 5432
  to_port                      = 5432
  referenced_security_group_id = aws_security_group.service[each.value].id
}

resource "aws_vpc_security_group_egress_rule" "service_to_db" {
  for_each                     = toset(["platform_api", "telemetry_bridge"])
  security_group_id            = aws_security_group.service[each.value].id
  description                  = "Postgres"
  ip_protocol                  = "tcp"
  from_port                    = 5432
  to_port                      = 5432
  referenced_security_group_id = aws_security_group.db.id
}

resource "aws_db_instance" "this" {
  identifier     = "${var.name}-platform"
  engine         = "postgres"
  engine_version = var.db_engine_version
  instance_class = var.db_instance_class
  db_name        = var.db_name
  username       = "aig_admin"
  port           = 5432

  manage_master_user_password   = true
  master_user_secret_kms_key_id = var.kms_key_arn

  allocated_storage     = var.db_allocated_storage
  max_allocated_storage = var.db_max_allocated_storage
  storage_type          = "gp3"
  storage_encrypted     = true
  kms_key_id            = var.kms_key_arn

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.db.id]
  parameter_group_name   = aws_db_parameter_group.this.name
  publicly_accessible    = false
  multi_az               = var.db_multi_az

  iam_database_authentication_enabled   = true
  auto_minor_version_upgrade            = true
  backup_retention_period               = var.db_backup_retention_days
  copy_tags_to_snapshot                 = true
  deletion_protection                   = var.db_deletion_protection
  skip_final_snapshot                   = !var.db_deletion_protection
  final_snapshot_identifier             = "${var.name}-platform-final"
  performance_insights_enabled          = true
  performance_insights_kms_key_id       = var.kms_key_arn
  enabled_cloudwatch_logs_exports       = ["postgresql"]
  apply_immediately                     = false
  ca_cert_identifier                    = "rds-ca-rsa2048-g1"
  performance_insights_retention_period = 7

  tags = local.tags
}
