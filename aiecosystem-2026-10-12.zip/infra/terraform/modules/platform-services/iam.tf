# IAM: one execution role (image pull, logs, the secrets ECS injects) and one task role per service
# (what the application itself may call). Only platform-api's task role can read
# aig/<env>/platform-api, which it loads itself (AIG_SECRET_PROVIDER=aws).
#
# Agent invocation (registry v2, backend/contracts/agent-invocation.md): platform-api invokes registered
# AgentCore runtimes with its own role (SigV4 InvokeAgentRuntime), limited to runtimes of this
# environment tagged aig:registered=true (modules/agentcore-runtime), and reads HTTPS agents'
# credentials from aig/<env>/agents/<agent_id>/invoke-auth only (never the agents' own runtime secrets).

data "aws_iam_policy_document" "ecs_tasks_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values   = ["arn:${local.partition}:ecs:${local.region}:${local.account}:*"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [local.account]
    }
  }
}

resource "aws_iam_role" "execution" {
  name               = "${var.name}-ecs-execution"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume.json
  tags               = local.tags
}

resource "aws_iam_role_policy_attachment" "execution_managed" {
  role       = aws_iam_role.execution.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

data "aws_iam_policy_document" "execution_secrets" {
  statement {
    sid       = "InjectedSecrets"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [var.telemetry_bridge_secret_arn, aws_db_instance.this.master_user_secret[0].secret_arn]
  }
  statement {
    sid       = "DecryptInjectedSecrets"
    actions   = ["kms:Decrypt"]
    resources = [var.kms_key_arn]
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["secretsmanager.${local.region}.amazonaws.com"]
    }
  }
}

resource "aws_iam_role_policy" "execution_secrets" {
  name   = "injected-secrets"
  role   = aws_iam_role.execution.id
  policy = data.aws_iam_policy_document.execution_secrets.json
}

resource "aws_iam_role" "task" {
  for_each           = toset(["platform_api", "telemetry_bridge", "cache_compress", "web"])
  name               = "${var.name}-${replace(each.value, "_", "-")}-task"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume.json
  tags               = merge(local.tags, { "aig:service" = replace(each.value, "_", "-") })
}

locals {
  agentcore_arn_prefix = "arn:${local.partition}:bedrock-agentcore:${local.region}:${local.account}"
  agent_invoke_resources = [
    "${local.agentcore_arn_prefix}:runtime/*",
    "${local.agentcore_arn_prefix}:runtime/*/runtime-endpoint/*",
  ]
  agent_invoke_auth_secrets = "arn:${local.partition}:secretsmanager:${local.region}:${local.account}:secret:aig/${var.env}/agents/*/invoke-auth-*"
}

data "aws_iam_policy_document" "platform_api_task" {
  statement {
    sid       = "KeyBrokerSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [var.platform_api_secret_arn]
  }
  statement {
    sid       = "DecryptKeyBrokerSecret"
    actions   = ["kms:Decrypt"]
    resources = [var.kms_key_arn]
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["secretsmanager.${local.region}.amazonaws.com"]
    }
  }
  dynamic "statement" {
    for_each = var.agent_invocation_enabled ? [1] : []
    content {
      sid       = "InvokeRegisteredAgentRuntimes"
      actions   = ["bedrock-agentcore:InvokeAgentRuntime"]
      resources = local.agent_invoke_resources
      condition {
        test     = "StringEquals"
        variable = "aws:ResourceTag/${var.agent_runtime_tag_key}"
        values   = ["true"]
      }
      condition {
        test     = "StringEquals"
        variable = "aws:ResourceTag/aig:env"
        values   = [var.env]
      }
    }
  }
  dynamic "statement" {
    for_each = var.agent_invocation_enabled ? [1] : []
    content {
      sid       = "ReadAgentInvokeAuth"
      actions   = ["secretsmanager:GetSecretValue"]
      resources = [local.agent_invoke_auth_secrets]
    }
  }
}

resource "aws_iam_role_policy" "platform_api_task" {
  name   = "key-broker-secret"
  role   = aws_iam_role.task["platform_api"].id
  policy = data.aws_iam_policy_document.platform_api_task.json
}
