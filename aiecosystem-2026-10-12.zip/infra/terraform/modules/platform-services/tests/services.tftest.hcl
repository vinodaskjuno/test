# Offline plan tests (mock AWS provider): images by digest, platform-api proxy/env wiring, health
# checks on /healthz, private encrypted Postgres with an RDS-managed password, daily reconcile and
# daily agent invocation purge.
mock_provider "aws" {
  mock_data "aws_region" {
    defaults = { region = "us-east-1" }
  }
  mock_data "aws_caller_identity" {
    defaults = { account_id = "123456789012" }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{}" }
  }
}

variables {
  env                       = "dev"
  name                      = "aig-dev"
  vpc_id                    = "vpc-test"
  vpc_cidr                  = "10.40.0.0/16"
  private_subnet_ids        = ["subnet-a", "subnet-b"]
  alb_subnet_ids            = ["subnet-a", "subnet-b"]
  alb_subnet_cidrs          = ["10.40.0.0/20", "10.40.16.0/20"]
  internal_alb_subnet_cidrs = ["10.40.0.0/20", "10.40.16.0/20"]
  alb_ingress_cidrs         = ["10.0.0.0/8"]
  egress_security_group_ids = ["sg-egress-allowlist"]
  certificate_arn           = "arn:aws:acm:us-east-1:123456789012:certificate/test"
  web_hostname              = "aig-portal-dev.example.com"
  api_hostname              = "aig-api-dev.example.com"
  bridge_hostname           = "aig-bridge-dev.example.com"
  cache_compress_hostname   = "aig-cc-dev.example.com"
  images = {
    platform_api     = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/platform-api@sha256:1111111111111111111111111111111111111111111111111111111111111111"
    telemetry_bridge = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/telemetry-bridge@sha256:2222222222222222222222222222222222222222222222222222222222222222"
    cache_compress   = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/cache-compress@sha256:3333333333333333333333333333333333333333333333333333333333333333"
    web              = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/web@sha256:4444444444444444444444444444444444444444444444444444444444444444"
  }
  kms_key_arn                  = "arn:aws:kms:us-east-1:123456789012:key/test"
  platform_api_secret_arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/platform-api-AbCdEf"
  telemetry_bridge_secret_arn  = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/telemetry-bridge-AbCdEf"
  telemetry_bridge_secret_keys = ["FIDDLER_API_KEY", "AIG_PLATFORM_SERVICE_TOKEN"] # gitleaks:allow (names)
  platform_api_config          = { portkey_gateway_url = "https://portkey.corp.example.com/v1", fiddler_url = "https://aig.fiddler.example.com" }
  cache_compress_upstreams     = { anthropic = "https://api.anthropic.com" }
  web_config                   = { env = "dev", apiBaseUrl = "https://aig-api-dev.example.com", auth = "oidc" }
}

run "platform_api_is_wired_for_production" {
  command = plan

  assert {
    condition     = local.platform_api_environment["AIG_PUBLIC_BASE_URL"] == "https://aig-api-dev.example.com"
    error_message = "AIG_PUBLIC_BASE_URL must be the https API host"
  }
  assert {
    condition     = local.platform_api_environment["AIG_SECRET_PROVIDER"] == "aws" && local.platform_api_environment["AIG_ENV"] == "dev"
    error_message = "platform-api reads aig/<env>/platform-api from Secrets Manager"
  }
  assert {
    condition     = local.platform_api_environment["FORWARDED_ALLOW_IPS"] == "10.40.0.0/20,10.40.16.0/20" && !strcontains(local.forwarded_allowed, "*")
    error_message = "FORWARDED_ALLOW_IPS must be the ALB subnets, never *"
  }
  assert {
    condition     = local.platform_api_environment["AIG_DB_AUTO_MIGRATE"] == "false"
    error_message = "migrations run as a one-off task, not at startup"
  }
  assert {
    condition     = contains(local.platform_api_container.entryPoint, "AIG_DATABASE_URL") && contains(local.task_defs.platform_api_migrate.containers[1].command, "upgrade")
    error_message = "AIG_DATABASE_URL is composed from the RDS secret; the migrate task runs `aig-platform-api db upgrade`"
  }
  assert {
    condition     = alltrue([for t in aws_lb_target_group.this : t.health_check[0].path == "/healthz"])
    error_message = "every target group checks /healthz"
  }
  assert {
    condition     = aws_lb_listener.https_public.protocol == "HTTPS" && aws_lb_listener.https_internal.protocol == "HTTPS"
    error_message = "both ALBs terminate HTTPS"
  }
  assert {
    condition     = aws_db_instance.this.storage_encrypted && !aws_db_instance.this.publicly_accessible && aws_db_instance.this.manage_master_user_password
    error_message = "Postgres is encrypted, private and its password is managed by RDS in Secrets Manager"
  }
  assert {
    condition     = aws_scheduler_schedule.reconcile.schedule_expression == "cron(30 1 * * ? *)"
    error_message = "telemetry-bridge reconcile runs daily"
  }
  assert {
    condition     = local.task_defs.telemetry_bridge_reconcile.containers[1].command == ["telemetry-bridge", "reconcile"]
    error_message = "the scheduled task runs `telemetry-bridge reconcile`"
  }
  assert {
    condition     = alltrue([for c in [local.platform_api_container, local.bridge_container, local.cache_compress_container, local.web_container] : c.user != "0" && c.readonlyRootFilesystem])
    error_message = "application containers run as non-root with a read-only root filesystem"
  }
}

run "refuses_image_tags" {
  command = plan
  variables {
    images = {
      platform_api     = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/platform-api:latest"
      telemetry_bridge = "x@sha256:2222222222222222222222222222222222222222222222222222222222222222"
      cache_compress   = "x@sha256:3333333333333333333333333333333333333333333333333333333333333333"
      web              = "x@sha256:4444444444444444444444444444444444444444444444444444444444444444"
    }
  }
  expect_failures = [var.images]
}

# Least privilege for agent invocation: only InvokeAgentRuntime, only this account/region's runtimes,
# only those tagged aig:registered=true in this env; secrets only aig/<env>/agents/*/invoke-auth.
run "platform_api_invokes_only_registered_agent_runtimes" {
  command = plan

  assert {
    condition     = one([for s in data.aws_iam_policy_document.platform_api_task.statement : s if s.sid == "InvokeRegisteredAgentRuntimes"]).actions == toset(["bedrock-agentcore:InvokeAgentRuntime"])
    error_message = "the invoke statement grants InvokeAgentRuntime and nothing else"
  }
  assert {
    condition = alltrue([for r in one([for s in data.aws_iam_policy_document.platform_api_task.statement : s if s.sid == "InvokeRegisteredAgentRuntimes"]).resources :
    startswith(r, "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/")])
    error_message = "invoke resources are this account/region's AgentCore runtimes (and their endpoints) only"
  }
  assert {
    condition = toset([for c in one([for s in data.aws_iam_policy_document.platform_api_task.statement : s if s.sid == "InvokeRegisteredAgentRuntimes"]).condition :
    "${c.test} ${c.variable}=${join(",", c.values)}"]) == toset(["StringEquals aws:ResourceTag/aig:registered=true", "StringEquals aws:ResourceTag/aig:env=dev"])
    error_message = "invocation is scoped by tag: aig:registered=true and aig:env=<env>"
  }
  assert {
    condition = one([for s in data.aws_iam_policy_document.platform_api_task.statement : s if s.sid == "ReadAgentInvokeAuth"]).resources == toset([
      "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/agents/*/invoke-auth-*",
    ])
    error_message = "platform-api reads only aig/<env>/agents/<id>/invoke-auth (never the agents' runtime secrets aig/<env>/agents/<id>)"
  }
  assert {
    condition     = one([for s in data.aws_iam_policy_document.platform_api_task.statement : s if s.sid == "ReadAgentInvokeAuth"]).actions == toset(["secretsmanager:GetSecretValue"])
    error_message = "invoke-auth secrets are read-only"
  }
  assert {
    condition = alltrue(flatten([for s in data.aws_iam_policy_document.platform_api_task.statement : [
      for a in s.actions : !contains(["*", "bedrock:InvokeModel", "bedrock-agentcore:*", "secretsmanager:*"], a)
    ]])) && alltrue(flatten([for s in data.aws_iam_policy_document.platform_api_task.statement : [for r in s.resources : r != "*"]]))
    error_message = "no wildcard actions or resources, no direct model access"
  }
}

run "agent_invocation_can_be_switched_off" {
  command = plan
  variables {
    agent_invocation_enabled = false
  }
  assert {
    condition     = length([for s in data.aws_iam_policy_document.platform_api_task.statement : s if contains(["InvokeRegisteredAgentRuntimes", "ReadAgentInvokeAuth"], s.sid)]) == 0
    error_message = "agent_invocation_enabled=false removes both grants"
  }
}

# Daily `aig-platform-api invocations purge`: platform-api container (same env, DB secrets and DB URL
# launcher) with only the command and the retention env vars changed; scheduler role is least privilege.
run "invocation_purge_runs_daily_with_retention_env" {
  command = plan

  assert {
    condition     = length(aws_scheduler_schedule.invocation_purge) == 1 && aws_scheduler_schedule.invocation_purge[0].schedule_expression == "cron(30 3 * * ? *)" && aws_scheduler_schedule.invocation_purge[0].schedule_expression_timezone == "UTC"
    error_message = "the invocation purge is scheduled daily at 03:30 UTC by default"
  }
  assert {
    condition     = aws_scheduler_schedule.invocation_purge[0].target[0].ecs_parameters[0].launch_type == "FARGATE" && aws_scheduler_schedule.invocation_purge[0].target[0].ecs_parameters[0].task_count == 1 && !aws_scheduler_schedule.invocation_purge[0].target[0].ecs_parameters[0].network_configuration[0].assign_public_ip
    error_message = "the purge runs as one private Fargate task"
  }
  assert {
    condition     = aws_ecs_task_definition.this["platform_api_invocation_purge"].family == "aig-dev-platform-api-invocation-purge"
    error_message = "the purge has its own task definition family"
  }
  assert {
    condition     = local.task_defs.platform_api_invocation_purge.containers[1].command == ["aig-platform-api", "invocations", "purge"]
    error_message = "the scheduled task runs `aig-platform-api invocations purge`"
  }
  assert {
    condition = (contains(local.task_defs.platform_api_invocation_purge.containers[1].entryPoint, "AIG_DATABASE_URL")
      && [for x in local.task_defs.platform_api_invocation_purge.containers[1].secrets : x.name] == ["AIG_DB_USERNAME", "AIG_DB_PASSWORD"]
    && local.task_defs.platform_api_invocation_purge.containers[1].image == var.images.platform_api)
    error_message = "the purge uses the platform-api image, DB secrets and DB URL launcher"
  }
  assert {
    condition = (
      { for e in local.task_defs.platform_api_invocation_purge.containers[1].environment : e.name => e.value }["AIG_AGENT_INVOCATION_RETENTION_DAYS"] == "90"
      && { for e in local.task_defs.platform_api_invocation_purge.containers[1].environment : e.name => e.value }["AIG_AGENT_OUTPUT_RETENTION_DAYS"] == "30"
      && { for e in local.task_defs.platform_api_invocation_purge.containers[1].environment : e.name => e.value }["AIG_DB_NAME"] == local.platform_api_environment["AIG_DB_NAME"]
    )
    error_message = "the purge gets 90/30 retention days by default plus the platform-api environment"
  }
  assert {
    condition     = one([for s in data.aws_iam_policy_document.invocation_purge_scheduler[0].statement : s if contains(s.actions, "ecs:RunTask")]).actions == toset(["ecs:RunTask"])
    error_message = "the purge scheduler may only run tasks"
  }
  assert {
    condition = toset([for c in one([for s in data.aws_iam_policy_document.invocation_purge_scheduler[0].statement : s if contains(s.actions, "iam:PassRole")]).condition :
    "${c.test} ${c.variable}=${join(",", c.values)}"]) == toset(["StringLike iam:PassedToService=ecs-tasks.amazonaws.com"])
    error_message = "the purge scheduler passes roles to ECS tasks only"
  }
  assert {
    condition     = length(data.aws_iam_policy_document.invocation_purge_scheduler[0].statement) == 2
    error_message = "the purge scheduler policy has only RunTask and PassRole"
  }
}

run "invocation_purge_retention_is_configurable" {
  command = plan
  variables {
    invocation_purge_schedule       = "cron(0 4 * * ? *)"
    agent_invocation_retention_days = 180
    agent_output_retention_days     = 14
    platform_api_environment        = { AIG_AGENT_OUTPUT_RETENTION_DAYS = "999" }
  }
  assert {
    condition     = aws_scheduler_schedule.invocation_purge[0].schedule_expression == "cron(0 4 * * ? *)"
    error_message = "the purge schedule is configurable"
  }
  assert {
    condition = (
      { for e in local.task_defs.platform_api_invocation_purge.containers[1].environment : e.name => e.value }["AIG_AGENT_INVOCATION_RETENTION_DAYS"] == "180"
      && length([for e in local.task_defs.platform_api_invocation_purge.containers[1].environment : e if e.name == "AIG_AGENT_OUTPUT_RETENTION_DAYS"]) == 1
      && { for e in local.task_defs.platform_api_invocation_purge.containers[1].environment : e.name => e.value }["AIG_AGENT_OUTPUT_RETENTION_DAYS"] == "14"
    )
    error_message = "retention variables are passed to the purge task and win over platform_api_environment (no duplicate env entries)"
  }
}

run "invocation_purge_can_be_switched_off" {
  command = plan
  variables {
    invocation_purge_enabled = false
  }
  assert {
    condition = (length(aws_scheduler_schedule.invocation_purge) == 0 && length(aws_iam_role.invocation_purge_scheduler) == 0
    && !contains(keys(local.task_defs), "platform_api_invocation_purge") && !contains(keys(aws_ecs_task_definition.this), "platform_api_invocation_purge"))
    error_message = "invocation_purge_enabled=false removes the schedule, its role and its task definition"
  }
  assert {
    condition     = length(aws_scheduler_schedule.reconcile.name) > 0 && contains(keys(aws_ecs_task_definition.this), "platform_api")
    error_message = "switching the purge off leaves reconcile and the services alone"
  }
}

run "refuses_zero_output_retention" {
  command = plan
  variables {
    agent_output_retention_days = 0
  }
  expect_failures = [var.agent_output_retention_days]
}

run "refuses_zero_invocation_retention" {
  command = plan
  variables {
    agent_invocation_retention_days = 0
    agent_output_retention_days     = 1
  }
  expect_failures = [var.agent_invocation_retention_days]
}

run "refuses_output_retention_longer_than_invocation_retention" {
  command = plan
  variables {
    agent_invocation_retention_days = 30
    agent_output_retention_days     = 60
  }
  expect_failures = [var.agent_output_retention_days]
}
