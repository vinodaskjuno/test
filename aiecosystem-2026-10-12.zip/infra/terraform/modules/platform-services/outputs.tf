output "cluster_name" {
  value = aws_ecs_cluster.this.name
}

output "cluster_arn" {
  value = aws_ecs_cluster.this.arn
}

output "service_names" {
  description = "key (platform_api, telemetry_bridge, cache_compress, web) -> ECS service name."
  value       = { for k, s in aws_ecs_service.this : k => s.name }
}

output "task_definition_arns" {
  value = { for k, t in aws_ecs_task_definition.this : k => t.arn }
}

output "invocation_purge_task_family" {
  description = "Task definition family of the daily invocation purge task (null when invocation_purge_enabled = false)."
  value       = var.invocation_purge_enabled ? local.all_task_defs.platform_api_invocation_purge.family : null
}

output "migrate_task" {
  description = "One-off `aig-platform-api db upgrade` task: run it (aws ecs run-task) before rolling out a new platform-api."
  value = {
    cluster         = aws_ecs_cluster.this.name
    task_definition = aws_ecs_task_definition.this["platform_api_migrate"].arn
    container       = "platform-api"
    subnets         = var.private_subnet_ids
    security_groups = concat([aws_security_group.service["platform_api"].id], var.egress_security_group_ids)
  }
}

output "public_alb_dns_name" {
  description = "Point web_hostname and api_hostname (CNAME/alias) here."
  value       = aws_lb.public.dns_name
}

output "internal_alb_dns_name" {
  description = "Point bridge_hostname and cache_compress_hostname here (private zone)."
  value       = aws_lb.internal.dns_name
}

output "public_alb_arn_suffix" {
  value = aws_lb.public.arn_suffix
}

output "internal_alb_arn_suffix" {
  value = aws_lb.internal.arn_suffix
}

output "target_group_arn_suffixes" {
  value = { for k, t in aws_lb_target_group.this : k => t.arn_suffix }
}

output "db_endpoint" {
  value = aws_db_instance.this.address
}

output "db_identifier" {
  value = aws_db_instance.this.identifier
}

output "db_master_secret_arn" {
  description = "RDS-managed master credentials (rotated by RDS)."
  value       = aws_db_instance.this.master_user_secret[0].secret_arn
}

output "log_group_names" {
  value = { for k, l in aws_cloudwatch_log_group.service : k => l.name }
}

output "urls" {
  value = {
    web            = "https://${var.web_hostname}"
    platform_api   = local.api_url
    bridge         = local.bridge_url
    cache_compress = "https://${var.cache_compress_hostname}"
  }
}

output "public_https_listener_arn" {
  description = "HTTPS listener of the portal/API ALB (the Phase 6 Teams bot adds its host rules here)."
  value       = aws_lb_listener.https_public.arn
}

output "public_alb_security_group_id" {
  description = "Security group of the portal/API ALB (the workspaces module adds the orchestrator/bot rules to it)."
  value       = aws_security_group.alb_public.id
}
