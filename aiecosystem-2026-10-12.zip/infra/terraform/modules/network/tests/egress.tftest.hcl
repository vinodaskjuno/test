# Offline plan tests (mock AWS provider, no credentials): the egress allow-list is default deny.
mock_provider "aws" {
  mock_data "aws_region" {
    defaults = { region = "us-east-1" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{}" }
  }
}

variables {
  name                 = "aig-test"
  cidr_block           = "10.40.0.0/16"
  azs                  = ["us-east-1a", "us-east-1b"]
  private_subnet_cidrs = ["10.40.0.0/20", "10.40.16.0/20"]
  public_subnet_cidrs  = ["10.40.128.0/24", "10.40.129.0/24"]
  portkey_egress_cidrs = ["10.1.2.0/24"]
  fiddler_egress_cidrs = ["203.0.113.0/26"]
}

run "cidr_mode_allows_only_portkey_fiddler_and_endpoints" {
  command = plan

  assert {
    condition     = length(aws_ec2_managed_prefix_list.egress_allow.entry) == 2
    error_message = "the egress prefix list must hold exactly the Portkey and Fiddler CIDRs"
  }
  assert {
    condition     = toset([for e in aws_ec2_managed_prefix_list.egress_allow.entry : e.cidr]) == toset(["10.1.2.0/24", "203.0.113.0/26"])
    error_message = "unexpected CIDRs in the egress prefix list"
  }
  assert {
    condition = alltrue([
      for r in [aws_vpc_security_group_egress_rule.allow_portkey_fiddler, aws_vpc_security_group_egress_rule.allow_vpc_endpoints, aws_vpc_security_group_egress_rule.allow_s3_gateway] :
      r.cidr_ipv4 == null && r.from_port == 443 && r.to_port == 443 && r.ip_protocol == "tcp"
    ])
    error_message = "allow-list rules must be HTTPS to a prefix list / security group, never to a CIDR"
  }
  assert {
    condition     = length(aws_security_group.internet_via_firewall) == 0 && length(aws_networkfirewall_firewall.egress) == 0
    error_message = "cidr mode must not create the firewall or the internet egress group"
  }
  assert {
    condition     = alltrue([for r in aws_route.private_default : r.vpc_endpoint_id == null])
    error_message = "cidr mode routes the private subnets to NAT"
  }
  assert {
    condition     = length(aws_vpc_endpoint.interface) >= 5 && contains(keys(aws_vpc_endpoint.interface), "secretsmanager") && contains(keys(aws_vpc_endpoint.interface), "ecr.dkr")
    error_message = "ECR, Logs, Secrets Manager and STS must be reached through VPC endpoints"
  }
  assert {
    condition     = alltrue([for s in aws_subnet.private : s.map_public_ip_on_launch != true])
    error_message = "private subnets never assign public IPs"
  }
}

run "refuses_open_egress_cidr" {
  command = plan
  variables {
    portkey_egress_cidrs = ["0.0.0.0/0"]
  }
  expect_failures = [var.portkey_egress_cidrs]
}

run "firewall_mode_adds_domain_allowlist" {
  command = plan
  variables {
    egress_mode            = "firewall"
    firewall_subnet_cidrs  = ["10.40.130.0/28", "10.40.130.16/28"]
    egress_allowed_domains = ["portkey.corp.example.com", "aig.fiddler.example.com"]
  }

  assert {
    condition     = length(aws_networkfirewall_firewall.egress) == 1
    error_message = "firewall mode deploys AWS Network Firewall"
  }
  assert {
    condition     = aws_networkfirewall_firewall_policy.egress[0].firewall_policy[0].stateful_default_actions == toset(["aws:drop_established", "aws:alert_established"])
    error_message = "the firewall policy must drop everything not allowed"
  }
  assert {
    condition     = aws_networkfirewall_rule_group.egress_domains[0].rule_group[0].rules_source[0].rules_source_list[0].generated_rules_type == "ALLOWLIST"
    error_message = "the domain rule group must be an allow-list"
  }
  assert {
    condition     = alltrue([for r in aws_route.private_default : r.nat_gateway_id == null])
    error_message = "firewall mode routes the private subnets through the firewall endpoints, not straight to NAT"
  }
}

run "workspace_prefix_list_is_separate_and_closed" {
  command = plan
  variables {
    workspace_egress_cidrs    = [{ cidr = "192.30.252.0/22", description = "GitHub" }]
    workspace_egress_domains  = ["github.com", "api.github.com"]
    extra_interface_endpoints = ["ecs"]
    egress_mode               = "firewall"
    firewall_subnet_cidrs     = ["10.40.130.0/28", "10.40.130.16/28"]
    egress_allowed_domains    = ["portkey.corp.example.com"]
  }

  assert {
    condition     = length(aws_ec2_managed_prefix_list.workspace_egress_allow) == 1 && length(aws_ec2_managed_prefix_list.egress_allow.entry) == 2
    error_message = "GitHub CIDRs go into the workspace prefix list only, never into the shared agent/service list"
  }
  assert {
    condition     = contains(aws_networkfirewall_rule_group.egress_domains[0].rule_group[0].rules_source[0].rules_source_list[0].targets, "github.com")
    error_message = "firewall mode allows the workspace domains"
  }
  assert {
    condition     = contains(keys(aws_vpc_endpoint.interface), "ecs")
    error_message = "the ECS API is reached through a VPC endpoint (orchestrator RunTask)"
  }
}

run "refuses_open_workspace_egress" {
  command = plan
  variables {
    workspace_egress_cidrs = [{ cidr = "0.0.0.0/0", description = "everything" }]
  }
  expect_failures = [var.workspace_egress_cidrs]
}
