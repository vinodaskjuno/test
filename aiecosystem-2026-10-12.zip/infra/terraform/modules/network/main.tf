# AIG network: VPC with private workload subnets and a default-deny egress allow-list.
#
#   internet <- IGW <- public subnets (NAT) [<- Network Firewall subnets] <- private subnets
#                                                                          (AgentCore, ECS, RDS, VPC endpoints)
#
# Egress allow-list (docs/IMPLEMENTATION_PLAN.md "Enforcement controls": VPC rules, Phase 5 infra for cloud):
#   * aws_ec2_managed_prefix_list.egress_allow holds the Portkey + Fiddler CIDRs.
#   * aws_security_group.egress_allowlist (attached to every AgentCore runtime and ECS task) allows
#     HTTPS only to that prefix list, to the interface VPC endpoints and to the S3 gateway endpoint
#     (ECR image layers). There is no 0.0.0.0/0 rule: everything else is denied.
#   * egress_mode = "firewall" adds AWS Network Firewall on the NAT path with a domain allow-list and
#     default drop. Only aws_security_group.internet_via_firewall (attached to the platform services
#     that need FQDN destinations) may send HTTPS to 0.0.0.0/0, and the firewall filters it.

locals {
  az_count     = length(var.azs)
  use_firewall = var.egress_mode == "firewall"
  nat_count    = var.single_nat_gateway ? 1 : local.az_count
  tags         = merge(var.tags, { "aig:module" = "network" })
}

resource "aws_vpc" "this" {
  cidr_block           = var.cidr_block
  enable_dns_support   = true
  enable_dns_hostnames = true # required for interface endpoint private DNS
  tags                 = merge(local.tags, { Name = var.name })

  lifecycle {
    precondition {
      condition     = length(var.private_subnet_cidrs) == local.az_count && length(var.public_subnet_cidrs) == local.az_count
      error_message = "private_subnet_cidrs and public_subnet_cidrs need exactly one CIDR per AZ."
    }
    precondition {
      condition     = !local.use_firewall || (length(var.firewall_subnet_cidrs) == local.az_count && length(var.egress_allowed_domains) > 0)
      error_message = "egress_mode = \"firewall\" needs one firewall_subnet_cidrs entry per AZ and a non-empty egress_allowed_domains."
    }
  }
}

# Lock down the default security group (no rules = no traffic).
resource "aws_default_security_group" "this" {
  vpc_id = aws_vpc.this.id
  tags   = merge(local.tags, { Name = "${var.name}-default-deny" })
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
  tags   = merge(local.tags, { Name = var.name })
}

# ---------------------------------------------------------------------------------------------
# Subnets
# ---------------------------------------------------------------------------------------------
resource "aws_subnet" "public" {
  count                   = local.az_count
  vpc_id                  = aws_vpc.this.id
  availability_zone       = var.azs[count.index]
  cidr_block              = var.public_subnet_cidrs[count.index]
  map_public_ip_on_launch = false
  tags                    = merge(local.tags, { Name = "${var.name}-public-${var.azs[count.index]}", "aig:tier" = "public" })
}

resource "aws_subnet" "private" {
  count             = local.az_count
  vpc_id            = aws_vpc.this.id
  availability_zone = var.azs[count.index]
  cidr_block        = var.private_subnet_cidrs[count.index]
  tags              = merge(local.tags, { Name = "${var.name}-private-${var.azs[count.index]}", "aig:tier" = "private" })
}

resource "aws_subnet" "firewall" {
  count             = local.use_firewall ? local.az_count : 0
  vpc_id            = aws_vpc.this.id
  availability_zone = var.azs[count.index]
  cidr_block        = var.firewall_subnet_cidrs[count.index]
  tags              = merge(local.tags, { Name = "${var.name}-firewall-${var.azs[count.index]}", "aig:tier" = "firewall" })
}

# ---------------------------------------------------------------------------------------------
# NAT
# ---------------------------------------------------------------------------------------------
resource "aws_eip" "nat" {
  count  = local.nat_count
  domain = "vpc"
  tags   = merge(local.tags, { Name = "${var.name}-nat-${count.index}" })
}

resource "aws_nat_gateway" "this" {
  count         = local.nat_count
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id
  tags          = merge(local.tags, { Name = "${var.name}-nat-${var.azs[count.index]}" })
  depends_on    = [aws_internet_gateway.this]
}

# ---------------------------------------------------------------------------------------------
# Network Firewall (egress_mode = "firewall"): domain allow-list, default drop
# ---------------------------------------------------------------------------------------------
resource "aws_networkfirewall_rule_group" "egress_domains" {
  count    = local.use_firewall ? 1 : 0
  name     = "${var.name}-egress-allow-domains"
  type     = "STATEFUL"
  capacity = 100
  rule_group {
    rule_variables {
      ip_sets {
        key = "HOME_NET"
        ip_set {
          definition = [var.cidr_block]
        }
      }
    }
    rules_source {
      rules_source_list {
        generated_rules_type = "ALLOWLIST"
        target_types         = ["TLS_SNI", "HTTP_HOST"]
        targets              = distinct(concat(var.egress_allowed_domains, var.workspace_egress_domains))
      }
    }
    stateful_rule_options {
      rule_order = "STRICT_ORDER"
    }
  }
  tags = local.tags
}

resource "aws_networkfirewall_firewall_policy" "egress" {
  count = local.use_firewall ? 1 : 0
  name  = "${var.name}-egress"
  firewall_policy {
    stateless_default_actions          = ["aws:forward_to_sfe"]
    stateless_fragment_default_actions = ["aws:forward_to_sfe"]
    stateful_engine_options {
      rule_order = "STRICT_ORDER"
    }
    # Anything not allowed by the domain list is dropped (and alerted).
    stateful_default_actions = ["aws:drop_established", "aws:alert_established"]
    stateful_rule_group_reference {
      priority     = 100
      resource_arn = aws_networkfirewall_rule_group.egress_domains[0].arn
    }
  }
  tags = local.tags
}

resource "aws_networkfirewall_firewall" "egress" {
  count               = local.use_firewall ? 1 : 0
  name                = "${var.name}-egress"
  vpc_id              = aws_vpc.this.id
  firewall_policy_arn = aws_networkfirewall_firewall_policy.egress[0].arn
  delete_protection   = false
  dynamic "subnet_mapping" {
    for_each = aws_subnet.firewall
    content {
      subnet_id = subnet_mapping.value.id
    }
  }
  tags = local.tags
}

resource "aws_cloudwatch_log_group" "firewall" {
  count             = local.use_firewall ? 1 : 0
  name              = "/aig/${var.name}/network-firewall"
  retention_in_days = var.flow_logs_retention_days
  kms_key_id        = var.kms_key_arn
  tags              = local.tags
}

resource "aws_networkfirewall_logging_configuration" "egress" {
  count        = local.use_firewall ? 1 : 0
  firewall_arn = aws_networkfirewall_firewall.egress[0].arn
  logging_configuration {
    log_destination_config {
      log_destination      = { logGroup = aws_cloudwatch_log_group.firewall[0].name }
      log_destination_type = "CloudWatchLogs"
      log_type             = "ALERT"
    }
  }
}

locals {
  # AZ -> firewall endpoint id (known after apply).
  firewall_endpoints = local.use_firewall ? {
    for s in tolist(aws_networkfirewall_firewall.egress[0].firewall_status[0].sync_states) :
    s.availability_zone => s.attachment[0].endpoint_id
  } : {}
}

# ---------------------------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------------------------
resource "aws_route_table" "public" {
  count  = local.az_count
  vpc_id = aws_vpc.this.id
  tags   = merge(local.tags, { Name = "${var.name}-public-${var.azs[count.index]}" })
}

resource "aws_route" "public_internet" {
  count                  = local.az_count
  route_table_id         = aws_route_table.public[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.this.id
}

# Firewall mode: return traffic to the private subnets goes back through the firewall (symmetric).
resource "aws_route" "public_to_private_via_firewall" {
  count                  = local.use_firewall ? local.az_count : 0
  route_table_id         = aws_route_table.public[count.index].id
  destination_cidr_block = var.private_subnet_cidrs[count.index]
  vpc_endpoint_id        = local.firewall_endpoints[var.azs[count.index]]
}

resource "aws_route_table_association" "public" {
  count          = local.az_count
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public[count.index].id
}

resource "aws_route_table" "firewall" {
  count  = local.use_firewall ? local.az_count : 0
  vpc_id = aws_vpc.this.id
  tags   = merge(local.tags, { Name = "${var.name}-firewall-${var.azs[count.index]}" })
}

resource "aws_route" "firewall_to_nat" {
  count                  = local.use_firewall ? local.az_count : 0
  route_table_id         = aws_route_table.firewall[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.this[var.single_nat_gateway ? 0 : count.index].id
}

resource "aws_route_table_association" "firewall" {
  count          = local.use_firewall ? local.az_count : 0
  subnet_id      = aws_subnet.firewall[count.index].id
  route_table_id = aws_route_table.firewall[count.index].id
}

resource "aws_route_table" "private" {
  count  = local.az_count
  vpc_id = aws_vpc.this.id
  tags   = merge(local.tags, { Name = "${var.name}-private-${var.azs[count.index]}" })
}

# Private default route: firewall endpoint (firewall mode) or NAT (cidr mode, where the security
# groups are the allow-list).
resource "aws_route" "private_default" {
  count                  = local.az_count
  route_table_id         = aws_route_table.private[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = local.use_firewall ? null : aws_nat_gateway.this[var.single_nat_gateway ? 0 : count.index].id
  vpc_endpoint_id        = local.use_firewall ? local.firewall_endpoints[var.azs[count.index]] : null
}

resource "aws_route_table_association" "private" {
  count          = local.az_count
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private[count.index].id
}

# ---------------------------------------------------------------------------------------------
# VPC endpoints (AWS APIs never leave the VPC)
# ---------------------------------------------------------------------------------------------
data "aws_region" "current" {}

resource "aws_security_group" "vpc_endpoints" {
  name        = "${var.name}-vpc-endpoints"
  description = "Interface VPC endpoints: HTTPS from inside the VPC only"
  vpc_id      = aws_vpc.this.id
  tags        = merge(local.tags, { Name = "${var.name}-vpc-endpoints" })
}

resource "aws_vpc_security_group_ingress_rule" "vpc_endpoints_https" {
  security_group_id = aws_security_group.vpc_endpoints.id
  description       = "HTTPS from the VPC"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = var.cidr_block
}

resource "aws_vpc_endpoint" "interface" {
  for_each            = toset(distinct(concat(var.interface_endpoints, var.extra_interface_endpoints)))
  vpc_id              = aws_vpc.this.id
  service_name        = "com.amazonaws.${data.aws_region.current.region}.${each.value}"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true
  subnet_ids          = aws_subnet.private[*].id
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  tags                = merge(local.tags, { Name = "${var.name}-${each.value}" })
}

resource "aws_vpc_endpoint" "s3" {
  vpc_id            = aws_vpc.this.id
  service_name      = "com.amazonaws.${data.aws_region.current.region}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = aws_route_table.private[*].id
  tags              = merge(local.tags, { Name = "${var.name}-s3" })
}

# ---------------------------------------------------------------------------------------------
# Egress allow-list
# ---------------------------------------------------------------------------------------------
locals {
  egress_entries = concat(
    [for c in var.portkey_egress_cidrs : { cidr = c, description = "Portkey gateway" }],
    [for c in var.fiddler_egress_cidrs : { cidr = c, description = "Fiddler" }],
    var.additional_egress_cidrs,
  )
}

resource "aws_ec2_managed_prefix_list" "egress_allow" {
  name           = "${var.name}-egress-allow"
  address_family = "IPv4"
  max_entries    = max(length(local.egress_entries), 10)
  dynamic "entry" {
    for_each = local.egress_entries
    content {
      cidr        = entry.value.cidr
      description = entry.value.description
    }
  }
  tags = merge(local.tags, { Name = "${var.name}-egress-allow" })
}

# Phase 6 team workspaces only: the Git host (GitHub) and package mirror CIDRs. Referenced by the
# workspace task security group (modules/workspaces), never by the shared egress-allowlist group,
# so agents and platform services cannot reach GitHub.
resource "aws_ec2_managed_prefix_list" "workspace_egress_allow" {
  count          = length(var.workspace_egress_cidrs) > 0 ? 1 : 0
  name           = "${var.name}-workspace-egress-allow"
  address_family = "IPv4"
  max_entries    = max(length(var.workspace_egress_cidrs), 10)
  dynamic "entry" {
    for_each = var.workspace_egress_cidrs
    content {
      cidr        = entry.value.cidr
      description = entry.value.description
    }
  }
  tags = merge(local.tags, { Name = "${var.name}-workspace-egress-allow" })
}

resource "aws_security_group" "egress_allowlist" {
  name        = "${var.name}-egress-allowlist"
  description = "Default-deny egress: HTTPS only to Portkey, Fiddler and AWS VPC endpoints"
  vpc_id      = aws_vpc.this.id
  tags        = merge(local.tags, { Name = "${var.name}-egress-allowlist" })
}

resource "aws_vpc_security_group_egress_rule" "allow_portkey_fiddler" {
  security_group_id = aws_security_group.egress_allowlist.id
  description       = "HTTPS to the Portkey gateway and Fiddler (managed prefix list)"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  prefix_list_id    = aws_ec2_managed_prefix_list.egress_allow.id
}

resource "aws_vpc_security_group_egress_rule" "allow_vpc_endpoints" {
  security_group_id            = aws_security_group.egress_allowlist.id
  description                  = "HTTPS to interface VPC endpoints (ECR, Logs, Secrets Manager, STS, KMS, ...)"
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
  referenced_security_group_id = aws_security_group.vpc_endpoints.id
}

resource "aws_vpc_security_group_egress_rule" "allow_s3_gateway" {
  security_group_id = aws_security_group.egress_allowlist.id
  description       = "HTTPS to S3 through the gateway endpoint (ECR image layers)"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  prefix_list_id    = aws_vpc_endpoint.s3.prefix_list_id
}

# Firewall mode only: HTTPS to anywhere, filtered by the Network Firewall domain allow-list.
# Never attached to AgentCore runtimes.
resource "aws_security_group" "internet_via_firewall" {
  count       = local.use_firewall ? 1 : 0
  name        = "${var.name}-internet-via-firewall"
  description = "HTTPS egress filtered by the Network Firewall domain allow-list"
  vpc_id      = aws_vpc.this.id
  tags        = merge(local.tags, { Name = "${var.name}-internet-via-firewall" })
}

resource "aws_vpc_security_group_egress_rule" "internet_via_firewall" {
  count             = local.use_firewall ? 1 : 0
  security_group_id = aws_security_group.internet_via_firewall[0].id
  description       = "HTTPS; the Network Firewall drops every domain not on the allow-list"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = "0.0.0.0/0"
}

# ---------------------------------------------------------------------------------------------
# VPC flow logs (audit of every accepted/rejected flow)
# ---------------------------------------------------------------------------------------------
resource "aws_cloudwatch_log_group" "flow_logs" {
  name              = "/aig/${var.name}/vpc-flow-logs"
  retention_in_days = var.flow_logs_retention_days
  kms_key_id        = var.kms_key_arn
  tags              = local.tags
}

data "aws_iam_policy_document" "flow_logs_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["vpc-flow-logs.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "flow_logs" {
  statement {
    actions   = ["logs:CreateLogStream", "logs:PutLogEvents", "logs:DescribeLogStreams"]
    resources = ["${aws_cloudwatch_log_group.flow_logs.arn}:*"]
  }
}

resource "aws_iam_role" "flow_logs" {
  name               = "${var.name}-vpc-flow-logs"
  assume_role_policy = data.aws_iam_policy_document.flow_logs_assume.json
  tags               = local.tags
}

resource "aws_iam_role_policy" "flow_logs" {
  name   = "write-flow-logs"
  role   = aws_iam_role.flow_logs.id
  policy = data.aws_iam_policy_document.flow_logs.json
}

resource "aws_flow_log" "this" {
  vpc_id               = aws_vpc.this.id
  traffic_type         = "ALL"
  log_destination_type = "cloud-watch-logs"
  log_destination      = aws_cloudwatch_log_group.flow_logs.arn
  iam_role_arn         = aws_iam_role.flow_logs.arn
  tags                 = local.tags
}
