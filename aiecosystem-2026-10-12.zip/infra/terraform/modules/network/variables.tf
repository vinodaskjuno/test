variable "name" {
  description = "Name prefix for every resource, e.g. aig-dev."
  type        = string
}

variable "cidr_block" {
  description = "VPC CIDR."
  type        = string
}

variable "azs" {
  description = "Availability zones (one subnet of each tier per AZ)."
  type        = list(string)
  validation {
    condition     = length(var.azs) >= 2
    error_message = "Use at least two availability zones (ALB and RDS subnet groups need two)."
  }
}

variable "private_subnet_cidrs" {
  description = "Private (workload) subnets, one per AZ: AgentCore runtimes, ECS tasks, RDS, VPC endpoints. No public IPs."
  type        = list(string)
}

variable "public_subnet_cidrs" {
  description = "Public subnets, one per AZ: NAT gateways (and an internet-facing ALB when enabled)."
  type        = list(string)
}

variable "firewall_subnet_cidrs" {
  description = "Subnets for the AWS Network Firewall endpoints, one per AZ. Required when egress_mode = \"firewall\"."
  type        = list(string)
  default     = []
}

variable "single_nat_gateway" {
  description = "One NAT gateway for the VPC (cheaper, dev) instead of one per AZ (stage/prod)."
  type        = bool
  default     = false
}

variable "egress_mode" {
  description = <<-EOT
    How outbound traffic from the workload subnets is restricted (default deny in both modes):
      "cidr"     - security groups allow HTTPS only to the egress prefix list (Portkey + Fiddler CIDRs)
                   and to the VPC endpoints; nothing else leaves the VPC.
      "firewall" - additionally deploys AWS Network Firewall on the NAT path with a domain allow-list
                   (TLS SNI / HTTP Host) and default drop, for FQDN-only destinations (SaaS Fiddler,
                   Entra ID, provider APIs for cache-compress). The agent security group stays CIDR-only.
  EOT
  type        = string
  default     = "cidr"
  validation {
    condition     = contains(["cidr", "firewall"], var.egress_mode)
    error_message = "egress_mode must be \"cidr\" or \"firewall\"."
  }
}

variable "portkey_egress_cidrs" {
  description = "CIDRs of the self-hosted Portkey gateway / MCP gateway / admin API (HTTPS)."
  type        = list(string)
  validation {
    condition     = length(var.portkey_egress_cidrs) > 0 && alltrue([for c in var.portkey_egress_cidrs : can(cidrhost(c, 0)) && c != "0.0.0.0/0"])
    error_message = "portkey_egress_cidrs must be non-empty valid CIDRs and never 0.0.0.0/0."
  }
}

variable "fiddler_egress_cidrs" {
  description = "CIDRs of the Fiddler instance (REST + OTLP, HTTPS)."
  type        = list(string)
  validation {
    condition     = length(var.fiddler_egress_cidrs) > 0 && alltrue([for c in var.fiddler_egress_cidrs : can(cidrhost(c, 0)) && c != "0.0.0.0/0"])
    error_message = "fiddler_egress_cidrs must be non-empty valid CIDRs and never 0.0.0.0/0."
  }
}

variable "additional_egress_cidrs" {
  description = "Extra HTTPS destinations for the egress prefix list (e.g. the corporate egress proxy). Never 0.0.0.0/0."
  type = list(object({
    cidr        = string
    description = string
  }))
  default = []
  validation {
    condition     = alltrue([for e in var.additional_egress_cidrs : can(cidrhost(e.cidr, 0)) && e.cidr != "0.0.0.0/0"])
    error_message = "additional_egress_cidrs entries must be valid CIDRs and never 0.0.0.0/0."
  }
}

variable "egress_allowed_domains" {
  description = <<-EOT
    Firewall mode only: domains allowed through AWS Network Firewall (a leading dot allows
    subdomains, e.g. ".fiddler.example.com"). Everything else is dropped. Put the Portkey and Fiddler
    hosts here, plus what platform services need (login.microsoftonline.com for OIDC JWKS,
    provider API hosts for cache-compress).
  EOT
  type        = list(string)
  default     = []
}

variable "workspace_egress_cidrs" {
  description = <<-EOT
    Phase 6 team workspaces: extra HTTPS destinations for the workspace tasks only (the Git host,
    e.g. the GitHub "git"/"api" ranges from https://api.github.com/meta or a GHES CIDR, and the
    package mirror). Held in a separate prefix list that only the workspace security group uses.
    Empty = no prefix list. Never 0.0.0.0/0.
  EOT
  type = list(object({
    cidr        = string
    description = string
  }))
  default = []
  validation {
    condition     = alltrue([for e in var.workspace_egress_cidrs : can(cidrhost(e.cidr, 0)) && e.cidr != "0.0.0.0/0"])
    error_message = "workspace_egress_cidrs entries must be valid CIDRs and never 0.0.0.0/0."
  }
}

variable "workspace_egress_domains" {
  description = "Firewall mode only: domains added to the Network Firewall allow-list for the Phase 6 workspaces and the Teams bot (github.com, api.github.com, Bot Framework hosts)."
  type        = list(string)
  default     = []
}

variable "extra_interface_endpoints" {
  description = "Interface VPC endpoints added to interface_endpoints (e.g. \"ecs\" for the workspace orchestrator's RunTask calls)."
  type        = list(string)
  default     = []
}

variable "interface_endpoints" {
  description = "AWS services reached through interface VPC endpoints (private DNS), so no AWS API traffic needs the internet."
  type        = list(string)
  default     = ["ecr.api", "ecr.dkr", "logs", "secretsmanager", "sts", "kms", "monitoring", "xray", "ssm"]
}

variable "flow_logs_retention_days" {
  description = "VPC flow log retention (CloudWatch Logs)."
  type        = number
  default     = 90
}

variable "kms_key_arn" {
  description = "KMS key for the flow-log and firewall log groups (null = AWS-owned key)."
  type        = string
  default     = null
}

variable "tags" {
  description = "Tags added to every resource."
  type        = map(string)
  default     = {}
}
