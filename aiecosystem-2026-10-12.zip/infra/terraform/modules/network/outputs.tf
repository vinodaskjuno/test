output "vpc_id" {
  value = aws_vpc.this.id
}

output "vpc_cidr" {
  value = aws_vpc.this.cidr_block
}

output "private_subnet_ids" {
  value = aws_subnet.private[*].id
}

output "public_subnet_ids" {
  value = aws_subnet.public[*].id
}

output "public_subnet_cidrs" {
  value = aws_subnet.public[*].cidr_block
}

output "private_subnet_cidrs" {
  value = aws_subnet.private[*].cidr_block
}

output "egress_allowlist_security_group_id" {
  description = "Attach to every AgentCore runtime and ECS task: HTTPS only to Portkey, Fiddler and the VPC endpoints."
  value       = aws_security_group.egress_allowlist.id
}

output "internet_via_firewall_security_group_id" {
  description = "Firewall mode only (else null): HTTPS filtered by the Network Firewall domain allow-list."
  value       = one(aws_security_group.internet_via_firewall[*].id)
}

output "egress_prefix_list_id" {
  value = aws_ec2_managed_prefix_list.egress_allow.id
}

output "vpc_endpoints_security_group_id" {
  value = aws_security_group.vpc_endpoints.id
}

output "flow_log_group_name" {
  value = aws_cloudwatch_log_group.flow_logs.name
}

output "workspace_egress_prefix_list_id" {
  description = "Phase 6 workspaces: prefix list of the Git host / package mirror CIDRs (null when workspace_egress_cidrs is empty)."
  value       = one(aws_ec2_managed_prefix_list.workspace_egress_allow[*].id)
}

output "s3_prefix_list_id" {
  description = "Prefix list of the S3 gateway endpoint (ECR image layers)."
  value       = aws_vpc_endpoint.s3.prefix_list_id
}
