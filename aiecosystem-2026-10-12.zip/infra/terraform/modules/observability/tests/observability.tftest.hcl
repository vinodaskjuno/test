# Offline plan tests (mock AWS provider): failed daily job runs (reconcile, invocation purge) notify
# the alarm topic.
mock_provider "aws" {
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{}" }
  }
}

variables {
  name                         = "aig-dev"
  kms_key_arn                  = "arn:aws:kms:us-east-1:123456789012:key/test"
  cluster_name                 = "aig-dev"
  service_names                = { platform_api = "platform-api", telemetry_bridge = "telemetry-bridge", cache_compress = "cache-compress", web = "web" }
  public_alb_arn_suffix        = "app/aig-dev-public/abc"
  internal_alb_arn_suffix      = "app/aig-dev-internal/def"
  target_group_arn_suffixes    = { platform_api = "targetgroup/a/1", telemetry_bridge = "targetgroup/b/2", cache_compress = "targetgroup/c/3", web = "targetgroup/d/4" }
  db_identifier                = "aig-dev"
  reconcile_task_family        = "aig-dev-telemetry-bridge-reconcile"
  invocation_purge_task_family = "aig-dev-platform-api-invocation-purge"
}

run "failed_invocation_purge_notifies_the_alarm_topic" {
  command = plan

  assert {
    condition     = length(aws_cloudwatch_event_rule.invocation_purge_failed) == 1 && aws_cloudwatch_event_rule.invocation_purge_failed[0].name == "aig-dev-invocation-purge-failed"
    error_message = "a failed invocation purge run has its own EventBridge rule"
  }
  assert {
    condition = jsondecode(aws_cloudwatch_event_rule.invocation_purge_failed[0].event_pattern) == {
      source        = ["aws.ecs"]
      "detail-type" = ["ECS Task State Change"]
      detail = {
        lastStatus = ["STOPPED"]
        group      = ["family:aig-dev-platform-api-invocation-purge"]
        containers = { name = ["platform-api"], exitCode = [{ "anything-but" = 0 }] }
      }
    }
    error_message = "the rule matches the purge task family stopping with a non-zero platform-api exit code"
  }
  assert {
    condition     = length(aws_cloudwatch_event_target.invocation_purge_failed) == 1
    error_message = "the purge failure rule targets the alarm topic"
  }
  assert {
    condition     = jsondecode(aws_cloudwatch_event_rule.reconcile_failed.event_pattern).detail.group == ["family:aig-dev-telemetry-bridge-reconcile"]
    error_message = "the reconcile failure rule is unchanged"
  }
}

run "no_purge_rule_when_purge_is_not_deployed" {
  command = plan
  variables {
    invocation_purge_task_family = null
  }
  assert {
    condition     = length(aws_cloudwatch_event_rule.invocation_purge_failed) == 0 && length(aws_cloudwatch_event_target.invocation_purge_failed) == 0
    error_message = "no purge failure rule when the purge task is switched off"
  }
}
