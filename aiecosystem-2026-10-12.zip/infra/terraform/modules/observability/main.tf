# Basic alarms for the platform: ECS CPU/memory, ALB 5xx, unhealthy targets, RDS CPU/storage,
# a failed daily reconciliation or invocation purge run, and the Phase 6 workspace alarms (workspaces.tf). All go to
# one KMS-encrypted SNS topic per environment.
# AgentCore runtime logs/metrics: see the agentcore-runtime module (log group per endpoint).

locals {
  tags = merge(var.tags, { "aig:module" = "observability" })
}

resource "aws_sns_topic" "alarms" {
  name              = "${var.name}-alarms"
  kms_master_key_id = var.kms_key_arn
  tags              = local.tags
}

resource "aws_sns_topic_subscription" "email" {
  for_each  = toset(var.alarm_emails)
  topic_arn = aws_sns_topic.alarms.arn
  protocol  = "email"
  endpoint  = each.value
}

resource "aws_cloudwatch_metric_alarm" "ecs_cpu" {
  for_each            = var.service_names
  alarm_name          = "${var.name}-${each.value}-cpu-high"
  alarm_description   = "${each.value}: average CPU above 85% for 15 minutes"
  namespace           = "AWS/ECS"
  metric_name         = "CPUUtilization"
  dimensions          = { ClusterName = var.cluster_name, ServiceName = each.value }
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 3
  threshold           = 85
  comparison_operator = "GreaterThanThreshold"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

resource "aws_cloudwatch_metric_alarm" "ecs_memory" {
  for_each            = var.service_names
  alarm_name          = "${var.name}-${each.value}-memory-high"
  alarm_description   = "${each.value}: average memory above 85% for 15 minutes"
  namespace           = "AWS/ECS"
  metric_name         = "MemoryUtilization"
  dimensions          = { ClusterName = var.cluster_name, ServiceName = each.value }
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 3
  threshold           = 85
  comparison_operator = "GreaterThanThreshold"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

resource "aws_cloudwatch_metric_alarm" "target_5xx" {
  for_each          = var.target_group_arn_suffixes
  alarm_name        = "${var.name}-${replace(each.key, "_", "-")}-5xx"
  alarm_description = "${replace(each.key, "_", "-")}: more than 10 target 5xx responses in 5 minutes, twice"
  namespace         = "AWS/ApplicationELB"
  metric_name       = "HTTPCode_Target_5XX_Count"
  dimensions = {
    TargetGroup  = each.value
    LoadBalancer = var.target_group_lb[each.key] == "public" ? var.public_alb_arn_suffix : var.internal_alb_arn_suffix
  }
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 2
  threshold           = 10
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

resource "aws_cloudwatch_metric_alarm" "unhealthy_targets" {
  for_each          = var.target_group_arn_suffixes
  alarm_name        = "${var.name}-${replace(each.key, "_", "-")}-unhealthy"
  alarm_description = "${replace(each.key, "_", "-")}: at least one target failing /healthz for 5 minutes"
  namespace         = "AWS/ApplicationELB"
  metric_name       = "UnHealthyHostCount"
  dimensions = {
    TargetGroup  = each.value
    LoadBalancer = var.target_group_lb[each.key] == "public" ? var.public_alb_arn_suffix : var.internal_alb_arn_suffix
  }
  statistic           = "Maximum"
  period              = 60
  evaluation_periods  = 5
  threshold           = 0
  comparison_operator = "GreaterThanThreshold"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

resource "aws_cloudwatch_metric_alarm" "db_cpu" {
  alarm_name          = "${var.name}-db-cpu-high"
  alarm_description   = "Platform Postgres CPU above 80% for 15 minutes"
  namespace           = "AWS/RDS"
  metric_name         = "CPUUtilization"
  dimensions          = { DBInstanceIdentifier = var.db_identifier }
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 3
  threshold           = 80
  comparison_operator = "GreaterThanThreshold"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

resource "aws_cloudwatch_metric_alarm" "db_storage" {
  alarm_name          = "${var.name}-db-free-storage-low"
  alarm_description   = "Platform Postgres free storage below 5 GiB"
  namespace           = "AWS/RDS"
  metric_name         = "FreeStorageSpace"
  dimensions          = { DBInstanceIdentifier = var.db_identifier }
  statistic           = "Minimum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 5368709120
  comparison_operator = "LessThanThreshold"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

# A reconcile task that stops with a non-zero exit code (or fails to start) notifies the topic.
resource "aws_cloudwatch_event_rule" "reconcile_failed" {
  name        = "${var.name}-reconcile-failed"
  description = "telemetry-bridge daily reconcile task stopped with a failure"
  event_pattern = jsonencode({
    source      = ["aws.ecs"]
    detail-type = ["ECS Task State Change"]
    detail = {
      lastStatus = ["STOPPED"]
      group      = ["family:${var.reconcile_task_family}"]
      containers = {
        name     = ["telemetry-bridge"]
        exitCode = [{ "anything-but" = 0 }]
      }
    }
  })
  tags = local.tags
}

resource "aws_cloudwatch_event_target" "reconcile_failed" {
  rule = aws_cloudwatch_event_rule.reconcile_failed.name
  arn  = aws_sns_topic.alarms.arn
}

# Same for the daily agent invocation purge (platform-services invocation_purge_enabled).
resource "aws_cloudwatch_event_rule" "invocation_purge_failed" {
  count       = var.invocation_purge_task_family == null ? 0 : 1
  name        = "${var.name}-invocation-purge-failed"
  description = "platform-api daily invocation purge task stopped with a failure"
  event_pattern = jsonencode({
    source      = ["aws.ecs"]
    detail-type = ["ECS Task State Change"]
    detail = {
      lastStatus = ["STOPPED"]
      group      = ["family:${var.invocation_purge_task_family}"]
      containers = {
        name     = ["platform-api"]
        exitCode = [{ "anything-but" = 0 }]
      }
    }
  })
  tags = local.tags
}

resource "aws_cloudwatch_event_target" "invocation_purge_failed" {
  count = length(aws_cloudwatch_event_rule.invocation_purge_failed)
  rule  = aws_cloudwatch_event_rule.invocation_purge_failed[0].name
  arn   = aws_sns_topic.alarms.arn
}

data "aws_iam_policy_document" "alarms_topic" {
  statement {
    sid       = "CloudWatchAlarms"
    actions   = ["sns:Publish"]
    resources = [aws_sns_topic.alarms.arn]
    principals {
      type        = "Service"
      identifiers = ["cloudwatch.amazonaws.com", "events.amazonaws.com"]
    }
  }
}

resource "aws_sns_topic_policy" "alarms" {
  arn    = aws_sns_topic.alarms.arn
  policy = data.aws_iam_policy_document.alarms_topic.json
}
