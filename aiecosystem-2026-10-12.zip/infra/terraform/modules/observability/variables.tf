variable "name" {
  description = "Name prefix, e.g. aig-dev."
  type        = string
}

variable "kms_key_arn" {
  description = "KMS key for the alarm SNS topic."
  type        = string
}

variable "alarm_emails" {
  description = "Email subscriptions for the alarm topic (each must confirm). Slack/PagerDuty: subscribe their HTTPS endpoints outside Terraform."
  type        = list(string)
  default     = []
}

variable "cluster_name" {
  type = string
}

variable "service_names" {
  description = "key -> ECS service name."
  type        = map(string)
}

variable "public_alb_arn_suffix" {
  type = string
}

variable "internal_alb_arn_suffix" {
  type = string
}

variable "target_group_arn_suffixes" {
  description = "key -> target group arn_suffix (same keys as service_names)."
  type        = map(string)
}

variable "target_group_lb" {
  description = "key -> \"public\" or \"internal\": which ALB serves the target group."
  type        = map(string)
  default = {
    platform_api     = "public"
    web              = "public"
    telemetry_bridge = "internal"
    cache_compress   = "internal"
  }
}

variable "db_identifier" {
  type = string
}

variable "reconcile_task_family" {
  description = "Task definition family of the daily reconcile task (a failed run alarms)."
  type        = string
}

variable "invocation_purge_task_family" {
  description = "Task definition family of the daily `aig-platform-api invocations purge` task (a failed run alarms). null = purge not deployed, no rule."
  type        = string
  default     = null
}

variable "tags" {
  type    = map(string)
  default = {}
}

variable "workspaces" {
  description = <<-EOT
    Phase 6 workspaces (null = none): the workspaces cluster, its long-running services
    (orchestrator, teams-bot), the orchestrator log group (failed-workspace metric filter) and the
    number of failed workspaces per hour that alarms.
  EOT
  type = object({
    cluster_name           = string
    service_names          = map(string)
    orchestrator_log_group = string
    failed_per_hour        = optional(number, 3)
  })
  default = null
}
