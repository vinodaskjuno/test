# Phase 6 workspaces: a long-running workspace service (orchestrator, teams-bot) with no running
# task, and failed workspaces counted from the orchestrator log.
locals {
  ws_services = var.workspaces == null ? {} : var.workspaces.service_names
}

# Container Insights (enhanced, enabled on the workspaces cluster) publishes RunningTaskCount per
# service. No data at all also counts as down.
resource "aws_cloudwatch_metric_alarm" "workspace_service_down" {
  for_each            = local.ws_services
  alarm_name          = "${var.name}-${each.value}-down"
  alarm_description   = "${each.value}: no running task for 3 minutes (workspaces are not dispatched / Teams is not answered)"
  namespace           = "ECS/ContainerInsights"
  metric_name         = "RunningTaskCount"
  dimensions          = { ClusterName = var.workspaces.cluster_name, ServiceName = each.value }
  statistic           = "Minimum"
  period              = 60
  evaluation_periods  = 3
  threshold           = 1
  comparison_operator = "LessThanThreshold"
  treat_missing_data  = "breaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}

# The orchestrator logs "workspace <id> -> failed (...)" when it fails a workspace (task ended
# without a PR, idle timeout, max runtime, could not start) and the relay logs
# "workspace <id> reported failed" when the job itself reports the failure. Each failure is logged
# once by one of the two.
resource "aws_cloudwatch_log_metric_filter" "workspace_failed" {
  count          = var.workspaces == null ? 0 : 1
  name           = "${var.name}-workspace-failed"
  log_group_name = var.workspaces.orchestrator_log_group
  pattern        = "?\"-> failed\" ?\"reported failed\""
  metric_transformation {
    name          = "WorkspacesFailed"
    namespace     = "AIG/Workspaces"
    value         = "1"
    default_value = "0"
    unit          = "Count"
  }
}

resource "aws_cloudwatch_metric_alarm" "workspace_failed" {
  count               = var.workspaces == null ? 0 : 1
  alarm_name          = "${var.name}-workspaces-failed"
  alarm_description   = "More than ${var.workspaces.failed_per_hour} workspaces failed in the last hour (orchestrator log, /aig/<env>/workspaces for the job logs)"
  namespace           = "AIG/Workspaces"
  metric_name         = aws_cloudwatch_log_metric_filter.workspace_failed[0].metric_transformation[0].name
  statistic           = "Sum"
  period              = 3600
  evaluation_periods  = 1
  threshold           = var.workspaces.failed_per_hour
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = local.tags
}
