variable "name_prefix" {
  description = "Repository name prefix, e.g. aig (repos are <prefix>/<name>)."
  type        = string
  default     = "aig"
}

variable "repositories" {
  description = "Repository names: the platform services plus one per agent (agents/<agent_id>)."
  type        = list(string)
}

variable "kms_key_arn" {
  description = "KMS key for image encryption (null = AES256)."
  type        = string
  default     = null
}

variable "keep_tagged_images" {
  description = "Tagged images kept per repository (older ones expire; every deployed digest must be among them)."
  type        = number
  default     = 100
}

variable "untagged_expiry_days" {
  type    = number
  default = 7
}

variable "pull_account_ids" {
  description = "Other AWS accounts (stage/prod) allowed to pull, for cross-account promotion of the same digest."
  type        = list(string)
  default     = []
}

variable "force_delete" {
  description = "Allow terraform destroy of a repository that still holds images (dev only)."
  type        = bool
  default     = false
}

variable "tags" {
  type    = map(string)
  default = {}
}
