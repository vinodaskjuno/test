# One Bedrock AgentCore runtime per agent per environment.
#
# Resource type: aws_bedrockagentcore_agent_runtime (+ _endpoint) from hashicorp/aws ~> 6.x
# (verified with `terraform providers schema -json`, aws v6.x; awscc_bedrockagentcore_runtime is
# the Cloud Control equivalent and is not needed).
#
#   * The container image is pinned by digest (promotion moves the same digest dev -> stage -> prod).
#   * VPC network mode in the private subnets with the egress allow-list security group: the agent
#     can reach only Portkey, Fiddler and the AWS VPC endpoints.
#   * AIG_* non-secret settings are runtime environment variables. AgentCore has no native secret
#     injection, so the three agent secrets (local.secret_keys) live in
#     Secrets Manager aig/<env>/agents/<agent_id>; the image's AgentCore entrypoint
#     (infra/ci/docker/agentcore_shim.py / agentcore-shim.mjs) reads AIG_RUNTIME_SECRET_ARN at start, puts
#     the values in its own process environment and only then calls the SDK's fail-closed init().
#   * Tagged aig:registered=true (var.registry_invocable): platform-api's task role may invoke it
#     (tag-scoped bedrock-agentcore:InvokeAgentRuntime, modules/platform-services); the three aig-http/1
#     custom headers are allow-listed (request_header_configuration).
#   * Least-privilege role: pull from this agent's repo only, write its logs/traces/metrics, read its
#     own secret. No bedrock:InvokeModel: models are reached only through the Portkey gateway.

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_partition" "current" {}

locals {
  account   = data.aws_caller_identity.current.account_id
  region    = data.aws_region.current.region
  partition = data.aws_partition.current.partition
  # AgentCore names: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$
  runtime_name = substr("aig_${var.env}_${replace(var.agent_id, "/[^A-Za-z0-9_]/", "_")}", 0, 48)
  secret_keys  = ["AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY", "AIG_PLATFORM_API_TOKEN"] # gitleaks:allow (names)
  tags = merge(var.tags, {
    "aig:module"   = "agentcore-runtime"
    "aig:env"      = var.env
    "aig:agent_id" = var.agent_id
    "aig:team"     = var.team
    # platform-api may invoke only runtimes tagged aig:registered=true in its env (modules/platform-services).
    "aig:registered" = var.registry_invocable ? "true" : "false"
  })

  # backend/contracts/agent-invocation.md: AgentCore forwards only allow-listed custom headers;
  # platform-api sends the caller token, invocation id and trace id as these (and mirrors them in
  # the body as aig_context).
  invocation_headers = [
    "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller",
    "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Invocation-Id",
    "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Trace-Id",
  ]

  # backend/contracts/env-vars.md, SDK section. Optional values are left out when null.
  aig_environment = { for k, v in merge({
    AIG_PORTKEY_BASE_URL       = var.portkey_base_url
    AIG_PORTKEY_CONFIG         = var.portkey_config
    AIG_PORTKEY_MCP_URL        = var.portkey_mcp_url
    AIG_FIDDLER_URL            = var.fiddler_url
    AIG_FIDDLER_PROJECT        = coalesce(var.fiddler_project, "aig-${var.env}")
    AIG_FIDDLER_APPLICATION_ID = var.fiddler_application_id
    AIG_OTLP_ENDPOINT          = var.otlp_endpoint
    AIG_PLATFORM_API_URL       = var.platform_api_url
    AIG_AGENT_ID               = var.agent_id
    AIG_TEAM                   = var.team
    AIG_ENV                    = var.env
    AIG_HOST                   = "agentcore"
    AIG_USER_TIER              = var.user_tier
    AIG_JOB_PROFILE            = var.job_profile
    AIG_LOG_LEVEL              = var.log_level
    AWS_REGION                 = local.region
  }, var.extra_environment) : k => v if v != null }

  runtime_environment = merge(local.aig_environment, {
    # Read by the AgentCore entrypoint shim, never by the SDK: JSON secret holding local.secret_keys.
    AIG_RUNTIME_SECRET_ARN = aws_secretsmanager_secret.agent.arn
  })
}

# ---------------------------------------------------------------------------------------------
# Agent secret (placeholders only; values uploaded by hand)
# ---------------------------------------------------------------------------------------------
resource "aws_secretsmanager_secret" "agent" {
  name                    = "aig/${var.env}/agents/${var.agent_id}"
  description             = "AIG agent ${var.agent_id} (${var.env}): scoped Portkey key, Fiddler token, platform-api token"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = var.secret_recovery_window_in_days
  tags                    = local.tags
}

resource "aws_secretsmanager_secret_version" "agent_placeholder" {
  secret_id     = aws_secretsmanager_secret.agent.id
  secret_string = jsonencode({ for k in local.secret_keys : k => "__REPLACE_ME_${k}_${upper(var.env)}__" })
  lifecycle {
    ignore_changes = [secret_string, version_stages]
  }
}

# ---------------------------------------------------------------------------------------------
# Execution role
# ---------------------------------------------------------------------------------------------
data "aws_iam_policy_document" "assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["bedrock-agentcore.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [local.account]
    }
    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values   = ["arn:${local.partition}:bedrock-agentcore:${local.region}:${local.account}:*"]
    }
  }
}

data "aws_iam_policy_document" "runtime" {
  statement {
    sid       = "PullOwnImage"
    actions   = ["ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer"]
    resources = [var.ecr_repository_arn]
  }
  statement {
    sid       = "EcrAuth"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }
  statement {
    sid       = "Logs"
    actions   = ["logs:CreateLogGroup", "logs:DescribeLogStreams", "logs:CreateLogStream", "logs:PutLogEvents"]
    resources = ["arn:${local.partition}:logs:${local.region}:${local.account}:log-group:/aws/bedrock-agentcore/runtimes/*"]
  }
  statement {
    sid       = "LogsDescribe"
    actions   = ["logs:DescribeLogGroups"]
    resources = ["arn:${local.partition}:logs:${local.region}:${local.account}:log-group:*"]
  }
  statement {
    sid       = "Traces"
    actions   = ["xray:PutTraceSegments", "xray:PutTelemetryRecords", "xray:GetSamplingRules", "xray:GetSamplingTargets"]
    resources = ["*"]
  }
  statement {
    sid       = "Metrics"
    actions   = ["cloudwatch:PutMetricData"]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "cloudwatch:namespace"
      values   = ["bedrock-agentcore"]
    }
  }
  statement {
    sid = "WorkloadIdentity"
    actions = [
      "bedrock-agentcore:GetWorkloadAccessToken",
      "bedrock-agentcore:GetWorkloadAccessTokenForJWT",
      "bedrock-agentcore:GetWorkloadAccessTokenForUserId",
    ]
    resources = [
      "arn:${local.partition}:bedrock-agentcore:${local.region}:${local.account}:workload-identity-directory/default",
      "arn:${local.partition}:bedrock-agentcore:${local.region}:${local.account}:workload-identity-directory/default/workload-identity/${local.runtime_name}-*",
    ]
  }
  statement {
    sid       = "ReadOwnSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.agent.arn]
  }
  statement {
    sid       = "DecryptOwnSecret"
    actions   = ["kms:Decrypt"]
    resources = [var.kms_key_arn]
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["secretsmanager.${local.region}.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "runtime" {
  name                 = substr("aig-${var.env}-agent-${replace(var.agent_id, ".", "-")}", 0, 64)
  description          = "AgentCore runtime role for AIG agent ${var.agent_id} (${var.env})"
  assume_role_policy   = data.aws_iam_policy_document.assume.json
  max_session_duration = 3600
  tags                 = local.tags
}

resource "aws_iam_role_policy" "runtime" {
  name   = "agentcore-runtime"
  role   = aws_iam_role.runtime.id
  policy = data.aws_iam_policy_document.runtime.json
}

# ---------------------------------------------------------------------------------------------
# Runtime + endpoint
# ---------------------------------------------------------------------------------------------
resource "aws_bedrockagentcore_agent_runtime" "this" {
  agent_runtime_name    = local.runtime_name
  description           = "AIG agent ${var.agent_id} (team ${var.team}, ${var.env})"
  role_arn              = aws_iam_role.runtime.arn
  environment_variables = local.runtime_environment

  agent_runtime_artifact {
    container_configuration {
      container_uri = var.image_uri
    }
  }

  network_configuration {
    network_mode = "VPC"
    network_mode_config {
      subnets         = var.subnet_ids
      security_groups = var.security_group_ids
    }
  }

  protocol_configuration {
    server_protocol = "HTTP"
  }

  request_header_configuration {
    request_header_allowlist = local.invocation_headers
  }

  lifecycle_configuration {
    idle_runtime_session_timeout = var.idle_runtime_session_timeout
    max_lifetime                 = var.max_lifetime
  }

  dynamic "authorizer_configuration" {
    for_each = var.jwt_authorizer == null ? [] : [var.jwt_authorizer]
    content {
      custom_jwt_authorizer {
        discovery_url    = authorizer_configuration.value.discovery_url
        allowed_audience = authorizer_configuration.value.allowed_audience
        allowed_clients  = authorizer_configuration.value.allowed_clients
      }
    }
  }

  tags = local.tags

  # The role policy must exist before AgentCore validates the role and pulls the image.
  depends_on = [aws_iam_role_policy.runtime, aws_secretsmanager_secret_version.agent_placeholder]
}

resource "aws_bedrockagentcore_agent_runtime_endpoint" "this" {
  name                  = var.endpoint_name
  agent_runtime_id      = aws_bedrockagentcore_agent_runtime.this.agent_runtime_id
  agent_runtime_version = aws_bedrockagentcore_agent_runtime.this.agent_runtime_version
  description           = "AIG ${var.env} endpoint for ${var.agent_id}, pinned to the deployed runtime version"
  tags                  = local.tags
}

# AgentCore writes to /aws/bedrock-agentcore/runtimes/<runtime_id>-<endpoint>; create it up front
# with retention and KMS encryption (otherwise it is created on first use, never expiring).
resource "aws_cloudwatch_log_group" "endpoint" {
  name              = "/aws/bedrock-agentcore/runtimes/${aws_bedrockagentcore_agent_runtime.this.agent_runtime_id}-${var.endpoint_name}"
  retention_in_days = var.log_retention_days
  kms_key_id        = var.kms_key_arn
  tags              = local.tags
}
