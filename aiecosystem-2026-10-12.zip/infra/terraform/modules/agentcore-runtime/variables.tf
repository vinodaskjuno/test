variable "env" {
  description = "dev, stage or prod (AIG_ENV)."
  type        = string
  validation {
    condition     = contains(["dev", "stage", "prod"], var.env)
    error_message = "env must be dev, stage or prod."
  }
}

variable "agent_id" {
  description = "Registered agent id (AIG_AGENT_ID), ^[A-Za-z0-9._-]{1,64}$."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9._-]{1,64}$", var.agent_id))
    error_message = "agent_id must match ^[A-Za-z0-9._-]{1,64}$ (backend/contracts/env-vars.md)."
  }
}

variable "team" {
  description = "Owning team slug (AIG_TEAM)."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9._-]{1,64}$", var.team))
    error_message = "team must match ^[A-Za-z0-9._-]{1,64}$."
  }
}

variable "image_uri" {
  description = "ECR image pinned by digest: <account>.dkr.ecr.<region>.amazonaws.com/aig/agents/<id>@sha256:<64 hex>. Tags are refused: promotion moves the same digest dev -> stage -> prod."
  type        = string
  validation {
    condition     = can(regex("^[0-9]{12}\\.dkr\\.ecr\\.[a-z0-9-]+\\.amazonaws\\.com/[a-z0-9._/-]+@sha256:[0-9a-f]{64}$", var.image_uri))
    error_message = "image_uri must be an ECR image pinned by digest (...@sha256:<64 hex>)."
  }
}

variable "ecr_repository_arn" {
  description = "ARN of the agent's ECR repository (the runtime role may pull only from it)."
  type        = string
}

variable "subnet_ids" {
  description = "Private subnets (VPC network mode)."
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups: the network module's egress allow-list group (HTTPS only to Portkey, Fiddler, VPC endpoints)."
  type        = list(string)
}

variable "kms_key_arn" {
  description = "Environment KMS key (agent secret + log group encryption)."
  type        = string
}

# --- AIG_* runtime configuration (non-secret; backend/contracts/env-vars.md) ---------------------------
variable "portkey_base_url" {
  description = "AIG_PORTKEY_BASE_URL, e.g. https://portkey.<corp>/v1."
  type        = string
}

variable "portkey_config" {
  description = "AIG_PORTKEY_CONFIG."
  type        = string
  default     = "pc-aig-router"
}

variable "portkey_mcp_url" {
  description = "AIG_PORTKEY_MCP_URL (optional)."
  type        = string
  default     = null
}

variable "fiddler_url" {
  description = "AIG_FIDDLER_URL."
  type        = string
}

variable "fiddler_project" {
  description = "AIG_FIDDLER_PROJECT (default aig-<env>)."
  type        = string
  default     = null
}

variable "fiddler_application_id" {
  description = "AIG_FIDDLER_APPLICATION_ID (optional: falls back to the platform-api registry record)."
  type        = string
  default     = null
}

variable "otlp_endpoint" {
  description = "AIG_OTLP_ENDPOINT (optional)."
  type        = string
  default     = null
}

variable "platform_api_url" {
  description = "AIG_PLATFORM_API_URL (registry lookup on init)."
  type        = string
}

variable "user_tier" {
  description = "AIG_USER_TIER (premium, standard, free) or null when every call passes a tier."
  type        = string
  default     = null
  validation {
    condition     = var.user_tier == null || contains(["premium", "standard", "free"], coalesce(var.user_tier, "standard"))
    error_message = "user_tier must be premium, standard or free."
  }
}

variable "job_profile" {
  description = "AIG_JOB_PROFILE."
  type        = string
  default     = "general"
  validation {
    condition     = contains(["underwriting", "claims", "operations", "general"], var.job_profile)
    error_message = "job_profile must be underwriting, claims, operations or general."
  }
}

variable "log_level" {
  type    = string
  default = "INFO"
}

variable "extra_environment" {
  description = "Additional NON-secret variables. Secret names and raw provider keys are refused."
  type        = map(string)
  default     = {}
  validation {
    condition = alltrue([for k in keys(var.extra_environment) : !contains([
      "AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY", "AIG_PLATFORM_API_TOKEN", # gitleaks:allow (names)
      "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "AZURE_OPENAI_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEY",
      "MISTRAL_API_KEY", "COHERE_API_KEY", "AWS_BEARER_TOKEN_BEDROCK",
    ], k)])
    error_message = "extra_environment must not carry secrets or raw provider keys: they come from the agent secret (AIG_*) or not at all (provider keys)."
  }
}

# --- Runtime behaviour ------------------------------------------------------------------------
variable "idle_runtime_session_timeout" {
  description = "Seconds before an idle session is stopped."
  type        = number
  default     = 900
}

variable "max_lifetime" {
  description = "Maximum session lifetime in seconds."
  type        = number
  default     = 28800
}

variable "endpoint_name" {
  description = "Runtime endpoint that callers use; it is pinned to the runtime version this apply produced."
  type        = string
  default     = "live"
}

variable "registry_invocable" {
  description = "Tag the runtime aig:registered=true so platform-api (agent registry) may invoke it with its IAM role. false keeps it reachable only by direct SigV4 callers (smoke tests)."
  type        = bool
  default     = true
}

variable "jwt_authorizer" {
  description = "Optional inbound JWT authorizer (Entra ID): discovery URL + allowed audiences/clients. null = IAM (SigV4) callers only."
  type = object({
    discovery_url    = string
    allowed_audience = optional(list(string))
    allowed_clients  = optional(list(string))
  })
  default = null
}

variable "log_retention_days" {
  type    = number
  default = 90
}

variable "secret_recovery_window_in_days" {
  type    = number
  default = 30
}

variable "tags" {
  type    = map(string)
  default = {}
}
