# Offline plan tests (mock AWS provider): image by digest, VPC mode, AIG_* wiring, no secrets in env.
mock_provider "aws" {
  mock_data "aws_region" {
    defaults = { region = "us-east-1" }
  }
  mock_data "aws_caller_identity" {
    defaults = { account_id = "123456789012" }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{}" }
  }
}

variables {
  env                = "dev"
  agent_id           = "langgraph-py-sample"
  team               = "sample-team"
  image_uri          = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/agents/langgraph-py-sample@sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
  ecr_repository_arn = "arn:aws:ecr:us-east-1:123456789012:repository/aig/agents/langgraph-py-sample"
  subnet_ids         = ["subnet-a", "subnet-b"]
  security_group_ids = ["sg-egress-allowlist"]
  kms_key_arn        = "arn:aws:kms:us-east-1:123456789012:key/test"
  portkey_base_url   = "https://portkey.corp.example.com/v1"
  fiddler_url        = "https://aig.fiddler.example.com"
  platform_api_url   = "https://aig-api-dev.example.com"
  user_tier          = "standard"
}

run "runtime_is_wired_for_the_aig_contract" {
  command = plan

  assert {
    condition     = aws_bedrockagentcore_agent_runtime.this.agent_runtime_name == "aig_dev_langgraph_py_sample"
    error_message = "runtime name must be sanitised to ^[a-zA-Z][a-zA-Z0-9_]{0,47}$"
  }
  assert {
    condition     = aws_bedrockagentcore_agent_runtime.this.network_configuration[0].network_mode == "VPC"
    error_message = "runtimes run in VPC mode in the restricted subnets"
  }
  assert {
    condition     = aws_bedrockagentcore_agent_runtime.this.agent_runtime_artifact[0].container_configuration[0].container_uri == var.image_uri
    error_message = "the runtime runs the digest it was given"
  }
  assert {
    condition = alltrue([for k in [
      "AIG_PORTKEY_BASE_URL", "AIG_FIDDLER_URL", "AIG_FIDDLER_PROJECT", "AIG_PLATFORM_API_URL",
      "AIG_AGENT_ID", "AIG_TEAM", "AIG_ENV", "AIG_HOST", "AIG_USER_TIER",
    ] : contains(keys(local.aig_environment), k)])
    error_message = "every required non-secret AIG_* variable must be set on the runtime"
  }
  assert {
    condition     = contains(keys(local.runtime_environment), "AIG_RUNTIME_SECRET_ARN")
    error_message = "the runtime gets its secret ARN (never the secret values)"
  }
  assert {
    condition     = local.aig_environment["AIG_HOST"] == "agentcore" && local.aig_environment["AIG_FIDDLER_PROJECT"] == "aig-dev"
    error_message = "AIG_HOST=agentcore and AIG_FIDDLER_PROJECT=aig-<env>"
  }
  assert {
    condition = length(setintersection(keys(local.aig_environment), [
      "AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY", "AIG_PLATFORM_API_TOKEN", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", # gitleaks:allow (names)
    ])) == 0
    error_message = "secrets and provider keys are never runtime environment variables"
  }
  assert {
    condition     = aws_secretsmanager_secret.agent.name == "aig/dev/agents/langgraph-py-sample"
    error_message = "agent secret id is aig/<env>/agents/<agent_id>"
  }
  assert {
    condition     = jsondecode(aws_secretsmanager_secret_version.agent_placeholder.secret_string)["AIG_PORTKEY_API_KEY"] == "__REPLACE_ME_AIG_PORTKEY_API_KEY_DEV__"
    error_message = "the secret is created with placeholders only"
  }
}

run "refuses_image_tag" {
  command = plan
  variables {
    image_uri = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/agents/langgraph-py-sample:latest"
  }
  expect_failures = [var.image_uri]
}

run "refuses_secret_in_extra_environment" {
  command = plan
  variables {
    extra_environment = { OPENAI_API_KEY = "sk-not-allowed" }
  }
  expect_failures = [var.extra_environment]
}

run "runtime_is_invocable_through_the_registry" {
  command = plan

  assert {
    condition     = aws_bedrockagentcore_agent_runtime.this.tags["aig:registered"] == "true" && aws_bedrockagentcore_agent_runtime_endpoint.this.tags["aig:registered"] == "true"
    error_message = "runtime and endpoint are tagged aig:registered=true (platform-api's tag-scoped InvokeAgentRuntime)"
  }
  assert {
    condition     = aws_bedrockagentcore_agent_runtime.this.tags["aig:env"] == "dev"
    error_message = "runtimes carry aig:env (platform-api may invoke only its own env's runtimes)"
  }
  assert {
    condition = toset(aws_bedrockagentcore_agent_runtime.this.request_header_configuration[0].request_header_allowlist) == toset([
      "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller",
      "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Invocation-Id",
      "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Trace-Id",
    ])
    error_message = "exactly the three aig-http/1 custom headers are forwarded to the agent"
  }
}

run "runtime_can_opt_out_of_the_registry" {
  command = plan
  variables {
    registry_invocable = false
  }
  assert {
    condition     = aws_bedrockagentcore_agent_runtime.this.tags["aig:registered"] == "false"
    error_message = "registry_invocable=false removes platform-api's access (tag false)"
  }
}
