output "agent_runtime_arn" {
  value = aws_bedrockagentcore_agent_runtime.this.agent_runtime_arn
}

output "agent_runtime_id" {
  value = aws_bedrockagentcore_agent_runtime.this.agent_runtime_id
}

output "agent_runtime_version" {
  value = aws_bedrockagentcore_agent_runtime.this.agent_runtime_version
}

output "agent_runtime_name" {
  value = local.runtime_name
}

output "endpoint_arn" {
  value = aws_bedrockagentcore_agent_runtime_endpoint.this.agent_runtime_endpoint_arn
}

output "endpoint_name" {
  value = var.endpoint_name
}

output "role_arn" {
  value = aws_iam_role.runtime.arn
}

output "secret_arn" {
  value = aws_secretsmanager_secret.agent.arn
}

output "secret_name" {
  value = aws_secretsmanager_secret.agent.name
}

output "log_group_name" {
  value = aws_cloudwatch_log_group.endpoint.name
}

output "environment_variable_names" {
  description = "Names (not values) of the runtime environment variables, for the image-check cross-test."
  value       = sort(concat(keys(local.aig_environment), ["AIG_RUNTIME_SECRET_ARN"]))
}

output "image_uri" {
  value = var.image_uri
}
