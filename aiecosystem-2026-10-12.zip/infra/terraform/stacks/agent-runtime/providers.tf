provider "aws" {
  region              = var.aws_region
  allowed_account_ids = [var.aws_account_id]
  default_tags {
    tags = {
      "aig:env"        = var.env
      "aig:agent_id"   = var.agent_id
      "aig:managed-by" = "terraform"
      "aig:repo"       = "aiecosystem/infra/terraform/stacks/agent-runtime"
    }
  }
}
