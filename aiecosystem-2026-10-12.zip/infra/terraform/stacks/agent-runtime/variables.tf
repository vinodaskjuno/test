variable "aws_region" {
  type = string
}

variable "aws_account_id" {
  type = string
  validation {
    condition     = can(regex("^[0-9]{12}$", var.aws_account_id))
    error_message = "aws_account_id must be a 12-digit AWS account id."
  }
}

variable "env" {
  description = "dev, stage or prod: selects /aig/<env>/infra/agent-runtime-inputs written by envs/<env>."
  type        = string
}

variable "agent_id" {
  type = string
}

variable "team" {
  type = string
}

variable "image_uri" {
  description = "Agent image by digest; set by .github/workflows/deploy-agent.yml (the digest that passed infra/ci/image-check)."
  type        = string
}

variable "user_tier" {
  type    = string
  default = null
}

variable "job_profile" {
  type    = string
  default = "general"
}

variable "fiddler_application_id" {
  type    = string
  default = null
}

variable "extra_environment" {
  type    = map(string)
  default = {}
}

variable "jwt_authorizer" {
  type = object({
    discovery_url    = string
    allowed_audience = optional(list(string))
    allowed_clients  = optional(list(string))
  })
  default = null
}
