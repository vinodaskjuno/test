terraform {
  required_version = ">= 1.9.0, < 2.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
  # Remote state: one state per agent per env (key aig/<env>/agents/<agent_id>.tfstate):
  #   terraform init -backend-config=backend.hcl      (copy backend.hcl.example; backend.hcl is gitignored)
  # Offline validation uses `terraform init -backend=false`.
  backend "s3" {}
}
