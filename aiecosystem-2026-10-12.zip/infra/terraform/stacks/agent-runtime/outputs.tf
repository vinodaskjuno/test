output "agent_runtime_arn" {
  value = module.agent.agent_runtime_arn
}

output "agent_runtime_version" {
  value = module.agent.agent_runtime_version
}

output "endpoint_arn" {
  value = module.agent.endpoint_arn
}

output "endpoint_name" {
  value = module.agent.endpoint_name
}

output "secret_name" {
  description = "Upload the agent's keys here by hand (docs/deploy.md)."
  value       = module.agent.secret_name
}

output "log_group_name" {
  value = module.agent.log_group_name
}

output "image_uri" {
  value = module.agent.image_uri
}
