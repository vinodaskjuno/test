# One AgentCore runtime for one agent in one environment. Applied by
# .github/workflows/deploy-agent.yml with state key aig/<env>/agents/<agent_id>.tfstate.
# Network, KMS and endpoint settings come from the env stack (SSM parameter), so this stack needs
# no access to the env state.

data "aws_ssm_parameter" "inputs" {
  name = "/aig/${var.env}/infra/agent-runtime-inputs"
}

locals {
  inputs = jsondecode(data.aws_ssm_parameter.inputs.value)
  # <account>.dkr.ecr.<region>.amazonaws.com/<repo>@sha256:<digest>  ->  repository ARN
  image = regex("^(?P<account>[0-9]{12})\\.dkr\\.ecr\\.(?P<region>[a-z0-9-]+)\\.amazonaws\\.com/(?P<repo>[a-z0-9._/-]+)@sha256:[0-9a-f]{64}$", var.image_uri)
}

module "agent" {
  source = "../../modules/agentcore-runtime"

  env                = var.env
  agent_id           = var.agent_id
  team               = var.team
  image_uri          = var.image_uri
  ecr_repository_arn = "arn:aws:ecr:${local.image.region}:${local.image.account}:repository/${local.image.repo}"
  subnet_ids         = local.inputs.private_subnet_ids
  security_group_ids = local.inputs.security_group_ids
  kms_key_arn        = local.inputs.kms_key_arn

  portkey_base_url       = local.inputs.portkey_base_url
  portkey_mcp_url        = local.inputs.portkey_mcp_url
  fiddler_url            = local.inputs.fiddler_url
  platform_api_url       = local.inputs.platform_api_url
  fiddler_application_id = var.fiddler_application_id
  user_tier              = var.user_tier
  job_profile            = var.job_profile
  extra_environment      = var.extra_environment
  jwt_authorizer         = var.jwt_authorizer
}
