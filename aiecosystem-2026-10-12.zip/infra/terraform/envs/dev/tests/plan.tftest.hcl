# Offline plan of the whole dev environment with the mock AWS provider: catches composition and
# type errors that `terraform validate` cannot see, without any AWS account.
mock_provider "aws" {
  mock_data "aws_region" {
    defaults = { region = "us-east-1" }
  }
  mock_data "aws_caller_identity" {
    defaults = { account_id = "123456789012" }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{}" }
  }
}

variables {
  aws_region           = "us-east-1"
  aws_account_id       = "123456789012"
  vpc_cidr             = "10.40.0.0/16"
  azs                  = ["us-east-1a", "us-east-1b"]
  private_subnet_cidrs = ["10.40.0.0/20", "10.40.16.0/20"]
  public_subnet_cidrs  = ["10.40.128.0/24", "10.40.129.0/24"]
  single_nat_gateway   = true
  portkey_egress_cidrs = ["10.1.2.0/24"]
  fiddler_egress_cidrs = ["203.0.113.0/26"]
  portkey_base_url     = "https://portkey.corp.example.com/v1"
  fiddler_url          = "https://aig.fiddler.example.com"
  agent_ids            = ["langgraph-py-sample"]
  certificate_arn      = "arn:aws:acm:us-east-1:123456789012:certificate/test"
  hostnames = {
    web            = "aig-portal-dev.example.com"
    api            = "aig-api-dev.example.com"
    bridge         = "aig-bridge-dev.example.com"
    cache_compress = "aig-cc-dev.example.com"
  }
  alb_ingress_cidrs        = ["10.0.0.0/8"]
  platform_api_config      = { portkey_gateway_url = "https://portkey.corp.example.com/v1" }
  cache_compress_upstreams = { anthropic = "https://api.anthropic.com" }
  web_config               = { env = "dev", auth = "oidc" }
  db_multi_az              = false
  deletion_protection      = false
}

run "bootstrap_without_platform_images" {
  command = plan

  assert {
    condition     = output.platform == null
    error_message = "the first apply creates network, KMS, secrets and ECR only"
  }
  assert {
    condition     = output.agent_runtime_inputs_parameter == "/aig/dev/infra/agent-runtime-inputs"
    error_message = "the env publishes the agent stack inputs to SSM"
  }
}

run "full_environment_with_images" {
  command = plan
  variables {
    platform_images = {
      platform_api     = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/platform-api@sha256:1111111111111111111111111111111111111111111111111111111111111111"
      telemetry_bridge = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/telemetry-bridge@sha256:2222222222222222222222222222222222222222222222222222222222222222"
      cache_compress   = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/cache-compress@sha256:3333333333333333333333333333333333333333333333333333333333333333"
      web              = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/web@sha256:4444444444444444444444444444444444444444444444444444444444444444"
    }
  }

  assert {
    condition     = output.platform != null
    error_message = "with images the platform services are planned"
  }
}

run "workspaces_bootstrap_creates_secrets_only" {
  command = plan
  variables {
    workspaces = {
      teams               = ["underwriting", "claims"]
      relay_hostname      = "aig-ws-relay-dev.example.com"
      github_egress_cidrs = ["192.30.252.0/22", "140.82.112.0/20"]
      teams_bot_hostname  = "aig-teams-bot-dev.example.com"
    }
  }

  assert {
    condition = alltrue([for n in ["workspace-orchestrator", "teams-bot", "workspaces/shared", "workspaces/underwriting", "workspaces/claims"] :
    contains(keys(output.secret_names), n)])
    error_message = "workspaces creates aig/<env>/workspace-orchestrator, teams-bot, workspaces/shared and workspaces/<team> (placeholders)"
  }
  assert {
    condition     = output.workspaces == null
    error_message = "without images (and the platform) no workspace ECS resources are planned"
  }
}

run "full_environment_with_workspaces" {
  command = plan
  variables {
    platform_images = {
      platform_api     = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/platform-api@sha256:1111111111111111111111111111111111111111111111111111111111111111"
      telemetry_bridge = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/telemetry-bridge@sha256:2222222222222222222222222222222222222222222222222222222222222222"
      cache_compress   = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/cache-compress@sha256:3333333333333333333333333333333333333333333333333333333333333333"
      web              = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/web@sha256:4444444444444444444444444444444444444444444444444444444444444444"
    }
    workspace_images = {
      workspace    = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/workspace@sha256:5555555555555555555555555555555555555555555555555555555555555555"
      orchestrator = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/workspace-orchestrator@sha256:6666666666666666666666666666666666666666666666666666666666666666"
      teams_bot    = "123456789012.dkr.ecr.us-east-1.amazonaws.com/aig/teams-bot@sha256:7777777777777777777777777777777777777777777777777777777777777777"
    }
    workspaces = {
      teams                           = ["underwriting", "claims"]
      relay_hostname                  = "aig-ws-relay-dev.example.com"
      github_egress_cidrs             = ["192.30.252.0/22", "140.82.112.0/20"]
      teams_bot_hostname              = "aig-teams-bot-dev.example.com"
      package_mirror_egress_cidrs     = ["10.9.0.0/24"]
      workspace_cpu                   = 4096
      workspace_memory                = 16384
      workspace_ephemeral_storage_gib = 100
      use_fargate_spot                = true
      teams_bot_tenant_id             = "00000000-0000-0000-0000-000000000000"
      orchestrator_environment = {
        AIG_FIDDLER_PROJECT = "aig-workspace"
        GITHUB_APP_ID       = "123456"
      }
    }
  }

  assert {
    condition     = output.workspaces != null && output.workspaces.cluster == "aig-dev-workspaces"
    error_message = "with workspace images the workspaces cluster is planned"
  }
  assert {
    condition     = output.workspaces.workspace_task_families == { _base = "aig-dev-workspace", underwriting = "aig-dev-workspace-underwriting", claims = "aig-dev-workspace-claims" }
    error_message = "one workspace task definition per team (+ the key-less base)"
  }
}
