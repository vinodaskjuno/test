module "env" {
  source = "../../modules/environment"
  env    = local.env

  vpc_cidr                = var.vpc_cidr
  azs                     = var.azs
  private_subnet_cidrs    = var.private_subnet_cidrs
  public_subnet_cidrs     = var.public_subnet_cidrs
  firewall_subnet_cidrs   = var.firewall_subnet_cidrs
  single_nat_gateway      = var.single_nat_gateway
  egress_mode             = var.egress_mode
  portkey_egress_cidrs    = var.portkey_egress_cidrs
  fiddler_egress_cidrs    = var.fiddler_egress_cidrs
  additional_egress_cidrs = var.additional_egress_cidrs
  egress_allowed_domains  = var.egress_allowed_domains

  portkey_base_url = var.portkey_base_url
  portkey_mcp_url  = var.portkey_mcp_url
  fiddler_url      = var.fiddler_url

  agent_ids            = var.agent_ids
  create_ecr           = var.create_ecr
  ecr_pull_account_ids = var.ecr_pull_account_ids

  platform_images                 = var.platform_images
  certificate_arn                 = var.certificate_arn
  hostnames                       = var.hostnames
  alb_internal                    = var.alb_internal
  alb_ingress_cidrs               = var.alb_ingress_cidrs
  platform_api_config             = var.platform_api_config
  platform_api_users_yaml         = var.platform_api_users_yaml
  platform_api_environment        = var.platform_api_environment
  telemetry_bridge_environment    = var.telemetry_bridge_environment
  cache_compress_upstreams        = var.cache_compress_upstreams
  web_config                      = var.web_config
  service_sizing                  = var.service_sizing
  db_instance_class               = var.db_instance_class
  db_multi_az                     = var.db_multi_az
  deletion_protection             = var.deletion_protection
  reconcile_dry_run               = var.reconcile_dry_run
  invocation_purge_enabled        = var.invocation_purge_enabled
  agent_invocation_retention_days = var.agent_invocation_retention_days
  agent_output_retention_days     = var.agent_output_retention_days
  workspaces                      = var.workspaces
  workspace_images                = var.workspace_images
  alarm_emails                    = var.alarm_emails
  log_retention_days              = var.log_retention_days
}
