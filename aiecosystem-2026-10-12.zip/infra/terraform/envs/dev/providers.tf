provider "aws" {
  region              = var.aws_region
  allowed_account_ids = [var.aws_account_id] # refuses to run against any other account
  default_tags {
    tags = {
      "aig:env"        = local.env
      "aig:managed-by" = "terraform"
      "aig:repo"       = "aiecosystem/infra/terraform/envs/${local.env}"
    }
  }
}
