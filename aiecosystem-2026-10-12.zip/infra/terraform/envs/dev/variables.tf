# Same variables in envs/dev, envs/stage and envs/prod (infra/terraform/scripts/validate.sh checks
# that main.tf, variables.tf, outputs.tf, versions.tf and providers.tf are identical across envs;
# only env.tf and the *.example files differ). Values: terraform.tfvars (from terraform.tfvars.example).

variable "aws_region" {
  type = string
}

variable "aws_account_id" {
  description = "The only account this env may be applied to."
  type        = string
  validation {
    condition     = can(regex("^[0-9]{12}$", var.aws_account_id))
    error_message = "aws_account_id must be a 12-digit AWS account id."
  }
}

variable "vpc_cidr" {
  type = string
}

variable "azs" {
  type = list(string)
}

variable "private_subnet_cidrs" {
  type = list(string)
}

variable "public_subnet_cidrs" {
  type = list(string)
}

variable "firewall_subnet_cidrs" {
  type    = list(string)
  default = []
}

variable "single_nat_gateway" {
  type    = bool
  default = false
}

variable "egress_mode" {
  type    = string
  default = "cidr"
}

variable "portkey_egress_cidrs" {
  type = list(string)
}

variable "fiddler_egress_cidrs" {
  type = list(string)
}

variable "additional_egress_cidrs" {
  type = list(object({
    cidr        = string
    description = string
  }))
  default = []
}

variable "egress_allowed_domains" {
  type    = list(string)
  default = []
}

variable "portkey_base_url" {
  type = string
}

variable "portkey_mcp_url" {
  type    = string
  default = null
}

variable "fiddler_url" {
  type = string
}

variable "agent_ids" {
  type    = list(string)
  default = []
}

variable "create_ecr" {
  type    = bool
  default = true
}

variable "ecr_pull_account_ids" {
  type    = list(string)
  default = []
}

variable "platform_images" {
  description = "Set by .github/workflows/deploy-platform.yml (-var-file images.auto.json). null on the first (bootstrap) apply."
  type = object({
    platform_api     = string
    telemetry_bridge = string
    cache_compress   = string
    web              = string
  })
  default = null
}

variable "certificate_arn" {
  type = string
}

variable "hostnames" {
  type = object({
    web            = string
    api            = string
    bridge         = string
    cache_compress = string
  })
}

variable "alb_internal" {
  type    = bool
  default = true
}

variable "alb_ingress_cidrs" {
  type = list(string)
}

variable "platform_api_config" {
  type = any
}

variable "platform_api_users_yaml" {
  type    = string
  default = null
}

variable "platform_api_environment" {
  type    = map(string)
  default = {}
}

variable "telemetry_bridge_environment" {
  type    = map(string)
  default = {}
}

variable "cache_compress_upstreams" {
  type = map(string)
}

variable "web_config" {
  type = any
}

variable "service_sizing" {
  type = map(object({
    cpu     = number
    memory  = number
    desired = number
    min     = number
    max     = number
  }))
  default = null
}

variable "db_instance_class" {
  type    = string
  default = "db.t4g.medium"
}

variable "db_multi_az" {
  type    = bool
  default = true
}

variable "deletion_protection" {
  type    = bool
  default = true
}

variable "reconcile_dry_run" {
  type    = bool
  default = false
}

variable "invocation_purge_enabled" {
  description = "Daily `aig-platform-api invocations purge` scheduled task (modules/platform-services)."
  type        = bool
  default     = true
}

variable "agent_invocation_retention_days" {
  description = "Invocation metadata retention in days (AIG_AGENT_INVOCATION_RETENTION_DAYS, >= 1)."
  type        = number
  default     = 90
}

variable "agent_output_retention_days" {
  description = "Background invocation output retention in days (AIG_AGENT_OUTPUT_RETENTION_DAYS, >= 1, <= agent_invocation_retention_days)."
  type        = number
  default     = 30
}

variable "workspaces" {
  description = "Phase 6 team workspaces (object documented in modules/environment/variables.tf). null = not deployed in this env."
  type        = any
  default     = null
}

variable "workspace_images" {
  description = "Set by .github/workflows/deploy-platform.yml (images.auto.tfvars.json) together with platform_images."
  type = object({
    workspace    = string
    orchestrator = string
    teams_bot    = string
  })
  default = null
}

variable "alarm_emails" {
  type    = list(string)
  default = []
}

variable "log_retention_days" {
  type    = number
  default = 90
}
