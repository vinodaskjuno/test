output "env" {
  value = local.env
}

output "vpc_id" {
  value = module.env.vpc_id
}

output "egress_prefix_list_id" {
  value = module.env.egress_prefix_list_id
}

output "secret_names" {
  value = module.env.secret_names
}

output "ecr_repository_urls" {
  value = module.env.ecr_repository_urls
}

output "platform" {
  value = module.env.platform
}

output "workspaces" {
  value = module.env.workspaces
}

output "alarm_topic_arn" {
  value = module.env.alarm_topic_arn
}

output "agent_runtime_inputs_parameter" {
  value = module.env.agent_runtime_inputs_parameter
}
