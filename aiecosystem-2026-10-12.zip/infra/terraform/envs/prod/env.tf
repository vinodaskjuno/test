# The only file (besides *.example) that differs between envs/dev, envs/stage and envs/prod.
locals {
  env = "prod"
}
