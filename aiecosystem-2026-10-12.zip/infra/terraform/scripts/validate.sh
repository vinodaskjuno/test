#!/usr/bin/env bash
# Offline validation of every Terraform root module (no AWS account, no credentials, never plan or
# apply):
#   1. terraform fmt -check -recursive infra/terraform
#   2. envs/dev, envs/stage and envs/prod share main.tf, variables.tf, outputs.tf, versions.tf and
#      providers.tf byte for byte (only env.tf and the *.example files differ)
#   3. per root (envs/*, stacks/*): terraform init -backend=false + terraform validate
#   4. terraform test (mock AWS provider, offline plan) for every root/module with tests/*.tftest.hcl
#
#   infra/terraform/scripts/validate.sh            all of the above
#   infra/terraform/scripts/validate.sh --fmt      formatting only
#   TERRAFORM=/path/to/terraform ... to use another binary (default: scripts/tools.sh terraform,
#   the pinned version downloaded into .tools/).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
TF_DIR="$ROOT/infra/terraform"
TERRAFORM="${TERRAFORM:-$("$ROOT/scripts/tools.sh" terraform)}"
export TF_PLUGIN_CACHE_DIR="${TF_PLUGIN_CACHE_DIR:-$ROOT/.tools/plugin-cache}"
export TF_IN_AUTOMATION=1 TF_INPUT=0 CHECKPOINT_DISABLE=1
mkdir -p "$TF_PLUGIN_CACHE_DIR"

echo "terraform: $("$TERRAFORM" version | head -n1)"

echo "==> terraform fmt -check -recursive infra/terraform"
"$TERRAFORM" fmt -check -recursive -diff "$TF_DIR"
[ "${1:-}" = "--fmt" ] && exit 0

echo "==> env roots share their code (only env.tf differs)"
for f in main.tf variables.tf outputs.tf versions.tf providers.tf; do
  for env in stage prod; do
    if ! cmp -s "$TF_DIR/envs/dev/$f" "$TF_DIR/envs/$env/$f"; then
      echo "envs/$env/$f differs from envs/dev/$f (keep env-specific values in env.tf / tfvars)" >&2
      exit 1
    fi
  done
done

status=0
for dir in "$TF_DIR"/envs/* "$TF_DIR"/stacks/* "$TF_DIR"/modules/*; do
  [ -d "$dir" ] || continue
  # Modules are validated through the roots; only the ones with offline tests are run on their own.
  case "$dir" in */modules/*) compgen -G "$dir/tests/*.tftest.hcl" >/dev/null || continue ;; esac
  rel="${dir#"$ROOT"/}"
  echo "==> $rel: init -backend=false + validate"
  if ! (cd "$dir" && "$TERRAFORM" init -backend=false -input=false -no-color >/dev/null &&
        "$TERRAFORM" validate -no-color); then
    status=1; continue
  fi
  if compgen -G "$dir/tests/*.tftest.hcl" >/dev/null; then
    echo "==> $rel: terraform test (mock providers)"
    (cd "$dir" && "$TERRAFORM" test -no-color) || status=1
  fi
done
exit $status
