#!/usr/bin/env python3
"""AIG image build check (docs/IMPLEMENTATION_PLAN.md Phase 5, enforcement table "Image build check").

    image_check.py IMAGE --language python|node [--profile agent|service] [--strict] [--json]

Fails (exit 1) when the image:
  * runs as root, bakes a raw provider key or an AIG/Portkey/Fiddler secret into its config or
    layer history, or ships secrets on its filesystem (gitleaks over the exported filesystem, plus
    .env files and private keys);
  * agent profile: lacks ``aig-sdk`` / ``@aig/sdk`` at the version pinned in infra/ci/image-check/pins.json,
    does not expose the SDK's ``init``, fails the SDK's offline contract checks inside the image
    (a static ``aig doctor``: raw-key guard, AIG_* names and values; network checks are skipped
    because CI has no Portkey/Fiddler), does not declare the required AIG_* names
    (label ``org.aig.env.required``), sets AIG_HOST to something other than agentcore/ecs, is not
    linux/arm64 (AgentCore), or its AgentCore entrypoint self-check fails.
Warnings (errors with --strict, used for prod): base image not pinned by digest, no HEALTHCHECK, no
revision label.

Docker is only used to collect facts (``docker image inspect``, ``docker history``, ``docker run
--rm --network none --entrypoint ...``, ``docker create`` + ``docker export``); every decision is
made by pure functions over those facts, unit-tested in infra/ci/image-check/tests without Docker.
"""

from __future__ import annotations

import argparse
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
DEFAULT_PINS = HERE / "pins.json"
DEFAULT_GITLEAKS_CONFIG = REPO / ".gitleaks.toml"

# backend/contracts/env-vars.md, "Variables that must NOT be set" (tests/test_contract_sync.py keeps it in sync).
RAW_PROVIDER_KEYS = (
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "AZURE_OPENAI_API_KEY",
    "GOOGLE_API_KEY",
    "GEMINI_API_KEY",
    "MISTRAL_API_KEY",
    "COHERE_API_KEY",
    "AWS_BEARER_TOKEN_BEDROCK",
)
# backend/contracts/env-vars.md SDK table, Required == "yes" (kept in sync by the tests).
REQUIRED_SDK_ENV = (
    "AIG_PORTKEY_BASE_URL",
    "AIG_PORTKEY_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "AIG_FIDDLER_URL",
    "AIG_FIDDLER_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "AIG_FIDDLER_PROJECT",
    "AIG_PLATFORM_API_URL",
    "AIG_AGENT_ID",
    "AIG_TEAM",
    "AIG_ENV",
    "AIG_HOST",
)
# Never baked into an image with a value: they come from the runtime's secret store.
SECRET_ENV = (
    "AIG_PORTKEY_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "AIG_FIDDLER_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "AIG_PLATFORM_API_TOKEN",
    "AIG_PORTKEY_ADMIN_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "AIG_PLATFORM_SERVICE_TOKEN",
    "AIG_BRIDGE_PUSH_SECRET",
    "AIG_BRIDGE_INGEST_TOKEN",
    "AIG_BRIDGE_SMTP_PASSWORD",
    "AIG_ALERT_PAGERDUTY_ROUTING_KEY",
    "PORTKEY_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "PORTKEY_ADMIN_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "PORTKEY_WEBHOOK_SECRET",
    "FIDDLER_API_KEY",  # gitleaks:allow (a variable name, not a value)
    "PLATFORM_SERVICE_TOKEN",
    "TELEMETRY_BRIDGE_TOKEN",
    "GITHUB_DISPATCH_TOKEN",
    "AGENT_CALLER_SIGNING_KEY",  # gitleaks:allow (a variable name, not a value)
    "AGENT_OUTPUT_ENCRYPTION_KEY",  # gitleaks:allow (a variable name, not a value)
    "AWS_SECRET_ACCESS_KEY",
    "AWS_SESSION_TOKEN",
)
ALLOWED_HOSTS = ("agentcore", "ecs")
ROOT_USERS = ("", "root", "0")
# Values that are obviously not secrets (placeholders, empty).
PLACEHOLDER_RE = re.compile(r"^$|__REPLACE_ME|^<.*>$|^\$\{?[A-Z_]+\}?$")
KEY_SHAPED_RE = re.compile(
    r"pk-(live|test|admin)-[A-Za-z0-9]{8,}"  # Portkey
    r"|sk-(ant-|proj-)?[A-Za-z0-9_-]{20,}"  # Anthropic / OpenAI
    r"|AKIA[0-9A-Z]{16}"  # AWS access key id
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----"
)
SECRET_ASSIGN_RE = re.compile(r"\b(" + "|".join(SECRET_ENV + RAW_PROVIDER_KEYS) + r")=(\S+)")
DIGEST_RE = re.compile(r"@sha256:[0-9a-f]{64}$")
DEFAULT_SCAN_PATHS = ("app", "opt", "srv", "home", "root", "etc", "usr/local/etc", "workspace", "tmp")
DOTENV_RE = re.compile(r"(^|/)\.env(\.[^/]*)?$")
# .pem/.crt are usually public certificates (/etc/ssl): private keys are found by content instead.
PRIVATE_KEY_FILE_RE = re.compile(r"\.(key|p12|pfx)$")
# Third-party packages are left to ECR scan-on-push / Inspector (their docs and tests carry sample
# keys such as AKIAIOSFODNN7EXAMPLE); the scan covers what the agent's build added.
VENDOR_DIR_RE = re.compile(r"(^|/)(site-packages|dist-packages|node_modules)(/|$)")
# Synthetic, obviously fake values for the in-image static doctor (never real, never reachable).
STATIC_DOCTOR_ENV = {
    "AIG_PORTKEY_BASE_URL": "https://portkey.image-check.invalid/v1",
    "AIG_PORTKEY_API_KEY": "image-check-dummy-key",  # gitleaks:allow (fake value)
    "AIG_FIDDLER_URL": "https://fiddler.image-check.invalid",
    "AIG_FIDDLER_API_KEY": "image-check-dummy-token",  # gitleaks:allow (fake value)
    "AIG_FIDDLER_PROJECT": "aig-dev",
    "AIG_FIDDLER_APPLICATION_ID": "00000000-0000-4000-8000-000000000000",
    "AIG_PLATFORM_API_URL": "https://platform-api.image-check.invalid",
    "AIG_AGENT_ID": "image-check",
    "AIG_TEAM": "image-check",
    "AIG_ENV": "dev",
    "AIG_HOST": "agentcore",
    "AIG_USER_TIER": "standard",
}

PY_SDK_VERSION = "import importlib.metadata as m; print(m.version('aig-sdk'))"
PY_SDK_INIT = "import aig_sdk, sys; sys.exit(0 if callable(getattr(aig_sdk, 'init', None)) else 3)"
PY_STATIC_DOCTOR = (
    "import json, os\n"
    "from aig_sdk.contract import validate\n"
    "try:\n"
    "    validate(os.environ)\n"
    "    print(json.dumps({'ok': True}))\n"
    "except Exception as exc:\n"
    "    print(json.dumps({'ok': False, 'code': getattr(exc, 'code', type(exc).__name__), 'field': getattr(exc, 'field', None)}))\n"
)
NODE_SDK_VERSION = (
    "const p=require('path').join(process.env.AIG_APP_DIR||'/app','node_modules','@aig','sdk','package.json');"
    "process.stdout.write(require(p).version)"
)
NODE_SDK_INIT = "import('@aig/sdk').then(m=>process.exit(typeof m.init==='function'?0:3),()=>process.exit(4))"
NODE_STATIC_DOCTOR = (
    "import('@aig/sdk').then(m=>{try{m.validate(process.env);console.log(JSON.stringify({ok:true}))}"
    "catch(e){console.log(JSON.stringify({ok:false,code:e.code||e.name,field:e.field??null}))}})"
)


# ---------------------------------------------------------------------------------------------
# Facts (collected with Docker) and findings (pure evaluation)
# ---------------------------------------------------------------------------------------------
@dataclass
class Finding:
    check: str
    level: str  # "ok" | "warn" | "error"
    message: str


@dataclass
class Facts:
    image: str
    language: str
    profile: str
    config: dict[str, Any] = field(default_factory=dict)  # docker inspect .Config
    architecture: str | None = None
    history: list[str] = field(default_factory=list)
    sdk_version: str | None = None
    sdk_init_ok: bool | None = None
    static_doctor: dict[str, Any] | None = None
    self_check: dict[str, Any] | None = None  # None = entrypoint is not the AIG AgentCore shim
    fs_dotenv_files: list[str] = field(default_factory=list)
    fs_private_keys: list[str] = field(default_factory=list)
    fs_key_shaped: list[str] = field(default_factory=list)
    gitleaks_findings: int | None = None  # None = gitleaks not run
    notes: list[str] = field(default_factory=list)


def env_map(config: dict[str, Any]) -> dict[str, str]:
    out = {}
    for item in config.get("Env") or []:
        name, _, value = item.partition("=")
        out[name] = value
    return out


def is_root_user(user: str | None) -> bool:
    user = (user or "").strip()
    name = user.split(":", 1)[0]
    return name in ROOT_USERS


def is_placeholder(value: str) -> bool:
    return bool(PLACEHOLDER_RE.search(value.strip()))


def load_pins(path: Path = DEFAULT_PINS) -> dict[str, Any]:
    return json.loads(Path(path).read_text())


def pinned_sdk_version(pins: dict[str, Any], language: str) -> str:
    return pins["sdk"]["aig-sdk" if language == "python" else "@aig/sdk"]


def evaluate(facts: Facts, pins: dict[str, Any], *, strict: bool = False) -> list[Finding]:
    out: list[Finding] = []
    add = lambda check, ok, msg, level="error": out.append(Finding(check, "ok" if ok else level, msg))  # noqa: E731
    warn_level = "error" if strict else "warn"
    config = facts.config or {}
    env = env_map(config)
    labels = config.get("Labels") or {}

    # --- every image -----------------------------------------------------------------------
    user = config.get("User") or ""
    add("non-root", not is_root_user(user), f"runs as user {user!r}" if user else "no USER: runs as root")

    raw = [k for k in RAW_PROVIDER_KEYS if k in env]
    add("no-provider-keys", not raw,
        "no raw provider key variables" if not raw else f"raw provider key variable(s) in the image config: {', '.join(raw)} "
        "(provider keys live only in Portkey virtual keys)")

    baked = sorted(k for k in SECRET_ENV if k in env and not is_placeholder(env[k]))
    shaped = sorted(k for k, v in env.items() if KEY_SHAPED_RE.search(v))
    add("no-secrets-in-env", not baked and not shaped,
        "no secret values in the image config" if not (baked or shaped) else
        f"secret value(s) baked into ENV: {', '.join(sorted(set(baked + shaped)))} (inject at runtime from Secrets Manager)")

    leaked = []
    for line in facts.history:
        if KEY_SHAPED_RE.search(line):
            leaked.append("key-shaped string")
        for name, value in SECRET_ASSIGN_RE.findall(line):
            if not is_placeholder(value.strip("'\"")):
                leaked.append(name)
    add("no-secrets-in-history", not leaked,
        "layer history is clean" if not leaked else f"secret(s) in the layer history: {', '.join(sorted(set(leaked)))} "
        "(use BuildKit --secret, never ARG/ENV)")

    if facts.gitleaks_findings is None:
        add("fs-gitleaks", False, "gitleaks did not run over the image filesystem", level=warn_level)
    else:
        add("fs-gitleaks", facts.gitleaks_findings == 0,
            "gitleaks: no leaks in the image filesystem" if facts.gitleaks_findings == 0
            else f"gitleaks: {facts.gitleaks_findings} leak(s) in the image filesystem")
    add("fs-no-dotenv", not facts.fs_dotenv_files,
        "no .env files" if not facts.fs_dotenv_files else f".env file(s) baked in: {', '.join(facts.fs_dotenv_files[:10])}")
    add("fs-no-private-keys", not facts.fs_private_keys,
        "no private key files" if not facts.fs_private_keys else f"private key file(s): {', '.join(facts.fs_private_keys[:10])}")
    add("fs-no-key-shaped", not facts.fs_key_shaped,
        "no key-shaped strings in app files" if not facts.fs_key_shaped else f"key-shaped string(s) in: {', '.join(facts.fs_key_shaped[:10])}")

    add("healthcheck", bool(config.get("Healthcheck")), "HEALTHCHECK declared" if config.get("Healthcheck") else "no HEALTHCHECK", level=warn_level)
    base = labels.get("org.opencontainers.image.base.name", "")
    add("base-digest", bool(DIGEST_RE.search(base)),
        f"base image pinned by digest ({base})" if DIGEST_RE.search(base) else
        f"base image not pinned by digest (label org.opencontainers.image.base.name={base or 'missing'}; pins.json base_images)",
        level=warn_level)
    rev = labels.get("org.opencontainers.image.revision", "")
    add("revision-label", bool(rev) and rev != "unknown", f"revision {rev}" if rev and rev != "unknown" else "no org.opencontainers.image.revision label", level=warn_level)

    if facts.profile != "agent":
        return out

    # --- agent images ------------------------------------------------------------------------
    pinned = pinned_sdk_version(pins, facts.language)
    sdk_name = "aig-sdk" if facts.language == "python" else "@aig/sdk"
    if facts.sdk_version is None:
        add("sdk-pinned", False, f"{sdk_name} is not installed in the image")
    else:
        add("sdk-pinned", facts.sdk_version == pinned, f"{sdk_name} {facts.sdk_version} (pinned {pinned})")
    add("sdk-init", bool(facts.sdk_init_ok), f"{sdk_name} imports and exposes init()" if facts.sdk_init_ok else f"{sdk_name} import or init symbol missing")

    declared = {n.strip() for n in labels.get("org.aig.env.required", "").split(",") if n.strip()}
    missing = [n for n in REQUIRED_SDK_ENV if n not in declared]
    add("env-contract", not missing,
        "label org.aig.env.required lists every required AIG_* variable" if not missing else
        f"label org.aig.env.required is missing: {', '.join(missing)}")
    host = env.get("AIG_HOST")
    add("aig-host", host in ALLOWED_HOSTS, f"AIG_HOST={host}" if host else "AIG_HOST is not set in the image config",)

    sd = facts.static_doctor
    if sd is None:
        add("static-doctor", False, "static aig doctor did not run")
    else:
        add("static-doctor", bool(sd.get("ok")),
            "static aig doctor: contract checks pass inside the image" if sd.get("ok") else
            f"static aig doctor failed inside the image: {sd.get('code')}" + (f" ({sd.get('field')})" if sd.get("field") else ""))

    if facts.self_check is None:
        add("entrypoint-self-check", False, "entrypoint is not the AIG AgentCore shim (infra/ci/docker)", level=warn_level)
    else:
        add("entrypoint-self-check", bool(facts.self_check.get("ok")),
            f"AgentCore entrypoint resolves {facts.self_check.get('entrypoint')}" if facts.self_check.get("ok")
            else f"AgentCore entrypoint self-check failed: {facts.self_check.get('error') or facts.self_check}")

    add("arch-arm64", facts.architecture == "arm64", f"architecture {facts.architecture} (AgentCore needs arm64)")
    return out


def failed(findings: Iterable[Finding]) -> bool:
    return any(f.level == "error" for f in findings)


# ---------------------------------------------------------------------------------------------
# Filesystem scan (pure: works on an extracted directory)
# ---------------------------------------------------------------------------------------------
def scan_tree(root: Path, *, max_bytes: int = 2_000_000) -> tuple[list[str], list[str], list[str]]:
    """Return (.env files, private key files, files with key-shaped strings) under ``root``."""
    dotenv, keys, shaped = [], [], []
    for path in sorted(p for p in root.rglob("*") if p.is_file() and not p.is_symlink()):
        rel = path.relative_to(root).as_posix()
        if DOTENV_RE.search(rel) and not rel.endswith(".example"):
            dotenv.append(rel)
        if PRIVATE_KEY_FILE_RE.search(rel):
            keys.append(rel)
        try:
            if path.stat().st_size > max_bytes:
                continue
            text = path.read_bytes().decode("utf-8", errors="ignore")
        except OSError:
            continue
        if any("EXAMPLE" not in m.group(0) for m in KEY_SHAPED_RE.finditer(text)):
            shaped.append(rel)
    return dotenv, keys, shaped


def extract_paths(tar_stream: io.BufferedIOBase, dest: Path, prefixes: Sequence[str]) -> int:
    """Extract regular files under ``prefixes`` from a ``docker export`` tar stream (no links, no devices)."""
    count = 0
    prefixes = tuple(p.strip("/") + "/" for p in prefixes)
    with tarfile.open(fileobj=tar_stream, mode="r|*") as tar:
        for member in tar:
            name = member.name.lstrip("./")
            if not member.isfile() or not name.startswith(prefixes) or ".." in Path(name).parts:
                continue
            if VENDOR_DIR_RE.search(name):
                continue
            target = dest / name
            target.parent.mkdir(parents=True, exist_ok=True)
            src = tar.extractfile(member)
            if src is None:
                continue
            with open(target, "wb") as fh:
                shutil.copyfileobj(src, fh)
            count += 1
    return count


def gitleaks_command(gitleaks: str, source: Path, report: Path, config: Path | None) -> list[str]:
    cmd = [gitleaks, "detect", "--no-git", "--source", str(source), "--report-format", "json",
           "--report-path", str(report), "--redact", "--no-banner", "--exit-code", "0"]
    if config and Path(config).is_file():
        cmd += ["--config", str(config)]
    return cmd


def count_gitleaks_report(report: Path) -> int:
    if not report.is_file() or not report.read_text().strip():
        return 0
    data = json.loads(report.read_text())
    return len(data) if isinstance(data, list) else 0


# ---------------------------------------------------------------------------------------------
# Collection (Docker)
# ---------------------------------------------------------------------------------------------
class Runner:
    """Thin subprocess wrapper so tests can replace Docker."""

    def run(self, args: Sequence[str], *, env: dict[str, str] | None = None) -> subprocess.CompletedProcess:
        return subprocess.run(list(args), capture_output=True, text=True, env=env)

    def stream(self, args: Sequence[str]) -> tuple[io.BufferedIOBase, Callable[[], int]]:
        proc = subprocess.Popen(list(args), stdout=subprocess.PIPE)
        assert proc.stdout is not None
        return proc.stdout, proc.wait


def interpreter(config: dict[str, Any], language: str) -> str:
    """The python/node binary of the image (from its ENTRYPOINT when it names one)."""
    want = "python" if language == "python" else "node"
    for part in (config.get("Entrypoint") or []) + (config.get("Cmd") or []):
        base = os.path.basename(part)
        if base.startswith(want) and "/" in part:
            return part
    return want


def docker_run(runner: Runner, image: str, entrypoint: str, args: Sequence[str], env: dict[str, str] | None = None,
               workdir: str | None = None) -> subprocess.CompletedProcess:
    cmd = ["docker", "run", "--rm", "--network", "none", "--read-only", "--tmpfs", "/tmp", "--entrypoint", entrypoint]
    if workdir:
        cmd += ["-w", workdir]
    for k, v in (env or {}).items():
        cmd += ["-e", f"{k}={v}"]
    return runner.run(cmd + [image, *args])


def parse_json_line(text: str) -> dict[str, Any] | None:
    for line in reversed((text or "").strip().splitlines()):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return None


def collect(image: str, language: str, profile: str, *, runner: Runner | None = None, gitleaks: str | None = "gitleaks",
            gitleaks_config: Path | None = DEFAULT_GITLEAKS_CONFIG, scan_paths: Sequence[str] = DEFAULT_SCAN_PATHS) -> Facts:
    runner = runner or Runner()
    facts = Facts(image=image, language=language, profile=profile)
    res = runner.run(["docker", "image", "inspect", image])
    if res.returncode != 0:
        raise SystemExit(f"docker image inspect {image} failed: {res.stderr.strip()}")
    info = json.loads(res.stdout)[0]
    facts.config = info.get("Config") or {}
    facts.architecture = info.get("Architecture")
    res = runner.run(["docker", "history", "--no-trunc", "--format", "{{.CreatedBy}}", image])
    facts.history = res.stdout.splitlines() if res.returncode == 0 else []

    if profile == "agent":
        interp = interpreter(facts.config, language)
        app_dir = env_map(facts.config).get("AIG_APP_DIR", "/app")
        if language == "python":
            r = docker_run(runner, image, interp, ["-c", PY_SDK_VERSION])
            facts.sdk_version = r.stdout.strip() or None if r.returncode == 0 else None
            facts.sdk_init_ok = docker_run(runner, image, interp, ["-c", PY_SDK_INIT]).returncode == 0
            static_cmd = ["-c", PY_STATIC_DOCTOR]
            workdir = None
        else:
            r = docker_run(runner, image, interp, ["-e", NODE_SDK_VERSION])
            facts.sdk_version = r.stdout.strip() or None if r.returncode == 0 else None
            facts.sdk_init_ok = docker_run(runner, image, interp, ["-e", NODE_SDK_INIT], workdir=app_dir).returncode == 0
            static_cmd = ["-e", NODE_STATIC_DOCTOR]
            workdir = app_dir
        image_env = env_map(facts.config)
        synthetic = {k: v for k, v in STATIC_DOCTOR_ENV.items() if k not in image_env}
        r = docker_run(runner, image, interp, static_cmd, env=synthetic, workdir=workdir)
        facts.static_doctor = parse_json_line(r.stdout) or {"ok": False, "code": f"exit {r.returncode}: {r.stderr.strip()[-200:]}"}
        entry = " ".join(facts.config.get("Entrypoint") or [])
        if "agentcore" in entry:
            ep = facts.config["Entrypoint"]
            r = docker_run(runner, image, ep[0], [*ep[1:], "--self-check"])
            facts.self_check = parse_json_line(r.stdout) or {"ok": False, "error": r.stderr.strip()[-200:]}

    with tempfile.TemporaryDirectory(prefix="aig-image-check-") as tmp:
        root = Path(tmp) / "fs"
        root.mkdir()
        res = runner.run(["docker", "create", image])
        if res.returncode != 0:
            raise SystemExit(f"docker create {image} failed: {res.stderr.strip()}")
        cid = res.stdout.strip()
        try:
            stream, wait = runner.stream(["docker", "export", cid])
            n = extract_paths(stream, root, scan_paths)
            wait()
            facts.notes.append(f"scanned {n} files under /{', /'.join(scan_paths)}")
        finally:
            runner.run(["docker", "rm", "-f", cid])
        facts.fs_dotenv_files, facts.fs_private_keys, facts.fs_key_shaped = scan_tree(root)
        if gitleaks and shutil.which(gitleaks):
            report = Path(tmp) / "gitleaks.json"
            r = runner.run(gitleaks_command(gitleaks, root, report, gitleaks_config))
            facts.gitleaks_findings = count_gitleaks_report(report) if r.returncode == 0 else None
            if r.returncode != 0:
                facts.notes.append(f"gitleaks failed: {r.stderr.strip()[-200:]}")
    return facts


# ---------------------------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------------------------
def render(findings: list[Finding], facts: Facts) -> str:
    width = max(len(f.check) for f in findings)
    lines = [f"image-check {facts.image} ({facts.language}, {facts.profile})", f"{'CHECK':<{width}}  STATUS  DETAIL"]
    for f in findings:
        lines.append(f"{f.check:<{width}}  {f.level.upper():<6}  {f.message}")
    lines += [f"note: {n}" for n in facts.notes]
    lines.append("image-check: " + ("FAILED" if failed(findings) else "passed"))
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="image-check", description=__doc__.split("\n\n")[0])
    p.add_argument("image", help="image reference (tag or digest), already built or pulled")
    p.add_argument("--language", required=True, choices=["python", "node"])
    p.add_argument("--profile", default="agent", choices=["agent", "service"],
                   help="agent: SDK, contract and AgentCore checks; service: platform service images (non-root, no secrets)")
    p.add_argument("--pins", type=Path, default=DEFAULT_PINS)
    p.add_argument("--strict", action="store_true", help="warnings fail too (prod)")
    p.add_argument("--json", action="store_true", help="machine-readable report on stdout")
    p.add_argument("--gitleaks", default="gitleaks", help="gitleaks binary ('' to skip: reported as a warning)")
    p.add_argument("--gitleaks-config", type=Path, default=DEFAULT_GITLEAKS_CONFIG)
    p.add_argument("--scan-path", action="append", help=f"filesystem prefix to scan (default: {', '.join(DEFAULT_SCAN_PATHS)})")
    p.add_argument("--facts", type=Path, help="evaluate saved facts JSON instead of running Docker")
    p.add_argument("--save-facts", type=Path, help="write the collected facts JSON here")
    return p


def main(argv: Sequence[str] | None = None, *, runner: Runner | None = None) -> int:
    args = build_parser().parse_args(argv)
    pins = load_pins(args.pins)
    if args.facts:
        facts = Facts(**json.loads(args.facts.read_text()))
    else:
        facts = collect(args.image, args.language, args.profile, runner=runner, gitleaks=args.gitleaks or None,
                        gitleaks_config=args.gitleaks_config, scan_paths=tuple(args.scan_path or DEFAULT_SCAN_PATHS))
    if args.save_facts:
        args.save_facts.write_text(json.dumps(asdict(facts), indent=2))
    findings = evaluate(facts, pins, strict=args.strict)
    if args.json:
        print(json.dumps({"ok": not failed(findings), "image": facts.image, "findings": [asdict(f) for f in findings],
                          "notes": facts.notes}, indent=2))
    else:
        print(render(findings, facts))
    return 1 if failed(findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
