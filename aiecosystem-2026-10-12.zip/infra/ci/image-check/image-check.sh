#!/usr/bin/env bash
# AIG image build check. Fails the build when an image lacks the pinned aig-sdk / @aig/sdk, fails
# the in-image static doctor, runs as root or carries secrets. Details: infra/ci/image-check/README.md.
#   infra/ci/image-check/image-check.sh IMAGE python|node [--profile agent|service] [--strict] [--json] ...
# Needs docker (and gitleaks on PATH for the filesystem secret scan); stdlib Python 3.10+ only.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
if [ $# -lt 2 ]; then
  echo "usage: $0 IMAGE python|node [image_check.py options]" >&2
  exit 2
fi
image="$1" language="$2"; shift 2
command -v docker >/dev/null || { echo "image-check: docker is required" >&2; exit 2; }
exec "${PYTHON:-python3}" "$here/image_check.py" "$image" --language "$language" "$@"
