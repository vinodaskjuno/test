import json
from pathlib import Path

import image_check as ic

FIX = Path(__file__).parent / "fixtures"


def test_cli_passes_good_facts(capsys):
    assert ic.main(["img", "--language", "python", "--facts", str(FIX / "agent-python-good.json")]) == 0
    assert "image-check: passed" in capsys.readouterr().out


def test_cli_fails_bad_facts_json(capsys):
    assert ic.main(["img", "--language", "python", "--facts", str(FIX / "agent-python-bad.json"), "--json"]) == 1
    report = json.loads(capsys.readouterr().out)
    assert report["ok"] is False
    assert {"check": "sdk-pinned", "level": "error"}.items() <= next(f for f in report["findings"] if f["check"] == "sdk-pinned").items()


def test_cli_strict(capsys):
    assert ic.main(["img", "--language", "python", "--profile", "service", "--facts", str(FIX / "service-good.json")]) == 0
    assert ic.main(["img", "--language", "python", "--profile", "service", "--strict", "--facts", str(FIX / "service-good.json")]) == 1


def test_wrapper_script_is_executable():
    script = Path(ic.__file__).with_name("image-check.sh")
    assert script.stat().st_mode & 0o111
    assert "image_check.py" in script.read_text()
