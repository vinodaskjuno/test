"""Fact collection with a fake Docker runner (Docker is not needed for the tests)."""

import io
import json
import subprocess
import tarfile

import image_check as ic
from conftest import FAKE_PORTKEY_KEY


def make_tar(files: dict[str, bytes], links: dict[str, str] | None = None) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tar:
        for name, data in files.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        for name, target in (links or {}).items():
            info = tarfile.TarInfo(name)
            info.type = tarfile.SYMTYPE
            info.linkname = target
            tar.addfile(info)
    return buf.getvalue()


class FakeRunner(ic.Runner):
    def __init__(self, inspect: dict, tar: bytes, outputs: dict[str, tuple[int, str]]):
        self.inspect, self.tar, self.outputs, self.calls = inspect, tar, outputs, []

    def run(self, args, *, env=None):
        args = list(args)
        self.calls.append(args)
        ok = lambda out="": subprocess.CompletedProcess(args, 0, out, "")  # noqa: E731
        if args[:3] == ["docker", "image", "inspect"]:
            return ok(json.dumps([self.inspect]))
        if args[:2] == ["docker", "history"]:
            return ok("ENV AIG_HOST=agentcore\nCOPY /opt/venv /opt/venv")
        if args[:2] == ["docker", "create"]:
            return ok("cid123\n")
        if args[:2] == ["docker", "rm"]:
            return ok()
        if args[:2] == ["docker", "run"]:
            script = args[-1]
            for marker, (code, out) in self.outputs.items():
                if marker in script or marker in args:
                    return subprocess.CompletedProcess(args, code, out, "")
            return subprocess.CompletedProcess(args, 1, "", "unexpected")
        raise AssertionError(f"unexpected command {args}")

    def stream(self, args):
        self.calls.append(list(args))
        return io.BytesIO(self.tar), lambda: 0


INSPECT = {
    "Architecture": "arm64",
    "Config": {
        "User": "65532:65532",
        "Env": ["PATH=/opt/venv/bin:/usr/bin", "AIG_HOST=agentcore", "AIG_PORTKEY_CONFIG=pc-aig-router"],
        "Entrypoint": ["/opt/venv/bin/python", "/opt/aig/agentcore_shim.py"],
        "Labels": {},
    },
}


def test_collect_python_agent(tmp_path):
    tar = make_tar({
        "app/main.py": b"print('hi')\n",
        "app/.env": b"X=1\n",
        "app/config/settings.py": f"KEY = '{FAKE_PORTKEY_KEY}'\n".encode(),
        "opt/venv/lib/python3.11/site-packages/botocore/docs.py": b"AKIAIOSFODNN7EXAMPLE\n",
        "etc/ssl/certs/ca.pem": b"-----BEGIN CERTIFICATE-----\nMIIB\n",
        "usr/lib/python3.11/os.py": b"# not scanned (not under a scan prefix)\n",
    }, links={"app/link": "/etc/shadow"})
    runner = FakeRunner(INSPECT, tar, {
        "m.version('aig-sdk')": (0, "0.1.0\n"),
        "callable(getattr(aig_sdk, 'init'": (0, ""),
        "from aig_sdk.contract import validate": (0, '{"ok": true}\n'),
        "--self-check": (0, 'INFO noise\n{"ok": true, "entrypoint": "pkg.agent:run"}\n'),
    })
    facts = ic.collect("img:1", "python", "agent", runner=runner, gitleaks=None)
    assert facts.sdk_version == "0.1.0" and facts.sdk_init_ok is True
    assert facts.static_doctor == {"ok": True}
    assert facts.self_check["ok"] is True
    assert facts.fs_dotenv_files == ["app/.env"]
    assert facts.fs_key_shaped == ["app/config/settings.py"]  # vendor dir skipped, EXAMPLE ignored
    assert facts.fs_private_keys == []  # certificates are not private keys
    assert facts.gitleaks_findings is None
    # Every in-image command runs offline with a read-only root filesystem.
    runs = [c for c in runner.calls if c[:2] == ["docker", "run"]]
    assert runs and all("--network" in c and "none" in c and "--read-only" in c for c in runs)
    # The static doctor gets synthetic values only for variables the image does not set itself.
    doctor = next(c for c in runs if "from aig_sdk.contract import validate" in c[-1])
    assert "AIG_HOST=agentcore" not in doctor and "AIG_AGENT_ID=image-check" in doctor
    assert ["docker", "rm", "-f", "cid123"] in runner.calls


def test_collect_reports_missing_sdk_and_failed_doctor():
    runner = FakeRunner(INSPECT, make_tar({"app/x.py": b"x"}), {
        "m.version('aig-sdk')": (1, ""),
        "callable(getattr(aig_sdk, 'init'": (1, ""),
        "from aig_sdk.contract import validate": (1, ""),
        "--self-check": (1, '{"ok": false, "error": "ModuleNotFoundError"}'),
    })
    facts = ic.collect("img:1", "python", "agent", runner=runner, gitleaks=None)
    assert facts.sdk_version is None and facts.sdk_init_ok is False
    assert facts.static_doctor["ok"] is False and facts.self_check["ok"] is False


def test_collect_node_agent_uses_entrypoint_node_and_app_dir():
    inspect = {"Architecture": "arm64", "Config": {
        "User": "65532:65532", "Env": ["AIG_APP_DIR=/app", "AIG_HOST=agentcore"],
        "Entrypoint": ["/nodejs/bin/node", "/app/.aig/agentcore-shim.mjs"], "Labels": {}}}
    runner = FakeRunner(inspect, make_tar({}), {
        "node_modules','@aig','sdk','package.json'": (0, "0.1.0"),
        "typeof m.init==='function'": (0, ""),
        "m.validate(process.env)": (0, '{"ok":true}'),
        "--self-check": (0, '{"ok":true,"entrypoint":"dist/agent.js#run"}'),
    })
    facts = ic.collect("img:1", "node", "agent", runner=runner, gitleaks=None)
    assert facts.sdk_version == "0.1.0" and facts.static_doctor == {"ok": True}
    runs = [c for c in runner.calls if c[:2] == ["docker", "run"]]
    assert all(c[c.index("--entrypoint") + 1] == "/nodejs/bin/node" for c in runs)
    assert any("-w" in c and c[c.index("-w") + 1] == "/app" for c in runs)


def test_service_profile_runs_no_sdk_commands():
    runner = FakeRunner({"Architecture": "arm64", "Config": {"User": "aig", "Env": []}}, make_tar({}), {})
    facts = ic.collect("img:1", "python", "service", runner=runner, gitleaks=None)
    assert facts.sdk_version is None and facts.static_doctor is None
    assert not [c for c in runner.calls if c[:2] == ["docker", "run"]]


def test_extract_skips_traversal_and_links(tmp_path):
    tar = make_tar({"app/ok.txt": b"1", "app/../../evil.txt": b"2"}, links={"app/l": "/etc/passwd"})
    n = ic.extract_paths(io.BytesIO(tar), tmp_path, ["app"])
    assert n == 1 and (tmp_path / "app/ok.txt").exists()
    assert not (tmp_path.parent / "evil.txt").exists()


def test_gitleaks_command_and_report(tmp_path):
    cfg = tmp_path / "gl.toml"
    cfg.write_text("")
    cmd = ic.gitleaks_command("gitleaks", tmp_path / "fs", tmp_path / "r.json", cfg)
    assert cmd[:3] == ["gitleaks", "detect", "--no-git"] and "--redact" in cmd and str(cfg) in cmd
    assert ic.count_gitleaks_report(tmp_path / "missing.json") == 0
    (tmp_path / "r.json").write_text(json.dumps([{"RuleID": "x"}, {"RuleID": "y"}]))
    assert ic.count_gitleaks_report(tmp_path / "r.json") == 2


def test_scan_tree_env_example_is_allowed(tmp_path):
    (tmp_path / "app").mkdir()
    (tmp_path / "app/.env.example").write_text("AIG_PORTKEY_API_KEY=__REPLACE_ME__\n")
    (tmp_path / "app/.env.prod").write_text("X=1\n")
    (tmp_path / "app/tls.key").write_text("x")
    dotenv, keys, shaped = ic.scan_tree(tmp_path)
    assert dotenv == ["app/.env.prod"] and keys == ["app/tls.key"] and shaped == []


def test_interpreter_from_entrypoint():
    assert ic.interpreter({"Entrypoint": ["/opt/venv/bin/python", "/opt/aig/agentcore_shim.py"]}, "python") == "/opt/venv/bin/python"
    assert ic.interpreter({"Entrypoint": ["/nodejs/bin/node", "x.mjs"]}, "node") == "/nodejs/bin/node"
    assert ic.interpreter({"Cmd": ["sh", "-c", "uvicorn"]}, "python") == "python"
