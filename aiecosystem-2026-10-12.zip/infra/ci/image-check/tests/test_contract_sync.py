"""image_check's lists, the Dockerfile labels and the AgentCore Terraform module follow backend/contracts/env-vars.md."""

import re

import image_check as ic
from conftest import REPO

CONTRACT = (REPO / "backend/contracts/env-vars.md").read_text()


def sdk_table_rows():
    section = CONTRACT.split("## SDKs", 1)[1].split("\n## ", 1)[0]
    for line in section.splitlines():
        m = re.match(r"^\| `(AIG_[A-Z_]+)` \| ([^|]+) \|", line)
        if m:
            yield m.group(1), m.group(2).strip()


def test_raw_provider_keys_match_contract():
    block = CONTRACT.split("### Variables that must NOT be set", 1)[1].split("###", 1)[0]
    names = re.findall(r"`([A-Z_]+)`", block.split("Any non-empty value", 1)[0])
    assert tuple(names) == ic.RAW_PROVIDER_KEYS


def test_required_sdk_env_matches_contract():
    required = tuple(name for name, req in sdk_table_rows() if req == "yes")
    assert required == ic.REQUIRED_SDK_ENV


def test_dockerfile_labels_declare_required_env():
    for lang in ("python", "node"):
        text = (REPO / f"infra/ci/docker/agent-{lang}.Dockerfile").read_text()
        label = re.search(r'org\.aig\.env\.required="([^"]+)"', text).group(1)
        # Same names; the order is free (it is chosen to keep the repo's gitleaks rules quiet).
        assert sorted(label.split(",")) == sorted(ic.REQUIRED_SDK_ENV), lang
        assert "AIG_HOST=agentcore" in text, lang


def test_platform_api_secret_names_are_known_secrets():
    example = (REPO / "backend/platform-api/secrets/dev.env.example").read_text()
    names = re.findall(r"^([A-Z_]+)=", example, flags=re.M)
    assert names and set(names) <= set(ic.SECRET_ENV)


def test_agentcore_module_wires_every_required_variable():
    """Non-secret required names are runtime env vars; secret ones come from the agent secret."""
    main = (REPO / "infra/terraform/modules/agentcore-runtime/main.tf").read_text()
    env_block = main.split("aig_environment = {", 1)[1].split("runtime_environment", 1)[0]
    wired = set(re.findall(r"^\s+(AIG_[A-Z_]+)\s+=", env_block, flags=re.M))
    secret_keys = set(re.search(r"secret_keys\s+=\s+\[([^\]]+)\]", main).group(1).replace('"', "").replace(" ", "").split(","))
    secret_required = {n for n in ic.REQUIRED_SDK_ENV if n.endswith(("_API_KEY", "_TOKEN"))}
    assert secret_required == {"AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY"}
    assert secret_required <= secret_keys
    assert set(ic.REQUIRED_SDK_ENV) - secret_required <= wired
    assert not (wired & secret_keys), "secrets must never be runtime environment variables"


def test_shims_load_exactly_the_agent_secret_keys():
    import agentcore_shim

    main = (REPO / "infra/terraform/modules/agentcore-runtime/main.tf").read_text()
    secret_keys = re.search(r"secret_keys\s+=\s+\[([^\]]+)\]", main).group(1).replace('"', "").replace(" ", "").split(",")
    assert list(agentcore_shim.SECRET_KEYS) == secret_keys
    node = (REPO / "infra/ci/docker/agentcore-shim.mjs").read_text()
    assert re.search(r"const SECRET_KEYS = \[([^\]]+)\]", node).group(1).replace('"', "").replace(" ", "").split(",") == secret_keys
