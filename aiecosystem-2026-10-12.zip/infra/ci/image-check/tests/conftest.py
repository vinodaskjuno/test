import json
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
CI = HERE.parent
REPO = CI.parents[2]
sys.path.insert(0, str(CI))
sys.path.insert(0, str(REPO / "infra" / "ci" / "docker"))

# Key-shaped test values are assembled at runtime so the repo's own gitleaks scan stays clean.
FAKE_PORTKEY_KEY = "pk-" + "live-" + "Zq7Xw2Lm9Rt4Yp6V"
FAKE_OPENAI_KEY = "sk-" + "proj-" + "Zq7Xw2Lm9Rt4Yp6VbN3cK8sD1fG5hJ0a"


@pytest.fixture
def load_fixture():
    def _load(name: str) -> dict:
        return json.loads((HERE / "fixtures" / name).read_text())

    return _load


@pytest.fixture
def pins():
    return json.loads((CI / "pins.json").read_text())
