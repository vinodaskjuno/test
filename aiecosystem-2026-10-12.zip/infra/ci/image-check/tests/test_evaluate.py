"""Pure evaluation of collected image facts (no Docker)."""

import image_check as ic
from conftest import FAKE_OPENAI_KEY, FAKE_PORTKEY_KEY


def by_check(findings):
    return {f.check: f for f in findings}


def facts(data):
    return ic.Facts(**data)


def test_good_python_agent_passes(load_fixture, pins):
    findings = ic.evaluate(facts(load_fixture("agent-python-good.json")), pins)
    assert not ic.failed(findings), [f for f in findings if f.level != "ok"]
    assert all(f.level == "ok" for f in findings)


def test_good_node_agent_passes(load_fixture, pins):
    findings = ic.evaluate(facts(load_fixture("agent-node-good.json")), pins)
    assert not ic.failed(findings)
    assert by_check(findings)["sdk-pinned"].message.startswith("@aig/sdk 0.1.0")


def test_service_profile_skips_agent_checks(load_fixture, pins):
    findings = by_check(ic.evaluate(facts(load_fixture("service-good.json")), pins))
    assert "sdk-pinned" not in findings and "static-doctor" not in findings
    assert findings["non-root"].level == "ok"
    assert findings["base-digest"].level == "warn"  # python:3.12-slim by tag
    assert not ic.failed(findings.values())


def test_bad_agent_fails_every_check(load_fixture, pins):
    data = load_fixture("agent-python-bad.json")
    data["config"]["Env"] = [e.replace("__KEY_INJECTED_BY_TEST__", FAKE_PORTKEY_KEY) for e in data["config"]["Env"]]
    data["history"].append(f"ARG PORTKEY_API_KEY={FAKE_PORTKEY_KEY}")
    findings = by_check(ic.evaluate(facts(data), pins))
    for check in ("non-root", "no-provider-keys", "no-secrets-in-env", "no-secrets-in-history", "fs-gitleaks",
                  "fs-no-dotenv", "fs-no-private-keys", "fs-no-key-shaped", "sdk-pinned", "sdk-init",
                  "env-contract", "static-doctor", "entrypoint-self-check", "arch-arm64"):
        assert findings[check].level == "error", check
    assert "AIG_E_RAW_PROVIDER_KEY" in findings["static-doctor"].message
    assert "AIG_PORTKEY_BASE_URL" not in findings["env-contract"].message  # declared
    assert "AIG_FIDDLER_URL" in findings["env-contract"].message  # missing
    # Warnings stay warnings unless --strict.
    assert findings["healthcheck"].level == "warn" and findings["base-digest"].level == "warn"


def test_strict_turns_warnings_into_errors(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["config"]["Labels"]["org.opencontainers.image.base.name"] = "gcr.io/distroless/python3-debian12:nonroot"
    assert not ic.failed(ic.evaluate(facts(data), pins))
    strict = by_check(ic.evaluate(facts(data), pins, strict=True))
    assert strict["base-digest"].level == "error"


def test_sdk_not_installed(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["sdk_version"] = None
    f = by_check(ic.evaluate(facts(data), pins))["sdk-pinned"]
    assert f.level == "error" and "not installed" in f.message


def test_sdk_version_must_equal_pin(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["sdk_version"] = "0.1.1"
    assert by_check(ic.evaluate(facts(data), pins))["sdk-pinned"].level == "error"


def test_root_users_are_refused():
    for user in ("", "root", "0", "0:0", "root:root", "0:1000"):
        assert ic.is_root_user(user), user
    for user in ("65532:65532", "aig", "10001", "nobody", "101"):
        assert not ic.is_root_user(user), user


def test_empty_provider_key_variable_still_fails(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["config"]["Env"].append("ANTHROPIC_API_KEY=")
    assert by_check(ic.evaluate(facts(data), pins))["no-provider-keys"].level == "error"


def test_placeholder_secret_env_is_not_a_leak(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["config"]["Env"] += ["AIG_PORTKEY_API_KEY=__REPLACE_ME_AIG_PORTKEY_API_KEY__", "FIDDLER_API_KEY="]
    assert by_check(ic.evaluate(facts(data), pins))["no-secrets-in-env"].level == "ok"


def test_key_shaped_value_under_any_name_fails(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["config"]["Env"].append(f"SOME_SETTING={FAKE_OPENAI_KEY}")
    f = by_check(ic.evaluate(facts(data), pins))["no-secrets-in-env"]
    assert f.level == "error" and "SOME_SETTING" in f.message
    assert FAKE_OPENAI_KEY not in f.message  # names only, never values


def test_wrong_aig_host(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["config"]["Env"] = [e for e in data["config"]["Env"] if not e.startswith("AIG_HOST=")] + ["AIG_HOST=laptop"]
    assert by_check(ic.evaluate(facts(data), pins))["aig-host"].level == "error"


def test_gitleaks_not_run_is_a_warning(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["gitleaks_findings"] = None
    findings = by_check(ic.evaluate(facts(data), pins))
    assert findings["fs-gitleaks"].level == "warn"
    assert by_check(ic.evaluate(facts(data), pins, strict=True))["fs-gitleaks"].level == "error"


def test_custom_entrypoint_without_shim_warns(load_fixture, pins):
    data = load_fixture("agent-python-good.json")
    data["self_check"] = None
    assert by_check(ic.evaluate(facts(data), pins))["entrypoint-self-check"].level == "warn"
