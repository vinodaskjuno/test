"""infra/ci/docker AgentCore entrypoints: secret loading, request handling (no AWS, no Docker)."""

import json
import shutil
import subprocess

import pytest

import agentcore_shim as shim
from conftest import FAKE_PORTKEY_KEY, REPO


class FakeSecrets:
    def __init__(self, data):
        self.data, self.ids = data, []

    def get_secret_value(self, SecretId):  # noqa: N803 (boto3 signature)
        self.ids.append(SecretId)
        return {"SecretString": json.dumps(self.data)}


def test_secret_loading_copies_only_allowed_keys():
    env = {"AIG_RUNTIME_SECRET_ARN": "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/agents/a"}
    client = FakeSecrets({"AIG_PORTKEY_API_KEY": FAKE_PORTKEY_KEY, "AIG_FIDDLER_API_KEY": "f", "OPENAI_API_KEY": "nope",
                          "AIG_PLATFORM_API_TOKEN": ""})
    loaded = shim.load_runtime_secret(env, client=client)
    assert loaded == ["AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY"]
    assert env["AIG_PORTKEY_API_KEY"] == FAKE_PORTKEY_KEY and "OPENAI_API_KEY" not in env
    assert "AIG_PLATFORM_API_TOKEN" not in env
    assert client.ids == [env["AIG_RUNTIME_SECRET_ARN"]]


def test_no_secret_arn_means_nothing_loaded():
    assert shim.load_runtime_secret({}, client=FakeSecrets({})) == []


def test_secret_must_be_an_object():
    with pytest.raises(ValueError):
        shim.load_runtime_secret({"AIG_RUNTIME_SECRET_ARN": "x"}, client=FakeSecrets(["a"]))


def test_extract_prompt():
    assert shim.extract_prompt({"prompt": "hi"}) == "hi"
    assert shim.extract_prompt({"input": "hi"}) == "hi"
    assert shim.extract_prompt("hi") == "hi"
    with pytest.raises(ValueError):
        shim.extract_prompt({"x": 1})


def test_resolve_entrypoint():
    assert shim.resolve_entrypoint("json:dumps") is json.dumps
    with pytest.raises(ValueError):
        shim.resolve_entrypoint("json")


SDK_PY = REPO / "sdk" / "python" / ".venv" / "bin" / "python"
TS_DIST = REPO / "sdk" / "typescript" / "dist"
SHIM_DIR = REPO / "infra" / "ci" / "docker"

# Runs inside the SDK's virtualenv (aig_sdk.serve + cryptography): the shim's app for a legacy
# `str -> str` entrypoint and for a marked invocation handler, exercised over real HTTP.
PY_SERVE_CHECK = r"""
import json, sys, threading, time, urllib.request, urllib.error
sys.path.insert(0, sys.argv[1])
import agentcore_shim as shim
from aig_sdk.serve import generate_test_key, sign_test_token, make_server, invocation_handler, Output

key, pem = generate_test_key()
env = {"AIG_ENV": "dev", "AIG_AGENT_ID": "shim-agent", "AIG_CALLER_PUBLIC_KEY": pem}

def legacy(prompt):
    if prompt == "boom":
        raise RuntimeError("secret detail")
    return f"echo: {prompt}"

@invocation_handler
async def modern(inv):
    yield "hi "
    yield Output({"user": inv.caller.user})

def post(url, body, headers=None):
    req = urllib.request.Request(url + "/invocations", data=json.dumps(body).encode(),
                                 headers={"content-type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()

now = int(time.time())
claims = {"iss": "aig-platform-api/dev", "aud": "shim-agent", "sub": "bob@example.com", "iat": now, "nbf": now, "exp": now + 300,
          "jti": "7d3f2c1e-9a4b-4c5d-8e6f-0a1b2c3d4e5f", "user": "bob@example.com", "name": "Bob", "team": "claims-ai",
          "tier": "standard", "groups": [], "agent_id": "shim-agent", "version": "1", "env": "dev",
          "invocation_id": "7d3f2c1e-9a4b-4c5d-8e6f-0a1b2c3d4e5f", "trace_id": "trace-shim-00001"}
tok = sign_test_token(key, claims)
out = {}
for name, entry in (("legacy", legacy), ("modern", modern)):
    app = shim.make_app(entry, env=env, descriptor={"name": "shim-agent", "input_schema": {"type": "object"}})
    srv = make_server(app, "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    res = {
        "prompt": post(url, {"prompt": "hello"}),
        "boom": post(url, {"prompt": "boom"}),
        "contract": post(url, {"input": {"prompt": "x"}}, {"x-amzn-bedrock-agentcore-runtime-custom-aig-caller": tok}),
        "stream": post(url, {"messages": [{"role": "user", "content": "x"}], "stream": True}, {"x-aig-caller": tok}),
        "no_token": post(url, {"input": {"prompt": "x"}}),
        "schema": urllib.request.urlopen(url + "/schema", timeout=5).read().decode(),
        "ping": urllib.request.urlopen(url + "/ping", timeout=5).read().decode(),
    }
    srv.shutdown()
    out[name] = res
print(json.dumps(out))
"""


@pytest.mark.skipif(not SDK_PY.exists(), reason="needs sdk/python/.venv (make setup)")
def test_python_shim_serves_the_contract_and_legacy_prompts():
    out = subprocess.run([str(SDK_PY), "-c", PY_SERVE_CHECK, str(SHIM_DIR)], capture_output=True, text=True, timeout=60)
    assert out.returncode == 0, out.stderr
    data = json.loads(out.stdout)
    legacy, modern = data["legacy"], data["modern"]
    status, body = legacy["prompt"]
    assert status == 200 and json.loads(body)["output"] == "echo: hello"  # deploy smoke test body
    status, body = legacy["boom"]
    assert status == 500 and json.loads(body) == {"error": {"code": "agent_error", "message": "agent failed"}}
    assert "secret detail" not in body
    status, body = legacy["contract"]
    assert status == 200 and json.loads(body)["output"] == "echo: x" and json.loads(body)["trace_id"] == "trace-shim-00001"
    assert legacy["no_token"][0] == 401
    assert json.loads(legacy["schema"])["protocol"] == "aig-http/1" and json.loads(legacy["ping"]) == {"status": "Healthy"}
    status, body = modern["stream"]
    assert status == 200 and body.startswith('event: delta\ndata: {"text":"hi "}')
    assert '"output":{"user":"bob@example.com"}' in body and body.endswith("event: done\ndata: {}\n\n")
    assert json.loads(modern["contract"][1])["output"] == {"user": "bob@example.com"}


def test_find_descriptor(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert shim.find_descriptor(tmp_path / "nowhere") is None
    (tmp_path / "aig-agent.yaml").write_text("name: x\n")
    assert shim.find_descriptor(tmp_path / "nowhere") == tmp_path / "aig-agent.yaml"


@pytest.mark.skipif(shutil.which("node") is None or not (TS_DIST / "serve.js").exists(), reason="needs node and sdk/typescript/dist")
def test_node_shim_serves_the_contract_and_legacy_prompts():
    script = f"""
    import {{ makeApp }} from {json.dumps(str(SHIM_DIR / 'agentcore-shim.mjs'))};
    const s = await import({json.dumps(str(TS_DIST / 'serve.js'))});
    const key = s.generateTestKey();
    const env = {{ AIG_ENV: "dev", AIG_AGENT_ID: "shim-agent", AIG_CALLER_PUBLIC_KEY: key.publicPem }};
    const now = Math.floor(Date.now() / 1000);
    const tok = s.signTestToken(key.privateKey, {{ iss: "aig-platform-api/dev", aud: "shim-agent", sub: "bob@example.com", iat: now, nbf: now,
      exp: now + 300, jti: "7d3f2c1e-9a4b-4c5d-8e6f-0a1b2c3d4e5f", user: "bob@example.com", name: "Bob", team: "claims-ai", tier: "standard",
      groups: [], agent_id: "shim-agent", version: "1", env: "dev", invocation_id: "7d3f2c1e-9a4b-4c5d-8e6f-0a1b2c3d4e5f", trace_id: "trace-shim-00001" }});
    const legacy = await makeApp(async (p) => `echo: ${{p}}`, {{ env, descriptor: {{ name: "shim-agent" }} }}, s);
    const modern = await makeApp(s.invocationHandler(async function* (inv) {{ yield "hi "; yield new s.Output({{ user: inv.caller.user }}); }}),
      {{ env, descriptor: {{ name: "shim-agent" }} }}, s);
    const call = async (app, body, headers = {{}}) => {{ const r = await s.collect(await app.handle("POST", "/invocations", headers, JSON.stringify(body))); return [r.status, r.body]; }};
    console.log(JSON.stringify({{
      prompt: await call(legacy, {{ prompt: "hello" }}),
      contract: await call(legacy, {{ input: {{ prompt: "x" }} }}, {{ "x-amzn-bedrock-agentcore-runtime-custom-aig-caller": tok }}),
      noToken: await call(legacy, {{ input: {{ prompt: "x" }} }}),
      stream: await call(modern, {{ messages: [{{ role: "user", content: "x" }}], stream: true }}, {{ "x-aig-caller": tok }}),
    }}));
    """
    out = subprocess.run(["node", "--input-type=module", "-e", script], capture_output=True, text=True, timeout=60)
    assert out.returncode == 0, out.stderr
    data = json.loads(out.stdout)
    assert data["prompt"][0] == 200 and json.loads(data["prompt"][1])["output"] == "echo: hello"
    assert data["contract"][0] == 200 and json.loads(data["contract"][1])["output"] == "echo: x"
    assert data["noToken"][0] == 401
    assert data["stream"][1].startswith('event: delta\ndata: {"text":"hi "}') and '"user":"bob@example.com"' in data["stream"][1]


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_node_shim_helpers():
    script = f"""
    import {{ extractPrompt, loadRuntimeSecret }} from {json.dumps(str(REPO / 'infra/ci/docker/agentcore-shim.mjs'))};
    const env = {{ AIG_RUNTIME_SECRET_ARN: "arn:x" }};
    const client = {{ getSecretValue: async () => ({{ SecretString: JSON.stringify({{ AIG_PORTKEY_API_KEY: "k", OPENAI_API_KEY: "no" }}) }}) }};
    const loaded = await loadRuntimeSecret(env, client);
    console.log(JSON.stringify({{ loaded, env, prompt: extractPrompt({{ prompt: "hi" }}) }}));
    """
    out = subprocess.run(["node", "--input-type=module", "-e", script], capture_output=True, text=True, timeout=30)
    assert out.returncode == 0, out.stderr
    data = json.loads(out.stdout)
    assert data["loaded"] == ["AIG_PORTKEY_API_KEY"] and "OPENAI_API_KEY" not in data["env"] and data["prompt"] == "hi"
