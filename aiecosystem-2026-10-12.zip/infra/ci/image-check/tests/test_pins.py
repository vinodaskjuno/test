"""infra/ci/image-check/pins.json stays in sync with the SDK sources and the template Dockerfiles."""

import json
import re
import subprocess
import sys
import tomllib

from conftest import CI, REPO


def test_python_sdk_pin_matches_pyproject(pins):
    pyproject = tomllib.loads((REPO / "sdk/python/pyproject.toml").read_text())
    assert pyproject["project"]["name"] == "aig-sdk"
    assert pins["sdk"]["aig-sdk"] == pyproject["project"]["version"], "bump infra/ci/image-check/pins.json with sdk/python"


def test_python_sdk_pin_matches_version_module(pins):
    text = (REPO / "sdk/python/src/aig_sdk/_version.py").read_text()
    assert re.search(r"__version__\s*=\s*['\"]" + re.escape(pins["sdk"]["aig-sdk"]) + "['\"]", text)


def test_typescript_sdk_pin_matches_package_json(pins):
    pkg = json.loads((REPO / "sdk/typescript/package.json").read_text())
    assert pkg["name"] == "@aig/sdk"
    assert pins["sdk"]["@aig/sdk"] == pkg["version"], "bump infra/ci/image-check/pins.json with sdk/typescript"


def test_base_images_have_digest_slots(pins):
    for name, entry in pins["base_images"].items():
        assert entry["image"] and ":" in entry["image"], name
        assert entry["digest"].startswith("sha256:"), name


def test_docker_templates_default_to_pinned_sdk(pins):
    for lang, key in (("python", "aig-sdk"), ("node", "@aig/sdk")):
        text = (REPO / f"infra/ci/docker/agent-{lang}.Dockerfile").read_text()
        versions = set(re.findall(r"^ARG AIG_SDK_VERSION=(\S+)$", text, flags=re.M))
        assert versions == {pins["sdk"][key]}, lang
        # The base image defaults are the tags recorded in pins.json.
        assert f"ARG BUILD_IMAGE={pins['base_images'][f'{lang}_build']['image']}" in text
        assert f"ARG RUNTIME_IMAGE={pins['base_images'][f'{lang}_runtime']['image']}" in text


def test_template_dockerfiles_are_rendered_from_ci_docker():
    proc = subprocess.run([sys.executable, str(REPO / "infra/ci/docker/render-templates.py"), "--check"], capture_output=True, text=True)
    assert proc.returncode == 0, proc.stderr


def test_every_template_has_a_dockerfile_and_dockerignore():
    for tdir in sorted((REPO / "sdk" / "templates").iterdir()):
        if (tdir / "aig-template.json").is_file():
            assert (tdir / "Dockerfile").is_file(), tdir.name
            ignore = (tdir / ".dockerignore").read_text().splitlines()
            assert ".env" in ignore and ".env.*" in ignore and ".venv" in ignore, tdir.name


def test_pins_file_is_the_one_the_script_reads():
    import image_check

    assert image_check.DEFAULT_PINS == CI / "pins.json"


def test_templates_depend_on_the_pinned_sdk_versions(pins):
    """Starter templates depend on the SDK by version (never a repo path), at the pinned release."""
    py_pin, ts_pin = pins["sdk"]["aig-sdk"], pins["sdk"]["@aig/sdk"]
    for name in ("langgraph-py", "strands-py"):
        project = tomllib.loads((REPO / "sdk/templates" / name / "pyproject.toml").read_text())["project"]
        sdk_deps = [d for d in project["dependencies"] + project["optional-dependencies"]["dev"] if d.startswith("aig-sdk")]
        assert sdk_deps and all(d.endswith(f"=={py_pin}") for d in sdk_deps), (name, sdk_deps)
    pkg = json.loads((REPO / "sdk/templates/langgraph-ts/package.json").read_text())
    assert pkg["dependencies"]["@aig/sdk"] == ts_pin
    lock = json.loads((REPO / "sdk/templates/langgraph-ts/package-lock.json").read_text())
    assert lock["packages"][""]["dependencies"]["@aig/sdk"] == ts_pin
    assert lock["packages"]["node_modules/@aig/sdk"]["resolved"] == f"file:.aig-wheels/aig-sdk-{ts_pin}.tgz"
