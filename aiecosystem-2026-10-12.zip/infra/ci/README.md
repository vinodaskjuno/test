# infra/ci/: image build check and hardened agent images (Phase 5)

| Path | What it is |
|---|---|
| [`image-check/`](image-check) | The image build check (enforcement table, "Image build check"). It fails the build when an image lacks the pinned SDK, fails the in-image static doctor, runs as root or carries secrets |
| [`image-check/pins.json`](image-check/pins.json) | Pinned `aig-sdk` / `@aig/sdk` versions and base-image digests. A test keeps it in sync with `sdk/python/pyproject.toml` and `sdk/typescript/package.json` |
| [`docker/agent-python.Dockerfile`](docker/agent-python.Dockerfile), [`docker/agent-node.Dockerfile`](docker/agent-node.Dockerfile) | Hardened multi-stage templates for agent images on Bedrock AgentCore |
| [`docker/agentcore_shim.py`](docker/agentcore_shim.py), [`docker/agentcore-shim.mjs`](docker/agentcore-shim.mjs) | AgentCore entrypoint baked into agent images: runtime secret, fail-closed `init()`, then serves the AIG invocation contract (`aig-http/1`) with `aig_sdk.serve` / `@aig/sdk/serve` on 8080: `/ping`, `/invocations`, `/schema` |
| [`docker/render-templates.py`](docker/render-templates.py) | Writes `sdk/templates/<t>/Dockerfile` + `.dockerignore` from the templates (`--check` in the tests) |

The workflows that use them are `.github/workflows/image-check.yml` (reusable),
`deploy-agent.yml` and `deploy-platform.yml`. The evals gate (`evals-gate.yml`) is documented in
`docs/evals.md`.

## Image check

```bash
infra/ci/image-check/image-check.sh <image> python|node [--profile agent|service] [--strict] [--json]
make image-check IMAGE=<ref> IMAGE_LANG=python PROFILE=agent    # same, through make (needs Docker)
make image-check-test                                           # unit tests, no Docker
```

Docker is used only to collect facts:
- `docker image inspect` and `docker history`
- `docker run --rm --network none --read-only --entrypoint <python|node> ...` for the in-image checks
- `docker create` + `docker export`, read for the filesystem scan

Every decision is a pure function over those facts, so the logic is unit-tested with fixtures and a
fake runner. Docker is not installed on developer machines; real images are checked in CI.

| Check | Profile | Fails when |
|---|---|---|
| `non-root` | all | no `USER`, or `root` / `0` |
| `no-provider-keys` | all | any of `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, ... (backend/contracts/env-vars.md) is declared in the image config, even empty |
| `no-secrets-in-env` | all | an AIG/Portkey/Fiddler secret name has a non-placeholder value, or any value is key-shaped |
| `no-secrets-in-history` | all | the layer history has a key-shaped string or `SECRET=value` (use BuildKit `--secret`) |
| `fs-gitleaks` | all | gitleaks (repo `.gitleaks.toml`) finds leaks in the exported filesystem (`/app`, `/opt`, `/srv`, `/home`, `/root`, `/etc`, ...). Third-party package dirs are left to ECR scan-on-push |
| `fs-no-dotenv`, `fs-no-private-keys`, `fs-no-key-shaped` | all | `.env*` files (not `.env.example`), `*.key`/`*.p12`/`*.pfx`, or key-shaped strings in the app files |
| `sdk-pinned` | agent | `aig-sdk` (`importlib.metadata`, the same data as `pip show`) or `node_modules/@aig/sdk/package.json` is missing or not the `pins.json` version |
| `sdk-init` | agent | `import aig_sdk` / `import('@aig/sdk')` fails or has no `init` |
| `static-doctor` | agent | the SDK's offline contract checks (`aig_sdk.contract.validate` / `validate` from `@aig/sdk`) fail inside the image (raw-key guard, `AIG_*` names and values). The image's own env plus obviously fake values for the rest are used. This is `aig doctor` without its network checks: CI cannot reach Portkey or Fiddler |
| `env-contract` | agent | label `org.aig.env.required` does not list every required `AIG_*` variable |
| `aig-host` | agent | `AIG_HOST` is not `agentcore` or `ecs` in the image config |
| `entrypoint-self-check` | agent | the AgentCore shim's `--self-check` (SDK import, `init`, `AIG_AGENT_ENTRYPOINT` resolves) fails. A warning when the image uses its own entrypoint |
| `arch-arm64` | agent | not linux/arm64 (AgentCore) |
| `base-digest`, `healthcheck`, `revision-label` | all | warning (error with `--strict`): base image not pinned by digest, no `HEALTHCHECK`, no `org.opencontainers.image.revision` |

## Hardened agent images

Both templates:
- are multi-stage, with a distroless runtime (no shell, no package manager, no pip/npm)
- run as non-root uid 65532 and are read-only-root-FS friendly
- pin base images by digest in CI (`pins.json` `base_images`; local builds use the tags)
- install the SDK at the pinned version
- have a `HEALTHCHECK`, an SBOM and provenance attestation (`buildx --sbom=true --provenance=mode=max`)
  and OCI labels
- are built for linux/arm64 (AgentCore)

`sdk/templates/{langgraph-py,strands-py,langgraph-ts}/Dockerfile` are rendered copies with the
template's entrypoint and SDK extra filled in. `aig init` copies them into new agents and replaces
the sample package name. Build from an agent directory:

```bash
pip wheel --no-deps -w .aig-wheels <aig-repo>/sdk/python        # or the internal index (--secret id=pip_index_url)
docker buildx build --platform linux/arm64 --build-context aigci=<aig-repo>/infra/ci/docker -t <image> .
```

The image entrypoint does three things before it serves requests:
1. reads `AIG_RUNTIME_SECRET_ARN`, a JSON secret, and copies only `AIG_PORTKEY_API_KEY`,
   `AIG_FIDDLER_API_KEY` and `AIG_PLATFORM_API_TOKEN` into its own environment, without logging them
2. calls the SDK's fail-closed `init()`
3. imports `AIG_AGENT_ENTRYPOINT` (`pkg.module:handler`, or `dist/agent.js#handler` for Node): a
   handler marked with `aig_sdk.serve.invocation_handler` / `invocationHandler()` (takes an
   `Invocation`, may stream deltas), or a legacy `str -> str` function (gets `invocation.prompt`)
4. serves it with the SDK's serve helpers (backend/contracts/agent-invocation.md): `POST /invocations`
   (JSON or SSE `delta|output|error|done`), `GET /ping`, `GET /schema` (the agent's `aig-agent.yaml`,
   copied next to the shim: `/opt/aig/` or `/app/.aig/`). Every request's caller token is verified
   (header `X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller` or the body's `aig_context`; public key
   from platform-api's JWKS at `AIG_PLATFORM_API_URL`), the input is validated against the input
   schema, and the caller's user/team + invocation id go into every Portkey call's metadata.

The legacy body `{"prompt": "..."}` (the deploy smoke test; AgentCore authorises it with IAM) is still
answered `{"output": ..., "trace_id": ...}`. The Python image installs `aig-sdk[<extra>,serve]`.
`AIG_RUNTIME_SECRET_ARN` is read only by this shim, never by the SDK.
