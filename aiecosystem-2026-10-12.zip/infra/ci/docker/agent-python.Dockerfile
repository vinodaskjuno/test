# syntax=docker/dockerfile:1.7
# AIG hardened image template for Python agents on Bedrock AgentCore (docs/IMPLEMENTATION_PLAN.md Phase 5).
#
#   * multi-stage: build in debian:12-slim, run on distroless python3-debian12 (no shell, no package
#     manager, no pip in the final image), non-root uid 65532
#   * base images pinned by digest in CI: .github/workflows/deploy-agent.yml passes
#     --build-arg BUILD_IMAGE/RUNTIME_IMAGE=<image>@sha256:<digest> from infra/ci/image-check/pins.json
#     (the defaults below are tags so a local build works)
#   * aig-sdk installed at the pinned version (AIG_SDK_VERSION = infra/ci/image-check/pins.json), verified
#     by infra/ci/image-check after the build, with its `serve` extra (aig_sdk.serve: the AIG invocation
#     contract the shim serves); boto3 for the runtime-secret read
#   * the agent's aig-agent.yaml (input schema, GET /schema) is copied next to the shim (/opt/aig/)
#   * read-only root filesystem friendly: bytecode compiled at build time, caches under /tmp
#   * SBOM + provenance: build with `docker buildx build --sbom=true --provenance=mode=max`
#   * AgentCore requires linux/arm64: build with --platform linux/arm64
#
# Build (context = the agent project; the AgentCore entrypoint comes from the AIG platform repo):
#   pip wheel --no-deps -w .aig-wheels <platform-repo>/sdk/python      # or use the internal index
#   docker buildx build --platform linux/arm64 --build-context aigci=<platform-repo>/infra/ci/docker \
#     --sbom=true --provenance=mode=max -t <ecr>/aig/agents/<agent_id>:<git-sha> .
# Private package index: --secret id=pip_index_url,src=<file containing the index URL>.
ARG BUILD_IMAGE=debian:12-slim
ARG RUNTIME_IMAGE=gcr.io/distroless/python3-debian12:nonroot

FROM ${BUILD_IMAGE} AS build
ARG AIG_SDK_VERSION=0.1.0
ARG AIG_SDK_EXTRA=langgraph
ENV PIP_NO_CACHE_DIR=1 PIP_DISABLE_PIP_VERSION_CHECK=1 PYTHONDONTWRITEBYTECODE=1
RUN apt-get update \
 && apt-get install -y --no-install-recommends python3 python3-venv \
 && rm -rf /var/lib/apt/lists/*
WORKDIR /src
COPY . .
RUN --mount=type=secret,id=pip_index_url,required=false \
    set -eu; \
    if [ -s /run/secrets/pip_index_url ]; then PIP_INDEX_URL="$(cat /run/secrets/pip_index_url)"; export PIP_INDEX_URL; fi; \
    python3 -m venv /opt/venv; \
    /opt/venv/bin/pip install --find-links /src/.aig-wheels \
      "aig-sdk[${AIG_SDK_EXTRA},serve]==${AIG_SDK_VERSION}" "boto3>=1.35,<2" /src; \
    /opt/venv/bin/pip uninstall -y pip setuptools wheel; \
    /opt/venv/bin/python -m compileall -q /opt/venv
COPY --from=aigci agentcore_shim.py /opt/aig/agentcore_shim.py
RUN if [ -f /src/aig-agent.yaml ]; then cp /src/aig-agent.yaml /opt/aig/aig-agent.yaml; fi; \
    /opt/venv/bin/python -m compileall -q /opt/aig

FROM ${RUNTIME_IMAGE}
ARG BUILD_IMAGE
ARG RUNTIME_IMAGE
ARG AGENT_ENTRYPOINT=aig_langgraph_starter.agent:handler
ARG AIG_SDK_VERSION=0.1.0
ARG VCS_REF=unknown
LABEL org.opencontainers.image.title="aig-agent" \
      org.opencontainers.image.base.name="${RUNTIME_IMAGE}" \
      org.opencontainers.image.revision="${VCS_REF}" \
      org.aig.sdk="aig-sdk==${AIG_SDK_VERSION}" \
      org.aig.sbom="buildx --sbom=true (SPDX attestation in the registry)" \
      org.aig.env.required="AIG_PORTKEY_BASE_URL,AIG_FIDDLER_PROJECT,AIG_PLATFORM_API_URL,AIG_AGENT_ID,AIG_TEAM,AIG_ENV,AIG_HOST,AIG_PORTKEY_API_KEY,AIG_FIDDLER_API_KEY,AIG_FIDDLER_URL" \
      org.aig.env.secrets="AIG_PLATFORM_API_TOKEN,AIG_PORTKEY_API_KEY,AIG_FIDDLER_API_KEY"
COPY --from=build /opt/venv /opt/venv
COPY --from=build /opt/aig /opt/aig
# Non-secret defaults only; everything else (and every secret) is set by the AgentCore runtime.
ENV PATH=/opt/venv/bin:/usr/bin:/bin \
    PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    HOME=/tmp \
    XDG_CACHE_HOME=/tmp/.cache \
    PORT=8080 \
    AIG_HOST=agentcore \
    AIG_PORTKEY_CONFIG=pc-aig-router \
    AIG_AGENT_ENTRYPOINT=${AGENT_ENTRYPOINT}
USER 65532:65532
WORKDIR /tmp
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s --start-period=20s --retries=3 \
  CMD ["/opt/venv/bin/python", "-c", "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8080/ping', timeout=2).status == 200 else 1)"]
ENTRYPOINT ["/opt/venv/bin/python", "/opt/aig/agentcore_shim.py"]
