# syntax=docker/dockerfile:1.7
# AIG hardened image template for Node/TypeScript agents on Bedrock AgentCore (Phase 5).
#
#   * multi-stage: build in node:22-bookworm-slim, run on distroless nodejs22-debian12 (no shell, no
#     npm in the final image), non-root uid 65532
#   * base images pinned by digest in CI (--build-arg BUILD_IMAGE/RUNTIME_IMAGE=<image>@sha256:...
#     from infra/ci/image-check/pins.json); the defaults are tags so a local build works
#   * @aig/sdk at the pinned version (AIG_SDK_VERSION = infra/ci/image-check/pins.json), verified by
#     infra/ci/image-check; @aws-sdk/client-secrets-manager for the runtime-secret read
#   * read-only root filesystem friendly (nothing written outside /tmp), production deps only
#   * the agent's aig-agent.yaml (input schema, GET /schema) is copied next to the shim (/app/.aig/);
#     the shim serves the AIG invocation contract with @aig/sdk/serve
#   * SBOM + provenance: `docker buildx build --sbom=true --provenance=mode=max`
#   * AgentCore requires linux/arm64: build with --platform linux/arm64
#
# Build (context = the agent project):
#   (cd <platform-repo>/sdk/typescript && npm run build && npm pack --pack-destination <agent>/.aig-wheels)
#   docker buildx build --platform linux/arm64 --build-context aigci=<platform-repo>/infra/ci/docker \
#     --sbom=true --provenance=mode=max -t <ecr>/aig/agents/<agent_id>:<git-sha> .
# Private registry: --secret id=npmrc,src=<.npmrc with the internal registry + token>.
ARG BUILD_IMAGE=node:22-bookworm-slim
ARG RUNTIME_IMAGE=gcr.io/distroless/nodejs22-debian12:nonroot

FROM ${BUILD_IMAGE} AS build
ARG AIG_SDK_VERSION=0.1.0
ARG AGENT_SOURCES="src/agent.ts"
ENV NPM_CONFIG_UPDATE_NOTIFIER=false NPM_CONFIG_FUND=false NPM_CONFIG_AUDIT=false
WORKDIR /app
COPY . .
# @aig/sdk comes from the local tarball (.aig-wheels/aig-sdk-<version>.tgz, built from the platform
# repo) or, without it, from the internal registry at exactly AIG_SDK_VERSION.
RUN --mount=type=secret,id=npmrc,required=false \
    set -eu; \
    if [ -s /run/secrets/npmrc ]; then cp /run/secrets/npmrc /root/.npmrc; fi; \
    tgz=".aig-wheels/aig-sdk-${AIG_SDK_VERSION}.tgz"; \
    if [ -f "$tgz" ]; then sdk="file:$tgz"; else sdk="${AIG_SDK_VERSION}"; fi; \
    npm pkg set "dependencies.@aig/sdk=$sdk" "dependencies.@aws-sdk/client-secrets-manager=^3.600.0"; \
    npm install --workspaces=false --include=dev; \
    npx tsc --outDir dist --rootDir src --target ES2022 --module ESNext --moduleResolution Bundler \
      --skipLibCheck --esModuleInterop --types node ${AGENT_SOURCES}; \
    npm prune --workspaces=false --omit=dev; \
    rm -f /root/.npmrc
COPY --from=aigci agentcore-shim.mjs /app/.aig/agentcore-shim.mjs
RUN if [ -f /app/aig-agent.yaml ]; then cp /app/aig-agent.yaml /app/.aig/aig-agent.yaml; fi

FROM ${RUNTIME_IMAGE}
ARG RUNTIME_IMAGE
ARG AGENT_ENTRYPOINT=dist/agent.js#handler
ARG AIG_SDK_VERSION=0.1.0
ARG VCS_REF=unknown
LABEL org.opencontainers.image.title="aig-agent" \
      org.opencontainers.image.base.name="${RUNTIME_IMAGE}" \
      org.opencontainers.image.revision="${VCS_REF}" \
      org.aig.sdk="@aig/sdk@${AIG_SDK_VERSION}" \
      org.aig.sbom="buildx --sbom=true (SPDX attestation in the registry)" \
      org.aig.env.required="AIG_PORTKEY_BASE_URL,AIG_FIDDLER_PROJECT,AIG_PLATFORM_API_URL,AIG_AGENT_ID,AIG_TEAM,AIG_ENV,AIG_HOST,AIG_PORTKEY_API_KEY,AIG_FIDDLER_API_KEY,AIG_FIDDLER_URL" \
      org.aig.env.secrets="AIG_PLATFORM_API_TOKEN,AIG_PORTKEY_API_KEY,AIG_FIDDLER_API_KEY"
WORKDIR /app
COPY --from=build /app/package.json /app/package.json
COPY --from=build /app/node_modules /app/node_modules
COPY --from=build /app/dist /app/dist
COPY --from=build /app/.aig /app/.aig
# Non-secret defaults only; everything else (and every secret) is set by the AgentCore runtime.
ENV NODE_ENV=production \
    HOME=/tmp \
    PORT=8080 \
    AIG_APP_DIR=/app \
    AIG_HOST=agentcore \
    AIG_PORTKEY_CONFIG=pc-aig-router \
    AIG_AGENT_ENTRYPOINT=${AGENT_ENTRYPOINT}
USER 65532:65532
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s --start-period=20s --retries=3 \
  CMD ["/nodejs/bin/node", "-e", "fetch('http://127.0.0.1:8080/ping').then(r=>process.exit(r.ok?0:1),()=>process.exit(1))"]
ENTRYPOINT ["/nodejs/bin/node", "/app/.aig/agentcore-shim.mjs"]
