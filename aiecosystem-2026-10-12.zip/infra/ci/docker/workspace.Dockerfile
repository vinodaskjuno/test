# syntax=docker/dockerfile:1.7
# AIG team workspace image (docs/IMPLEMENTATION_PLAN.md Phase 6): one ECS Fargate task per workspace
# runs `workspace-job` (backend/workspace-orchestrator/src/workspace_orchestrator/job).
#
# Contents (the "starter pack" for the code agent):
#   * git, Python 3.12, Node 22 (the repo's own tests run in here), tini (PID 1, forwards SIGTERM
#     from ecs:StopTask so the job flushes its Fiddler spans)
#   * aig-sdk (Python) and @aig/sdk (TypeScript) at the pinned versions of infra/ci/image-check/pins.json,
#     built from this repo (sdk/python, sdk/typescript) - `aig doctor` / `aig eval` are on PATH
#   * Claude Code CLI @anthropic-ai/claude-code at CLAUDE_CODE_VERSION (verified: ANTHROPIC_BASE_URL,
#     ANTHROPIC_AUTH_TOKEN, ANTHROPIC_CUSTOM_HEADERS; see the orchestrator README) and the optional
#     Python claude-agent-sdk (AIG_WS_CODE_AGENT=claude-sdk)
#   * workspace-orchestrator[job,agent-sdk] in /opt/aig/venv (entrypoint `workspace-job`)
#
# Hardening: non-root uid 10001 with a real HOME (Claude Code writes ~/.claude), no secrets baked in
# (Portkey key, Fiddler key and GitHub App key come from Secrets Manager through the task
# definition), no sshd/sudo, apt lists removed, pip/npm caches off, bytecode precompiled, base images
# pinned by digest in CI (--build-arg PYTHON_IMAGE/NODE_IMAGE=<image>@sha256:...), SBOM +
# provenance via `docker buildx build --sbom=true --provenance=mode=max`. The task runs with a
# restricted-egress security group (Portkey, Fiddler, the orchestrator relay, the Git host and the
# package mirror only) - see backend/workspace-orchestrator/README.md "Infrastructure" and infra/terraform/modules/workspaces.
# Writable paths: /workspace (clone, venv) and /home/aig; the root filesystem can be read-only
# (readonlyRootFilesystem=true with /workspace, /home/aig and /tmp as task volumes).
#
# Build from the REPO ROOT (needs sdk/ and backend/workspace-orchestrator/):
#   (cd sdk/typescript && npm ci && npm run build)
#   docker buildx build -f infra/ci/docker/workspace.Dockerfile --platform linux/amd64 \
#     --sbom=true --provenance=mode=max -t <ecr>/aig/workspace:<git-sha> .
# Private indexes: --secret id=pip_index_url,src=... and --secret id=npmrc,src=...
# Optional toolchains for Java repos: --build-arg INSTALL_JAVA=true (JDK 17 + Maven; larger image).
ARG PYTHON_IMAGE=python:3.12-slim-bookworm
ARG NODE_IMAGE=node:22-bookworm-slim

FROM ${NODE_IMAGE} AS node

FROM ${PYTHON_IMAGE} AS build
ARG AIG_SDK_VERSION=0.1.0
ENV PIP_NO_CACHE_DIR=1 PIP_DISABLE_PIP_VERSION_CHECK=1
WORKDIR /src
COPY sdk/python ./sdk/python
COPY backend/workspace-orchestrator/pyproject.toml ./backend/workspace-orchestrator/pyproject.toml
COPY backend/workspace-orchestrator/src ./backend/workspace-orchestrator/src
RUN --mount=type=secret,id=pip_index_url,required=false \
    set -eu; \
    if [ -s /run/secrets/pip_index_url ]; then PIP_INDEX_URL="$(cat /run/secrets/pip_index_url)"; export PIP_INDEX_URL; fi; \
    grep -q "^version = \"${AIG_SDK_VERSION}\"" sdk/python/pyproject.toml || { echo "aig-sdk is not ${AIG_SDK_VERSION}"; exit 1; }; \
    python -m venv /opt/aig/venv; \
    /opt/aig/venv/bin/pip install "./sdk/python[evals]" "./backend/workspace-orchestrator[job,agent-sdk]"; \
    /opt/aig/venv/bin/pip check; \
    /opt/aig/venv/bin/python -m compileall -q /opt/aig/venv

FROM ${PYTHON_IMAGE}
ARG AIG_SDK_VERSION=0.1.0
ARG CLAUDE_CODE_VERSION=2.1.247
ARG INSTALL_JAVA=false
ARG VCS_REF=unknown
LABEL org.opencontainers.image.title="aig-workspace" \
      org.opencontainers.image.revision="${VCS_REF}" \
      org.aig.sdk="aig-sdk==${AIG_SDK_VERSION},@aig/sdk@${AIG_SDK_VERSION}" \
      org.aig.code-agent="@anthropic-ai/claude-code@${CLAUDE_CODE_VERSION}" \
      org.aig.env.required="WORKSPACE_ID,AIG_WS_STATUS_URL,AIG_WS_STATUS_TOKEN,AIG_PORTKEY_BASE_URL,AIG_FIDDLER_URL,AIG_FIDDLER_PROJECT,AIG_AGENT_ID,AIG_TEAM" \
      org.aig.env.secrets="AIG_PORTKEY_API_KEY,AIG_FIDDLER_API_KEY,GITHUB_APP_PRIVATE_KEY"

ENV DEBIAN_FRONTEND=noninteractive
RUN set -eu; \
    apt-get update; \
    apt-get install -y --no-install-recommends git ca-certificates tini; \
    if [ "${INSTALL_JAVA}" = "true" ]; then apt-get install -y --no-install-recommends openjdk-17-jdk-headless maven; fi; \
    apt-get purge -y --auto-remove; rm -rf /var/lib/apt/lists/* /var/cache/apt/*

# Node 22 (+ npm) from the official image, same Debian release.
COPY --from=node /usr/local/bin/node /usr/local/bin/node
COPY --from=node /usr/local/lib/node_modules /usr/local/lib/node_modules
RUN ln -s ../lib/node_modules/npm/bin/npm-cli.js /usr/local/bin/npm \
 && ln -s ../lib/node_modules/npm/bin/npx-cli.js /usr/local/bin/npx \
 && node --version | grep -q '^v22\.'

# @aig/sdk (built dist from sdk/typescript, packed at exactly AIG_SDK_VERSION) + Claude Code CLI.
COPY sdk/typescript /tmp/aig-sdk-ts
RUN --mount=type=secret,id=npmrc,required=false \
    set -eu; \
    if [ -s /run/secrets/npmrc ]; then cp /run/secrets/npmrc /root/.npmrc; fi; \
    test -d /tmp/aig-sdk-ts/dist || { echo "build sdk/typescript first (npm run build)"; exit 1; }; \
    cd /tmp/aig-sdk-ts; \
    test "$(node -p 'require("./package.json").version')" = "${AIG_SDK_VERSION}"; \
    npm pack --silent --pack-destination /tmp >/dev/null; \
    npm install -g --no-audit --no-fund "/tmp/aig-sdk-${AIG_SDK_VERSION}.tgz" "@anthropic-ai/claude-code@${CLAUDE_CODE_VERSION}"; \
    npm cache clean --force; rm -rf /tmp/aig-sdk-ts /tmp/*.tgz /root/.npmrc /root/.npm; \
    claude --version | grep -q "${CLAUDE_CODE_VERSION}"

COPY --from=build /opt/aig/venv /opt/aig/venv

RUN useradd --uid 10001 --create-home --home-dir /home/aig --shell /usr/sbin/nologin aig \
 && mkdir -p /workspace && chown aig:aig /workspace

ENV PATH=/opt/aig/venv/bin:/usr/local/bin:/usr/bin:/bin \
    PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    NPM_CONFIG_UPDATE_NOTIFIER=false \
    HOME=/home/aig \
    AIG_ENV=workspace \
    AIG_HOST=ecs \
    AIG_PORTKEY_CONFIG=pc-aig-router \
    AIG_WS_WORKDIR=/workspace \
    DISABLE_AUTOUPDATER=1 \
    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1

# Build-time self-check: the starter pack and the job import, the pinned SDK version is present.
RUN python -c "import aig_sdk, workspace_orchestrator.job, claude_agent_sdk; assert aig_sdk.__version__ == '${AIG_SDK_VERSION}'" \
 && aig --help >/dev/null && git --version >/dev/null

USER 10001
WORKDIR /workspace
ENTRYPOINT ["/usr/bin/tini", "--", "workspace-job"]
