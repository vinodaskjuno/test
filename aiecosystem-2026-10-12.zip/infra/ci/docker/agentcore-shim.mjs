// AIG AgentCore entrypoint for Node agents (baked into images built from agent-node.Dockerfile).
//
// Bedrock AgentCore runtime contract: listen on 0.0.0.0:8080, serve GET /ping and POST /invocations.
// The serving itself is `@aig/sdk/serve` (AIG invocation contract aig-http/1,
// backend/contracts/agent-invocation.md): caller-token verification (header
// X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller or the body's aig_context), input validation
// against aig-agent.yaml, JSON or SSE answers, GET /schema, caller fields in the Portkey metadata.
// The legacy body {"prompt": "..."} (deploy smoke test, pre-contract callers; AgentCore authorises
// them with IAM) is still accepted.
// Start-up (fail closed, exit 1 on any failure):
//   1. AIG_RUNTIME_SECRET_ARN set: read that Secrets Manager JSON secret and copy ONLY
//      AIG_PORTKEY_API_KEY, AIG_FIDDLER_API_KEY and AIG_PLATFORM_API_TOKEN into process.env
//      (values never logged).
//   2. `init()` from @aig/sdk (fail-closed checks).
//   3. Import AIG_AGENT_ENTRYPOINT ("<path relative to /app>#<export>", e.g. "dist/agent.js#handler"):
//      a handler marked with `invocationHandler()` from @aig/sdk/serve (takes an Invocation, may
//      stream), or a legacy `(prompt: string) => string` function (gets invocation.prompt).
//   4. Serve it with `@aig/sdk/serve` on PORT / AIG_SERVE_PORT (8080); the descriptor is
//      aig-agent.yaml next to this file (<app>/.aig/) or in the app directory.
// `node agentcore-shim.mjs --self-check` (infra/ci/image-check; no network, no secrets) checks that
// @aig/sdk and @aig/sdk/serve load, init exists, the descriptor loads and the entrypoint resolves;
// prints JSON.
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const SECRET_KEYS = ["AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY", "AIG_PLATFORM_API_TOKEN"]; // gitleaks:allow (names)
const DESCRIPTOR = "aig-agent.yaml";
// The image copies this file to <app>/.aig/, so bare imports ("@aig/sdk") resolve through the
// agent's own node_modules with ESM resolution: the shim and the agent share ONE @aig/sdk instance
// (init() here is the runtime the agent's calls use).
const APP_DIR = process.env.AIG_APP_DIR || dirname(dirname(fileURLToPath(import.meta.url)));

async function importFromApp(specifier) {
  return import(specifier);
}

export async function loadRuntimeSecret(env = process.env, client = undefined) {
  const arn = env.AIG_RUNTIME_SECRET_ARN;
  if (!arn) return [];
  let sm = client;
  if (!sm) {
    const { SecretsManagerClient, GetSecretValueCommand } = await importFromApp("@aws-sdk/client-secrets-manager");
    const c = new SecretsManagerClient({});
    sm = { getSecretValue: (id) => c.send(new GetSecretValueCommand({ SecretId: id })) };
  }
  const resp = await sm.getSecretValue(arn);
  const data = JSON.parse(resp.SecretString || "{}");
  if (data === null || typeof data !== "object" || Array.isArray(data)) throw new Error("AIG_RUNTIME_SECRET_ARN must hold a JSON object");
  const loaded = [];
  for (const key of SECRET_KEYS) {
    if (typeof data[key] === "string" && data[key]) {
      env[key] = data[key];
      loaded.push(key);
    }
  }
  return loaded;
}

export async function resolveEntrypoint(spec) {
  const [file, name] = (spec || "").split("#");
  if (!file || !name) throw new Error(`AIG_AGENT_ENTRYPOINT must be '<file>#<export>', got '${spec}'`);
  const mod = await import(pathToFileURL(join(APP_DIR, file)).href);
  if (typeof mod[name] !== "function") throw new Error(`${spec} is not a function`);
  return mod[name];
}

/** Prompt of a legacy body (kept for callers of the pre-contract shim API). */
export function extractPrompt(payload) {
  if (typeof payload === "string") return payload;
  if (payload && typeof payload === "object") {
    for (const key of ["prompt", "input", "question", "message"]) if (typeof payload[key] === "string") return payload[key];
  }
  throw new Error('request body must be {"prompt": "..."}');
}

/** aig-agent.yaml next to the shim (<app>/.aig/ in the image), else in the app directory. */
export function findDescriptor(here = dirname(fileURLToPath(import.meta.url)), appDir = APP_DIR) {
  for (const candidate of [join(here, DESCRIPTOR), join(appDir, DESCRIPTOR)]) if (existsSync(candidate)) return candidate;
  return undefined;
}

/** The @aig/sdk/serve AgentApp for an entrypoint (legacy {"prompt"} bodies accepted). */
export async function makeApp(entry, options = {}, serveModule = undefined) {
  const s = serveModule ?? (await importFromApp("@aig/sdk/serve"));
  const handler = s.isInvocationHandler(entry) ? entry : s.legacyHandler(entry);
  const descriptor = options.descriptor ?? findDescriptor() ?? {};
  return new s.AgentApp(handler, { ...options, descriptor, allowLegacyPrompt: true });
}

async function selfCheck() {
  const sdk = await importFromApp("@aig/sdk");
  const serveModule = await importFromApp("@aig/sdk/serve");
  const pkg = JSON.parse(readFileSync(join(APP_DIR, "node_modules", "@aig", "sdk", "package.json"), "utf8"));
  const descriptorPath = findDescriptor();
  const descriptor = descriptorPath ? serveModule.loadDescriptor(descriptorPath) : undefined;
  await resolveEntrypoint(process.env.AIG_AGENT_ENTRYPOINT);
  const ok = typeof sdk.init === "function" && typeof serveModule.serve === "function";
  return {
    ok,
    sdk: pkg.version,
    init: typeof sdk.init === "function",
    serve: typeof serveModule.serve === "function",
    descriptor: descriptor ? String(descriptor.name ?? DESCRIPTOR) : null,
    entrypoint: process.env.AIG_AGENT_ENTRYPOINT,
  };
}

async function main(argv) {
  if (argv.includes("--self-check")) {
    let result;
    try {
      result = await selfCheck();
    } catch (e) {
      result = { ok: false, error: `${e?.name}: ${e?.message}` };
    }
    console.log(JSON.stringify(result));
    return result.ok ? 0 : 1;
  }

  const sdk = await importFromApp("@aig/sdk");
  let app;
  let serveModule;
  try {
    const loaded = await loadRuntimeSecret();
    console.log(`runtime secret: ${loaded.join(", ") || "not used"}`);
    await sdk.init();
    serveModule = await importFromApp("@aig/sdk/serve");
    app = await makeApp(await resolveEntrypoint(process.env.AIG_AGENT_ENTRYPOINT), {}, serveModule);
  } catch (e) {
    console.error(`refusing to start: ${e?.message}${e?.remediation ? `\n  fix: ${e.remediation}` : ""}`);
    return 1;
  }
  const server = await serveModule.serve(app, {
    host: "0.0.0.0",
    port: Number(process.env.PORT || process.env.AIG_SERVE_PORT || 8080),
    handleSignals: false,
  });
  const stop = () => server.close(async () => { await sdk.shutdown?.(); process.exit(0); });
  process.on("SIGTERM", stop);
  process.on("SIGINT", stop);
  return undefined;
}

if (import.meta.url === pathToFileURL(process.argv[1] || "").href) {
  const code = await main(process.argv.slice(2));
  if (code !== undefined) process.exit(code);
}
