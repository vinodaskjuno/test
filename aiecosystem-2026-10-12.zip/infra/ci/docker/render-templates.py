#!/usr/bin/env python3
"""Write sdk/templates/<name>/Dockerfile from the hardened templates in infra/ci/docker/.

    python3 infra/ci/docker/render-templates.py           # (re)write the template Dockerfiles
    python3 infra/ci/docker/render-templates.py --check   # exit 1 if one is stale (run by the tests)

Each template's Dockerfile is the infra/ci/docker/agent-<language>.Dockerfile with the template's ARG
defaults (SDK extra, entrypoint) and the pinned SDK version (infra/ci/image-check/pins.json) filled in, so
`docker build` works in the template and in every project `aig init` scaffolds from it (aig init
replaces the sample package name in the Dockerfile too). Edit infra/ci/docker/*.Dockerfile, not the copies.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PINS = json.loads((ROOT / "infra/ci/image-check/pins.json").read_text())

TEMPLATES = {
    "langgraph-py": {
        "language": "python",
        "args": {"AIG_SDK_EXTRA": "langgraph", "AGENT_ENTRYPOINT": "aig_langgraph_starter.agent:handler"},
    },
    "strands-py": {
        "language": "python",
        "args": {"AIG_SDK_EXTRA": "strands", "AGENT_ENTRYPOINT": "aig_strands_starter.agent:handler"},
    },
    "langgraph-ts": {
        "language": "node",
        "args": {"AGENT_ENTRYPOINT": "dist/agent.js#handler", "AGENT_SOURCES": '"src/agent.ts"'},
    },
}

DOCKERIGNORE = """# Build context hygiene for the AIG agent image (infra/ci/docker). Secrets and local state never enter
# the image: .env files, virtualenvs, node_modules (reinstalled inside), tests and caches.
.env
.env.*
**/.env
**/.env.*
*.pem
*.key
.venv
venv
node_modules
dist
**/__pycache__
**/*.pyc
*.egg-info
**/*.egg-info
.pytest_cache
.ruff_cache
.mypy_cache
coverage
test
tests
.git
.gitignore
.dockerignore
Dockerfile
README.md
"""


def render(name: str) -> str:
    spec = TEMPLATES[name]
    src_name = f"agent-{spec['language']}.Dockerfile"
    text = (ROOT / "infra/ci/docker" / src_name).read_text()
    sdk_key = "aig-sdk" if spec["language"] == "python" else "@aig/sdk"
    args = {**spec["args"], "AIG_SDK_VERSION": PINS["sdk"][sdk_key]}
    for arg, value in args.items():
        text, n = re.subn(rf"^ARG {arg}=.*$", f"ARG {arg}={value}", text, flags=re.M)
        if n == 0:
            raise SystemExit(f"infra/ci/docker/{src_name} has no 'ARG {arg}=' line")
    lines = text.splitlines(keepends=True)
    syntax = lines[0] if lines[0].startswith("# syntax=") else ""
    body = "".join(lines[1:] if syntax else lines)
    header = (
        f"# GENERATED from infra/ci/docker/{src_name} by infra/ci/docker/render-templates.py - edit that file instead.\n"
        f"# Template: sdk/templates/{name}. Build from the agent directory (see the build notes below):\n"
        f"#   docker buildx build --platform linux/arm64 --build-context aigci=<aig-repo>/infra/ci/docker -t <image> .\n"
    )
    return syntax + header + body


def main(argv: list[str]) -> int:
    check = "--check" in argv
    stale = []
    for name in TEMPLATES:
        for target, content in ((ROOT / "sdk" / "templates" / name / "Dockerfile", render(name)),
                                (ROOT / "sdk" / "templates" / name / ".dockerignore", DOCKERIGNORE)):
            current = target.read_text() if target.exists() else None
            if current == content:
                continue
            if check:
                stale.append(str(target.relative_to(ROOT)))
            else:
                target.write_text(content)
                print(f"wrote {target.relative_to(ROOT)}")
    if stale:
        print("stale (run python3 infra/ci/docker/render-templates.py): " + ", ".join(stale), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
