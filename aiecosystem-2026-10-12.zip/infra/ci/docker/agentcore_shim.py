"""AIG AgentCore entrypoint for Python agents (baked into images built from agent-python.Dockerfile).

Bedrock AgentCore runtime contract: the container listens on 0.0.0.0:8080 and serves ``GET /ping``
(health) and ``POST /invocations``. The serving itself is ``aig_sdk.serve`` (the AIG invocation
contract ``aig-http/1``, backend/contracts/agent-invocation.md): caller-token verification (header
``X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-Caller`` or the body's ``aig_context``), input
validation against ``aig-agent.yaml``, JSON or SSE answers, ``GET /schema``, caller fields in the
Portkey metadata. The legacy body ``{"prompt": "..."}`` (deploy smoke test, pre-contract callers;
AgentCore authorises those with IAM) is still accepted.

Start-up, in order (fail closed: any failure exits non-zero, so AgentCore never routes traffic to an
agent that cannot reach Portkey and Fiddler):

1. ``AIG_RUNTIME_SECRET_ARN`` set (infra/terraform/modules/agentcore-runtime): read that Secrets
   Manager JSON secret and put ONLY the allowed keys (``AIG_PORTKEY_API_KEY``,
   ``AIG_FIDDLER_API_KEY``, ``AIG_PLATFORM_API_TOKEN``) into this process's environment. Values are
   never logged. AgentCore itself has no secret injection, so this is how runtimes get the scoped
   Portkey key from secrets.
2. ``aig_sdk.init()``: the SDK's fail-closed checks (raw provider keys, Portkey, Fiddler, registry).
3. Import ``AIG_AGENT_ENTRYPOINT`` (``package.module:function``): a handler marked with
   ``aig_sdk.serve.invocation_handler`` (takes an ``Invocation``, may stream), or a legacy
   ``str -> str`` callable (gets ``invocation.prompt``).
4. Serve it with ``aig_sdk.serve`` on ``PORT`` / ``AIG_SERVE_PORT`` (8080); the descriptor is
   ``aig-agent.yaml`` next to this file (the image copies it to /opt/aig/) or in the working directory.

``python agentcore_shim.py --self-check`` (used by infra/ci/image-check, no network, no secrets) verifies
that aig_sdk and aig_sdk.serve import, ``init`` exists, the descriptor loads and the entrypoint resolves;
it prints JSON.
"""

from __future__ import annotations

import importlib
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Callable

SECRET_KEYS = ("AIG_PORTKEY_API_KEY", "AIG_FIDDLER_API_KEY", "AIG_PLATFORM_API_TOKEN")  # gitleaks:allow (names)
DESCRIPTOR = "aig-agent.yaml"
log = logging.getLogger("aig.agentcore")


def load_runtime_secret(environ: dict[str, str] | None = None, client: Any = None) -> list[str]:
    """Copy the allowed keys of the JSON secret ``AIG_RUNTIME_SECRET_ARN`` into ``environ``.

    Returns the names that were set (never the values)."""
    environ = os.environ if environ is None else environ  # type: ignore[assignment]
    arn = environ.get("AIG_RUNTIME_SECRET_ARN")
    if not arn:
        return []
    if client is None:
        import boto3  # installed into agent images by agent-python.Dockerfile

        client = boto3.client("secretsmanager")
    data = json.loads(client.get_secret_value(SecretId=arn).get("SecretString") or "{}")
    if not isinstance(data, dict):
        raise ValueError("AIG_RUNTIME_SECRET_ARN must hold a JSON object")
    loaded = []
    for key in SECRET_KEYS:
        value = data.get(key)
        if isinstance(value, str) and value:
            environ[key] = value
            loaded.append(key)
    return loaded


def resolve_entrypoint(spec: str) -> Callable[..., Any]:
    module_name, _, attr = spec.partition(":")
    if not module_name or not attr:
        raise ValueError(f"AIG_AGENT_ENTRYPOINT must be 'package.module:function', got {spec!r}")
    fn = getattr(importlib.import_module(module_name), attr)
    if not callable(fn):
        raise TypeError(f"{spec} is not callable")
    return fn


def extract_prompt(payload: Any) -> str:
    """Prompt of a legacy body (kept for callers of the pre-contract shim API)."""
    if isinstance(payload, str):
        return payload
    if isinstance(payload, dict):
        for key in ("prompt", "input", "question", "message"):
            if isinstance(payload.get(key), str):
                return payload[key]
    raise ValueError('request body must be {"prompt": "..."}')


def find_descriptor(here: Path | None = None) -> Path | None:
    """``aig-agent.yaml`` next to the shim (/opt/aig in the image), else in the working directory."""
    for candidate in ((here or Path(__file__).resolve().parent) / DESCRIPTOR, Path.cwd() / DESCRIPTOR):
        if candidate.is_file():
            return candidate
    return None


def make_app(entry: Callable[..., Any], *, descriptor: Any = None, **options: Any):
    """The ``aig_sdk.serve.AgentApp`` for an entrypoint (legacy ``{"prompt"}`` bodies accepted)."""
    from aig_sdk.serve import AgentApp, is_invocation_handler, legacy_handler

    if isinstance(entry, AgentApp):
        entry.allow_legacy_prompt = True
        return entry
    handler = entry if is_invocation_handler(entry) else legacy_handler(entry)
    if descriptor is None:
        descriptor = find_descriptor()
    return AgentApp(handler, descriptor=descriptor if descriptor is not None else {}, allow_legacy_prompt=True, **options)


def self_check() -> dict[str, Any]:
    result: dict[str, Any] = {"ok": False, "sdk": None, "init": False, "serve": False, "descriptor": None, "entrypoint": None}
    import aig_sdk

    result["sdk"] = getattr(aig_sdk, "__version__", None)
    result["init"] = callable(getattr(aig_sdk, "init", None))
    from aig_sdk.serve import load_descriptor, serve

    result["serve"] = callable(serve)
    path = find_descriptor()
    if path is not None:
        result["descriptor"] = str(load_descriptor(path).get("name") or path.name)
    spec = os.environ.get("AIG_AGENT_ENTRYPOINT", "")
    resolve_entrypoint(spec)
    result["entrypoint"] = spec
    result["ok"] = bool(result["init"] and result["serve"])
    return result


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    logging.basicConfig(level=os.environ.get("AIG_LOG_LEVEL", "INFO"), format="%(levelname)s %(name)s %(message)s")
    if "--self-check" in argv:
        try:
            result = self_check()
        except Exception as exc:  # noqa: BLE001
            result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        print(json.dumps(result))
        return 0 if result.get("ok") else 1

    import aig_sdk

    try:
        loaded = load_runtime_secret()
        log.info("runtime secret: %s", ", ".join(loaded) or "not used")
        aig_sdk.init()
        app = make_app(resolve_entrypoint(os.environ.get("AIG_AGENT_ENTRYPOINT", "")))
    except aig_sdk.AigStartupError as exc:
        print(f"refusing to start: {exc}\n  fix: {exc.remediation}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001
        print(f"refusing to start: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    from aig_sdk.serve import serve

    port = int(os.environ.get("PORT") or os.environ.get("AIG_SERVE_PORT") or "8080")
    try:
        return serve(app, host="0.0.0.0", port=port)  # noqa: S104 (AgentCore contract)
    finally:
        aig_sdk.shutdown()


if __name__ == "__main__":
    raise SystemExit(main())
