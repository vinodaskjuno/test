# Contributing

## Secrets

Real keys (Portkey, Fiddler, and so on) live in exactly two places, and only
`backend/platform-api` reads them:

- **Local / manual upload:** `backend/platform-api/secrets/.env.<env>`
  (for example `secrets/.env.dev`), created by copying the matching
  `secrets/<env>.env.example` template and replacing each
  `__REPLACE_ME_<NAME>__` value. Everything in `secrets/` except the
  `*.env.example` templates is gitignored.
- **Deployed environments:** AWS Secrets Manager secret
  `aig/<env>/platform-api` (run with `AIG_SECRET_PROVIDER=aws`).

Rules:

- Never commit a real key, `.env` file, private key, or `config/users.yaml`.
  Templates contain placeholders only.
- Clients (the VS Code extension and other apps) never hold a Portkey key.
  They sign in with Entra ID and call the platform API.
- If a key is ever committed, treat it as leaked: rotate it first, then
  remove it from history.

Set up the pre-commit hooks once per clone (they run gitleaks on every commit):

```sh
pip install pre-commit
pre-commit install
```

Scan manually at any time (uses `.gitleaks.toml` at the repo root):

```sh
gitleaks detect --source . --config .gitleaks.toml             # git history
gitleaks detect --no-git --source . --config .gitleaks.toml    # working tree
```
