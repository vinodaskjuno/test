# Deployment (Phase 5, Phase 6 workspaces): AgentCore agents and the platform on AWS

How AIG agents and the platform services get to AWS, and how to run them there. The code is in
[`infra/terraform`](../infra/terraform) (Terraform), [`infra/ci/`](../infra/ci) (image check, hardened
images) and `.github/workflows/deploy-*.yml`. Status: **validated offline only**. Nothing has been
applied to a real AWS account yet (see [PROGRESS](PROGRESS.md), Phase 5).

## 1. Architecture

```
                      corporate network / VPN                      self-hosted Portkey      Fiddler
                              |                                      (gateway, MCP, admin)   (REST, OTLP)
                              v                                              ^                   ^
 VPC aig-<env> ---------------------------------------------------------------|-------------------|----
 | private subnets (no public IPs)                                            | HTTPS only        |     |
 |                                                                            | (egress prefix list)    |
 |  [ALB public*] --> web (nginx)          platform-api  --+--> RDS Postgres  |                   |     |
 |        \-------> platform-api  ------------------------/    (encrypted,    |                   |     |
 |  [ALB internal] -> telemetry-bridge (+ daily reconcile) -/    managed pwd)  |                   |     |
 |                \-> cache-compress  <---- Portkey gateway (custom_host)     |                   |     |
 |                                                                            |                   |     |
 |  AgentCore runtimes (VPC mode): agent containers ---------------------------+-------------------+     |
 |                                                                                                      |
 |  Phase 6 (cluster aig-<env>-workspaces, when `workspaces` is set):                                   |
 |    [ALB public*] host teams_bot_hostname -> teams-bot (/api/messages; /api/notify = 403)             |
 |    workspace-orchestrator (1 task) --RunTask--> workspace task per request (team task definition)    |
 |    workspace task --> [relay ALB, internal HTTPS] --> orchestrator relay                             |
 |                   --> Portkey, Fiddler, GitHub + package mirror only (own SG, no ingress)            |
 |    orchestrator --Cloud Map, HMAC--> teams-bot /api/notify                                           |
 |  VPC endpoints: ECR (api, dkr), S3 (gateway), Logs, Secrets Manager, STS, KMS, Monitoring, X-Ray, SSM |
 |  [optional] AWS Network Firewall (domain allow-list, default drop) on the NAT path                   |
 -------------------------------------------------------------------------------------------------------
   * internal by default (alb_internal = true)
```

- **Agents** run on **Bedrock AgentCore** (`aws_bedrockagentcore_agent_runtime`), one runtime per
  agent per env. The image is pinned by digest and the runtime runs in VPC mode in the private
  subnets with the egress allow-list security group. It gets the non-secret `AIG_*` variables as
  runtime environment, plus `AIG_RUNTIME_SECRET_ARN` for its secret. Its role is least-privilege:
  no Bedrock model access, because models are reached only through Portkey.
- **Platform services** (platform-api, telemetry-bridge, cache-compress, web) run on **ECS Fargate
  (ARM64)** behind two HTTPS ALBs. RDS Postgres backs platform-api and the bridge. An EventBridge
  Scheduler task runs `telemetry-bridge reconcile` daily, and another runs
  `aig-platform-api invocations purge` daily (`cron(30 3 * * ? *)` UTC, `invocation_purge_schedule`):
  it deletes agent invocation metadata older than `agent_invocation_retention_days` (90) and
  background outputs older than `agent_output_retention_days` (30). Same image, environment and
  database secrets as the platform-api service, only the command differs; `invocation_purge_enabled =
  false` removes the task, the schedule and its alarm.
- **Team workspaces (Phase 6)** run on a separate ECS cluster (`modules/workspaces`). The
  orchestrator service starts one Fargate task per request from the team's task definition, and the
  Teams bot service sits behind the portal/API ALB. Details:
  [infra/terraform/README.md](../infra/terraform/README.md#workspaces) and
  [workspaces.md](workspaces.md).
- **Secrets** are in Secrets Manager, under one KMS key per env. They are created by Terraform with
  placeholders only and filled by hand ([section 4](#4-secrets-upload-manual-key-broker-design)).
- **Images** are in ECR with immutable tags, scan on push and KMS. Every image passes
  [`infra/ci/image-check`](../infra/ci/README.md) before any environment runs it.

## 2. Environments and promotion

| | dev | stage | prod |
|---|---|---|---|
| Terraform root | `infra/terraform/envs/dev` | `envs/stage` | `envs/prod` |
| Agent stacks | `stacks/agent-runtime`, state `aig/dev/agents/<id>.tfstate` | `aig/stage/agents/<id>.tfstate` | `aig/prod/agents/<id>.tfstate` |
| Secrets | `aig/dev/platform-api`, `aig/dev/telemetry-bridge`, `aig/dev/deploy-pipeline`, `aig/dev/agents/<id>` (+ `aig/dev/agents/<id>/invoke-auth` for HTTPS agents); with workspaces also `aig/dev/workspace-orchestrator`, `aig/dev/teams-bot`, `aig/dev/workspaces/shared`, `aig/dev/workspaces/<team>` | `aig/stage/...` | `aig/prod/...` |
| Egress (tfvars example) | `cidr` | `cidr` | `firewall` |
| GitHub environment | `dev` | `stage` | `prod` (**required reviewers**) |

**Promotion by immutable digest.** The deploy workflows build once and push to ECR with immutable
tags, and capture the digest. Every later step uses `<repo>@sha256:<digest>`. Terraform rejects
tags (`image_uri` / `images` validation), so stage and prod run exactly the bytes that passed the
image check and dev.

### deploy-agent.yml

`build` (linux/arm64, SBOM + provenance) -> `image-check` (agent profile) -> `dev` (terraform
plan/apply + smoke invocation) -> `stage` (apply + smoke) -> `stage-evals` (the evals gate,
`evals-gate.yml`, `aig-env: stage`) -> **manual approval** (`prod` environment) -> `prod`.

Reusable (`workflow_call`) for agent repos, and runnable by hand (`workflow_dispatch`, e.g.
`sdk/templates/langgraph-py`). Each env deploy is `deploy-agent-env.yml`:
1. init with the agent's state key
2. write `agent.auto.tfvars.json` (env, agent id, team, digest, tier, job profile)
3. `terraform plan -out` then `terraform apply` of that plan
4. smoke: `aws bedrock-agentcore invoke-agent-runtime --qualifier live` with a prompt, expecting an
   `output` back (the legacy `{"prompt": ...}` body, which the AgentCore shims still accept)
5. **auto-registration** with platform-api (below), then platform-api's verification

### Auto-registration (agent registry)

After a successful smoke test, `deploy-agent-env.yml` registers the deployed version with
platform-api (`scripts/register-agent-version.py`, standard library only, tested against a mock
platform-api in `scripts/tests/`):

| Field | Value |
|---|---|
| `POST /api/v1/agents/{agent_id}/versions` | service token (`x-aig-service-token`) |
| `env`, `kind` | the deploy env, `agentcore` |
| `runtime_arn`, `qualifier` | Terraform outputs `agent_runtime_arn`, `endpoint_name` (`live`) |
| `version` | `sha-<git sha 12>-<image digest 12>` (plus `git_sha`, `image_digest`) |
| `protocol` | `aig-http/1` |
| `input_schema`, `output_schema` | from the agent's `aig-agent.yaml` (input `agent-dir`; converted with `yq -o=json`) |
| `verified` | `true` when the smoke test ran and passed |
| `activate` | `true` on **prod** with a verified registration: the agent's lifecycle becomes `active` (platform-api accepts `activate` only from the service token, with `env=prod` and `verified=true`; the owner-only `POST .../lifecycle` is not used by the pipeline) |

It is idempotent (a re-run replaces the same env + version: HTTP 200 instead of 201), retries
connection errors / 429 / 502 / 503 / 504 with backoff, and fails at once with platform-api's error
code otherwise (`agent_not_found`: register the agent first with `aig init` or the portal). Then it
calls `POST .../versions/{version}/verify?env=<env>` (health, test invocation through AgentCore, gateway
agent-check, trace check) and prints every check. Workflow inputs: `register` (default `true`),
`verify` (`require` = fail the deploy when verification does not pass, `warn`, `skip`), `agent-dir`
(passed through by `deploy-agent.yml`). Output: `registered-version`.

Configuration per GitHub environment:
- `AIG_PLATFORM_API_URL`: platform-api base URL of that env (required while `register` is on)
- `AIG_PLATFORM_SERVICE_TOKEN_SECRET_ID` (optional): Secrets Manager secret holding
  `{"PLATFORM_SERVICE_TOKEN": "..."}`, default `aig/<env>/deploy-pipeline` (created by
  `modules/secrets`; upload the same value as platform-api's `PLATFORM_SERVICE_TOKEN`). The deploy role
  needs `secretsmanager:GetSecretValue` on it (and `kms:Decrypt` via Secrets Manager); it never reads
  `aig/<env>/platform-api`. The token is masked in the log and never printed.

Locally: `AIG_PLATFORM_SERVICE_TOKEN=... scripts/register-agent-version.py --api-url ... --agent-id ...
--env dev --runtime-arn ... --image ...@sha256:... --git-sha ... --descriptor aig-agent.yaml --verified`
(`--dry-run` prints the request body).

For platform-api to invoke the runtime, its task role has `bedrock-agentcore:InvokeAgentRuntime` on
this env's runtimes tagged `aig:registered=true` (set by `modules/agentcore-runtime`, opt out with
`registry_invocable = false`), and the runtime allow-lists the three `X-Amzn-Bedrock-AgentCore-Runtime-Custom-Aig-*`
headers. A runtime with a `jwt_authorizer` only accepts JWT callers, so platform-api (SigV4) cannot
invoke it.

### deploy-platform.yml

`build` (7 images in a matrix: the 4 platform services plus `workspace` (linux/amd64, built on an
x64 runner after `sdk/typescript` is built), `workspace-orchestrator` and `teams-bot` (linux/arm64))
-> `image-check` x7 (service profile; the workspace image is checked on x64) -> `dev` -> `stage`
-> **manual approval** -> `prod`. Each env (`deploy-platform-env.yml`) gets all seven digests. It
writes `platform_images` and `workspace_images`. The workspace images create resources only in envs
whose tfvars set `workspaces`. Each env runs these steps in order:
1. targeted apply of the `platform-api-migrate` task definition with the new image
2. `aws ecs run-task` with `aig-platform-api db upgrade`, which must exit 0. If it fails, the
   rollout stops before any service changes
3. full `terraform apply`: rolling deployment, `wait_for_steady_state`, deployment circuit breaker
   with automatic rollback
4. smoke: `aws ecs wait services-stable` and every ALB target `healthy` on `/healthz`, checked
   through the AWS API because the ALBs are internal
5. smoke (workspaces, when enabled): the same checks for `workspace-orchestrator` (relay target
   group) and `teams-bot` in `aig-<env>-workspaces`. Workspace tasks themselves are not started by
   the deploy

### GitHub setup (once)

- **Repository variables**:
  - `AWS_REGION`
  - `ECR_REGISTRY` (`<acct>.dkr.ecr.<region>.amazonaws.com`)
  - `AWS_ECR_PUSH_ROLE_ARN`
- **Environments** `dev`, `stage`, `prod`, each with these variables:
  - `AWS_ACCOUNT_ID`
  - `AWS_DEPLOY_ROLE_ARN`
  - `TF_STATE_BUCKET`
  - `TF_LOCK_TABLE`
  - `TF_VARS_S3_URI` (`s3://<bucket>/aig/<env>/terraform.tfvars.json`: the env's non-secret
    tfvars, same shape as `terraform.tfvars.example`)

  Give `prod` required reviewers, and restrict it to `main`.
- **IAM roles**: trust `token.actions.githubusercontent.com` with
  `sub = repo:<org>/aiecosystem:environment:<env>` (deploy roles) or `...:ref:refs/heads/main`
  (ECR push). There are **no long-lived AWS keys** anywhere.
- **Eval secrets** for the stage evals gate (`AIG_EVAL_PORTKEY_API_KEY`, `AIG_EVAL_FIDDLER_API_KEY`,
  `AIG_EVAL_PLATFORM_API_TOKEN`): environment secrets of the calling repo. These are a scoped CI
  key, never a provider key.

## 3. Egress allow-list

Enforcement table: "Egress allow-list ... VPC rules (Phase 5 infra for cloud)". Traffic is denied
by default. What is allowed:

| From | To | How |
|---|---|---|
| AgentCore runtimes, ECS tasks | Portkey gateway / MCP / admin (443) | managed prefix list `aig-<env>-egress-allow` (`portkey_egress_cidrs`) |
| AgentCore runtimes, ECS tasks | Fiddler REST + OTLP (443) | same prefix list (`fiddler_egress_cidrs`) |
| AgentCore runtimes, ECS tasks | ECR, Logs, Secrets Manager, STS, KMS, CloudWatch, X-Ray, SSM | interface VPC endpoints (private DNS) |
| AgentCore runtimes, ECS tasks | S3 (ECR layers) | gateway endpoint prefix list |
| platform-api, telemetry-bridge, cache-compress (firewall mode only) | `egress_allowed_domains` (Entra ID JWKS, provider APIs for cache-compress, Slack, PagerDuty) | `internet-via-firewall` SG + AWS Network Firewall domain allow-list, default `drop_established` |
| Workspace tasks (Phase 6) | Portkey, Fiddler (443) | own `workspace-tasks` SG -> egress prefix list. No ingress, no `0.0.0.0/0` rule |
| Workspace tasks | GitHub / GHES and the package mirror (443) | `workspace-egress-allow` prefix list (`workspaces.github_egress_cidrs`, `package_mirror_egress_cidrs`). Only the workspace SG uses it. In firewall mode `github.com` and `api.github.com` are also added to the domain allow-list |
| Workspace tasks | orchestrator relay (443) | relay ALB SG (internal HTTPS ALB, ingress from the workspace SG only) |
| Workspace tasks | ECR, Logs, Secrets Manager; S3 layers | VPC endpoints, S3 gateway prefix list |
| workspace-orchestrator | platform-api, ECS API, teams-bot `/api/notify` | portal/API ALB SG (443), `ecs` VPC endpoint (shared allow-list SG), bot SG (3978) |
| teams-bot (firewall mode) | Bot Framework / Entra ID hosts (`teams_bot_egress_domains`) | `internet-via-firewall` SG + domain allow-list. In `cidr` mode the bot needs an egress proxy (`additional_egress_cidrs`) |
| everything else | anything | **denied** (no SG rule; in firewall mode also dropped and alerted) |

AgentCore runtimes **never** get the internet-via-firewall group. To allow a new destination for
an agent, add its CIDR to `portkey_egress_cidrs` / `fiddler_egress_cidrs` /
`additional_egress_cidrs` in the env's tfvars, and get network/security approval in the same PR.
`0.0.0.0/0` is rejected by validation. VPC flow logs record every flow.

In `cidr` mode, platform-api needs a route to Entra ID for OIDC JWKS. Either use `firewall` mode,
or add the corporate egress proxy CIDR to `additional_egress_cidrs`.

## 4. Secrets upload (manual, key-broker design)

Keys live only in Portkey and in the platform-api key broker (IMPLEMENTATION_PLAN.md, Phase 4).
Terraform creates each secret with **placeholders** (`__REPLACE_ME_<KEY>_<ENV>__`) and never reads
or writes its value again. Every service treats placeholders as "not configured" and fails closed:
- platform-api refuses to start outside `local`
- AgentCore agents refuse to start (SDK `init()`)
- the bridge's endpoints answer 503

The platform owner uploads the real values **by hand**, from a workstation with an admin session,
never from CI:

```bash
ENV=dev   # dev | stage | prod

# platform-api key broker (names: backend/platform-api/secrets/<env>.env.example)
aws secretsmanager put-secret-value --secret-id "aig/$ENV/platform-api" \
  --secret-string file://<(jq -n \
    --arg pk "$PORTKEY_API_KEY" --arg pka "$PORTKEY_ADMIN_API_KEY" --arg fk "$FIDDLER_API_KEY" \
    --arg wh "$PORTKEY_WEBHOOK_SECRET" --arg st "$PLATFORM_SERVICE_TOKEN" --arg bt "$TELEMETRY_BRIDGE_TOKEN" \
    --arg cs "$AGENT_CALLER_SIGNING_KEY" --arg oe "$AGENT_OUTPUT_ENCRYPTION_KEY" \
    '{PORTKEY_API_KEY:$pk, PORTKEY_ADMIN_API_KEY:$pka, FIDDLER_API_KEY:$fk,
      PORTKEY_WEBHOOK_SECRET:$wh, PLATFORM_SERVICE_TOKEN:$st, TELEMETRY_BRIDGE_TOKEN:$bt,
      AGENT_CALLER_SIGNING_KEY:$cs, AGENT_OUTPUT_ENCRYPTION_KEY:$oe}')
# AGENT_CALLER_SIGNING_KEY: EC P-256 private key (PEM, or base64 of it) that signs the agent caller
# token; AGENT_OUTPUT_ENCRYPTION_KEY: Fernet key for background invocation outputs
# (backend/contracts/agent-invocation.md). Without them agent invocation / background runs are off.

# telemetry-bridge (names: backend/telemetry-bridge/.env.example; same token values as above
# where they pair: AIG_PLATFORM_SERVICE_TOKEN = PLATFORM_SERVICE_TOKEN, AIG_BRIDGE_INGEST_TOKEN = TELEMETRY_BRIDGE_TOKEN)
aws secretsmanager put-secret-value --secret-id "aig/$ENV/telemetry-bridge" --secret-string file://bridge.json

# deploy pipeline (agent auto-registration): the same value as platform-api's PLATFORM_SERVICE_TOKEN
aws secretsmanager put-secret-value --secret-id "aig/$ENV/deploy-pipeline" \
  --secret-string file://<(jq -n --arg st "$PLATFORM_SERVICE_TOKEN" '{PLATFORM_SERVICE_TOKEN:$st}')

# one agent (after its first deploy created the secret): scoped Portkey workspace key, Fiddler token,
# platform-api token. Never a provider key.
aws secretsmanager put-secret-value --secret-id "aig/$ENV/agents/<agent_id>" --secret-string file://agent.json

# Phase 6 workspaces (created as soon as `workspaces` is set in the env's tfvars):
#   AIG_PLATFORM_SERVICE_TOKEN = platform-api PLATFORM_SERVICE_TOKEN; AIG_WS_NOTIFY_SECRET = the bot's
#   AIG_BOT_NOTIFY_SECRET; AIG_WS_RELAY_SECRET = a fresh random value (openssl rand -hex 32).
aws secretsmanager put-secret-value --secret-id "aig/$ENV/workspace-orchestrator" --secret-string file://orchestrator.json
aws secretsmanager put-secret-value --secret-id "aig/$ENV/teams-bot" --secret-string file://teams-bot.json   # MicrosoftAppId, MicrosoftAppPassword, AIG_BOT_NOTIFY_SECRET
aws secretsmanager put-secret-value --secret-id "aig/$ENV/workspaces/shared" --secret-string file://ws-shared.json   # fiddler_api_key, github_app_private_key (PEM)
# one per team: that team's scoped Portkey workspace key (never a provider key)
aws secretsmanager put-secret-value --secret-id "aig/$ENV/workspaces/<team>" --secret-string file://ws-team.json    # portkey_api_key
```

Rules:
- Type the values in, or read them from a password manager. Do not keep `bridge.json` or
  `agent.json` around (`shred -u`), and never commit them (`.gitignore` covers `*.env`, `secrets/*`).
- **Every key** in the placeholder JSON must be present, even ones you do not use: ECS fails to
  start a task whose `valueFrom` key is missing. Leave unused optional keys as their placeholder.
- After an upload:
  - ECS: force a new deployment (`aws ecs update-service --force-new-deployment --cluster aig-<env> --service <svc>`;
    the workspace services are in `--cluster aig-<env>-workspaces`, services `workspace-orchestrator` and `teams-bot`).
    New workspace tasks read the team and shared secrets when they start, so they need no restart
  - AgentCore: values are read at session start, so new sessions pick them up
- **Rotation**: put a new version, then restart as above. The previous version stays as
  `AWSPREVIOUS` for rollback. The rotation cadence is still an open item in the plan.
- The RDS master password is managed and rotated by RDS (`manage_master_user_password`). Never
  upload it by hand.
- Checking without seeing values:
  - `aws secretsmanager describe-secret --secret-id aig/$ENV/platform-api` (the `LastChangedDate`)
  - platform-api `GET /healthz` (shows configured, placeholder or missing per key)

## 5. Rollbacks

| What | How |
|---|---|
| Platform service rollout fails health checks | Automatic: the ECS deployment circuit breaker rolls back to the previous task definition. The workflow fails |
| Platform release is bad after it went healthy | Re-run `deploy-platform-env.yml` (or `deploy-platform.yml` from the last good commit) with the **previous digests** (job summaries and ECR list every deployed digest; immutable tags = `<sha>-<attempt>`). Same promotion path, same approvals |
| Migration fails | Nothing was rolled out (the services still run the previous version). Fix forward. Alembic downgrades are deliberately not automated: restore from the RDS automated backup / snapshot if a migration corrupted data |
| Agent release is bad | Re-run `deploy-agent-env.yml` for the env with the previous digest. This creates a new runtime version and repoints the `live` endpoint. Or, for an instant switch, point the `live` endpoint at the previous runtime version (`aws bedrock-agentcore-control update-agent-runtime-endpoint --agent-runtime-version <n>`), then reconcile Terraform with a redeploy of that digest |
| Terraform change breaks an env | Revert the PR, then plan/apply again. State is versioned in S3: restore a previous state object only as a last resort, with the lock held |
| A key leaked | Revoke it in Portkey/Fiddler first, then upload a new value ([section 4](#4-secrets-upload-manual-key-broker-design)) and restart. The reconcile job and Portkey logs show who used it |

## 6. Runbook

**A service will not start.** Check the log group `/aig/<env>/<service>` (CloudWatch). Common causes:
- `portkey_key_not_configured` or a startup error about a placeholder: the secret was not uploaded
  ([section 4](#4-secrets-upload-manual-key-broker-design))
- "schema is not at head": run the migrate task (`deploy-platform-env.yml`, or
  `aws ecs run-task --task-definition aig-<env>-platform-api-migrate ...` with the network settings
  from the `platform.migrate_task` output)
- `ResourceInitializationError: unable to pull secrets`: a JSON key is missing in the secret, or a
  KMS/IAM problem

**An agent will not start or answers 5xx.** Check `/aws/bedrock-agentcore/runtimes/<runtime-id>-live`.
`refusing to start: AIG_E_...` is the SDK's fail-closed check: the code names the cause
(`backend/contracts/errors.md`). A timeout reaching Portkey or Fiddler usually means the egress allow-list
lacks the destination CIDR: check the VPC flow logs (`/aig/aig-<env>/vpc-flow-logs`, `REJECT`) and,
in firewall mode, `/aig/aig-<env>/network-firewall`.

**The alarm topic fires.** The alarms are:
- `aig-<env>-<svc>-cpu-high` / `-memory-high`: scale limits in `service_sizing`
- `<svc>-5xx` / `-unhealthy`: `/healthz` is failing, look at the service logs
- `db-*`: RDS
- `reconcile-failed`: the daily reconciliation did not finish. Run it again by hand:
  `aws ecs run-task --task-definition aig-<env>-telemetry-bridge-reconcile ...`
- `invocation-purge-failed`: the daily invocation retention purge exited non-zero (database
  unreachable, schema not at head, retention variables refused). Check the task log (one JSON line
  with the counts on success), then run it again by hand:
  `aws ecs run-task --task-definition aig-<env>-platform-api-invocation-purge ...` (add
  `--overrides` with `--dry-run` in the command to only count)
- `workspace-orchestrator-down` / `teams-bot-down`: no running task in `aig-<env>-workspaces`. Check
  `/aig/<env>/workspace-orchestrator` or `/aig/<env>/teams-bot`. A config error at start usually
  means a placeholder secret (`AIG_WS_RELAY_SECRET is required`, `AIG_WS_NOTIFY_URLS needs
  AIG_WS_NOTIFY_SECRET`)
- `workspaces-failed`: more failed workspaces than expected in an hour. The orchestrator log says
  why (`-> failed (...)`). The job's own log is the `log_url` on the workspace (`/aig/<env>/workspaces`,
  stream `workspace/workspace/<task id>`). Timeouts reaching GitHub or Portkey mean the workspace
  prefix list or the domain allow-list is missing a destination (VPC flow logs, `REJECT`)

**First rollout of an env.** Set `reconcile_dry_run = true` until the agent registry and Fiddler
data are trusted. Reconciliation then reports without suspending agents.

**Access to a task.** ECS Exec is disabled on purpose (`enable_execute_command = false`). Use logs
and metrics. Enabling Exec temporarily is a reviewed Terraform change.

## 7. What is verified, and what is not

- Verified offline:
  - `terraform validate` and `fmt` on every root, and `terraform test` plans against the mock AWS
    provider (`make infra-validate`)
  - actionlint on every workflow (`make workflows-lint`)
  - image-check logic and the AgentCore shims against fixtures (`make image-check-test`), incl. the
    shims serving `aig-http/1` through `aig_sdk.serve` / `@aig/sdk/serve` and the legacy `{"prompt"}` body
  - the auto-registration script against a mock platform-api (`scripts/tests/`), and the IAM policy
    for agent invocation (tag-scoped, `modules/platform-services` tests)
  - the template Dockerfiles are kept in sync with `infra/ci/docker`
- **Not yet verified:**
  - no apply to a real AWS account
  - no Docker build of the agent templates or the hardened base images (Docker is not available
    locally; CI builds them on `ubuntu-24.04-arm`)
  - base-image digests in `pins.json` are still placeholders
  - auto-registration against a real platform-api from GitHub Actions, and platform-api invoking a
    real AgentCore runtime with the tag-scoped role (AgentCore's support for `aws:ResourceTag`
    conditions on `InvokeAgentRuntime` follows AWS documentation, not a test)
  - AgentCore's log group naming (`<runtime-id>-<endpoint>`), its CLI invoke parameters and the
    `{"prompt": ...}` payload convention follow AWS documentation but have not been run
  - Phase 6 workspaces: none of it has been applied or run. In particular:
    - the workspace, orchestrator and bot images have not been built in CI
    - Fargate copy-up / permissions of the `prepare`-chmodded task volumes
    - the Cloud Map name from the orchestrator to the bot
    - Bot Framework reaching the ALB
    - the GitHub CIDR list
