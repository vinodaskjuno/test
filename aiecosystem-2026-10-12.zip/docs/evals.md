# Evals: `aig eval` and the CI evals gate (Phase 5)

`aig eval` evaluates an agent on its datasets with the Fiddler Evals SDK
([`fiddler-evals`](https://pypi.org/project/fiddler-evals/), Python, pinned `>=0.6,<0.7`),
compares the scores with the last approved baseline, and fails when a score is below its threshold
or has regressed. The reusable workflow [`.github/workflows/evals-gate.yml`](../.github/workflows/evals-gate.yml)
runs it on every pull request that touches an agent, comments the summary and the Fiddler link on
the PR, and blocks the merge when it fails (as a required check).

Status: implemented and tested against fiddler-evals' real runner, with Fiddler's HTTP API faked
(`sdk/python/tests/fiddler_fakes.py`) and platform-api mocked (respx). **Nothing has been run
against a real Fiddler yet** (no credentials); see "Not verified yet" at the end.

## Quick start

```bash
pip install 'aig-sdk[evals]'           # the aig CLI + fiddler-evals + PyYAML
aig eval init                          # aig-eval.yaml + datasets/smoke.csv (the templates ship both)
aig eval run --offline                 # dev loop: local evaluators only, nothing recorded
aig eval run --md report.md            # Fiddler experiment + baseline comparison
aig eval run --post --md report.md     # ... and recorded in platform-api (what the gate runs)
```

TypeScript agents: `npx aig-eval run --offline` (the `@aig/sdk` bin forwards to the Python CLI).

## How a run works

1. Load `aig-eval.yaml`; build the evaluators and the task (exit 2 on any error).
2. Python task: `aig_sdk.init()` first, fail-closed as always (no offline exemption), so every
   model call the agent makes goes through Portkey with the AIG metadata and is traced to Fiddler.
   HTTP task: the agent process runs its own `init()`; `task.http.start` launches it when
   `ready_url` does not already answer and stops it afterwards.
3. Per dataset:
   - **Online (default)**: `fiddler_evals.init(url=AIG_FIDDLER_URL, token=AIG_FIDDLER_API_KEY)`;
     the agent's application (`Application.get_by_id(AIG_FIDDLER_APPLICATION_ID or the registry
     record)`, else `Project.get_or_create(AIG_FIDDLER_PROJECT)` + `Application.get_or_create(agent_id)`);
     the dataset (`Dataset.get_by_name` for `fiddler_dataset:`; a CSV is uploaded once per content
     hash as `<name>-<sha12>` with `Dataset.create` + `Dataset.insert`); then
     `fiddler_evals.evaluate(dataset, task, evaluators, name_prefix="<agent>-<dataset>", metadata={git_sha, pr, ...})`,
     which records an experiment (items, outputs, scores, and the task's traces) in Fiddler.
   - **`--offline`**: no Fiddler at all. Items become local `DatasetItem`s and go through the same
     argument binding as fiddler-evals' `ExperimentRunner`; evaluators that need the Fiddler
     evaluator API are reported `skipped`. The report says OFFLINE everywhere, and
     **`--offline --post` is refused** (exit 2): offline results never reach platform-api and can
     never gate a merge.
4. Aggregate: mean of the successful numeric values per score name, plus `task_success_rate`
   (items whose task returned an answer / all items).
5. Select the baseline, compare (thresholds + regression), write `--out` (JSON) and `--md`.
6. `--post`: `POST /api/v1/evals` per dataset with
   `{agent_id, dataset, experiment_id, scores, baseline_scores, passed, fiddler_url, git_sha, pr}`.

Exit codes: **0** every dataset passed; **1** a score is below its threshold or regressed (the
gate fails); **2** configuration or infrastructure error (bad config / dataset / task / evaluator,
`--offline --post`, `init()` refused to start, Fiddler or platform-api unreachable or refusing,
pinned baseline not found): nothing was judged, and the gate fails too.

## Dataset format (CSV)

Header row required, UTF-8. One row = one test case.

| Column | Required | Meaning |
|---|---|---|
| `input` | yes | The prompt sent to the agent (`input_column` renames it) |
| `expected_output` | no | Reference answer. `\|` separates accepted alternatives for `contains_expected`. Blank = unreviewed: reference-based evaluators skip the row |
| `context` | no | Grounding text (faithfulness evaluators); passed to the task in `inputs.context` |
| `metadata` | no | JSON object (telemetry-bridge writes tags, project, span id, trust scores) |
| `trace_id`, `reason` | no | From telemetry-bridge `export-failing`; kept in metadata, `trace_id` is the item's `source_id` |
| `id`, `source_name`, `source_id` | no | Stable id / provenance |
| anything else | no | Goes to the item's `extras` |

Item ids are UUID5 values from the dataset name and the row, so a CSV maps to the same Fiddler
items every run. **Feedback loop (Phase 3):** `telemetry-bridge export-failing --agent <id>
--output-dir datasets/failing` writes `<agent>.failing.<since>-<until>.csv` with exactly the
columns above (`input, expected_output, metadata, trace_id, reason`); point a dataset at
`datasets/failing/*.csv` (`optional: true` so an empty directory is fine), review the rows and fill
in `expected_output`. Unreviewed rows are still scored by the reference-free evaluators
(relevance, safety, ...).

## `aig-eval.yaml` reference

```yaml
version: 1                       # optional, only 1 exists
agent_id: uw-quote-assistant     # required (default AIG_AGENT_ID); must equal AIG_AGENT_ID when that is set
experiment_prefix: null          # experiment name prefix (default <agent_id>-<dataset>)
description: null
max_workers: 1                   # fiddler-evals concurrency (1-32; >1 only for thread-safe tasks)

datasets:                        # at least one; names unique ([A-Za-z0-9._-]{1,128})
  - name: smoke
    path: datasets/smoke.csv     # CSV or glob, relative to this file
    input_column: input          # optional
    expected_output_column: expected_output
  - name: failing-traces
    path: "datasets/failing/*.csv"
    optional: true               # no matching file = skipped with a warning (not an error)
  - name: regression
    fiddler_dataset: uw-regression-v3   # an existing Fiddler dataset (online only)

task:                            # exactly one of python / http (a plain string works too)
  python: my_agent.evals:task    # import path; the project's src/ and root are on sys.path
  # http:
  #   url: ${AIG_EVAL_AGENT_URL:-http://127.0.0.1:8787}/invoke
  #   method: POST
  #   headers: {x-api-key: "${AGENT_TOKEN}"}   # values may use env vars; never logged
  #   input_field: input          # dataset input sent as body.input
  #   output_field: output        # dotted path of the answer in the JSON response
  #   start: npm run serve        # optional: started unless ready_url answers, stopped afterwards
  #   cwd: .
  #   ready_url: http://127.0.0.1:8787/healthz
  #   timeout_seconds: 120
  #   startup_timeout_seconds: 90

judge:                           # LLM-as-a-judge evaluators (run inside Fiddler's LLM Gateway)
  model: openai/gpt-4o           # "{provider}/{model}" as configured in Fiddler
  credential: null               # Fiddler LLM Gateway credential name (optional)

evaluators:                      # names are case/separator-insensitive
  - contains_expected
  - {name: regex_search, params: {regex: "\\bUW-\\d+\\b", score_name: has_policy_number}}
  - {name: answer_relevance, mapping: {user_query: inputs.input, rag_response: outputs.output}}
  - {custom: my_agent.evals:mentions_policy, name: mentions_policy}
  - {custom: my_agent.evals:PolicyChecker, params: {strict: true}}

thresholds:
  max_regression: 0.05           # default allowed absolute drop vs the baseline (default 0.05)
  scores:
    contains_expected: {min: 0.8}
    task_success_rate: {min: 1.0}
    toxicity_max_risk_prob: {max: 0.3}           # max only => direction lower
    answer_relevance: {min: 0.6, max_regression: 0.1}
    latency_score: {direction: lower}

baseline:
  policy: auto                   # auto | pinned | none
  pinned_experiment_id: null     # used by pinned, and as the auto fallback
```

String values may use `${VAR}` and `${VAR:-default}`; an unset `${VAR}` without default is a
configuration error.

### Task contract

Every task has fiddler-evals' signature `task(inputs, extras, metadata) -> dict` and returns at
least `{"output": str}` (optionally `context` / `retrieved_documents` for faithfulness and RAG
evaluators). A Python task may instead take one positional argument (the `input` text) or any
subset of `inputs`/`extras`/`metadata` by name, and may return a string. An exception fails that
item (recorded, counted in `task_success_rate`), not the run.

HTTP task request: `POST {url}` with `{"input": "...", "inputs": {...}, "metadata": {...}}` and
header `x-aig-eval: 1`; response JSON with the answer at `output_field`, optional `context` /
`retrieved_documents`; an `x-aig-trace-id` response header is kept in the outputs. HTTP >= 400,
non-JSON or a missing field fails the item.

### Evaluators

fiddler-evals built-ins (scored by the Fiddler evaluator API; `skipped` offline):

| Name (aliases) | fiddler-evals class | Default inputs |
|---|---|---|
| `answer_relevance` | `AnswerRelevance` (LLM judge) | user_query = input, rag_response = output |
| `coherence` | `Coherence` (LLM judge) | prompt = input, response = output |
| `conciseness` | `Conciseness` (LLM judge) | response = output |
| `context_relevance` | `ContextRelevance` (LLM judge) | user_query, retrieved_documents (outputs/inputs, else `[context]`) |
| `rag_faithfulness` | `RAGFaithfulness` (LLM judge) | user_query, rag_response, retrieved_documents |
| `custom_judge` | `CustomJudge` (LLM judge) | `params.prompt_template`, `params.output_fields`; `mapping.inputs` builds the placeholder dict |
| `prompt_safety` (`ftl_prompt_safety`) | `FTLPromptSafety` | text = input; scores `illegal_prob` ... `jailbreaking_prob`, `max_risk_prob` |
| `toxicity` | `FTLPromptSafety` on the **answer**, scores prefixed `toxicity_` (e.g. `toxicity_max_risk_prob`) | text = output |
| `faithfulness` (`ftl_response_faithfulness`) | `FTLResponseFaithfulness` | response = output, context (outputs/inputs `context`, else joined documents) |
| `sentiment` | `Sentiment` | text = output |
| `topic_classification` | `TopicClassification` (`params.topics`) | text = output |
| `regex_search`, `regex_match` | `RegexSearch`, `RegexMatch` (`params.regex`, `params.score_name`) | output |

fiddler-evals 0.6 has no evaluator called "Toxicity"; `toxicity` is the Fiddler safety model
applied to the answer. The score names a Fiddler evaluator returns come from the Fiddler API:
check the first real report and adjust `thresholds.scores` (a threshold naming a score the online
run did not produce fails, so typos are caught).

aig local evaluators (in-process, also offline; fiddler-evals `Evaluator` subclasses, importable
from `aig_sdk.evals`): `contains_expected` (`case_sensitive`), `exact_match` (`case_sensitive`),
`not_empty`, `max_length` (`max_chars`). Reference-based ones are `skipped` on rows without
`expected_output`.

Custom (`custom: module:attr`): an `Evaluator` subclass (instantiated with `params`), an
`Evaluator` instance, or a plain function wrapped in fiddler-evals' `EvalFn` (arguments bound by
name from `output` and any other task output key, `inputs`, `outputs`, `expected_outputs`;
returns bool / number / `Score` / `None` = skipped; `name` sets the score name).

`mapping` overrides an evaluator's inputs: `{param: "inputs.input" | "outputs.output" |
"expected_outputs.expected_output" | {key: path, ...}}`.

## Baseline policy

- **`auto`** (default): the **last approved run** for this agent and dataset: the newest
  platform-api eval run (`GET /api/v1/evals?agent_id=`, newest first) with `passed: true` and
  **no `pr`**. The gate posts PR runs with `--pr` and default-branch pushes without, so this is
  "the last passing run on the default branch". platform-api records no branch, so runs posted
  from other branches without `--pr` would also qualify: only post from PRs and the default
  branch. If there is none, `baseline.pinned_experiment_id` is used; if that is unset too, the run
  has no baseline (first run: only absolute thresholds apply, reported as such).
- **`pinned`** / **`--baseline <experiment_id>`**: that experiment's scores, from platform-api (any
  run with that `experiment_id`) or else read from Fiddler (`Experiment.get_by_id().get_items()`,
  online only). Not found = exit 2.
- **`none`** / **`--baseline none`**: no regression check.

When `AIG_PLATFORM_API_URL` is unset (laptop), `auto` falls back to the pinned id or no baseline.
When it is set, a failing baseline lookup is an error (exit 2), never a silent pass.

### Pass / fail per score

- below `min` or above `max` fails;
- `max_regression` (absolute): fails when the score dropped more than that from the baseline
  (`direction: lower`: rose more than that);
- no successful value (every item errored in the evaluator) fails when a threshold or the
  baseline expects the score (fail-closed); offline Fiddler-only scores are `skipped`;
- a threshold for a score the run did not produce fails online, is `skipped` offline;
- a baseline score the run no longer produces is reported `info` ("not evaluated").

## Reports

`--out report.json` (schema `aig-eval-report/v1`): agent, mode (`fiddler` | `offline`),
`offline`, `passed`, git sha, PR, versions, and per dataset: source, content hash, Fiddler
dataset, experiment id/name, `fiddler_url`, item counts, baseline (source, experiment id, scores,
reason), score rows (value, baseline, delta, min, max, max_regression, direction, status,
reason, counts), skipped evaluators, the first 20 task failures, the platform-api record id.

`--md report.md`: starts with `<!-- aig-evals-gate:<agent_id> -->` (the gate updates that one
comment), the verdict, the OFFLINE banner when offline, and per dataset a table
`Score | Value | Baseline | Delta | Threshold | Max regression | Result` plus the Fiddler link.

## platform-api

- `GET /api/v1/evals?agent_id=&limit=200` (baselines) and `POST /api/v1/evals` (`--post`).
- Auth: `AIG_PLATFORM_API_TOKEN` is sent as the **service token** `x-aig-service-token`
  (platform-api's `PLATFORM_SERVICE_TOKEN`; `POST /api/v1/evals` accepts nothing else). For
  reading baselines locally with a developer token set `AIG_PLATFORM_API_AUTH=bearer`
  (`Authorization: Bearer`). `--post` without a token is exit 2.
- The Web UI's Evals page shows these records (run history, pass/fail against the baseline).

## TypeScript agents

fiddler-evals is Python-only, so a TypeScript agent is evaluated over HTTP by the Python CLI:

1. Expose the agent on a local endpoint. The `langgraph-ts` template has `npm run serve`
   (`src/serve.ts`, same fail-closed `init()` as `npm start`): `127.0.0.1:${AIG_EVAL_PORT:-8787}`,
   `POST /invoke {"input"} -> {"output"}`, `GET /healthz`.
2. `aig-eval.yaml` uses `task.http` with `start: npm run serve` and `ready_url` (the template's
   config does; `AIG_EVAL_AGENT_URL` points it at an agent you started yourself).
3. Run `npx aig-eval run ...` (or `npm run eval` / `npm run eval:offline`). The `@aig/sdk`
   `aig-eval` bin forwards every argument and the exit code to the Python `aig eval`, found via
   `AIG_PYTHON_CLI`, `aig` on `PATH` or `${AIG_PYTHON:-python3} -m aig_sdk.cli`; without one it
   exits 127 with `pip install 'aig-sdk[evals]'` instructions.

The template's `test/eval.test.ts` runs exactly this offline against a fake gateway.

## The evals gate in CI

[`.github/workflows/evals-gate.yml`](../.github/workflows/evals-gate.yml) (`on: workflow_call`):

| Input | Default | Meaning |
|---|---|---|
| `agent_path` | required | Agent project directory (holds the config) |
| `eval-config` | `aig-eval.yaml` | Config path relative to `agent_path` |
| `python-version` | `3.12` | |
| `node-version` | `''` | Set for TypeScript agents (installs Node) |
| `paths` | `''` | Globs (comma/newline separated); PRs touching none skip the gate |
| `aig-sdk-spec` | `aig-sdk[evals]` | pip requirement for the CLI (monorepo: `./sdk/python[evals]`) |
| `install-command` | `''` | Installs the agent, run in `agent_path` (`pip install -e '.[dev]'`, `npm ci`) |
| `datasets` | `''` | `--dataset` values (default: all configured) |
| `baseline` | `auto` | `auto`, `none` or an experiment id |
| `post` / `comment` | `true` | Record in platform-api / comment on the PR |
| `team`, `aig-env`, `user-tier` | required, `dev`, `standard` | `AIG_TEAM`, `AIG_ENV`, `AIG_USER_TIER` (`AIG_HOST=ci`) |
| `portkey-base-url`, `fiddler-url`, `platform-api-url` | repo/org `vars.AIG_*` | Non-secret endpoints |
| `fiddler-project`, `fiddler-application-id` | `aig-<env>`, registry | |

Secrets: `AIG_PORTKEY_API_KEY` (the CI environment's scoped Portkey key, never a provider key),
`AIG_FIDDLER_API_KEY`, `AIG_PLATFORM_API_TOKEN` (platform-api service token), optional
`PIP_INDEX_URL` and `NPM_TOKEN` for AIG's internal package indexes.

What it does: installs the CLI and the agent, runs `aig eval run --post --md --out --pr
<number> --git-sha <head sha>`, writes the summary to the job summary, uploads the reports
(`aig-eval-report-*` artifact, 30 days), creates or updates **one** PR comment (found by the
`<!-- aig-evals-gate:<agent_id> -->` marker; `actions/github-script@v7`), and finally fails the
job on exit 1 (regression / below threshold) or 2 (could not judge). Pushes to the default branch
run the same job without a PR: their passing runs become the next `auto` baseline.

Example caller: [`sdk/templates/langgraph-py/.github/workflows/evals.yml`](../sdk/templates/langgraph-py/.github/workflows/evals.yml)
(copied by `aig init`; replace `__REPLACE_ME_GITHUB_ORG__`).

```yaml
on:
  pull_request:
  push: {branches: [main]}
permissions: {contents: read, pull-requests: write}
jobs:
  evals:
    uses: <org>/aiecosystem/.github/workflows/evals-gate.yml@main
    with: {agent_path: agents/uw-quote, paths: "agents/uw-quote/**", team: underwriting-ai,
           install-command: "pip install -e '.[dev]'"}
    secrets:
      AIG_PORTKEY_API_KEY: ${{ secrets.AIG_PORTKEY_API_KEY }}
      AIG_FIDDLER_API_KEY: ${{ secrets.AIG_FIDDLER_API_KEY }}
      AIG_PLATFORM_API_TOKEN: ${{ secrets.AIG_PLATFORM_API_TOKEN }}
```

### Making it a required check (blocks the merge)

1. Merge the caller workflow and let it run once (so GitHub knows the check name, e.g.
   `evals / Evals gate (agents/uw-quote)`).
2. Repository settings > Branches (or Rulesets) > the default branch: "Require status checks to
   pass before merging", add that check. Also require branches to be up to date if baselines
   must be compared against the latest main.
3. **Path filters**: do not put `paths:` on the trigger of a workflow whose check is required (a
   PR that does not match never reports the check, and the PR waits forever). Pass the globs as
   the `paths` input instead: the gate job is then *skipped* for unrelated PRs, and GitHub treats
   a skipped job as passing.
4. Fork PRs get no secrets: the gate fails with exit 2 (cannot judge). Run it from branches in
   the main repository, or have a maintainer re-run it.
5. One agent per caller job; for several agents in one repo, add one job (or a matrix) per agent.

## Reuse for the model harness (Phase 7)

The pieces are independent of agents: `aig_sdk.evals.runner.FiddlerBackend` (dataset upload,
`evaluate()`, experiment scores), the evaluator registry (`build_evaluators`), the HTTP task
wrapper (`make_http_task`, e.g. pointed at a sandbox model endpoint or the platform-api LLM proxy
with guardrails on), `gate.compare` (thresholds + regression against the tier's current model as
the "baseline") and the reports. Phase 7 benchmark and safety suites (injection, jailbreak, data
leakage) can be `aig-eval.yaml` files with `prompt_safety` / `custom_judge` evaluators and
`direction: lower` thresholds; scorecards go to `PUT /api/v1/models/{id}/scorecard` instead of
`POST /api/v1/evals`.

## Not verified yet / open items

- **Real Fiddler: not yet.** The fiddler-evals API used here was read from the installed
  0.6.0 source and exercised through its real `evaluate()` / `ExperimentRunner` /
  `ExperimentResultPublisher` with the HTTP calls faked; the server-side score names, the LLM
  Gateway model names, dataset/experiment permissions of the CI token and trace capture in the
  eval application are unverified.
- The evals gate workflow is linted (actionlint) and structure-tested, but has not run on GitHub.
- LLM-as-a-judge evaluators call models through **Fiddler's LLM Gateway**, not Portkey (the
  agent's own calls do go through Portkey). Whether that is acceptable, and which judge model, is
  an open item for the platform owner.
- Gate thresholds per tier (plan "Open items"): the templates use example values.
- platform-api eval records have no branch field; the "default branch" rule relies on `pr` being
  empty only for default-branch runs (see Baseline policy).
