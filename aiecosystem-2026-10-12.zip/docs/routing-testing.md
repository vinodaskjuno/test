# Testing usage-, tier- and cost-based model routing

Every chat goes through the platform API. The platform API adds metadata that it builds itself
(the client cannot set or override it) and sends the request to the Portkey config. Portkey's
conditional rules then pick the model from two inputs:

| Input | Values | Where it comes from |
|---|---|---|
| `user_tier` | premium · standard · free | User directory (`users.yaml`), per user |
| `cost_mode` | economy · balanced · quality | User directory: the user's own value, else `teams.<team>.cost_mode`, else `default_cost_mode`, else `balanced` |
| `job_profile` | underwriting · claims · operations · general | Chosen in the chat (job-profile select) |

The tier caps how strong a model the user can get. The cost mode picks a model within that cap.

## Routing table (Portkey config `pc-aig-router`, Bedrock via `@aiecosystem`)

The source is `backend/gateway/configs/pc-aig-router.portkey-cloud.json`. The first rule that
matches wins. Each target has a fallback model, listed in brackets.

| # | Condition | Model served |
|---|---|---|
| 1 | cost_mode = economy (any tier) | Nova Lite |
| 2 | premium + quality | Claude Sonnet 4.5 (fallback: Haiku 4.5) |
| 3 | premium (balanced) | Claude Haiku 4.5 (fallback: Nova Pro) |
| 4 | standard + quality | Claude Haiku 4.5 |
| 5 | standard (balanced) | Nova Pro (fallback: Nova Lite) |
| 6 | job_profile underwriting / claims | Nova Pro |
| 7 | free + quality | Nova Pro |
| – | default (free + balanced) | Nova Lite |

To change the routing, edit that JSON file and apply it to Portkey. Use the Portkey UI
(Configs → `pc-aig-router`), or the API:

```bash
python3 -c "import json;print(json.dumps({'config':json.load(open('backend/gateway/configs/pc-aig-router.portkey-cloud.json'))}))" > /tmp/cfg.json
curl -X PUT https://api.portkey.ai/v1/configs/<config-id> -H "x-portkey-api-key: $PORTKEY_API_KEY" \
     -H 'content-type: application/json' --data @/tmp/cfg.json
```

## Local setup

1. **Keys.** In `backend/platform-api/secrets/.env.local` (gitignored), set `PORTKEY_API_KEY`.
2. **Endpoints.** In `backend/platform-api/config/environments/local.override.yaml` (gitignored; copy
   it from `local.override.example.yaml`), set the Portkey cloud URLs and your config ID. Portkey
   cloud shows the ID as `pc-…`.
3. **Users.** The test personas are in `config/users.example.yaml`. You can copy that file to
   `config/users.yaml` to make your own. You sign in locally with any of these emails:

   | Email | Tier | Cost mode |
   |---|---|---|
   | `premium.quality@aig.example` | premium | quality |
   | `premium.balanced@aig.example` | premium | balanced |
   | `premium.economy@aig.example` | premium | economy |
   | `standard.quality@aig.example` | standard | quality |
   | `standard.balanced@aig.example` | standard | balanced |
   | `free.quality@aig.example` | free | quality |
   | `free.balanced@aig.example` | free | balanced |
   | `finance.user@aig.example` | premium | economy (from team `finance-ai`) |
   | `routing.admin@aig.example` | premium | quality, **admin** (can run the matrix) |

4. **Restart the backend:** `cd backend/platform-api && ./run-local.sh start`.
5. **Switch off sample data** to see real routing:
   - Portal: set `"demoData": false` in `web/public/config.json`.
   - VS Code: turn `aig.demoData` off.
   - Eclipse: untick *Use sample data*.

## How to test

### Command line

```bash
# Your own route (any signed-in user)
curl -s localhost:8080/api/v1/routing/test -H 'authorization: Bearer dev:premium.economy@aig.example' \
     -H 'content-type: application/json' -d '{"job_profile":"general"}'

# Any tier / cost mode (admins only)
curl -s localhost:8080/api/v1/routing/test -H 'authorization: Bearer dev:routing.admin@aig.example' \
     -H 'content-type: application/json' -d '{"user_tier":"standard","cost_mode":"quality"}'
```

The response holds `model` (what Portkey actually served), `route` (the tier, cost mode and job
profile that were sent), `latency_ms`, `provider` and `trace_id`.

### Web portal (http://localhost:3000)

- **Routing page → "Routing test" card:**
  - *Test my route* runs one test with your own tier and cost mode.
  - Admins (`routing.admin@…`) also get a custom tier/cost-mode test and **Run matrix**, which runs
    all 9 tier × cost-mode combinations and fills a table with the served model and latency of each.
- **Chat page:** under every answer you see the served model and the route as a chip line, for
  example `claude-sonnet-4.5 · premium · quality · general · 13 + 11 tokens`. Your tier and cost
  mode also show next to the job-profile select.

### VS Code extension (0.13.0+)

- **Sidebar → Chat:** the same chip line under every answer. Sign in as different personas to
  compare which model each one gets.
- **Command palette → "AIG: Test model routing":** pick a job profile, and the result appears in
  a notification (model · tier · cost mode · job profile · latency), with *Copy trace id* and
  *Details* buttons.

### Eclipse

The chat in the AIG view shows the same chip line under every answer.

## Usage-based routing (limits → cheaper model)

The platform API reads each user's live usage from Portkey analytics, filtered by metadata `_user`,
and compares it with their limits. It sends the result to Portkey as `usage_state`, and the Portkey
config checks `usage_state` before the tier and cost rules:

| usage_state | When | Effect in `pc-aig-router` |
|---|---|---|
| `normal` | Below 80% of every limit, or the user has no limits | Tier and cost routing as above |
| `soft` | At least 80% (`usage_soft_threshold`) of **any** daily or monthly limit | One model level lower: premium·quality → Haiku 4.5, premium → Nova Pro, standard·quality → Nova Pro, everyone else → Nova Lite |
| `hard` | At least 100% of any limit | Nova Lite for every request (never blocked) |
| `unknown` | No limit could be read from Portkey | Routed like `normal` (fail open) |

**Periods.** `daily` is the current UTC day and `monthly` the current UTC calendar month. A limit
resets at 00:00 UTC on the next day, or on the 1st of the next month.

**Metrics.** `tokens` and `cost_usd` come from Portkey analytics graphs, which need analytics read
permission on `PORTKEY_ADMIN_API_KEY`. `requests` comes from Portkey's per-model analytics and works
with the current key. A metric Portkey refuses is shown as "can't check" and never triggers a downgrade.

**Where limits are set.**
- Defaults per tier: `usage_limits` in the environment config. Locally that's
  `config/environments/local.override.yaml`.
- Overrides: under `limits:` for a team (`teams.<team>.limits`) or for a user in `users.yaml`. The
  user's value wins over the team's, which wins over the tier default, metric by metric.
- Example: `limits: {daily: {requests: 5}, monthly: {tokens: 100000, cost_usd: 2}}`.

**Caching.** Each user's evaluation is cached for `usage_cache_seconds` (15 s locally), so a
downgrade can take up to 15 s to apply.

**API.**
- `GET /api/v1/usage/limits?refresh=true` returns the caller's limits, live usage per check, and
  the resulting state.
- `POST /api/v1/routing/test` with `{"usage_state": "soft"}` lets admins test a state without
  using up any limit.

### Test users

| Email | Tier · cost mode | Limit | Expected |
|---|---|---|---|
| `usage.standard@aig.example` | standard · quality | 10 requests / day | Haiku 4.5 → Nova Pro from the 8th request → Nova Lite from the 10th |
| `usage.limit@aig.example` | premium · quality | 5 requests / day | Sonnet 4.5 → Haiku 4.5 at 4 → Nova Lite at 5 |
| `usage.tokens@aig.example` | premium · quality | 2,000 tokens, $0.05 / day | "Can't check" until analytics permission is granted |

Checked live on 2026-10-11 with `usage.limit@`: 0–3 requests → Sonnet 4.5 (normal), 4 → Haiku 4.5
(soft), 5 and over → Nova Lite (hard).

The interactive test plan and the flow chart (with a usage-state selector) are in
`docs/routing-test-plan.html`.

## Notes

- Clients can never set the tier or cost mode. Both always come from the platform API's user
  directory. The backend ignores anything a client sends in `x-portkey-metadata`, and tests check this.
- Every chat response reports its route: as the `x-aig-route-*` headers over HTTP, and as `route`
  plus `model` in the WebSocket `chat.done` message.
- Agents that call Portkey directly (agent mode) do not send `cost_mode`, so they follow the
  balanced rules for their tier.
