# Branch protection

`main` of the platform repo and of every agent repo is protected so that nothing reaches a deploy
without passing CI, the evals gate and the image check, and without a human review. This is a
repository setting: a **repo admin** applies it with [`scripts/branch-protection.sh`](../scripts/branch-protection.sh)
(dry run by default; it prints the exact `gh api` request).

## Rules

| Rule | Setting | Why |
|---|---|---|
| Required status checks, up to date with `main` | `required_status_checks.strict: true` | The checks ran on the code that is merged |
| **CI** | platform repo: every job of `.github/workflows/ci.yml` (contracts, backend, SDKs + templates, VSIX, web, Eclipse, infra, workflow lint, secrets scan, ...). Path-filtered jobs that are skipped report success, so requiring all of them is safe | Tests, lint, contracts, key isolation |
| **Evals gate** | agent repos: `evals / Evals gate (.)` (the caller job in `sdk/templates/*/.github/workflows/evals.yml`; `evals / Evals gate (<agent_path>)` for an agent in a sub-directory) | Scores below threshold or regressions block the merge ([`docs/evals.md`](evals.md)) |
| **Image check** | platform repo: `Image build check (infra/ci/image-check unit tests, template Dockerfiles in sync)`; agent repos: the job that calls `image-check.yml` on PRs, if the repo runs one (add it with `--check`). Deploys run the image check again before pushing (`deploy-agent.yml`) | Pinned SDK, hardened base image, no secrets in the image |
| **1+ approving review** | `required_approving_review_count: 1` (raise with `--reviewers`) | Four-eyes principle |
| **Code-agent PRs need a human approval** | `require_last_push_approval: true`, `dismiss_stale_reviews: true`, no bypass allowances | PRs opened or updated by the code agent (workspace-orchestrator GitHub App, Path B) can only be approved by a person other than the last pusher; a new push by the agent dismisses earlier approvals |
| No admin bypass | `enforce_admins: true` | The rules also bind admins and automation with admin rights |
| Conversations resolved | `required_conversation_resolution: true` | Review comments are addressed |
| No force push / deletion | `allow_force_pushes: false`, `allow_deletions: false` | History of `main` is kept |

Do not add the code agent's GitHub App (or any bot) to the bypass lists, and do not give it the
`admin` or `maintain` role: its installation token only needs `contents: write` and
`pull_requests: write` on the one repository it works on (`backend/workspace-orchestrator`).

## Apply

```bash
# Platform repo (required checks read from .github/workflows/ci.yml): dry run, prints the JSON
scripts/branch-protection.sh --repo <org>/aiecosystem

# An agent repo created from a template: evals gate + its own CI / image-check jobs
scripts/branch-protection.sh --repo <org>/claims-agent --profile agent \
  --check "CI / test" --check "image / Image check (agent, python)"

# After reviewing the output, a repo admin applies it (gh auth login with admin rights)
scripts/branch-protection.sh --repo <org>/aiecosystem --apply
```

Check names must match the check runs exactly (a job's `name:`; for a reusable workflow
`<caller job id or name> / <called job name>`). Look them up on a recent PR (**Checks** tab) or with
`gh pr checks <number>`. A required check that never reports (a typo, or a workflow with a
trigger-level `paths:` filter) keeps PRs pending forever.

Rulesets (`gh api repos/<org>/<repo>/rulesets`) can express the same rules organisation-wide; the
script uses the classic branch-protection endpoint because it works on every plan.

Status: the script and these rules exist in the repo; **not yet applied** to any real repository
(needs the GitHub org and an admin).
