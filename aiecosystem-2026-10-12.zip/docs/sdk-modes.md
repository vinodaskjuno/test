# AIG SDK connection modes

One SDK, two ways to connect. Agents are built from the starter pack and call Portkey directly
with their own key (**agent mode**). The VS Code extension and the web portal use the same SDK
through **backend mode**: they sign in, talk only to platform-api, and never see a Portkey key.

This page mirrors the approved design review ("AIG SDK connection modes") and records how it was
implemented.

## What the starter pack is

The starter pack is the whole kit a new agent starts from:

| Part | What it is |
|---|---|
| SDK | `aig-sdk` (Python) / `@aig/sdk` (TypeScript), **agent mode**: fail-closed checks, Portkey client, Fiddler tracing, MCP |
| `aig` tool | `aig init` (create + register), `aig doctor` (check setup), `aig eval` (run evals) |
| Templates | `sdk/templates/langgraph-py`, `strands-py`, `langgraph-ts`, each already using the SDK |
| Pre-wired config | `.env.example` (`AIG_*` settings), `aig-eval.yaml` + datasets, hardened Dockerfile, CI evals-gate workflow |

A developer runs `aig init` (or **AIG: New Agent** in VS Code) and gets a project with Portkey,
guardrails and Fiddler wired in; the project runs in agent mode.

**The starter pack is agent mode only.** Backend mode (`@aig/sdk/platform`) ships in the same
npm package but is not part of the starter pack: templates and `aig init` output never import it
(enforced by `sdk/typescript/test/platform/guard.test.ts`, which scans `sdk/templates/`, the `aig` CLI
source and the output of `aig init` for every template).

## The two modes

| | Agent mode | Backend mode |
|---|---|---|
| Used by | Agents built from the starter pack (laptop, VDI, ECS, AgentCore, CI) | VS Code extension, web portal |
| In the starter pack | Yes, it is the SDK part of it | No (same package, separate entry point) |
| Import | `@aig/sdk` / `aig_sdk` | `@aig/sdk/platform` (TypeScript only) |
| Talks to | Portkey gateway directly | platform-api only |
| Credential the SDK holds | **The agent's own Portkey key** | The signed-in user's bearer token (Entra ID, or `dev:<email>` on a local dev backend) |
| Who adds the Portkey key | The SDK | platform-api (key broker) |
| Metadata built by | The SDK, from `AIG_*` settings | platform-api, from its user directory (tier and team cannot be faked) |
| Start-up checks | Fail-closed: Portkey, Fiddler, registered agent, no raw provider keys | Backend URL valid; signed in |
| Tracing to Fiddler | The SDK sends traces | Portkey logs reach Fiddler through the telemetry bridge |
| Transport | HTTPS to Portkey | HTTPS + WebSocket (reconnect, HTTP fallback) |
| Runs in a browser | No (it would expose the key) | Yes (browser-safe entry, no Node built-ins) |

### Where the Portkey key lives

```
Agent mode    agent code ── @aig/sdk ──[agent's Portkey key + AIG metadata]──▶ Portkey ──▶ models
                                └── OTel ──▶ Fiddler

Backend mode  VS Code / web ── @aig/sdk/platform ──[user's bearer token only]──▶ platform-api
                                                    platform-api ──[Portkey key + metadata]──▶ Portkey ──▶ models
                                                    Portkey logs ── telemetry bridge ──▶ Fiddler
```

In backend mode a Portkey key exists only inside platform-api. The client side carries nothing
but the user's token: on HTTP in the `Authorization` header, on the WebSocket either in the
`Authorization` header of the upgrade (Node, the `ws` package) or, in browsers, as the second
`Sec-WebSocket-Protocol` entry `["aig.bearer", "b64u.<base64url token>"]` (platform-api selects only
`aig.bearer` and never echoes the token). The token is never put in a URL.

## Backend mode, request by request

1. The app signs the user in (Entra ID, or the local sign-in page) and passes `getToken()` to
   `createPlatformClient({ baseUrl, getToken })`.
2. `GET /api/v1/session` with the bearer token: user, team, tier, allowed job profiles.
3. `client.live().start()` opens `/api/v1/ws`; the server answers `ready`.
4. `usage.subscribe` (7 / 30 / 90 days): platform-api reads Portkey analytics with its admin key
   and pushes `usage` every 15 s and after each chat.
5. `chat.stream(messages, { jobProfile })` sends a `chat` frame (no key); platform-api adds the
   Portkey key and metadata, calls Portkey and streams `chat.delta` frames back, then `chat.done`
   with token counts.
6. Socket down: the live connection reconnects with backoff (1 s, 2 s, 5 s, 10 s, 30 s); usage
   falls back to HTTP polling (`GET /api/v1/usage/dashboard`) and chat to the HTTP SSE proxy
   (`POST /api/v1/llm/chat/completions`), both automatic.

Only platform-api's outbound calls carry a key (the admin key for analytics, the gateway key for
chat). Every call from the SDK carries only the user's token and the `x-aig-*` routing hints
(`x-aig-job-profile`, `x-aig-agent-id`, `x-aig-trace-id`; backend/contracts/headers.md section 2).

## Package layout

```
sdk/typescript/src/
  core/          shared contract core, browser-safe, used by both entries:
                   contract.ts  job profiles, agent-id / trace-id patterns, trace-id rule
                   headers.ts   x-aig-* client headers (= reference.py backend_client)
                   b64u.ts      bearer token -> aig.bearer subprotocol value
                   ws.ts        WebSocket frame types, parser, builder, ws URL
                   sse.ts       SSE parser + OpenAI chat-chunk decoding
                   usage.ts     usage dashboard / personal usage parsing
  index.ts, contract.ts, ...   '@aig/sdk'           agent mode (the starter pack)
  platform/                    '@aig/sdk/platform'  backend mode
    client.ts   createPlatformClient: session, preferences, usage, agents, MCP servers, models
                (transition, scorecard, canary-pr), audit, workspaces (incl. cancel), evals,
                routing, chat.stream, live()
    live.ts     reconnecting WebSocket (statuses, ready, usage push + HTTP fallback, chat
                routing by id, cancel, keepalive)
    chat.ts     chat over the live socket with automatic HTTP SSE fallback
    http.ts     fetch transport (timeouts, cancellation, no redirects, no cookies)
    errors.ts   PlatformError {status, code, message, traceId}
    url.ts      base URL rule (https; http only for loopback in local)
    types.ts    REST types from openapi.d.ts
    openapi.d.ts  generated from backend/contracts/platform-api.openapi.json (npm run openapi)
```

Consumers:

- **Agents** import `@aig/sdk` through the starter pack.
- **VS Code extension** (`vscode-extension`, 0.9.0) bundles `@aig/sdk/platform` from source
  (`aliases.mjs`, tsconfig `paths`) and injects the Node `ws` package (header auth). Its own
  `backendClient.ts`, `ws/*`, `headers.ts` and `sse.ts` were removed.
- **Web portal** (`web`) resolves `@aig/sdk/platform` from source the same way and uses the
  browser WebSocket (subprotocol auth). Its `api/client.ts` internals, `api/sse.ts` and
  `live/protocol.ts` were replaced; pages are unchanged.
- **Eclipse plugin** (Java) keeps its own client; it passes the same `kind: backend_client`
  fixtures, so all three stay consistent.

The contract core is tested against `backend/contracts/fixtures`: every `kind: backend_client` fixture is
reproduced byte for byte (unit tests, both dist bundles, and `scripts/cross-sdk-contract.sh`), and
agent mode's `kind: sdk` output is unchanged (Python == TypeScript CJS == ESM == expected).

## Decisions (approved)

1. **Backend mode lives inside `@aig/sdk`** as the second entry point `@aig/sdk/platform`, over a
   shared contract core (not a separate package), so the contract lives in one place.
2. **Eclipse keeps its Java client.** A TypeScript SDK cannot run inside Eclipse; the contract
   fixtures keep it consistent.
3. **No Python backend mode.** Not needed for the extension or the portal.
4. **No change to where keys live.** Agents keep their own Portkey key in agent mode; the VS Code
   extension, the web portal and Eclipse never hold one. Backend mode only ever sends the user's
   bearer token to platform-api (guarded by no-secrets tests over the SDK source and its bundle,
   and in both apps).
5. **The starter pack stays agent-only.** Starter pack = SDK (agent mode) + `aig` tool +
   templates + pre-wired config; templates and `aig init` never use or reference
   `@aig/sdk/platform`.

## Usage

```ts
// An agent (agent mode): calls Portkey with its own key.
import { init, openaiClient } from "@aig/sdk";
await init(); // fails closed if Portkey, Fiddler or the agent registration is missing
const reply = await openaiClient({ job_profile: "claims" }).chat.completions.create({
  model: "auto",
  messages: [{ role: "user", content: "Summarise claim 4411" }],
});
```

```ts
// VS Code extension or web portal (backend mode): no Portkey key anywhere.
import { createPlatformClient } from "@aig/sdk/platform";

const aig = createPlatformClient({ baseUrl: "https://platform-api.dev.example.internal", env: "dev", getToken: () => auth.accessToken() });
const me = await aig.session();
const live = aig.live({ usageDays: 30 }).start(); // WebSocket + HTTP fallback
live.on("usage", (u) => render(u.data));
for await (const ev of aig.chat.stream(messages, { jobProfile: "general" })) {
  if (ev.type === "delta") append(ev.text);
}
```

Details: [`sdk/typescript/README.md`](../sdk/typescript/README.md#backend-mode-aigsdkplatform).
