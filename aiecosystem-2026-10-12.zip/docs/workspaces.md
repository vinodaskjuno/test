# Team workspaces (Phase 6)

The blueprint's second harness path, "Team workspace (UI or Teams)": pick a work item, and a code
agent fixes it in an isolated workspace, with the Portkey gateway, guardrails and Fiddler on from
the first prompt to the pull request.

| Blueprint step | Where it happens |
|---|---|
| 1. Start from UI or Teams | `web` Workspaces page or `backend/teams-bot` -> `POST /api/v1/workspaces` with the **user's** token (team and cost are the user's) |
| 2. Dev workspace, provisioned automatically | `backend/workspace-orchestrator` claims the request and starts an ECS Fargate task from `infra/ci/docker/workspace.Dockerfile` (starter pack, team Portkey key, Fiddler SDK) |
| 3. Git clone | `workspace-job`: GitHub App installation token scoped to the repo, `git clone --depth 1`, branch `aig/ws-<id>` |
| 4. Spin up ECS container | one task per request, its own network interface in a private subnet; the repo's dependencies are installed inside it |
| 5. Code agent fixes it | Claude Code (headless) with `ANTHROPIC_BASE_URL` = Portkey; every call carries the contract headers (`agent_id=workspace.<team>`, `env=workspace`, `host=ecs`) and the job's OTel trace id |
| 6. Test the functionality | unit + functional tests (failures go back to the agent, up to 2 rounds), then `aig eval run --post` when the repo has `aig-eval.yaml` |
| 7. Commit and raise the PR | commit by "AIG Code Agent", push, PR with `Fixes #N` (or the work-item link), the test/eval summary and the trace id; CI runs the evals gate and a person reviews |
| 8. Spin down | the job exits; the orchestrator marks the workspace `completed`. Idle timeout and max runtime stop anything that hangs |

```
 Web UI / Teams bot ──user token──▶ platform-api (queued)
                                         ▲   │ GET ?status=queued, POST /claim, PATCH /status (service token)
              signed POST /api/notify    │   ▼
 Teams bot ◀──────────────────── workspace-orchestrator ──ecs:RunTask──▶ ECS task: workspace-job
                                   relay :8090 ◀──per-workspace token── status, heartbeats, aig_sdk/aig eval
                                                                         │ Claude Code ─▶ Portkey ─▶ Claude
                                                                         │ OTLP spans ─▶ Fiddler
                                                                         └ git push + PR ─▶ GitHub
```

## Statuses

| Status | Set by | Meaning |
|---|---|---|
| `queued` | platform-api (user request) | waiting for an orchestrator |
| `provisioning` | orchestrator (`POST /claim`, atomic) | task starting; `log_url` = CloudWatch stream |
| `running` | job (relay) | clone, setup, code agent |
| `testing` | job (relay) | tests and evals; back to `running` for another agent round |
| `pr_opened` | job (relay) | `pr_url` set; the job exits |
| `completed` | orchestrator | PR opened and the workspace has spun down |
| `failed` | job or orchestrator | `error` = `<step>: <message>` + scrubbed output tail (tests failing, no changes, starter pack refused, idle timeout, max runtime, task ended without a PR, could not start) |
| `cancelled` | user (`POST /cancel`, Web UI or Teams `cancel <id>`) | the orchestrator stops the task on its next tick |

`completed`, `failed` and `cancelled` are final.

## Timeouts

- **Idle timeout: 30 minutes by default** (`AIG_WS_IDLE_TIMEOUT_MINUTES`). Activity = any call
  from the job to the relay (status, heartbeat, platform call); the job sends a heartbeat (at most
  once a minute) whenever the code agent, setup or tests produce output. **Open item:** the
  blueprint leaves "how long an idle workspace stays up before it spins down" to be confirmed.
- **Max runtime: 120 minutes** (`AIG_WS_MAX_RUNTIME_MINUTES`), regardless of activity.
- Per step inside the job: code agent 60 min, tests 30 min (`AIG_WS_AGENT_TIMEOUT_MINUTES`,
  `AIG_WS_TEST_TIMEOUT_MINUTES`).

## Security

- **Per-workspace isolation**: one Fargate task per request (own kernel boundary, ENI, ephemeral
  storage), non-root user, no task-role AWS permissions, no ECS Exec, nothing shared between
  workspaces; the clone and any build output disappear with the task.
- **Restricted egress**: private subnets without public IPs; the workspace security group allows
  only the Portkey gateway, Fiddler, the orchestrator relay, the Git host and the package mirror.
  Claude Code's non-essential traffic (telemetry, auto-update, error reporting) is switched off and
  `WebFetch`/`WebSearch` are disallowed.
- **Secrets**:
  - The team's scoped Portkey key, the Fiddler token and the GitHub App private key come from
    Secrets Manager through the task definition, never through task overrides, images or logs.
  - The platform service token never enters a workspace: tasks get a per-workspace relay token
    (HMAC, valid for that workspace only and only until it is final) and reach platform-api
    through the orchestrator's allow-listed relay.
  - The GitHub token is an App installation token scoped to the one repository
    (`contents`/`pull_requests: write`, `issues: read`), passed to git per command as an
    `http.extraHeader` env config (never in a URL, `ps` or `.git/config`).
  - The code agent, setup and test processes get an environment without secrets (the agent gets
    only the Portkey key it needs). Logs, status errors, PR bodies and notifications pass through a
    scrubber (registered values plus token patterns).
  - Teams notifications are HMAC-signed with a timestamp (5-minute replay window).
- **Users act as themselves**: the Web UI and the Teams bot call platform-api with the user's own
  Entra token (Teams SSO / OAuth connection), so the request's team, budget and audit trail are the
  user's. The bot never holds the service token.
- **Every model call is governed**: Portkey required metadata, the `aig-agent-check` webhook (the
  orchestrator registers `workspace.<team>`), guardrails, budgets per team key; the job starts only
  if `aig_sdk.init()` passes its fail-closed checks.
- **PR approval**: the code agent can open PRs only; it cannot merge. CI runs the evals gate and a
  person must review. **Open item:** who approves PRs raised by the code agent (CODEOWNERS / branch
  protection per repository).

## Open items

- Workspace idle timeout (default 30 min) and max runtime (120 min).
- PR approver for code-agent PRs.
- Workspace image contents and size (currently git, Python 3.12, Node 22, starter pack, Claude
  Code; JDK/Maven optional with `INSTALL_JAVA=true`) and task sizing (2 vCPU / 8 GiB proposed).
- Whether the self-hosted Portkey route behind `pc-aig-router` accepts Anthropic-format
  `/v1/messages` traffic for every tier the workspace uses, or a Claude-only config is needed for
  the code agent (`AIG_PORTKEY_CONFIG`).
- Bot Framework SDK long-term support: Microsoft's successor is the Teams SDK; the bot isolates the
  Teams-specific code to ease a later move.
- Infrastructure: `infra/terraform/modules/workspaces` provides it (summary in
  `backend/workspace-orchestrator/README.md` "Infrastructure"). It is validated offline only and
  has not been applied to a real AWS account.

## Running it locally

```bash
backend/platform-api/run-local.sh                           # PLATFORM_SERVICE_TOKEN in secrets/.env.local
backend/workspace-orchestrator/run-local.sh                 # .env + job.env (see the README)
cd backend/teams-bot && npm run dev --workspaces=false          # optional: Bot Framework Emulator
```

Tests: `make workspace-orchestrator-test` (includes a full local end-to-end run against the real
platform-api) and `make teams-bot-test`.
