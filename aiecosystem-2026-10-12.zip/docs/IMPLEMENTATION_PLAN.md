# AIG AI Ecosystem: implementation plan

## Context

`AIG AI Ecosystem_ architecture blueprint-8.html` (v3.2 draft) describes 10 charters. Its core rule is **"no gateway, no Fiddler, no agent"**: every agent and MCP server, whether on a laptop, VDI or in the cloud, must send model calls through **Portkey** and report to **Fiddler**. A pre-wired **starter pack** makes this automatic.

The workspace holds only the blueprint, so this is a greenfield build.

**In scope**
- Portkey integration through the SDK (Python and TypeScript, built together)
- Fiddler integration
- AgentOps, the evals gate and deployment
- Dev harness: the VSIX plugin and team workspaces
- Model harness
- React Web UI (the platform portal)
- Eclipse plugin
- AIG branding (logo, light and dark themes) shared by the Web UI, the VSIX and the Eclipse plugin

**Out of scope for now:** code intelligence, ontology, and RAG with the governed ETL (Collibra) pipeline.

**Given:** an enterprise self-hosted Portkey already exists, covering the AI gateway, MCP gateway and control plane.

---

## Target repo layout (monorepo)

```
aig-ai-ecosystem/
  backend/contracts/                 # single source of truth shared by both SDKs
    metadata.schema.json     # user_tier, job_profile, agent_id, team, env, host, ...
    tags.schema.json         # Fiddler tags: agent, team, tier, model, env, host
    env-vars.md              # AIG_* variable contract
    errors.md                # fail-closed error codes
    fixtures/                # golden request/headers/span fixtures for contract tests
  sdk/python/aig_sdk/        # pip: aig-sdk   (+ `aig` CLI)
  sdk/typescript/            # npm: @aig/sdk
  backend/gateway/           # Portkey config-as-code + sync tool
  backend/platform-api/     # FastAPI + Postgres: agent/MCP registry, model catalog, approvals, workspaces
  backend/telemetry-bridge/ # Portkey logs -> Fiddler; daily reconciliation job
  backend/workspace-orchestrator/  # ECS team workspaces
  web/packages/design-tokens/    # AIG brand tokens (light/dark) -> CSS vars, TS, VS Code, Eclipse CSS
  web/packages/brand-assets/     # approved AIG logo set (SVG/PNG, light/dark/mono), app icons
  web/packages/ui/               # shared React components + panels (used by web, VSIX webviews, Eclipse browser)
  web/                  # React (Vite + TS) platform portal
  vscode-extension/     # AIG VSIX
  eclipse-plugin/       # AIG Eclipse plugin (Java, PDE/Tycho build)
  backend/teams-bot/            # Microsoft Teams entry point for team workspaces
  sdk/templates/                 # starter agents: langgraph-py, strands-py, langgraph-ts
  infra/ci/                        # reusable pipelines: evals gate, image build check, deploy
  infra/                     # Terraform/CDK: AgentCore, ECS, networking, secrets
```

---

## Phase 0: Foundations and decisions
- Set up the monorepo with a Python toolchain (uv, ruff, pytest) and a TypeScript toolchain (pnpm, tsup, vitest), plus CI lint, test and contract jobs.
- Write the `backend/contracts/` specs before any SDK code. Both SDKs must emit **identical** Portkey headers and Fiddler tags, and shared golden fixtures enforce this.
- Collect environment facts:
  - self-hosted Portkey AI gateway and MCP gateway base URLs
  - Portkey admin API scopes
  - Fiddler instance URL and auth type (access token or API key)
  - SSO provider (OIDC/Entra)
  - the CI system
- Get the **approved AIG logo files and brand guidelines** (colours, typography, clear space, minimum size, rules for internal tools) from the AIG brand team. Don't recreate or approximate the logo.
- **Exit:** contracts approved, brand assets received, and dev, stage and prod Portkey workspaces and Fiddler projects exist.

## Phase 0b: AIG design system (logo, light and dark themes)
One token source drives all three surfaces, so the Web UI, the VSIX and the Eclipse plugin look like one product.

### Light theme: taken from aig.com
These values come from aig.com's live stylesheets (`/etc.clientlibs/design2022/...`, the "design2022" library), ranked by how often each is used.

| Token | Value | Where AIG uses it |
|---|---|---|
| `brand` (AIG navy) | `#001871` | Header bar, primary buttons, headings, accordion. Most-used colour after white. White on navy is 15.3:1 |
| `interactive` | `#1352de` | Links, button hover and focus (6.4:1 on white) |
| `brand-2` | `#0057b8` | Secondary blue for links and icons |
| `accent` (sky) | `#00a4e4` | Highlights, borders, icons. Not for body text (2.8:1) |
| `ink` | `#343741` | Body text (11.9:1) |
| `muted` | `#54565b` / `#5b5c60` | Secondary text (6.7:1) |
| `subtle` | `#76777b`, `#b1b1b1` | Placeholders, disabled |
| `bg` / `panel` | `#ffffff` | Page and cards |
| `panel2` | `#f5f7f9` | Alternate sections |
| `tint` / `info-bg` | `#e9f1fb` / `#c7dbf4` | Selected rows, info alerts |
| `line` | `#dcdcdc` (strong `#cccccc`) | Dividers, inputs |
| `danger` | `#e03c31` (bg `#fff0f3`) | Errors. It's 4.3:1, so small text needs a darker shade |
| `warning-bg` | `#fdfaef` | Warning alerts |
| `success` | `#4dd29a` / `#32c9a6` (AIG mint) | Icons and fills only. Text uses a suggested `#0f7b55` (5.3:1) |

- **Typography**:
  - Headings, nav, buttons and labels use **AIG Futura** (`aig_futurabold`, `aig_futura_medregular`, `aig_futuraregular`; PT Futura based).
  - Body text uses **Source Sans Pro** (regular, semibold, bold, light), base 1rem with line-height about 1.43.
  - AIG Futura is a licensed AIG font, so the files come from the AIG brand team, with the fallback stack `"Futura PT", "Century Gothic", sans-serif`. Source Sans is open source (Source Sans 3).
  - Mono text uses IBM Plex Mono or the system monospace, for code and JSON.
- **Shape and components (AIG style)**:
  - Square corners (`border-radius: 0`) on buttons, inputs and cards; circles only for avatars and icons.
  - Primary button: navy fill, white uppercase AIG Futura Medium at 14 px, padding about 16 px, hover/focus `#1352de`.
  - Header: a navy `#001871` bar with the **white AIG logo**.
  - Light shadows: `rgba(0,0,0,.05)`.
- **Logo**: aig.com serves `aig-logo.png` (colour) and `icon-aig-logo-white.png` (reversed). For production, ask the AIG brand team for vector SVGs and usage rules rather than scraping the site's PNGs.

### Dark theme: suggested (derived from AIG navy)
A navy-based dark theme, not neutral grey, so it still reads as AIG. Contrast ratios were computed against `bg`.

| Token | Value | Notes |
|---|---|---|
| `bg` | `#0a1230` | Deep navy, a darkened `#001871` |
| `panel` / `panel2` | `#111b3f` / `#18244f` | Raised surfaces |
| `header` | `#000e45` | Darker than navy so the white logo still pops |
| `line` | `rgba(199,219,244,.16)` | AIG's `#c7dbf4` tint at low alpha |
| `ink` / `muted` | `#eef2fa` (16.4:1) / `#a9b4cc` (8.8:1) | |
| `interactive` | `#6e9bff` (6.8:1) | `#1352de` lifted for dark backgrounds. Primary buttons use a `#6e9bff` fill with `#0a1230` text (6.8:1) |
| `accent` (sky) | `#33b6ea` (7.9:1) | |
| `tint` / `info-bg` | `#1b2b5c` | Selected rows, info alerts |
| `danger` / `success` / `warning` | `#ff6b5e` (6.6) / `#4dd29a` (9.6, AIG mint as is) / `#f5c451` (11.3) | |

- Same fonts, square shapes and white logo as the light theme.
- Charter accents (build, ship, run, trust, fiddler, claude, openai) keep the blueprint's dark values, retuned to sit beside AIG navy.

### Packages
- **`web/packages/design-tokens`** (Style Dictionary, JSON source):
  - Semantic tokens (the tables above) plus charter accents. They replace the blueprint's placeholder palette (`#1E3A8A` / IBM Plex).
  - Build outputs:
    - **CSS variables** with `:root` for light, `[data-theme="dark"]`, and a `prefers-color-scheme` fallback (the same pattern as the blueprint)
    - a **TS theme object** for React
    - a **VS Code webview CSS** mapping
    - **Eclipse e4 CSS** files for light and dark
  - Each colour pair is checked for WCAG AA contrast in CI.
- **`web/packages/brand-assets`**:
  - AIG logo in full-colour, reversed (for dark backgrounds) and monochrome versions, as SVG plus PNG at 16, 32, 128 and 256 px.
  - Favicon, VS Code marketplace icon (128 px PNG), a monochrome activity-bar SVG using `currentColor`, and Eclipse 16 px view and toolbar icons in light and dark variants.
- **`web/packages/ui`**: shared React components built on the tokens (app bar with logo, nav, tables, status chips, charts, empty states) and a **theme provider** with System, Light and Dark modes.
- **Per surface**:
  - **Web UI**:
    - Logo in the app bar; System/Light/Dark toggle saved per user in `platform-api`.
    - It follows the OS setting by default.
  - **VSIX**:
    - Webview panels (sign-in, agents, token usage, evals) use `web/packages/ui`.
    - They **follow the active VS Code theme** by reading the `vscode-light`, `vscode-dark` and `vscode-high-contrast` body classes and mapping AIG tokens onto `--vscode-*` variables, so they never clash with the editor.
    - The AIG brand shows in headers and the logo.
    - Marketplace icon and activity-bar icon included.
  - **Eclipse plugin**:
    - Contributes AIG e4 CSS light and dark themes and follows Eclipse's active theme (Default/Dark).
    - Its views host the same `web/packages/ui` panels in an SWT Browser, with a theme bridge from Java to JS.
    - Native icons come in light and dark sets.
- **Exit:** a Storybook shows every component in light and dark, and screenshots of all three surfaces in both themes are signed off by the AIG brand team.

## Phase 1: Portkey gateway as code (`backend/gateway/`)
Version-controlled JSON/YAML, applied by a `sync` tool that calls the Portkey admin API. Every gateway change goes through PR review.

- **Config `pc-aig-router`**: use the blueprint's conditional strategy exactly.
  - Rules, first match wins:
    1. `metadata.user_tier == premium` → `opus` (fallback to sonnet)
    2. `user_tier == standard` → `sonnet` (fallback to openai)
    3. `job_profile ∈ [underwriting, claims]` → `sonnet`
  - Default → `openai`, load-balanced across 2 deployments.
  - Every leaf has `custom_host` set to the caching and compression layer (see below).
- **Virtual keys (integrations)**: `anthropic-prod`, `openai-prod`, and a separate `*-sandbox` set that only exists in the model-sandbox workspace. Provider keys live only in Portkey.
- **Security**: workspaces per team, scoped API keys, budgets and rate limits per team or profile, model allow-lists, audit logs.
- **Required metadata**: enforce `user_tier`, `job_profile`, `agent_id` and `team` at the gateway, using Portkey's required-metadata feature (Apr 2026 changelog). Calls without them are rejected before reaching a model.
- **Registered-agent check**: an input **webhook guardrail** calls `platform-api` to verify that `agent_id` is registered and active. Unknown or suspended agents are denied.
- **Guardrails**:
  - Input hooks: PII, prompt injection, policy.
  - Output hooks: schema, policy, PII.
  - Start in log-only mode in dev, then switch to deny/redact.
- **Caching**: decide one owner, Portkey cache or the caching and compression layer, so nothing is cached twice. Recommendation: Portkey owns exact and semantic caching, and the layer only compresses context and keeps prefixes stable.
- **Caching and compression layer**: ship a pass-through proxy first (forwards unchanged, keeps `model` and usage), so routing works end to end. Add compression later.
- **MCP gateway**: register approved MCP servers with workspace and user scoping mapped to IAM roles. Unregistered servers are refused.
- **Exit:** a routing matrix test passes for every tier × job_profile combination, and missing metadata or an unknown agent_id is rejected.

## Phase 2: Starter-pack SDK, Python and TypeScript (Portkey integration)
Both SDKs are thin wrappers that share one contract.

| Module | Python (`aig_sdk`) | TypeScript (`@aig/sdk`) |
|---|---|---|
| Bootstrap / **fail-closed check** | `aig_sdk.init()` checks that `AIG_PORTKEY_*` and `AIG_FIDDLER_*` are set, Portkey and Fiddler are reachable, and the agent_id is registered. Otherwise it raises `AigStartupError` | `init()` with the same checks; throws |
| Gateway client | Wraps `portkey-ai` (`Portkey(base_url=<self-hosted>, config="pc-aig-router")`) and injects `x-portkey-metadata` and `x-portkey-trace-id` | Wraps the `portkey-ai` npm package the same way |
| Framework adapters | LangGraph/LangChain `ChatOpenAI` on the Portkey gateway URL plus headers; Strands model provider | LangGraph.js / LangChain.js; OpenAI-compatible client |
| MCP | Client that connects only through the Portkey MCP gateway URL | Same |
| Tracing | Calls the Fiddler integration from Phase 3 | Same |
| Raw keys guard | Refuses provider keys (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`) in the environment; warns or fails | Same |

- **Trace correlation**: set the Portkey trace id to the OTel trace id, so Portkey logs and Fiddler spans join on one id.
- **Metadata propagation**:
  - Tier and job_profile come from the caller.
  - agent_id, team, env and host come from config.
  - env is `local`, `workspace` or `prod`; host is `laptop`, `vdi`, `ecs` or `agentcore`.
- **`aig` CLI** (Python; the TS side calls it):
  - `aig init`: scaffold from `sdk/templates/` and register the agent
  - `aig doctor`: run the startup checks
  - `aig eval`: see Phase 5
- **Exit:** the templates run locally through Portkey, and contract tests show both SDKs emit byte-identical headers and tags.

## Phase 3: Fiddler integration
- **SDK tracing inside the starter pack**:
  - Python LangGraph: `fiddler-langgraph` (`FiddlerClient` + `LangGraphInstrumentor`), auto-instrumented on `init()`.
  - TypeScript LangGraph: `@fiddler-ai/langgraph`.
  - Strands and custom agents: generic OTel with an OTLP exporter to Fiddler.
  - Every span gets the shared tags (agent, team, tier, model, env, host).
- **Project model**: one Fiddler project per environment and one application per registered agent, created automatically when the agent registers.
- **`telemetry-bridge` service**:
  - Pulls Portkey logs (or receives webhooks or OTel export from Portkey) and forwards gateway events to Fiddler with the same tags and trace id. Each event carries prompt, reply, model, tokens, cost, cache result and guardrail result.
  - Also forwards IDE token-usage events.
- **Trust scoring and monitors**: enable hallucination, toxicity, PII and jailbreak scores. Add drift, latency, error and cost monitors per agent. Route alerts to Slack, PagerDuty or email with links to the failing traces.
- **Daily reconciliation job**: match Portkey traffic per agent_id against Fiddler traces. If an agent has gateway traffic but no Fiddler data, suspend its Portkey key through the admin API, mark it suspended in the registry and alert the owner.
- **Feedback loop**: export failing traces from Fiddler into eval datasets (CSV), and track guardrail-tightening tickets.
- **Exit:**
  - A sample agent on a laptop shows in Fiddler as `env: local`, with its Portkey events joined on the same trace.
  - A reconciliation test suspends a deliberately untraced agent.

## Phase 4: Platform API and React Web UI
- **`platform-api`** (FastAPI + Postgres, behind SSO):
  - Agent registry: automatic registration, agent IDs, owner, team, status.
  - MCP registry: servers mapped to IAM roles, synced to the Portkey MCP gateway.
  - Model catalog and approvals with an audit log.
  - Workspace requests.
  - **Key broker** (all Portkey enterprise API keys live only here):
    - Holds `PORTKEY_API_KEY`, optional `PORTKEY_ADMIN_API_KEY` and optional `FIDDLER_API_KEY` per environment (`local`, `dev`, `stage`, `prod`, chosen by `AIG_ENV`).
    - The repo carries only placeholders (`__REPLACE_ME_<NAME>_<ENV>__`) in `secrets/<env>.env.example`. The platform owner uploads real keys by hand to the gitignored `secrets/.env.<env>` or to AWS Secrets Manager `aig/<env>/platform-api`.
    - Fails closed outside `local`: the service will not start if the key is missing or a placeholder. In `local` it starts and the proxy returns 503.
    - Keys are never returned by any endpoint and never logged (`/healthz` shows only configured/placeholder/missing).
    - OpenAI-compatible LLM proxy `/api/v1/llm/chat/completions` injects the key, config `pc-aig-router` and server-built metadata (user_tier, job_profile, agent_id, team, env, host, user), and strips client `x-portkey-*` and `Authorization` headers.
  - The webhook endpoint used by the Phase 1 guardrail.
- **`web`** (React + Vite + TS, OIDC SSO). It is built on `web/packages/ui`, with the AIG logo and the light/dark theme from Phase 0b. Pages:
  - **Agents**: one view of every agent across laptop, VDI and cloud, with status, owner, cost, and deep links to Fiddler and Portkey.
  - **MCP registry**: request, approve and list servers.
  - **Workspaces**: start a team workspace from a work item and watch its status.
  - **Models**: catalog, scorecards, the approval gate and canary controls.
  - **Evals**: run history and pass/fail against the baseline.
  - **Usage**: token and cost data per developer, team and tier (from Portkey analytics).
  - **Routing**: read-only view of `pc-aig-router`.
- **Exit:** a user signs in, registers an agent and sees its traffic and traces linked.

## Phase 5: AgentOps, evals gate and deployment
- **`aig eval`**:
  - Runs `fiddler-evals` (Python) on predefined or CSV datasets.
  - TS agents are evaluated by calling them over HTTP from a Python task wrapper, because the Evals SDK is Python-only.
  - Compares each run with the last approved baseline experiment.
- **Evals gate in CI** (`infra/ci/` reusable workflow): it runs on every PR that touches an agent, blocks the merge when scores fall below the baseline, and posts a summary and a Fiddler link on the PR.
- **Image build check**: the build fails if the image lacks `aig-sdk` / `@aig/sdk` at the pinned version, or if `aig doctor` fails inside the image. Images are hardened, with security baked in.
- **Deployment**: IaC deploys to **Bedrock AgentCore**. The path is dev → stage → prod, with stage tests before promotion. Runtimes get the Portkey key from secrets, and VPC egress is allowed only to Portkey and Fiddler.
- **Exit:** a PR that degrades evals is blocked, and a passing PR is promoted through the environments to AgentCore.

## Phase 6: Dev harness
- **AIG VSIX** (`vscode-extension`, built on `@aig/sdk`; its webviews use `web/packages/ui` and follow the VS Code theme):
  - SSO sign-in, then connects to the `platform-api` backend per environment (`aig.environment`, `aig.backendUrls` placeholders). It never holds a Portkey key; model calls go through the backend proxy.
  - `AIG: New agent` scaffolds a project through the templates and registers the agent.
  - It points the in-IDE coding assistant at Portkey.
  - A token-tracking panel shows usage per developer.
  - Commands run local evals.
  - It works with Floci for local AWS services.
  - **Tokenomics dashboard** (webview, opened after sign-in and from the status bar): active user count, total tokens, requests, cost, and token usage per model for 7/30/90 days. The backend fetches it from Portkey analytics with the admin key (`GET /api/v1/usage/dashboard`, user count only, no per-user rows).
  - **Local sign-in without SSO**: in the local environment, Sign In opens the backend's local sign-in page in the browser. Submitting it redirects back to `vscode://aig.aig-ai-ecosystem/auth-callback` (one-time state checked) and opens the dashboard.
- **AIG Eclipse plugin** (`eclipse-plugin`, Java 17, PDE/Tycho, p2 update site):
  - It has the same features as the VSIX: SSO sign-in, model calls through the `platform-api` backend proxy (no Portkey key on the client), agent scaffold and registration, a token-tracking view, and local eval commands.
  - A thin Java host calls `platform-api` and the `aig` CLI.
  - Model calls go to the backend's OpenAI-compatible proxy, which adds the key and the shared `backend/contracts/` headers server-side. A small Java contract-test suite runs against the same fixtures.
  - The UI panels reuse `web/packages/ui` through the SWT Browser, with AIG light and dark e4 themes.
- **Team workspace**:
  - A request comes from the Web UI or the Teams bot.
  - `workspace-orchestrator` provisions an ECS Fargate task with the starter pack and keys, then clones the repo.
  - The code agent runs through Portkey (Claude via the gateway base URL) and is traced to Fiddler.
  - Unit tests, functional tests and evals run in the task.
  - The agent commits and opens a PR linked to the issue.
  - The task spins down after the PR or after an idle timeout (value to confirm).
- **Exit:** both paths produce a PR with Portkey and Fiddler data from the first prompt onward.

## Phase 7: Model harness
- **Model request and catalog** entries live in `platform-api` and the UI.
- **Sandbox**: registering a model creates a **sandbox-only virtual key** in the Portkey model-sandbox workspace, with no route from production configs. Only synthetic or masked data is allowed.
- **Evals and red-teaming**: benchmark suites per job profile and safety suites (injection, jailbreak, data leakage) run through `fiddler-evals` with guardrails on.
- **Scorecard**: accuracy, faithfulness, safety, latency and cost. Cost comes from Portkey. Each is compared with the tier's current model.
- **Approval gate**: an approver role signs off in the UI, and the decision and its evidence go to the audit log.
- **Canary**: the `backend/gateway` sync adds a weighted load-balance target (canary share) to the tier's route, and Fiddler monitors it live.
- **Promote or roll back**: a one-step config change through PR plus sync. A rejected model never gets a production route.
- **Exit:** a candidate model goes from sandbox through the scorecard, approval and canary to promotion, and a rollback test passes.

---

## Sequencing
Phases 0 → 1 → 2 + 3 (in parallel, they share the contracts) → 4 → 5 → 6 and 7 (in parallel).

Phase 0b (design system) runs alongside Phases 1–3 and must finish before Phase 4 (Web UI) and Phase 6 (VSIX and Eclipse).

The first vertical slice to demo is: a LangGraph Python template, started with `aig init`, calls the model through Portkey and appears in Fiddler with the correct route and tags.

## Enforcement controls: who owns what
| Control | Implemented in |
|---|---|
| Startup check that fails closed | SDK `init()` (Phase 2) |
| Keys only in Portkey and the platform-api key broker | Virtual keys (Phase 1), raw-key guard (Phase 2), key broker and LLM proxy (Phase 4) |
| Egress allow-list | Network and security teams: device proxy, VDI policy, VPC rules (Phase 5 infra for cloud) |
| MCP registry and gateway | Phases 1 and 4 |
| Registered agent ID required | Required metadata plus webhook guardrail (Phase 1) |
| Daily reconciliation and suspension | `telemetry-bridge` (Phase 3) |
| Image build check | `infra/ci/` (Phase 5) |

## Open items to confirm (from the blueprint)
- Fiddler SDK versions to pin: `fiddler-langgraph`, `@fiddler-ai/langgraph`, `fiddler-evals` (all three are in Fiddler's docs, but their version ranges differ), plus which trust metrics are enabled and how alerts are routed.
- Real model IDs; the OpenAI deployment; the caching and compression host; and whether required metadata and webhook guardrails are available on the self-hosted Portkey version.
- Gate thresholds per tier, the model approver, and the canary share and duration.
- Contents of the VSIX and starter pack, the ECS image size, the workspace idle timeout, and the PR approver for code-agent PRs.
- Laptop device proxy and endpoint-management tooling, and who receives suspension alerts.
- Vector AIG logo files, AIG Futura font licence for internal apps (web, VSIX and Eclipse), sign-off on the suggested dark palette, the minimum Eclipse version to support, and the distribution channels (private VS Code marketplace or VSIX file, internal p2 update site).
- Who uploads and rotates the per-environment Portkey keys, and the rotation cadence.

## Verification
1. **Contract tests**: the Python and TS SDKs produce identical headers and tags against `backend/contracts/fixtures`.
2. **Routing matrix**: an integration test sends every tier × job_profile combination through the self-hosted gateway and asserts the served model, using Portkey logs and response headers.
3. **Fail-closed tests**: missing Fiddler config, a direct provider call, an unregistered MCP server and an unknown agent_id are each refused, matching the blueprint's enforcement table.
4. **End-to-end trace**: a template agent runs on a laptop, in an ECS workspace and on AgentCore. Each run shows one joined trace across Portkey and Fiddler with the correct env and host tags.
5. **Reconciliation**: an agent that sends Portkey traffic with no Fiddler data is suspended and its owner is alerted.
6. **Evals gate**: a seeded regression PR is blocked and a clean PR is promoted.
7. **Model harness**: a sandbox key cannot reach the production config, and canary, promotion and rollback work through config sync.
8. **UI**: Playwright smoke tests cover sign-in, agent registration, workspace launch and model approval.
9. **Theme and branding**:
   - Playwright visual snapshots of key Web UI pages in light and dark.
   - VS Code extension tests (`@vscode/test-electron`) open the webviews under Light+, Dark+ and High Contrast.
   - The Eclipse plugin is checked by hand under the Default and Dark themes.
   - Tokens pass the CI contrast check, and the AIG brand team signs off on logo use.
10. **Key isolation**: a scan finds no Portkey key or key-shaped string in the VSIX and Eclipse packages, and a proxy test shows client-supplied `x-portkey-*` headers are stripped before forwarding.
