# Demo data mode (temporary)

The web portal, the VS Code extension and the Eclipse plugin can show **sample data** instead of
live backend data. This is a temporary aid for the UI redesign: every screen is populated, with
numbers that move every few seconds, without a running platform-api, Portkey or Fiddler.

**Demo mode is off by default** on every surface: the dashboards show the signed-in user's own live
Portkey usage. Turn it on explicitly only for offline UI work. The switch code stays until demo mode
is removed (see below).

**It is never real data.** Whenever demo mode is on, a gold **Sample data** badge shows in the
header of every surface. The backend itself never returns sample data: usage endpoints still answer
`501 usage_not_configured` when Portkey is not configured.

## How it works

`web/packages/demo-data` (`@aig/demo-data`) is an in-memory emulation of platform-api. It provides
two drop-in transports for the SDK's backend client (`createPlatformClient` in
`sdk/typescript/src/platform`):

| Transport | What it does |
|---|---|
| `fetch` | Answers every `/api/v1/*` route: JSON responses, plus SSE for chat and agent runs. |
| `createSocket` | A fake WebSocket that speaks the live protocol: usage pushes, `chat.*` frames and `agent.*` frames. |

Hosts inject these two transports, so the pages, widgets and services run unchanged.

## Switches (default off)

| Surface | Switch | Where it is read |
|---|---|---|
| Web portal | `"demoData"` in `web/public/config.json` (shipped `false`; set `true` to turn it on) | `web/src/demo.ts` (one place: the authenticator and the API client) |
| VS Code | Setting `aig.demoData` (default `false`) | `vscode-extension/src/demo.ts` |
| Eclipse | Preference *Use sample data (temporary)* (`demoData`, default off; Window > Preferences > AIG AI Ecosystem) | Java: `AigServices.demoData()` → `LiveService` demo session + `BrowserPane` injects `window.__aigDemo = {"env": …}`; page: `eclipse-plugin/web/src/demoHost.ts` (the page's widget host, picked in `pageHost.ts`) |

In demo mode, **Sign In** starts a demo session straight away (user *Demo User*), with no browser
redirect and no backend call.

In Eclipse the sample data lives in the page, not in Java: `demoHost.ts` runs the web portal's browser
hosts (`web/src/live`) on the SDK client with the demo transports, and posts to Java only what needs
Eclipse (sign-in/out, open dashboard/preferences/environment, agent navigation, clipboard), handled by
`DemoBridge` (core bundle). The Run view gets `demo.open` / `demo.show` messages that the page resolves
against the sample catalog. The header badge is added at runtime (`addDemoBadge`).

VS Code: the demo session is a boolean flag in the extension's global state (no token is stored), so
it survives a window reload; **Sign Out** ends it. Toggling `aig.demoData` takes effect immediately
(config, status and sidebar re-initialise); an already open Dashboard or Run Agent tab picks up the
badge change when reopened.

## Removing demo mode

1. Delete `web/packages/demo-data/`.
2. Remove the `@aig/demo-data` aliases from `web/aliases.mjs`, `web/tsconfig.json`,
   `vscode-extension/aliases.mjs`, `vscode-extension/tsconfig.json` and `eclipse-plugin/web/build.mjs`
   (plus `eclipse-plugin/web/test/demoHost.test.mjs`).
3. Delete the three switch modules listed above and their call sites. Each call site is a single
   `if (demo…)` branch.
4. Remove the setting and preference: `aig.demoData` in `vscode-extension/package.json`, the Eclipse
   preference (`DEMO_DATA` in `PreferenceConstants` / `PreferenceInitializer` / `AigPreferencePage`, the
   `demoData()` branches in `AigServices`), and `demoData` from `web/public/config.json` and `web/src/config.ts`.
   In Eclipse also delete `DemoBridge` (+ `DemoBridgeTest`), the demo branches in `BrowserPane`,
   `AgentRunView` and `LiveService` (+ its two demo tests), and the demo branch in `eclipse-plugin/web/src/pageHost.ts`.
5. Remove the guard tests that pin the switch points: `web/src/guard.test.ts` ("demo data only via
   src/demo.ts") and the VS Code guard.

The **Sample data** badge (`.demo-badge`, and `demo` in `renderShell`) can stay; it renders nothing
when demo mode is off.

## Live data and manual multi-user testing (demo off)

- `GET /api/v1/usage/dashboard` returns only the caller's own usage (`scope: "user"`, `user`). Metrics
  Portkey refuses (`unavailable`: `tokens`, `cost`, `series`) render as "—" with one notice; the charts
  then use request counts.
- Nothing refreshes by itself: usage loads once when a dashboard opens (or on sign-in) and again only
  on the Refresh button/icon or a 7D/30D/90D change. "Last refreshed hh:mm:ss" shows next to Refresh.
- Local environment only: sign in as any email to test several users. Web portal: email field +
  persona chips on the sign-in page, **Switch user** in the account menu. VS Code: email field and
  persona picker in the sign-in view, **AIG: Sign in as…** and **AIG: Switch user**. Eclipse: email
  field in the sign-in view and **Switch User...**. Personas (`@aig.example`): premium.quality,
  premium.balanced, premium.economy, standard.quality, standard.balanced, free.quality, free.balanced,
  finance.user, routing.admin (admin). Unknown emails get tier standard / cost mode balanced.
