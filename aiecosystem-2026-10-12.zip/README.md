# AIG AI Ecosystem

Monorepo for the AIG AI Ecosystem: the platform that makes every AIG agent and MCP server,
whether on a laptop, a VDI or in the cloud, send model calls through the self-hosted
**Portkey** gateway and report to **Fiddler** ("no gateway, no Fiddler, no agent").

- Architecture: `docs/AIG AI Ecosystem_ architecture blueprint-8.html` (v3.2 draft)
- Build plan: [`docs/IMPLEMENTATION_PLAN.md`](docs/IMPLEMENTATION_PLAN.md)
- What is done and what is not: [`docs/PROGRESS.md`](docs/PROGRESS.md)
- Secrets rules: [`CONTRIBUTING.md`](CONTRIBUTING.md)

## Layout

```
aiecosystem/
├── web/                 React portal (+ web/packages: ui, design-tokens, brand-assets)
├── backend/             platform-api, telemetry-bridge, cache-compress, workspace-orchestrator,
│                        teams-bot, gateway (Portkey), observability (Fiddler), model-harness, contracts
├── vscode-extension/    VS Code extension (VSIX)
├── eclipse-plugin/      Eclipse plugin (Tycho)
├── sdk/                 python, typescript, templates (starter agents for `aig init`)
├── infra/               terraform, ci (image check, hardened Dockerfiles)
└── docs/  scripts/  .github/
```

| Path | Status | What it is |
|---|---|---|
| `web/` | **exists** (Phase 4) | React + Vite platform portal: Agents, MCP registry, Workspaces, Models (approval gate, canary, audit), Evals, Usage and Chat (embedded `@aig/ui` widgets), Routing viewer, Settings; Entra ID OIDC (PKCE) or local dev sign-in; nginx image with CSP |
| `web/packages/design-tokens/` | in progress | AIG brand tokens (light/dark) to CSS vars, TS, VS Code and Eclipse CSS |
| `web/packages/brand-assets/` | in progress | AIG logo set and app icons |
| `web/packages/ui/` | in progress | Shared React components and panels (web, VSIX webviews, Eclipse browser) |
| `backend/platform-api/` | **exists** | FastAPI key broker and OpenAI-compatible LLM proxy (HTTP + WebSocket), usage dashboard, local sign-in, Entra ID auth, agent registry + Portkey agent-check webhook |
| `backend/telemetry-bridge/` | **exists** (Phase 3) | Portkey logs (pull + push) and IDE usage events to Fiddler with the shared tags and trace id; daily Portkey/Fiddler reconciliation that suspends untraced agents; failing traces to eval CSVs; guardrail tickets |
| `backend/cache-compress/` | **exists** (Phase 1) | Caching and compression layer: pass-through proxy that every `pc-aig-router` leaf uses as `custom_host` (no caching; compression later) |
| `backend/workspace-orchestrator/` | **exists** (Phase 6) | Team workspaces: claims queued requests, one ECS Fargate task per workspace (`infra/ci/docker/workspace.Dockerfile`) where Claude Code fixes the work item through Portkey (traced to Fiddler), runs tests + evals and opens the PR; idle timeout / max runtime / cancel; relay so tasks never hold the service token. [README](backend/workspace-orchestrator/README.md), [docs/workspaces.md](docs/workspaces.md) |
| `backend/teams-bot/` | **exists** (Phase 6) | Microsoft Teams bot (botbuilder): start/status/list/cancel workspaces as the signed-in user (Teams SSO), proactive status cards from the orchestrator, Teams app manifest. [README](backend/teams-bot/README.md) |
| `backend/gateway/` | **exists** (Phase 1) | Portkey config-as-code (`pc-aig-router`, workspaces, keys, limits, guardrails, MCP registry) and the `aigw` sync tool |
| `backend/observability/` | **exists** (Phase 3) | Fiddler config-as-code (per-env projects, one application per agent, trust scores, monitors, alert routing) and the `fiddler-sync` tool |
| `backend/model-harness/` | **exists** (Phase 7) | Model harness: `aig-model eval` runs benchmark suites per job profile and red-team suites (synthetic data only) through `fiddler-evals` in the Portkey model sandbox, compares with the tier's current model, applies the per-tier gate thresholds and posts the scorecard to platform-api; canary / promote / rollback are `aigw canary` manifest PRs (`.github/workflows/model-canary.yml`). [README](backend/model-harness/README.md), [docs/model-harness.md](docs/model-harness.md) |
| `backend/contracts/` | **exists** | Single source of truth for headers, metadata, span tags, `AIG_*` variables, error codes and golden fixtures |
| `vscode-extension/` | **exists** | AIG VSIX: sign-in, sidebar, tokenomics dashboard, chat over WebSocket; holds no keys |
| `eclipse-plugin/` | planned (Phase 6) | AIG Eclipse plugin (Java, PDE/Tycho) |
| `sdk/python/` | done (Phase 2) | `aig-sdk` (`import aig_sdk`): fail-closed `init()`, Portkey gateway client, LangChain/Strands/OpenAI adapters, MCP gateway client, Fiddler tracing, `aig` CLI (`init`, `doctor`, `templates`, `eval`) |
| `sdk/typescript/` | done (Phase 2) | `@aig/sdk` (ESM + CJS): same API and contract; `@aig/sdk/langchain`, `@aig/sdk/mcp` (agent mode, the starter pack); `@aig/sdk/platform`: backend mode for the VS Code extension and the web portal (bearer token to platform-api only), see [`docs/sdk-modes.md`](docs/sdk-modes.md) |
| `sdk/templates/` | done (Phase 2) | Starter agents: langgraph-py, strands-py, langgraph-ts (scaffolded by `aig init`) |
| `infra/terraform/` | **exists** (Phase 5) | Terraform: network with the egress allow-list, KMS + Secrets Manager (placeholders only), ECR, Bedrock AgentCore runtimes, ECS Fargate platform services + RDS, alarms; envs dev/stage/prod; validated offline, not yet applied (see `docs/deploy.md`) |
| `infra/ci/` | **exists** (Phase 5) | Image build check (`infra/ci/image-check`, pinned SDK versions in `pins.json`), hardened agent image templates and AgentCore entrypoints (`infra/ci/docker`); workflows in `.github/workflows` (`image-check.yml`, `deploy-agent.yml`, `deploy-platform.yml`, `evals-gate.yml`) |
| `docs/` | **exists** | Progress tracker, deployment guide (`deploy.md`), evals (`evals.md`), workspaces (`workspaces.md`), model harness (`model-harness.md`) |
| `scripts/` | **exists** | Repo tooling (`test-all.sh`, `secrets-scan.sh`, `gateway-matrix-live.sh`) |
| `.github/` | **exists** | CI (contracts, backend, gateway, cache-compress, telemetry-bridge, fiddler, extension, packages, gitleaks), Dependabot, PR template |

## Prerequisites

- Python 3.12+ (backend and contracts)
- Node 22 (`nvm use` reads `.nvmrc`) and npm 10
- Optional: `gitleaks` 8.18.4 and `pre-commit` (see CONTRIBUTING.md)

```bash
make setup     # creates the Python venvs and runs npm ci in each Node project
```

Each Node project keeps its own `package-lock.json`. Because the root `package.json` declares
npm workspaces, run installs inside a project with `--workspaces=false`
(`make setup` does this), for example `cd vscode-extension && npm ci --workspaces=false`.

## Run the web portal locally

```bash
backend/platform-api/run-local.sh   # backend on :8080 (local dev auth)
make web-dev                         # http://localhost:3000, local dev sign-in (web/public/config.json)
make web-test                        # typecheck + vitest
make web-e2e                         # Playwright (installed Google Chrome) against vite preview + mock API
make web-e2e-real                    # Playwright against the real platform-api (temp SQLite)
```

Details: [`web/README.md`](web/README.md).

## Run the backend locally

```bash
backend/platform-api/run-local.sh          # start (AIG_ENV=local, dev auth, port 8080)
backend/platform-api/run-local.sh status   # health
backend/platform-api/run-local.sh logs     # follow the log
backend/platform-api/run-local.sh stop
```

Without real keys the LLM proxy answers `503 portkey_key_not_configured` and usage answers
`501 usage_not_configured`. To use a real self-hosted Portkey, copy
`backend/platform-api/secrets/local.env.example` to `secrets/.env.local` (gitignored), fill in
`PORTKEY_API_KEY` / `PORTKEY_ADMIN_API_KEY`, and point
`backend/platform-api/config/environments/local.yaml` at your gateway. Details:
[`backend/platform-api/README.md`](backend/platform-api/README.md).

## Build and install the VS Code extension

```bash
make vsix-package     # build + package; writes vscode-extension/aig-ai-ecosystem-<version>.vsix
code --install-extension vscode-extension/aig-ai-ecosystem-<version>.vsix
```

`.vsix` files are gitignored; CI uploads the packaged VSIX as the `aig-vsix` artifact. In VS
Code set `aig.environment` to `local` and run **AIG: Sign In**: the local backend's sign-in
page opens in the browser. Details: [`vscode-extension/README.md`](vscode-extension/README.md).

## Tests and checks

| Command | What it runs |
|---|---|
| `make test` | Every suite that exists: contracts check, pytest for each Python project with its own `.venv` (`backend/platform-api`, `backend/cache-compress`, `backend/telemetry-bridge`, `backend/workspace-orchestrator`, `backend/gateway/tool`, `backend/observability/tool`, `backend/model-harness`), `aigw validate` and `fiddler-sync validate` for every env, VS Code extension vitest, `web` vitest, `backend/teams-bot` vitest (Playwright runs separately: `make web-e2e`), each `web/packages/*` test script, `sdk/python` pytest, `sdk/typescript` vitest, the `sdk/templates/*` tests, the cross-SDK contract diff, and future `backend/*` suites automatically. Missing ones are skipped (`STRICT=1` fails instead) |
| `make contracts` | `backend/contracts/scripts/check_contracts.py` (schemas, fixtures, reference model) |
| `make sdk-py-test` / `make sdk-ts-test` | Python / TypeScript SDK suites |
| `make cross-sdk` | `scripts/cross-sdk-contract.sh`: both SDKs byte-identical on every `kind: sdk` fixture |
| `make templates-test` | Starter template tests (`make setup` installs them against the local SDKs) |
| `make template-run` | `scripts/template-local-run.sh`: the langgraph-py template against a local fake Portkey (`scripts/fake-portkey.py`), headers checked against `backend/contracts/` |
| `make lint` | JSON validity, ruff (if installed, else byte-compile), TypeScript typecheck / lint scripts |
| `make secrets-scan` | gitleaks over git history and every file git would track (skips with a hint if gitleaks is not installed) |
| `make harness-test`, `make harness-datasets`, `make harness-eval-offline` | Model harness tests (incl. the Phase 7 exit-criterion journey), the sandbox data-policy check, an offline smoke run (see [`docs/model-harness.md`](docs/model-harness.md)) |
| `make backend-test`, `make gateway-test`, `make cache-compress-test`, `make bridge-test`, `make fiddler-test`, `make vsix-test` | One component only |
| `make fiddler-validate`, `make fiddler-render ENV=local` | Validate / render the Fiddler config-as-code (see [`backend/observability/README.md`](backend/observability/README.md)) |
| `make gateway-validate`, `make gateway-render ENV=dev` | Validate / render the Portkey config-as-code (see [`backend/gateway/README.md`](backend/gateway/README.md)) |
| `scripts/gateway-matrix-live.sh` | Routing matrix against a real gateway (skips unless `AIG_PORTKEY_BASE_URL` and `AIG_PORTKEY_API_KEY` are set) |

CI (`.github/workflows/ci.yml`) runs the same suites on every push and pull request, with path
filters so a pull request only runs the jobs it affects.
