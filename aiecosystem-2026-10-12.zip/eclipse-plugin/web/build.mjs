#!/usr/bin/env node
/**
 * Generates the resources of com.aig.ai.ecosystem.ui (run by Maven during generate-resources, or by hand):
 *   web/{sidebar,dashboard,signin,agents,agentRun}.html  self-contained pages: @aig/ui widgets + Eclipse host shim as an
 *                                        esbuild IIFE inlined under a nonce CSP, logos as data: URIs
 *   css/aig-{light,dark}.css             e4 themes from web/packages/design-tokens (its build runs first)
 *   icons/aig16*.png, icons/dark/...     view/toolbar icons from web/packages/brand-assets
 *   templates/<name>/...                 starter templates from sdk/templates (built-in `aig init` fallback), without
 *                                        .venv / node_modules / caches / .env / .aig-wheels
 *   sdk/manifest.json + artifacts        SDK pins (aig-sdk / @aig/sdk versions) and the bundled aig-sdk wheel +
 *                                        @aig/sdk tarball (scripts/sdk-artifacts.mjs) for New Agent / Update SDK /
 *                                        Install aig CLI; AIG_SKIP_SDK_ARTIFACTS=1 writes the pins only
 * Usage: node build.mjs --out <ui bundle dir>    (default ../bundles/com.aig.ai.ecosystem.ui)
 * esbuild comes from this folder's node_modules (npm ci) or, failing that, the toolchains web/packages/ui
 * already uses (web/packages/ui/scripts/tool.mjs search path).
 */
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync, renameSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const REPO = resolve(HERE, '..', '..');
const UI = join(REPO, 'web', 'packages', 'ui');
const TOKENS = join(REPO, 'web', 'packages', 'design-tokens');
const BRAND = join(REPO, 'web', 'packages', 'brand-assets');
const TEMPLATES = join(REPO, 'sdk', 'templates');

const args = process.argv.slice(2);
const outIdx = args.indexOf('--out');
const OUT = resolve(outIdx >= 0 ? args[outIdx + 1] : join(HERE, '..', 'bundles', 'com.aig.ai.ecosystem.ui'));

function loadEsbuild() {
  const req = createRequire(import.meta.url);
  const own = join(HERE, 'node_modules', 'esbuild');
  if (existsSync(join(own, 'package.json'))) return req(own);
  return import(pathToFileURL(join(UI, 'scripts', 'tool.mjs')).href).then((m) => req(m.resolvePackage('esbuild')));
}

const esbuild = await loadEsbuild();
const alias = {
  '@aig/ui': join(UI, 'src', 'index.ts'),
  '@aig/design-tokens': join(TOKENS, 'src', 'index.ts'),
  // Pages bundle the portal's browser hosts (web/src/live) over the SDK client for the TEMPORARY demo-data
  // mode (src/demoHost.ts, docs/demo-data.md). Delete the demo-data line with web/packages/demo-data.
  '@aig/sdk/platform': join(REPO, 'sdk', 'typescript', 'src', 'platform', 'index.ts'),
  '@aig/demo-data': join(REPO, 'web', 'packages', 'demo-data', 'src', 'index.ts'),
};

// 1. Design tokens (e4 CSS) are generated output: build them first.
const tok = spawnSync(process.execPath, [join(TOKENS, 'scripts', 'build.mjs')], { stdio: 'inherit' });
if (tok.status !== 0) throw new Error('web/packages/design-tokens build failed');

// 2. Widget pages.
const tmp = join(HERE, '.build');
rmSync(tmp, { recursive: true, force: true });
mkdirSync(tmp, { recursive: true });
const pagesJs = join(tmp, 'pages.mjs');
await esbuild.build({ entryPoints: [join(HERE, 'src', 'pages.ts')], bundle: true, format: 'esm', platform: 'node', outfile: pagesJs, alias, logLevel: 'warning' });
const { page, APPS } = await import(pathToFileURL(pagesJs).href);
const dataUri = (file) => `data:image/svg+xml;base64,${readFileSync(file).toString('base64')}`;
const logoWhite = dataUri(join(BRAND, 'svg', 'aig-logo-white.svg'));
const logoColor = dataUri(join(BRAND, 'svg', 'aig-logo.svg'));
const fontUri = (f) => `data:font/woff2;base64,${readFileSync(join(BRAND, 'fonts', f)).toString('base64')}`;
const fonts = { inter: fontUri('inter-var.woff2'), mono: fontUri('jetbrains-mono-var.woff2') };

const webOut = join(OUT, 'web');
rmSync(webOut, { recursive: true, force: true });
mkdirSync(webOut, { recursive: true });
for (const app of APPS) {
  const r = await esbuild.build({
    entryPoints: [join(HERE, 'src', `${app}.ts`)],
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: 'es2020',
    minify: true,
    write: false,
    alias,
    legalComments: 'none',
    logLevel: 'warning',
  });
  const js = r.outputFiles[0].text;
  const html = page(app, js, logoWhite, logoColor, fonts);
  if (/\b(src|href)=["']https?:/i.test(html) || /url\(\s*['"]?https?:/i.test(html)) throw new Error(`${app}.html references a remote resource`);
  if (/pk-(live|test|admin)-[A-Za-z0-9]{8,}|x-portkey-api-key/i.test(html)) throw new Error(`${app}.html contains a Portkey key or key header`);
  writeFileSync(join(webOut, `${app}.html`), html);
}
rmSync(tmp, { recursive: true, force: true });

// 3. e4 themes.
const cssOut = join(OUT, 'css');
mkdirSync(cssOut, { recursive: true });
for (const f of ['aig-light.css', 'aig-dark.css']) cpSync(join(TOKENS, 'dist', 'eclipse', f), join(cssOut, f));

// 4. Icons (dark set under icons/dark/).
const iconsOut = join(OUT, 'icons');
rmSync(iconsOut, { recursive: true, force: true });
cpSync(join(BRAND, 'eclipse', 'icons'), iconsOut, { recursive: true });
cpSync(join(BRAND, 'svg', 'aig-icon.svg'), join(iconsOut, 'aig-icon.svg'));

// 5. Templates for the built-in scaffolder (same excludes as aig_sdk/cli.py DEFAULT_EXCLUDES, minus the manifest).
const EXCLUDE = new Set(['.venv', 'node_modules', '__pycache__', '.pytest_cache', '.ruff_cache', '.mypy_cache', 'dist', '.env', 'package-lock.json', '.aig-wheels', '.DS_Store']);
const tplOut = join(OUT, 'templates');
rmSync(tplOut, { recursive: true, force: true });
let copied = 0;
for (const name of readdirSync(TEMPLATES)) {
  const dir = join(TEMPLATES, name);
  if (!statSync(dir).isDirectory() || !existsSync(join(dir, 'aig-template.json'))) continue;
  cpSync(dir, join(tplOut, name), {
    recursive: true,
    filter: (src) => {
      const base = src.split(/[\\/]/).pop();
      return !EXCLUDE.has(base) && !base.endsWith('.egg-info');
    },
  });
  copied++;
}
if (copied === 0) throw new Error('no templates found under sdk/templates/');
// Maven/Tycho default excludes drop files like .gitignore from the jar; ship them as __dot__<name>.
// Templates.restoreDotName / restoreDotfiles map them back when scaffolding.
const DOT_KEEP = new Set(['.gitignore', '.gitattributes']);
(function renameDotfiles(dir) {
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) renameDotfiles(p);
    else if (DOT_KEEP.has(entry)) renameSync(p, join(dir, `__dot__${entry.slice(1)}`));
  }
})(tplOut);

// 6. SDK pins + bundled SDK artifacts (same files as the VSIX's dist/sdk/).
const { buildSdkArtifacts, sdkPins } = await import(pathToFileURL(join(REPO, 'scripts', 'sdk-artifacts.mjs')).href);
const sdkOut = join(OUT, 'sdk');
let sdkNote;
if (process.env.AIG_SKIP_SDK_ARTIFACTS === '1') {
  rmSync(sdkOut, { recursive: true, force: true });
  mkdirSync(sdkOut, { recursive: true });
  writeFileSync(join(sdkOut, 'manifest.json'), `${JSON.stringify({ pins: sdkPins(REPO) }, null, 2)}\n`);
  sdkNote = 'pins only (AIG_SKIP_SDK_ARTIFACTS=1)';
} else {
  const { manifest, total } = buildSdkArtifacts(REPO, sdkOut);
  writeFileSync(join(sdkOut, 'manifest.json'), `${JSON.stringify({ pins: sdkPins(REPO), ...manifest }, null, 2)}\n`);
  sdkNote = `${manifest.python.file} + ${manifest.typescript.file} (${Math.round(total / 1024)} KiB)`;
}

console.log(`aig-eclipse-web: wrote ${webOut} (${APPS.length} pages), ${cssOut}, ${iconsOut}, ${tplOut} (${copied} templates), ${sdkOut} (${sdkNote})`);
