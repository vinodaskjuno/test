/**
 * TEMPORARY demo-data host (docs/demo-data.md): the only Eclipse module that touches @aig/demo-data.
 *
 * With the Eclipse preference "Use sample data (temporary)" on, BrowserPane injects
 * `window.__aigDemo = {"env": "<env>"}` before the page script runs. The page then answers its widgets in
 * JS instead of over the Java bridge: the web portal's browser hosts (web/src/live: LiveService,
 * createWidgetHost, createAgentHost) run on the SDK client (`@aig/sdk/platform`) whose fetch and
 * WebSocket are the in-memory platform-api emulation of `@aig/demo-data`. Nothing touches the network.
 *
 * Still sent to Java (aigPost): ready (Java's whenReady), signIn / signOut / openDashboard / openPanel /
 * selectEnvironment, agent.open / agent.run.show / agent.register (cross-view navigation) and clipboard.copy.
 * Java answers navigation into the Run view with `demo.open` / `demo.show`, resolved here against the
 * demo catalog. Remove this file, pageHost.ts's demo branch and the Java DemoBridge to drop demo mode.
 */
import { createDemoBackend, DEMO_BASE_URL, DEMO_TEAM, DEMO_USER, type DemoBackendOptions } from '@aig/demo-data';
import { catalogAgentFromItem, runTargetFromCatalog, type AgentRunTarget, type HostMessage, type UsageLimits, type WebviewMessage, type WidgetHost } from '@aig/ui';
import { createApi, createClient, type Invocation } from '../../../web/src/api';
import { invocationMessages, createAgentHost } from '../../../web/src/live/agentHost';
import { LiveService } from '../../../web/src/live/liveService';
import { createWidgetHost } from '../../../web/src/live/widgetHost';
import { eclipseHost } from './eclipseHost';

export type DemoApp = 'sidebar' | 'dashboard' | 'signin' | 'agents' | 'agentRun';

interface DemoFlag {
  env?: string;
}
interface DemoWindow extends Window {
  __aigDemo?: boolean | DemoFlag;
}

/** True when the Java view switched this page to sample data. */
export function isDemo(w: DemoWindow = window as DemoWindow): boolean {
  return !!w.__aigDemo;
}

function demoEnv(w: DemoWindow = window as DemoWindow): string {
  const f = w.__aigDemo;
  const env = f && typeof f === 'object' && typeof f.env === 'string' ? f.env : 'dev';
  return /^(local|dev|stage|prod)$/.test(env) ? env : 'dev';
}

/** Adds the "Sample data" badge to the prebuilt header (renderShell `demo: true` markup). */
export function addDemoBadge(doc: Document = document): void {
  const right = doc.querySelector('.hdr .right');
  if (!right || right.querySelector('.demo-badge')) return;
  const b = doc.createElement('span');
  b.className = 'demo-badge';
  b.id = 'demo';
  b.title = 'Showing sample data, not live backend data';
  b.textContent = 'Sample data';
  right.insertBefore(b, right.firstChild);
}

/** sessionStorage stand-in (the SWT page is about:blank; widget state goes through Java's aigSaveState). */
const noStorage = { getItem: () => null, setItem() {}, removeItem() {}, clear() {}, key: () => null, length: 0 } as Storage;

const JAVA_CMDS = new Set(['signIn', 'signOut', 'openDashboard', 'openPanel', 'selectEnvironment', 'agent.open', 'agent.run.show', 'agent.register', 'clipboard.copy']);
const AGENT_CMDS = new Set(['catalog.refresh', 'agent.runs.refresh', 'agent.invoke', 'agent.cancel', 'agent.poll']);

/** Sample routing (platform-api tier + cost-based routing) for the chat route chip and the composer's "tier · costMode". */
export const DEMO_ROUTE = { user_tier: 'premium', cost_mode: 'quality' } as const;
export const DEMO_MODEL = 'us.anthropic.claude-sonnet-4-5-20250929-v1:0';

/** Fills tier / costMode on init and model / route on chat.done when the sample backend does not report them. */
export function withDemoRoute(m: HostMessage, jobProfile = 'general'): HostMessage {
  if (m.type === 'init') {
    return { ...m, info: { ...m.info, tier: m.info.tier ?? DEMO_ROUTE.user_tier, costMode: m.info.costMode ?? DEMO_ROUTE.cost_mode } };
  }
  if (m.type === 'chat.done') {
    return { ...m, model: m.model ?? DEMO_MODEL, route: m.route ?? { ...DEMO_ROUTE, job_profile: jobProfile } };
  }
  return m;
}

/** Sample usage limits (GET /api/v1/usage/limits) for the "Usage limits" card: within every limit (state normal). */
export function demoUsageLimits(now: Date = new Date()): UsageLimits {
  const day = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())).toISOString();
  const month = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString();
  return {
    user: DEMO_USER.email,
    user_tier: DEMO_ROUTE.user_tier,
    soft_threshold: 0.8,
    limits: { daily: { tokens: 400000, requests: 200 }, monthly: { cost_usd: 100 } },
    state: 'normal',
    configured: true,
    checks: [
      { period: 'daily', metric: 'tokens', limit: 400000, used: 126400, ratio: 0.316, status: 'ok', since: day },
      { period: 'daily', metric: 'requests', limit: 200, used: 58, ratio: 0.29, status: 'ok', since: day },
      { period: 'monthly', metric: 'cost_usd', limit: 100, used: 41.2, ratio: 0.412, status: 'ok', since: month },
    ],
    checked_at: now.toISOString(),
  };
}

export interface DemoHostOptions {
  /** Java bridge (default: the real Eclipse host shim; tests pass a fake). */
  java?: WidgetHost;
  env?: string;
  /** Extra demo backend options (tests: tickMs 0, streamDelayMs 0). */
  backend?: DemoBackendOptions;
}

export interface DemoWidgetHost extends WidgetHost {
  dispose(): void;
}

export function demoHost(app: DemoApp, o: DemoHostOptions = {}): DemoWidgetHost {
  const env = o.env ?? demoEnv();
  const java = o.java ?? eclipseHost();
  const backend = createDemoBackend({ ...o.backend, env });
  const api = createApi(
    createClient({ baseUrl: DEMO_BASE_URL, env, getToken: async () => backend.token, fetchImpl: backend.fetch, createSocket: backend.createSocket }),
  );
  const live = new LiveService({ api }, { env, user: DEMO_USER.email, team: DEMO_TEAM, jobProfiles: ['general'] });
  const listeners: Array<(m: HostMessage) => void> = [];
  let disposed = false;
  const deliver = (m: HostMessage) => {
    if (disposed) return;
    for (const l of [...listeners]) l(m);
  };

  const wantsUsage = app === 'sidebar' || app === 'dashboard';
  let jobProfile = 'general'; // last chat.send, for the sample chat.done route

  const widget = createWidgetHost(live, { usage: wantsUsage, onCommand: (cmd) => java.post({ cmd }), storage: noStorage });
  widget.onMessage((raw) => {
    // The sample usage limits come from this shim only (sendLimits), never twice.
    if (raw.type === 'usage.limits' || raw.type === 'usage.limits.error') return;
    deliver(withDemoRoute(raw, jobProfile));
  });
  // Loaded with the usage: on ready and on refresh / range change only (as the Java LiveService does).
  const sendLimits = () => {
    if (wantsUsage) deliver({ type: 'usage.limits', data: demoUsageLimits() });
  };
  // agent.open / agent.run.show / agent.register go to Java (JAVA_CMDS), which drives the Run view.
  const agents = createAgentHost(api, undefined);
  agents.onMessage(deliver);

  async function findTarget(agentId: string, pick: { env?: string; version?: string }): Promise<AgentRunTarget | undefined> {
    const list = await api.catalog.list({ q: agentId });
    const item = (list.items ?? []).map(catalogAgentFromItem).find((x) => x?.agentId === agentId);
    return item ? runTargetFromCatalog(item, pick) : undefined;
  }

  async function openTarget(agentId: string, pick: { env?: string; version?: string }) {
    try {
      const target = await findTarget(agentId, pick);
      deliver(target ? { type: 'agent.target', target } : { type: 'agent.target.error', code: 'agent_not_found', message: `${agentId} is not in the sample catalog.` });
    } catch (e) {
      deliver({ type: 'agent.target.error', code: 'error', message: e instanceof Error ? e.message : String(e) });
    }
  }

  async function showInvocation(invocationId: string) {
    try {
      const inv = (await api.invocations.get(invocationId)) as Invocation;
      const target = (await findTarget(inv.agent_id, { env: inv.env, version: inv.version })) ?? {
        agentId: inv.agent_id,
        name: inv.agent_id,
        versions: [{ env: inv.env, version: inv.version, kind: 'https', verified: true }],
        version: inv.version,
        env: inv.env,
      };
      deliver({ type: 'agent.target', target: target as AgentRunTarget });
      const localId = `show-${invocationId}`.slice(0, 64);
      for (const x of invocationMessages(localId, inv)) deliver(x);
    } catch (e) {
      deliver({ type: 'agent.target.error', code: (e as { code?: string })?.code ?? 'error', message: e instanceof Error ? e.message : String(e) });
    }
  }

  // Java -> page: navigation requests for the Run view and tab switches; Java's sign-in status is replaced.
  java.onMessage((raw) => {
    const m = raw as unknown as { type: string; agentId?: unknown; env?: unknown; version?: unknown; invocationId?: unknown };
    if (m.type === 'demo.open' && typeof m.agentId === 'string') {
      void openTarget(m.agentId, { env: typeof m.env === 'string' ? m.env : undefined, version: typeof m.version === 'string' ? m.version : undefined });
    } else if (m.type === 'demo.show' && typeof m.invocationId === 'string') {
      void showInvocation(m.invocationId);
    } else if (m.type !== 'status') {
      deliver(raw);
    }
  });

  live.start();

  return {
    post(msg: WebviewMessage) {
      if (disposed) return;
      const cmd = msg.cmd;
      if (cmd === 'ready') {
        if (app === 'signin') {
          deliver({ type: 'status', env, tone: 'ok', label: 'Sample data', detail: `Sample data (${env}): Sign In starts a demo session as ${DEMO_USER.name}, no backend needed`, method: 'devUser' });
        } else {
          widget.post(msg); // init, live status, usage (dashboard widgets)
          sendLimits();
        }
        java.post(msg); // Java's whenReady (run targets)
      } else if (cmd === 'range' || cmd === 'refresh') {
        widget.post(msg);
        sendLimits();
      } else if (cmd === 'chat.send' || cmd === 'chat.cancel') {
        if (msg.cmd === 'chat.send' && msg.jobProfile) jobProfile = msg.jobProfile;
        widget.post(msg);
      } else if (AGENT_CMDS.has(cmd)) {
        agents.post(msg);
      } else if (JAVA_CMDS.has(cmd)) {
        java.post(msg);
      }
    },
    onMessage(cb) {
      listeners.push(cb);
    },
    getState: () => java.getState?.(),
    setState: (s: unknown) => java.setState?.(s),
    dispose() {
      disposed = true;
      widget.dispose();
      agents.dispose();
      live.stop();
      backend.stop();
      listeners.length = 0;
    },
  };
}
