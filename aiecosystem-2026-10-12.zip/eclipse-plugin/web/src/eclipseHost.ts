/**
 * Eclipse SWT Browser host for the @aig/ui widgets: the WidgetHost contract over the Java <-> JS bridge.
 *   widget -> Java : window.aigPost(json)       (an SWT BrowserFunction installed by the view)
 *   Java -> widget : window.__aigReceive(msg)   (browser.execute from the view)
 *   theme          : window.__aigTheme(kind)    (light | dark | hc | hc-light; follows the Eclipse theme)
 *   state          : window.aigSaveState(json)  (BrowserFunction; restored as window.__aigInitialState)
 * Nothing here talks to the network: the page has no remote resources and a nonce CSP.
 */
import { parseDashboard, type HostMessage, type WebviewMessage, type WidgetHost } from '@aig/ui';

type Fn = (json: string) => unknown;
interface AigWindow extends Window {
  aigPost?: Fn;
  aigSaveState?: Fn;
  __aigReceive?: (m: unknown) => void;
  __aigTheme?: (kind: string) => void;
  __aigInitialState?: unknown;
}

const w = window as AigWindow;
const THEME_CLASSES = ['vscode-light', 'vscode-dark', 'vscode-high-contrast', 'vscode-high-contrast-light', 'eclipse-light', 'eclipse-dark', 'eclipse-hc'];

/** Maps the Eclipse theme kind onto the body classes the shared stylesheet understands. */
export function themeClasses(kind: string): string[] {
  switch (kind) {
    case 'dark':
      return ['vscode-dark', 'eclipse-dark'];
    case 'hc':
      return ['vscode-high-contrast', 'eclipse-hc'];
    case 'hc-light':
      return ['vscode-high-contrast-light', 'eclipse-hc'];
    default:
      return ['vscode-light', 'eclipse-light'];
  }
}

/**
 * High contrast in the shared stylesheet defers to VS Code's --vscode-* variables. Eclipse has none,
 * so map them to CSS system colours (the OS high-contrast palette). Set through CSSOM, which the
 * nonce CSP allows.
 */
const HC_VARS: Record<string, string> = {
  '--vscode-editor-background': 'Canvas',
  '--vscode-editor-foreground': 'CanvasText',
  '--vscode-descriptionForeground': 'CanvasText',
  '--vscode-textLink-foreground': 'LinkText',
  '--vscode-textLink-activeForeground': 'LinkText',
  '--vscode-contrastBorder': 'CanvasText',
  '--vscode-focusBorder': 'Highlight',
  '--vscode-errorForeground': 'CanvasText',
  '--vscode-button-background': 'ButtonFace',
  '--vscode-button-foreground': 'ButtonText',
};

export function applyTheme(kind: string): void {
  const b = document.body;
  b.classList.remove(...THEME_CLASSES);
  b.classList.add(...themeClasses(kind));
  b.dataset.aigTheme = kind;
  const hc = kind === 'hc' || kind === 'hc-light';
  for (const [k, v] of Object.entries(HC_VARS)) {
    if (hc) b.style.setProperty(k, v);
    else b.style.removeProperty(k);
  }
}

/** Normalises host messages before they reach a widget (usage data goes through parseDashboard). */
export function normalize(raw: unknown): HostMessage | undefined {
  let m: unknown = raw;
  if (typeof raw === 'string') {
    try {
      m = JSON.parse(raw);
    } catch {
      return undefined;
    }
  }
  if (!m || typeof m !== 'object' || typeof (m as { type?: unknown }).type !== 'string') return undefined;
  const msg = m as HostMessage;
  if (msg.type === 'usage') {
    const parsed = parseDashboard((msg as { data: unknown }).data);
    return parsed.ok ? { ...msg, data: parsed.data } : { type: 'usage.error', code: 'invalid_dashboard', message: parsed.reason };
  }
  return msg;
}

export function eclipseHost(): WidgetHost {
  const listeners: Array<(m: HostMessage) => void> = [];
  const queue: string[] = [];
  let timer: ReturnType<typeof setInterval> | undefined;
  let state: unknown = w.__aigInitialState;

  // BrowserFunctions are (re)installed by SWT once the page loads; queue until they exist.
  const flush = (): boolean => {
    if (typeof w.aigPost !== 'function') return false;
    while (queue.length) w.aigPost(queue.shift()!);
    if (timer) clearInterval(timer);
    timer = undefined;
    return true;
  };

  w.__aigReceive = (raw: unknown) => {
    const m = normalize(raw);
    if (!m) return;
    for (const cb of listeners) cb(m);
  };
  w.__aigTheme = applyTheme;

  return {
    post(msg: WebviewMessage) {
      queue.push(JSON.stringify(msg));
      if (!flush() && !timer) timer = setInterval(flush, 50);
    },
    onMessage(cb) {
      listeners.push(cb);
    },
    getState: () => state,
    setState(s: unknown) {
      state = s;
      if (typeof w.aigSaveState === 'function') w.aigSaveState(JSON.stringify(s));
    },
  };
}

export const appRoot = (): HTMLElement => document.getElementById('app')!;
