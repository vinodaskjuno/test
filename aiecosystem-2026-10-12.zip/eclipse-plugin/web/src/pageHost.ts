/** The widget host of a page: the Eclipse Java bridge, or (TEMPORARY, docs/demo-data.md) the in-page sample-data host. */
import type { WidgetHost } from '@aig/ui';
import { addDemoBadge, demoHost, isDemo, type DemoApp } from './demoHost';
import { eclipseHost } from './eclipseHost';

export function pageHost(app: DemoApp): WidgetHost {
  if (isDemo()) {
    addDemoBadge();
    return demoHost(app);
  }
  return eclipseHost();
}
