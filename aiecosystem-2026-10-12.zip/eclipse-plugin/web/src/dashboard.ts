/** Eclipse dashboard page: the @aig/ui widget on the Eclipse host bridge. */
import { mountDashboard } from '@aig/ui';
import { appRoot, applyTheme } from './eclipseHost';
import { pageHost } from './pageHost';

applyTheme(document.body.dataset.aigTheme ?? 'light');
mountDashboard(appRoot(), pageHost('dashboard'));
