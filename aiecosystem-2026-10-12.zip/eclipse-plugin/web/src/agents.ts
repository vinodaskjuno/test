/** Eclipse "AIG Agents" page: the @aig/ui agent catalog (search, team/tag filters, Run, Register, My recent runs) on the Eclipse host bridge. */
import { mountCatalog } from '@aig/ui';
import { appRoot, applyTheme } from './eclipseHost';
import { pageHost } from './pageHost';

applyTheme(document.body.dataset.aigTheme ?? 'light');
mountCatalog(appRoot(), pageHost('agents'), { compact: true });
