/** Node-side page generation (run by build.mjs): the real @aig/ui renderShell with an inline script. */
import { renderShell } from '@aig/ui';

export const NONCE_PLACEHOLDER = 'aig-runtime-nonce-0000000000000000';
export const SCRIPT_PLACEHOLDER = 'aig-inline-script.js';

const TITLES = {
  sidebar: { title: 'AIG AI Ecosystem', headerTitle: 'AI Ecosystem', headerSub: 'Token usage · Chat' },
  dashboard: { title: 'AIG Dashboard', headerTitle: 'Tokenomics', headerSub: 'Token usage across the AIG model gateway' },
  signin: { title: 'AIG AI Ecosystem', headerTitle: 'AI Ecosystem', headerSub: 'Welcome' },
  agents: { title: 'AIG Agents', headerTitle: 'Agents', headerSub: 'Agents you can run' },
  agentRun: { title: 'AIG Run', headerTitle: 'Run agent', headerSub: 'Form or chat · streamed output' },
} as const;

export type App = keyof typeof TITLES;
export const APPS = Object.keys(TITLES) as App[];

/** renderShell layout per page: the Agents view is a narrow side view, the Run view an editor-style page. */
const SHELL_APP: Record<App, 'sidebar' | 'dashboard' | 'signin' | 'agents' | 'agentrun'> = {
  sidebar: 'sidebar',
  dashboard: 'dashboard',
  signin: 'signin',
  agents: 'agents',
  agentRun: 'agentrun',
};

/**
 * Self-contained page: CSS and JS inline (nonce CSP, default-src 'none'), logos and fonts as data: URIs,
 * no remote resource of any kind. The Java view replaces the nonce placeholder per load.
 */
export function page(app: App, js: string, logoWhite: string, logoColor: string, fonts?: { inter: string; mono: string }): string {
  const html = renderShell({
    ...TITLES[app],
    app: SHELL_APP[app],
    nonce: NONCE_PLACEHOLDER,
    cspSource: "'self'",
    scriptUri: SCRIPT_PLACEHOLDER,
    logoWhiteUri: logoWhite,
    logoColorUri: logoColor,
    env: '',
    ...(fonts ? { fontUris: fonts } : {}),
  });
  const tag = `<script nonce="${NONCE_PLACEHOLDER}" src="${SCRIPT_PLACEHOLDER}"></script>`;
  if (!html.includes(tag)) throw new Error('renderShell output changed: script tag not found');
  const safe = js.replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--');
  return html.replace(tag, () => `<script nonce="${NONCE_PLACEHOLDER}">${safe}</script>`);
}
