/** Eclipse sidebar page: the @aig/ui widget on the Eclipse host bridge. */
import { mountSidebar } from '@aig/ui';
import { appRoot, applyTheme } from './eclipseHost';
import { pageHost } from './pageHost';

applyTheme(document.body.dataset.aigTheme ?? 'light');
mountSidebar(appRoot(), pageHost('sidebar'));
