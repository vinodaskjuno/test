/** Eclipse signin page: the @aig/ui widget on the Eclipse host bridge. */
import { mountSignin } from '@aig/ui';
import { appRoot, applyTheme } from './eclipseHost';
import { pageHost } from './pageHost';

applyTheme(document.body.dataset.aigTheme ?? 'light');
mountSignin(appRoot(), pageHost('signin'));
