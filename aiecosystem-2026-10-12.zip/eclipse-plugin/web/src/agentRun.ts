/** Eclipse "AIG Run" page: the @aig/ui run widget (form from the input schema or chat, streamed output, background runs). The Java view sends agent.target. */
import { mountAgentRun } from '@aig/ui';
import { appRoot, applyTheme } from './eclipseHost';
import { pageHost } from './pageHost';

applyTheme(document.body.dataset.aigTheme ?? 'light');
mountAgentRun(appRoot(), pageHost('agentRun'), { compact: false });
