/**
 * TEMPORARY demo-data host (src/demoHost.ts, docs/demo-data.md): the page answers the widgets from the in-memory
 * platform-api emulation and forwards only navigation to Java. Run: npm test (bundles the module with esbuild).
 */
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const REPO = resolve(HERE, '..', '..', '..');
let mod;
let dir;

before(async () => {
  const esbuild = createRequire(import.meta.url)(join(HERE, '..', 'node_modules', 'esbuild'));
  dir = mkdtempSync(join(tmpdir(), 'aig-demohost-'));
  const out = join(dir, 'demoHost.mjs');
  await esbuild.build({
    entryPoints: [join(HERE, '..', 'src', 'demoHost.ts')],
    bundle: true,
    format: 'esm',
    platform: 'node',
    outfile: out,
    logLevel: 'warning',
    alias: {
      '@aig/ui': join(REPO, 'web', 'packages', 'ui', 'src', 'index.ts'),
      '@aig/design-tokens': join(REPO, 'web', 'packages', 'design-tokens', 'src', 'index.ts'),
      '@aig/sdk/platform': join(REPO, 'sdk', 'typescript', 'src', 'platform', 'index.ts'),
      '@aig/demo-data': join(REPO, 'web', 'packages', 'demo-data', 'src', 'index.ts'),
    },
  });
  globalThis.window ??= globalThis; // eclipseHost.ts reads window at module load
  mod = await import(pathToFileURL(out).href);
});
after(() => dir && rmSync(dir, { recursive: true, force: true }));

function fakeJava() {
  const posts = [];
  const subs = [];
  return { posts, send: (m) => subs.forEach((cb) => cb(m)), host: { post: (m) => posts.push(m), onMessage: (cb) => subs.push(cb), getState: () => undefined, setState() {} } };
}

function setup(app) {
  const java = fakeJava();
  const host = mod.demoHost(app, { env: 'dev', java: java.host, backend: { tickMs: 0, streamDelayMs: [0, 0], latencyMs: [0, 0] } });
  const got = [];
  host.onMessage((m) => got.push(m));
  const until = async (pred, ms = 5000) => {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      const hit = got.find(pred);
      if (hit) return hit;
      await new Promise((r) => setTimeout(r, 10));
    }
    throw new Error(`timed out; got ${got.map((m) => m.type).join(', ')}`);
  };
  return { java, host, got, until };
}

test('isDemo reads window.__aigDemo', () => {
  assert.equal(mod.isDemo({}), false);
  assert.equal(mod.isDemo({ __aigDemo: { env: 'dev' } }), true);
  assert.equal(mod.isDemo({ __aigDemo: true }), true);
});

test('sidebar: ready gives init and usage (never usage.me); range switches; ready also reaches Java', async () => {
  const { java, host, until, got } = setup('sidebar');
  host.post({ cmd: 'ready' });
  const init = await until((m) => m.type === 'init');
  assert.equal(init.info.env, 'dev');
  assert.equal(typeof init.info.tier, 'string', 'composer shows tier · costMode');
  assert.equal(typeof init.info.costMode, 'string');
  const usage = await until((m) => m.type === 'usage');
  assert.ok(usage.data.models.length > 0);
  const limits = await until((m) => m.type === 'usage.limits');
  assert.equal(limits.data.configured, true);
  assert.equal(limits.data.state, 'normal');
  assert.ok(limits.data.checks.length > 0);
  assert.deepEqual(java.posts, [{ cmd: 'ready' }]);
  got.length = 0;
  host.post({ cmd: 'range', days: 7 });
  await until((m) => m.type === 'usage' && m.range === 7);
  assert.equal(got.filter((m) => m.type === 'usage.limits').length, 1, 'a range change reloads the limits once');
  assert.ok(!got.some((m) => m.type === 'usage.me' || m.type === 'usage.me.error'), '/usage/me is not called');
  host.dispose();
});

test('sidebar: chat streams deltas and completes', async () => {
  const { host, until, got } = setup('sidebar');
  host.post({ cmd: 'ready' });
  await until((m) => m.type === 'live' && m.status === 'open');
  host.post({ cmd: 'chat.send', localId: 'c1', messages: [{ role: 'user', content: 'What did we spend on tokens?' }], jobProfile: 'general' });
  const done = await until((m) => m.type === 'chat.done' && m.localId === 'c1');
  assert.ok(typeof done.model === 'string' && done.model.length > 0, 'route chip: served model');
  assert.equal(typeof done.route?.user_tier, 'string');
  assert.ok(got.some((m) => m.type === 'chat.delta' && m.localId === 'c1'));
  host.dispose();
});

test('agents: catalog, recent runs and a streamed run; navigation goes to Java', async () => {
  const { java, host, until } = setup('agents');
  host.post({ cmd: 'ready' });
  host.post({ cmd: 'catalog.refresh' });
  const cat = await until((m) => m.type === 'catalog');
  assert.ok(cat.items.length > 10);
  host.post({ cmd: 'agent.runs.refresh' });
  await until((m) => m.type === 'agent.runs');
  const id = cat.items[0].agentId;
  host.post({ cmd: 'agent.invoke', localId: 'r1', agentId: id, mode: 'stream', messages: [{ role: 'user', content: 'hello' }] });
  const done = await until((m) => m.type === 'agent.done' && m.localId === 'r1');
  assert.equal(done.status, 'succeeded');
  host.post({ cmd: 'agent.open', agentId: id });
  host.post({ cmd: 'signOut' });
  assert.deepEqual(java.posts.slice(1), [{ cmd: 'agent.open', agentId: id }, { cmd: 'signOut' }]);
  host.dispose();
});

test('agentRun: Java demo.open / demo.show resolve against the demo catalog', async () => {
  const { java, host, until, got } = setup('agentRun');
  host.post({ cmd: 'ready' });
  java.send({ type: 'demo.open', agentId: 'claims-triage' });
  const t = await until((m) => m.type === 'agent.target');
  assert.equal(t.target.agentId, 'claims-triage');
  java.send({ type: 'demo.open', agentId: 'no-such-agent' });
  await until((m) => m.type === 'agent.target.error');
  host.post({ cmd: 'agent.runs.refresh' });
  const runs = await until((m) => m.type === 'agent.runs' && m.runs.length > 0);
  const inv = runs.runs[0].invocationId;
  java.send({ type: 'demo.show', invocationId: inv });
  await until((m) => m.type === 'agent.status' && m.localId === `show-${inv}`.slice(0, 64));
  java.send({ type: 'tab', tab: 'chat' });
  assert.ok(got.some((m) => m.type === 'tab'));
  host.dispose();
});

test('signin: sample-data status replaces Java status; Sign In goes to Java', async () => {
  const { java, host, until, got } = setup('signin');
  host.post({ cmd: 'ready' });
  const s = await until((m) => m.type === 'status');
  assert.equal(s.tone, 'ok');
  java.send({ type: 'status', env: 'dev', tone: 'bad', label: 'Not configured', detail: '', method: 'unconfigured' });
  assert.equal(got.filter((m) => m.type === 'status').length, 1);
  host.post({ cmd: 'signIn' });
  assert.deepEqual(java.posts, [{ cmd: 'ready' }, { cmd: 'signIn' }]);
  host.dispose();
});
