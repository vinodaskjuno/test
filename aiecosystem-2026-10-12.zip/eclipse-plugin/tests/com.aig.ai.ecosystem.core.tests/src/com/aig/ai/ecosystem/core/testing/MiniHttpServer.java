package com.aig.ai.ecosystem.core.testing;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

/**
 * Tiny HTTP/1.1 test server on 127.0.0.1 (no com.sun.net.httpserver, which is outside the OSGi
 * execution environment). Records requests; responses may be streamed as chunks (chunked encoding).
 */
public final class MiniHttpServer implements AutoCloseable {
  public record Request(String method, String target, Map<String, String> headers, List<String> headerNames, String body) {
    public String path() {
      int q = target.indexOf('?');
      return q < 0 ? target : target.substring(0, q);
    }

    public String query() {
      int q = target.indexOf('?');
      return q < 0 ? "" : target.substring(q + 1);
    }
  }

  public record Response(int status, Map<String, String> headers, List<String> chunks) {
    public static Response json(int status, String body) {
      return new Response(status, Map.of("content-type", "application/json"), List.of(body));
    }

    public static Response sse(String... chunks) {
      return new Response(200, Map.of("content-type", "text/event-stream"), List.of(chunks));
    }
  }

  private final ServerSocket server;
  private final Function<Request, Response> handler;
  private final List<Request> requests = Collections.synchronizedList(new ArrayList<>());
  private final Thread thread;

  public MiniHttpServer(Function<Request, Response> handler) throws IOException {
    this.handler = handler;
    this.server = new ServerSocket();
    server.bind(new InetSocketAddress(InetAddress.getByAddress(new byte[] {127, 0, 0, 1}), 0));
    thread = new Thread(this::loop, "mini-http");
    thread.setDaemon(true);
    thread.start();
  }

  public String baseUrl() {
    return "http://127.0.0.1:" + server.getLocalPort();
  }

  public List<Request> requests() {
    synchronized (requests) {
      return new ArrayList<>(requests);
    }
  }

  public Request last() {
    List<Request> r = requests();
    return r.isEmpty() ? null : r.get(r.size() - 1);
  }

  private void loop() {
    while (!server.isClosed()) {
      try (Socket s = server.accept()) {
        handle(s);
      } catch (IOException e) {
        // closed or client error
      }
    }
  }

  private static String readLine(InputStream in) throws IOException {
    ByteArrayOutputStream b = new ByteArrayOutputStream();
    int c;
    while ((c = in.read()) >= 0) {
      if (c == '\n') break;
      if (c != '\r') b.write(c);
    }
    return c < 0 && b.size() == 0 ? null : b.toString(StandardCharsets.ISO_8859_1);
  }

  private void handle(Socket s) throws IOException {
    InputStream in = s.getInputStream();
    String line = readLine(in);
    if (line == null) return;
    String[] parts = line.split(" ");
    Map<String, String> headers = new LinkedHashMap<>();
    List<String> names = new ArrayList<>();
    String h;
    while ((h = readLine(in)) != null && !h.isEmpty()) {
      int colon = h.indexOf(':');
      String name = h.substring(0, colon).trim();
      names.add(name);
      headers.put(name.toLowerCase(Locale.ROOT), h.substring(colon + 1).trim());
    }
    int len = Integer.parseInt(headers.getOrDefault("content-length", "0"));
    byte[] body = in.readNBytes(len);
    Request req = new Request(parts[0], parts[1], headers, names, new String(body, StandardCharsets.UTF_8));
    requests.add(req);
    Response res = handler.apply(req);
    OutputStream out = s.getOutputStream();
    StringBuilder head = new StringBuilder("HTTP/1.1 " + res.status() + " X\r\n");
    res.headers().forEach((k, v) -> head.append(k).append(": ").append(v).append("\r\n"));
    head.append("transfer-encoding: chunked\r\nconnection: close\r\n\r\n");
    out.write(head.toString().getBytes(StandardCharsets.ISO_8859_1));
    out.flush();
    for (String chunk : res.chunks()) {
      byte[] b = chunk.getBytes(StandardCharsets.UTF_8);
      if (b.length == 0) continue;
      out.write((Integer.toHexString(b.length) + "\r\n").getBytes(StandardCharsets.ISO_8859_1));
      out.write(b);
      out.write("\r\n".getBytes(StandardCharsets.ISO_8859_1));
      out.flush();
    }
    out.write("0\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1));
    out.flush();
  }

  @Override
  public void close() throws IOException {
    server.close();
  }
}
