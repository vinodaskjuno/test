package com.aig.ai.ecosystem.core.http;

import static org.junit.jupiter.api.Assertions.*;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class SseParserTest {
  @Test
  void parsesEventsAcrossChunks() {
    SseParser p = new SseParser();
    assertTrue(p.feed("data: {\"a\"").isEmpty());
    List<SseEvent> ev = p.feed(":1}\n\nevent: x\nid: 7\ndata: one\ndata: two\n\n");
    assertEquals(2, ev.size());
    assertEquals("{\"a\":1}", ev.get(0).data());
    assertNull(ev.get(0).event());
    assertEquals("x", ev.get(1).event());
    assertEquals("7", ev.get(1).id());
    assertEquals("one\ntwo", ev.get(1).data());
  }

  @Test
  void handlesCrLfSplitAcrossChunksAndComments() {
    SseParser p = new SseParser();
    List<SseEvent> all = new ArrayList<>();
    all.addAll(p.feed(": keepalive\r\ndata: a\r"));
    all.addAll(p.feed("\n\r\ndata:b\r\rdata: [DONE]\n\n"));
    assertEquals(List.of("a", "b", "[DONE]"), all.stream().map(SseEvent::data).toList());
    assertTrue(all.get(2).isDone());
  }

  @Test
  void endFlushesUnterminatedEvent() {
    SseParser p = new SseParser();
    assertTrue(p.feed("data: tail").isEmpty());
    List<SseEvent> ev = p.end();
    assertEquals(1, ev.size());
    assertEquals("tail", ev.get(0).data());
    assertTrue(p.end().isEmpty());
  }

  @Test
  void fieldWithoutColonAndEmptyEvent() {
    SseParser p = new SseParser();
    assertTrue(p.feed("event: only\n\n").isEmpty());
    List<SseEvent> ev = p.feed("data\n\n");
    assertEquals("", ev.get(0).data());
  }

  @Test
  void chunkHelpers() {
    assertEquals("Hi", ChatChunks.deltaText("{\"choices\":[{\"delta\":{\"content\":\"H\"}},{\"delta\":{\"content\":\"i\"}}]}"));
    assertEquals("full", ChatChunks.deltaText("{\"choices\":[{\"message\":{\"content\":\"full\"}}]}"));
    assertEquals("", ChatChunks.deltaText("not json"));
    assertEquals("boom", ChatChunks.streamError("{\"error\":{\"message\":\"boom\"}}"));
    assertEquals("rate_limited", ChatChunks.streamError("{\"error\":{\"code\":\"rate_limited\"}}"));
    assertNull(ChatChunks.streamError("{\"choices\":[]}"));
  }

  @Test
  void readStreamCollectsDeltasUntilDone() throws Exception {
    String body = "data: {\"choices\":[{\"delta\":{\"content\":\"Hel\"}}]}\n\n"
        + "data: {\"choices\":[{\"delta\":{\"content\":\"lo\"}}]}\n\ndata: [DONE]\n\ndata: {\"choices\":[{\"delta\":{\"content\":\"ignored\"}}]}\n\n";
    List<String> deltas = new ArrayList<>();
    BackendClient.ChatResult r = BackendClient.readStream(new StringReader(body), "t", deltas::add, () -> false);
    assertEquals("Hello", r.text());
    assertTrue(r.complete());
    assertEquals(List.of("Hel", "lo"), deltas);
  }

  @Test
  void readStreamWithoutDoneIsIncompleteAndErrorsThrow() throws Exception {
    BackendClient.ChatResult r = BackendClient.readStream(new StringReader("data: {\"choices\":[{\"delta\":{\"content\":\"x\"}}]}"), "t", null, null);
    assertEquals("x", r.text());
    assertFalse(r.complete());
    BackendException e = assertThrows(BackendException.class,
        () -> BackendClient.readStream(new StringReader("data: {\"error\":{\"message\":\"upstream\"}}\n\n"), "t9", null, null));
    assertEquals("stream_error", e.code());
    assertEquals("t9", e.traceId());
  }
}
