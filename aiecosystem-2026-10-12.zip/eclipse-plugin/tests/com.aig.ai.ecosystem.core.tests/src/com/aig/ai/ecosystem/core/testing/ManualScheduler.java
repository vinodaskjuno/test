package com.aig.ai.ecosystem.core.testing;

import com.aig.ai.ecosystem.core.ws.AigSocket;
import java.util.ArrayList;
import java.util.List;

/** Collects scheduled tasks; tests run them explicitly. */
public final class ManualScheduler implements AigSocket.Scheduler {
  public static final class Task implements AigSocket.Cancellable {
    public final Runnable run;
    public final long delayMs;
    public boolean cancelled;

    Task(Runnable run, long delayMs) {
      this.run = run;
      this.delayMs = delayMs;
    }

    @Override
    public void cancel() {
      cancelled = true;
    }
  }

  public final List<Task> tasks = new ArrayList<>();

  @Override
  public synchronized AigSocket.Cancellable schedule(Runnable task, long delayMs) {
    Task t = new Task(task, delayMs);
    tasks.add(t);
    return t;
  }

  /** Runs (and removes) every pending, non-cancelled task once. */
  public void runPending() {
    List<Task> now;
    synchronized (this) {
      now = new ArrayList<>(tasks);
      tasks.clear();
    }
    for (Task t : now) if (!t.cancelled) t.run.run();
  }

  public synchronized List<Long> pendingDelays() {
    List<Long> d = new ArrayList<>();
    for (Task t : tasks) if (!t.cancelled) d.add(t.delayMs);
    return d;
  }
}
