package com.aig.ai.ecosystem.core.config;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class ConfigTest {
  @ParameterizedTest
  @ValueSource(strings = {"", "   ", "https://__AIG_BACKEND_URL_DEV__", "__REPLACE_ME_X", "api://__AIG_API_CLIENT_ID_DEV__/.default", "x__A__y"})
  void placeholders(String v) {
    assertTrue(Placeholders.isPlaceholder(v));
  }

  @ParameterizedTest
  @ValueSource(strings = {"https://aig.example.com", "api://1234/.default", "a__b", "__", "my_value"})
  void notPlaceholders(String v) {
    assertFalse(Placeholders.isPlaceholder(v));
  }

  @Test
  void nullIsPlaceholder() {
    assertTrue(Placeholders.isPlaceholder(null));
  }

  @ParameterizedTest
  @CsvSource({
    "local, http://localhost:8080, http://localhost:8080",
    "local, http://127.0.0.1:8080/, http://127.0.0.1:8080",
    "local, http://[::1]:8080, http://[::1]:8080",
    "local, https://aig.example.com/api//, https://aig.example.com/api",
    "dev, https://AIG.example.com:443/, https://aig.example.com",
    "prod, https://localhost:8443, https://localhost:8443",
  })
  void validUrls(String env, String raw, String want) {
    UrlCheck c = BackendUrls.validate(raw, AigEnvironment.parse(env));
    assertTrue(c.ok(), c.toString());
    assertEquals(want, c.url());
  }

  @ParameterizedTest
  @CsvSource({
    "dev, http://localhost:8080, http is not allowed for dev; use https",
    "local, http://aig.example.com, http is only allowed for localhost; use https",
    "local, http://10.0.0.5:8080, http is only allowed for localhost; use https",
    "prod, https://user:pw@aig.example.com, credentials in URL are not allowed",
    "prod, https://aig.example.com?x=1, query string or fragment not allowed",
    "prod, https://aig.example.com#f, query string or fragment not allowed",
    "prod, ftp://aig.example.com, unsupported protocol ftp:",
    "prod, https://__AIG_BACKEND_URL_PROD__, placeholder",
    "prod, not a url, invalid URL",
  })
  void invalidUrls(String env, String raw, String reason) {
    UrlCheck c = BackendUrls.validate(raw, AigEnvironment.parse(env));
    assertFalse(c.ok());
    assertEquals(reason, c.reason());
  }

  @Test
  void environmentNormalisation() {
    assertEquals(AigEnvironment.DEV, AigEnvironment.normalize(null));
    assertEquals(AigEnvironment.DEV, AigEnvironment.normalize("qa"));
    assertEquals(AigEnvironment.STAGE, AigEnvironment.normalize("stage"));
    assertEquals("general", JobProfiles.normalize("root"));
  }

  @Test
  void defaultsAreNotConfiguredOutsideLocal() {
    for (String env : new String[] {"dev", "stage", "prod"}) {
      ResolvedConfig c = ConfigResolver.resolve(AigSettings.defaults(env));
      assertFalse(c.configured(), env);
      assertNull(c.backendUrl());
      assertEquals(AuthPlan.Kind.UNCONFIGURED, c.auth().kind());
      assertEquals(2, c.problems().size(), c.problems().toString());
      assertEquals("AIG backend not configured for " + env, c.notConfiguredMessage());
    }
  }

  @Test
  void localDefaultsUseBrowserSignIn() {
    ResolvedConfig c = ConfigResolver.resolve(AigSettings.defaults("local"));
    assertTrue(c.configured(), c.problems().toString());
    assertEquals("http://localhost:8080", c.backendUrl());
    assertEquals(AuthPlan.Kind.LOCAL_BROWSER, c.auth().kind());
    assertEquals("browser", c.auth().method());
  }

  @Test
  void localDevUserShortcut() {
    ResolvedConfig ok = ConfigResolver.resolve(AigSettings.defaults("local").withDevUser(" jane@example.com "));
    assertEquals(AuthPlan.Kind.DEV, ok.auth().kind());
    assertEquals("jane@example.com", ok.auth().email());
    ResolvedConfig bad = ConfigResolver.resolve(AigSettings.defaults("local").withDevUser("not-an-email"));
    assertFalse(bad.configured());
    // ignored outside local
    ResolvedConfig dev = ConfigResolver.resolve(AigSettings.defaults("dev").withDevUser("jane@example.com"));
    assertEquals(AuthPlan.Kind.UNCONFIGURED, dev.auth().kind());
  }

  @Test
  void entraConfigured() {
    AigSettings s = AigSettings.defaults("stage").withEnv(AigEnvironment.STAGE,
        new EnvSettings("https://aig-stage.example.com/", "11111111-2222-3333-4444-555555555555", "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
            "api://platform-api-stage/.default", ""));
    ResolvedConfig c = ConfigResolver.resolve(s);
    assertTrue(c.configured(), c.problems().toString());
    assertEquals(AuthPlan.Kind.MICROSOFT, c.auth().kind());
    assertEquals("https://login.microsoftonline.com", c.auth().entra().authority());
    assertEquals("api://platform-api-stage/.default", c.auth().entra().scope());
    assertEquals("microsoft", c.auth().method());
  }

  @Test
  void entraPlaceholderPartsAreReported() {
    AigSettings s = AigSettings.defaults("dev").withEnv(AigEnvironment.DEV,
        new EnvSettings("https://aig-dev.example.com", "tenant-1", "__AIG_ENTRA_IDE_CLIENT_ID_DEV__", "api://x/.default", null));
    ResolvedConfig c = ConfigResolver.resolve(s);
    assertFalse(c.configured());
    assertEquals("Entra client id for dev: placeholder", c.auth().reason());
  }

  @Test
  void entraAuthorityMustBeHttps() {
    AigSettings s = AigSettings.defaults("dev").withEnv(AigEnvironment.DEV,
        new EnvSettings("https://aig-dev.example.com", "t", "c", "api://x/.default", "http://login.example.com"));
    ResolvedConfig c = ConfigResolver.resolve(s);
    assertFalse(c.configured());
    assertTrue(c.auth().reason().contains("authority"), c.auth().reason());
  }
}
