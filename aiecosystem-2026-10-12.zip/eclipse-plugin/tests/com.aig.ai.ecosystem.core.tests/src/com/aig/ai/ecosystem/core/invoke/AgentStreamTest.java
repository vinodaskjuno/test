package com.aig.ai.ecosystem.core.invoke;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.RepoFiles;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

/** SSE framing of agent invocation streams, incl. the backend/contracts agent_invocation stream fixtures. */
class AgentStreamTest {
  static List<Map<String, Object>> fixtures(String invocationCase) throws Exception {
    List<Map<String, Object>> out = new ArrayList<>();
    try (Stream<Path> files = Files.list(RepoFiles.root().resolve("backend/contracts/fixtures"))) {
      for (Path p : (Iterable<Path>) files.sorted()::iterator) {
        if (!p.getFileName().toString().startsWith("agent-invocation-") || !p.toString().endsWith(".json")) continue;
        Map<String, Object> f = Json.parseObject(Files.readString(p, StandardCharsets.UTF_8));
        assertNotNull(f, "fixture is not a JSON object: " + p);
        if (!"agent_invocation".equals(Json.str(f, "kind"))) continue;
        if (invocationCase.equals(Json.str(Json.obj(Json.obj(f, "input"), "invocation"), "case"))) out.add(f);
      }
    }
    return out;
  }

  /** Event as the fixtures write it: {event, data} without the invocation id platform-api adds. */
  static Map<String, Object> asFixture(AgentEvent e) {
    Map<String, Object> data = new LinkedHashMap<>();
    String name;
    if (e instanceof AgentEvent.Delta d) {
      name = "delta";
      data.put("text", d.text());
    } else if (e instanceof AgentEvent.Output o) {
      name = "output";
      data.put("output", o.output());
      if (o.usage() != null) data.put("usage", o.usage());
      if (o.traceId() != null) data.put("trace_id", o.traceId());
    } else if (e instanceof AgentEvent.Error er) {
      name = "error";
      data.put("code", er.code());
      data.put("message", er.message());
    } else {
      name = "done";
    }
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("event", name);
    m.put("data", data);
    return m;
  }

  static List<AgentEvent> feedAll(AgentStream s, List<String> chunks) {
    List<AgentEvent> out = new ArrayList<>();
    for (String c : chunks) out.addAll(s.feed(c));
    out.addAll(s.end());
    return out;
  }

  static List<String> oneCharChunks(String s) {
    List<String> out = new ArrayList<>();
    for (int i = 0; i < s.length(); i++) out.add(s.substring(i, i + 1));
    return out;
  }

  @Test
  void streamFixturesExist() throws Exception {
    assertTrue(fixtures("stream").size() >= 4, "expected agent_invocation stream fixtures");
  }

  @TestFactory
  List<DynamicTest> everyStreamFixture() throws Exception {
    List<DynamicTest> tests = new ArrayList<>();
    for (Map<String, Object> f : fixtures("stream")) {
      String sse = Json.str(Json.obj(Json.obj(f, "input"), "invocation"), "sse");
      // As sent, split into single characters, and with CRLF line endings: same events, same result.
      tests.add(DynamicTest.dynamicTest(Json.str(f, "name") + " (whole)", () -> check(f, List.of(sse))));
      tests.add(DynamicTest.dynamicTest(Json.str(f, "name") + " (1-char chunks)", () -> check(f, oneCharChunks(sse))));
      tests.add(DynamicTest.dynamicTest(Json.str(f, "name") + " (CRLF)", () -> check(f, oneCharChunks(sse.replace("\n", "\r\n")))));
    }
    return tests;
  }

  private static void check(Map<String, Object> f, List<String> chunks) {
    Map<String, Object> expected = Json.obj(f, "expected");
    AgentStream s = new AgentStream();
    List<Object> got = new ArrayList<>();
    for (AgentEvent e : feedAll(s, chunks)) got.add(asFixture(e));
    assertEquals(Json.write(expected.get("events")), Json.write(got), "events");
    Map<String, Object> want = Json.obj(expected, "result");
    AgentStream.Result r = s.result(false);
    assertEquals(Json.str(want, "status"), r.status());
    assertEquals(Json.str(want, "text"), r.text());
    if (want.containsKey("output")) assertEquals(Json.write(want.get("output")), Json.write(r.output()));
    if (want.containsKey("usage")) assertEquals(Json.write(want.get("usage")), Json.write(r.usage()));
    Map<String, Object> err = Json.obj(want, "error");
    if (err != null) {
      assertNotNull(r.error());
      // platform-api maps an agent's own error codes to agent_error before the client sees them; the client keeps
      // what it receives, so only the message is compared for agent-side error events.
      assertEquals(Json.str(err, "message"), r.error().message());
      if (!r.sawDone()) assertEquals(Json.str(err, "code"), r.error().code());
    } else {
      assertNull(r.error());
    }
  }

  @Test
  void platformApiEventsCarryInvocationIdAndDoneStatus() {
    AgentStream s = new AgentStream();
    String sse = ": keepalive\r\n\r\nevent: delta\r\ndata: {\"invocation_id\":\"inv-1\",\"text\":\"Hi\"}\r\n\r\n"
        + "event: output\r\ndata: {\"invocation_id\":\"inv-1\",\"output\":{\"a\":1},\"usage\":{\"prompt_tokens\":3,\"completion_tokens\":4,\"total_tokens\":7,\"cost\":0.1},"
        + "\"trace_id\":\"trace-0001\"}\r\n\r\nevent: done\r\ndata: {\"invocation_id\":\"inv-1\",\"status\":\"succeeded\",\"duration_ms\":3200}\r\n\r\n";
    List<AgentEvent> ev = feedAll(s, oneCharChunks(sse));
    assertEquals(3, ev.size());
    assertEquals("inv-1", ev.get(0).invocationId());
    AgentEvent.Done done = (AgentEvent.Done) ev.get(2);
    assertEquals("succeeded", done.status());
    assertEquals(3200L, done.durationMs());
    AgentStream.Result r = s.result(false);
    assertTrue(r.succeeded());
    assertEquals("{\"a\":1}", Json.write(r.output()));
    assertEquals("{\"prompt_tokens\":3,\"completion_tokens\":4,\"total_tokens\":7}", Json.write(r.usage()), "non-integer usage fields dropped");
    assertEquals("trace-0001", r.traceId());
    assertEquals("inv-1", r.invocationId());
    assertEquals(3200L, r.durationMs());
  }

  @Test
  void doneWithoutOutputSucceedsWithTextAndEventsAfterDoneAreIgnored() {
    AgentStream s = new AgentStream("inv-h", "trace-h");
    List<AgentEvent> ev = feedAll(s, List.of("event: delta\ndata: {\"text\":\"a\"}\n\nevent: done\ndata: {}\n\nevent: delta\ndata: {\"text\":\"late\"}\n\n"));
    assertEquals(2, ev.size());
    AgentStream.Result r = s.result(false);
    assertEquals("succeeded", r.status());
    assertEquals("a", r.output());
    assertEquals("inv-h", r.invocationId());
    assertEquals("trace-h", r.traceId());
  }

  @Test
  void doneStatusCancelledOrTimeoutWins() {
    AgentStream s = new AgentStream();
    feedAll(s, List.of("event: error\ndata: {\"code\":\"invocation_timeout\",\"message\":\"too slow\"}\n\nevent: done\ndata: {\"status\":\"timeout\"}\n\n"));
    assertEquals("timeout", s.result(false).status());
    assertEquals("invocation_timeout", s.result(false).error().code());
    AgentStream c = new AgentStream();
    feedAll(c, List.of("event: done\ndata: {\"status\":\"cancelled\"}\n\n"));
    assertEquals("cancelled", c.result(false).status());
  }

  @Test
  void malformedAndUnknownEventsAreIgnored() {
    AgentStream s = new AgentStream();
    List<AgentEvent> ev = feedAll(s, List.of("data: {\"text\":\"no event name\"}\n\nevent: delta\ndata: not json\n\nevent: delta\ndata: {\"txt\":1}\n\n",
        "event: output\ndata: {\"no_output\":1}\n\n: comment\nevent: ping\ndata: {}\n\n"));
    assertTrue(ev.isEmpty());
    assertEquals("failed", s.result(false).status());
    assertEquals(AgentStream.TRUNCATED_CODE, s.result(false).error().code());
  }

  @Test
  void trailingEventWithoutBlankLineIsFlushedAndCancelledStreamsReportCancelled() {
    AgentStream s = new AgentStream();
    assertTrue(s.feed("event: delta\ndata: {\"text\":\"x\"}").isEmpty());
    assertEquals(1, s.end().size());
    assertEquals("cancelled", s.result(true).status());
    assertNull(s.result(true).error());
  }

  @TestFactory
  List<DynamicTest> syncResponseFixtures() throws Exception {
    List<DynamicTest> tests = new ArrayList<>();
    for (Map<String, Object> f : fixtures("response")) {
      Map<String, Object> inv = Json.obj(Json.obj(f, "input"), "invocation");
      if (((Number) inv.get("http_status")).intValue() / 100 != 2) continue; // agent-side error mapping is platform-api's job
      tests.add(DynamicTest.dynamicTest(Json.str(f, "name"), () -> {
        InvokeResult r = InvokeResult.from(Json.obj(inv, "body"));
        Map<String, Object> want = Json.obj(Json.obj(f, "expected"), "result");
        assertEquals(Json.str(want, "status"), r.status());
        assertEquals(Json.write(want.get("output")), Json.write(r.output()));
        assertEquals(Json.write(want.get("usage")), Json.write(r.usage()));
      }));
    }
    assertFalse(tests.isEmpty());
    return tests;
  }
}
