package com.aig.ai.ecosystem.core.live;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.invoke.Catalog;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.ManualScheduler;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/** {@link AgentBridge}: widget agent messages in, catalog / agent.* host messages out (direct executor, manual scheduler). */
class AgentBridgeTest {
  static final String CATALOG = "{\"items\":[{\"agent\":{\"agent_id\":\"claims-triage\",\"name\":\"Claims triage\",\"team\":\"claims-ai\",\"tags\":[\"claims\"]},"
      + "\"versions\":[{\"env\":\"prod\",\"version\":\"1.4\",\"kind\":\"agentcore\",\"verified\":true,\"input_schema\":{\"type\":\"object\"}}],"
      + "\"default\":{\"env\":\"prod\",\"version\":\"1.4\",\"kind\":\"agentcore\",\"verified\":true},\"access\":\"org\"}],\"teams\":[\"claims-ai\"],\"tags\":[\"claims\"]}";

  static String inv(String status, String extra) {
    return "{\"id\":\"inv-b\",\"agent_id\":\"claims-triage\",\"version\":\"1.4\",\"env\":\"prod\",\"mode\":\"background\",\"status\":\"" + status + "\","
        + "\"trace_id\":\"trace-b\",\"created_at\":\"2026-10-09T10:00:00\",\"duration_ms\":" + ("succeeded".equals(status) ? "4000" : "null") + extra + "}";
  }

  MiniHttpServer srv;
  final List<String> out = new ArrayList<>();
  final List<String> hostCalls = new ArrayList<>();
  final ManualScheduler scheduler = new ManualScheduler();
  final AtomicReference<Catalog> cache = new AtomicReference<>();
  AgentBridge bridge;

  AgentBridge start(Function<MiniHttpServer.Request, Response> handler) throws Exception {
    srv = new MiniHttpServer(handler);
    BackendClient client = new BackendClient(srv.baseUrl(), () -> "dev:jane@example.com");
    bridge = new AgentBridge(() -> client, Runnable::run, scheduler, out::add, new AgentBridge.Host() {
      @Override
      public void openRun(String targetMessage) {
        hostCalls.add("openRun " + targetMessage);
      }

      @Override
      public void register() {
        hostCalls.add("register");
      }

      @Override
      public void showRun(String invocationId) {
        hostCalls.add("showRun " + invocationId);
      }

      @Override
      public void copy(String text) {
        hostCalls.add("copy " + text);
      }

      @Override
      public void runFinished(String agentId, String name, String status, String invocationId) {
        hostCalls.add("finished " + name + " " + status + " " + invocationId);
      }
    }, cache);
    return bridge;
  }

  @AfterEach
  void tearDown() throws Exception {
    if (bridge != null) bridge.dispose();
    if (srv != null) srv.close();
  }

  boolean post(String json) {
    return bridge.receive(AgentMessage.parse(json));
  }

  List<String> types() {
    List<String> t = new ArrayList<>();
    for (String m : out) t.add(Json.str(Json.parseObject(m), "type"));
    return t;
  }

  Map<String, Object> msg(int i) {
    return Json.parseObject(out.get(i));
  }

  @Test
  void catalogRefreshOpenAndSimpleCommands() throws Exception {
    start(r -> r.path().equals("/api/v1/catalog") ? Response.json(200, CATALOG) : Response.json(404, "{\"error\":{\"code\":\"agent_not_found\",\"message\":\"nope\"}}"));
    assertTrue(post("{\"cmd\":\"catalog.refresh\"}"));
    assertEquals(List.of("catalog.loading", "catalog"), types());
    Map<String, Object> cat = msg(1);
    Map<String, Object> item = Json.asObject(Json.list(cat, "items").get(0));
    assertEquals("claims-triage", item.get("agentId"));
    assertEquals("Claims triage", item.get("name"));
    assertEquals("[\"claims-ai\"]", Json.write(cat.get("teams")));
    assertNotNull(cache.get());

    int calls = srv.requests().size();
    post("{\"cmd\":\"agent.open\",\"agentId\":\"claims-triage\"}");
    assertEquals(calls, srv.requests().size(), "target resolved from the cached catalog");
    Map<String, Object> open = Json.parseObject(hostCalls.get(0).substring("openRun ".length()));
    assertEquals("agent.target", open.get("type"));
    assertEquals("1.4", Json.str(Json.obj(open, "target"), "version"));
    assertEquals("prod", Json.str(Json.obj(open, "target"), "env"));

    post("{\"cmd\":\"agent.open\",\"agentId\":\"unknown\"}");
    Map<String, Object> err = Json.parseObject(hostCalls.get(1).substring("openRun ".length()));
    assertEquals("agent.target.error", err.get("type"));
    assertEquals("agent_not_found", err.get("code"));

    post("{\"cmd\":\"agent.register\"}");
    post("{\"cmd\":\"agent.run.show\",\"invocationId\":\"inv-1\"}");
    post("{\"cmd\":\"clipboard.copy\",\"text\":\"hello\"}");
    assertEquals(List.of("register", "showRun inv-1", "copy hello"), hostCalls.subList(2, 5));
    assertFalse(bridge.receive(null));
  }

  @Test
  void catalogErrorsAreReported() throws Exception {
    start(r -> Response.json(401, "{\"error\":{\"code\":\"unauthenticated\",\"message\":\"bad token\"}}"));
    post("{\"cmd\":\"catalog.refresh\"}");
    assertEquals(List.of("catalog.loading", "catalog.error"), types());
    assertEquals("unauthenticated", msg(1).get("code"));
    assertTrue(Json.str(msg(1), "message").contains("Sign in"));
  }

  @Test
  void streamRunForwardsEventsWithTheLocalId() throws Exception {
    start(r -> new Response(200, Map.of("content-type", "text/event-stream", "x-aig-invocation-id", "inv-s", "x-aig-trace-id", "trace-s1234"),
        List.of(": keepalive\n\nevent: delta\ndata: {\"invocation_id\":\"inv-s\",\"text\":\"Severity: \"}\n\n", "event: delta\ndata: {\"text\":\"HIGH\"}\n\n",
            "event: output\ndata: {\"output\":{\"severity\":\"HIGH\"},\"usage\":{\"prompt_tokens\":412,\"completion_tokens\":168,\"total_tokens\":580},\"trace_id\":\"trace-s1234\"}\n\n",
            "event: done\ndata: {\"invocation_id\":\"inv-s\",\"status\":\"succeeded\",\"duration_ms\":3200}\n\n")));
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"claims-triage\",\"env\":\"prod\",\"version\":\"1.4\",\"mode\":\"stream\",\"input\":{\"claim_id\":\"CLM-4411\"}}");
    assertEquals(List.of("agent.status", "agent.status", "agent.delta", "agent.delta", "agent.output", "agent.done"), types());
    for (int i = 0; i < out.size(); i++) assertEquals("r1", msg(i).get("localId"));
    assertEquals("running", msg(1).get("status"));
    assertEquals("inv-s", msg(1).get("invocationId"));
    assertEquals("trace-s1234", msg(1).get("traceId"));
    assertEquals("1.4", msg(1).get("version"));
    assertEquals("prod", msg(1).get("env"));
    assertEquals("HIGH", msg(3).get("text"));
    assertEquals("{\"severity\":\"HIGH\"}", Json.write(msg(4).get("output")));
    assertEquals(580L, Json.obj(msg(4), "usage").get("total_tokens"));
    assertEquals("succeeded", msg(5).get("status"));
    assertEquals(3200L, msg(5).get("durationMs"));
    assertEquals("inv-s", msg(5).get("invocationId"));
    assertEquals("{\"input\":{\"claim_id\":\"CLM-4411\"}}", srv.last().body());
    assertTrue(bridge.activeRuns().isEmpty());
  }

  @Test
  void streamWithoutOutputEmitsTheTextAndTruncationEmitsAnError() throws Exception {
    AtomicInteger n = new AtomicInteger();
    start(r -> n.incrementAndGet() == 1 ? Response.sse("event: delta\ndata: {\"text\":\"Hello\"}\n\nevent: done\ndata: {}\n\n")
        : Response.sse("event: delta\ndata: {\"text\":\"part\"}\n\n"));
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a\",\"mode\":\"stream\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}");
    assertEquals(List.of("agent.status", "agent.delta", "agent.output", "agent.done"), types());
    assertEquals("Hello", msg(2).get("output"));
    out.clear();
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"r2\",\"agentId\":\"a\",\"mode\":\"stream\",\"input\":{}}");
    assertEquals(List.of("agent.status", "agent.delta", "agent.error", "agent.done"), types());
    assertEquals("agent_error", msg(2).get("code"));
    assertEquals("failed", msg(3).get("status"));
  }

  @Test
  void httpErrorsBecomeAgentErrorPlusDone() throws Exception {
    start(r -> Response.json(400, "{\"error\":{\"code\":\"input_invalid\",\"message\":\"claim_id is required\"}}"));
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a\",\"mode\":\"stream\",\"input\":{}}");
    assertEquals(List.of("agent.status", "agent.error", "agent.done"), types());
    assertEquals("input_invalid", msg(1).get("code"));
    assertEquals("claim_id is required", msg(1).get("message"));
    out.clear();
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"r2\",\"agentId\":\"a\",\"mode\":\"background\",\"input\":{}}");
    assertEquals(List.of("agent.error", "agent.done"), types());
  }

  @Test
  void backgroundRunIsPolledUntilFinal() throws Exception {
    AtomicInteger polls = new AtomicInteger();
    start(r -> {
      if (r.path().endsWith("/invoke")) {
        return Response.json(202, "{\"invocation_id\":\"inv-b\",\"agent_id\":\"claims-triage\",\"version\":\"1.4\",\"env\":\"prod\",\"status\":\"queued\",\"location\":\"/api/v1/invocations/inv-b\"}");
      }
      if (r.path().equals("/api/v1/catalog")) return Response.json(200, CATALOG);
      return polls.incrementAndGet() == 1 ? Response.json(200, inv("running", ""))
          : Response.json(200, inv("succeeded", ",\"usage\":{\"prompt_tokens\":1,\"completion_tokens\":2,\"total_tokens\":3},\"output_available\":true,\"output\":{\"ok\":true}"));
    });
    post("{\"cmd\":\"catalog.refresh\"}");
    out.clear();
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"bg1\",\"agentId\":\"claims-triage\",\"mode\":\"background\",\"input\":{\"x\":1}}");
    assertEquals("/api/v1/agents/claims-triage/invoke?mode=background", srv.last().target());
    assertEquals(List.of("agent.status"), types());
    assertEquals("queued", msg(0).get("status"));
    assertEquals("inv-b", msg(0).get("invocationId"));
    assertEquals(List.of(AgentBridge.POLL_MS), scheduler.pendingDelays());
    int before = srv.requests().size();
    post("{\"cmd\":\"agent.poll\",\"localId\":\"bg1\",\"invocationId\":\"inv-b\"}");
    assertEquals(before, srv.requests().size(), "the widget's own poll is folded into the bridge's polling");
    scheduler.runPending();
    assertEquals("/api/v1/invocations/inv-b", srv.last().target());
    assertEquals("running", msg(1).get("status"));
    assertEquals(List.of(AgentBridge.POLL_MS), scheduler.pendingDelays());
    scheduler.runPending();
    assertEquals(List.of("agent.status", "agent.status", "agent.status", "agent.output", "agent.done"), types());
    assertEquals("succeeded", msg(2).get("status"));
    assertEquals("{\"ok\":true}", Json.write(msg(3).get("output")));
    assertEquals(4000L, msg(4).get("durationMs"));
    assertTrue(scheduler.pendingDelays().isEmpty(), "polling stops at a final status");
    assertEquals(List.of("finished Claims triage succeeded inv-b"), hostCalls);
    assertTrue(bridge.activeRuns().isEmpty());
  }

  @Test
  void backgroundCancelAndFailedRecord() throws Exception {
    start(r -> {
      if (r.path().endsWith("/invoke")) return Response.json(202, "{\"invocation_id\":\"inv-b\",\"status\":\"queued\"}");
      if (r.path().endsWith("/cancel")) return Response.json(200, inv("cancelled", ",\"error_code\":\"invocation_cancelled\""));
      return Response.json(200, inv("failed", ",\"error_code\":\"agent_error\",\"error_message\":\"boom\""));
    });
    post("{\"cmd\":\"agent.invoke\",\"localId\":\"bg1\",\"agentId\":\"claims-triage\",\"mode\":\"background\",\"input\":{}}");
    out.clear();
    post("{\"cmd\":\"agent.cancel\",\"localId\":\"bg1\",\"invocationId\":\"inv-b\"}");
    assertEquals("/api/v1/invocations/inv-b/cancel", srv.last().target());
    assertEquals(List.of("agent.status", "agent.done"), types());
    assertEquals("cancelled", msg(1).get("status"));
    assertTrue(scheduler.pendingDelays().isEmpty());

    out.clear();
    post("{\"cmd\":\"agent.poll\",\"localId\":\"x1\",\"invocationId\":\"inv-b\"}");
    assertEquals(List.of("agent.status", "agent.error", "agent.done"), types());
    assertEquals("boom", msg(1).get("message"));
    assertEquals("failed", msg(2).get("status"));
  }

  @Test
  void streamCancelSendsDoneCancelledAndCancelsServerSide() throws Exception {
    AtomicReference<AgentBridge> ref = new AtomicReference<>();
    start(r -> {
      if (r.path().endsWith("/cancel")) return Response.json(200, inv("cancelled", ""));
      return new Response(200, Map.of("content-type", "text/event-stream", "x-aig-invocation-id", "inv-c"),
          List.of("event: delta\ndata: {\"text\":\"a\"}\n\n", "event: delta\ndata: {\"text\":\"b\"}\n\n", "event: done\ndata: {}\n\n"));
    });
    ref.set(bridge);
    List<String> seen = new ArrayList<>();
    // Cancel as soon as the first delta reaches the widget.
    AgentBridge b = new AgentBridge(() -> new BackendClient(srv.baseUrl(), () -> "t"), Runnable::run, scheduler, m -> {
      seen.add(m);
      if (m.contains("agent.delta")) ref.get().receive(AgentMessage.parse("{\"cmd\":\"agent.cancel\",\"localId\":\"r1\"}"));
    }, null, null);
    ref.set(b);
    b.receive(AgentMessage.parse("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a\",\"mode\":\"stream\",\"input\":{}}"));
    List<String> t = new ArrayList<>();
    for (String m : seen) t.add(Json.str(Json.parseObject(m), "type"));
    assertEquals(List.of("agent.status", "agent.status", "agent.delta", "agent.done"), t);
    assertEquals("cancelled", Json.str(Json.parseObject(seen.get(3)), "status"));
    assertEquals("inv-c", Json.str(Json.parseObject(seen.get(3)), "invocationId"));
    assertTrue(srv.requests().stream().anyMatch(r -> r.target().equals("/api/v1/invocations/inv-c/cancel")));
    b.dispose();
  }

  @Test
  void recentRunsAndShowInvocation() throws Exception {
    start(r -> {
      if (r.path().equals("/api/v1/invocations")) return Response.json(200, "{\"items\":[" + inv("succeeded", "") + "]}");
      if (r.path().equals("/api/v1/catalog")) return Response.json(200, CATALOG);
      return Response.json(200, inv("succeeded", ",\"output_available\":true,\"output\":\"done!\""));
    });
    post("{\"cmd\":\"agent.runs.refresh\"}");
    assertEquals("/api/v1/invocations?mine=1&limit=20", srv.last().target());
    Map<String, Object> run = Json.asObject(Json.list(msg(0), "runs").get(0));
    assertEquals("inv-b", run.get("invocationId"));
    assertEquals("succeeded", run.get("status"));
    out.clear();
    bridge.showInvocation("inv-b");
    assertEquals(List.of("agent.target", "agent.status", "agent.output", "agent.done"), types());
    assertEquals("Claims triage", Json.str(Json.obj(msg(0), "target"), "name"));
    assertEquals("show-inv-b", msg(1).get("localId"));
    assertEquals("done!", msg(2).get("output"));
    out.clear();
    bridge.onReady();
    assertEquals(List.of("agent.target"), types(), "the target is replayed when the page reloads");
  }
}
