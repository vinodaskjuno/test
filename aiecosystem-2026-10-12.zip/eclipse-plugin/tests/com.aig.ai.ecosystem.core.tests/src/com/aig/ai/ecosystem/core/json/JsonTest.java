package com.aig.ai.ecosystem.core.json;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class JsonTest {
  @Test
  void roundTrip() {
    String src = "{\"a\":1,\"b\":[true,false,null,2.5,\"x\\n\\u00e9\"],\"c\":{\"d\":-3e2}}";
    Map<String, Object> m = Json.parseObject(src);
    assertEquals(1L, m.get("a"));
    assertEquals(List.of(true, false), Json.list(m, "b").subList(0, 2));
    assertEquals("x\né", Json.list(m, "b").get(4));
    assertEquals(-300.0, Json.obj(m, "c").get("d"));
    assertEquals("{\"a\":1,\"b\":[true,false,null,2.5,\"x\\né\"],\"c\":{\"d\":-300}}", Json.write(m));
  }

  @Test
  void writerIsScriptSafe() {
    String w = Json.write("</script><b>& ");
    assertFalse(w.contains("<") || w.contains(">") || w.contains("&") || w.contains(" "));
    assertEquals("</script><b>& ", Json.parse(w));
  }

  @Test
  void rejectsMalformed() {
    for (String bad : new String[] {"", "{", "{\"a\":}", "[1,]", "tru", "\"\u0001\"", "{} x", "01"}) {
      assertNull(Json.parseObject(bad), bad);
    }
    assertThrows(Json.JsonException.class, () -> Json.parse("[".repeat(100) + "]".repeat(100)));
  }

  @Test
  void numHelperIsDefensive() {
    Map<String, Object> m = Json.parseObject("{\"a\":-1,\"b\":\"7\",\"c\":7}");
    assertEquals(0, Json.num(m, "a"));
    assertEquals(0, Json.num(m, "b"));
    assertEquals(7, Json.num(m, "c"));
  }
}
