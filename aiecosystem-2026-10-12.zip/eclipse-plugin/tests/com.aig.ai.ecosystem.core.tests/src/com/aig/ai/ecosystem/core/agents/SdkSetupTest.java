package com.aig.ai.ecosystem.core.agents;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.agents.SdkSetup.Bundled;
import com.aig.ai.ecosystem.core.agents.SdkSetup.CliPlan;
import com.aig.ai.ecosystem.core.agents.SdkSetup.DoctorSummary;
import com.aig.ai.ecosystem.core.agents.SdkSetup.FileChange;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Language;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Pins;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Source;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Step;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.RepoFiles;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class SdkSetupTest {
  @TempDir
  Path tmp;

  static final Pins PINS = new Pins("0.1.0", "0.1.0");
  static final Bundled BUNDLED = new Bundled("aig_sdk-0.1.0-py3-none-any.whl", "0.1.0", "aig-sdk-0.1.0.tgz", "0.1.0");

  @Test
  void sourcesAndUrls() {
    assertEquals(Source.REGISTRY, Source.parse(null));
    assertEquals(Source.BUNDLED, Source.parse(" Bundled "));
    assertEquals(Source.MONOREPO, Source.parse("monorepo"));
    assertEquals(Source.REGISTRY, Source.parse("pypi"));
    assertNull(SdkSetup.normalizeUrl("https://__AIG_PYPI_URL__/simple"));
    assertNull(SdkSetup.normalizeUrl("https://u:p@pypi.aig.internal/simple"));
    assertNull(SdkSetup.normalizeUrl("file:///etc"));
    assertNull(SdkSetup.normalizeUrl("  "));
    assertEquals("https://pypi.aig.internal/simple", SdkSetup.normalizeUrl(" https://pypi.aig.internal/simple "));
  }

  @Test
  void manifestParsing() {
    Map<String, Object> m = Json.parseObject("{\"pins\":{\"python\":\"0.1.0\",\"typescript\":\"0.2.0\"},"
        + "\"python\":{\"version\":\"0.1.0\",\"file\":\"aig_sdk-0.1.0-py3-none-any.whl\"},\"typescript\":{\"version\":\"0.2.0\",\"file\":\"../x.tgz\"}}");
    assertEquals(new Pins("0.1.0", "0.2.0"), SdkSetup.parsePins(m));
    Bundled b = SdkSetup.parseBundled(m);
    assertTrue(b.has(Language.PYTHON));
    assertFalse(b.has(Language.NODE), "file names with paths are rejected");
    assertNull(SdkSetup.parsePins(Json.parseObject("{\"pins\":{\"python\":\"x\",\"typescript\":\"0.1.0\"}}")));
    assertNull(SdkSetup.parsePins(null));
  }

  @Test
  void detection() throws Exception {
    assertEquals(Language.PYTHON, SdkSetup.detect(Set.of("pyproject.toml", "package.json")::contains));
    assertEquals(Language.NODE, SdkSetup.detect(Set.of("package.json")::contains));
    assertNull(SdkSetup.detect(Set.<String>of()::contains));
    Files.writeString(tmp.resolve("package.json"), "{}");
    assertEquals(Language.NODE, SdkSetup.detect(tmp));
    assertEquals(Path.of("/a/.venv/bin/python"), SdkSetup.venvBin(Path.of("/a"), "python", false));
    assertTrue(SdkSetup.venvBin(Path.of("a"), "aig", true).toString().endsWith("aig.exe"));
    boolean windows = SdkSetup.isWindows();
    if (!windows) {
      Path bin = Files.createDirectories(tmp.resolve("bin"));
      Path py = bin.resolve("python3");
      Files.writeString(py, "#!/bin/sh\n");
      py.toFile().setExecutable(true);
      assertEquals(py, SdkSetup.findPython(Map.of("PATH", bin.toString()), false));
      assertNull(SdkSetup.findPython(Map.of("PATH", "/nonexistent"), false));
    }
  }

  static List<List<String>> commands(List<Step> steps) {
    return steps.stream().map(Step::command).toList();
  }

  @Test
  void pythonSteps() {
    Path dest = Path.of("/w/agent");
    List<Step> reg = SdkSetup.envSetupSteps(Language.PYTHON, dest, Source.REGISTRY, Path.of("/usr/bin/python3"), null, "https://pypi.aig.internal/simple", null, null, false);
    assertEquals(List.of(List.of("/usr/bin/python3", "-m", "venv", ".venv"),
        List.of("/w/agent/.venv/bin/python", "-m", "pip", "install", "--index-url", "https://pypi.aig.internal/simple", "-e", ".[dev]")), commands(reg));
    assertTrue(reg.stream().allMatch(s -> s.cwd().equals(dest)));
    List<Step> bundled = SdkSetup.envSetupSteps(Language.PYTHON, dest, Source.BUNDLED, Path.of("C:/Py/py.exe"), null, null, null, null, false);
    assertEquals(List.of("C:/Py/py.exe", "-3", "-m", "venv", ".venv"), bundled.get(0).command());
    assertEquals(List.of("/w/agent/.venv/bin/python", "-m", "pip", "install", "--find-links", ".aig-wheels", "-e", ".[dev]"), bundled.get(1).command());
    List<Step> mono = SdkSetup.envSetupSteps(Language.PYTHON, dest, Source.MONOREPO, Path.of("python3"), null, null, null, Path.of("/repo"), false);
    assertEquals(List.of("create .venv", "install the local aig-sdk (monorepo)", "install the project and aig-sdk"), mono.stream().map(Step::label).toList());
    assertEquals(List.of("/w/agent/.venv/bin/python", "-m", "pip", "install", "-e", "/repo/sdk/python"), mono.get(1).command());
  }

  @Test
  void nodeSteps() {
    List<Step> s = SdkSetup.envSetupSteps(Language.NODE, Path.of("/w/t"), Source.REGISTRY, null, null, null, "https://npm.aig.internal/", null, false);
    assertEquals(List.of(List.of("npm", "install", "--no-audit", "--no-fund", "--@aig:registry=https://npm.aig.internal/")), commands(s));
    assertEquals("npm.cmd", SdkSetup.envSetupSteps(Language.NODE, Path.of("/w/t"), Source.REGISTRY, null, null, null, null, null, true).get(0).command().get(0));
  }

  @Test
  void fileChangesPerSource() {
    Path dest = Path.of("/w/t");
    Path dir = Path.of("/plugin/sdk");
    assertEquals(List.of(new FileChange("npm-spec", dest.resolve("package.json"), null, "0.1.0")),
        SdkSetup.fileChanges(Language.NODE, dest, Source.REGISTRY, PINS, BUNDLED, dir, null));
    assertEquals(List.of(new FileChange("copy", dest.resolve(".aig-wheels/aig-sdk-0.1.0.tgz"), dir.resolve("aig-sdk-0.1.0.tgz"), null),
        new FileChange("npm-spec", dest.resolve("package.json"), null, "file:.aig-wheels/aig-sdk-0.1.0.tgz")),
        SdkSetup.fileChanges(Language.NODE, dest, Source.BUNDLED, PINS, BUNDLED, dir, null));
    assertEquals("file:../../sdk/typescript", SdkSetup.monorepoNpmSpec(Path.of("/repo/agents/x"), Path.of("/repo")));
    List<FileChange> py = SdkSetup.fileChanges(Language.PYTHON, dest, Source.BUNDLED, PINS, BUNDLED, dir, null);
    assertEquals("python-pin", py.get(0).kind());
    assertEquals(dir.resolve("aig_sdk-0.1.0-py3-none-any.whl"), py.get(1).from());
  }

  @Test
  void pinRewritesAndApply() throws Exception {
    String toml = "dependencies = [\"aig-sdk[langgraph]>=0.1\", \"httpx>=0.27\"]\ndev = ['aig-sdk[evals]==0.0.9', \"aig-sdk==0.0.1\"]\n";
    assertEquals("dependencies = [\"aig-sdk[langgraph]==0.2.0\", \"httpx>=0.27\"]\ndev = ['aig-sdk[evals]==0.2.0', \"aig-sdk==0.2.0\"]\n", SdkSetup.setPythonSdkPin(toml, "0.2.0"));
    String pkg = "{\n  \"name\": \"x\",\n  \"dependencies\": {\n    \"@aig/sdk\": \"0.1.0\",\n    \"zod\": \"^4\"\n  }\n}\n";
    assertEquals(pkg.replace("\"0.1.0\"", "\"file:.aig-wheels/aig-sdk-0.1.0.tgz\""), SdkSetup.setNpmSdkSpec(pkg, "file:.aig-wheels/aig-sdk-0.1.0.tgz"));
    assertTrue(SdkSetup.setNpmSdkSpec("{\"name\":\"x\"}", "0.1.0").contains("\"@aig/sdk\":\"0.1.0\""));
    Path dir = Files.createDirectories(tmp.resolve("p"));
    Files.writeString(dir.resolve("pyproject.toml"), toml);
    Path wheel = Files.writeString(tmp.resolve("aig_sdk-0.1.0-py3-none-any.whl"), "wheel");
    List<String> log = SdkSetup.apply(SdkSetup.fileChanges(Language.PYTHON, dir, Source.BUNDLED, PINS, BUNDLED, tmp, null));
    assertEquals(2, log.size());
    assertTrue(Files.readString(dir.resolve("pyproject.toml")).contains("aig-sdk[langgraph]==0.1.0"));
    assertEquals("wheel", Files.readString(dir.resolve(".aig-wheels").resolve(wheel.getFileName())));
    assertEquals(List.of(), SdkSetup.apply(SdkSetup.fileChanges(Language.PYTHON, dir, Source.REGISTRY, PINS, BUNDLED, tmp, null)), "idempotent");
  }

  @Test
  void descriptor() {
    String y = SdkSetup.renderDescriptor("# c\nname: s\ndisplay_name: s\ndescription: d\n  name: nested\ninput_schema:\n", "claims.v2", "Claims: triage", "say \"hi\" # x");
    assertEquals("# c\nname: \"claims.v2\"\ndisplay_name: \"Claims: triage\"\ndescription: \"say \\\"hi\\\" # x\"\n  name: nested\ninput_schema:\n", y);
  }

  @Test
  void repoTemplatesDependOnTheSdkByVersion() throws Exception {
    Path root = RepoFiles.root();
    String pin = Json.str(Json.parseObject(Files.readString(root.resolve("sdk/typescript/package.json"), StandardCharsets.UTF_8)), "version");
    String pkg = Files.readString(root.resolve("sdk/templates/langgraph-ts/package.json"), StandardCharsets.UTF_8);
    assertEquals(pin, Json.str(Json.obj(Json.parseObject(pkg), "dependencies"), "@aig/sdk"));
    for (String t : List.of("langgraph-py", "strands-py")) {
      String toml = Files.readString(root.resolve("sdk/templates/" + t + "/pyproject.toml"), StandardCharsets.UTF_8);
      assertFalse(toml.contains(">=0.1\""), t);
      assertTrue(Files.isRegularFile(root.resolve("sdk/templates/" + t + "/aig-agent.yaml")), t);
    }
  }

  @Test
  void doctorSummary() {
    String json = "{\"ok\":false,\"checks\":[{\"name\":\"Configuration\",\"ok\":false,\"code\":\"AIG_E_PORTKEY_UNCONFIGURED\",\"field\":\"AIG_PORTKEY_BASE_URL\",\"remediation\":\"Set it\"},"
        + "{\"name\":\"Portkey\",\"ok\":false,\"code\":null},{\"name\":\"Fiddler\",\"ok\":true}]}";
    DoctorSummary s = SdkSetup.parseDoctor("noise\n" + json);
    assertFalse(s.ok());
    assertEquals(1, s.failed());
    assertEquals(List.of("FAIL Configuration AIG_E_PORTKEY_UNCONFIGURED (AIG_PORTKEY_BASE_URL)", "     fix: Set it", "SKIP Portkey", "OK   Fiddler"), s.lines());
    assertNull(SdkSetup.parseDoctor("not json"));
    assertEquals(List.of("/w/a/.venv/bin/aig", "doctor", "--json"), SdkSetup.doctorStep(Language.PYTHON, Path.of("/w/a"), null, false).command());
    assertNull(SdkSetup.doctorStep(Language.NODE, Path.of("/w/a"), null, false));
  }

  @Test
  void cliInstall() {
    CliPlan pipx = SdkSetup.cliInstallPlan("0.1.0", Path.of("/opt/pipx"), null, null, "https://pypi.aig.internal/simple", Path.of("/home/me"), false);
    assertEquals("pipx", pipx.method());
    assertEquals(List.of("/opt/pipx", "install", "--force", "--pip-args=--index-url https://pypi.aig.internal/simple", "aig-sdk[evals]==0.1.0"), pipx.steps().get(0).command());
    CliPlan venv = SdkSetup.cliInstallPlan("0.1.0", null, Path.of("/usr/bin/python3"), Path.of("/plugin/sdk"), null, Path.of("/home/me"), false);
    assertEquals("venv", venv.method());
    assertEquals(Path.of("/home/me/.aig/cli/bin/aig"), venv.aigPath());
    assertEquals(List.of(List.of("/usr/bin/python3", "-m", "venv", "/home/me/.aig/cli"),
        List.of("/home/me/.aig/cli/bin/python", "-m", "pip", "install", "--upgrade", "--find-links", "/plugin/sdk", "aig-sdk[evals]==0.1.0")), commands(venv.steps()));
    assertNull(SdkSetup.cliInstallPlan("0.1.0", null, null, null, null, Path.of("/h"), false));
  }
}
