package com.aig.ai.ecosystem.core.agents;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.testing.RepoFiles;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TemplatesTest {
  @TempDir
  Path tmp;

  Path template() throws IOException {
    Path t = tmp.resolve("templates/sample-py");
    Files.createDirectories(t.resolve("src/sample_pkg"));
    Files.createDirectories(t.resolve(".venv/lib"));
    Files.createDirectories(t.resolve("node_modules/x"));
    Files.createDirectories(t.resolve("pkg.egg-info"));
    Files.writeString(t.resolve("aig-template.json"), "{\"name\":\"sample-py\",\"description\":\"Sample\",\"language\":\"python\",\"placeholders\":"
        + "{\"agent_id\":\"sample-agent\",\"team\":\"sample-team\",\"project\":\"sample-project\",\"package\":\"sample_pkg\",\"description\":\"Sample agent\","
        + "\"sdk_python\":\"../../sdk/python\"},\"exclude\":[\"*.log\"]}");
    Files.writeString(t.resolve("pyproject.toml"), "name = \"sample-project\"\nagent = \"sample-agent\" # not sample-agent-x\n");
    Files.writeString(t.resolve("src/sample_pkg/__init__.py"), "AGENT_ID = 'sample-agent'\nTEAM = 'sample-team'\n");
    Files.write(t.resolve("logo.bin"), new byte[] {(byte) 0xff, (byte) 0xfe, 's', 'a', 'm'});
    Files.writeString(t.resolve(".venv/lib/x.py"), "x");
    Files.writeString(t.resolve("node_modules/x/i.js"), "x");
    Files.writeString(t.resolve("pkg.egg-info/PKG-INFO"), "x");
    Files.writeString(t.resolve("debug.log"), "x");
    Files.writeString(t.resolve(".env"), "SECRET=1");
    return t;
  }

  @Test
  void loadsAndScaffoldsLikeTheCli() throws Exception {
    template();
    Map<String, Template> all = Templates.load(tmp.resolve("templates"));
    Template t = all.get("sample-py");
    assertNotNull(t);
    assertEquals("Sample", t.description());
    Path dest = tmp.resolve("work/My Agent!");
    Map<String, String> values = Templates.values(t, dest, "claims-bot", "uw-ai", null);
    assertEquals("my-agent", values.get("project"));
    assertEquals("my_agent", values.get("package"));
    assertEquals("sample-py agent claims-bot", values.get("description"));
    List<Path> written = Templates.scaffold(t, dest, values, false);
    List<String> rel = written.stream().map(p -> dest.relativize(p).toString().replace('\\', '/')).sorted().toList();
    assertEquals(List.of("logo.bin", "pyproject.toml", "src/my_agent/__init__.py"), rel);
    assertEquals("name = \"my-agent\"\nagent = \"claims-bot\" # not claims-bot-x\n", Files.readString(dest.resolve("pyproject.toml"), StandardCharsets.UTF_8));
    assertEquals("AGENT_ID = 'claims-bot'\nTEAM = 'uw-ai'\n", Files.readString(dest.resolve("src/my_agent/__init__.py")));
    assertArrayEquals(new byte[] {(byte) 0xff, (byte) 0xfe, 's', 'a', 'm'}, Files.readAllBytes(dest.resolve("logo.bin")), "binary copied as is");
    IOException e = assertThrows(IOException.class, () -> Templates.scaffold(t, dest, values, false));
    assertTrue(e.getMessage().contains("not empty"));
    assertEquals(3, Templates.scaffold(t, dest, values, true).size());
  }

  @Test
  void slugRules() {
    assertEquals("my-agent", Templates.slug("My Agent!"));
    assertEquals("agent", Templates.slug("!!!"));
    assertEquals("a.b_c", Templates.slug("..a.b_c--"));
    assertEquals(64, Templates.slug("x".repeat(100)).length());
  }

  @Test
  void repoTemplatesHaveManifests() throws Exception {
    Map<String, Template> all = Templates.load(RepoFiles.root().resolve("sdk/templates"));
    assertTrue(all.keySet().containsAll(List.of("langgraph-py", "langgraph-ts", "strands-py")), all.keySet().toString());
    assertEquals("langgraph-py-sample", all.get("langgraph-py").placeholders().get("agent_id"));
  }

  @Test
  void cliLookupAndCommands() throws Exception {
    Path bin = Files.createDirectories(tmp.resolve("bin"));
    Path aig = bin.resolve("aig");
    Files.writeString(aig, "#!/bin/sh\n");
    aig.toFile().setExecutable(true);
    boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
    if (!windows) assertEquals(aig, AigCli.find("aig", Map.of("PATH", "/nonexistent" + java.io.File.pathSeparator + bin)));
    assertNull(AigCli.find("aig", Map.of("PATH", "/nonexistent")));
    assertEquals(List.of(aig.toString(), "init", "langgraph-py", "/w/a", "--agent-id", "a1", "--team", "uw", "--description", "d", "--no-register", "--no-install"),
        AigCli.initCommand(aig, "langgraph-py", Path.of("/w/a"), "a1", "uw", " d ", null));
    assertEquals(List.of(aig.toString(), "eval", "run", "--md", "r.md", "--out", "r.json", "--offline"), AigCli.evalCommand(aig, Path.of("r.md"), Path.of("r.json"), true));
  }

  @Test
  void dotfilesShippedAsDotPrefixAreRestored(@TempDir Path tmp) throws IOException {
    assertEquals(".gitignore", Templates.restoreDotName("__dot__gitignore"));
    assertEquals("src/.gitignore", Templates.restoreDotName("src/__dot__gitignore"));
    assertEquals("README.md", Templates.restoreDotName("README.md"));
    Path proj = tmp.resolve("proj");
    Files.createDirectories(proj.resolve("sub"));
    Files.writeString(proj.resolve("__dot__gitignore"), ".venv/\n", StandardCharsets.UTF_8);
    Files.writeString(proj.resolve("sub/__dot__gitignore"), "x\n", StandardCharsets.UTF_8);
    Templates.restoreDotfiles(proj);
    assertTrue(Files.exists(proj.resolve(".gitignore")));
    assertTrue(Files.exists(proj.resolve("sub/.gitignore")));
    assertFalse(Files.exists(proj.resolve("__dot__gitignore")));
  }
}
