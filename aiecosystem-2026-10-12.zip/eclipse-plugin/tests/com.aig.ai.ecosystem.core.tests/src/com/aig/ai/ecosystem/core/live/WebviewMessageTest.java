package com.aig.ai.ecosystem.core.live;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.ws.LiveStatus;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class WebviewMessageTest {
  @Test
  void simpleCommands() {
    for (String c : new String[] {"ready", "refresh", "openDashboard", "openPanel", "signOut", "signIn", "selectEnvironment"}) {
      assertEquals(c, WebviewMessage.parse("{\"cmd\":\"" + c + "\",\"extra\":1}").cmd());
    }
  }

  @Test
  void signInWithOptionalEmail() {
    WebviewMessage plain = WebviewMessage.parse("{\"cmd\":\"signIn\"}");
    assertEquals("signIn", plain.cmd());
    assertNull(plain.email(), "no email: the configured sign-in flow");
    WebviewMessage m = WebviewMessage.parse("{\"cmd\":\"signIn\",\"email\":\"  Premium.Quality@AIG.example \"}");
    assertEquals("signIn", m.cmd());
    assertEquals("premium.quality@aig.example", m.email(), "trimmed and lower-cased");
    for (String bad : new String[] {"\"\"", "\"nobody\"", "\"a b@c.de\"", "\"a@b\"", "\"a@@b.com\"", "\"a@b.c\"", "\"a@b.c0m\"", "42", "null", "{}",
        "\"" + "x".repeat(65) + "@aig.example\"", "\"a@" + "d".repeat(191) + ".com\""}) {
      assertNull(WebviewMessage.parse("{\"cmd\":\"signIn\",\"email\":" + bad + "}"), "rejected: " + bad);
    }
    assertEquals("x@y.io", WebviewMessage.normalizeSignInEmail("X@Y.IO"));
    assertNull(WebviewMessage.normalizeSignInEmail("a@b.com" + " ".repeat(300)), "over the raw length cap");
    assertNull(WebviewMessage.normalizeSignInEmail(null));
  }

  @Test
  void range() {
    assertEquals(90, WebviewMessage.parse("{\"cmd\":\"range\",\"days\":90}").days());
    assertNull(WebviewMessage.parse("{\"cmd\":\"range\",\"days\":14}"));
    assertNull(WebviewMessage.parse("{\"cmd\":\"range\",\"days\":\"7\"}"));
    assertNull(WebviewMessage.parse("{\"cmd\":\"range\",\"days\":7.5}"));
  }

  @Test
  void chatSendValidation() {
    WebviewMessage ok = WebviewMessage.parse("{\"cmd\":\"chat.send\",\"localId\":\"a_1-\",\"jobProfile\":\"claims\",\"messages\":[{\"role\":\"user\",\"content\":\"q\"},"
        + "{\"role\":\"assistant\",\"content\":\"a\"},{\"role\":\"user\",\"content\":\"q2\",\"x\":1}]}");
    assertEquals(3, ok.messages().size());
    assertEquals("claims", ok.jobProfile());
    String[] bad = {
      "{\"cmd\":\"chat.send\",\"localId\":\"bad id\",\"jobProfile\":\"g\",\"messages\":[{\"role\":\"user\",\"content\":\"q\"}]}",
      "{\"cmd\":\"chat.send\",\"localId\":\"a\",\"messages\":[{\"role\":\"user\",\"content\":\"q\"}]}",
      "{\"cmd\":\"chat.send\",\"localId\":\"a\",\"jobProfile\":\"g\",\"messages\":[]}",
      "{\"cmd\":\"chat.send\",\"localId\":\"a\",\"jobProfile\":\"g\",\"messages\":[{\"role\":\"system\",\"content\":\"q\"}]}",
      "{\"cmd\":\"chat.send\",\"localId\":\"a\",\"jobProfile\":\"g\",\"messages\":[{\"role\":\"user\",\"content\":\"q\"},{\"role\":\"assistant\",\"content\":\"a\"}]}",
      "{\"cmd\":\"chat.send\",\"localId\":\"a\",\"jobProfile\":\"g\",\"messages\":[{\"role\":\"user\",\"content\":5}]}",
      "{\"cmd\":\"chat.send\",\"localId\":\"a\",\"jobProfile\":\"g\",\"messages\":[{\"role\":\"user\",\"content\":\"" + "x".repeat(32_001) + "\"}]}",
    };
    for (String b : bad) assertNull(WebviewMessage.parse(b), b.length() > 200 ? b.substring(0, 200) : b);
    StringBuilder many = new StringBuilder("{\"cmd\":\"chat.send\",\"localId\":\"a\",\"jobProfile\":\"g\",\"messages\":[");
    for (int i = 0; i < 51; i++) many.append(i == 0 ? "" : ",").append("{\"role\":\"user\",\"content\":\"q\"}");
    assertNull(WebviewMessage.parse(many.append("]}").toString()));
    assertEquals("x", WebviewMessage.parse("{\"cmd\":\"chat.cancel\",\"localId\":\"x\"}").localId());
    assertNull(WebviewMessage.parse("{\"cmd\":\"chat.cancel\",\"localId\":\"\"}"));
  }

  @Test
  void hostMessagesShape() {
    Map<String, Object> init = Json.parseObject(HostMessages.init(new HostMessages.InitInfo("dev", null, "premium", "quality", null, "general", List.of("general"), 30)));
    Map<String, Object> info = Json.obj(init, "info");
    assertFalse(info.containsKey("user"), "optional fields are omitted, never null");
    assertEquals("premium", info.get("tier"));
    assertEquals("quality", info.get("costMode"));
    assertFalse(Json.obj(Json.parseObject(HostMessages.init(new HostMessages.InitInfo("dev", null, null, null, null, "general", List.of("general"), 30))), "info")
        .containsKey("costMode"));
    assertEquals("{\"type\":\"chat.done\",\"localId\":\"L\",\"traceId\":\"t\"}", HostMessages.chatDone("L", null, "t", null, null));
    assertEquals("{\"type\":\"chat.done\",\"localId\":\"L\",\"model\":\"m\",\"route\":{\"user_tier\":\"standard\",\"cost_mode\":\"economy\"}}",
        HostMessages.chatDone("L", null, null, "m", Json.object().put("user_tier", "standard").put("cost_mode", "economy").map()));
    assertEquals("{\"type\":\"chat.done\",\"localId\":\"L\",\"route\":{\"user_tier\":\"free\",\"usage_state\":\"hard\"}}",
        HostMessages.chatDone("L", null, null, null, Json.object().put("user_tier", "free").put("usage_state", "hard").map()));
    assertEquals("{\"type\":\"usage.limits\",\"data\":{\"configured\":false,\"state\":\"normal\"}}",
        HostMessages.usageLimits(Json.object().put("configured", false).put("state", "normal").map()));
    assertEquals("{\"type\":\"usage.limits.error\",\"code\":\"forbidden\",\"message\":\"m\"}", HostMessages.usageLimitsError("forbidden", "m"));
    assertEquals("{\"type\":\"live\",\"status\":\"reconnecting\",\"detail\":\"x\"}", HostMessages.live(LiveStatus.RECONNECTING, "x"));
    assertEquals("{\"type\":\"tab\",\"tab\":\"chat\"}", HostMessages.tab("chat"));
    assertThrows(IllegalArgumentException.class, () -> HostMessages.tab("other"));
    assertEquals("{\"type\":\"status\",\"env\":\"dev\",\"tone\":\"bad\",\"label\":\"Not configured\",\"detail\":\"d\",\"method\":\"unconfigured\"}",
        HostMessages.status("dev", "bad", "Not configured", "d", "unconfigured"));
    assertEquals("{\"type\":\"chat.delta\",\"localId\":\"L\",\"text\":\"\\u003cb\\u003e\"}", HostMessages.chatDelta("L", "<b>"));
  }
}
