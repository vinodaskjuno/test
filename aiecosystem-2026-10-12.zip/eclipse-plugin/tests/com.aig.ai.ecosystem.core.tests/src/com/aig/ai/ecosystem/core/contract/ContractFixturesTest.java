package com.aig.ai.ecosystem.core.contract;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.http.ContractException;
import com.aig.ai.ecosystem.core.http.ContractHeaders;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.RepoFiles;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

/**
 * backend/contracts/fixtures: every IDE-client case ({@code kind: backend_client}, also accepted as
 * {@code ide-client}) must produce exactly the expected x-aig-* headers, byte for byte, or the
 * expected error code and field.
 */
class ContractFixturesTest {
  static final String GENERATED_UUID4 = "<generated:uuid4>";

  static List<Map<String, Object>> fixtures() throws Exception {
    List<Map<String, Object>> out = new ArrayList<>();
    try (Stream<Path> files = Files.list(RepoFiles.root().resolve("backend/contracts/fixtures"))) {
      for (Path p : (Iterable<Path>) files.sorted()::iterator) {
        if (!p.toString().endsWith(".json")) continue;
        Map<String, Object> f = Json.parseObject(Files.readString(p, StandardCharsets.UTF_8));
        assertNotNull(f, "fixture is not a JSON object: " + p);
        String kind = Json.str(f, "kind");
        if ("backend_client".equals(kind) || "ide-client".equals(kind) || "ide_client".equals(kind)) out.add(f);
      }
    }
    return out;
  }

  @Test
  void thereAreIdeClientFixtures() throws Exception {
    assertTrue(fixtures().size() >= 3, "expected at least 3 backend_client fixtures");
  }

  @TestFactory
  List<DynamicTest> everyIdeClientFixture() throws Exception {
    List<DynamicTest> tests = new ArrayList<>();
    for (Map<String, Object> f : fixtures()) tests.add(DynamicTest.dynamicTest(Json.str(f, "name"), () -> check(f)));
    return tests;
  }

  private static void check(Map<String, Object> f) {
    Map<String, Object> call = Json.obj(Json.obj(f, "input"), "call");
    Map<String, Object> expected = Json.obj(f, "expected");
    String job = Json.str(call, "job_profile");
    String agent = Json.str(call, "agent_id");
    String trace = Json.str(call, "trace_id");
    Map<String, Object> err = Json.obj(expected, "error");
    if (err != null) {
      ContractException e = assertThrows(ContractException.class, () -> ContractHeaders.backendHeaders(job, agent, trace));
      assertEquals(Json.str(err, "code"), e.code());
      assertEquals(Json.str(err, "field"), e.field());
      return;
    }
    Map<String, Object> want = Json.obj(expected, "backend_headers");
    Map<String, String> got = ContractHeaders.backendHeaders(job, agent, trace);
    assertEquals(want.keySet(), got.keySet(), "header names");
    for (Map.Entry<String, Object> e : want.entrySet()) {
      String value = got.get(e.getKey());
      assertTrue(e.getKey().startsWith("x-aig-"), "only x-aig-* headers are in the client contract");
      if (GENERATED_UUID4.equals(e.getValue())) {
        assertTrue(ContractHeaders.UUID_V4.matcher(value).matches(), "uuid4 expected, got " + value);
      } else {
        assertArrayEquals(((String) e.getValue()).getBytes(StandardCharsets.UTF_8), value.getBytes(StandardCharsets.UTF_8), e.getKey());
      }
    }
    // Byte-for-byte wire form (name: value CRLF) in the fixture's order.
    StringBuilder wantWire = new StringBuilder();
    StringBuilder gotWire = new StringBuilder();
    for (String k : want.keySet()) {
      Object w = want.get(k);
      String g = got.get(k);
      wantWire.append(k).append(": ").append(GENERATED_UUID4.equals(w) ? g : w).append("\r\n");
      gotWire.append(k).append(": ").append(g).append("\r\n");
    }
    assertArrayEquals(wantWire.toString().getBytes(StandardCharsets.UTF_8), gotWire.toString().getBytes(StandardCharsets.UTF_8));
    assertFalse(got.keySet().stream().anyMatch(k -> k.startsWith("x-portkey")));
  }

  @Test
  void chatHeadersAddOnlyTransportAndBearer() {
    Map<String, String> h = ContractHeaders.chatHeaders("t0k", "claims", "ide.eclipse", "0f8fad5b-d9cb-469f-a165-70867728950e", true);
    assertEquals(List.of("authorization", "content-type", "accept", "x-aig-job-profile", "x-aig-trace-id", "x-aig-agent-id"), new ArrayList<>(h.keySet()));
    assertEquals("Bearer t0k", h.get("authorization"));
    assertEquals("text/event-stream", h.get("accept"));
    assertFalse(h.keySet().stream().anyMatch(k -> k.startsWith("x-portkey")));
  }

  @Test
  void invalidTraceIdsAreReplacedNotRejected() {
    assertTrue(ContractHeaders.UUID_V4.matcher(ContractHeaders.backendHeaders(null, null, "bad\nid").get("x-aig-trace-id")).matches());
    assertTrue(ContractHeaders.UUID_V4.matcher(ContractHeaders.backendHeaders(null, null, "short").get("x-aig-trace-id")).matches());
    assertEquals("trace.id-1234", ContractHeaders.backendHeaders(null, null, "trace.id-1234").get("x-aig-trace-id"));
  }

  @Test
  void rejectsBadJobProfileAgentAndHeaderInjection() {
    assertEquals("job_profile", assertThrows(ContractException.class, () -> ContractHeaders.backendHeaders("root", null, null)).field());
    assertEquals("agent_id", assertThrows(ContractException.class, () -> ContractHeaders.backendHeaders(null, "x".repeat(65), null)).field());
    assertThrows(IllegalArgumentException.class, () -> ContractHeaders.bearer("a\r\nx-portkey-api-key: y"));
    assertThrows(IllegalArgumentException.class, () -> ContractHeaders.bearer(""));
    assertEquals("Bearer dev:me@aig.com", ContractHeaders.authHeaders(ContractHeaders.devToken("me@aig.com")).get("authorization"));
  }
}
