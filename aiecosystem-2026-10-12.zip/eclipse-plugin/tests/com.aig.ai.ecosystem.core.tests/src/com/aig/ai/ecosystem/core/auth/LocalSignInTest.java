package com.aig.ai.ecosystem.core.auth;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import com.aig.ai.ecosystem.core.config.AuthPlan;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.Test;

class LocalSignInTest {
  final AtomicLong now = new AtomicLong(1_000_000);
  final PendingStates pending = new PendingStates(now::get, PendingStates.STATE_TTL_MS);

  @Test
  void stateShapeMatchesBackendPattern() {
    String s = PendingStates.newState();
    assertTrue(s.matches("^[A-Za-z0-9_-]{16,128}$"), s);
    assertNotEquals(s, PendingStates.newState());
  }

  @Test
  void statesAreOneTime() {
    String s = pending.issue();
    assertEquals(1, pending.size());
    assertTrue(pending.consume(s));
    assertFalse(pending.consume(s), "a state is accepted only once");
    assertFalse(pending.consume("never-issued"));
    assertFalse(pending.consume(null));
  }

  @Test
  void statesExpireAfterTenMinutes() {
    String a = pending.issue();
    now.addAndGet(10 * 60 * 1000);
    assertTrue(pending.consume(a), "valid at exactly 10 minutes");
    String b = pending.issue();
    now.addAndGet(10 * 60 * 1000 + 1);
    assertFalse(pending.consume(b));
    pending.issue();
    now.addAndGet(PendingStates.STATE_TTL_MS + 1);
    assertEquals(0, pending.size(), "expired states are pruned");
  }

  @Test
  void signInUrl() {
    String url = LocalSignIn.buildSignInUrl("http://localhost:8080", "http://127.0.0.1:5000/auth/callback", "st_ate-123", "jane@example.com");
    assertEquals("http://localhost:8080/auth/local/signin?redirect_uri=http%3A%2F%2F127.0.0.1%3A5000%2Fauth%2Fcallback&state=st_ate-123&login_hint=jane%40example.com", url);
    assertFalse(LocalSignIn.buildSignInUrl("http://localhost:8080", "r", "s", "not email").contains("login_hint"));
  }

  @Test
  void callbackValidation() {
    String s = pending.issue();
    assertEquals("unknown callback path /x", LocalSignIn.handleCallback("/x", "state=" + s, pending).reason());
    CallbackResult bad = LocalSignIn.handleCallback("/auth/callback", "state=" + s + "&email=nope", pending);
    assertFalse(bad.ok());
    assertEquals("sign-in returned an invalid email", bad.reason());
    // consumed above, so a replay fails
    assertFalse(LocalSignIn.handleCallback("/auth/callback", "state=" + s + "&email=jane%40example.com", pending).ok());
    String s2 = pending.issue();
    CallbackResult ok = LocalSignIn.handleCallback("/auth/callback", "email=jane%40example.com&state=" + s2, pending);
    assertTrue(ok.ok());
    assertEquals("jane@example.com", ok.value());
    assertFalse(LocalSignIn.handleCallback("/auth/callback", "email=jane%40example.com", pending).ok());
  }

  @Test
  void normalizeEmailMatchesTheWidgetRule() {
    assertEquals("premium.quality@aig.example", LocalSignIn.normalizeEmail("  Premium.Quality@AIG.Example\t"));
    assertNull(LocalSignIn.normalizeEmail("a@b"));
    assertNull(LocalSignIn.normalizeEmail("a b@c.de"));
    assertNull(LocalSignIn.normalizeEmail("a@b.c"));
    assertNull(LocalSignIn.normalizeEmail(7));
    assertNull(LocalSignIn.normalizeEmail("x".repeat(65) + "@aig.example"));
  }

  static ResolvedConfig cfg(AigEnvironment env, AuthPlan plan) {
    return new ResolvedConfig(env, "http://localhost:8080", true, plan, "general", List.of());
  }

  @Test
  void signInAsAnyEmailLocallyAndSwitchUser() throws Exception {
    LocalSessionStore.InMemory local = new LocalSessionStore.InMemory();
    AuthService auth = new AuthService(new InMemoryTokenStore(), local, url -> fail("no browser for an email sign-in"));
    ResolvedConfig c = cfg(AigEnvironment.LOCAL, AuthPlan.localBrowser());
    assertNull(auth.lastLocalEmail());
    assertEquals("premium.quality@aig.example", auth.signInAs(c, " Premium.Quality@aig.example "));
    assertTrue(auth.hasSession(c));
    assertEquals("Bearer dev:premium.quality@aig.example", "Bearer " + auth.accessToken(c));
    assertEquals("premium.quality@aig.example", auth.account(c));
    // switch user: replaces the session
    auth.signInAs(c, "free.balanced@aig.example");
    assertEquals("dev:free.balanced@aig.example", auth.accessToken(c));
    auth.signOut(c);
    assertFalse(auth.hasSession(c));
    assertEquals("free.balanced@aig.example", auth.lastLocalEmail(), "kept after sign-out to prefill the email field");
    assertThrows(NotSignedInException.class, () -> auth.signInAs(c, "not-an-email"));
    assertFalse(auth.hasSession(c));
  }

  @Test
  void signInAsIsLocalBrowserOnly() {
    LocalSessionStore.InMemory local = new LocalSessionStore.InMemory();
    AuthService auth = new AuthService(new InMemoryTokenStore(), local, url -> {});
    NotSignedInException ms = assertThrows(NotSignedInException.class,
        () -> auth.signInAs(cfg(AigEnvironment.DEV, AuthPlan.microsoft(new AuthPlan.EntraConfig("https://login.microsoftonline.com", "t", "c", "s"))), "a@b.co"));
    assertTrue(ms.getMessage().contains("only available in the local environment"), ms.getMessage());
    NotSignedInException dev = assertThrows(NotSignedInException.class, () -> auth.signInAs(cfg(AigEnvironment.LOCAL, AuthPlan.dev("jane@example.com")), "a@b.co"));
    assertTrue(dev.getMessage().contains("dev user"), dev.getMessage());
    assertThrows(NotSignedInException.class,
        () -> auth.signInAs(new ResolvedConfig(AigEnvironment.LOCAL, null, false, AuthPlan.localBrowser(), "general", List.of("backend URL missing")), "a@b.co"));
    assertNull(local.load(), "nothing stored");
  }

  @Test
  void queryParsing() {
    Map<String, String> q = Query.parse("a=1&b=x%20y&a=2&c&d=%E2%82%AC+");
    assertEquals("1", q.get("a"));
    assertEquals("x y", q.get("b"));
    assertEquals("", q.get("c"));
    assertEquals("€ ", q.get("d"));
  }

  @Test
  void loopbackReceiverEndToEnd() throws Exception {
    String state = pending.issue();
    try (LoopbackReceiver rx = new LoopbackReceiver("/auth/callback", (p, q) -> LocalSignIn.handleCallback(p, q, pending))) {
      assertTrue(rx.redirectUri().matches("http://127\\.0\\.0\\.1:\\d+/auth/callback"));
      HttpClient http = HttpClient.newHttpClient();
      HttpResponse<String> nf = http.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + rx.port() + "/favicon.ico")).build(),
          HttpResponse.BodyHandlers.ofString());
      assertEquals(404, nf.statusCode());
      assertFalse(rx.result().isDone(), "other paths do not complete the sign-in");
      HttpResponse<String> ok = http.send(HttpRequest.newBuilder(URI.create(rx.redirectUri() + "?email=jane%40example.com&state=" + state)).build(),
          HttpResponse.BodyHandlers.ofString());
      assertEquals(200, ok.statusCode());
      assertTrue(ok.body().contains("signed in"));
      assertEquals("default-src 'none'; style-src 'unsafe-inline'", ok.headers().firstValue("content-security-policy").orElse(""));
      CallbackResult r = rx.await(Duration.ofSeconds(5));
      assertEquals("jane@example.com", r.value());
    }
  }

  @Test
  void loopbackReceiverRejectsBadStateAndCancel() throws Exception {
    try (LoopbackReceiver rx = new LoopbackReceiver("/auth/callback", (p, q) -> LocalSignIn.handleCallback(p, q, pending))) {
      HttpResponse<String> r = HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create(rx.redirectUri() + "?email=a%40b.co&state=forged%3Cx%3E")).build(),
          HttpResponse.BodyHandlers.ofString());
      assertEquals(400, r.statusCode());
      assertFalse(r.body().contains("<x>"), "message is HTML-escaped");
      assertFalse(rx.await(Duration.ofSeconds(5)).ok());
    }
    LoopbackReceiver rx2 = new LoopbackReceiver("/auth/callback", (p, q) -> CallbackResult.ok("x"));
    rx2.close();
    assertEquals("sign-in was cancelled", rx2.result().get().reason());
  }
}
