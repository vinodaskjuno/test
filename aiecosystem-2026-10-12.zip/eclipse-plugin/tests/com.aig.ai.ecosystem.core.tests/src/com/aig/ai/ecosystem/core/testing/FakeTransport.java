package com.aig.ai.ecosystem.core.testing;

import com.aig.ai.ecosystem.core.ws.WsTransport;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** In-memory {@link WsTransport}: records connects and sent frames; the test drives callbacks. */
public final class FakeTransport implements WsTransport {
  public final class Conn implements Connection {
    public final URI uri;
    public final Map<String, String> headers;
    public final Listener listener;
    public final List<String> sent = new ArrayList<>();
    public boolean closed;
    public int closeCode;

    Conn(URI uri, Map<String, String> headers, Listener listener) {
      this.uri = uri;
      this.headers = headers;
      this.listener = listener;
    }

    @Override
    public synchronized void send(String text) {
      sent.add(text);
    }

    @Override
    public void close(int code, String reason) {
      closed = true;
      closeCode = code;
    }

    public synchronized List<String> sent() {
      return new ArrayList<>(sent);
    }
  }

  public final List<Conn> conns = new ArrayList<>();
  public RuntimeException failNext;

  @Override
  public synchronized Connection connect(URI uri, Map<String, String> headers, Listener listener) {
    if (failNext != null) {
      RuntimeException e = failNext;
      failNext = null;
      throw e;
    }
    Conn c = new Conn(uri, headers, listener);
    conns.add(c);
    return c;
  }

  public synchronized Conn last() {
    return conns.get(conns.size() - 1);
  }
}
