package com.aig.ai.ecosystem.core.live;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/** Same rules as web/packages/ui parseWebviewMessage for the agent commands. */
class AgentMessageTest {
  @Test
  void simpleCommands() {
    for (String c : new String[] {"catalog.refresh", "agent.register", "agent.runs.refresh"}) assertEquals(c, AgentMessage.parse("{\"cmd\":\"" + c + "\"}").cmd());
    assertNull(AgentMessage.parse("{\"cmd\":\"ready\"}"), "not an agent command");
    assertNull(AgentMessage.parse("[1]"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.nope\"}"));
  }

  @Test
  void openShowPollCancelClipboard() {
    AgentMessage o = AgentMessage.parse("{\"cmd\":\"agent.open\",\"agentId\":\"claims-triage\",\"env\":\"stage\",\"version\":\"1.5\"}");
    assertEquals("claims-triage", o.agentId());
    assertEquals("stage", o.env());
    assertEquals("1.5", o.version());
    assertNotNull(AgentMessage.parse("{\"cmd\":\"agent.open\",\"agentId\":\"a\"}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.open\",\"agentId\":\"a b\"}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.open\",\"agentId\":\"a\",\"env\":\"qa\"}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.open\",\"agentId\":\"a\",\"env\":null}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.open\",\"agentId\":\"a\",\"version\":\"../x\"}"));
    assertEquals("inv-1", AgentMessage.parse("{\"cmd\":\"agent.run.show\",\"invocationId\":\"inv-1\"}").invocationId());
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.run.show\",\"invocationId\":\"inv/1\"}"));
    assertEquals("l1", AgentMessage.parse("{\"cmd\":\"agent.poll\",\"localId\":\"l1\",\"invocationId\":\"i\"}").localId());
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.poll\",\"localId\":\"l1\"}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.cancel\",\"localId\":\"l 1\"}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.cancel\",\"localId\":\"l1\",\"invocationId\":5}"));
    assertNull(AgentMessage.parse("{\"cmd\":\"agent.cancel\",\"localId\":\"l1\"}").invocationId());
    assertEquals("x", AgentMessage.parse("{\"cmd\":\"clipboard.copy\",\"text\":\"x\"}").text());
    assertNull(AgentMessage.parse("{\"cmd\":\"clipboard.copy\",\"text\":\"" + "x".repeat(1_000_001) + "\"}"));
  }

  @Test
  void invokeValidation() {
    AgentMessage in = AgentMessage.parse("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"claims-triage\",\"mode\":\"stream\",\"env\":\"prod\","
        + "\"input\":{\"claim_id\":\"CLM-1\",\"n\":[1,2]},\"sessionId\":\"case:4411\"}");
    assertEquals("stream", in.mode());
    assertEquals("CLM-1", in.input().get("claim_id"));
    assertEquals("case:4411", in.sessionId());
    AgentMessage chat = AgentMessage.parse("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a\",\"mode\":\"background\","
        + "\"messages\":[{\"role\":\"user\",\"content\":\"q\"},{\"role\":\"assistant\",\"content\":\"a\"},{\"role\":\"user\",\"content\":\"q2\"}]}");
    assertEquals(3, chat.messages().size());
    String base = "{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a\",";
    String[] bad = {
      base + "\"mode\":\"sync\",\"input\":{}}",
      base + "\"mode\":\"stream\"}",
      base + "\"mode\":\"stream\",\"input\":{},\"messages\":[{\"role\":\"user\",\"content\":\"q\"}]}",
      base + "\"mode\":\"stream\",\"input\":null,\"messages\":[{\"role\":\"user\",\"content\":\"q\"}]}",
      base + "\"mode\":\"stream\",\"input\":[1]}",
      base + "\"mode\":\"stream\",\"input\":\"text\"}",
      base + "\"mode\":\"stream\",\"input\":{\"big\":\"" + "x".repeat(AgentMessage.MAX_INPUT_BYTES) + "\"}}",
      base + "\"mode\":\"stream\",\"messages\":[]}",
      base + "\"mode\":\"stream\",\"messages\":[{\"role\":\"system\",\"content\":\"q\"}]}",
      base + "\"mode\":\"stream\",\"messages\":[{\"role\":\"user\",\"content\":\"q\"},{\"role\":\"assistant\",\"content\":\"a\"}]}",
      base + "\"mode\":\"stream\",\"input\":{},\"sessionId\":\"bad id\"}",
      base + "\"mode\":\"stream\",\"input\":{},\"env\":\"qa\"}",
      "{\"cmd\":\"agent.invoke\",\"localId\":\"r 1\",\"agentId\":\"a\",\"mode\":\"stream\",\"input\":{}}",
      "{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a/b\",\"mode\":\"stream\",\"input\":{}}",
    };
    for (String b : bad) assertNull(AgentMessage.parse(b), b.length() > 200 ? b.substring(0, 200) : b);
  }
}
