package com.aig.ai.ecosystem.core.live;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

/** TEMPORARY demo-data mode (docs/demo-data.md): the page answers its widgets; Java only does commands and navigation. */
class DemoBridgeTest {
  final List<String> commands = new ArrayList<>();
  final List<String> hostCalls = new ArrayList<>();
  final DemoBridge bridge = new DemoBridge(commands::add, new AgentBridge.Host() {
    @Override
    public void openRun(String targetMessage) {
      hostCalls.add("openRun " + targetMessage);
    }

    @Override
    public void register() {
      hostCalls.add("register");
    }

    @Override
    public void showRun(String invocationId) {
      hostCalls.add("showRun " + invocationId);
    }

    @Override
    public void copy(String text) {
      hostCalls.add("copy " + text);
    }
  });

  @Test
  void hostCommandsGoToEclipse() {
    for (String c : List.of("ready", "signIn", "signOut", "openDashboard", "openPanel", "selectEnvironment")) {
      assertTrue(bridge.receive("{\"cmd\":\"" + c + "\"}"), c);
    }
    assertEquals(List.of("ready", "signIn", "signOut", "openDashboard", "openPanel", "selectEnvironment"), commands);
  }

  @Test
  void agentNavigationOpensTheRunViewWithADemoRequest() {
    assertTrue(bridge.receive("{\"cmd\":\"agent.open\",\"agentId\":\"claims-triage\",\"env\":\"prod\",\"version\":\"3.9.5\"}"));
    assertTrue(bridge.receive("{\"cmd\":\"agent.run.show\",\"invocationId\":\"inv_123\"}"));
    assertTrue(bridge.receive("{\"cmd\":\"agent.register\"}"));
    assertTrue(bridge.receive("{\"cmd\":\"clipboard.copy\",\"text\":\"hi\"}"));
    assertEquals(List.of("openRun {\"type\":\"demo.open\",\"agentId\":\"claims-triage\",\"env\":\"prod\",\"version\":\"3.9.5\"}", "showRun inv_123", "register", "copy hi"),
        hostCalls);
    assertTrue(DemoBridge.isOpen(DemoBridge.open("a", null, null)));
    assertFalse(DemoBridge.isOpen(HostMessages.agentTargetError("x", "y")));
    assertEquals("inv_9", Json.str(Json.parseObject(DemoBridge.show("inv_9")), "invocationId"));
  }

  @Test
  void dataMessagesAndInvalidInputAreNotHandledInJava() {
    assertFalse(bridge.receive("{\"cmd\":\"range\",\"days\":7}"));
    assertFalse(bridge.receive("{\"cmd\":\"catalog.refresh\"}"));
    assertFalse(bridge.receive("{\"cmd\":\"agent.invoke\",\"localId\":\"r1\",\"agentId\":\"a\",\"mode\":\"stream\",\"input\":{}}"));
    assertFalse(bridge.receive("{\"cmd\":\"agent.open\",\"agentId\":\"bad id!\"}"));
    assertFalse(bridge.receive("not json"));
    bridge.dispose();
    assertFalse(bridge.receive("{\"cmd\":\"signIn\"}"));
    assertTrue(commands.isEmpty());
    assertTrue(hostCalls.isEmpty());
  }
}
