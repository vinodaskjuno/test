package com.aig.ai.ecosystem.core.invoke;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AgentRegistrationTest {
  static final String ARN = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/agents/claims-triage/invoke-auth-AbCdEf";

  @Test
  void agentFields() {
    assertNull(AgentRegistration.agentProblem("claims-triage", "Claims triage", "desc", List.of("claims", "triage.v2")));
    assertNotNull(AgentRegistration.agentProblem("bad id", null, null, null));
    assertNotNull(AgentRegistration.agentProblem("a".repeat(65), null, null, null));
    assertNotNull(AgentRegistration.agentProblem("ok", null, "x".repeat(501), null));
    assertNotNull(AgentRegistration.agentProblem("ok", null, null, List.of("Upper")));
    assertNotNull(AgentRegistration.agentProblem("ok", null, null, java.util.Collections.nCopies(21, "t")));
    assertEquals(List.of("claims", "uw", "x-1"), AgentRegistration.parseTags(" Claims, uw  x-1,claims "));
  }

  @Test
  void endpointRules() {
    assertNull(AgentRegistration.endpointProblem("https://agents.example.com/claims", "prod"));
    assertNull(AgentRegistration.endpointProblem("http://localhost:8080", "local"));
    assertNotNull(AgentRegistration.endpointProblem("http://localhost:8080", "dev"));
    assertNotNull(AgentRegistration.endpointProblem("https://localhost:8080", "prod"));
    assertNotNull(AgentRegistration.endpointProblem("http://agents.example.com", "dev"));
    assertNotNull(AgentRegistration.endpointProblem("https://user:pw@agents.example.com", "dev"));
    assertNotNull(AgentRegistration.endpointProblem("https://agents.example.com/?key=1", "dev"));
    assertNotNull(AgentRegistration.endpointProblem("https://agents.example.com/#x", "dev"));
    assertNotNull(AgentRegistration.endpointProblem("agents.example.com", "dev"));
    assertNotNull(AgentRegistration.endpointProblem("", "dev"));
  }

  @Test
  void onlySecretReferencesAreAccepted() {
    assertNull(AgentRegistration.secretProblem("none", "", "prod"));
    assertNotNull(AgentRegistration.secretProblem("none", ARN, "prod"));
    assertNull(AgentRegistration.secretProblem("api_key", ARN, "prod"));
    assertNull(AgentRegistration.secretProblem("oauth_client_credentials", ARN, "dev"));
    assertNull(AgentRegistration.secretProblem("api_key", "local:CLAIMS_KEY", "local"));
    assertNotNull(AgentRegistration.secretProblem("api_key", "local:CLAIMS_KEY", "dev"));
    assertNotNull(AgentRegistration.secretProblem("api_key", "sk-" + "live-" + "0123456789abcdef", "prod"), "a pasted key is refused");
    assertNotNull(AgentRegistration.secretProblem("api_key", "", "prod"));
    assertNotNull(AgentRegistration.secretProblem("basic", ARN, "prod"));
  }

  @Test
  void schemaMustBeAJsonObject() {
    assertNull(AgentRegistration.parseSchema("  "));
    Map<String, Object> s = AgentRegistration.parseSchema("{\"type\":\"object\",\"properties\":{\"claim_id\":{\"type\":\"string\"}}}");
    assertEquals("object", s.get("type"));
    assertThrows(IllegalArgumentException.class, () -> AgentRegistration.parseSchema("[1,2]"));
    assertThrows(IllegalArgumentException.class, () -> AgentRegistration.parseSchema("{oops"));
    assertThrows(IllegalArgumentException.class, () -> AgentRegistration.parseSchema("{\"type\":5}"));
    assertThrows(IllegalArgumentException.class, () -> AgentRegistration.parseSchema("{\"a\":\"" + "x".repeat(70_000) + "\"}"));
  }

  @Test
  void versionBodyCarriesOnlyTheReference() {
    AgentRegistration.VersionSpec spec = new AgentRegistration.VersionSpec("1.4.0", "prod", "https://agents.example.com/claims/", "api_key", ARN,
        Map.of("type", "object"));
    assertNull(AgentRegistration.versionProblem(spec));
    Map<String, Object> b = spec.toJson();
    assertEquals("https", b.get("kind"));
    assertEquals("aig-http/1", b.get("protocol"));
    assertEquals("{\"type\":\"api_key\",\"secret_arn\":\"" + ARN + "\"}", Json.write(b.get("auth")));
    AgentRegistration.VersionSpec none = new AgentRegistration.VersionSpec("1.0", "dev", "https://a.example.com", "none", null, null);
    assertEquals("{\"type\":\"none\"}", Json.write(none.toJson().get("auth")));
    assertFalse(none.toJson().containsKey("input_schema"));
    assertNotNull(AgentRegistration.versionProblem(new AgentRegistration.VersionSpec("-bad", "dev", "https://a.example.com", "none", null, null)));
    assertNotNull(AgentRegistration.versionProblem(new AgentRegistration.VersionSpec("1.0", "qa", "https://a.example.com", "none", null, null)));
  }
}
