package com.aig.ai.ecosystem.core.ws;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.json.Json;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class WsProtocolTest {
  @Test
  void wsUrl() {
    assertEquals("wss://aig.example.com/base/api/v1/ws", WsProtocol.wsUrl("https://aig.example.com/base/").toString());
    assertEquals("ws://localhost:8080/api/v1/ws", WsProtocol.wsUrl("http://localhost:8080").toString());
  }

  @Test
  void readyFrame() {
    ServerFrame f = WsProtocol.parse("{\"type\":\"ready\",\"user\":{\"email\":\"jane@example.com\",\"name\":\"Jane\"},\"team\":\"uw\",\"env\":\"local\","
        + "\"user_tier\":\"premium\",\"allowed_job_profiles\":[\"claims\",3,\"general\"],\"server_time\":\"x\"}");
    assertEquals("ready", f.type());
    assertEquals("jane@example.com", f.ready().email());
    assertEquals("Jane", f.ready().name());
    assertEquals("premium", f.ready().userTier());
    assertEquals(List.of("claims", "general"), f.ready().allowedJobProfiles());
    assertNull(WsProtocol.parse("{\"type\":\"ready\",\"user\":{}}"));
  }

  @Test
  void chatFrames() {
    ServerFrame d = WsProtocol.parse("{\"type\":\"chat.delta\",\"id\":\"c1\",\"text\":\"hi\"}");
    assertEquals("hi", d.text());
    assertEquals("", WsProtocol.parse("{\"type\":\"chat.delta\",\"id\":\"c1\"}").text());
    ServerFrame done = WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"trace_id\":\"t\",\"usage\":{\"prompt_tokens\":3,\"completion_tokens\":-1,\"total_tokens\":\"x\"}}");
    assertEquals("t", done.traceId());
    assertEquals(3L, done.usage().get("prompt_tokens"));
    assertEquals(0L, done.usage().get("completion_tokens"));
    assertEquals(0L, done.usage().get("total_tokens"));
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\"}").usage());
    assertNull(done.model());
    assertNull(done.route());
    ServerFrame err = WsProtocol.parse("{\"type\":\"chat.error\",\"id\":\"c1\",\"code\":\"cancelled\"}");
    assertEquals("cancelled", err.code());
    assertEquals("cancelled", err.message());
    assertNull(WsProtocol.parse("{\"type\":\"chat.delta\",\"text\":\"no id\"}"));
  }

  @Test
  void chatDoneModelAndRoute() {
    ServerFrame f = WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"model\":\"us.anthropic.claude-sonnet-4-5-20250929-v1:0\","
        + "\"route\":{\"user_tier\":\"premium\",\"cost_mode\":\"quality\",\"job_profile\":\"claims\"}}");
    assertEquals("us.anthropic.claude-sonnet-4-5-20250929-v1:0", f.model());
    assertEquals(Map.of("user_tier", "premium", "cost_mode", "quality", "job_profile", "claims"), f.route());
    // non-string sub-fields are dropped
    ServerFrame partial = WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"model\":7,\"route\":{\"user_tier\":\"standard\",\"cost_mode\":1,\"job_profile\":null}}");
    assertNull(partial.model());
    assertEquals(Map.of("user_tier", "standard"), partial.route());
    // route only with a non-empty string user_tier
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"cost_mode\":\"quality\"}}").route());
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"user_tier\":\"\"}}").route());
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"user_tier\":3}}").route());
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":\"premium\",\"model\":\"\"}").route());
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"model\":\"\"}").model());
  }

  @Test
  void chatDoneRouteUsageState() {
    ServerFrame f = WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"user_tier\":\"premium\",\"cost_mode\":\"quality\","
        + "\"job_profile\":\"general\",\"usage_state\":\"soft\"}}");
    assertEquals(Map.of("user_tier", "premium", "cost_mode", "quality", "job_profile", "general", "usage_state", "soft"), f.route());
    // optional: a non-string or empty usage_state is dropped
    assertEquals(Map.of("user_tier", "standard"),
        WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"user_tier\":\"standard\",\"usage_state\":\"\"}}").route());
    assertEquals(Map.of("user_tier", "standard"),
        WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"user_tier\":\"standard\",\"usage_state\":2}}").route());
    // usage_state alone is not a route
    assertNull(WsProtocol.parse("{\"type\":\"chat.done\",\"id\":\"c1\",\"route\":{\"usage_state\":\"hard\"}}").route());
  }

  @Test
  void usageAndErrorFrames() {
    ServerFrame u = WsProtocol.parse("{\"type\":\"usage\",\"days\":7,\"data\":{\"totals\":{\"users\":1},\"models\":[]}}");
    assertEquals(7, u.days());
    assertEquals(1.0, Json.num(Json.obj(u.data(), "totals"), "users"));
    assertNull(WsProtocol.parse("{\"type\":\"usage\",\"days\":7,\"data\":{\"models\":[]}}"));
    ServerFrame ue = WsProtocol.parse("{\"type\":\"usage.error\",\"code\":\"usage_not_configured\",\"message\":\"m\"}");
    assertEquals("usage_not_configured", ue.code());
    assertEquals("error", WsProtocol.parse("{\"type\":\"error\"}").code());
    assertEquals("ping", WsProtocol.parse("{\"type\":\"ping\"}").type());
  }

  @Test
  void malformedOrUnknown() {
    for (String bad : new String[] {"", "x", "[]", "{}", "{\"type\":\"nope\"}", "{\"type\":5}", "null"}) assertNull(WsProtocol.parse(bad), bad);
  }

  @Test
  void clientFrames() {
    Map<String, Object> chat = Json.parseObject(WsProtocol.chat("c1", List.of(new ChatMessage("user", "q")), "claims", "ide.eclipse"));
    assertEquals("chat", chat.get("type"));
    assertEquals("claims", chat.get("job_profile"));
    assertEquals("ide.eclipse", chat.get("agent_id"));
    assertFalse(Json.parseObject(WsProtocol.chat("c1", List.of(new ChatMessage("user", "q")), null, null)).containsKey("agent_id"));
    assertThrows(IllegalArgumentException.class, () -> WsProtocol.chat("bad id", List.of(), null, null));
    assertEquals("{\"type\":\"usage.subscribe\",\"days\":90}", WsProtocol.usageSubscribe(90));
    assertEquals("{\"type\":\"cancel\",\"id\":\"c1\"}", WsProtocol.cancel("c1"));
    assertEquals("{\"type\":\"usage.unsubscribe\"}", WsProtocol.usageUnsubscribe());
    assertEquals("{\"type\":\"ping\"}", WsProtocol.ping());
  }
}
