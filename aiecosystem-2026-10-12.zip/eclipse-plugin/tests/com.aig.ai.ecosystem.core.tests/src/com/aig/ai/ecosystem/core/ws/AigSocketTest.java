package com.aig.ai.ecosystem.core.ws;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.testing.FakeTransport;
import com.aig.ai.ecosystem.core.testing.ManualScheduler;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AigSocketTest {
  final FakeTransport transport = new FakeTransport();
  final ManualScheduler scheduler = new ManualScheduler();
  final List<String> statuses = new ArrayList<>();
  final List<ServerFrame> frames = new ArrayList<>();
  ReadyInfo ready;

  AigSocket socket(AigSocket.TokenSource tokens) {
    return new AigSocket(URI.create("ws://localhost:8080/api/v1/ws"), tokens, transport, new AigSocket.Events() {
      @Override
      public void onStatus(LiveStatus s, String detail) {
        statuses.add(s.id());
      }

      @Override
      public void onReady(ReadyInfo info) {
        ready = info;
      }

      @Override
      public void onFrame(ServerFrame f) {
        frames.add(f);
      }
    }, scheduler);
  }

  @Test
  void connectsWithBearerHeaderAndSubscribesOnOpen() {
    AigSocket s = socket(() -> "dev:jane@example.com");
    s.requestUsage(30);
    s.start();
    FakeTransport.Conn c = transport.last();
    assertEquals(Map.of("Authorization", "Bearer dev:jane@example.com"), c.headers);
    assertEquals("ws://localhost:8080/api/v1/ws", c.uri.toString());
    assertFalse(c.uri.toString().contains("dev:"), "token is never in the URL");
    assertFalse(s.isOpen());
    c.listener.onOpen();
    assertTrue(s.isOpen());
    assertEquals(List.of("{\"type\":\"usage.subscribe\",\"days\":30}"), c.sent());
    c.listener.onText("{\"type\":\"ready\",\"user\":{\"email\":\"jane@example.com\"}}");
    assertEquals("jane@example.com", ready.email());
    c.listener.onText("{\"type\":\"ping\"}");
    assertEquals("{\"type\":\"pong\"}", c.sent().get(1));
    c.listener.onText("garbage");
    assertEquals(2, frames.size());
    assertEquals(List.of("connecting", "open"), statuses);
  }

  @Test
  void chatStreamsAndCompletes() {
    AigSocket s = socket(() -> "t");
    s.start();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    StringBuilder text = new StringBuilder();
    String[] done = new String[2];
    Object[] route = new Object[1];
    String id = s.chat(List.of(new ChatMessage("user", "q")), new AigSocket.ChatHandlers() {
      @Override
      public void onDelta(String t) {
        text.append(t);
      }

      @Override
      public void onDone(String traceId, Map<String, Object> usage, String model, Map<String, Object> r) {
        done[0] = traceId;
        done[1] = model;
        route[0] = r;
      }

      @Override
      public void onError(String code, String message) {
        fail(code);
      }
    }, "claims", "ide.eclipse");
    assertTrue(WsProtocol.CHAT_ID.matcher(id).matches());
    assertTrue(c.sent().get(0).contains("\"type\":\"chat\""));
    c.listener.onText("{\"type\":\"chat.delta\",\"id\":\"" + id + "\",\"text\":\"Hel\"}");
    c.listener.onText("{\"type\":\"chat.delta\",\"id\":\"other\",\"text\":\"zzz\"}");
    c.listener.onText("{\"type\":\"chat.delta\",\"id\":\"" + id + "\",\"text\":\"lo\"}");
    c.listener.onText("{\"type\":\"chat.done\",\"id\":\"" + id + "\",\"trace_id\":\"tr\",\"model\":\"m-1\",\"route\":{\"user_tier\":\"standard\",\"cost_mode\":\"economy\"}}");
    assertEquals("Hello", text.toString());
    assertEquals("tr", done[0]);
    assertEquals("m-1", done[1]);
    assertEquals(Map.of("user_tier", "standard", "cost_mode", "economy"), route[0]);
    assertEquals(0, s.activeChats());
    s.cancel(id); // finished: nothing sent
    assertEquals(1, c.sent().size());
  }

  @Test
  void chatRequiresOpenSocket() {
    AigSocket s = socket(() -> "t");
    assertThrows(IllegalStateException.class, () -> s.chat(List.of(new ChatMessage("user", "q")), null, null, null));
  }

  @Test
  void reconnectsWithBackoffAndFailsInflightChats() {
    AigSocket s = socket(() -> "t");
    s.requestUsage(7);
    s.start();
    FakeTransport.Conn c1 = transport.last();
    c1.listener.onOpen();
    List<String> errors = new ArrayList<>();
    s.chat(List.of(new ChatMessage("user", "q")), new AigSocket.ChatHandlers() {
      public void onDelta(String t) {}

      public void onDone(String t, Map<String, Object> u, String m, Map<String, Object> r) {}

      public void onError(String code, String m) {
        errors.add(code);
      }
    }, null, null);
    c1.listener.onClose(1006, "gone");
    assertEquals(List.of("disconnected"), errors);
    assertEquals("reconnecting", statuses.get(statuses.size() - 1));
    assertEquals(List.of(1000L), scheduler.pendingDelays());
    scheduler.runPending();
    FakeTransport.Conn c2 = transport.last();
    assertNotSame(c1, c2);
    c2.listener.onClose(1006, "again");
    assertEquals(List.of(2000L), scheduler.pendingDelays());
    scheduler.runPending();
    FakeTransport.Conn c3 = transport.last();
    c3.listener.onOpen();
    assertEquals(List.of("{\"type\":\"usage.subscribe\",\"days\":7}"), c3.sent(), "an unanswered usage request is re-sent after reconnect");
    // Stale callbacks from an old connection are ignored.
    c1.listener.onText("{\"type\":\"ping\"}");
    assertEquals(1, c3.sent().size());
  }

  @Test
  void answeredUsageRequestIsNotResentOnReconnect() {
    AigSocket s = socket(() -> "t");
    s.requestUsage(30);
    s.start();
    FakeTransport.Conn c1 = transport.last();
    c1.listener.onOpen();
    assertEquals(30, s.pendingUsage());
    c1.listener.onText("{\"type\":\"usage\",\"days\":7,\"data\":{\"totals\":{},\"models\":[]}}");
    assertEquals(30, s.pendingUsage(), "a frame for another range does not answer it");
    c1.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":{\"totals\":{},\"models\":[]}}");
    assertNull(s.pendingUsage());
    c1.listener.onClose(1006, "gone");
    scheduler.runPending();
    FakeTransport.Conn c2 = transport.last();
    c2.listener.onOpen();
    assertTrue(c2.sent().isEmpty(), "no usage.subscribe after the answer: " + c2.sent());
    s.requestUsage(90);
    assertEquals(List.of("{\"type\":\"usage.subscribe\",\"days\":90}"), c2.sent());
    c2.listener.onText("{\"type\":\"usage.error\",\"code\":\"x\",\"message\":\"y\"}");
    assertNull(s.pendingUsage());
    s.requestUsage(7);
    assertEquals(7, s.cancelUsageRequest());
    assertNull(s.pendingUsage());
  }

  @Test
  void unauthorizedCloseStopsReconnecting() {
    for (int code : new int[] {4401, 4403, 1008}) {
      AigSocket s = socket(() -> "t");
      s.start();
      transport.last().listener.onClose(code, "");
      assertEquals(LiveStatus.UNAUTHORIZED, s.state());
      assertTrue(scheduler.pendingDelays().isEmpty());
    }
  }

  @Test
  void tokenFailureIsUnauthorized() {
    AigSocket s = socket(() -> {
      throw new IllegalStateException("Not signed in");
    });
    s.start();
    assertEquals(LiveStatus.UNAUTHORIZED, s.state());
    assertTrue(transport.conns.isEmpty());
  }

  @Test
  void stopClosesAndDoesNotReconnect() {
    AigSocket s = socket(() -> "t");
    s.start();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    s.stop();
    assertTrue(c.closed);
    assertEquals(1000, c.closeCode);
    c.listener.onClose(1000, "client stop");
    assertEquals(LiveStatus.CLOSED, s.state());
    assertTrue(scheduler.pendingDelays().isEmpty());
  }

  @Test
  void transportFailureRetries() {
    transport.failNext = new IllegalStateException("boom");
    AigSocket s = socket(() -> "t");
    s.start();
    assertEquals(LiveStatus.RECONNECTING, s.state());
    assertEquals(List.of(1000L), scheduler.pendingDelays());
  }
}
