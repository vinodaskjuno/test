package com.aig.ai.ecosystem.core.live;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.auth.AuthService;
import com.aig.ai.ecosystem.core.auth.InMemoryTokenStore;
import com.aig.ai.ecosystem.core.auth.LocalSessionStore;
import com.aig.ai.ecosystem.core.config.AigSettings;
import com.aig.ai.ecosystem.core.config.ConfigResolver;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.FakeTransport;
import com.aig.ai.ecosystem.core.testing.ManualScheduler;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer.Response;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LiveServiceTest {
  static final String LIMITS = "{\"user\":\"jane@example.com\",\"user_tier\":\"standard\",\"soft_threshold\":0.8,"
      + "\"limits\":{\"daily\":{\"requests\":5}},\"state\":\"hard\",\"configured\":true,\"checks\":[{\"period\":\"daily\",\"metric\":\"requests\","
      + "\"limit\":5,\"used\":7.0,\"ratio\":1.4,\"status\":\"hard\",\"since\":\"2026-10-11T00:00:00+00:00\"}],\"checked_at\":\"2026-10-11T13:01:09+00:00\"}";
  static final String DASH = "{\"env\":\"local\",\"window\":{\"days\":30},\"totals\":{\"users\":3,\"tokens\":42},\"models\":[]}";

  MiniHttpServer backend;
  final FakeTransport transport = new FakeTransport();
  final ManualScheduler scheduler = new ManualScheduler();
  final LocalSessionStore.InMemory local = new LocalSessionStore.InMemory();
  final AtomicReference<ResolvedConfig> cfg = new AtomicReference<>();
  final List<String> out = new ArrayList<>();
  final List<String> commands = new ArrayList<>();
  final List<Boolean> signedIn = new ArrayList<>();
  final AtomicReference<Response> limitsResponse = new AtomicReference<>(Response.json(200, LIMITS));
  AuthService auth;
  LiveService live;

  @BeforeEach
  void setUp() throws Exception {
    backend = new MiniHttpServer(r -> switch (r.path()) {
      case "/api/v1/usage/dashboard" -> Response.json(200, DASH);
      case "/api/v1/usage/limits" -> limitsResponse.get();
      case "/api/v1/session" -> Response.json(200, "{\"user\":{\"email\":\"jane@example.com\"},\"env\":\"local\",\"team\":\"uw-ai\",\"user_tier\":\"standard\","
          + "\"cost_mode\":\"balanced\",\"allowed_job_profiles\":[\"general\",\"claims\"],\"llm\":{\"base_url\":\"x\"}}");
      default -> Response.json(404, "{}");
    });
    AigSettings s = AigSettings.defaults("local").withEnv(com.aig.ai.ecosystem.core.config.AigEnvironment.LOCAL,
        com.aig.ai.ecosystem.core.config.EnvSettings.defaults(com.aig.ai.ecosystem.core.config.AigEnvironment.LOCAL)).withDevUser("jane@example.com");
    ResolvedConfig base = ConfigResolver.resolve(s);
    cfg.set(new ResolvedConfig(base.env(), backend.baseUrl(), true, base.auth(), "general", List.of()));
    auth = new AuthService(new InMemoryTokenStore(), local, url -> {});
    live = new LiveService(cfg::get, auth, transport, scheduler, c -> new BackendClient(c.backendUrl(), () -> auth.accessToken(c)), Runnable::run,
        m -> {});
    live.addListener(out::add);
    live.addSignedInListener(signedIn::add);
  }

  @AfterEach
  void tearDown() throws Exception {
    live.dispose();
    backend.close();
  }

  List<String> types() {
    List<String> t = new ArrayList<>();
    for (String m : out) t.add(Json.str(Json.parseObject(m), "type"));
    return t;
  }

  @Test
  void demoSessionSignsInWithoutSocketOrBackend() {
    live.setDemoMode(() -> true);
    live.sync();
    assertFalse(live.isSignedIn());
    live.setDemoSession(true);
    assertTrue(live.isSignedIn());
    assertTrue(live.isDemo());
    assertEquals(List.of(true), signedIn);
    assertTrue(transport.conns.isEmpty(), "no WebSocket in demo mode");
    assertEquals("open", live.status().id());
    live.setRange(7);
    live.refreshUsage();
    assertTrue(backend.requests().isEmpty(), "no backend call in demo mode");
    live.setDemoSession(false);
    assertFalse(live.isSignedIn());
    assertEquals(List.of(true, false), signedIn);
  }

  @Test
  void demoModeIgnoresTheRealSessionAndOffRestoresIt() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    boolean[] demo = {true};
    live.setDemoMode(() -> demo[0]);
    live.sync();
    assertFalse(live.isSignedIn(), "a real session does not count in demo mode");
    demo[0] = false;
    live.sync();
    assertTrue(live.isSignedIn());
    assertFalse(transport.conns.isEmpty());
  }

  @Test
  void signedOutStaysIdle() {
    live.sync();
    assertFalse(live.isSignedIn());
    assertTrue(transport.conns.isEmpty());
    assertEquals("idle", Json.str(Json.parseObject(live.snapshot().get(1)), "status"));
  }

  @Test
  void signInStartsSocketAndStreamsUsage() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    assertTrue(live.isSignedIn());
    assertEquals(List.of(true), signedIn);
    FakeTransport.Conn c = transport.last();
    assertEquals("Bearer dev:jane@example.com", c.headers.get("Authorization"));
    assertTrue(c.uri.toString().startsWith("ws://127.0.0.1:") && c.uri.toString().endsWith("/api/v1/ws"));
    assertEquals("uw-ai", live.team(), "session loaded over HTTP");
    c.listener.onOpen();
    assertTrue(c.sent().contains("{\"type\":\"usage.subscribe\",\"days\":30}"));
    out.clear();
    c.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + DASH + "}");
    Map<String, Object> usage = Json.parseObject(out.get(out.size() - 1));
    assertEquals("usage", usage.get("type"));
    assertEquals(30L, usage.get("range"));
    assertEquals(42.0, Json.num(Json.obj(Json.obj(usage, "data"), "totals"), "tokens"));
    List<String> snap = live.snapshot();
    assertEquals(List.of("init", "live", "usage", "usage.limits"), snap.stream().map(m -> Json.str(Json.parseObject(m), "type")).toList());
    Map<String, Object> init = Json.obj(Json.parseObject(snap.get(0)), "info");
    assertEquals("local", init.get("env"));
    assertEquals("jane@example.com", init.get("user"));
    assertEquals(List.of("general", "claims"), init.get("jobProfiles"));
    assertEquals("standard", init.get("tier"));
    assertEquals("balanced", init.get("costMode"), "cost mode from /api/v1/session cost_mode");
  }

  @Test
  void rangeChangeResubscribesAndUsageErrorIsForwarded() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    out.clear();
    live.setRange(7);
    assertEquals(List.of("init", "usage.loading", "usage.limits"), types());
    assertTrue(c.sent().contains("{\"type\":\"usage.subscribe\",\"days\":7}"));
    // a stale 30-day push is stored but not forwarded for the 7-day view
    out.clear();
    c.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + DASH + "}");
    assertTrue(out.isEmpty());
    c.listener.onText("{\"type\":\"usage.error\",\"code\":\"usage_not_configured\",\"message\":\"no admin key\"}");
    assertEquals("usage.error", types().get(0));
    live.setRange(14); // ignored
    assertEquals(7, live.range());
  }

  List<String> limitsQueries() {
    return backend.requests().stream().filter(r -> r.path().equals("/api/v1/usage/limits")).map(MiniHttpServer.Request::query).toList();
  }

  @Test
  void usageLimitsLoadOnOpenAndOnRefreshOrRangeOnly() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    assertEquals(List.of("refresh=false"), limitsQueries(), "one load on sign-in, served from the backend cache");
    Map<String, Object> msg = Json.parseObject(out.stream().filter(m -> m.contains("\"usage.limits\"")).findFirst().orElseThrow());
    assertEquals("hard", Json.obj(msg, "data").get("state"));
    assertEquals(true, Json.obj(msg, "data").get("configured"));
    assertEquals(1.4, Json.num(Json.asObject(Json.list(Json.obj(msg, "data"), "checks").get(0)), "ratio"), "passed through untouched");
    assertEquals("2026-10-11T13:01:09+00:00", Json.obj(msg, "data").get("checked_at"));
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    c.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + DASH + "}");
    // a view opening with limits loaded replays them without a request
    List<String> toWidget = new ArrayList<>();
    WidgetBridge bridge = new WidgetBridge(live, toWidget::add, commands::add);
    bridge.receive("{\"cmd\":\"ready\"}");
    assertTrue(toWidget.stream().anyMatch(m -> m.contains("\"usage.limits\"")), "snapshot replays the limits");
    assertEquals(1, limitsQueries().size());
    // reconnect: no request
    c.listener.onClose(1006, "blip");
    scheduler.runPending();
    FakeTransport.Conn c2 = transport.last();
    c2.listener.onOpen();
    assertEquals(1, limitsQueries().size(), "a reconnect does not load limits");
    // a finished chat: no request
    bridge.receive("{\"cmd\":\"chat.send\",\"localId\":\"L1\",\"jobProfile\":\"general\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}");
    String id = (String) Json.parseObject(c2.sent().get(c2.sent().size() - 1)).get("id");
    c2.listener.onText("{\"type\":\"chat.done\",\"id\":\"" + id + "\",\"route\":{\"user_tier\":\"standard\",\"usage_state\":\"hard\"}}");
    assertEquals(1, limitsQueries().size(), "a chat does not load limits");
    Map<String, Object> done = Json.parseObject(toWidget.stream().filter(m -> m.contains("\"chat.done\"")).findFirst().orElseThrow());
    assertEquals("hard", Json.obj(done, "route").get("usage_state"));
    // manual refresh and range change bypass the backend cache
    bridge.receive("{\"cmd\":\"refresh\"}");
    assertEquals(List.of("refresh=false", "refresh=true"), limitsQueries());
    bridge.receive("{\"cmd\":\"range\",\"days\":7}");
    assertEquals(List.of("refresh=false", "refresh=true", "refresh=true"), limitsQueries());
    assertTrue(scheduler.pendingDelays().isEmpty(), "no timers");
    bridge.dispose();
  }

  @Test
  void usageLimitsErrorsAreForwarded() throws Exception {
    limitsResponse.set(Response.json(503, "{\"error\":{\"code\":\"usage_limits_unavailable\",\"message\":\"usage store down\"}}"));
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    Map<String, Object> err = Json.parseObject(out.stream().filter(m -> m.contains("\"usage.limits.error\"")).findFirst().orElseThrow());
    assertEquals("usage_limits_unavailable", err.get("code"));
    assertTrue(((String) err.get("message")).contains("usage store down"), String.valueOf(err.get("message")));
    // a view opening after a failed load shows the error and does not retry (only Refresh does)
    List<String> toWidget = new ArrayList<>();
    WidgetBridge bridge = new WidgetBridge(live, toWidget::add, commands::add);
    bridge.receive("{\"cmd\":\"ready\"}");
    assertTrue(toWidget.stream().anyMatch(m -> m.contains("\"usage.limits.error\"")));
    assertEquals(1, limitsQueries().size());
    // malformed bodies: configured must be a boolean of a JSON object
    for (String bad : List.of("{\"state\":\"normal\"}", "{\"configured\":\"yes\"}", "[]")) {
      limitsResponse.set(Response.json(200, bad));
      out.clear();
      bridge.receive("{\"cmd\":\"refresh\"}");
      Map<String, Object> e = Json.parseObject(out.stream().filter(m -> m.contains("\"usage.limits.error\"")).findFirst().orElseThrow());
      assertEquals("invalid_usage_limits", e.get("code"), bad);
    }
    limitsResponse.set(Response.json(200, "{\"configured\":false,\"state\":\"normal\",\"soft_threshold\":0.8,\"limits\":{},\"checks\":[],\"checked_at\":null}"));
    out.clear();
    bridge.receive("{\"cmd\":\"refresh\"}");
    Map<String, Object> ok = Json.parseObject(out.stream().filter(m -> m.contains("\"usage.limits\"")).findFirst().orElseThrow());
    assertEquals(false, Json.obj(ok, "data").get("configured"));
    assertTrue(Json.obj(ok, "data").containsKey("checked_at"), "null fields are kept");
    assertEquals("usage.limits", Json.str(Json.parseObject(live.snapshot().get(live.snapshot().size() - 1)), "type"), "the error is replaced");
    bridge.dispose();
  }

  long dashboardRequests() {
    return backend.requests().stream().filter(r -> r.path().equals("/api/v1/usage/dashboard")).count();
  }

  static long subscribes(FakeTransport.Conn c) {
    return c.sent().stream().filter(f -> f.contains("\"usage.subscribe\"")).count();
  }

  @Test
  void socketDownMeansOneHttpGetAndNoPolling() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    out.clear();
    c.listener.onClose(1006, "down"); // the session's usage request is still unanswered: one HTTP GET
    assertTrue(types().contains("usage"), types().toString());
    assertEquals(1, dashboardRequests());
    assertEquals(List.of(1000L), scheduler.pendingDelays(), "only the reconnect backoff, no usage poll timer");
    scheduler.runPending(); // reconnect attempt fails again
    transport.last().listener.onClose(1006, "down");
    assertEquals(1, dashboardRequests(), "no polling while the socket stays down");
    live.refreshUsage(); // explicit refresh while down: one HTTP GET
    assertEquals(2, dashboardRequests());
    scheduler.runPending();
    FakeTransport.Conn back = transport.last();
    back.listener.onOpen();
    assertEquals(0, subscribes(back), "answered over HTTP: the reconnect does not ask again");
    assertTrue(backend.requests().stream().noneMatch(r -> r.path().equals("/api/v1/usage/me")), "/usage/me is never called");
  }

  @Test
  void usageLoadsOnceAndOnlyOnExplicitRefresh() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    assertEquals(1, subscribes(c), "one usage request on sign-in");
    c.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + DASH + "}");
    assertTrue(scheduler.pendingDelays().isEmpty(), "no timers once usage is loaded");
    // a view opening with usage loaded does not refetch
    List<String> toWidget = new ArrayList<>();
    WidgetBridge bridge = new WidgetBridge(live, toWidget::add, commands::add);
    bridge.receive("{\"cmd\":\"ready\"}");
    assertEquals(1, subscribes(c));
    // a reconnect after the answer does not ask again
    c.listener.onClose(1006, "blip");
    scheduler.runPending();
    FakeTransport.Conn c2 = transport.last();
    c2.listener.onOpen();
    assertEquals(0, subscribes(c2));
    assertEquals(0, dashboardRequests(), "no HTTP poll");
    // finishing a chat does not refetch usage
    bridge.receive("{\"cmd\":\"chat.send\",\"localId\":\"L1\",\"jobProfile\":\"general\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}");
    String id = (String) Json.parseObject(c2.sent().get(c2.sent().size() - 1)).get("id");
    c2.listener.onText("{\"type\":\"chat.done\",\"id\":\"" + id + "\",\"usage\":{\"total_tokens\":3}}");
    assertEquals(0, subscribes(c2));
    // the refresh button: exactly one request, answered once
    assertTrue(bridge.receive("{\"cmd\":\"refresh\"}"));
    assertEquals(1, subscribes(c2));
    c2.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + DASH + "}");
    c2.listener.onClose(1006, "blip");
    scheduler.runPending();
    transport.last().listener.onOpen();
    assertEquals(0, subscribes(transport.last()));
    assertTrue(scheduler.pendingDelays().isEmpty());
    bridge.dispose();
  }

  @Test
  void widgetReadyLoadsUsageWhenNothingIsLoadedOrPending() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    c.listener.onText("{\"type\":\"usage.error\",\"code\":\"usage_not_configured\",\"message\":\"no admin key\"}");
    WidgetBridge bridge = new WidgetBridge(live, s -> {}, commands::add);
    bridge.receive("{\"cmd\":\"ready\"}");
    assertEquals(1, subscribes(c), "a failed load is retried only by the refresh button");
    bridge.receive("{\"cmd\":\"refresh\"}");
    assertEquals(2, subscribes(c));
    bridge.receive("{\"cmd\":\"ready\"}");
    assertEquals(2, subscribes(c), "already requested: a second view does not ask again");
    bridge.dispose();
  }

  @Test
  void dashboardFieldsArePassedThroughUntouched() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    out.clear();
    String mine = "{\"env\":\"local\",\"scope\":\"user\",\"user\":\"jane@example.com\",\"unavailable\":[\"cost\"],\"previous\":{\"tokens\":1},"
        + "\"window\":{\"days\":30},\"totals\":{\"users\":1,\"tokens\":42},\"models\":[]}";
    c.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + mine + "}");
    Map<String, Object> data = Json.obj(Json.parseObject(out.get(out.size() - 1)), "data");
    assertEquals("user", data.get("scope"));
    assertEquals("jane@example.com", data.get("user"));
    assertEquals(List.of("cost"), data.get("unavailable"));
    assertEquals(1L, Json.obj(data, "previous").get("tokens"));
  }

  @Test
  void switchingLocalUserRestartsTheSessionWithThatUsersToken() throws Exception {
    ResolvedConfig base = cfg.get();
    cfg.set(new ResolvedConfig(base.env(), base.backendUrl(), true, com.aig.ai.ecosystem.core.config.AuthPlan.localBrowser(), "general", List.of()));
    auth.signInAs(cfg.get(), "premium.quality@aig.example");
    live.sync();
    FakeTransport.Conn c1 = transport.last();
    assertEquals("Bearer dev:premium.quality@aig.example", c1.headers.get("Authorization"));
    c1.listener.onOpen();
    c1.listener.onText("{\"type\":\"usage\",\"days\":30,\"data\":" + DASH + "}");
    out.clear();
    auth.signInAs(cfg.get(), "free.balanced@aig.example");
    live.sync();
    assertTrue(c1.closed, "the previous user's socket is closed");
    FakeTransport.Conn c2 = transport.last();
    assertNotSame(c1, c2);
    assertEquals("Bearer dev:free.balanced@aig.example", c2.headers.get("Authorization"));
    assertTrue(types().contains("usage.loading"), "the previous user's usage is cleared: " + types());
    assertFalse(live.snapshot().stream().anyMatch(m -> "usage".equals(Json.str(Json.parseObject(m), "type"))));
    c2.listener.onOpen();
    assertEquals(1, subscribes(c2), "one load for the new user");
    assertEquals(List.of(true), signedIn, "still signed in: views stay open and reload their data");
  }

  @Test
  void widgetSignInWithEmailReachesTheHost() {
    List<String> emails = new ArrayList<>();
    WidgetBridge bridge = new WidgetBridge(live, s -> {}, new WidgetBridge.Commands() {
      @Override
      public void run(String cmd) {
        commands.add(cmd);
      }

      @Override
      public void signIn(String email) {
        emails.add(email);
      }
    });
    assertTrue(bridge.receive("{\"cmd\":\"signIn\",\"email\":\" Standard.Quality@aig.example\"}"));
    assertEquals(List.of("standard.quality@aig.example"), emails);
    assertFalse(bridge.receive("{\"cmd\":\"signIn\",\"email\":\"nope\"}"), "invalid email rejected");
    assertTrue(bridge.receive("{\"cmd\":\"signIn\"}"));
    assertEquals(List.of("signIn"), commands, "no email: the configured sign-in flow");
    assertEquals(1, emails.size());
    // hosts without email support fall back to the plain sign-in
    List<String> plain = new ArrayList<>();
    new WidgetBridge(live, s -> {}, plain::add).receive("{\"cmd\":\"signIn\",\"email\":\"a@b.co\"}");
    assertEquals(List.of("signIn"), plain);
    bridge.dispose();
  }

  @Test
  void signOutStopsSocket() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    auth.signOut(cfg.get());
    live.sync();
    assertFalse(live.isSignedIn());
    assertTrue(c.closed);
    assertEquals(List.of(true, false), signedIn);
  }

  @Test
  void widgetBridgeRoutesMessages() throws Exception {
    auth.signIn(cfg.get(), Duration.ofSeconds(1));
    live.sync();
    FakeTransport.Conn c = transport.last();
    c.listener.onOpen();
    List<String> toWidget = new ArrayList<>();
    WidgetBridge bridge = new WidgetBridge(live, toWidget::add, commands::add);
    assertTrue(bridge.receive("{\"cmd\":\"ready\"}"));
    assertEquals("init", Json.str(Json.parseObject(toWidget.get(0)), "type"));
    assertEquals("ready", commands.get(0));
    assertTrue(bridge.receive("{\"cmd\":\"openDashboard\"}"));
    assertTrue(bridge.receive("{\"cmd\":\"signOut\"}"));
    assertEquals(List.of("ready", "openDashboard", "signOut"), commands);
    assertFalse(bridge.receive("{\"cmd\":\"exec\",\"code\":\"rm -rf\"}"));
    assertFalse(bridge.receive("not json"));

    toWidget.clear();
    assertTrue(bridge.receive("{\"cmd\":\"chat.send\",\"localId\":\"L1\",\"jobProfile\":\"general\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}"));
    String chatFrame = c.sent().get(c.sent().size() - 1);
    Map<String, Object> frame = Json.parseObject(chatFrame);
    assertEquals("chat", frame.get("type"));
    assertEquals("ide.eclipse", frame.get("agent_id"), "Eclipse chats use its pre-registered agent");
    String id = (String) frame.get("id");
    c.listener.onText("{\"type\":\"chat.delta\",\"id\":\"" + id + "\",\"text\":\"yo\"}");
    c.listener.onText("{\"type\":\"chat.done\",\"id\":\"" + id + "\",\"trace_id\":\"t1\",\"usage\":{\"prompt_tokens\":1,\"completion_tokens\":2,\"total_tokens\":3}}");
    List<Map<String, Object>> msgs = toWidget.stream().map(Json::parseObject).filter(m -> String.valueOf(m.get("type")).startsWith("chat")).toList();
    assertEquals("chat.delta", msgs.get(0).get("type"));
    assertEquals("L1", msgs.get(0).get("localId"));
    assertEquals("yo", msgs.get(0).get("text"));
    assertEquals("chat.done", msgs.get(1).get("type"));
    assertEquals("t1", msgs.get(1).get("traceId"));
    assertEquals(3L, Json.obj(msgs.get(1), "usage").get("total_tokens"));
    assertFalse(msgs.get(1).containsKey("model"), "no model / route when the backend did not report them");
    assertFalse(msgs.get(1).containsKey("route"));

    toWidget.clear();
    bridge.receive("{\"cmd\":\"chat.send\",\"localId\":\"R1\",\"jobProfile\":\"claims\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}");
    String rid = (String) Json.parseObject(c.sent().get(c.sent().size() - 1)).get("id");
    c.listener.onText("{\"type\":\"chat.done\",\"id\":\"" + rid + "\",\"trace_id\":\"t2\",\"model\":\"us.anthropic.claude-sonnet-4-5-20250929-v1:0\","
        + "\"route\":{\"user_tier\":\"premium\",\"cost_mode\":\"quality\",\"job_profile\":\"claims\"}}");
    Map<String, Object> routed = Json.parseObject(toWidget.get(toWidget.size() - 1));
    assertEquals("chat.done", routed.get("type"));
    assertEquals("R1", routed.get("localId"));
    assertEquals("us.anthropic.claude-sonnet-4-5-20250929-v1:0", routed.get("model"));
    assertEquals(Map.of("user_tier", "premium", "cost_mode", "quality", "job_profile", "claims"), Json.obj(routed, "route"));

    bridge.receive("{\"cmd\":\"chat.send\",\"localId\":\"L2\",\"jobProfile\":\"general\",\"messages\":[{\"role\":\"user\",\"content\":\"again\"}]}");
    String id2 = (String) Json.parseObject(c.sent().get(c.sent().size() - 1)).get("id");
    bridge.receive("{\"cmd\":\"chat.cancel\",\"localId\":\"L2\"}");
    assertEquals("{\"type\":\"cancel\",\"id\":\"" + id2 + "\"}", c.sent().get(c.sent().size() - 1));

    c.listener.onClose(1006, "x");
    toWidget.clear();
    bridge.receive("{\"cmd\":\"chat.send\",\"localId\":\"L3\",\"jobProfile\":\"general\",\"messages\":[{\"role\":\"user\",\"content\":\"q\"}]}");
    Map<String, Object> err = Json.parseObject(toWidget.get(toWidget.size() - 1));
    assertEquals("chat.error", err.get("type"));
    assertEquals("not_connected", err.get("code"));
    bridge.dispose();
    int before = toWidget.size();
    live.setRange(90);
    assertEquals(before, toWidget.size(), "disposed bridge no longer receives");
  }
}
