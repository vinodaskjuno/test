package com.aig.ai.ecosystem.core.testing;

import java.nio.file.Files;
import java.nio.file.Path;

/** Locates the monorepo root (backend/contracts/, sdk/templates/) from the test runtime. */
public final class RepoFiles {
  private RepoFiles() {}

  public static Path root() {
    String prop = System.getProperty("aig.repo.root");
    if (prop != null) {
      Path p = Path.of(prop).toAbsolutePath().normalize();
      if (Files.isDirectory(p.resolve("backend/contracts"))) return p;
    }
    Path p = Path.of("").toAbsolutePath();
    while (p != null) {
      if (Files.isDirectory(p.resolve("backend/contracts/fixtures"))) return p;
      p = p.getParent();
    }
    throw new IllegalStateException("monorepo root (backend/contracts/fixtures) not found; set -Daig.repo.root");
  }
}
