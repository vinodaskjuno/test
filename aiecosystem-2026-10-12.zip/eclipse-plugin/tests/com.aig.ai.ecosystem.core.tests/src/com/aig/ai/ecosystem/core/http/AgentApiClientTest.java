package com.aig.ai.ecosystem.core.http;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.invoke.AgentEvent;
import com.aig.ai.ecosystem.core.invoke.AgentRegistration;
import com.aig.ai.ecosystem.core.invoke.AgentStream;
import com.aig.ai.ecosystem.core.invoke.AgentStreamListener;
import com.aig.ai.ecosystem.core.invoke.AgentVersionInfo;
import com.aig.ai.ecosystem.core.invoke.Cancellation;
import com.aig.ai.ecosystem.core.invoke.Catalog;
import com.aig.ai.ecosystem.core.invoke.Invocation;
import com.aig.ai.ecosystem.core.invoke.InvocationAccepted;
import com.aig.ai.ecosystem.core.invoke.InvokeRequest;
import com.aig.ai.ecosystem.core.invoke.InvokeResult;
import com.aig.ai.ecosystem.core.invoke.VerifyResult;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer.Response;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

/** Registry v2 + invoke API of {@link BackendClient}: URLs, encoding, bodies, auth, SSE, errors. */
class AgentApiClientTest {
  static final String TOKEN = "dev:jane@example.com";
  static final String CATALOG = "{\"items\":[{\"agent\":{\"agent_id\":\"claims-triage\",\"name\":\"Claims triage\",\"description\":\"Routes claims\",\"team\":\"claims-ai\","
      + "\"owner\":\"o@example.com\",\"lifecycle\":\"active\",\"status\":\"active\",\"tags\":[\"claims\"],\"visibility\":\"org\",\"docs_url\":null},"
      + "\"versions\":[{\"env\":\"prod\",\"version\":\"1.4\",\"kind\":\"agentcore\",\"verified\":true,\"verified_at\":\"2026-10-01T00:00:00\","
      + "\"input_schema\":{\"type\":\"object\"},\"output_schema\":null},{\"env\":\"stage\",\"version\":\"1.5\",\"kind\":\"https\",\"verified\":true}],"
      + "\"default\":{\"env\":\"prod\",\"version\":\"1.4\",\"kind\":\"agentcore\",\"verified\":true},\"access\":\"team\"},"
      + "{\"agent\":{\"name\":\"no id\"},\"versions\":[]}],\"total\":1,\"teams\":[\"claims-ai\"],\"tags\":[\"claims\"]}";
  static final String INV = "{\"id\":\"inv-1\",\"agent_id\":\"claims-triage\",\"version\":\"1.4\",\"env\":\"prod\",\"mode\":\"background\",\"status\":\"succeeded\","
      + "\"trace_id\":\"trace-0001\",\"created_at\":\"2026-10-09T10:00:00\",\"duration_ms\":3200,\"usage\":{\"prompt_tokens\":1,\"completion_tokens\":2,\"total_tokens\":3},"
      + "\"error_code\":null,\"error_message\":null,\"output_available\":true,\"output\":{\"severity\":\"HIGH\"}}";

  static void assertAuthOnlyInHeader(MiniHttpServer.Request r) {
    assertEquals("Bearer " + TOKEN, r.headers().get("authorization"));
    assertFalse(r.target().contains("jane"), "token never in the URL: " + r.target());
    assertFalse(r.target().toLowerCase().contains("token"), r.target());
    assertTrue(r.headers().keySet().stream().noneMatch(k -> k.startsWith("x-portkey")));
  }

  @Test
  void catalogQueryIsEncodedAndItemsAreFlattened() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> Response.json(200, CATALOG))) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> TOKEN);
      Catalog cat = c.catalog("claims & co/?", "claims-ai", null);
      assertEquals("GET", srv.last().method());
      assertEquals("/api/v1/catalog?q=claims%20%26%20co%2F%3F&team=claims-ai", srv.last().target());
      assertAuthOnlyInHeader(srv.last());
      assertEquals(1, cat.items().size(), "malformed item dropped");
      assertEquals(List.of("claims-ai"), cat.teams());
      Map<String, Object> w = cat.items().get(0).toWidget();
      assertEquals("claims-triage", w.get("agentId"));
      assertEquals("team", w.get("access"));
      assertEquals("1.4", Json.str(Json.asObject(w.get("defaultVersion")), "version"));
      Map<String, Object> v0 = Json.asObject(Json.list(w, "versions").get(0));
      assertEquals("2026-10-01T00:00:00", v0.get("verifiedAt"));
      assertEquals("object", Json.str(Json.asObject(v0.get("inputSchema")), "type"));
      Map<String, Object> target = cat.find("claims-triage").runTarget("stage", null);
      assertEquals("1.5", target.get("version"));
      assertEquals("stage", target.get("env"));
      assertEquals("1.4", cat.find("claims-triage").runTarget(null, "9.9").get("version"), "unknown pick falls back to the default");
      Map<String, Object> msg = Json.parseObject(cat.toHostMessage());
      assertEquals("catalog", msg.get("type"));
      assertEquals(1, Json.list(msg, "items").size());
      c.catalog(null, " ", "");
      assertEquals("/api/v1/catalog", srv.last().target());
      assertThrows(BackendException.class, () -> c.catalog("x".repeat(201), null, null));
    }
  }

  @Test
  void pathSegmentsAreValidatedAndEncoded() throws Exception {
    assertEquals("/api/v1/agents/claims.triage_v2/invoke?mode=stream&env=prod&version=1.4%2Bb", BackendClient.invokePath("claims.triage_v2", "prod", "1.4+b", "stream"));
    assertEquals("/api/v1/agents/a/invoke?mode=sync", BackendClient.invokePath("a", null, null, "sync"));
    assertThrows(BackendException.class, () -> BackendClient.invokePath("../admin", null, null, "sync"));
    assertThrows(BackendException.class, () -> BackendClient.invokePath("a/b", null, null, "sync"));
    assertThrows(BackendException.class, () -> BackendClient.invokePath("a", "qa", null, "sync"));
    assertThrows(BackendException.class, () -> BackendClient.invokePath("a", null, "1.0/../x", "sync"));
    BackendClient c = new BackendClient("http://127.0.0.1:9", () -> TOKEN);
    assertThrows(BackendException.class, () -> c.invocation("../../agents"));
    assertThrows(BackendException.class, () -> c.cancelInvocation("a b"));
    assertThrows(BackendException.class, () -> c.agentVersions("bad id", null));
    assertThrows(BackendException.class, () -> c.verifyVersion("a", "bad/version", null));
    assertThrows(BackendException.class, () -> c.invocations(true, null, "weird", 10));
  }

  @Test
  void registrationVersionsAndVerify() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> {
      if (r.path().equals("/api/v1/agents")) return Response.json(201, "{\"agent\":{\"agent_id\":\"claims-triage\",\"status\":\"active\",\"lifecycle\":\"draft\"}}");
      if (r.path().endsWith("/verify")) {
        return Response.json(200, "{\"passed\":false,\"code\":\"trace_missing\",\"checks\":[{\"name\":\"health\",\"status\":\"passed\",\"detail\":\"200\"},"
            + "{\"name\":\"trace\",\"status\":\"failed\",\"detail\":\"no trace\"}],\"invocation_id\":\"inv-v\",\"trace_id\":\"trace-v\",\"activated\":false,\"version\":{}}");
      }
      if (r.method().equals("POST")) return Response.json(201, "{\"version\":{\"env\":\"dev\",\"version\":\"1.0.0\",\"kind\":\"https\",\"endpoint\":\"https://a.example.com\"},\"created\":true}");
      return Response.json(200, "{\"items\":[{\"env\":\"dev\",\"version\":\"1.0.0\",\"kind\":\"https\",\"verified_at\":null,\"status\":\"active\"},{\"env\":\"bogus\"}],\"total\":2}");
    })) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> TOKEN);
      c.registerAgent("claims-triage", "Claims triage", "Routes claims", List.of("claims", "triage"));
      Map<String, Object> sent = Json.parseObject(srv.last().body());
      assertEquals("[\"claims\",\"triage\"]", Json.write(sent.get("tags")));
      assertEquals("draft", sent.get("lifecycle"));
      assertThrows(BackendException.class, () -> c.registerAgent("ok", null, null, List.of("NOT OK")));

      String arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:aig/dev/agents/claims-triage/invoke-auth";
      AgentVersionInfo v = c.registerVersion("claims-triage",
          new AgentRegistration.VersionSpec("1.0.0", "dev", "https://a.example.com", "api_key", arn, Map.of("type", "object")));
      assertEquals("1.0.0", v.version());
      MiniHttpServer.Request req = srv.last();
      assertEquals("/api/v1/agents/claims-triage/versions", req.target());
      assertAuthOnlyInHeader(req);
      Map<String, Object> body = Json.parseObject(req.body());
      assertEquals("https", body.get("kind"));
      assertEquals("aig-http/1", body.get("protocol"));
      assertEquals("dev", body.get("env"));
      assertEquals(arn, Json.str(Json.obj(body, "auth"), "secret_arn"));
      assertEquals(2, Json.obj(body, "auth").size(), "auth carries type + secret_arn only");
      int before = srv.requests().size();
      BackendException bad = assertThrows(BackendException.class, () -> c.registerVersion("claims-triage",
          new AgentRegistration.VersionSpec("1.0.0", "dev", "https://a.example.com", "api_key", "my-secret-value", null)));
      assertEquals("version_invalid", bad.code());
      assertEquals(before, srv.requests().size(), "invalid version spec is not sent");

      List<AgentVersionInfo> vs = c.agentVersions("claims-triage", "dev");
      assertEquals("/api/v1/agents/claims-triage/versions?env=dev", srv.last().target());
      assertEquals(1, vs.size());
      assertFalse(vs.get(0).verified());

      VerifyResult vr = c.verifyVersion("claims-triage", "1.0.0", "dev");
      assertEquals("/api/v1/agents/claims-triage/versions/1.0.0/verify?env=dev", srv.last().target());
      assertFalse(vr.passed());
      assertEquals("trace_missing", vr.code());
      assertEquals(2, vr.checks().size());
      assertTrue(vr.summary().contains("[fail] trace: no trace"), vr.summary());
    }
  }

  @Test
  void syncBackgroundInvocationsAndCancel() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> {
      if (r.path().endsWith("/invoke") && r.query().startsWith("mode=sync")) {
        return Response.json(200, "{\"invocation_id\":\"inv-s\",\"agent_id\":\"claims-triage\",\"version\":\"1.4\",\"env\":\"prod\",\"status\":\"succeeded\","
            + "\"output\":\"ok\",\"usage\":null,\"trace_id\":\"t-12345678\",\"duration_ms\":12}");
      }
      if (r.path().endsWith("/invoke")) {
        return new Response(202, Map.of("content-type", "application/json", "location", "https://evil.example.com/x"),
            List.of("{\"invocation_id\":\"inv-b\",\"agent_id\":\"claims-triage\",\"version\":\"1.4\",\"env\":\"prod\",\"status\":\"queued\",\"location\":\"/api/v1/invocations/inv-b\"}"));
      }
      if (r.path().equals("/api/v1/invocations")) return Response.json(200, "{\"items\":[" + INV + ",{\"id\":1}],\"total\":2}");
      if (r.path().endsWith("/cancel")) return Response.json(409, "{\"error\":{\"code\":\"invocation_finished\",\"message\":\"the invocation already ended (succeeded)\"}}");
      return Response.json(200, INV);
    })) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> TOKEN);
      InvokeResult r = c.invoke("claims-triage", "prod", null, InvokeRequest.input(Map.of("claim_id", "CLM-1")));
      assertEquals("/api/v1/agents/claims-triage/invoke?mode=sync&env=prod", srv.last().target());
      assertEquals("{\"input\":{\"claim_id\":\"CLM-1\"}}", srv.last().body());
      assertEquals("ok", r.output());
      assertEquals(12L, r.durationMs());

      InvocationAccepted a = c.invokeBackground("claims-triage", null, "1.4",
          InvokeRequest.chat(List.of(new ChatMessage("user", "hi"))));
      assertEquals("/api/v1/agents/claims-triage/invoke?mode=background&version=1.4", srv.last().target());
      assertEquals("{\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}", srv.last().body());
      assertEquals("inv-b", a.invocationId());
      assertEquals("queued", a.status());

      List<Invocation> mine = c.invocations(true, "claims-triage", "succeeded", 1000);
      assertEquals("/api/v1/invocations?mine=1&agent_id=claims-triage&status=succeeded&limit=500", srv.last().target());
      assertEquals(1, mine.size());
      Map<String, Object> run = mine.get(0).toRecentRun("Claims triage");
      assertEquals("inv-1", run.get("invocationId"));
      assertEquals(3200L, run.get("durationMs"));
      c.invocations(false, null, null, 5);
      assertEquals("/api/v1/invocations?limit=5", srv.last().target());

      Invocation one = c.invocation(a.invocationId());
      assertEquals("/api/v1/invocations/inv-b", srv.last().target(), "status is read from the configured backend, not the returned location");
      assertTrue(one.isFinal());
      assertEquals("{\"severity\":\"HIGH\"}", Json.write(one.output()));

      BackendException e = assertThrows(BackendException.class, () -> c.cancelInvocation("inv-1"));
      assertEquals("POST", srv.last().method());
      assertEquals("/api/v1/invocations/inv-1/cancel", srv.last().target());
      assertEquals("", srv.last().body());
      assertEquals(409, e.status());
      assertEquals("invocation_finished", e.code());
      assertEquals("the invocation already ended (succeeded)", e.getMessage());
      for (MiniHttpServer.Request req : srv.requests()) assertAuthOnlyInHeader(req);
    }
  }

  @Test
  void streamDeliversEventsFromSplitChunks() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> new Response(200,
        Map.of("content-type", "text/event-stream", "x-aig-invocation-id", "inv-9", "x-aig-trace-id", "trace-9999"),
        List.of(": keepalive\r\n\r\nevent: del", "ta\r\ndata: {\"invocation_id\":\"inv-9\",\"text\":\"Sev\"}\r", "\n\r\nevent: delta\ndata: {\"text\":\"erity\"}\n\n",
            "event: output\ndata: {\"output\":{\"severity\":\"HIGH\"},\"trace_id\":\"trace-9999\"}\n\nevent: done\ndata: {\"status\":\"succeeded\",\"duration_ms\":5}\n\n")))) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> TOKEN);
      List<String> seen = new ArrayList<>();
      AgentStream.Result r = c.invokeStream("claims-triage", "prod", "1.4", InvokeRequest.input(Map.of("q", 1L)), new AgentStreamListener() {
        @Override
        public void onOpen(String invocationId, String traceId) {
          seen.add("open " + invocationId + " " + traceId);
        }

        @Override
        public void onEvent(AgentEvent ev) {
          seen.add(ev.getClass().getSimpleName() + (ev instanceof AgentEvent.Delta d ? " " + d.text() : ""));
        }
      }, new Cancellation());
      assertEquals(List.of("open inv-9 trace-9999", "Delta Sev", "Delta erity", "Output", "Done"), seen);
      assertTrue(r.succeeded());
      assertEquals("Severity", r.text());
      assertEquals(5L, r.durationMs());
      assertEquals("inv-9", r.invocationId());
      MiniHttpServer.Request req = srv.last();
      assertEquals("/api/v1/agents/claims-triage/invoke?mode=stream&env=prod&version=1.4", req.target());
      assertEquals("text/event-stream", req.headers().get("accept"));
      assertAuthOnlyInHeader(req);
    }
  }

  @Test
  void streamErrorsTruncationAndCancel() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> {
      if (r.query().contains("env=dev")) return Response.json(403, "{\"error\":{\"code\":\"agent_forbidden\",\"message\":\"not allowed\"}}");
      if (r.query().contains("env=stage")) return Response.sse("event: delta\ndata: {\"text\":\"partial\"}\n\n");
      return Response.sse("event: delta\ndata: {\"text\":\"a\"}\n\n", "event: delta\ndata: {\"text\":\"b\"}\n\n", "event: done\ndata: {}\n\n");
    })) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> TOKEN);
      InvokeRequest req = InvokeRequest.input(Map.of());
      BackendException e = assertThrows(BackendException.class, () -> c.invokeStream("a", "dev", null, req, ev -> {}, null));
      assertEquals(403, e.status());
      assertEquals("agent_forbidden", e.code());

      AgentStream.Result t = c.invokeStream("a", "stage", null, req, ev -> {}, null);
      assertEquals("failed", t.status());
      assertEquals("agent_error", t.error().code());
      assertEquals("partial", t.text());

      Cancellation cancel = new Cancellation();
      List<AgentEvent> got = new ArrayList<>();
      AgentStream.Result cr = c.invokeStream("a", "prod", null, req, ev -> {
        got.add(ev);
        cancel.cancel();
      }, cancel);
      assertEquals(1, got.size(), "no events after cancel");
      assertEquals("cancelled", cr.status());

      Cancellation pre = new Cancellation();
      pre.cancel();
      int n = srv.requests().size();
      assertEquals("cancelled", c.invokeStream("a", "prod", null, req, ev -> {}, pre).status());
      assertEquals(n, srv.requests().size(), "a cancelled call sends nothing");
    }
  }

  @Test
  void readAgentStreamStopsAtDone() {
    AgentStream s = new AgentStream();
    AgentStream.Result r = BackendClient.readAgentStream(new StringReader("event: done\ndata: {}\n\nevent: delta\ndata: {\"text\":\"x\"}\n\n"), s, null, null);
    assertEquals("succeeded", r.status());
    assertEquals("", r.text());
  }
}
