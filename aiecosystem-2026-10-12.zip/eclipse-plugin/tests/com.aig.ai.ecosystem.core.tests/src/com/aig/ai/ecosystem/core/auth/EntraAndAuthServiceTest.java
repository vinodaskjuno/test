package com.aig.ai.ecosystem.core.auth;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import com.aig.ai.ecosystem.core.config.AigSettings;
import com.aig.ai.ecosystem.core.config.AuthPlan;
import com.aig.ai.ecosystem.core.config.ConfigResolver;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer.Response;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.Test;

class EntraAndAuthServiceTest {
  static final AuthPlan.EntraConfig ENTRA = new AuthPlan.EntraConfig("https://login.microsoftonline.com", "tenant-1", "client-1", "api://platform/.default");

  static String idToken(String user) {
    String payload = Base64.getUrlEncoder().withoutPadding().encodeToString(("{\"preferred_username\":\"" + user + "\"}").getBytes(StandardCharsets.UTF_8));
    return "e30." + payload + ".sig";
  }

  @Test
  void pkce() {
    String v = Pkce.newVerifier();
    assertEquals(43, v.length());
    assertTrue(v.matches("[A-Za-z0-9_-]+"));
    // Computed independently with Python hashlib + base64.urlsafe_b64encode.
    assertEquals("VTD5zvxKVtUrCiTAuQVdJ4k_uRWd5RKxnzdCYHmv1EA", Pkce.challenge("dBjftJeZ4CVP-mJ92K9a7Z4f5xgi3VtqPqZf4vV2mq8"));
  }

  @Test
  void authorizeUrl() {
    String url = EntraClient.authorizeUrl(ENTRA, "http://127.0.0.1:5555/callback", "st", "ch");
    assertTrue(url.startsWith("https://login.microsoftonline.com/tenant-1/oauth2/v2.0/authorize?"), url);
    Map<String, String> q = Query.parse(URI.create(url).getRawQuery());
    assertEquals("client-1", q.get("client_id"));
    assertEquals("code", q.get("response_type"));
    assertEquals("http://127.0.0.1:5555/callback", q.get("redirect_uri"));
    assertEquals("api://platform/.default openid profile offline_access", q.get("scope"));
    assertEquals("S256", q.get("code_challenge_method"));
    assertEquals("ch", q.get("code_challenge"));
    assertEquals("st", q.get("state"));
    assertFalse(q.containsKey("client_secret"));
  }

  @Test
  void entraCallbackValidation() {
    PendingStates p = new PendingStates();
    String s = p.issue();
    assertEquals("abc", EntraClient.handleCallback("code=abc&state=" + s, p).value());
    assertFalse(EntraClient.handleCallback("code=abc&state=" + s, p).ok(), "replayed state");
    String s2 = p.issue();
    assertEquals("Microsoft sign-in failed: user cancelled", EntraClient.handleCallback("error=access_denied&error_description=user+cancelled&state=" + s2, p).reason());
    String s3 = p.issue();
    assertFalse(EntraClient.handleCallback("state=" + s3, p).ok());
  }

  @Test
  void tokenResponseParsing() throws Exception {
    StoredToken t = EntraClient.parseTokenResponse(200, "{\"access_token\":\"AT\",\"refresh_token\":\"RT\",\"expires_in\":3600,\"id_token\":\"" + idToken("jane@aig.com") + "\"}", null, 100);
    assertEquals("AT", t.accessToken());
    assertEquals("RT", t.refreshToken());
    assertEquals(3700, t.expiresAt());
    assertEquals("jane@aig.com", t.account());
    assertFalse(t.toString().contains("AT,") || t.toString().contains("RT]"), "toString hides tokens");
    StoredToken refreshed = EntraClient.parseTokenResponse(200, "{\"access_token\":\"AT2\",\"expires_in\":60}", t, 200);
    assertEquals("RT", refreshed.refreshToken(), "refresh token kept when not rotated");
    assertEquals("jane@aig.com", refreshed.account());
    Exception e = assertThrows(java.io.IOException.class, () -> EntraClient.parseTokenResponse(400, "{\"error\":\"invalid_grant\",\"error_description\":\"AADSTS70008: expired\\nTrace\"}", null, 0));
    assertEquals("token request failed (HTTP 400): AADSTS70008: expired", e.getMessage());
  }

  /** Opens "the browser" by following the redirect with the given extra query. */
  static AuthService.BrowserOpener follow(java.util.function.Function<Map<String, String>, String> callbackQuery, AtomicInteger opened) {
    return url -> {
      opened.incrementAndGet();
      Map<String, String> q = Query.parse(URI.create(url).getRawQuery());
      String target = q.get("redirect_uri") + "?" + callbackQuery.apply(q);
      new Thread(() -> {
        try {
          HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create(target)).build(), HttpResponse.BodyHandlers.ofString());
        } catch (Exception ignored) {
          // test assertion happens on the result
        }
      }).start();
    };
  }

  @Test
  void localBrowserSignInEndToEnd() throws Exception {
    AtomicInteger opened = new AtomicInteger();
    LocalSessionStore.InMemory local = new LocalSessionStore.InMemory();
    AuthService auth = new AuthService(new InMemoryTokenStore(), local,
        follow(q -> "email=jane%40example.com&state=" + q.get("state"), opened));
    ResolvedConfig cfg = ConfigResolver.resolve(AigSettings.defaults("local"));
    assertFalse(auth.hasSession(cfg));
    assertThrows(NotSignedInException.class, () -> auth.accessToken(cfg));
    assertEquals("jane@example.com", auth.signIn(cfg, Duration.ofSeconds(10)));
    assertEquals(1, opened.get());
    assertTrue(auth.hasSession(cfg));
    assertEquals("dev:jane@example.com", auth.accessToken(cfg));
    assertEquals(0, auth.pending().size(), "state consumed");
    auth.signOut(cfg);
    assertFalse(auth.hasSession(cfg));
  }

  @Test
  void localBrowserSignInRejectsForgedState() {
    AuthService auth = new AuthService(new InMemoryTokenStore(), new LocalSessionStore.InMemory(),
        follow(q -> "email=jane%40example.com&state=forged-state-000000", new AtomicInteger()));
    ResolvedConfig cfg = ConfigResolver.resolve(AigSettings.defaults("local"));
    NotSignedInException e = assertThrows(NotSignedInException.class, () -> auth.signIn(cfg, Duration.ofSeconds(10)));
    assertTrue(e.getMessage().contains("expired or was not started"), e.getMessage());
  }

  @Test
  void devUserShortcut() throws Exception {
    AuthService auth = new AuthService(new InMemoryTokenStore(), new LocalSessionStore.InMemory(), url -> fail("no browser for the dev user"));
    ResolvedConfig cfg = ConfigResolver.resolve(AigSettings.defaults("local").withDevUser("dev@example.com"));
    assertFalse(auth.hasSession(cfg));
    auth.signIn(cfg, Duration.ofSeconds(1));
    assertEquals("dev:dev@example.com", auth.accessToken(cfg));
    auth.signOut(cfg);
    assertFalse(auth.hasSession(cfg));
  }

  @Test
  void unconfiguredRefusesSignIn() {
    AuthService auth = new AuthService(new InMemoryTokenStore(), new LocalSessionStore.InMemory(), url -> fail("never"));
    ResolvedConfig cfg = ConfigResolver.resolve(AigSettings.defaults("prod"));
    NotSignedInException e = assertThrows(NotSignedInException.class, () -> auth.signIn(cfg, Duration.ofSeconds(1)));
    assertTrue(e.getMessage().startsWith("AIG backend not configured for prod"));
  }

  @Test
  void microsoftPkceSignInAndRefresh() throws Exception {
    AtomicLong now = new AtomicLong(1000);
    try (MiniHttpServer idp = new MiniHttpServer(r -> {
      Map<String, String> form = Query.parse(r.body());
      if ("authorization_code".equals(form.get("grant_type"))) {
        boolean pkceOk = Pkce.challenge(form.get("code_verifier")).equals(form.get("x-expected-challenge")) || form.get("code_verifier").length() == 43;
        if (!"the-code".equals(form.get("code")) || !pkceOk || form.containsKey("client_secret")) return Response.json(400, "{\"error\":\"invalid_grant\"}");
        return Response.json(200, "{\"access_token\":\"AT1\",\"refresh_token\":\"RT1\",\"expires_in\":3600,\"id_token\":\"" + idToken("jane@aig.com") + "\"}");
      }
      if ("refresh_token".equals(form.get("grant_type")) && "RT1".equals(form.get("refresh_token"))) {
        return Response.json(200, "{\"access_token\":\"AT2\",\"refresh_token\":\"RT2\",\"expires_in\":3600}");
      }
      return Response.json(400, "{\"error\":\"invalid_grant\"}");
    })) {
      AuthPlan.EntraConfig entra = new AuthPlan.EntraConfig(idp.baseUrl(), "tenant-1", "client-1", "api://platform/.default");
      ResolvedConfig cfg = new ResolvedConfig(AigEnvironment.DEV, "https://aig-dev.example.com", true, AuthPlan.microsoft(entra), "general", List.of());
      InMemoryTokenStore store = new InMemoryTokenStore();
      String[] challenge = new String[1];
      AuthService.BrowserOpener browser = url -> {
        Map<String, String> q = Query.parse(URI.create(url).getRawQuery());
        challenge[0] = q.get("code_challenge");
        assertTrue(q.get("redirect_uri").matches("http://127\\.0\\.0\\.1:\\d+/callback"));
        follow(x -> "code=the-code&state=" + x.get("state"), new AtomicInteger()).open(url);
      };
      AuthService auth = new AuthService(store, new LocalSessionStore.InMemory(), new EntraClient(now::get), browser, now::get);
      assertEquals("jane@aig.com", auth.signIn(cfg, Duration.ofSeconds(10)));
      MiniHttpServer.Request tokenReq = idp.last();
      assertEquals("/tenant-1/oauth2/v2.0/token", tokenReq.path());
      Map<String, String> form = Query.parse(tokenReq.body());
      assertEquals(challenge[0], Pkce.challenge(form.get("code_verifier")), "verifier matches the challenge sent to the browser");
      assertEquals("AT1", auth.accessToken(cfg));
      assertTrue(auth.hasSession(cfg));
      now.set(1000 + 3600 - 60); // inside the refresh margin
      assertEquals("AT2", auth.accessToken(cfg));
      assertEquals("RT2", store.load(AigEnvironment.DEV).refreshToken());
      auth.signOut(cfg);
      assertNull(store.load(AigEnvironment.DEV));
      assertThrows(NotSignedInException.class, () -> auth.accessToken(cfg));
    }
  }

  @Test
  void expiredTokenWithFailedRefreshSignsOut() throws Exception {
    AtomicLong now = new AtomicLong(10_000);
    try (MiniHttpServer idp = new MiniHttpServer(r -> Response.json(400, "{\"error\":\"invalid_grant\"}"))) {
      AuthPlan.EntraConfig entra = new AuthPlan.EntraConfig(idp.baseUrl(), "t", "c", "s");
      ResolvedConfig cfg = new ResolvedConfig(AigEnvironment.PROD, "https://x", true, AuthPlan.microsoft(entra), "general", List.of());
      InMemoryTokenStore store = new InMemoryTokenStore();
      store.save(AigEnvironment.PROD, new StoredToken("old", "rt", 9_000, "a"));
      AuthService auth = new AuthService(store, new LocalSessionStore.InMemory(), new EntraClient(now::get), url -> {}, now::get);
      assertThrows(NotSignedInException.class, () -> auth.accessToken(cfg));
      assertNull(store.load(AigEnvironment.PROD));
    }
  }
}
