package com.aig.ai.ecosystem.core.http;

import static org.junit.jupiter.api.Assertions.*;

import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer;
import com.aig.ai.ecosystem.core.testing.MiniHttpServer.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class BackendClientTest {
  static final String DASH = "{\"env\":\"local\",\"totals\":{\"users\":2,\"tokens\":10},\"models\":[]}";

  @Test
  void chatStreamsThroughTheProxyWithContractHeaders() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> {
      Response sse = Response.sse("data: {\"choices\":[{\"delta\":{\"content\":\"He\"}}]}\n\n", "data: {\"choices\":[{\"delta\":{\"content\":\"llo\"}}]}\n\n",
          "data: [DONE]\n\n");
      return new Response(200, Map.of("content-type", "text/event-stream", "x-aig-trace-id", "srv-trace-1"), sse.chunks());
    })) {
      BackendClient c = new BackendClient(srv.baseUrl() + "/", () -> "dev:jane@example.com");
      List<String> deltas = new ArrayList<>();
      BackendClient.ChatResult r = c.chat(List.of(new ChatMessage("user", "hi")), "claims", "ide.eclipse", "0f8fad5b-d9cb-469f-a165-70867728950e",
          deltas::add, () -> false);
      assertEquals("Hello", r.text());
      assertTrue(r.complete());
      assertEquals("srv-trace-1", r.traceId());
      MiniHttpServer.Request req = srv.last();
      assertEquals("POST", req.method());
      assertEquals("/api/v1/llm/chat/completions", req.path());
      assertEquals("Bearer dev:jane@example.com", req.headers().get("authorization"));
      assertEquals("claims", req.headers().get("x-aig-job-profile"));
      assertEquals("ide.eclipse", req.headers().get("x-aig-agent-id"));
      assertEquals("0f8fad5b-d9cb-469f-a165-70867728950e", req.headers().get("x-aig-trace-id"));
      assertEquals("text/event-stream", req.headers().get("accept"));
      assertTrue(req.headers().keySet().stream().noneMatch(k -> k.startsWith("x-portkey")), "client never sends x-portkey-*");
      Map<String, Object> body = Json.parseObject(req.body());
      assertEquals(Boolean.TRUE, body.get("stream"));
      assertEquals("hi", Json.str(Json.asObject(Json.list(body, "messages").get(0)), "content"));
    }
  }

  @Test
  void nonStreamingCompletionIsAccepted() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> Response.json(200, "{\"choices\":[{\"message\":{\"content\":\"whole\"}}]}"))) {
      BackendClient.ChatResult r = new BackendClient(srv.baseUrl(), () -> "t").chat(List.of(new ChatMessage("user", "q")), null, null, null, null, null);
      assertEquals("whole", r.text());
      assertTrue(r.complete());
      assertEquals("general", srv.last().headers().get("x-aig-job-profile"));
      assertNull(srv.last().headers().get("x-aig-agent-id"));
    }
  }

  @Test
  void errorBodiesBecomeBackendExceptions() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> new Response(400, Map.of("content-type", "application/json", "x-aig-trace-id", "tr-1"),
        List.of("{\"error\":{\"code\":\"invalid_job_profile\",\"message\":\"job profile not allowed\"}}")))) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> "t");
      BackendException e = assertThrows(BackendException.class, () -> c.chat(List.of(new ChatMessage("user", "q")), "claims", null, null, null, null));
      assertEquals(400, e.status());
      assertEquals("invalid_job_profile", e.code());
      assertEquals("job profile not allowed", e.getMessage());
      assertEquals("tr-1", e.traceId());
      BackendException d = assertThrows(BackendException.class, () -> c.dashboard(30));
      assertEquals("invalid_job_profile", d.code());
    }
  }

  @Test
  void dashboardSessionAgentsAndNoRedirects() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> {
      switch (r.path()) {
        case "/api/v1/usage/dashboard": return Response.json(200, DASH);
        case "/api/v1/session": return Response.json(200, "{\"user\":{\"email\":\"jane@example.com\"},\"env\":\"local\",\"team\":\"uw\",\"llm\":{\"base_url\":\"http://x\"}}");
        case "/api/v1/agents": return Response.json(201, "{\"agent\":{\"agent_id\":\"my-agent\",\"status\":\"active\"},\"hooks\":[]}");
        default: return new Response(302, Map.of("location", "https://evil.example.com/"), List.of());
      }
    })) {
      BackendClient c = new BackendClient(srv.baseUrl(), () -> "tok");
      assertEquals(2.0, Json.num(Json.obj(c.dashboard(30), "totals"), "users"));
      assertEquals("/api/v1/usage/dashboard?days=30", srv.last().target());
      assertEquals("Bearer tok", srv.last().headers().get("authorization"));
      assertEquals("uw", Json.str(c.session(), "team"));
      Map<String, Object> reg = c.registerAgent("my-agent", "My agent", "desc");
      assertEquals("active", Json.str(Json.obj(reg, "agent"), "status"));
      Map<String, Object> sent = Json.parseObject(srv.last().body());
      assertEquals("my-agent", sent.get("agent_id"));
      assertEquals("My agent", sent.get("name"));
      assertEquals("draft", sent.get("lifecycle"));
      assertEquals("POST", srv.last().method());
      BackendException redirect = assertThrows(BackendException.class, () -> c.health());
      assertEquals(302, redirect.status());
      assertEquals(4, srv.requests().size(), "redirect was not followed");
      assertThrows(BackendException.class, () -> c.dashboard(14));
      assertThrows(BackendException.class, () -> c.registerAgent("bad id!", null, null));
    }
  }

  @Test
  void tokenFailureIsUnauthenticated() {
    BackendClient c = new BackendClient("http://127.0.0.1:9", () -> {
      throw new IllegalStateException("Not signed in");
    });
    BackendException e = assertThrows(BackendException.class, () -> c.dashboard(7));
    assertEquals(401, e.status());
    assertEquals("Not signed in", e.getMessage());
  }

  @Test
  void invalidSessionShapeIsRejected() throws Exception {
    try (MiniHttpServer srv = new MiniHttpServer(r -> Response.json(200, "{\"user\":{},\"env\":\"dev\"}"))) {
      BackendException e = assertThrows(BackendException.class, () -> new BackendClient(srv.baseUrl(), () -> "t").session());
      assertEquals("invalid_session", e.code());
    }
  }
}
