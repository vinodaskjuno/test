package com.aig.ai.ecosystem.ui;

import static com.aig.ai.ecosystem.ui.prefs.PreferenceConstants.*;

import com.aig.ai.ecosystem.core.CoreInfo;
import com.aig.ai.ecosystem.core.auth.AuthService;
import com.aig.ai.ecosystem.core.auth.InMemoryTokenStore;
import com.aig.ai.ecosystem.core.auth.SecureStorageTokenStore;
import com.aig.ai.ecosystem.core.auth.TokenStore;
import com.aig.ai.ecosystem.core.config.AigEnvironment;
import com.aig.ai.ecosystem.core.config.AigSettings;
import com.aig.ai.ecosystem.core.config.ConfigResolver;
import com.aig.ai.ecosystem.core.config.EnvSettings;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.invoke.Catalog;
import com.aig.ai.ecosystem.core.live.LiveService;
import com.aig.ai.ecosystem.core.ws.AigSocket;
import com.aig.ai.ecosystem.core.ws.JdkWsTransport;
import com.aig.ai.ecosystem.ui.prefs.PrefsLocalSessionStore;
import java.net.URL;
import java.time.Duration;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;

/**
 * Wires the core services to Eclipse: preferences to settings, Secure Storage for the Entra token,
 * the system browser, and one {@link LiveService} shared by every AIG view.
 */
public final class AigServices {
  private final IPreferenceStore prefs;
  private final AuthService auth;
  private final LiveService live;
  private final ScheduledExecutorService scheduler;
  private final ExecutorService background;
  private final IPropertyChangeListener prefListener;
  private final AigSocket.Scheduler sched;
  /** Last agent catalog of the selected environment (shared by the Agents and Run views; cleared on env change). */
  private final AtomicReference<Catalog> catalogCache = new AtomicReference<>();
  private volatile Job signInJob;

  AigServices(IPreferenceStore prefs) {
    this.prefs = prefs;
    this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> daemon(r, "aig-scheduler"));
    this.background = Executors.newCachedThreadPool(r -> daemon(r, "aig-background"));
    TokenStore tokens;
    try {
      tokens = new SecureStorageTokenStore();
    } catch (RuntimeException e) {
      Activator.log("Eclipse secure storage unavailable; the Entra token is kept in memory only", e);
      tokens = new InMemoryTokenStore();
    }
    this.auth = new AuthService(tokens, new PrefsLocalSessionStore(prefs), AigServices::openExternal);
    this.sched = (task, delayMs) -> {
      ScheduledFuture<?> f = scheduler.schedule(task, delayMs, TimeUnit.MILLISECONDS);
      return () -> f.cancel(false);
    };
    this.live = new LiveService(this::config, auth, new JdkWsTransport(), sched, this::client, background, msg -> AigConsole.log(msg));
    live.setDemoMode(this::demoData);
    this.prefListener = e -> {
      if (LOCAL_EMAIL.equals(e.getProperty()) || LOCAL_LAST_EMAIL.equals(e.getProperty())) return;
      catalogCache.set(null);
      // Switching sample data on or off ends a demo session (the views reload on the sign-in change).
      if (DEMO_DATA.equals(e.getProperty())) background.execute(() -> live.setDemoSession(false));
      else background.execute(live::sync);
    };
    prefs.addPropertyChangeListener(prefListener);
    background.execute(live::sync);
  }

  private static Thread daemon(Runnable r, String name) {
    Thread t = new Thread(r, name);
    t.setDaemon(true);
    return t;
  }

  /** Raw settings from preferences. */
  public AigSettings settings() {
    Map<AigEnvironment, EnvSettings> envs = new EnumMap<>(AigEnvironment.class);
    for (AigEnvironment e : AigEnvironment.values()) {
      envs.put(e, new EnvSettings(prefs.getString(key(e, BACKEND_URL)), prefs.getString(key(e, TENANT_ID)), prefs.getString(key(e, CLIENT_ID)),
          prefs.getString(key(e, SCOPE)), prefs.getString(key(e, AUTHORITY))));
    }
    return new AigSettings(prefs.getString(ENVIRONMENT), envs, prefs.getString(JOB_PROFILE), prefs.getString(DEV_USER));
  }

  /** TEMPORARY sample-data mode (preference "Use sample data", docs/demo-data.md). */
  public boolean demoData() {
    return prefs.getBoolean(DEMO_DATA);
  }

  public ResolvedConfig config() {
    return ConfigResolver.resolve(settings());
  }

  public ResolvedConfig config(AigEnvironment env) {
    return ConfigResolver.resolve(settings().withEnvironment(env.id()));
  }

  public AuthService auth() {
    return auth;
  }

  public LiveService live() {
    return live;
  }

  public ExecutorService background() {
    return background;
  }

  /** Delayed tasks (background-run polling). */
  public AigSocket.Scheduler scheduler() {
    return sched;
  }

  public AtomicReference<Catalog> catalogCache() {
    return catalogCache;
  }

  /** Client for the selected environment, or null when it is not configured. */
  public BackendClient client() {
    return client(config());
  }

  public BackendClient client(ResolvedConfig cfg) {
    if (!cfg.configured() || cfg.backendUrl() == null) return null;
    return new BackendClient(cfg.backendUrl(), () -> auth.accessToken(config()), Duration.ofSeconds(15), Duration.ofSeconds(120), CoreInfo.USER_AGENT);
  }

  public void setEnvironment(AigEnvironment env) {
    prefs.setValue(ENVIRONMENT, env.id());
  }

  /** Starts the browser sign-in in a cancellable job; opens the dashboard when it succeeds. */
  public void signIn() {
    if (demoData()) {
      // TEMPORARY sample-data mode: a demo session straight away (no browser, no backend call).
      AigConsole.log("[auth] demo session started (sample data; Window > Preferences > AIG AI Ecosystem to turn it off)");
      background.execute(() -> {
        live.setDemoSession(true);
        Display.getDefault().asyncExec(() -> Ui.showView(Ui.DASHBOARD_VIEW));
      });
      return;
    }
    ResolvedConfig cfg = config();
    if (!cfg.configured()) {
      MessageDialog.openWarning(null, "AIG", cfg.notConfiguredMessage() + ":\n" + String.join("\n", cfg.problems())
          + "\n\nSet the values in Window > Preferences > AIG AI Ecosystem.");
      return;
    }
    Job running = signInJob;
    if (running != null) running.cancel();
    Job job = new Job("AIG: Sign in (" + cfg.env().id() + ")") {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        try {
          String account = auth.signIn(cfg, AuthService.SIGN_IN_TIMEOUT);
          AigConsole.log("[auth] signed in to " + cfg.env().id() + " as " + account);
          live.sync();
          Display.getDefault().asyncExec(() -> Ui.showView(Ui.DASHBOARD_VIEW));
          return Status.OK_STATUS;
        } catch (Exception e) {
          if (monitor.isCanceled()) return Status.CANCEL_STATUS;
          AigConsole.log("[auth] sign-in failed: " + e.getMessage());
          Display.getDefault().asyncExec(() -> MessageDialog.openError(null, "AIG sign-in", e.getMessage()));
          return Status.OK_STATUS;
        }
      }

      @Override
      protected void canceling() {
        auth.cancelPending();
      }
    };
    job.setUser(true);
    signInJob = job;
    job.schedule();
  }

  /**
   * Local environment only: signs in as {@code email} straight away (no browser page; any email, e.g. the
   * backend's test personas), replacing the current local user, then opens the dashboard. The views
   * reload with that user's live data. Outside the local browser sign-in it reports why it is unavailable.
   */
  public void signIn(String email) {
    if (demoData()) {
      signIn();
      return;
    }
    ResolvedConfig cfg = config();
    Job running = signInJob;
    if (running != null) running.cancel();
    background.execute(() -> {
      try {
        String account = auth.signInAs(cfg, email);
        catalogCache.set(null);
        AigConsole.log("[auth] signed in to " + cfg.env().id() + " as " + account + " (local email sign-in)");
        live.sync();
        Display.getDefault().asyncExec(() -> Ui.showView(Ui.DASHBOARD_VIEW));
      } catch (Exception e) {
        AigConsole.log("[auth] sign-in failed: " + e.getMessage());
        Display.getDefault().asyncExec(() -> MessageDialog.openError(null, "AIG sign-in", e.getMessage()));
      }
    });
  }

  /** Last local sign-in email (prefills the email field), or null. */
  public String lastLocalEmail() {
    return auth.lastLocalEmail();
  }

  public void signOut() {
    if (demoData()) {
      AigConsole.log("[auth] demo session ended");
      background.execute(() -> live.setDemoSession(false));
      return;
    }
    ResolvedConfig cfg = config();
    auth.signOut(cfg);
    catalogCache.set(null);
    AigConsole.log("[auth] signed out of " + cfg.env().id());
    background.execute(live::sync);
  }

  static void openExternal(String url) throws Exception {
    Exception[] err = new Exception[1];
    Display.getDefault().syncExec(() -> {
      try {
        PlatformUI.getWorkbench().getBrowserSupport().getExternalBrowser().openURL(new URL(url));
      } catch (Exception e) {
        if (!Program.launch(url)) err[0] = e;
      }
    });
    if (err[0] != null) throw err[0];
  }

  void dispose() {
    prefs.removePropertyChangeListener(prefListener);
    auth.cancelPending();
    live.dispose();
    scheduler.shutdownNow();
    background.shutdownNow();
  }
}
