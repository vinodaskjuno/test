package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigImages;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/** "AIG Dashboard": the @aig/ui tokenomics dashboard (users, tokens, requests, cost per model; 7/30/90 days). */
public final class DashboardView extends ViewPart {
  private BrowserPane pane;
  private Image icon;

  @Override
  public void createPartControl(Composite parent) {
    pane = new BrowserPane(parent, Activator.aig().live(), WidgetCommands.of(() -> pane));
    pane.load("dashboard");
    icon = AigImages.create(AigImages.LOGO);
    if (icon != null) setTitleImage(icon);
  }

  @Override
  public void setFocus() {
    if (pane != null) pane.setFocus();
  }

  @Override
  public void dispose() {
    if (pane != null) pane.dispose();
    super.dispose();
    if (icon != null) icon.dispose();
  }
}
