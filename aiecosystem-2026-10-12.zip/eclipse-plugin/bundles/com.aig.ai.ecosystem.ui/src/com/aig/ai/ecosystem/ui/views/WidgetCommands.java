package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.live.HostMessages;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigServices;
import com.aig.ai.ecosystem.ui.Ui;
import com.aig.ai.ecosystem.ui.handlers.SelectEnvironmentHandler;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.PreferencesUtil;

/** Runs widget commands on the UI thread. */
final class WidgetCommands {
  private WidgetCommands() {}

  /** Commands of one pane (host commands plus sign-in with an email). */
  static BrowserPane.Commands of(java.util.function.Supplier<BrowserPane> pane) {
    return new BrowserPane.Commands() {
      @Override
      public void run(String cmd) {
        WidgetCommands.run(cmd, pane.get());
      }

      @Override
      public void signIn(String email) {
        AigServices aig = Activator.aig();
        Display.getDefault().asyncExec(() -> aig.signIn(email));
      }
    };
  }

  static void run(String cmd, BrowserPane pane) {
    AigServices aig = Activator.aig();
    Display.getDefault().asyncExec(() -> {
      switch (cmd) {
        case "signIn": aig.signIn(); break;
        case "signOut": aig.signOut(); break;
        case "openDashboard": Ui.showView(Ui.DASHBOARD_VIEW); break;
        case "selectEnvironment": SelectEnvironmentHandler.choose(); break;
        case "openPanel": PreferencesUtil.createPreferenceDialogOn(null, "com.aig.ai.ecosystem.ui.prefs", null, null).open(); break;
        case "ready":
          if ("signin".equals(pane.app())) pane.send(statusMessage(aig.config(), aig.lastLocalEmail()));
          break;
        default: break;
      }
    });
  }

  /** Sign-in card status line for the selected environment. */
  static String statusMessage(ResolvedConfig cfg, String lastLocalEmail) {
    String env = cfg.env().id();
    if (!cfg.configured()) {
      return HostMessages.status(env, "bad", "Not configured", cfg.notConfiguredMessage() + ": " + String.join("; ", cfg.problems()), "unconfigured");
    }
    String detail;
    switch (cfg.auth().kind()) {
      case LOCAL_BROWSER: detail = "Local sign-in at " + cfg.backendUrl() + ": enter any email to see that user's live usage"; break;
      case DEV: detail = "Local dev user " + cfg.auth().email(); break;
      default: detail = "Microsoft Entra ID sign-in for " + cfg.backendUrl(); break;
    }
    String method = cfg.auth().method();
    // Local browser sign-in: the card shows an email field (any email / test persona), prefilled with the last one.
    return HostMessages.status(env, "warn", "Signed out", detail, method, "browser".equals(method) ? lastLocalEmail : null);
  }
}
