package com.aig.ai.ecosystem.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.function.BooleanSupplier;

/** Runs an external command (the aig CLI, pip, npm, pipx), streaming its output into the AIG console. */
public final class ProcessRunner {
  private ProcessRunner() {}

  /** Returns the exit code; destroys the process when {@code cancelled} turns true. */
  public static int run(List<String> cmd, Path dir, BooleanSupplier cancelled) throws IOException, InterruptedException {
    AigConsole.log("$ " + String.join(" ", cmd));
    ProcessBuilder pb = new ProcessBuilder(cmd).directory(dir == null ? null : dir.toFile()).redirectErrorStream(true);
    // The plugin adds nothing secret to the environment; the CLI uses the user's own settings.
    Process p = pb.start();
    Thread pump = new Thread(() -> {
      try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
        String line;
        while ((line = r.readLine()) != null) AigConsole.log(line);
      } catch (IOException ignored) {
        // process ended
      }
    }, "aig-cli-output");
    pump.setDaemon(true);
    pump.start();
    while (p.isAlive()) {
      if (cancelled.getAsBoolean()) {
        p.destroy();
        AigConsole.log("[aig] cancelled");
        return -1;
      }
      p.waitFor(200, java.util.concurrent.TimeUnit.MILLISECONDS);
    }
    pump.join(2000);
    AigConsole.log("[aig] exit code " + p.exitValue());
    return p.exitValue();
  }

  /**
   * Runs {@code cmd} without echoing its output; returns stdout+stderr ("" on failure). Used for
   * {@code aig doctor --json}. {@code extraEnv} is added to the inherited environment (values already
   * set in the environment win, like the agents' own .env loader).
   */
  public static String capture(List<String> cmd, Path dir, java.util.Map<String, String> extraEnv, long timeoutSeconds) {
    try {
      ProcessBuilder pb = new ProcessBuilder(cmd).directory(dir == null ? null : dir.toFile()).redirectErrorStream(true);
      if (extraEnv != null) extraEnv.forEach((k, v) -> pb.environment().putIfAbsent(k, v));
      Process p = pb.start();
      byte[] out = p.getInputStream().readAllBytes();
      if (!p.waitFor(timeoutSeconds, java.util.concurrent.TimeUnit.SECONDS)) p.destroyForcibly();
      return new String(out, StandardCharsets.UTF_8);
    } catch (IOException e) {
      return "";
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      return "";
    }
  }
}
