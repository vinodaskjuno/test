package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.http.BackendException;
import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.http.ContractHeaders;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.AigServices;
import java.util.List;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.handlers.HandlerUtil;

/**
 * Ask AIG: sends the editor selection (plus an optional instruction) to the model through
 * platform-api's OpenAI-compatible proxy ({@code POST /api/v1/llm/chat/completions}, SSE) and streams
 * the answer into the AIG console. The request carries only the user's bearer token and the
 * {@code x-aig-*} hints; the backend adds the gateway key.
 */
public final class AskHandler extends AbstractHandler {
  static final int MAX_SELECTION = 24_000;

  @Override
  public Object execute(ExecutionEvent event) {
    AigServices aig = Activator.aig();
    ResolvedConfig cfg = aig.config();
    BackendClient client = aig.client(cfg);
    if (client == null) {
      MessageDialog.openWarning(HandlerUtil.getActiveShell(event), "AIG", cfg.notConfiguredMessage() + ": " + String.join("; ", cfg.problems()));
      return null;
    }
    ISelection sel = HandlerUtil.getCurrentSelection(event);
    String selected = sel instanceof ITextSelection ? ((ITextSelection) sel).getText() : null;
    if (selected != null && selected.length() > MAX_SELECTION) selected = selected.substring(0, MAX_SELECTION);
    InputDialog d = new InputDialog(HandlerUtil.getActiveShell(event), "Ask AIG (" + cfg.env().id() + ", " + cfg.jobProfile() + ")",
        selected == null || selected.isBlank() ? "Your question:" : "Instruction for the selected text:",
        selected == null || selected.isBlank() ? "" : "Explain this code.", null);
    if (d.open() != Window.OK || d.getValue().isBlank()) return null;
    String prompt = selected == null || selected.isBlank() ? d.getValue() : d.getValue() + "\n\n```\n" + selected + "\n```";
    String traceId = ContractHeaders.newTraceId();
    AigConsole.show();
    AigConsole.log("");
    AigConsole.log("> " + d.getValue());
    AigConsole.log("[ask] env=" + cfg.env().id() + " profile=" + cfg.jobProfile() + " trace=" + traceId);
    Job job = new Job("AIG: waiting for the model") {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        try {
          BackendClient.ChatResult r = client.chat(List.of(new ChatMessage("user", prompt)), cfg.jobProfile(), ContractHeaders.ECLIPSE_AGENT_ID, traceId,
              AigConsole::append, monitor::isCanceled);
          AigConsole.log("");
          AigConsole.log(r.complete() ? "[ask] done trace=" + r.traceId() : "[ask] warning: response may be incomplete (stream ended without [DONE]) trace=" + r.traceId());
        } catch (BackendException e) {
          AigConsole.log("");
          if ("cancelled".equals(e.code())) {
            AigConsole.log("[ask] cancelled");
            return Status.CANCEL_STATUS;
          }
          String msg = e.describe(cfg.env().id());
          AigConsole.log("[ask] error: " + msg + " trace=" + (e.traceId() != null ? e.traceId() : traceId));
          Display.getDefault().asyncExec(() -> MessageDialog.openError(null, "AIG", msg));
        }
        return Status.OK_STATUS;
      }
    };
    job.setUser(true);
    job.schedule();
    return null;
  }
}
