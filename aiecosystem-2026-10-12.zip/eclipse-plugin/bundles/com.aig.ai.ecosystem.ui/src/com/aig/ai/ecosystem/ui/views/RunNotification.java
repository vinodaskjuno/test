package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.ui.Ui;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.dialogs.PopupDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.PlatformUI;

/**
 * "Background run finished": a status-line message plus a small, non-modal popup in the bottom-right corner of
 * the workbench window that closes itself after a few seconds ("Show" opens the run in the AIG Run view).
 */
final class RunNotification extends PopupDialog {
  private static final int CLOSE_AFTER_MS = 8000;
  private final String name;
  private final String status;
  private final String invocationId;

  private RunNotification(Shell parent, String name, String status, String invocationId) {
    super(parent, PopupDialog.HOVER_SHELLSTYLE | SWT.ON_TOP, false, false, false, false, false, "AIG agent run " + status, null);
    this.name = name;
    this.status = status;
    this.invocationId = invocationId;
  }

  static void show(String name, String status, String invocationId) {
    String text = "AIG: " + name + " " + status;
    IWorkbenchPage page = Ui.page();
    if (page != null) {
      IWorkbenchPart part = page.getActivePart();
      IViewPart run = page.findView(Ui.AGENT_RUN_VIEW);
      IViewPart target = run != null ? run : part instanceof IViewPart ? (IViewPart) part : null;
      if (target != null && target.getSite() instanceof IViewSite) {
        IStatusLineManager sl = ((IViewSite) target.getSite()).getActionBars().getStatusLineManager();
        sl.setMessage(text);
      }
    }
    Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null ? PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell() : null;
    if (shell == null || shell.isDisposed()) return;
    RunNotification n = new RunNotification(shell, name, status, invocationId);
    n.open();
    Display.getDefault().timerExec(CLOSE_AFTER_MS, () -> {
      Shell s = n.getShell();
      if (s != null && !s.isDisposed()) n.close();
    });
  }

  @Override
  protected Control createDialogArea(Composite parent) {
    Composite c = (Composite) super.createDialogArea(parent);
    Label l = new Label(c, SWT.WRAP);
    l.setText(name + ": background run " + status + ".");
    l.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
    Link link = new Link(c, SWT.NONE);
    link.setText("<a>Show in AIG Run</a>");
    link.addListener(SWT.Selection, e -> {
      close();
      new AgentUiHost().showRun(invocationId);
    });
    return c;
  }

  @Override
  protected Point getDefaultLocation(Point initialSize) {
    Shell parent = getParentShell();
    if (parent == null) return super.getDefaultLocation(initialSize);
    Rectangle b = parent.getBounds();
    return new Point(b.x + b.width - initialSize.x - 24, b.y + b.height - initialSize.y - 48);
  }

  @Override
  protected Point getDefaultSize() {
    Point p = super.getDefaultSize();
    return new Point(Math.max(p.x, 320), p.y);
  }
}
