package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.live.DemoBridge;
import com.aig.ai.ecosystem.core.live.LiveService;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigImages;
import java.util.Map;
import java.util.function.Consumer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.part.ViewPart;

/**
 * "AIG Run": the @aig/ui run widget for one agent (form generated from the version's input schema, or chat mode;
 * streamed output; background runs with status polling). The target comes from the AIG Agents view, AIG &gt; Run
 * Agent... or a run opened from history; the part name shows the agent ("AIG Run: claims-triage").
 */
public final class AgentRunView extends ViewPart {
  private BrowserPane pane;
  private Consumer<Boolean> signedInListener;
  private Image icon;
  /** Last target host message, re-sent after a reload (sign-in change). */
  private String target;

  @Override
  public void createPartControl(Composite parent) {
    LiveService live = Activator.aig().live();
    pane = new BrowserPane(parent, live, WidgetCommands.of(() -> pane));
    load(live.isSignedIn());
    signedInListener = signedIn -> Display.getDefault().asyncExec(() -> {
      if (pane != null && !pane.control().isDisposed()) load(signedIn);
    });
    live.addSignedInListener(signedInListener);
    icon = AigImages.create(AigImages.LOGO);
    if (icon != null) setTitleImage(icon);
  }

  private void load(boolean signedIn) {
    pane.load(signedIn ? "agentRun" : "signin");
    if (signedIn && target != null) deliver(target);
  }

  private void deliver(String msg) {
    pane.whenReady(() -> {
      if (pane != null) pane.showTarget(msg);
    });
  }

  /** Shows a target ({@code agent.target} / {@code agent.target.error} host message). UI thread. */
  public void showTarget(String targetMessage) {
    target = targetMessage;
    Map<String, Object> m = Json.parseObject(targetMessage);
    Map<String, Object> t = DemoBridge.isOpen(targetMessage) ? m : Json.obj(m, "target"); // demo.open: TEMPORARY demo-data mode
    if (t != null) {
      String name = Json.str(t, "agentId");
      String env = Json.str(t, "env");
      String version = Json.str(t, "version");
      setPartName("AIG Run: " + name);
      setContentDescription(env != null && version != null ? env + " v" + version : "");
    }
    if (pane != null && Activator.aig().live().isSignedIn()) deliver(targetMessage);
  }

  /** Shows a past or running invocation (target, status, output). UI thread. */
  public void showInvocation(String invocationId) {
    if (pane == null) return;
    pane.whenReady(() -> {
      if (pane != null) pane.showInvocation(invocationId);
    });
  }

  @Override
  public void setFocus() {
    if (pane != null) pane.setFocus();
  }

  @Override
  public void dispose() {
    Activator.aig().live().removeSignedInListener(signedInListener);
    if (pane != null) pane.dispose();
    pane = null;
    super.dispose();
    if (icon != null) icon.dispose();
  }
}
