package com.aig.ai.ecosystem.ui;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * Icons from web/packages/brand-assets. Dark variants live under {@code icons/dark/} with the same file
 * name; {@link #descriptor(String)} picks them while a dark Eclipse theme is active.
 */
public final class AigImages {
  public static final String LOGO = "aig16.png";

  private AigImages() {}

  public static ImageDescriptor descriptor(String name) {
    String path = (ThemeSupport.isDark() ? "icons/dark/" : "icons/") + name;
    ImageDescriptor d = AbstractUIPlugin.imageDescriptorFromPlugin(Activator.PLUGIN_ID, path);
    return d != null ? d : AbstractUIPlugin.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons/" + name);
  }

  /** Creates an image the caller must dispose. */
  public static Image create(String name) {
    ImageDescriptor d = descriptor(name);
    return d == null ? null : d.createImage();
  }
}
