package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.auth.LocalSignIn;
import com.aig.ai.ecosystem.core.config.AuthPlan;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigServices;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.Window;

/**
 * AIG &gt; Switch User...: in the local environment (browser sign-in) asks for an email and signs in as
 * that user right away, so the views can be tried with each test persona; elsewhere it signs out and
 * starts the normal sign-in.
 */
public final class SwitchUserHandler extends AbstractHandler {
  static final String PERSONAS = "premium.quality@, premium.balanced@, premium.economy@, standard.quality@, standard.balanced@,\n"
      + "free.quality@, free.balanced@, finance.user@, routing.admin@  (all @aig.example)";

  @Override
  public Object execute(ExecutionEvent event) {
    AigServices aig = Activator.aig();
    ResolvedConfig cfg = aig.config();
    if (aig.demoData() || !cfg.configured() || cfg.auth().kind() != AuthPlan.Kind.LOCAL_BROWSER) {
      aig.signOut();
      aig.signIn();
      return null;
    }
    String current = aig.live().isSignedIn() ? aig.auth().account(cfg) : null;
    String initial = current != null ? current : aig.lastLocalEmail();
    InputDialog d = new InputDialog(null, "AIG: Switch User",
        "Sign in to the local backend as (any email; test personas:\n" + PERSONAS + "):",
        initial == null ? "" : initial, v -> LocalSignIn.normalizeEmail(v) == null ? "Enter a valid email" : null);
    if (d.open() != Window.OK) return null;
    aig.signIn(LocalSignIn.normalizeEmail(d.getValue()));
    return null;
  }
}
