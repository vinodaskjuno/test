package com.aig.ai.ecosystem.ui.prefs;

import com.aig.ai.ecosystem.core.config.AigEnvironment;

/** Preference keys (instance scope of com.aig.ai.ecosystem.ui). */
public final class PreferenceConstants {
  public static final String ENVIRONMENT = "environment";
  public static final String JOB_PROFILE = "jobProfile";
  public static final String DEV_USER = "devUser";
  /** Local-environment browser sign-in email (not a secret; the dev token only works on a local dev-mode backend). */
  public static final String LOCAL_EMAIL = "local.signedInEmail";
  /** Last local sign-in email, kept after sign-out to prefill the sign-in email field. */
  public static final String LOCAL_LAST_EMAIL = "local.lastEmail";

  /** SDK source for New Agent / Update SDK / Install aig CLI: registry | bundled | monorepo. */
  public static final String SDK_SOURCE = "sdk.source";
  /** Python index serving aig-sdk (pip --index-url); empty = pip's own config. Placeholders / credentials ignored. */
  public static final String SDK_INDEX_URL = "sdk.indexUrl";
  /** npm registry for the @aig scope; empty = .npmrc. */
  public static final String SDK_NPM_REGISTRY = "sdk.npmRegistry";
  /** New Agent creates the environment (.venv / npm install) and runs aig doctor. */
  public static final String NEW_AGENT_SETUP_ENV = "newAgent.setupEnvironment";
  /**
   * TEMPORARY (docs/demo-data.md): the AIG views show sample data from an in-page emulation of platform-api and
   * Sign In starts a demo session. Default off: the views show the signed-in user's live data; remove with web/packages/demo-data.
   */
  public static final String DEMO_DATA = "demoData";

  public static final String BACKEND_URL = "backendUrl";
  public static final String TENANT_ID = "tenantId";
  public static final String CLIENT_ID = "clientId";
  public static final String SCOPE = "scope";
  public static final String AUTHORITY = "authority";

  private PreferenceConstants() {}

  public static String key(AigEnvironment env, String field) {
    return env.id() + "." + field;
  }
}
