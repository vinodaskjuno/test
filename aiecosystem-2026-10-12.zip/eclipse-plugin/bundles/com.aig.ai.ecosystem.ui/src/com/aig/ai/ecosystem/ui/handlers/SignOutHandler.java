package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.Activator;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;

/** AIG &gt; Sign Out: forgets the token for the selected environment (Secure Storage entry removed). */
public final class SignOutHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Activator.aig().signOut();
    return null;
  }
}
