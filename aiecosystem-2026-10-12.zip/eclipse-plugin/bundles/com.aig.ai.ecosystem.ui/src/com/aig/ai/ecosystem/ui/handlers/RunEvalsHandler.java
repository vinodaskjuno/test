package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.agents.AigCli;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.ProcessRunner;
import com.aig.ai.ecosystem.ui.Ui;
import com.aig.ai.ecosystem.ui.views.EvalReportView;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Adapters;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.handlers.HandlerUtil;

/**
 * Run Evals: {@code aig eval run --md <report.md>} in the selected agent project (needs
 * {@code aig-eval.yaml}); output goes to the AIG console, the Markdown summary to the AIG Eval
 * Report view.
 */
public final class RunEvalsHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Path aig = AigCli.find("aig", System.getenv());
    if (aig == null) {
      MessageDialog.openError(HandlerUtil.getActiveShell(event), "AIG",
          "The aig CLI was not found on PATH. Install the AIG Python SDK (pip install aig-sdk) and restart Eclipse.");
      return null;
    }
    Path dir = projectDir(HandlerUtil.getCurrentSelection(event));
    if (dir == null || !Files.isRegularFile(dir.resolve("aig-eval.yaml"))) {
      DirectoryDialog dd = new DirectoryDialog(HandlerUtil.getActiveShell(event));
      dd.setText("AIG: Run Evals");
      dd.setMessage("Agent project folder (contains aig-eval.yaml)");
      if (dir != null) dd.setFilterPath(dir.toString());
      String chosen = dd.open();
      if (chosen == null) return null;
      dir = Path.of(chosen);
    }
    if (!Files.isRegularFile(dir.resolve("aig-eval.yaml"))) {
      MessageDialog.openError(HandlerUtil.getActiveShell(event), "AIG", dir + " has no aig-eval.yaml (create one with: aig eval init).");
      return null;
    }
    Path project = dir;
    AigConsole.show();
    Job job = new Job("AIG: Run Evals (" + project.getFileName() + ")") {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        try {
          Path out = Files.createTempDirectory("aig-eval-");
          Path md = out.resolve("report.md");
          int code = ProcessRunner.run(AigCli.evalCommand(aig, md, out.resolve("report.json"), false), project, monitor::isCanceled);
          if (code < 0) return Status.CANCEL_STATUS;
          String report = Files.isRegularFile(md) ? Files.readString(md, StandardCharsets.UTF_8) : "No Markdown report was written (exit code " + code + "). See the AIG console.";
          Display.getDefault().asyncExec(() -> {
            if (Ui.showView(Ui.EVAL_REPORT_VIEW) instanceof EvalReportView v) v.show(project.getFileName() + " - exit code " + code, report);
          });
        } catch (Exception e) {
          AigConsole.log("[eval] failed: " + e.getMessage());
        }
        return Status.OK_STATUS;
      }
    };
    job.setUser(true);
    job.schedule();
    return null;
  }

  static Path projectDir(ISelection sel) {
    if (sel instanceof IStructuredSelection ss && !ss.isEmpty()) {
      IResource r = Adapters.adapt(ss.getFirstElement(), IResource.class);
      if (r != null && r.getProject() != null && r.getProject().getLocation() != null) return r.getProject().getLocation().toFile().toPath();
    }
    return null;
  }
}
