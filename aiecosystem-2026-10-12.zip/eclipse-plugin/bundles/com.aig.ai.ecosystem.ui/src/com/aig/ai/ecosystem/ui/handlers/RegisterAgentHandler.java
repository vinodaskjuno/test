package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.wizards.RegisterAgentWizard;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.handlers.HandlerUtil;

/** AIG &gt; Register Existing Agent...: wizard for an agent that already runs behind an HTTPS endpoint. */
public final class RegisterAgentHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    new WizardDialog(HandlerUtil.getActiveShell(event), new RegisterAgentWizard()).open();
    return null;
  }
}
