package com.aig.ai.ecosystem.ui;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/** Bundle activator; owns the {@link AigServices} singleton. */
public final class Activator extends AbstractUIPlugin {
  public static final String PLUGIN_ID = "com.aig.ai.ecosystem.ui";
  private static Activator plugin;
  private AigServices services;

  @Override
  public void start(BundleContext context) throws Exception {
    super.start(context);
    plugin = this;
  }

  @Override
  public void stop(BundleContext context) throws Exception {
    AigServices s;
    synchronized (this) {
      s = services;
      services = null;
    }
    if (s != null) s.dispose();
    plugin = null;
    super.stop(context);
  }

  public static Activator getDefault() {
    return plugin;
  }

  public synchronized AigServices services() {
    if (services == null) services = new AigServices(getPreferenceStore());
    return services;
  }

  public static AigServices aig() {
    return getDefault().services();
  }

  public static void log(String message, Throwable t) {
    Activator a = getDefault();
    if (a != null) a.getLog().log(new Status(t == null ? IStatus.INFO : IStatus.WARNING, PLUGIN_ID, message, t));
  }
}
