package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.Ui;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;

public final class OpenViewHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Ui.showView(Ui.AIG_VIEW);
    return null;
  }
}
