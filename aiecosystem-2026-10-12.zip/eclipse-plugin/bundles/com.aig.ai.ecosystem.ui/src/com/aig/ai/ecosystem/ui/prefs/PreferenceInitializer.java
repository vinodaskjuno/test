package com.aig.ai.ecosystem.ui.prefs;

import static com.aig.ai.ecosystem.ui.prefs.PreferenceConstants.*;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import com.aig.ai.ecosystem.core.config.EnvSettings;
import com.aig.ai.ecosystem.core.config.JobProfiles;
import com.aig.ai.ecosystem.ui.Activator;
import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/** Defaults: obvious per-environment placeholders (treated as "not configured" until replaced). */
public final class PreferenceInitializer extends AbstractPreferenceInitializer {
  @Override
  public void initializeDefaultPreferences() {
    IPreferenceStore s = Activator.getDefault().getPreferenceStore();
    s.setDefault(ENVIRONMENT, AigEnvironment.DEFAULT.id());
    s.setDefault(JOB_PROFILE, JobProfiles.DEFAULT);
    s.setDefault(DEV_USER, "");
    s.setDefault(LOCAL_EMAIL, "");
    s.setDefault(LOCAL_LAST_EMAIL, "");
    s.setDefault(SDK_SOURCE, "registry");
    s.setDefault(SDK_INDEX_URL, "");
    s.setDefault(SDK_NPM_REGISTRY, "");
    s.setDefault(NEW_AGENT_SETUP_ENV, true);
    s.setDefault(DEMO_DATA, false); // live data only; sample data is an explicit opt-in (docs/demo-data.md)
    for (AigEnvironment e : AigEnvironment.values()) {
      EnvSettings d = EnvSettings.defaults(e);
      s.setDefault(key(e, BACKEND_URL), d.backendUrl());
      s.setDefault(key(e, TENANT_ID), d.tenantId());
      s.setDefault(key(e, CLIENT_ID), d.clientId());
      s.setDefault(key(e, SCOPE), d.scope());
      s.setDefault(key(e, AUTHORITY), d.authority());
    }
  }
}
