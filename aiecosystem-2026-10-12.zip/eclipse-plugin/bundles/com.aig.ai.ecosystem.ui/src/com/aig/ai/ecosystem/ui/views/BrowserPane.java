package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.live.AgentBridge;
import com.aig.ai.ecosystem.core.live.DemoBridge;
import com.aig.ai.ecosystem.core.live.LiveService;
import com.aig.ai.ecosystem.core.live.WidgetBridge;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.ThemeSupport;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.BrowserFunction;
import org.eclipse.swt.browser.LocationAdapter;
import org.eclipse.swt.browser.LocationEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

/**
 * Hosts one @aig/ui widget page in an SWT Browser and implements the WidgetHost bridge:
 * <ul>
 *   <li>widget to Java: {@code window.aigPost(json)} (a {@link BrowserFunction}), validated by
 *       {@link WidgetBridge} / WebviewMessage.parse</li>
 *   <li>Java to widget: {@code browser.execute("window.__aigReceive(<json>)")}; the JSON writer
 *       escapes &lt; &gt; &amp; U+2028/9, so it is safe to splice into script</li>
 *   <li>theme: {@code window.__aigTheme(kind)} on Eclipse theme changes</li>
 *   <li>agents: catalog / run widget messages go to an {@link AgentBridge} (platform-api with the user's token)
 *       whose UI actions are done by {@link AgentUiHost}</li>
 * </ul>
 * The page is loaded with {@code setText} from the bundle (no remote resources, nonce CSP with a
 * fresh nonce per load) and any navigation away from it is blocked.
 * <p>TEMPORARY demo-data mode (preference "Use sample data", docs/demo-data.md): the page gets
 * {@code window.__aigDemo = {"env": ...}} before its script runs, answers its widgets itself from in-page sample
 * data, and posts only host commands and agent navigation, handled by a {@link DemoBridge}.
 */
public final class BrowserPane {
  /** Host commands (signIn, signOut, openDashboard, selectEnvironment, openPanel, ready). */
  public interface Commands {
    void run(String cmd);

    /** Sign in as {@code email} (already validated; local environment only). */
    default void signIn(String email) {
      run("signIn");
    }
  }

  static final String NONCE_PLACEHOLDER = "aig-runtime-nonce-0000000000000000";
  private static final SecureRandom RANDOM = new SecureRandom();

  private final Composite root;
  private final Browser browser;
  private final LiveService live;
  private final Commands commands;
  private WidgetBridge bridge;
  private AgentBridge agents;
  private DemoBridge demo;
  private boolean ready;
  private final List<Runnable> whenReady = new ArrayList<>();
  private BrowserFunction post;
  private BrowserFunction saveState;
  private String state = "null";
  private String app;
  private final Runnable themeSub;

  public BrowserPane(Composite parent, LiveService live, Commands commands) {
    this.live = live;
    this.commands = commands;
    root = new Composite(parent, SWT.NONE);
    root.setLayout(new FillLayout());
    Browser b;
    try {
      // Edge (WebView2) on Windows; WebKit on macOS/Linux. The default IE engine cannot run ES2020.
      b = new Browser(root, "win32".equals(SWT.getPlatform()) ? SWT.EDGE : SWT.NONE);
    } catch (SWTError e) {
      Activator.log("SWT Browser with the preferred engine is unavailable; using the default", e);
      b = null;
      try {
        b = new Browser(root, SWT.NONE);
      } catch (SWTError e2) {
        Label l = new Label(root, SWT.WRAP);
        l.setText("The AIG views need an embedded browser (WebKit / WebView2), which is not available: " + e2.getMessage());
        Activator.log("no SWT Browser available", e2);
      }
    }
    browser = b;
    if (browser != null) {
      browser.addLocationListener(new LocationAdapter() {
        @Override
        public void changing(LocationEvent event) {
          String loc = event.location == null ? "" : event.location;
          // Only the page we set ourselves (about:blank / data) may load; no navigation, no remote resources.
          if (!(loc.isEmpty() || loc.startsWith("about:") || loc.startsWith("data:"))) event.doit = false;
        }
      });
    }
    themeSub = ThemeSupport.onThemeChange(() -> Display.getDefault().asyncExec(this::applyTheme));
  }

  public Composite control() {
    return root;
  }

  public String app() {
    return app;
  }

  /** Loads {@code web/<app>.html} (sidebar, dashboard, signin, agents or agentRun) and connects it to the live service and the agent bridge. */
  public void load(String app) {
    if (browser == null || browser.isDisposed()) return;
    this.app = app;
    disposeBridge();
    String html;
    try {
      html = readPage(app);
    } catch (IOException e) {
      browser.setText("<html><body>AIG widget resources are missing: " + e.getMessage().replace("<", "&lt;") + "</body></html>");
      return;
    }
    byte[] n = new byte[18];
    RANDOM.nextBytes(n);
    String nonce = Base64.getUrlEncoder().withoutPadding().encodeToString(n);
    String theme = ThemeSupport.kind();
    com.aig.ai.ecosystem.ui.AigServices aig = Activator.aig();
    boolean demoMode = live.isDemo();
    String demoFlag = demoMode ? "window.__aigDemo=" + Json.object().put("env", aig.config().env().id()) + ";" : "";
    html = html.replace(NONCE_PLACEHOLDER, nonce)
        .replaceFirst("<body class=\"", "<body data-aig-theme=\"" + theme + "\" class=\"")
        .replaceFirst("<div id=\"app\"></div>", java.util.regex.Matcher.quoteReplacement(
            "<div id=\"app\"></div><script nonce=\"" + nonce + "\">window.__aigInitialState=" + state + ";" + demoFlag + "</script>"));
    ready = false;
    WidgetBridge.Commands cmds = new WidgetBridge.Commands() {
      @Override
      public void run(String cmd) {
        if ("ready".equals(cmd)) root.getDisplay().asyncExec(BrowserPane.this::onReady);
        if (commands != null) commands.run(cmd);
      }

      @Override
      public void signIn(String email) {
        if (commands != null) commands.signIn(email);
      }
    };
    if (demoMode) {
      demo = new DemoBridge(cmds, new AgentUiHost());
    } else {
      agents = new AgentBridge(aig::client, aig.background(), aig.scheduler(), this::send, new AgentUiHost(), aig.catalogCache());
      bridge = new WidgetBridge(live, this::send, cmds, agents);
    }
    post = new BrowserFunction(browser, "aigPost") {
      @Override
      public Object function(Object[] args) {
        if (args.length != 1 || !(args[0] instanceof String)) return null;
        if (bridge != null) bridge.receive((String) args[0]);
        else if (demo != null) demo.receive((String) args[0]);
        return null;
      }
    };
    saveState = new BrowserFunction(browser, "aigSaveState") {
      @Override
      public Object function(Object[] args) {
        if (args.length == 1 && args[0] instanceof String && ((String) args[0]).length() < 256 * 1024 && Json.parseObject((String) args[0]) != null) {
          state = (String) args[0];
        }
        return null;
      }
    };
    browser.setText(html, true);
  }

  /** The agent bridge of the current page (null before the first load and in demo-data mode). */
  public AgentBridge agents() {
    return agents;
  }

  /** Delivers a run target ({@code agent.target} / {@code agent.target.error}, or {@code demo.open} in demo-data mode). */
  public void showTarget(String targetMessage) {
    if (demo != null) send(targetMessage);
    else if (agents != null) agents.showTarget(targetMessage);
  }

  /** Shows a past or running invocation in the run widget. */
  public void showInvocation(String invocationId) {
    if (demo != null) send(DemoBridge.show(invocationId));
    else if (agents != null) agents.showInvocation(invocationId);
  }

  /** Runs {@code r} on the UI thread once the current page posted {@code ready} (now if it already did). */
  public void whenReady(Runnable r) {
    if (ready) r.run();
    else whenReady.add(r);
  }

  private void onReady() {
    if (root.isDisposed()) return;
    ready = true;
    List<Runnable> run = new ArrayList<>(whenReady);
    whenReady.clear();
    for (Runnable r : run) r.run();
  }

  static String readPage(String app) throws IOException {
    URL url = FileLocator.find(Activator.getDefault().getBundle(), new Path("web/" + app + ".html"), null);
    if (url == null) throw new IOException("web/" + app + ".html not found in the bundle (run the Maven build)");
    try (InputStream in = url.openStream()) {
      return new String(in.readAllBytes(), StandardCharsets.UTF_8);
    }
  }

  /** Host to widget message (JSON text); safe to call from any thread. */
  public void send(String json) {
    Display d = root.isDisposed() ? null : root.getDisplay();
    if (d == null) return;
    d.asyncExec(() -> {
      if (browser != null && !browser.isDisposed()) browser.execute("window.__aigReceive&&window.__aigReceive(" + json + ")");
    });
  }

  private void applyTheme() {
    if (browser != null && !browser.isDisposed()) browser.execute("window.__aigTheme&&window.__aigTheme(" + Json.quote(ThemeSupport.kind()) + ")");
  }

  public void setFocus() {
    if (browser != null && !browser.isDisposed()) browser.setFocus();
    else root.setFocus();
  }

  private void disposeBridge() {
    if (bridge != null) bridge.dispose();
    if (demo != null) demo.dispose();
    bridge = null;
    agents = null;
    demo = null;
    if (post != null && !post.isDisposed()) post.dispose();
    if (saveState != null && !saveState.isDisposed()) saveState.dispose();
  }

  public void dispose() {
    themeSub.run();
    disposeBridge();
    root.dispose();
  }
}
