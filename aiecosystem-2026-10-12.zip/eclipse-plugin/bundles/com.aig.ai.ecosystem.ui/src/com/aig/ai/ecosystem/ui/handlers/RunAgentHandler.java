package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.http.BackendException;
import com.aig.ai.ecosystem.core.invoke.Catalog;
import com.aig.ai.ecosystem.core.invoke.CatalogAgent;
import com.aig.ai.ecosystem.core.live.HostMessages;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigServices;
import com.aig.ai.ecosystem.ui.views.AgentUiHost;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;

/**
 * AIG &gt; Run Agent...: loads the catalog (agents the signed-in user may run) in a job, lets the user pick one
 * (filterable list) and opens the AIG Run view for it.
 */
public final class RunAgentHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    AigServices aig = Activator.aig();
    BackendClient client = aig.client();
    if (client == null || !aig.live().isSignedIn()) {
      MessageDialog.openInformation(null, "AIG: Run Agent", "Sign in first (AIG > Sign In).");
      return null;
    }
    Job job = new Job("AIG: Loading the agent catalog") {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        try {
          Catalog cat = client.catalog(null, null, null);
          aig.catalogCache().set(cat);
          Display.getDefault().asyncExec(() -> choose(cat));
        } catch (BackendException e) {
          String msg = e.describe(aig.config().env().id());
          Display.getDefault().asyncExec(() -> MessageDialog.openError(null, "AIG: Run Agent", "Could not load the agent catalog: " + msg));
        }
        return Status.OK_STATUS;
      }
    };
    job.setUser(true);
    job.schedule();
    return null;
  }

  static void choose(Catalog cat) {
    if (cat.items().isEmpty()) {
      MessageDialog.openInformation(null, "AIG: Run Agent", "There are no agents you can run yet. Agents appear here once they are active, "
          + "verified in prod and shared with you (team, group or org-wide).");
      return;
    }
    ElementListSelectionDialog d = new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider() {
      @Override
      public String getText(Object element) {
        CatalogAgent a = (CatalogAgent) element;
        return a.name() + "  (" + a.agentId() + " · " + a.team() + " · " + a.defaultVersion().env() + " v" + a.defaultVersion().version() + ")";
      }
    });
    d.setTitle("AIG: Run Agent");
    d.setMessage("Agent to run (type to filter):");
    d.setElements(cat.items().toArray());
    d.setMultipleSelection(false);
    if (d.open() == Window.OK && d.getFirstResult() instanceof CatalogAgent) {
      CatalogAgent a = (CatalogAgent) d.getFirstResult();
      AgentUiHost.openRunView(HostMessages.agentTarget(a.runTarget(null, null)));
    }
  }
}
