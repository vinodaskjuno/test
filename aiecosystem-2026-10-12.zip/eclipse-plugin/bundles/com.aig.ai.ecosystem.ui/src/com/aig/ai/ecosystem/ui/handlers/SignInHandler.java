package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.Activator;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;

/** AIG &gt; Sign In: Entra ID (PKCE, system browser) for dev/stage/prod, local sign-in page for local. */
public final class SignInHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Activator.aig().signIn();
    return null;
  }
}
