package com.aig.ai.ecosystem.ui;

import java.util.Locale;
import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.e4.ui.css.swt.theme.ITheme;
import org.eclipse.e4.ui.css.swt.theme.IThemeEngine;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;
import org.osgi.service.event.EventHandler;

/**
 * Follows the active Eclipse theme for the embedded widgets: {@code light}, {@code dark}, {@code hc}
 * (high contrast on a dark background) or {@code hc-light}. Dark is detected from the e4 theme id
 * (Eclipse "Dark", "AIG Dark", ...), falling back to the widget background luminance.
 */
public final class ThemeSupport {
  private ThemeSupport() {}

  private static IThemeEngine engine() {
    try {
      return PlatformUI.getWorkbench().getService(IThemeEngine.class);
    } catch (RuntimeException e) {
      return null;
    }
  }

  public static boolean isDark() {
    String k = kind();
    return "dark".equals(k) || "hc".equals(k);
  }

  /** Must be called on the UI thread (or it uses the default display synchronously). */
  public static String kind() {
    Display d = Display.getCurrent();
    if (d == null) {
      String[] out = new String[1];
      Display.getDefault().syncExec(() -> out[0] = kind());
      return out[0];
    }
    boolean darkBg = luminance(d.getSystemColor(org.eclipse.swt.SWT.COLOR_LIST_BACKGROUND)) < 0.4;
    if (d.getHighContrast()) return darkBg ? "hc" : "hc-light";
    IThemeEngine e = engine();
    ITheme t = e == null ? null : e.getActiveTheme();
    if (t != null && t.getId() != null) return t.getId().toLowerCase(Locale.ROOT).contains("dark") ? "dark" : "light";
    return darkBg ? "dark" : "light";
  }

  static double luminance(Color c) {
    RGB rgb = c.getRGB();
    return (0.2126 * rgb.red + 0.7152 * rgb.green + 0.0722 * rgb.blue) / 255.0;
  }

  /** Subscribes to theme switches; returns a handle to unsubscribe. */
  public static Runnable onThemeChange(Runnable r) {
    IEventBroker broker;
    try {
      broker = PlatformUI.getWorkbench().getService(IEventBroker.class);
    } catch (RuntimeException e) {
      broker = null;
    }
    if (broker == null) return () -> {};
    EventHandler h = ev -> r.run();
    broker.subscribe(IThemeEngine.Events.THEME_CHANGED, h);
    IEventBroker b = broker;
    return () -> b.unsubscribe(h);
  }
}
