package com.aig.ai.ecosystem.ui.views;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/** "AIG Eval Report": the Markdown summary written by {@code aig eval run --md}. */
public final class EvalReportView extends ViewPart {
  private Text text;

  @Override
  public void createPartControl(Composite parent) {
    text = new Text(parent, SWT.MULTI | SWT.READ_ONLY | SWT.WRAP | SWT.V_SCROLL | SWT.H_SCROLL);
    text.setFont(JFaceResources.getTextFont());
    text.setText("Run AIG > Run Evals to produce a report.");
  }

  public void show(String title, String markdown) {
    setContentDescription(title);
    text.setText(markdown);
  }

  @Override
  public void setFocus() {
    text.setFocus();
  }
}
