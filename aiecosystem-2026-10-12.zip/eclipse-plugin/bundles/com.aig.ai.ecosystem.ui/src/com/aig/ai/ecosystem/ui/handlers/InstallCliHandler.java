package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.agents.AigCli;
import com.aig.ai.ecosystem.core.agents.SdkSetup;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Bundled;
import com.aig.ai.ecosystem.core.agents.SdkSetup.CliPlan;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Pins;
import com.aig.ai.ecosystem.core.agents.SdkSetup.Source;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.SdkSupport;
import java.nio.file.Path;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.handlers.HandlerUtil;

/**
 * AIG &gt; Install / Update aig CLI: {@code pipx install --force aig-sdk[evals]==<pin>} (index from the
 * AIG preferences, or the bundled wheel), else a private venv in {@code ~/.aig/cli}; guidance when
 * neither pipx nor Python is on PATH. A failed registry install is retried with the bundled wheel.
 */
public final class InstallCliHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Pins pins = SdkSupport.pins();
    if (pins == null) {
      MessageDialog.openError(HandlerUtil.getActiveShell(event), "AIG", "This plugin build carries no SDK pins (sdk/manifest.json).");
      return null;
    }
    boolean windows = SdkSetup.isWindows();
    Path pipx = AigCli.find("pipx", System.getenv());
    Path python = SdkSetup.findPython(System.getenv(), windows);
    Bundled bundled = SdkSupport.bundled();
    Path wheels;
    try {
      wheels = bundled.pythonFile() != null ? SdkSupport.bundledDir() : null;
    } catch (java.io.IOException e) {
      wheels = null;
    }
    boolean useBundled = SdkSupport.source() == Source.BUNDLED && wheels != null;
    Path home = Path.of(System.getProperty("user.home"));
    CliPlan plan = SdkSetup.cliInstallPlan(useBundled ? bundled.pythonVersion() : pins.python(), pipx, python, useBundled ? wheels : null, SdkSupport.indexUrl(), home, windows);
    if (plan == null) {
      MessageDialog.openError(HandlerUtil.getActiveShell(event), "AIG", SdkSetup.CLI_GUIDANCE);
      return null;
    }
    Path fallbackWheels = useBundled ? null : wheels;
    AigConsole.show();
    Job job = new Job("AIG: Install aig CLI (aig-sdk " + pins.python() + ", " + plan.method() + ")") {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        String msg;
        try {
          int code = SdkSupport.runSteps(plan.steps(), monitor);
          if (code == -1) return Status.CANCEL_STATUS;
          if (code != 0 && fallbackWheels != null) {
            AigConsole.log("[sdk] registry install failed; retrying with the bundled aig-sdk wheel");
            CliPlan retry = SdkSetup.cliInstallPlan(bundled.pythonVersion(), pipx, python, fallbackWheels, null, home, windows);
            code = SdkSupport.runSteps(plan.method().equals("venv") ? retry.steps().subList(1, retry.steps().size()) : retry.steps(), monitor);
          }
          if (code != 0) msg = "Installing the aig CLI failed (exit code " + code + "). See the AIG console.";
          else if (plan.aigPath() != null) msg = "aig CLI installed in ~/.aig/cli (" + plan.aigPath() + "). Add its folder to PATH (or install pipx) so Run Evals finds `aig`.";
          else msg = "aig CLI installed with pipx; restart Eclipse if `aig` was not on its PATH before.";
        } catch (Exception e) {
          msg = "Installing the aig CLI failed: " + e.getMessage();
        }
        AigConsole.log("[sdk] " + msg);
        String text = msg;
        Display.getDefault().asyncExec(() -> MessageDialog.openInformation(null, "AIG: Install / Update aig CLI", text));
        return Status.OK_STATUS;
      }
    };
    job.setUser(true);
    job.schedule();
    return null;
  }
}
