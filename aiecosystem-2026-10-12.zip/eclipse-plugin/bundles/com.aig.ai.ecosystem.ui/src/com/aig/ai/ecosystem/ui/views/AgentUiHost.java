package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.core.live.AgentBridge;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.Ui;
import com.aig.ai.ecosystem.ui.wizards.RegisterAgentWizard;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IViewPart;

/** Eclipse side of {@link AgentBridge.Host}: Run view, Register wizard, SWT clipboard, run notifications (all on the UI thread). */
public final class AgentUiHost implements AgentBridge.Host {
  private static void ui(Runnable r) {
    Display d = Display.getDefault();
    if (d != null && !d.isDisposed()) d.asyncExec(r);
  }

  /** Opens / focuses the AIG Run view and hands it a run target host message. */
  public static void openRunView(String targetMessage) {
    IViewPart p = Ui.showView(Ui.AGENT_RUN_VIEW);
    if (p instanceof AgentRunView) ((AgentRunView) p).showTarget(targetMessage);
  }

  @Override
  public void openRun(String targetMessage) {
    ui(() -> openRunView(targetMessage));
  }

  @Override
  public void register() {
    ui(() -> new WizardDialog(Display.getDefault().getActiveShell(), new RegisterAgentWizard()).open());
  }

  @Override
  public void showRun(String invocationId) {
    ui(() -> {
      IViewPart p = Ui.showView(Ui.AGENT_RUN_VIEW);
      if (p instanceof AgentRunView) ((AgentRunView) p).showInvocation(invocationId);
    });
  }

  @Override
  public void copy(String text) {
    if (text == null || text.isEmpty()) return;
    ui(() -> {
      Clipboard cb = new Clipboard(Display.getDefault());
      try {
        cb.setContents(new Object[] {text}, new Transfer[] {TextTransfer.getInstance()});
      } finally {
        cb.dispose();
      }
    });
  }

  @Override
  public void runFinished(String agentId, String name, String status, String invocationId) {
    String msg = "AIG: background run of " + name + " " + status + " (" + invocationId + ")";
    AigConsole.log("[agents] " + msg);
    ui(() -> RunNotification.show(name, status, invocationId));
  }
}
