package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.core.live.LiveService;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigImages;
import com.aig.ai.ecosystem.ui.ThemeSupport;
import java.util.function.Consumer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.part.ViewPart;

/**
 * The "AIG" view: the @aig/ui sidebar (Token usage and Chat tabs) when signed in, the sign-in card
 * when signed out. Data comes from the shared {@link LiveService} (WebSocket, HTTP fallback).
 */
public final class AigView extends ViewPart {
  private BrowserPane pane;
  private Consumer<Boolean> signedInListener;
  private Image icon;
  private Runnable themeSub;

  @Override
  public void createPartControl(Composite parent) {
    LiveService live = Activator.aig().live();
    pane = new BrowserPane(parent, live, WidgetCommands.of(() -> pane));
    pane.load(live.isSignedIn() ? "sidebar" : "signin");
    signedInListener = signedIn -> Display.getDefault().asyncExec(() -> {
      if (pane != null && !pane.control().isDisposed()) pane.load(signedIn ? "sidebar" : "signin");
    });
    live.addSignedInListener(signedInListener);
    updateIcon();
    themeSub = ThemeSupport.onThemeChange(() -> Display.getDefault().asyncExec(this::updateIcon));
  }

  /** Switches the sidebar to a tab ("usage" or "chat"). */
  public void showTab(String tab) {
    if (pane != null) pane.send(com.aig.ai.ecosystem.core.live.HostMessages.tab(tab));
  }

  private void updateIcon() {
    Image old = icon;
    icon = AigImages.create(AigImages.LOGO);
    if (icon != null) setTitleImage(icon);
    if (old != null) old.dispose();
  }

  @Override
  public void setFocus() {
    if (pane != null) pane.setFocus();
  }

  @Override
  public void dispose() {
    if (themeSub != null) themeSub.run();
    Activator.aig().live().removeSignedInListener(signedInListener);
    if (pane != null) pane.dispose();
    pane = null;
    super.dispose();
    if (icon != null) icon.dispose();
  }
}
