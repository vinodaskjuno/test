package com.aig.ai.ecosystem.ui.status;

import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.live.LiveService;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.handlers.SelectEnvironmentHandler;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.menus.WorkbenchWindowControlContribution;

/** Status line: "AIG dev · open" (environment + connection state); click to switch environment. */
public final class StatusContribution extends WorkbenchWindowControlContribution {
  private Label label;
  private Runnable listener;
  private java.util.function.Consumer<Boolean> signedInListener;

  public StatusContribution() {
    super("com.aig.ai.ecosystem.ui.status");
  }

  /** Pure text for the status line (exposed for reuse). */
  public static String text(ResolvedConfig cfg, boolean signedIn, String status) {
    if (!cfg.configured()) return "AIG " + cfg.env().id() + " · not configured";
    if (!signedIn) return "AIG " + cfg.env().id() + " · signed out";
    return "AIG " + cfg.env().id() + " · " + status;
  }

  @Override
  protected Control createControl(Composite parent) {
    Composite c = new Composite(parent, SWT.NONE);
    GridLayout gl = new GridLayout(1, false);
    gl.marginHeight = 0;
    gl.marginWidth = 4;
    c.setLayout(gl);
    label = new Label(c, SWT.NONE);
    label.setToolTipText("AIG backend environment and connection. Click to switch environment.");
    label.addListener(SWT.MouseUp, e -> SelectEnvironmentHandler.choose());
    LiveService live = Activator.aig().live();
    listener = () -> {
      if (label != null && !label.isDisposed()) label.getDisplay().asyncExec(this::update);
    };
    live.addStatusListener(listener);
    signedInListener = b -> listener.run();
    live.addSignedInListener(signedInListener);
    update();
    return c;
  }

  @Override
  public void update() {
    if (label == null || label.isDisposed()) return;
    LiveService live = Activator.aig().live();
    String t = text(Activator.aig().config(), live.isSignedIn(), live.status().id());
    if (!t.equals(label.getText())) {
      label.setText(t);
      label.getParent().layout(true);
      label.getParent().getParent().layout(true);
    }
  }

  @Override
  public void dispose() {
    if (listener != null) Activator.aig().live().removeStatusListener(listener);
    if (signedInListener != null) Activator.aig().live().removeSignedInListener(signedInListener);
    super.dispose();
  }
}
