package com.aig.ai.ecosystem.ui.views;

import com.aig.ai.ecosystem.core.live.LiveService;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigImages;
import java.util.function.Consumer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.part.ViewPart;

/**
 * "AIG Agents": the @aig/ui agent catalog (search, team and tag filters, Run, Register existing agent, My recent
 * runs) for the agents the signed-in user may run; the sign-in card when signed out. Run opens the AIG Run view.
 */
public final class AgentsView extends ViewPart {
  private BrowserPane pane;
  private Consumer<Boolean> signedInListener;
  private Image icon;

  @Override
  public void createPartControl(Composite parent) {
    LiveService live = Activator.aig().live();
    pane = new BrowserPane(parent, live, WidgetCommands.of(() -> pane));
    pane.load(live.isSignedIn() ? "agents" : "signin");
    signedInListener = signedIn -> Display.getDefault().asyncExec(() -> {
      if (pane != null && !pane.control().isDisposed()) pane.load(signedIn ? "agents" : "signin");
    });
    live.addSignedInListener(signedInListener);
    icon = AigImages.create(AigImages.LOGO);
    if (icon != null) setTitleImage(icon);
  }

  /** Reloads the catalog (view toolbar Refresh). */
  public void refresh() {
    if (pane != null) pane.load(Activator.aig().live().isSignedIn() ? "agents" : "signin");
  }

  @Override
  public void setFocus() {
    if (pane != null) pane.setFocus();
  }

  @Override
  public void dispose() {
    Activator.aig().live().removeSignedInListener(signedInListener);
    if (pane != null) pane.dispose();
    pane = null;
    super.dispose();
    if (icon != null) icon.dispose();
  }
}
