package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.Ui;
import com.aig.ai.ecosystem.ui.views.AgentsView;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.ui.IViewPart;

/** AIG Agents view toolbar: reload the catalog. */
public final class RefreshAgentsHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    IViewPart v = Ui.showView(Ui.AGENTS_VIEW);
    if (v instanceof AgentsView) ((AgentsView) v).refresh();
    return null;
  }
}
