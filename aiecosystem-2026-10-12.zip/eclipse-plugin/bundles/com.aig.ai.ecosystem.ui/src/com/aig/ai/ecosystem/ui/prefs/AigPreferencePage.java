package com.aig.ai.ecosystem.ui.prefs;

import static com.aig.ai.ecosystem.ui.prefs.PreferenceConstants.*;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import com.aig.ai.ecosystem.core.config.JobProfiles;
import com.aig.ai.ecosystem.ui.Activator;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.ComboFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.StringFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * Window &gt; Preferences &gt; AIG AI Ecosystem. Per environment: platform-api URL and the Microsoft
 * Entra ID tenant, client id, scope and authority. Values that still contain {@code __TOKEN__}
 * placeholders mean "not configured". There is deliberately no field for any gateway key.
 */
public final class AigPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {
  public AigPreferencePage() {
    super(GRID);
    setPreferenceStore(Activator.getDefault().getPreferenceStore());
    setDescription("Connects Eclipse to the AIG platform backend. The plugin holds no model-gateway key: "
        + "model calls go through the backend, which adds the key server-side.");
  }

  @Override
  public void init(IWorkbench workbench) {}

  private static String[][] entries(java.util.List<String> values) {
    String[][] out = new String[values.size()][];
    for (int i = 0; i < values.size(); i++) out[i] = new String[] {values.get(i), values.get(i)};
    return out;
  }

  @Override
  protected void createFieldEditors() {
    Composite parent = getFieldEditorParent();
    // TEMPORARY (docs/demo-data.md): sample data in the AIG views; Sign In starts a demo session.
    addField(new BooleanFieldEditor(DEMO_DATA, "Use sample data (temporary)", parent));
    Label demoNote = new Label(parent, SWT.WRAP);
    demoNote.setText("Off (default): the views show the signed-in user's live usage from the backend. On: sample data (badge \"Sample data\"), Sign In starts a demo session and no backend is used.");
    demoNote.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1));
    String[] envs = {"local", "dev", "stage", "prod"};
    addField(new ComboFieldEditor(ENVIRONMENT, "Environment:", entries(java.util.List.of(envs)), parent));
    addField(new ComboFieldEditor(JOB_PROFILE, "Job profile (x-aig-job-profile):", entries(JobProfiles.ALL), parent));
    addField(new StringFieldEditor(DEV_USER, "Local dev user (optional email):", parent));
    Group sdk = new Group(parent, SWT.NONE);
    sdk.setText("AIG SDK (New Agent, Update SDK, Install aig CLI)");
    sdk.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1));
    sdk.setLayout(new GridLayout(2, false));
    addField(new ComboFieldEditor(SDK_SOURCE, "SDK source:", new String[][] {{"registry (internal index; bundled fallback)", "registry"},
        {"bundled (shipped with this plugin)", "bundled"}, {"monorepo (platform development)", "monorepo"}}, sdk));
    addField(new StringFieldEditor(SDK_INDEX_URL, "Python index URL (optional):", sdk));
    addField(new StringFieldEditor(SDK_NPM_REGISTRY, "npm registry for @aig (optional):", sdk));
    addField(new BooleanFieldEditor(NEW_AGENT_SETUP_ENV, "New Agent creates the environment and runs aig doctor", sdk));
    Label sdkNote = new Label(sdk, SWT.WRAP);
    sdkNote.setText("Empty index / registry = pip.conf, PIP_INDEX_URL, .npmrc. URLs with credentials or __ placeholders are ignored.");
    sdkNote.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1));
    sdk.setLayout(new GridLayout(2, false));
    for (AigEnvironment e : AigEnvironment.values()) {
      Group g = new Group(parent, SWT.NONE);
      g.setText(e.id());
      GridData gd = new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1);
      g.setLayoutData(gd);
      g.setLayout(new GridLayout(2, false));
      addField(new StringFieldEditor(key(e, BACKEND_URL), "Backend URL:", g));
      if (e == AigEnvironment.LOCAL) {
        Label l = new Label(g, SWT.WRAP);
        l.setText("Local uses the backend's local sign-in page (no SSO); http is allowed only for localhost.");
        l.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1));
      } else {
        addField(new StringFieldEditor(key(e, TENANT_ID), "Entra tenant id:", g));
        addField(new StringFieldEditor(key(e, CLIENT_ID), "Entra client id (IDE app):", g));
        addField(new StringFieldEditor(key(e, SCOPE), "API scope:", g));
        addField(new StringFieldEditor(key(e, AUTHORITY), "Entra authority:", g));
      }
      g.setLayout(new GridLayout(2, false));
    }
  }
}
