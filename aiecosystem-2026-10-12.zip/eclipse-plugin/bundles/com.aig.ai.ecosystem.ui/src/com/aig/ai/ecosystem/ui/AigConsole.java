package com.aig.ai.ecosystem.ui;

import java.io.IOException;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;

/** The "AIG" console (Console view): logs, Ask AIG answers, aig CLI output. Never prints tokens. */
public final class AigConsole {
  private static final String NAME = "AIG";
  private static MessageConsole console;

  private AigConsole() {}

  public static synchronized MessageConsole get() {
    if (console != null) return console;
    IConsoleManager m = ConsolePlugin.getDefault().getConsoleManager();
    for (IConsole c : m.getConsoles()) {
      if (NAME.equals(c.getName()) && c instanceof MessageConsole) return console = (MessageConsole) c;
    }
    console = new MessageConsole(NAME, AigImages.descriptor(AigImages.LOGO));
    m.addConsoles(new IConsole[] {console});
    return console;
  }

  public static void show() {
    ConsolePlugin.getDefault().getConsoleManager().showConsoleView(get());
  }

  public static void log(String line) {
    try {
      append(line + "\n");
    } catch (RuntimeException e) {
      // console not available (e.g. during shutdown)
    }
  }

  public static void append(String text) {
    try (MessageConsoleStream s = get().newMessageStream()) {
      s.print(text);
    } catch (IOException ignored) {
      // closing a message stream does not fail in practice
    }
  }
}
