package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigServices;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;

/** AIG &gt; Select Environment: local / dev / stage / prod (shows which are configured). */
public final class SelectEnvironmentHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    choose();
    return null;
  }

  public static void choose() {
    AigServices aig = Activator.aig();
    AigEnvironment current = aig.config().env();
    ElementListSelectionDialog d = new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider() {
      @Override
      public String getText(Object element) {
        AigEnvironment e = (AigEnvironment) element;
        ResolvedConfig c = aig.config(e);
        return e.id() + (e == current ? "  (current)" : "") + (c.configured() ? "" : "  - not configured");
      }
    });
    d.setTitle("AIG: Select Environment");
    d.setMessage("Backend environment to connect to:");
    d.setElements(AigEnvironment.values());
    d.setInitialSelections(current);
    d.setMultipleSelection(false);
    if (d.open() == Window.OK && d.getFirstResult() instanceof AigEnvironment) aig.setEnvironment((AigEnvironment) d.getFirstResult());
  }
}
