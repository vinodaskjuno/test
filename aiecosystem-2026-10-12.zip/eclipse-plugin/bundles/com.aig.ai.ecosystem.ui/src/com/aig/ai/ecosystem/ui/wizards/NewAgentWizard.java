package com.aig.ai.ecosystem.ui.wizards;

import com.aig.ai.ecosystem.core.agents.SdkSetup;
import com.aig.ai.ecosystem.core.agents.Template;
import com.aig.ai.ecosystem.core.agents.Templates;
import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.http.BackendException;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.AigServices;
import com.aig.ai.ecosystem.ui.SdkSupport;
import com.aig.ai.ecosystem.ui.prefs.PreferenceConstants;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.widgets.Display;

/**
 * AIG &gt; New Agent: scaffolds from the templates bundled with the plugin (built-in scaffolder, same
 * rules as {@code aig init}), fills aig-agent.yaml, registers the agent as a draft through
 * {@code POST /api/v1/agents} with the signed-in user's token (owner and team default server-side),
 * then creates the environment and installs the pinned SDK ({@link SdkSupport}: .venv + pip / npm
 * install, bundled fallback; output in the AIG console, cancellable) and logs the {@code aig doctor}
 * summary.
 */
public final class NewAgentWizard extends Wizard {
  private NewAgentPage page;
  private Path templatesRoot;

  public NewAgentWizard() {
    setWindowTitle("AIG: New Agent");
    setNeedsProgressMonitor(false);
  }

  static Path bundledTemplates() throws IOException {
    URL url = FileLocator.find(Activator.getDefault().getBundle(), new org.eclipse.core.runtime.Path("templates"), null);
    if (url == null) throw new IOException("templates/ not bundled (run the Maven build)");
    try {
      return Path.of(FileLocator.toFileURL(url).toURI());
    } catch (java.net.URISyntaxException e) {
      return Path.of(FileLocator.toFileURL(url).getPath());
    }
  }

  @Override
  public void addPages() {
    List<Template> list = new ArrayList<>();
    try {
      templatesRoot = bundledTemplates();
      list.addAll(Templates.load(templatesRoot).values());
    } catch (IOException e) {
      Activator.log("could not load the bundled templates", e);
    }
    page = new NewAgentPage(list, Activator.aig().live().team());
    addPage(page);
  }

  @Override
  public boolean performFinish() {
    Template t = page.template();
    String agentId = page.agentId();
    String name = page.agentName();
    String description = page.agentDescription();
    String team = page.team();
    Path dest = page.targetDir();
    AigServices aig = Activator.aig();
    AigConsole.show();
    Job job = new Job("AIG: New agent " + agentId) {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        try {
          Map<String, String> values = Templates.values(t, dest, agentId, team, description);
          List<Path> files = Templates.scaffold(t, dest, values, false);
          Path descriptor = dest.resolve("aig-agent.yaml");
          if (Files.isRegularFile(descriptor)) {
            Files.writeString(descriptor, SdkSetup.renderDescriptor(Files.readString(descriptor, StandardCharsets.UTF_8), agentId, name, values.get("description")),
                StandardCharsets.UTF_8);
          }
          AigConsole.log("[new agent] scaffolded " + t.name() + " into " + dest + " (" + files.size() + " files)");
          BackendClient client = aig.client();
          String registered;
          if (client == null || !aig.auth().hasSession(aig.config())) {
            registered = "Not registered: sign in (AIG > Sign In) and register it in the AIG portal, or run `aig init` registration later.";
          } else {
            try {
              Map<String, Object> r = client.registerAgent(agentId, name.isEmpty() ? null : name, description);
              registered = "Registered " + agentId + " as a draft (status " + Json.str(Json.obj(r, "agent"), "status") + ", team " + Json.str(Json.obj(r, "agent"), "team") + ").";
            } catch (BackendException e) {
              registered = "Registration failed: " + e.describe(aig.config().env().id());
            }
          }
          AigConsole.log("[new agent] " + registered);
          String env = "";
          if (Activator.getDefault().getPreferenceStore().getBoolean(PreferenceConstants.NEW_AGENT_SETUP_ENV)) {
            monitor.setTaskName("AIG: New agent " + agentId + ": installing the environment and the AIG SDK");
            SdkSupport.Result r = SdkSupport.setupProject(dest, false, monitor);
            AigConsole.log("[new agent] " + r.message());
            env = r.ok() ? "\nEnvironment ready (SDK from " + r.source().id() + ")"
                + (r.doctor() != null ? "; aig doctor: " + (r.doctor().ok() ? "all checks passed." : r.doctor().failed() + " problem(s), see the AIG console.") : ".")
                : "\nEnvironment NOT ready: " + r.message();
          }
          String msg = "Created " + dest + ".\n" + registered + env;
          Display.getDefault().asyncExec(() -> MessageDialog.openInformation(null, "AIG: New Agent", msg));
          return Status.OK_STATUS;
        } catch (Exception e) {
          AigConsole.log("[new agent] failed: " + e.getMessage());
          Display.getDefault().asyncExec(() -> MessageDialog.openError(null, "AIG: New Agent", e.getMessage()));
          return Status.OK_STATUS;
        }
      }
    };
    job.setUser(true);
    job.schedule();
    return true;
  }
}
