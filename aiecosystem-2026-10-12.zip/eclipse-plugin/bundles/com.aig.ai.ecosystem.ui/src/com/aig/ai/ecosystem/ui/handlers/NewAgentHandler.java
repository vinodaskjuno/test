package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.wizards.NewAgentWizard;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.handlers.HandlerUtil;

public final class NewAgentHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    new WizardDialog(HandlerUtil.getActiveShell(event), new NewAgentWizard()).open();
    return null;
  }
}
