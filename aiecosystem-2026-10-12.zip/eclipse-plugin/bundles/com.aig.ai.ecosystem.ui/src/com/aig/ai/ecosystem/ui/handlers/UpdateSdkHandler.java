package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.core.agents.SdkSetup;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.SdkSupport;
import java.nio.file.Path;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.handlers.HandlerUtil;

/**
 * AIG &gt; Update SDK in this project: detects the Python (pyproject.toml) or Node (package.json) project
 * of the selection, sets the SDK to the version this plugin ships with (aig-sdk==&lt;pin&gt; /
 * {@code @aig/sdk}), reinstalls ({@code .venv/bin/python -m pip install -e .[dev]} / {@code npm install})
 * and shows the {@code aig doctor} result. Output goes to the AIG console.
 */
public final class UpdateSdkHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Path dir = RunEvalsHandler.projectDir(HandlerUtil.getCurrentSelection(event));
    if (dir == null || SdkSetup.detect(dir) == null) {
      DirectoryDialog dd = new DirectoryDialog(HandlerUtil.getActiveShell(event));
      dd.setText("AIG: Update SDK in this project");
      dd.setMessage("Agent project folder (contains pyproject.toml or package.json)");
      if (dir != null) dd.setFilterPath(dir.toString());
      String chosen = dd.open();
      if (chosen == null) return null;
      dir = Path.of(chosen);
    }
    if (SdkSetup.detect(dir) == null) {
      MessageDialog.openError(HandlerUtil.getActiveShell(event), "AIG", dir + " has no pyproject.toml or package.json.");
      return null;
    }
    Path project = dir;
    AigConsole.show();
    Job job = new Job("AIG: Update SDK (" + project.getFileName() + ")") {
      @Override
      protected IStatus run(IProgressMonitor monitor) {
        String msg;
        try {
          SdkSupport.Result r = SdkSupport.setupProject(project, true, monitor);
          if (monitor.isCanceled()) return Status.CANCEL_STATUS;
          msg = r.ok() ? "SDK updated in " + project + " (" + r.message() + ")."
              + (r.doctor() != null ? " aig doctor: " + (r.doctor().ok() ? "all checks passed." : r.doctor().failed() + " problem(s), see the AIG console.") : "")
              : "SDK update failed: " + r.message();
        } catch (Exception e) {
          msg = "SDK update failed: " + e.getMessage();
        }
        AigConsole.log("[sdk] " + msg);
        String text = msg;
        Display.getDefault().asyncExec(() -> MessageDialog.openInformation(null, "AIG: Update SDK", text));
        return Status.OK_STATUS;
      }
    };
    job.setUser(true);
    job.schedule();
    return null;
  }
}
