package com.aig.ai.ecosystem.ui.wizards;

import com.aig.ai.ecosystem.core.agents.Template;
import com.aig.ai.ecosystem.core.agents.Templates;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/** Template, agent id, name, description, team and location. */
final class NewAgentPage extends WizardPage {
  private final List<Template> templates;
  private final String defaultTeam;
  private Combo template;
  private Text agentId;
  private Text name;
  private Text description;
  private Text team;
  private Text location;

  NewAgentPage(List<Template> templates, String defaultTeam) {
    super("newAgent");
    this.templates = templates;
    this.defaultTeam = defaultTeam;
    setTitle("New AIG agent");
    setDescription("Scaffold an agent from an AIG starter template and register it in the platform registry.");
  }

  @Override
  public void createControl(Composite parent) {
    Composite c = new Composite(parent, SWT.NONE);
    c.setLayout(new GridLayout(3, false));
    template = combo(c, "Template:");
    for (Template t : templates) template.add(t.toString());
    if (!templates.isEmpty()) template.select(0);
    agentId = text(c, "Agent id:", "");
    agentId.setMessage("[A-Za-z0-9._-]{1,64}, e.g. claims-triage");
    name = text(c, "Name:", "");
    description = text(c, "Description:", "");
    team = text(c, "Team:", defaultTeam == null ? "" : defaultTeam);
    team.setMessage("owning team slug");
    new Label(c, SWT.NONE).setText("Location:");
    location = new Text(c, SWT.BORDER);
    location.setText(System.getProperty("user.home"));
    location.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
    Button browse = new Button(c, SWT.PUSH);
    browse.setText("Browse...");
    browse.addListener(SWT.Selection, e -> {
      DirectoryDialog d = new DirectoryDialog(getShell());
      d.setFilterPath(location.getText());
      String p = d.open();
      if (p != null) location.setText(p);
    });
    agentId.addModifyListener(e -> validate());
    team.addModifyListener(e -> validate());
    location.addModifyListener(e -> validate());
    template.addModifyListener(e -> validate());
    setControl(c);
    validate();
  }

  private Combo combo(Composite c, String label) {
    new Label(c, SWT.NONE).setText(label);
    Combo combo = new Combo(c, SWT.READ_ONLY);
    combo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
    return combo;
  }

  private Text text(Composite c, String label, String value) {
    new Label(c, SWT.NONE).setText(label);
    Text t = new Text(c, SWT.BORDER);
    t.setText(value);
    t.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
    return t;
  }

  private void validate() {
    String err = null;
    if (templates.isEmpty()) err = "No templates available.";
    else if (template.getSelectionIndex() < 0) err = "Choose a template.";
    else if (!Templates.AGENT_ID.matcher(agentId.getText().trim()).matches()) err = "Agent id must match [A-Za-z0-9._-]{1,64}.";
    else if (!Templates.TEAM.matcher(team.getText().trim()).matches()) err = "Team must be a slug [A-Za-z0-9._-]{1,64}.";
    else if (location.getText().isBlank() || !Files.isDirectory(Path.of(location.getText().trim()))) err = "Location must be an existing folder.";
    else if (Files.exists(targetDir())) err = targetDir() + " already exists.";
    setErrorMessage(err);
    setPageComplete(err == null);
  }

  Template template() {
    return templates.get(template.getSelectionIndex());
  }

  String agentId() {
    return agentId.getText().trim();
  }

  String agentName() {
    return name.getText().trim();
  }

  String agentDescription() {
    return description.getText().trim();
  }

  String team() {
    return team.getText().trim();
  }

  Path targetDir() {
    return Path.of(location.getText().trim()).resolve(agentId.getText().trim());
  }
}
