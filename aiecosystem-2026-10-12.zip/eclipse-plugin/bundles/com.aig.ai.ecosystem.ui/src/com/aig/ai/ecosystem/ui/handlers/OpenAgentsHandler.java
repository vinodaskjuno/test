package com.aig.ai.ecosystem.ui.handlers;

import com.aig.ai.ecosystem.ui.Ui;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;

/** AIG &gt; Open Agents: the AIG Agents view (catalog). */
public final class OpenAgentsHandler extends AbstractHandler {
  @Override
  public Object execute(ExecutionEvent event) {
    Ui.showView(Ui.AGENTS_VIEW);
    return null;
  }
}
