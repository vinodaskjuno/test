package com.aig.ai.ecosystem.ui.wizards;

import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.http.BackendException;
import com.aig.ai.ecosystem.core.invoke.AgentIds;
import com.aig.ai.ecosystem.core.invoke.AgentRegistration;
import com.aig.ai.ecosystem.core.invoke.AgentVersionInfo;
import com.aig.ai.ecosystem.core.invoke.VerifyResult;
import com.aig.ai.ecosystem.ui.Activator;
import com.aig.ai.ecosystem.ui.AigConsole;
import com.aig.ai.ecosystem.ui.AigServices;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * AIG &gt; Register Existing Agent...: registers an agent that already runs behind an HTTPS endpoint implementing
 * the {@code aig-http/1} contract. Page 1: agent id, name, description, tags. Page 2: endpoint, environment,
 * version, credentials <em>reference</em> (auth type + Secrets Manager ARN; there is no field for the secret
 * itself), input schema (pasted or loaded from a file, must be a JSON object), optional verification. Finish:
 * {@code POST /api/v1/agents} (draft) + {@code POST /api/v1/agents/{id}/versions} + optional
 * {@code .../verify}, with the signed-in user's token; the verification checks are shown at the end.
 */
public final class RegisterAgentWizard extends Wizard {
  private AgentPage agentPage;
  private EndpointPage endpointPage;

  public RegisterAgentWizard() {
    setWindowTitle("AIG: Register Existing Agent");
    setNeedsProgressMonitor(true);
  }

  @Override
  public void addPages() {
    agentPage = new AgentPage();
    endpointPage = new EndpointPage(Activator.aig().config().env().id());
    addPage(agentPage);
    addPage(endpointPage);
  }

  private static Text field(Composite c, String label, String hint, String tooltip) {
    new Label(c, SWT.NONE).setText(label);
    Text t = new Text(c, SWT.BORDER | SWT.SINGLE);
    t.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
    if (hint != null) t.setMessage(hint);
    if (tooltip != null) t.setToolTipText(tooltip);
    return t;
  }

  static final class AgentPage extends WizardPage {
    Text id;
    Text name;
    Text description;
    Text tags;

    AgentPage() {
      super("agent");
      setTitle("Agent");
      setDescription("The registry record. New agents start as a draft owned by you and your team.");
      setPageComplete(false);
    }

    @Override
    public void createControl(Composite parent) {
      Composite c = new Composite(parent, SWT.NONE);
      c.setLayout(new GridLayout(2, false));
      id = field(c, "Agent id:", "claims-triage", "[A-Za-z0-9._-]{1,64}; cannot be changed later");
      name = field(c, "Name:", "Claims triage", null);
      description = field(c, "Description:", "What the agent does (shown in the catalog)", null);
      tags = field(c, "Tags:", "claims, triage", "Comma separated; lower case [a-z0-9][a-z0-9._-]{0,31}, at most 20");
      for (Text t : new Text[] {id, name, description, tags}) t.addModifyListener(e -> validate());
      setControl(c);
    }

    List<String> tagList() {
      return AgentRegistration.parseTags(tags.getText());
    }

    void validate() {
      String p = id.getText().isBlank() ? "Enter the agent id." : AgentRegistration.agentProblem(id.getText().trim(), name.getText().trim(), description.getText().trim(), tagList());
      setErrorMessage(id.getText().isBlank() ? null : p);
      setPageComplete(p == null);
    }
  }

  static final class EndpointPage extends WizardPage {
    private final String defaultEnv;
    Text endpoint;
    Combo env;
    Text version;
    Combo authType;
    Text secretArn;
    Text schema;
    Button verify;

    EndpointPage(String defaultEnv) {
      super("endpoint");
      this.defaultEnv = defaultEnv;
      setTitle("Endpoint and version");
      setDescription("Where platform-api reaches the agent (aig-http/1: POST /invocations, GET /ping). Credentials are referenced by secret ARN only.");
      setPageComplete(false);
    }

    @Override
    public void createControl(Composite parent) {
      Composite c = new Composite(parent, SWT.NONE);
      c.setLayout(new GridLayout(2, false));
      endpoint = field(c, "Endpoint:", "https://agents.example.com/claims-triage", "Base URL; https:// (http://localhost only for env local); no credentials, query or fragment");
      new Label(c, SWT.NONE).setText("Environment:");
      env = new Combo(c, SWT.READ_ONLY);
      env.setItems(AgentIds.ENVS.toArray(new String[0]));
      env.select(Math.max(0, AgentIds.ENVS.indexOf(defaultEnv)));
      version = field(c, "Version:", "1.0.0", "[A-Za-z0-9][A-Za-z0-9._+-]{0,127}");
      version.setText("1.0.0");
      new Label(c, SWT.NONE).setText("Auth type:");
      authType = new Combo(c, SWT.READ_ONLY);
      authType.setItems(AgentRegistration.AUTH_TYPES.toArray(new String[0]));
      authType.select(0);
      authType.setToolTipText("How platform-api authenticates to the agent: none, an API key or OAuth client credentials kept in AWS Secrets Manager");
      secretArn = field(c, "Secret ARN:", "arn:aws:secretsmanager:<region>:<account>:secret:aig/<env>/agents/<id>/invoke-auth",
          "A reference to the secret in AWS Secrets Manager (local:<NAME> for env local). Never paste the key or client secret itself.");
      Label note = new Label(c, SWT.WRAP);
      note.setText("Reference only: the secret value stays in Secrets Manager and is never entered here or sent from Eclipse.");
      GridData nd = new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1);
      nd.widthHint = 480;
      note.setLayoutData(nd);

      Label sl = new Label(c, SWT.NONE);
      sl.setText("Input schema (JSON):");
      sl.setLayoutData(new GridData(SWT.BEGINNING, SWT.BEGINNING, false, false));
      Composite sc = new Composite(c, SWT.NONE);
      GridLayout sgl = new GridLayout(1, false);
      sgl.marginWidth = 0;
      sgl.marginHeight = 0;
      sc.setLayout(sgl);
      sc.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
      schema = new Text(sc, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL);
      schema.setFont(JFaceResources.getTextFont());
      schema.setMessage("{\"type\": \"object\", \"properties\": {...}}  (optional; drives the run form)");
      GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true);
      gd.heightHint = 140;
      gd.widthHint = 480;
      schema.setLayoutData(gd);
      Button load = new Button(sc, SWT.PUSH);
      load.setText("Load from file...");
      load.addListener(SWT.Selection, e -> loadSchema());

      new Label(c, SWT.NONE);
      verify = new Button(c, SWT.CHECK);
      verify.setText("Verify after registering (health, test invocation, gateway and trace checks)");
      verify.setSelection(true);

      endpoint.addModifyListener(e -> validate());
      version.addModifyListener(e -> validate());
      secretArn.addModifyListener(e -> validate());
      schema.addModifyListener(e -> validate());
      env.addListener(SWT.Selection, e -> validate());
      authType.addListener(SWT.Selection, e -> validate());
      validate();
      setControl(c);
    }

    private void loadSchema() {
      FileDialog fd = new FileDialog(getShell(), SWT.OPEN);
      fd.setFilterExtensions(new String[] {"*.json", "*.*"});
      String file = fd.open();
      if (file == null) return;
      try {
        Path p = Path.of(file);
        if (Files.size(p) > AgentRegistration.MAX_SCHEMA_BYTES) {
          setErrorMessage("The file is larger than " + AgentRegistration.MAX_SCHEMA_BYTES / 1024 + " KiB.");
          return;
        }
        String text = Files.readString(p, StandardCharsets.UTF_8);
        Map<String, Object> o = AgentRegistration.parseSchema(text);
        if (o != null && o.get("input_schema") != null && o.get("properties") == null && o.get("type") == null) {
          // aig-agent.yaml exported as JSON / a /schema answer: take its input_schema
          Object inner = o.get("input_schema");
          text = com.aig.ai.ecosystem.core.json.Json.write(inner);
        }
        schema.setText(text);
      } catch (IOException | IllegalArgumentException ex) {
        setErrorMessage("Could not load the schema: " + ex.getMessage());
      }
    }

    String envId() {
      return env.getText();
    }

    String authTypeId() {
      return authType.getText();
    }

    AgentRegistration.VersionSpec spec() {
      return new AgentRegistration.VersionSpec(version.getText().trim(), envId(), endpoint.getText().trim(), authTypeId(),
          "none".equals(authTypeId()) ? null : secretArn.getText().trim(), AgentRegistration.parseSchema(schema.getText()));
    }

    void validate() {
      boolean none = "none".equals(authTypeId());
      secretArn.setEnabled(!none);
      String p;
      try {
        AgentRegistration.VersionSpec s = spec();
        p = endpoint.getText().isBlank() ? "Enter the agent's endpoint." : AgentRegistration.versionProblem(s);
      } catch (IllegalArgumentException e) {
        p = e.getMessage();
      }
      setErrorMessage(endpoint.getText().isBlank() ? null : p);
      setPageComplete(p == null);
    }
  }

  @Override
  public boolean performFinish() {
    AigServices aig = Activator.aig();
    BackendClient client = aig.client();
    if (client == null || !aig.live().isSignedIn()) {
      endpointPage.setErrorMessage("Sign in first (AIG > Sign In).");
      return false;
    }
    String agentId = agentPage.id.getText().trim();
    String name = agentPage.name.getText().trim();
    String description = agentPage.description.getText().trim();
    List<String> tags = agentPage.tagList();
    AgentRegistration.VersionSpec spec;
    try {
      spec = endpointPage.spec();
    } catch (IllegalArgumentException e) {
      endpointPage.setErrorMessage(e.getMessage());
      return false;
    }
    boolean doVerify = endpointPage.verify.getSelection();
    String envName = aig.config().env().id();
    StringBuilder report = new StringBuilder();
    String[] error = new String[1];
    try {
      getContainer().run(true, false, monitor -> {
        monitor.beginTask("Registering " + agentId, doVerify ? 3 : 2);
        try {
          monitor.subTask("Agent record");
          try {
            client.registerAgent(agentId, name.isEmpty() ? null : name, description, tags);
            report.append("Registered ").append(agentId).append(" as a draft.\n");
          } catch (BackendException e) {
            if (e.status() != 409 && !"agent_exists".equals(e.code())) throw e;
            report.append(agentId).append(" is already registered; adding the version.\n");
          }
          monitor.worked(1);
          monitor.subTask("Version " + spec.version() + " (" + spec.env() + ")");
          AgentVersionInfo v = client.registerVersion(agentId, spec);
          report.append("Version ").append(v.version()).append(" (").append(v.env()).append(", ").append(v.kind()).append(") registered.\n");
          monitor.worked(1);
          if (doVerify) {
            monitor.subTask("Verifying (health, test invocation, gateway, trace)");
            VerifyResult r = client.verifyVersion(agentId, v.version(), v.env());
            report.append('\n').append(r.summary()).append('\n');
            if (!r.passed()) report.append("\nFix the failing checks and verify again; the agent is not in the catalog until a version is verified.\n");
            monitor.worked(1);
          } else {
            report.append("\nNot verified yet: the agent is not in the catalog until a version is verified.\n");
          }
        } catch (BackendException e) {
          error[0] = e.describe(envName) + (e.code() != null ? " (" + e.code() + ")" : "");
        } finally {
          monitor.done();
        }
      });
    } catch (InvocationTargetException e) {
      error[0] = e.getCause() == null ? e.getMessage() : e.getCause().getMessage();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      return false;
    }
    AigConsole.log("[register agent] " + report.toString().replace('\n', ' ').trim() + (error[0] != null ? " Error: " + error[0] : ""));
    if (error[0] != null) {
      String done = report.length() > 0 ? report.toString().trim() + "\n" : "";
      endpointPage.setErrorMessage(error[0]);
      if (!done.isEmpty()) MessageDialog.openWarning(getShell(), "AIG: Register Existing Agent", done + "\nFailed: " + error[0]);
      return false;
    }
    MessageDialog.openInformation(getShell(), "AIG: Register Existing Agent", report.toString().trim());
    aig.catalogCache().set(null);
    return true;
  }
}
