package com.aig.ai.ecosystem.ui.prefs;

import com.aig.ai.ecosystem.core.auth.LocalSessionStore;
import org.eclipse.jface.preference.IPreferenceStore;

/** Local sign-in email in instance preferences. */
public final class PrefsLocalSessionStore implements LocalSessionStore {
  private final IPreferenceStore store;

  public PrefsLocalSessionStore(IPreferenceStore store) {
    this.store = store;
  }

  @Override
  public String load() {
    String v = store.getString(PreferenceConstants.LOCAL_EMAIL);
    return v == null || v.isEmpty() ? null : v;
  }

  @Override
  public void save(String email) {
    store.setValue(PreferenceConstants.LOCAL_EMAIL, email);
    if (email != null && !email.isEmpty()) store.setValue(PreferenceConstants.LOCAL_LAST_EMAIL, email);
  }

  @Override
  public String last() {
    String v = store.getString(PreferenceConstants.LOCAL_LAST_EMAIL);
    return v == null || v.isEmpty() ? load() : v;
  }

  @Override
  public void clear() {
    store.setValue(PreferenceConstants.LOCAL_EMAIL, "");
  }
}
