package com.aig.ai.ecosystem.ui;

import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

/** Small UI-thread helpers. */
public final class Ui {
  public static final String AIG_VIEW = "com.aig.ai.ecosystem.ui.views.aig";
  public static final String DASHBOARD_VIEW = "com.aig.ai.ecosystem.ui.views.dashboard";
  public static final String EVAL_REPORT_VIEW = "com.aig.ai.ecosystem.ui.views.evalReport";
  public static final String AGENTS_VIEW = "com.aig.ai.ecosystem.ui.views.agents";
  public static final String AGENT_RUN_VIEW = "com.aig.ai.ecosystem.ui.views.agentRun";

  private Ui() {}

  public static IWorkbenchPage page() {
    IWorkbenchWindow w = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
    if (w == null && PlatformUI.getWorkbench().getWorkbenchWindowCount() > 0) w = PlatformUI.getWorkbench().getWorkbenchWindows()[0];
    return w == null ? null : w.getActivePage();
  }

  /** Shows a view (UI thread). */
  public static IViewPart showView(String id) {
    IWorkbenchPage p = page();
    if (p == null) return null;
    try {
      return p.showView(id);
    } catch (PartInitException e) {
      Activator.log("could not open view " + id, e);
      return null;
    }
  }
}
