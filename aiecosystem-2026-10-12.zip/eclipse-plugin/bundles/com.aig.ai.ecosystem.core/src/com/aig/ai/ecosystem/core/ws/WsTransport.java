package com.aig.ai.ecosystem.core.ws;

import java.net.URI;
import java.util.Map;

/** Pluggable WebSocket transport (the JDK client in the plugin, a fake in tests). */
public interface WsTransport {
  /** Callbacks for one connection. Implementations deliver whole text messages. */
  interface Listener {
    void onOpen();

    void onText(String text);

    void onClose(int code, String reason);

    void onError(Throwable error);
  }

  /** An open (or opening) connection. */
  interface Connection {
    void send(String text);

    void close(int code, String reason);
  }

  /** Starts connecting; callbacks may arrive on any thread. */
  Connection connect(URI uri, Map<String, String> headers, Listener listener);
}
