package com.aig.ai.ecosystem.core.http;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.Map;
import java.util.Set;

/** One chat message ({@code system}, {@code user} or {@code assistant}). */
public record ChatMessage(String role, String content) {
  private static final Set<String> ROLES = Set.of("system", "user", "assistant");

  public ChatMessage {
    if (!ROLES.contains(role)) throw new IllegalArgumentException("invalid role " + role);
    if (content == null) throw new IllegalArgumentException("content is null");
  }

  public Map<String, Object> toJson() {
    return Json.object().put("role", role).put("content", content).map();
  }
}
