package com.aig.ai.ecosystem.core.auth;

import com.aig.ai.ecosystem.core.config.AuthPlan.EntraConfig;
import com.aig.ai.ecosystem.core.json.Json;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.LongSupplier;

/**
 * Microsoft Entra ID (v2.0 endpoints) Authorization Code flow with PKCE for a public client, as
 * recommended for native apps (RFC 8252): system browser, loopback redirect, no client secret.
 */
public final class EntraClient {
  /** Extra scopes so a refresh token and the account name come back. */
  static final String EXTRA_SCOPES = "openid profile offline_access";

  private final HttpClient http;
  private final LongSupplier nowSec;

  public EntraClient() {
    this(() -> System.currentTimeMillis() / 1000);
  }

  public EntraClient(LongSupplier nowSec) {
    this.http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).connectTimeout(Duration.ofSeconds(10)).build();
    this.nowSec = nowSec;
  }

  static String endpoint(EntraConfig c, String what) {
    return c.authority() + "/" + Query.enc(c.tenantId()) + "/oauth2/v2.0/" + what;
  }

  public static String scopes(EntraConfig c) {
    return c.scope() + " " + EXTRA_SCOPES;
  }

  public static String authorizeUrl(EntraConfig c, String redirectUri, String state, String challenge) {
    Map<String, String> q = new LinkedHashMap<>();
    q.put("client_id", c.clientId());
    q.put("response_type", "code");
    q.put("redirect_uri", redirectUri);
    q.put("response_mode", "query");
    q.put("scope", scopes(c));
    q.put("state", state);
    q.put("code_challenge", challenge);
    q.put("code_challenge_method", "S256");
    q.put("prompt", "select_account");
    return endpoint(c, "authorize") + "?" + Query.encode(q);
  }

  /** Validates the redirect: matching one-time state, no error, a code. Returns the code. */
  public static CallbackResult handleCallback(String query, PendingStates pending) {
    Map<String, String> q = Query.parse(query);
    String state = q.getOrDefault("state", "");
    boolean stateOk = !state.isEmpty() && pending.consume(state);
    if (q.containsKey("error")) {
      String d = q.getOrDefault("error_description", q.get("error"));
      return CallbackResult.fail("Microsoft sign-in failed: " + d);
    }
    if (!stateOk) return CallbackResult.fail("sign-in link expired or was not started from this Eclipse window");
    String code = q.getOrDefault("code", "");
    if (code.isEmpty()) return CallbackResult.fail("Microsoft sign-in returned no authorization code");
    return CallbackResult.ok(code);
  }

  public StoredToken exchangeCode(EntraConfig c, String code, String redirectUri, String verifier) throws IOException {
    Map<String, String> form = new LinkedHashMap<>();
    form.put("client_id", c.clientId());
    form.put("grant_type", "authorization_code");
    form.put("code", code);
    form.put("redirect_uri", redirectUri);
    form.put("code_verifier", verifier);
    form.put("scope", scopes(c));
    return post(c, form, null);
  }

  public StoredToken refresh(EntraConfig c, StoredToken current) throws IOException {
    Map<String, String> form = new LinkedHashMap<>();
    form.put("client_id", c.clientId());
    form.put("grant_type", "refresh_token");
    form.put("refresh_token", current.refreshToken());
    form.put("scope", scopes(c));
    return post(c, form, current);
  }

  private StoredToken post(EntraConfig c, Map<String, String> form, StoredToken previous) throws IOException {
    HttpRequest req = HttpRequest.newBuilder(URI.create(endpoint(c, "token")))
        .timeout(Duration.ofSeconds(20))
        .header("content-type", "application/x-www-form-urlencoded")
        .header("accept", "application/json")
        .POST(HttpRequest.BodyPublishers.ofString(Query.encode(form), StandardCharsets.UTF_8))
        .build();
    HttpResponse<String> res;
    try {
      res = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IOException("cancelled");
    }
    return parseTokenResponse(res.statusCode(), res.body(), previous, nowSec.getAsLong());
  }

  static StoredToken parseTokenResponse(int status, String body, StoredToken previous, long now) throws IOException {
    Map<String, Object> m = Json.parseObject(body);
    if (status / 100 != 2 || m == null) {
      String err = m == null ? null : Json.str(m, "error_description");
      if (err == null && m != null) err = Json.str(m, "error");
      // Never echo the response body: it could contain tokens.
      throw new IOException("token request failed (HTTP " + status + ")" + (err != null ? ": " + firstLine(err) : ""));
    }
    String access = Json.str(m, "access_token");
    if (access == null || access.isEmpty()) throw new IOException("token response has no access_token");
    long expiresIn = (long) Json.num(m, "expires_in");
    if (expiresIn <= 0) expiresIn = 3600;
    String refresh = Json.str(m, "refresh_token");
    if (refresh == null && previous != null) refresh = previous.refreshToken();
    String account = accountFromIdToken(Json.str(m, "id_token"));
    if (account == null && previous != null) account = previous.account();
    return new StoredToken(access, refresh, now + expiresIn, account);
  }

  private static String firstLine(String s) {
    int nl = s.indexOf('\n');
    String l = nl < 0 ? s : s.substring(0, nl);
    return l.length() > 200 ? l.substring(0, 200) : l;
  }

  /** Display-only account name from an (unverified) ID token payload. */
  static String accountFromIdToken(String idToken) {
    if (idToken == null) return null;
    String[] parts = idToken.split("\\.");
    if (parts.length < 2) return null;
    try {
      String json = new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
      Map<String, Object> claims = Json.parseObject(json);
      for (String k : new String[] {"preferred_username", "email", "upn", "name"}) {
        String v = Json.str(claims, k);
        if (v != null && !v.isEmpty()) return v;
      }
    } catch (IllegalArgumentException e) {
      return null;
    }
    return null;
  }
}
