package com.aig.ai.ecosystem.core.invoke;

import java.util.ArrayList;
import java.util.List;

/** A cancel signal shared between the UI and a blocking call. Callbacks run once, on the cancelling thread. */
public final class Cancellation {
  private final List<Runnable> callbacks = new ArrayList<>();
  private boolean cancelled;

  public void cancel() {
    List<Runnable> run;
    synchronized (this) {
      if (cancelled) return;
      cancelled = true;
      run = new ArrayList<>(callbacks);
      callbacks.clear();
    }
    for (Runnable r : run) {
      try {
        r.run();
      } catch (RuntimeException e) {
        // best effort (e.g. closing a stream that is already closed)
      }
    }
  }

  public synchronized boolean isCancelled() {
    return cancelled;
  }

  /** Registers a callback; runs it immediately when already cancelled. */
  public void onCancel(Runnable r) {
    synchronized (this) {
      if (!cancelled) {
        callbacks.add(r);
        return;
      }
    }
    r.run();
  }
}
