package com.aig.ai.ecosystem.core.auth;

import com.aig.ai.ecosystem.core.config.ConfigResolver;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Local-environment browser sign-in (no SSO). The plugin listens on an ephemeral loopback port and
 * opens {@code <backend>/auth/local/signin?redirect_uri=http://127.0.0.1:<port>/auth/callback&state=<nonce>}.
 * After the user submits the form, the browser is sent to the loopback callback with
 * {@code email} and {@code state}; the email is accepted only if the state is one this plugin issued
 * in the last 10 minutes. The resulting {@code dev:<email>} token works only on a backend running
 * {@code AIG_ENV=local} with {@code AIG_AUTH_MODE=dev}.
 */
public final class LocalSignIn {
  public static final String CALLBACK_PATH = "/auth/callback";
  /** Email accepted by the local dev sign-in (SIGN_IN_EMAIL_RE in web/packages/ui messages.ts, the portal's LocalAuthenticator). */
  public static final Pattern SIGN_IN_EMAIL = Pattern.compile("^[^\\s@]{1,64}@[^\\s@]{1,190}\\.[A-Za-z]{2,24}$", Pattern.UNICODE_CHARACTER_CLASS);
  public static final int MAX_EMAIL = 254;

  private LocalSignIn() {}

  /**
   * Trimmed, lower-cased email when valid for the local dev sign-in, null otherwise (port of
   * {@code normalizeSignInEmail} in messages.ts).
   */
  public static String normalizeEmail(Object v) {
    if (!(v instanceof String) || ((String) v).length() > MAX_EMAIL + 16) return null;
    String e = ((String) v).strip().toLowerCase(Locale.ROOT);
    return e.length() <= MAX_EMAIL && SIGN_IN_EMAIL.matcher(e).matches() ? e : null;
  }

  public static String buildSignInUrl(String backendUrl, String redirectUri, String state, String loginHint) {
    Map<String, String> q = new LinkedHashMap<>();
    q.put("redirect_uri", redirectUri);
    q.put("state", state);
    if (loginHint != null && ConfigResolver.isValidEmail(loginHint)) q.put("login_hint", loginHint);
    return backendUrl + "/auth/local/signin?" + Query.encode(q);
  }

  /** Validates the callback request against the pending states; returns the signed-in email. */
  public static CallbackResult handleCallback(String path, String query, PendingStates pending) {
    if (!CALLBACK_PATH.equals(path)) return CallbackResult.fail("unknown callback path " + path);
    Map<String, String> q = Query.parse(query);
    String state = q.getOrDefault("state", "");
    String email = q.getOrDefault("email", "").trim();
    if (state.isEmpty() || !pending.consume(state)) return CallbackResult.fail("sign-in link expired or was not started from this Eclipse window");
    if (!ConfigResolver.isValidEmail(email)) return CallbackResult.fail("sign-in returned an invalid email");
    return CallbackResult.ok(email);
  }
}
