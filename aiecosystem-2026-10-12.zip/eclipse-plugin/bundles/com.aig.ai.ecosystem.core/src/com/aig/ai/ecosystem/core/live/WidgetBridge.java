package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.ws.AigSocket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Connects one embedded widget (sidebar, dashboard or sign-in) to the {@link LiveService}: the
 * {@code WidgetHost} contract seen from the Java side. Widget messages arrive as JSON text (from the
 * SWT BrowserFunction) and are validated with {@link WebviewMessage#parse}; host messages go out via
 * {@code send} (browser.execute in the plugin). No Eclipse API, so it is unit tested headless.
 */
public final class WidgetBridge {
  /** Host commands a widget can trigger. */
  public interface Commands {
    void run(String cmd);

    /** Sign in as {@code email} (validated; local environment only). Hosts that cannot do it fall back to {@code signIn}. */
    default void signIn(String email) {
      run("signIn");
    }
  }

  private final LiveService live;
  private final Consumer<String> send;
  private final Commands commands;
  private final Consumer<String> listener;
  private final AgentBridge agents;
  /** localId (widget) to server chat id. */
  private final Map<String, String> active = new ConcurrentHashMap<>();
  private volatile boolean disposed;

  public WidgetBridge(LiveService live, Consumer<String> send, Commands commands) {
    this(live, send, commands, null);
  }

  /** With {@code agents}, the catalog / run widget messages ({@link AgentMessage}) are handled too. */
  public WidgetBridge(LiveService live, Consumer<String> send, Commands commands, AgentBridge agents) {
    this.live = live;
    this.agents = agents;
    this.send = send;
    this.commands = commands;
    this.listener = m -> {
      if (!disposed) send.accept(m);
    };
    live.addListener(listener);
  }

  /** Handles one raw message posted by the widget. Returns false when it was rejected. */
  public boolean receive(String raw) {
    if (disposed) return false;
    WebviewMessage m = WebviewMessage.parse(raw);
    if (m == null) return agents != null && agents.receive(AgentMessage.parse(raw));
    switch (m.cmd()) {
      case "ready":
        onReady();
        break;
      case "range":
        live.setRange(m.days());
        break;
      case "refresh":
        live.refreshUsage();
        break;
      case "signIn":
        if (m.email() != null) commands.signIn(m.email());
        else commands.run(m.cmd());
        break;
      case "openDashboard":
      case "openPanel":
      case "signOut":
      case "selectEnvironment":
        commands.run(m.cmd());
        break;
      case "chat.cancel": {
        String id = active.get(m.localId());
        if (id != null) live.cancel(id);
        break;
      }
      case "chat.send":
        chat(m);
        break;
      default:
        return false;
    }
    return true;
  }

  /** Replays the current state (also called by the host when a page finishes loading). */
  public void onReady() {
    for (String s : live.snapshot()) send.accept(s);
    live.ensureUsage(); // first view with nothing loaded: one request (never a refetch)
    if (agents != null) agents.onReady();
    commands.run("ready");
  }

  private void chat(WebviewMessage m) {
    String localId = m.localId();
    try {
      String id = live.chat(m.messages(), m.jobProfile(), new AigSocket.ChatHandlers() {
        @Override
        public void onDelta(String text) {
          send.accept(HostMessages.chatDelta(localId, text));
        }

        @Override
        public void onDone(String traceId, Map<String, Object> usage, String model, Map<String, Object> route) {
          active.remove(localId);
          send.accept(HostMessages.chatDone(localId, usage, traceId, model, route));
        }

        @Override
        public void onError(String code, String message) {
          active.remove(localId);
          send.accept(HostMessages.chatError(localId, code, message));
        }
      });
      active.put(localId, id);
    } catch (RuntimeException e) {
      send.accept(HostMessages.chatError(localId, "not_connected", e.getMessage() == null ? "not connected" : e.getMessage()));
    }
  }

  public void dispose() {
    disposed = true;
    live.removeListener(listener);
    if (agents != null) agents.dispose();
    active.values().forEach(live::cancel);
    active.clear();
  }
}
