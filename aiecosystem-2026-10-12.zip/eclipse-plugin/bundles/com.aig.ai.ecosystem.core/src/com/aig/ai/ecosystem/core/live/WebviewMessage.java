package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.auth.LocalSignIn;
import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * A validated widget to host message (web/packages/ui src/messages.ts {@code WebviewMessage}). Widget
 * messages are untrusted input: {@link #parse(String)} applies the same rules as the TypeScript
 * {@code parseWebviewMessage}.
 */
public record WebviewMessage(String cmd, int days, String localId, List<ChatMessage> messages, String jobProfile, String email) {
  static final Pattern LOCAL_ID = Pattern.compile("^[A-Za-z0-9_-]{1,64}$");
  static final int MAX_MESSAGES = 50;
  static final int MAX_CONTENT = 32_000;
  static final int MAX_RAW = 2 * 1024 * 1024;
  private static final Set<String> SIMPLE = Set.of("ready", "refresh", "openDashboard", "openPanel", "signOut", "selectEnvironment");

  private static WebviewMessage simple(String cmd) {
    return new WebviewMessage(cmd, 0, null, null, null, null);
  }

  /** Trimmed, lower-cased email when valid for the local dev sign-in, null otherwise ({@code normalizeSignInEmail}). */
  public static String normalizeSignInEmail(Object v) {
    return LocalSignIn.normalizeEmail(v);
  }

  /** Returns null for anything malformed or unknown. */
  public static WebviewMessage parse(String raw) {
    if (raw == null || raw.length() > MAX_RAW) return null;
    Map<String, Object> o = Json.parseObject(raw);
    if (o == null) return null;
    String cmd = Json.str(o, "cmd");
    if (cmd == null) return null;
    if (SIMPLE.contains(cmd)) return simple(cmd);
    switch (cmd) {
      case "signIn": {
        // Without an email: the configured sign-in flow. With one (local only): it must be a valid email.
        if (!o.containsKey("email")) return simple(cmd);
        String email = normalizeSignInEmail(o.get("email"));
        return email == null ? null : new WebviewMessage(cmd, 0, null, null, null, email);
      }
      case "range": {
        Object d = o.get("days");
        if (!(d instanceof Long)) return null;
        long days = (Long) d;
        return days == 7 || days == 30 || days == 90 ? new WebviewMessage(cmd, (int) days, null, null, null, null) : null;
      }
      case "chat.cancel": {
        String id = Json.str(o, "localId");
        return id != null && LOCAL_ID.matcher(id).matches() ? new WebviewMessage(cmd, 0, id, null, null, null) : null;
      }
      case "chat.send": {
        String id = Json.str(o, "localId");
        String job = Json.str(o, "jobProfile");
        List<Object> raws = Json.list(o, "messages");
        if (id == null || !LOCAL_ID.matcher(id).matches() || job == null) return null;
        if (raws == null || raws.isEmpty() || raws.size() > MAX_MESSAGES) return null;
        List<ChatMessage> msgs = new ArrayList<>();
        for (Object x : raws) {
          Map<String, Object> r = Json.asObject(x);
          String role = Json.str(r, "role");
          String content = Json.str(r, "content");
          if (r == null || (!"user".equals(role) && !"assistant".equals(role)) || content == null || content.length() > MAX_CONTENT) return null;
          msgs.add(new ChatMessage(role, content));
        }
        if (!"user".equals(msgs.get(msgs.size() - 1).role())) return null;
        return new WebviewMessage(cmd, 0, id, List.copyOf(msgs), job, null);
      }
      default:
        return null;
    }
  }
}
