package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.ws.LiveStatus;
import java.util.List;
import java.util.Map;

/** Builders for host to widget messages (web/packages/ui src/messages.ts {@code HostMessage}), as JSON text. */
public final class HostMessages {
  private HostMessages() {}

  /** web/packages/ui {@code InitInfo}. Optional fields may be null. */
  public record InitInfo(String env, String user, String tier, String costMode, String team, String jobProfile, List<String> jobProfiles, int range) {}

  public static String init(InitInfo i) {
    Json.Obj info = Json.object().put("env", i.env()).opt("user", i.user()).opt("tier", i.tier()).opt("costMode", i.costMode()).opt("team", i.team())
        .put("jobProfile", i.jobProfile()).put("jobProfiles", i.jobProfiles()).put("range", i.range());
    return Json.object().put("type", "init").put("info", info.map()).toString();
  }

  public static String live(LiveStatus status, String detail) {
    return Json.object().put("type", "live").put("status", status.id()).opt("detail", detail).toString();
  }

  public static String usageLoading() {
    return Json.object().put("type", "usage.loading").toString();
  }

  /** {@code data} is the dashboard body; the browser shim normalises it with web/packages/ui parseDashboard. */
  public static String usage(int range, Map<String, Object> data) {
    return Json.object().put("type", "usage").put("range", range).put("data", data).toString();
  }

  public static String usageError(String code, String message) {
    return Json.object().put("type", "usage.error").put("code", code).put("message", message).toString();
  }

  /** {@code data}: the {@code GET /api/v1/usage/limits} body as is (web/packages/ui {@code UsageLimits}). */
  public static String usageLimits(Map<String, Object> data) {
    return Json.object().put("type", "usage.limits").put("data", data).toString();
  }

  public static String usageLimitsError(String code, String message) {
    return Json.object().put("type", "usage.limits.error").put("code", code).put("message", message).toString();
  }

  public static String chatDelta(String localId, String text) {
    return Json.object().put("type", "chat.delta").put("localId", localId).put("text", text).toString();
  }

  /** {@code model} / {@code route} (web/packages/ui {@code ChatRoute}) are omitted when null. */
  public static String chatDone(String localId, Map<String, Object> usage, String traceId, String model, Map<String, Object> route) {
    return Json.object().put("type", "chat.done").put("localId", localId).opt("usage", usage).opt("traceId", traceId).opt("model", model).opt("route", route)
        .toString();
  }

  public static String chatError(String localId, String code, String message) {
    return Json.object().put("type", "chat.error").put("localId", localId).put("code", code).put("message", message).toString();
  }

  public static String tab(String tab) {
    if (!"usage".equals(tab) && !"chat".equals(tab) && !"agents".equals(tab)) throw new IllegalArgumentException("tab");
    return Json.object().put("type", "tab").put("tab", tab).toString();
  }

  /** Sign-in card status: tone ok|warn|bad; method browser|microsoft|devUser|unconfigured. */
  public static String status(String env, String tone, String label, String detail, String method) {
    return status(env, tone, label, detail, method, null);
  }

  /** {@code user}: last local sign-in email, prefills the email field (method browser only; null = omitted). */
  public static String status(String env, String tone, String label, String detail, String method, String user) {
    return Json.object().put("type", "status").put("env", env).put("tone", tone).put("label", label).put("detail", detail).put("method", method)
        .opt("user", user).toString();
  }

  // ---------- agents (catalog + run widgets) ----------

  public static String catalogLoading() {
    return Json.object().put("type", "catalog.loading").toString();
  }

  public static String catalogError(String code, String message) {
    return Json.object().put("type", "catalog.error").put("code", code).put("message", message).toString();
  }

  /** {@code runs}: web/packages/ui {@code RecentRun} objects. */
  public static String agentRuns(List<Map<String, Object>> runs) {
    return Json.object().put("type", "agent.runs").put("runs", runs).toString();
  }

  /** {@code target}: web/packages/ui {@code AgentRunTarget}. */
  public static String agentTarget(Map<String, Object> target) {
    return Json.object().put("type", "agent.target").put("target", target).toString();
  }

  public static String agentTargetError(String code, String message) {
    return Json.object().put("type", "agent.target.error").put("code", code).put("message", message).toString();
  }

  /** {@code agent.status}; every argument after {@code status} is optional (null = omitted). */
  public static String agentStatus(String localId, String status, String invocationId, String traceId, Long durationMs, Map<String, Object> usage,
      String errorCode, String version, String env) {
    return Json.object().put("type", "agent.status").put("localId", localId).put("status", status).opt("invocationId", invocationId).opt("traceId", traceId)
        .opt("durationMs", durationMs).opt("usage", usage).opt("errorCode", errorCode).opt("version", version).opt("env", env).toString();
  }

  public static String agentDelta(String localId, String text) {
    return Json.object().put("type", "agent.delta").put("localId", localId).put("text", text).toString();
  }

  public static String agentOutput(String localId, Object output, Map<String, Object> usage, String traceId) {
    return Json.object().put("type", "agent.output").put("localId", localId).put("output", output).opt("usage", usage).opt("traceId", traceId).toString();
  }

  public static String agentDone(String localId, String status, Long durationMs, String traceId, Map<String, Object> usage, String invocationId) {
    return Json.object().put("type", "agent.done").put("localId", localId).put("status", status).opt("durationMs", durationMs).opt("traceId", traceId)
        .opt("usage", usage).opt("invocationId", invocationId).toString();
  }

  public static String agentError(String localId, String code, String message, String invocationId) {
    return Json.object().put("type", "agent.error").put("localId", localId).put("code", code).put("message", message).opt("invocationId", invocationId)
        .toString();
  }
}
