package com.aig.ai.ecosystem.core.agents;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/** A starter template (templates/&lt;name&gt;/aig-template.json). */
public record Template(String name, Path path, String description, String language, Map<String, String> placeholders, List<String> exclude) {
  @Override
  public String toString() {
    return name + (description.isEmpty() ? "" : " - " + description);
  }
}
