package com.aig.ai.ecosystem.core.ws;

import java.util.Map;

/**
 * One parsed server frame. Only the fields relevant to {@code type} are set:
 * <ul>
 *   <li>{@code ready}: ready</li>
 *   <li>{@code chat.delta}: id, text</li>
 *   <li>{@code chat.done}: id, traceId, usage (prompt/completion/total tokens, may be null), model (the model the gateway
 *   served, may be null), route ({@code user_tier} + optional {@code cost_mode} / {@code job_profile} / {@code usage_state}, may be null)</li>
 *   <li>{@code chat.error}, {@code usage.error}, {@code error}: code, message (+ id for chat.error)</li>
 *   <li>{@code usage}: days, data (the dashboard body)</li>
 *   <li>{@code ping}, {@code pong}: nothing</li>
 * </ul>
 */
public record ServerFrame(String type, String id, String text, String traceId, Map<String, Object> usage, String code, String message,
    int days, Map<String, Object> data, ReadyInfo ready, String model, Map<String, Object> route) {

  static ServerFrame of(String type) {
    return new ServerFrame(type, null, null, null, null, null, null, 0, null, null, null, null);
  }
}
