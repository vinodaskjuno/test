package com.aig.ai.ecosystem.core.auth;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;

/**
 * RFC 8252 loopback redirect receiver: a one-shot HTTP listener on {@code 127.0.0.1:<ephemeral port>}.
 * It answers only {@code GET <path>}; anything else gets 404 and is ignored. The first request on the
 * expected path completes {@link #result()} with whatever the validator returns, and the listener
 * closes. Bound to the IPv4 loopback literal only, never to all interfaces.
 */
public final class LoopbackReceiver implements AutoCloseable {
  private static final int MAX_HEADER_BYTES = 16 * 1024;

  private final ServerSocket server;
  private final String path;
  private final BiFunction<String, String, CallbackResult> validator;
  private final CompletableFuture<CallbackResult> result = new CompletableFuture<>();
  private final Thread thread;

  /**
   * @param path expected callback path, e.g. {@code /callback} or {@code /auth/callback}
   * @param validator (path, rawQuery) to result; called once for the expected path
   */
  public LoopbackReceiver(String path, BiFunction<String, String, CallbackResult> validator) throws IOException {
    this.path = path;
    this.validator = validator;
    this.server = new ServerSocket();
    server.bind(new InetSocketAddress(InetAddress.getByAddress(new byte[] {127, 0, 0, 1}), 0), 8);
    this.thread = new Thread(this::loop, "aig-loopback-" + server.getLocalPort());
    thread.setDaemon(true);
    thread.start();
  }

  public int port() {
    return server.getLocalPort();
  }

  /** {@code http://127.0.0.1:<port><path>} */
  public String redirectUri() {
    return "http://127.0.0.1:" + port() + path;
  }

  public CompletableFuture<CallbackResult> result() {
    return result;
  }

  /** Waits for the callback; closes the listener afterwards. */
  public CallbackResult await(Duration timeout) throws Exception {
    try {
      return result.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
    } finally {
      close();
    }
  }

  @Override
  public void close() {
    try {
      server.close();
    } catch (IOException ignored) {
      // closing
    }
    result.complete(CallbackResult.fail("sign-in was cancelled"));
  }

  private void loop() {
    while (!server.isClosed() && !result.isDone()) {
      try (Socket s = server.accept()) {
        s.setSoTimeout(5000);
        handle(s);
      } catch (SocketTimeoutException e) {
        // slow client; keep listening
      } catch (IOException e) {
        if (server.isClosed()) return;
      }
    }
    try {
      server.close();
    } catch (IOException ignored) {
      // closing
    }
  }

  private void handle(Socket s) throws IOException {
    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.ISO_8859_1));
    String requestLine = in.readLine();
    int total = requestLine == null ? 0 : requestLine.length();
    String line;
    while ((line = in.readLine()) != null && !line.isEmpty()) {
      total += line.length();
      if (total > MAX_HEADER_BYTES) break;
    }
    OutputStream out = s.getOutputStream();
    if (requestLine == null) return;
    String[] parts = requestLine.split(" ");
    if (parts.length < 2 || !parts[0].equals("GET")) {
      respond(out, 405, "Method not allowed", false);
      return;
    }
    String target = parts[1];
    int q = target.indexOf('?');
    String p = q < 0 ? target : target.substring(0, q);
    String query = q < 0 ? "" : target.substring(q + 1);
    if (!p.equals(path)) {
      respond(out, 404, "Not found", false);
      return;
    }
    CallbackResult r;
    try {
      r = validator.apply(p, query);
    } catch (RuntimeException e) {
      r = CallbackResult.fail(e.getMessage() == null ? "sign-in failed" : e.getMessage());
    }
    respond(out, r.ok() ? 200 : 400, r.ok() ? "You are signed in to AIG. You can close this tab and return to Eclipse." : "Sign-in failed: " + r.reason(), r.ok());
    result.complete(r);
  }

  static String page(String message, boolean ok) {
    String msg = message.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    return "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>AIG sign-in</title>"
        + "<style>body{margin:0;font-family:Arial,sans-serif;background:#f5f7f9;color:#343741}"
        + "header{background:#001871;color:#fff;padding:14px 24px;font-weight:700;letter-spacing:.08em}"
        + "main{max-width:480px;margin:48px auto;background:#fff;border:1px solid #dcdcdc;padding:24px}"
        + ".bad{color:#e03c31}</style></head><body><header>AIG &middot; AI Ecosystem</header><main><p"
        + (ok ? "" : " class=\"bad\"") + ">" + msg + "</p></main></body></html>";
  }

  private static void respond(OutputStream out, int status, String message, boolean ok) throws IOException {
    byte[] body = page(message, ok).getBytes(StandardCharsets.UTF_8);
    String reason = status == 200 ? "OK" : status == 404 ? "Not Found" : status == 405 ? "Method Not Allowed" : "Bad Request";
    String head = "HTTP/1.1 " + status + " " + reason + "\r\n"
        + "Content-Type: text/html; charset=utf-8\r\n"
        + "Content-Length: " + body.length + "\r\n"
        + "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'\r\n"
        + "Cache-Control: no-store\r\n"
        + "Referrer-Policy: no-referrer\r\n"
        + "Connection: close\r\n\r\n";
    out.write(head.getBytes(StandardCharsets.ISO_8859_1));
    out.write(body);
    out.flush();
  }
}
