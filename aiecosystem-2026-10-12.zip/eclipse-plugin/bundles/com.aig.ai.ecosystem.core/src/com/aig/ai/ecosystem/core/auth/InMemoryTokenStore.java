package com.aig.ai.ecosystem.core.auth;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import java.util.EnumMap;
import java.util.Map;

/** Non-persistent {@link TokenStore} (tests, or when secure storage is unavailable). */
public final class InMemoryTokenStore implements TokenStore {
  private final Map<AigEnvironment, StoredToken> tokens = new EnumMap<>(AigEnvironment.class);

  @Override
  public synchronized StoredToken load(AigEnvironment env) {
    return tokens.get(env);
  }

  @Override
  public synchronized void save(AigEnvironment env, StoredToken token) {
    tokens.put(env, token);
  }

  @Override
  public synchronized void clear(AigEnvironment env) {
    tokens.remove(env);
  }
}
