package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** {@code POST /api/v1/agents/{id}/versions/{v}/verify}: health, invocation, gateway and trace checks. */
public record VerifyResult(boolean passed, String code, List<Check> checks, String invocationId, String traceId, boolean activated) {
  public record Check(String name, String status, String detail) {}

  public static VerifyResult from(Map<String, Object> body) {
    List<Check> checks = new ArrayList<>();
    List<Object> raw = Json.list(body, "checks");
    if (raw != null) {
      for (Object o : raw) {
        Map<String, Object> c = Json.asObject(o);
        if (c == null || Json.str(c, "name") == null) continue;
        String status = Json.str(c, "status");
        String detail = Json.str(c, "detail");
        checks.add(new Check(Json.str(c, "name"), status == null ? "skipped" : status, detail == null ? "" : detail));
      }
    }
    return new VerifyResult(Boolean.TRUE.equals(body.get("passed")), Json.str(body, "code"), List.copyOf(checks), Json.str(body, "invocation_id"),
        Json.str(body, "trace_id"), Boolean.TRUE.equals(body.get("activated")));
  }

  /** Multi-line summary for a dialog. */
  public String summary() {
    StringBuilder sb = new StringBuilder(passed ? "Verification passed" : "Verification failed" + (code != null ? " (" + code + ")" : ""));
    if (activated) sb.append("; the agent is now active");
    sb.append('.');
    for (Check c : checks) sb.append("\n  ").append(c.status().equals("passed") ? "[ok]   " : c.status().equals("failed") ? "[fail] " : "[skip] ")
        .append(c.name()).append(c.detail().isEmpty() ? "" : ": " + c.detail());
    if (traceId != null) sb.append("\nTrace: ").append(traceId);
    return sb.toString();
  }
}
