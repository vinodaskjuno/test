package com.aig.ai.ecosystem.core.auth;

/** No usable session for the selected environment. */
public final class NotSignedInException extends Exception {
  private static final long serialVersionUID = 1L;

  public NotSignedInException(String message) {
    super(message);
  }
}
