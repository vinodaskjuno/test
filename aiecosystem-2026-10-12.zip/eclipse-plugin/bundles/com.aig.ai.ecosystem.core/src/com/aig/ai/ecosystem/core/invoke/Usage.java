package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.Map;

/** Token usage: only the integer prompt/completion/total counts are kept (other fields are dropped). */
public final class Usage {
  private Usage() {}

  /** web/packages/ui {@code ChatUsage}, or null when there is no usable usage object. */
  public static Map<String, Object> clean(Object raw) {
    Map<String, Object> u = Json.asObject(raw);
    if (u == null) return null;
    Json.Obj out = Json.object();
    boolean any = false;
    for (String k : new String[] {"prompt_tokens", "completion_tokens", "total_tokens"}) {
      Object v = u.get(k);
      if (v instanceof Long && (Long) v >= 0) {
        out.put(k, v);
        any = true;
      } else {
        out.put(k, 0L);
      }
    }
    return any ? out.map() : null;
  }
}
