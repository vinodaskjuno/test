/** AIG core: agent catalog, registration, invocation (platform-api registry v2 + aig-http/1 invoke API). */
package com.aig.ai.ecosystem.core.invoke;
