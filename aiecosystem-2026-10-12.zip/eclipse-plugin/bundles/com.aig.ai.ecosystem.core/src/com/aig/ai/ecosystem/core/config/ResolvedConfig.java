package com.aig.ai.ecosystem.core.config;

import java.util.List;

/**
 * Validated settings for the selected environment.
 *
 * @param backendUrl normalised backend URL, or {@code null} when not configured
 * @param configured true only when the backend URL and a sign-in method are usable
 */
public record ResolvedConfig(AigEnvironment env, String backendUrl, boolean configured, AuthPlan auth, String jobProfile, List<String> problems) {
  public String notConfiguredMessage() {
    return "AIG backend not configured for " + env.id();
  }
}
