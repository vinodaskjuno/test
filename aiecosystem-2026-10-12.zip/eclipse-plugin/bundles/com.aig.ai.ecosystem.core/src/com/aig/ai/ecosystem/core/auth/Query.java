package com.aig.ai.ecosystem.core.auth;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** application/x-www-form-urlencoded helpers. */
public final class Query {
  private Query() {}

  /** Parses a query string; the first value of a repeated key wins. */
  public static Map<String, String> parse(String query) {
    Map<String, String> out = new LinkedHashMap<>();
    if (query == null || query.isEmpty()) return out;
    for (String pair : query.split("&")) {
      if (pair.isEmpty()) continue;
      int eq = pair.indexOf('=');
      String k = decode(eq < 0 ? pair : pair.substring(0, eq));
      String v = eq < 0 ? "" : decode(pair.substring(eq + 1));
      out.putIfAbsent(k, v);
    }
    return out;
  }

  public static String encode(Map<String, String> params) {
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, String> e : params.entrySet()) {
      if (sb.length() > 0) sb.append('&');
      sb.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
    }
    return sb.toString();
  }

  public static String enc(String s) {
    return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
  }

  private static String decode(String s) {
    try {
      return URLDecoder.decode(s, StandardCharsets.UTF_8);
    } catch (IllegalArgumentException e) {
      return "";
    }
  }
}
