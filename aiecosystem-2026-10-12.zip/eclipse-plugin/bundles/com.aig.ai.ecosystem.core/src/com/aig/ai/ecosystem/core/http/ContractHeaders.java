package com.aig.ai.ecosystem.core.http;

import com.aig.ai.ecosystem.core.config.JobProfiles;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Request headers for platform-api (backend/contracts/headers.md section 2). The plugin sends only its own
 * bearer token plus the {@code x-aig-*} routing hints. It never sends {@code x-portkey-*}: the
 * backend adds the gateway key, config and metadata server-side.
 */
public final class ContractHeaders {
  public static final Pattern AGENT_ID = Pattern.compile("^[A-Za-z0-9._-]{1,64}$");
  /** backend/contracts/scripts/reference.py TRACE_ID_RE. */
  public static final Pattern TRACE_ID = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$");
  public static final Pattern UUID_V4 = Pattern.compile("^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$");
  /** The plugin's pre-registered agent in platform-api (agents.py DEFAULT_AGENT_BY_HOST). */
  public static final String ECLIPSE_AGENT_ID = "ide.eclipse";

  public static final String JOB_PROFILE = "x-aig-job-profile";
  public static final String TRACE = "x-aig-trace-id";
  public static final String AGENT = "x-aig-agent-id";

  private ContractHeaders() {}

  public static String newTraceId() {
    return UUID.randomUUID().toString();
  }

  /**
   * The contract part (fixtures {@code kind: backend_client}): {@code x-aig-job-profile} (default
   * general), {@code x-aig-trace-id} (explicit when valid, else a new UUID v4) and
   * {@code x-aig-agent-id} only when given. Order matches the fixtures.
   *
   * @throws ContractException {@code AIG_E_METADATA_INVALID} for a bad job profile or agent id
   */
  public static Map<String, String> backendHeaders(String jobProfile, String agentId, String traceId) {
    String job = jobProfile == null || jobProfile.isEmpty() ? JobProfiles.DEFAULT : jobProfile;
    if (!JobProfiles.isValid(job)) throw new ContractException(ContractException.METADATA_INVALID, "job_profile");
    Map<String, String> h = new LinkedHashMap<>();
    h.put(JOB_PROFILE, job);
    h.put(TRACE, traceId != null && TRACE_ID.matcher(traceId).matches() ? traceId : newTraceId());
    if (agentId != null) {
      if (!AGENT_ID.matcher(agentId).matches()) throw new ContractException(ContractException.METADATA_INVALID, "agent_id");
      h.put(AGENT, agentId);
    }
    return h;
  }

  public static String bearer(String token) {
    if (token == null || token.isEmpty() || token.indexOf('\r') >= 0 || token.indexOf('\n') >= 0) {
      throw new IllegalArgumentException("invalid auth token");
    }
    return "Bearer " + token;
  }

  public static String devToken(String email) {
    return "dev:" + email;
  }

  public static Map<String, String> authHeaders(String token) {
    Map<String, String> h = new LinkedHashMap<>();
    h.put("authorization", bearer(token));
    h.put("accept", "application/json");
    return h;
  }

  /** Full header set for {@code POST /api/v1/llm/chat/completions}. */
  public static Map<String, String> chatHeaders(String token, String jobProfile, String agentId, String traceId, boolean stream) {
    Map<String, String> h = new LinkedHashMap<>();
    h.put("authorization", bearer(token));
    h.put("content-type", "application/json");
    h.put("accept", stream ? "text/event-stream" : "application/json");
    h.putAll(backendHeaders(jobProfile, agentId, traceId));
    return h;
  }
}
