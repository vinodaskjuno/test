package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** {@code GET /api/v1/catalog}: the agents the caller may run, plus the team and tag filter values. */
public record Catalog(List<CatalogAgent> items, List<String> teams, List<String> tags) {
  public static Catalog from(Map<String, Object> body) {
    List<CatalogAgent> items = new ArrayList<>();
    List<Object> raw = Json.list(body, "items");
    if (raw != null) {
      for (Object o : raw) {
        CatalogAgent a = CatalogAgent.from(o);
        if (a != null) items.add(a);
      }
    }
    List<String> teams = Json.strings(body.get("teams"));
    List<String> tags = Json.strings(body.get("tags"));
    if (body.get("teams") == null) {
      TreeSet<String> t = new TreeSet<>();
      for (CatalogAgent a : items) if (!a.team().isEmpty()) t.add(a.team());
      teams = new ArrayList<>(t);
    }
    if (body.get("tags") == null) {
      TreeSet<String> t = new TreeSet<>();
      for (CatalogAgent a : items) t.addAll(a.tags());
      tags = new ArrayList<>(t);
    }
    return new Catalog(List.copyOf(items), List.copyOf(teams), List.copyOf(tags));
  }

  public CatalogAgent find(String agentId) {
    for (CatalogAgent a : items) if (a.agentId().equals(agentId)) return a;
    return null;
  }

  /** Host message {@code {type: 'catalog', items, teams, tags}}. */
  public String toHostMessage() {
    List<Object> out = new ArrayList<>();
    for (CatalogAgent a : items) out.add(a.toWidget());
    return Json.object().put("type", "catalog").put("items", out).put("teams", teams).put("tags", tags).toString();
  }
}
