package com.aig.ai.ecosystem.core.http;

/** One Server-Sent Event. {@code event} and {@code id} may be null. */
public record SseEvent(String event, String data, String id) {
  public boolean isDone() {
    return data.trim().equals("[DONE]");
  }
}
