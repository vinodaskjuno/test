package com.aig.ai.ecosystem.core.http;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.List;
import java.util.Map;

/** OpenAI-compatible chat chunk helpers. */
public final class ChatChunks {
  private ChatChunks() {}

  /** Text delta of a chat.completion.chunk (or the message of a full completion); "" otherwise. */
  public static String deltaText(String data) {
    Map<String, Object> obj = Json.parseObject(data);
    if (obj == null) return "";
    List<Object> choices = Json.list(obj, "choices");
    if (choices == null) return "";
    StringBuilder sb = new StringBuilder();
    for (Object c : choices) {
      Map<String, Object> choice = Json.asObject(c);
      if (choice == null) continue;
      String content = Json.str(Json.obj(choice, "delta"), "content");
      if (content == null) content = Json.str(Json.obj(choice, "message"), "content");
      if (content != null) sb.append(content);
    }
    return sb.toString();
  }

  /** In-stream error message, or null. */
  public static String streamError(String data) {
    Map<String, Object> obj = Json.parseObject(data);
    if (obj == null) return null;
    Object err = obj.get("error");
    if (err == null) return null;
    Map<String, Object> e = Json.asObject(err);
    if (e == null) return String.valueOf(err);
    String m = Json.str(e, "message");
    if (m != null) return m;
    Object code = e.get("code");
    return code != null ? String.valueOf(code) : "stream error";
  }
}
