package com.aig.ai.ecosystem.core.http;

import java.util.ArrayList;
import java.util.List;

/** Incremental Server-Sent Events parser (port of vscode-extension/src/sse.ts). Not thread safe. */
public final class SseParser {
  private final StringBuilder buffer = new StringBuilder();
  private final List<String> dataLines = new ArrayList<>();
  private String eventName;
  private String lastId;

  /** Feeds a decoded text chunk; returns all events completed by it. */
  public List<SseEvent> feed(String chunk) {
    buffer.append(chunk);
    List<SseEvent> out = new ArrayList<>();
    int idx;
    while ((idx = nextLineEnd()) >= 0) {
      String line = buffer.substring(0, idx);
      int skip = buffer.charAt(idx) == '\r' && idx + 1 < buffer.length() && buffer.charAt(idx + 1) == '\n' ? 2 : 1;
      buffer.delete(0, idx + skip);
      if (line.endsWith("\r")) line = line.substring(0, line.length() - 1);
      SseEvent ev = processLine(line);
      if (ev != null) out.add(ev);
    }
    return out;
  }

  /** Flushes a trailing event that was not terminated by a blank line. */
  public List<SseEvent> end() {
    List<SseEvent> out = new ArrayList<>();
    if (buffer.length() > 0) {
      SseEvent ev = processLine(buffer.toString());
      buffer.setLength(0);
      if (ev != null) out.add(ev);
    }
    SseEvent ev = dispatch();
    if (ev != null) out.add(ev);
    return out;
  }

  private int nextLineEnd() {
    int n = buffer.indexOf("\n");
    int r = buffer.indexOf("\r");
    if (r >= 0 && (n < 0 || r < n)) {
      // A lone trailing \r may be the first half of \r\n; wait for more input.
      if (r == buffer.length() - 1) return -1;
      return r;
    }
    return n;
  }

  private SseEvent processLine(String line) {
    if (line.isEmpty()) return dispatch();
    if (line.startsWith(":")) return null;
    int colon = line.indexOf(':');
    String field = colon < 0 ? line : line.substring(0, colon);
    String value = colon < 0 ? "" : line.substring(colon + 1);
    if (value.startsWith(" ")) value = value.substring(1);
    switch (field) {
      case "data": dataLines.add(value); break;
      case "event": eventName = value; break;
      case "id": lastId = value; break;
      default: break;
    }
    return null;
  }

  private SseEvent dispatch() {
    if (dataLines.isEmpty()) {
      eventName = null;
      return null;
    }
    SseEvent ev = new SseEvent(eventName == null || eventName.isEmpty() ? null : eventName, String.join("\n", dataLines), lastId);
    dataLines.clear();
    eventName = null;
    return ev;
  }
}
