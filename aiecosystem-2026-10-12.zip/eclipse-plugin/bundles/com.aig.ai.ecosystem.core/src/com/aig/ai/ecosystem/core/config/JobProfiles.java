package com.aig.ai.ecosystem.core.config;

import java.util.List;

/** Job profiles a client may send as {@code x-aig-job-profile} (backend/contracts/headers.md). */
public final class JobProfiles {
  public static final List<String> ALL = List.of("underwriting", "claims", "operations", "general");
  public static final String DEFAULT = "general";

  private JobProfiles() {}

  public static boolean isValid(String v) {
    return v != null && ALL.contains(v);
  }

  public static String normalize(String v) {
    return isValid(v) ? v : DEFAULT;
  }
}
