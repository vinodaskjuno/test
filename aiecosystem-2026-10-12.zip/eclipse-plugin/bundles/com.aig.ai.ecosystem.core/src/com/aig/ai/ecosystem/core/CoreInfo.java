package com.aig.ai.ecosystem.core;

/**
 * AIG Eclipse plugin core (no UI): configuration and placeholder rules, platform-api REST/SSE and
 * WebSocket clients, contract headers, sign-in (Entra ID PKCE and local browser sign-in) and the
 * widget bridge. Security model: the plugin never holds a Portkey or provider key; model calls go
 * through platform-api, which adds the key server-side.
 */
public final class CoreInfo {
  public static final String BUNDLE_ID = "com.aig.ai.ecosystem.core";
  public static final String USER_AGENT = "aig-eclipse-plugin/0.1.0";

  private CoreInfo() {}
}
