package com.aig.ai.ecosystem.core.http;

/** A client-side contract violation (backend/contracts/errors.md code plus the offending field). */
public final class ContractException extends IllegalArgumentException {
  private static final long serialVersionUID = 1L;
  public static final String METADATA_INVALID = "AIG_E_METADATA_INVALID";

  private final String code;
  private final String field;

  public ContractException(String code, String field) {
    super(code + " (" + field + ")");
    this.code = code;
    this.field = field;
  }

  public String code() {
    return code;
  }

  public String field() {
    return field;
  }
}
