package com.aig.ai.ecosystem.core.invoke;

/** Receives a running invocation stream (called on the thread that runs the blocking invokeStream). */
public interface AgentStreamListener {
  /** The response headers arrived: ids from {@code x-aig-invocation-id} / {@code x-aig-trace-id} (may be null). */
  default void onOpen(String invocationId, String traceId) {}

  void onEvent(AgentEvent event);
}
