package com.aig.ai.ecosystem.core.invoke;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Identifier rules shared with platform-api and web/packages/ui (messages.ts AGENT_ID_RE, AGENT_VERSION_RE,
 * SESSION_ID_RE, INVOCATION_ID_RE) plus URL helpers. Everything that goes into a request path or query is
 * validated first and percent-encoded, never spliced in raw.
 */
public final class AgentIds {
  public static final Pattern AGENT_ID = Pattern.compile("^[A-Za-z0-9._-]{1,64}$");
  public static final Pattern VERSION = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$");
  public static final Pattern SESSION_ID = Pattern.compile("^[A-Za-z0-9._:-]{1,128}$");
  public static final Pattern INVOCATION_ID = Pattern.compile("^[A-Za-z0-9_-]{1,64}$");
  /** platform-api agents.py TAG_RE (max 20 tags). */
  public static final Pattern TAG = Pattern.compile("^[a-z0-9][a-z0-9._-]{0,31}$");
  public static final int MAX_TAGS = 20;
  public static final List<String> ENVS = List.of("local", "dev", "stage", "prod");
  public static final List<String> RUN_STATUSES = List.of("queued", "running", "succeeded", "failed", "cancelled", "timeout");
  public static final List<String> FINAL_STATUSES = List.of("succeeded", "failed", "cancelled", "timeout");

  private AgentIds() {}

  public static boolean agentId(String s) {
    return s != null && AGENT_ID.matcher(s).matches();
  }

  public static boolean version(String s) {
    return s != null && VERSION.matcher(s).matches();
  }

  public static boolean env(String s) {
    return s != null && ENVS.contains(s);
  }

  public static boolean invocationId(String s) {
    return s != null && INVOCATION_ID.matcher(s).matches();
  }

  public static boolean isFinal(String status) {
    return status != null && FINAL_STATUSES.contains(status);
  }

  /** Percent-encodes one path segment or query value (space as %20, never '+'). */
  public static String encode(String s) {
    return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
  }
}
