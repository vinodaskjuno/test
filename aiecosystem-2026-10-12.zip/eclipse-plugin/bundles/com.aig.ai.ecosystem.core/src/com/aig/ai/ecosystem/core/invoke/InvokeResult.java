package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.Map;

/** {@code mode=sync} answer: {@code {invocation_id, agent_id, version, env, status, output, usage, trace_id, duration_ms}}. */
public record InvokeResult(String invocationId, String agentId, String version, String env, String status, Object output, Map<String, Object> usage,
    String traceId, Long durationMs) {
  public static InvokeResult from(Map<String, Object> b) {
    Object d = b.get("duration_ms");
    String status = Json.str(b, "status");
    return new InvokeResult(Json.str(b, "invocation_id"), Json.str(b, "agent_id"), Json.str(b, "version"), Json.str(b, "env"),
        status == null ? "succeeded" : status, b.get("output"), Usage.clean(b.get("usage")), Json.str(b, "trace_id"), d instanceof Long ? (Long) d : null);
  }
}
