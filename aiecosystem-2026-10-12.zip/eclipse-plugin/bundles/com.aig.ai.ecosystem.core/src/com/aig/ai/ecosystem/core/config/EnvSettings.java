package com.aig.ai.ecosystem.core.config;

/**
 * Per-environment connection settings (Eclipse preferences). Every value ships as an obvious
 * placeholder and is filled in by the user or by a product customization (plugin_customization.ini).
 * There is no model-gateway credential here: the plugin holds none.
 *
 * @param backendUrl platform-api base URL
 * @param tenantId Microsoft Entra ID tenant (directory) id, used for dev/stage/prod sign-in
 * @param clientId Entra ID public client (the IDE app registration) used for Authorization Code + PKCE
 * @param scope scope requested for platform-api, e.g. {@code api://<api-client-id>/.default}
 * @param authority Entra authority host, default {@code https://login.microsoftonline.com}
 */
public record EnvSettings(String backendUrl, String tenantId, String clientId, String scope, String authority) {
  public static final String DEFAULT_AUTHORITY = "https://login.microsoftonline.com";

  public static EnvSettings defaults(AigEnvironment env) {
    String e = env.name();
    String backend = env == AigEnvironment.LOCAL ? "http://localhost:8080" : "https://__AIG_BACKEND_URL_" + e + "__";
    return new EnvSettings(
        backend,
        "__AIG_ENTRA_TENANT_ID_" + e + "__",
        "__AIG_ENTRA_IDE_CLIENT_ID_" + e + "__",
        "api://__AIG_API_CLIENT_ID_" + e + "__/.default",
        DEFAULT_AUTHORITY);
  }
}
