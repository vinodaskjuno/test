package com.aig.ai.ecosystem.core.agents;

import com.aig.ai.ecosystem.core.json.Json;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Project environment + SDK install for AIG &gt; New Agent, Update SDK in this project and Install / Update aig CLI.
 * Same plan as {@code aig init --install} (sdk/python aig_sdk/project.py) and the VS Code extension
 * (vscode-extension/src/scaffold/sdkSetup.ts):
 *
 * <pre>
 *   python: &lt;python&gt; -m venv .venv ; .venv/bin/python -m pip install [--index-url U] [--find-links .aig-wheels] -e .[dev]
 *   node:   npm install [--@aig:registry=U]
 * </pre>
 *
 * Sources: {@code registry} (pinned version from the internal index; default, falls back to bundled),
 * {@code bundled} (wheel / tarball shipped in the ui bundle's sdk/ folder, copied to .aig-wheels/),
 * {@code monorepo} (platform development: the repo's sdk/). Pure apart from the small file helpers.
 */
public final class SdkSetup {
  public static final String WHEELS_DIR = ".aig-wheels";
  public static final String PY_SDK = "aig-sdk";
  public static final String TS_SDK = "@aig/sdk";
  public static final String CLI_GUIDANCE = "Python 3.10+ was not found on PATH. Install Python (and optionally pipx), then run AIG > Install / Update aig CLI again, "
      + "or install it yourself: pipx install aig-sdk (from the AIG internal package index).";
  private static final Pattern VERSION = Pattern.compile("^\\d+\\.\\d+\\.\\d+(?:[-.+][0-9A-Za-z.-]+)?$");

  private SdkSetup() {}

  public enum Source {
    REGISTRY, BUNDLED, MONOREPO;

    public String id() {
      return name().toLowerCase(Locale.ROOT);
    }

    public static Source parse(String v) {
      if (v != null) for (Source s : values()) if (s.id().equals(v.trim().toLowerCase(Locale.ROOT))) return s;
      return REGISTRY;
    }
  }

  public enum Language { PYTHON, NODE }

  /** One command (never run through a shell). */
  public record Step(String label, List<String> command, Path cwd) {}

  /** Pins: aig-sdk and @aig/sdk versions this plugin build ships with (sdk/manifest.json). */
  public record Pins(String python, String typescript) {}

  /** Bundled artifacts (file names under the ui bundle's sdk/ folder); null when absent. */
  public record Bundled(String pythonFile, String pythonVersion, String typescriptFile, String typescriptVersion) {
    public boolean has(Language l) {
      return l == Language.PYTHON ? pythonFile != null : typescriptFile != null;
    }
  }

  /** sdk/manifest.json: {"pins": {python, typescript}, "python": {version, file}, "typescript": {version, file}}. */
  public static Pins parsePins(Map<String, Object> manifest) {
    Map<String, Object> p = manifest == null ? null : Json.obj(manifest, "pins");
    if (p == null) return null;
    String py = Json.str(p, "python"), ts = Json.str(p, "typescript");
    return py != null && ts != null && VERSION.matcher(py).matches() && VERSION.matcher(ts).matches() ? new Pins(py, ts) : null;
  }

  public static Bundled parseBundled(Map<String, Object> manifest) {
    String[] out = new String[4];
    if (manifest != null) {
      int i = 0;
      for (String k : List.of("python", "typescript")) {
        Map<String, Object> e = Json.obj(manifest, k);
        String file = e == null ? null : Json.str(e, "file");
        String version = e == null ? null : Json.str(e, "version");
        if (file != null && version != null && !file.contains("/") && !file.contains("\\") && VERSION.matcher(version).matches()) {
          out[i] = file;
          out[i + 1] = version;
        }
        i += 2;
      }
    }
    return new Bundled(out[0], out[1], out[2], out[3]);
  }

  /** URL preferences: empty, "__" placeholders, credentials or non-http(s) mean "not configured" (null). */
  public static String normalizeUrl(String v) {
    if (v == null) return null;
    String s = v.trim();
    if (s.isEmpty() || s.contains("__")) return null;
    try {
      URI u = new URI(s);
      String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
      if (!scheme.equals("https") && !scheme.equals("http")) return null;
      if (u.getHost() == null || u.getRawUserInfo() != null) return null;
      return s;
    } catch (Exception e) {
      return null;
    }
  }

  /** python (pyproject.toml) wins over node (package.json), like aig init. */
  public static Language detect(Predicate<String> exists) {
    if (exists.test("pyproject.toml")) return Language.PYTHON;
    if (exists.test("package.json")) return Language.NODE;
    return null;
  }

  public static Language detect(Path dir) {
    return dir == null ? null : detect(rel -> Files.isRegularFile(dir.resolve(rel)));
  }

  public static Path venvBin(Path dir, String name, boolean windows) {
    return windows ? dir.resolve(".venv").resolve("Scripts").resolve(name + ".exe") : dir.resolve(".venv").resolve("bin").resolve(name);
  }

  public static boolean isWindows() {
    return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
  }

  /** A Python 3.10+ interpreter for venvs: python3.12/3.13/3.11/3.10, python3, python (Windows: py, python). */
  public static Path findPython(Map<String, String> env, boolean windows) {
    List<String> names = windows ? List.of("py", "python", "python3") : List.of("python3.12", "python3.13", "python3.11", "python3.10", "python3", "python");
    for (String n : names) {
      Path p = AigCli.find(n, env);
      if (p != null) return p;
    }
    return null;
  }

  private static List<String> pythonPrefix(Path python) {
    List<String> c = new ArrayList<>(List.of(python.toString()));
    String n = python.getFileName().toString().toLowerCase(Locale.ROOT);
    if (n.equals("py") || n.equals("py.exe")) c.add("-3");
    return c;
  }

  /** Environment + project + SDK install steps (file changes come first, see {@link #fileChanges}). */
  public static List<Step> envSetupSteps(Language lang, Path dest, Source source, Path python, String npm, String indexUrl, String npmRegistry, Path repoRoot,
      boolean windows) {
    List<Step> steps = new ArrayList<>();
    if (lang == Language.PYTHON) {
      List<String> venv = pythonPrefix(python == null ? Path.of(windows ? "python" : "python3") : python);
      venv.addAll(List.of("-m", "venv", ".venv"));
      steps.add(new Step("create .venv", venv, dest));
      String py = venvBin(dest, "python", windows).toString();
      if (source == Source.MONOREPO && repoRoot != null) {
        steps.add(new Step("install the local aig-sdk (monorepo)", List.of(py, "-m", "pip", "install", "-e", repoRoot.resolve("sdk").resolve("python").toString()), dest));
      }
      List<String> pip = new ArrayList<>(List.of(py, "-m", "pip", "install"));
      if (indexUrl != null) pip.addAll(List.of("--index-url", indexUrl));
      if (source == Source.BUNDLED) pip.addAll(List.of("--find-links", WHEELS_DIR));
      pip.addAll(List.of("-e", ".[dev]"));
      steps.add(new Step("install the project and aig-sdk", pip, dest));
      return steps;
    }
    List<String> c = new ArrayList<>(List.of(npm != null ? npm : (windows ? "npm.cmd" : "npm"), "install", "--no-audit", "--no-fund"));
    if (npmRegistry != null) c.add("--@aig:registry=" + npmRegistry);
    steps.add(new Step("npm install (@aig/sdk + dependencies)", c, dest));
    return steps;
  }

  /** A file change a source needs before the install steps: copy, npm dependency spec, or Python pin. */
  public record FileChange(String kind, Path file, Path from, String value) {}

  public static List<FileChange> fileChanges(Language lang, Path dest, Source source, Pins pins, Bundled bundled, Path bundledDir, Path repoRoot) {
    List<FileChange> out = new ArrayList<>();
    if (lang == Language.PYTHON) {
      boolean b = source == Source.BUNDLED && bundled.pythonFile() != null;
      out.add(new FileChange("python-pin", dest.resolve("pyproject.toml"), null, b ? bundled.pythonVersion() : pins.python()));
      if (b) out.add(new FileChange("copy", dest.resolve(WHEELS_DIR).resolve(bundled.pythonFile()), bundledDir.resolve(bundled.pythonFile()), null));
      return out;
    }
    Path pkg = dest.resolve("package.json");
    if (source == Source.BUNDLED && bundled.typescriptFile() != null) {
      out.add(new FileChange("copy", dest.resolve(WHEELS_DIR).resolve(bundled.typescriptFile()), bundledDir.resolve(bundled.typescriptFile()), null));
      out.add(new FileChange("npm-spec", pkg, null, "file:" + WHEELS_DIR + "/" + bundled.typescriptFile()));
    } else if (source == Source.MONOREPO && repoRoot != null) {
      out.add(new FileChange("npm-spec", pkg, null, monorepoNpmSpec(dest, repoRoot)));
    } else {
      out.add(new FileChange("npm-spec", pkg, null, pins.typescript()));
    }
    return out;
  }

  public static String monorepoNpmSpec(Path dest, Path repoRoot) {
    return "file:" + dest.toAbsolutePath().normalize().relativize(repoRoot.toAbsolutePath().normalize().resolve("sdk").resolve("typescript")).toString().replace('\\', '/');
  }

  /** Applies the changes; returns a log line per change that modified something. */
  public static List<String> apply(List<FileChange> changes) throws IOException {
    List<String> log = new ArrayList<>();
    for (FileChange c : changes) {
      switch (c.kind()) {
        case "copy" -> {
          Files.createDirectories(c.file().getParent());
          Files.copy(c.from(), c.file(), StandardCopyOption.REPLACE_EXISTING);
          log.add("copied " + c.from().getFileName() + " to " + c.file());
        }
        case "npm-spec" -> {
          String before = Files.readString(c.file(), StandardCharsets.UTF_8);
          String after = setNpmSdkSpec(before, c.value());
          if (!after.equals(before)) {
            Files.writeString(c.file(), after, StandardCharsets.UTF_8);
            log.add(c.file().getFileName() + ": @aig/sdk = " + c.value());
          }
        }
        default -> {
          String before = Files.readString(c.file(), StandardCharsets.UTF_8);
          String after = setPythonSdkPin(before, c.value());
          if (!after.equals(before)) {
            Files.writeString(c.file(), after, StandardCharsets.UTF_8);
            log.add(c.file().getFileName() + ": aig-sdk==" + c.value());
          }
        }
      }
    }
    return log;
  }

  private static final Pattern PY_PIN = Pattern.compile("([\"'])aig-sdk(\\[[A-Za-z0-9_,\\s-]*\\])?\\s*(?:==|>=|~=|<=|>|<|!=)[^\"']*\\1");
  private static final Pattern NPM_SPEC = Pattern.compile("(\"@aig/sdk\"\\s*:\\s*)\"(?:[^\"\\\\]|\\\\.)*\"");

  /** Rewrites every {@code aig-sdk[...]<op><version>} requirement in pyproject.toml to {@code ==pin}. */
  public static String setPythonSdkPin(String pyproject, String pin) {
    Matcher m = PY_PIN.matcher(pyproject);
    StringBuilder sb = new StringBuilder();
    while (m.find()) {
      String q = m.group(1), extras = m.group(2) == null ? "" : m.group(2);
      m.appendReplacement(sb, Matcher.quoteReplacement(q + "aig-sdk" + extras + "==" + pin + q));
    }
    m.appendTail(sb);
    return sb.toString();
  }

  /** Sets {@code dependencies["@aig/sdk"]} in package.json text, keeping the file's formatting. */
  public static String setNpmSdkSpec(String packageJson, String spec) {
    Matcher m = NPM_SPEC.matcher(packageJson);
    if (m.find()) return packageJson.substring(0, m.start()) + m.group(1) + Json.quote(spec) + packageJson.substring(m.end());
    Map<String, Object> pkg = Json.parseObject(packageJson);
    Map<String, Object> deps = new LinkedHashMap<>();
    Map<String, Object> old = Json.obj(pkg, "dependencies");
    if (old != null) deps.putAll(old);
    deps.put(TS_SDK, spec);
    pkg.put("dependencies", deps);
    return Json.write(pkg) + "\n";
  }

  /** aig-agent.yaml: top-level name / display_name / description as JSON-quoted (YAML-safe) values, like aig init. */
  public static String renderDescriptor(String text, String name, String displayName, String description) {
    Map<String, String> v = new LinkedHashMap<>();
    v.put("name", name);
    v.put("display_name", displayName == null || displayName.isBlank() ? name : displayName.trim());
    v.put("description", description);
    List<String> seen = new ArrayList<>();
    StringBuilder sb = new StringBuilder();
    for (String line : text.replace("\r\n", "\n").replaceAll("\n+$", "").split("\n", -1)) {
      int colon = line.indexOf(':');
      String key = colon < 0 ? "" : line.substring(0, colon);
      if (v.containsKey(key) && !seen.contains(key) && !line.startsWith(" ") && !line.startsWith("#")) {
        seen.add(key);
        line = key + ": " + Json.quote(v.get(key));
      }
      sb.append(line).append('\n');
    }
    return sb.toString();
  }

  /** {@code aig doctor --json} for the project: the venv's aig (python) or the given CLI (node). Null when none. */
  public static Step doctorStep(Language lang, Path dest, Path cli, boolean windows) {
    Path aig = lang == Language.PYTHON ? venvBin(dest, "aig", windows) : cli;
    return aig == null ? null : new Step("aig doctor", List.of(aig.toString(), "doctor", "--json"), dest);
  }

  /** Summary of {@code aig doctor --json}: ok flag, failed count and printable lines. */
  public record DoctorSummary(boolean ok, int failed, List<String> lines) {}

  public static DoctorSummary parseDoctor(String stdout) {
    int i = stdout == null ? -1 : stdout.indexOf('{');
    if (i < 0) return null;
    Map<String, Object> d;
    try {
      d = Json.parseObject(stdout.substring(i));
    } catch (RuntimeException e) {
      return null;
    }
    if (d == null || !(d.get("ok") instanceof Boolean ok) || Json.list(d, "checks") == null) return null;
    List<String> lines = new ArrayList<>();
    int failed = 0;
    for (Object o : Json.list(d, "checks")) {
      Map<String, Object> c = Json.asObject(o);
      if (c == null) continue;
      boolean cok = Boolean.TRUE.equals(c.get("ok"));
      String code = Json.str(c, "code"), field = Json.str(c, "field"), fix = Json.str(c, "remediation");
      if (!cok && code != null) failed++;
      lines.add((cok ? "OK   " : code != null ? "FAIL " : "SKIP ") + Json.str(c, "name") + (code != null ? " " + code + (field != null ? " (" + field + ")" : "") : ""));
      if (!cok && code != null && fix != null) lines.add("     fix: " + fix);
    }
    return new DoctorSummary(ok, failed, lines);
  }

  /** aig CLI install: pipx (preferred) or a private venv in ~/.aig/cli. Null without pipx and Python. */
  public record CliPlan(String method, List<Step> steps, Path aigPath) {}

  public static CliPlan cliInstallPlan(String pin, Path pipx, Path python, Path wheelsDir, String indexUrl, Path home, boolean windows) {
    String spec = PY_SDK + "[evals]==" + pin;
    List<String> pipArgs = new ArrayList<>();
    if (indexUrl != null) pipArgs.addAll(List.of("--index-url", indexUrl));
    if (wheelsDir != null) pipArgs.addAll(List.of("--find-links", wheelsDir.toString()));
    if (pipx != null) {
      List<String> c = new ArrayList<>(List.of(pipx.toString(), "install", "--force"));
      if (!pipArgs.isEmpty()) c.add("--pip-args=" + String.join(" ", pipArgs));
      c.add(spec);
      return new CliPlan("pipx", List.of(new Step("pipx install aig-sdk", c, home)), null);
    }
    if (python == null) return null;
    Path dir = home.resolve(".aig").resolve("cli");
    Path py = windows ? dir.resolve("Scripts").resolve("python.exe") : dir.resolve("bin").resolve("python");
    List<String> venv = pythonPrefix(python);
    venv.addAll(List.of("-m", "venv", dir.toString()));
    List<String> pip = new ArrayList<>(List.of(py.toString(), "-m", "pip", "install", "--upgrade"));
    pip.addAll(pipArgs);
    pip.add(spec);
    return new CliPlan("venv", List.of(new Step("create ~/.aig/cli", venv, home), new Step("install aig-sdk", pip, home)),
        windows ? dir.resolve("Scripts").resolve("aig.exe") : dir.resolve("bin").resolve("aig"));
  }
}
