package com.aig.ai.ecosystem.core.ws;

import java.util.Locale;

/** Backend WebSocket connection state (the widgets' {@code LiveStatus}). */
public enum LiveStatus {
  IDLE, CONNECTING, OPEN, RECONNECTING, UNAUTHORIZED, CLOSED;

  public String id() {
    return name().toLowerCase(Locale.ROOT);
  }
}
