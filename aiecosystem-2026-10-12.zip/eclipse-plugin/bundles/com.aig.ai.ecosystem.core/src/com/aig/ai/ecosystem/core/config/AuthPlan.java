package com.aig.ai.ecosystem.core.config;

/**
 * How the plugin signs in for the selected environment.
 * <ul>
 *   <li>{@code MICROSOFT}: dev/stage/prod, Entra ID Authorization Code + PKCE in the system browser
 *       with a loopback redirect ({@code http://127.0.0.1:<port>/callback}, RFC 8252)</li>
 *   <li>{@code LOCAL_BROWSER}: local, the backend's local sign-in page redirecting to
 *       {@code http://127.0.0.1:<port>/auth/callback}</li>
 *   <li>{@code DEV}: local, the optional dev-user shortcut ({@code dev:<email>} token)</li>
 *   <li>{@code UNCONFIGURED}: placeholders or invalid values</li>
 * </ul>
 */
public final class AuthPlan {
  public enum Kind { MICROSOFT, LOCAL_BROWSER, DEV, UNCONFIGURED }

  private final Kind kind;
  private final EntraConfig entra;
  private final String email;
  private final String reason;

  private AuthPlan(Kind kind, EntraConfig entra, String email, String reason) {
    this.kind = kind;
    this.entra = entra;
    this.email = email;
    this.reason = reason;
  }

  public static AuthPlan microsoft(EntraConfig entra) {
    return new AuthPlan(Kind.MICROSOFT, entra, null, null);
  }

  public static AuthPlan localBrowser() {
    return new AuthPlan(Kind.LOCAL_BROWSER, null, null, null);
  }

  public static AuthPlan dev(String email) {
    return new AuthPlan(Kind.DEV, null, email, null);
  }

  public static AuthPlan unconfigured(String reason) {
    return new AuthPlan(Kind.UNCONFIGURED, null, null, reason);
  }

  public Kind kind() {
    return kind;
  }

  public EntraConfig entra() {
    return entra;
  }

  public String email() {
    return email;
  }

  public String reason() {
    return reason;
  }

  /** Value used for the sign-in widget's {@code status.method}. */
  public String method() {
    switch (kind) {
      case MICROSOFT: return "microsoft";
      case LOCAL_BROWSER: return "browser";
      case DEV: return "devUser";
      default: return "unconfigured";
    }
  }

  /** Validated Entra ID values. */
  public record EntraConfig(String authority, String tenantId, String clientId, String scope) {}
}
