package com.aig.ai.ecosystem.core.config;

import java.util.EnumMap;
import java.util.Map;

/** Raw settings as read from preferences (unvalidated). */
public final class AigSettings {
  private final String environment;
  private final Map<AigEnvironment, EnvSettings> envs;
  private final String jobProfile;
  private final String devUser;

  public AigSettings(String environment, Map<AigEnvironment, EnvSettings> envs, String jobProfile, String devUser) {
    this.environment = environment;
    this.envs = new EnumMap<>(AigEnvironment.class);
    for (AigEnvironment e : AigEnvironment.values()) {
      EnvSettings s = envs == null ? null : envs.get(e);
      this.envs.put(e, s == null ? EnvSettings.defaults(e) : s);
    }
    this.jobProfile = jobProfile;
    this.devUser = devUser;
  }

  /** All defaults (placeholders) for the given environment. */
  public static AigSettings defaults(String environment) {
    return new AigSettings(environment, null, JobProfiles.DEFAULT, "");
  }

  public String environment() {
    return environment;
  }

  public EnvSettings env(AigEnvironment e) {
    return envs.get(e);
  }

  public String jobProfile() {
    return jobProfile;
  }

  public String devUser() {
    return devUser;
  }

  public AigSettings withEnvironment(String env) {
    return new AigSettings(env, envs, jobProfile, devUser);
  }

  public AigSettings withEnv(AigEnvironment e, EnvSettings s) {
    Map<AigEnvironment, EnvSettings> m = new EnumMap<>(envs);
    m.put(e, s);
    return new AigSettings(environment, m, jobProfile, devUser);
  }

  public AigSettings withDevUser(String user) {
    return new AigSettings(environment, envs, jobProfile, user);
  }

  public AigSettings withJobProfile(String p) {
    return new AigSettings(environment, envs, p, devUser);
  }
}
