package com.aig.ai.ecosystem.core.config;

import java.util.Locale;

/** The four AIG platform backend environments (the VSIX's {@code aig.environment}). */
public enum AigEnvironment {
  LOCAL, DEV, STAGE, PROD;

  public static final AigEnvironment DEFAULT = DEV;

  public String id() {
    return name().toLowerCase(Locale.ROOT);
  }

  /** Parses an environment id; returns {@code null} for anything unknown. */
  public static AigEnvironment parse(String value) {
    if (value == null) return null;
    for (AigEnvironment e : values()) if (e.id().equals(value.trim())) return e;
    return null;
  }

  /** Unknown or missing values fall back to {@link #DEFAULT} (same as the VSIX). */
  public static AigEnvironment normalize(String value) {
    AigEnvironment e = parse(value);
    return e == null ? DEFAULT : e;
  }

  @Override
  public String toString() {
    return id();
  }
}
