package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** An invocation record ({@code GET /api/v1/invocations[/{id}]}); metadata, plus the output for the caller's background runs. */
public record Invocation(String id, String agentId, String version, String env, String mode, String status, String traceId, String createdAt,
    Long durationMs, Map<String, Object> usage, String errorCode, String errorMessage, boolean outputAvailable, Object output) {

  public static Invocation from(Object raw) {
    Map<String, Object> r = Json.asObject(raw);
    String id = Json.str(r, "id");
    String agentId = Json.str(r, "agent_id");
    if (id == null || agentId == null) return null;
    Object d = r.get("duration_ms");
    String status = Json.str(r, "status");
    String mode = Json.str(r, "mode");
    String created = Json.str(r, "created_at");
    return new Invocation(id, agentId, Json.str(r, "version"), Json.str(r, "env"), mode == null ? "sync" : mode, status == null ? "queued" : status,
        Json.str(r, "trace_id"), created == null ? "" : created, d instanceof Long ? (Long) d : null, Usage.clean(r.get("usage")), Json.str(r, "error_code"),
        Json.str(r, "error_message"), Boolean.TRUE.equals(r.get("output_available")), r.get("output"));
  }

  public static List<Invocation> list(Map<String, Object> body) {
    List<Invocation> out = new ArrayList<>();
    List<Object> raw = Json.list(body, "items");
    if (raw != null) {
      for (Object o : raw) {
        Invocation i = from(o);
        if (i != null) out.add(i);
      }
    }
    return out;
  }

  public boolean isFinal() {
    return AgentIds.isFinal(status);
  }

  /** web/packages/ui {@code RecentRun}. {@code name} may be null. */
  public Map<String, Object> toRecentRun(String name) {
    return Json.object().put("invocationId", id).put("agentId", agentId).opt("name", name).put("status", status).put("mode", mode).opt("version", version)
        .opt("env", env).put("createdAt", createdAt).put("durationMs", durationMs).opt("traceId", traceId).put("errorCode", errorCode).map();
  }
}
