package com.aig.ai.ecosystem.core.agents;

import com.aig.ai.ecosystem.core.json.Json;
import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Built-in scaffolder used when the {@code aig} CLI is not on PATH. Same rules as
 * sdk/python aig_sdk/cli.py {@code scaffold}: copy the template, replacing each placeholder's sample
 * value (longest first) in file contents and paths, skipping the default and manifest excludes.
 */
public final class Templates {
  public static final String MANIFEST = "aig-template.json";
  public static final List<String> DEFAULT_EXCLUDES = List.of(".venv", "node_modules", "__pycache__", ".pytest_cache", ".ruff_cache", "dist", ".env",
      "package-lock.json", "*.egg-info", ".aig-wheels", MANIFEST);
  public static final Pattern AGENT_ID = Pattern.compile("^[A-Za-z0-9._-]{1,64}$");
  public static final Pattern TEAM = Pattern.compile("^[A-Za-z0-9._-]{1,64}$");

  private Templates() {}

  /** Loads every template under {@code root} (sorted by name). */
  public static Map<String, Template> load(Path root) throws IOException {
    Map<String, Template> out = new TreeMap<>();
    if (root == null || !Files.isDirectory(root)) return out;
    try (Stream<Path> dirs = Files.list(root)) {
      for (Path dir : (Iterable<Path>) dirs.sorted()::iterator) {
        Path manifest = dir.resolve(MANIFEST);
        if (!Files.isRegularFile(manifest)) continue;
        Map<String, Object> m = Json.parseObject(Files.readString(manifest, StandardCharsets.UTF_8));
        if (m == null || Json.str(m, "name") == null) continue;
        Map<String, String> ph = new LinkedHashMap<>();
        Map<String, Object> raw = Json.obj(m, "placeholders");
        if (raw != null) raw.forEach((k, v) -> {
          if (v instanceof String) ph.put(k, (String) v);
        });
        List<String> ex = new ArrayList<>(Json.strings(m.get("exclude")));
        ex.addAll(DEFAULT_EXCLUDES);
        String desc = Json.str(m, "description");
        String lang = Json.str(m, "language");
        out.put(Json.str(m, "name"), new Template(Json.str(m, "name"), dir, desc == null ? "" : desc, lang == null ? "" : lang, ph, List.copyOf(ex)));
      }
    }
    return out;
  }

  /** cli.py {@code _slug}. */
  public static String slug(String name) {
    String s = name.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^[-.]+|[-.]+$", "").toLowerCase(java.util.Locale.ROOT);
    if (s.length() > 64) s = s.substring(0, 64);
    return s.isEmpty() ? "agent" : s;
  }

  /** Placeholder values for a new project, as {@code aig init} computes them. */
  public static Map<String, String> values(Template t, Path dest, String agentId, String team, String description) {
    String project = slug(dest.toAbsolutePath().normalize().getFileName().toString());
    Map<String, String> v = new LinkedHashMap<>();
    v.put("agent_id", agentId);
    v.put("team", team);
    v.put("project", project);
    v.put("package", project.replaceAll("[^A-Za-z0-9_]", "_").toLowerCase(java.util.Locale.ROOT));
    v.put("description", description == null || description.isBlank() ? t.name() + " agent " + agentId : description.trim());
    return v;
  }

  static boolean excluded(Path rel, List<String> patterns) {
    for (Path part : rel) {
      String p = part.toString();
      for (String pat : patterns) {
        if (p.equals(pat)) return true;
        if (pat.contains("*") && p.matches(Pattern.quote(pat).replace("*", "\\E.*\\Q"))) return true;
      }
    }
    return false;
  }

  /**
   * Copies {@code t} to {@code dest}. Fails when {@code dest} exists and is not empty (unless force).
   *
   * @return written files
   */
  public static List<Path> scaffold(Template t, Path dest, Map<String, String> values, boolean force) throws IOException {
    if (Files.isDirectory(dest) && !force) {
      try (Stream<Path> s = Files.list(dest)) {
        if (s.findAny().isPresent()) throw new IOException(dest + " exists and is not empty");
      }
    }
    List<String[]> repl = new ArrayList<>();
    for (Map.Entry<String, String> e : values.entrySet()) {
      String sample = t.placeholders().get(e.getKey());
      if (sample != null && !sample.isEmpty()) repl.add(new String[] {sample, e.getValue()});
    }
    repl.sort(Comparator.comparingInt((String[] kv) -> kv[0].length()).reversed());
    List<Path> written = new ArrayList<>();
    List<Path> files = new ArrayList<>();
    // Prune excluded directories (.venv, node_modules, ...) instead of walking them.
    Files.walkFileTree(t.path(), new java.nio.file.SimpleFileVisitor<Path>() {
      @Override
      public java.nio.file.FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes a) {
        Path rel = t.path().relativize(dir);
        return rel.toString().isEmpty() || !excluded(rel, t.exclude()) ? java.nio.file.FileVisitResult.CONTINUE : java.nio.file.FileVisitResult.SKIP_SUBTREE;
      }

      @Override
      public java.nio.file.FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes a) {
        if (a.isRegularFile() && !excluded(t.path().relativize(file), t.exclude())) files.add(file);
        return java.nio.file.FileVisitResult.CONTINUE;
      }
    });
    files.sort(Comparator.naturalOrder());
    for (Path src : files) {
      Path rel = t.path().relativize(src);
      Path target = dest.resolve(restoreDotName(substitute(rel.toString().replace('\\', '/'), repl))).normalize();
      if (!target.startsWith(dest.normalize())) throw new IOException("template path escapes the destination: " + rel);
      Files.createDirectories(target.getParent());
      byte[] data = Files.readAllBytes(src);
      String text = decodeUtf8(data);
      if (text == null) Files.copy(src, target, StandardCopyOption.REPLACE_EXISTING);
      else Files.writeString(target, substitute(text, repl), StandardCharsets.UTF_8);
      if (Files.isExecutable(src)) target.toFile().setExecutable(true);
      written.add(target);
    }
    return written;
  }

  private static String substitute(String text, List<String[]> repl) {
    for (String[] kv : repl) text = text.replace(kv[0], kv[1]);
    return text;
  }

  private static String decodeUtf8(byte[] data) {
    try {
      return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
          .decode(java.nio.ByteBuffer.wrap(data)).toString();
    } catch (CharacterCodingException e) {
      return null;
    }
  }

  /**
   * Bundled templates store dotfiles that Maven/Tycho's default excludes would drop (e.g. .gitignore)
   * as {@code __dot__<name>}; web/build.mjs writes them that way. This maps them back.
   */
  public static final String DOT_PREFIX = "__dot__";

  static String restoreDotName(String relPath) {
    String[] parts = relPath.split("/", -1);
    for (int i = 0; i < parts.length; i++) if (parts[i].startsWith(DOT_PREFIX)) parts[i] = "." + parts[i].substring(DOT_PREFIX.length());
    return String.join("/", parts);
  }

  /** Renames any {@code __dot__*} files under {@code dir} back to dotfiles (used after `aig init` copied a bundled template). */
  public static void restoreDotfiles(Path dir) throws IOException {
    if (!Files.isDirectory(dir)) return;
    List<Path> found;
    try (Stream<Path> s = Files.walk(dir)) {
      found = s.filter(f -> f.getFileName().toString().startsWith(DOT_PREFIX)).sorted(Comparator.reverseOrder()).toList();
    }
    for (Path f : found) {
      Path target = f.resolveSibling("." + f.getFileName().toString().substring(DOT_PREFIX.length()));
      Files.move(f, target, StandardCopyOption.REPLACE_EXISTING);
    }
  }
}
