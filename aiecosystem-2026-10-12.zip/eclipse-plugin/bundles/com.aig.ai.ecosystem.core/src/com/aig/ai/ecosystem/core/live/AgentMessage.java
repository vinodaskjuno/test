package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.invoke.AgentIds;
import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A validated agent widget to host message (web/packages/ui src/messages.ts, the {@code catalog.*} and
 * {@code agent.*} part of {@code WebviewMessage}, plus {@code clipboard.copy}). Untrusted input: {@link #parse}
 * applies the same rules as the TypeScript {@code parseWebviewMessage} (ids, regexes, size limits; exactly one
 * of input / messages; the input must be a plain object of at most 256 KiB serialised).
 */
public record AgentMessage(String cmd, String localId, String agentId, String env, String version, String mode, Map<String, Object> input,
    List<ChatMessage> messages, String sessionId, String invocationId, String text) {
  public static final int MAX_INPUT_BYTES = 256 * 1024;
  static final int MAX_AGENT_MESSAGES = 200;
  static final int MAX_CLIPBOARD = 1_000_000;
  private static final Set<String> SIMPLE = Set.of("catalog.refresh", "agent.register", "agent.runs.refresh");

  private static AgentMessage of(String cmd) {
    return new AgentMessage(cmd, null, null, null, null, null, null, null, null, null, null);
  }

  private static boolean localId(Object o) {
    return o instanceof String && WebviewMessage.LOCAL_ID.matcher((String) o).matches();
  }

  /** Returns null for anything malformed or not an agent command. */
  public static AgentMessage parse(String raw) {
    if (raw == null || raw.length() > WebviewMessage.MAX_RAW) return null;
    Map<String, Object> o = Json.parseObject(raw);
    if (o == null) return null;
    String cmd = Json.str(o, "cmd");
    if (cmd == null) return null;
    if (SIMPLE.contains(cmd)) return of(cmd);
    switch (cmd) {
      case "agent.open": {
        String agentId = Json.str(o, "agentId");
        if (!AgentIds.agentId(agentId)) return null;
        String[] t = target(o);
        return t == null ? null : new AgentMessage(cmd, null, agentId, t[0], t[1], null, null, null, null, null, null);
      }
      case "agent.run.show": {
        String id = Json.str(o, "invocationId");
        return AgentIds.invocationId(id) ? new AgentMessage(cmd, null, null, null, null, null, null, null, null, id, null) : null;
      }
      case "agent.cancel": {
        if (!localId(o.get("localId"))) return null;
        Object inv = o.get("invocationId");
        if (o.containsKey("invocationId") && !(inv instanceof String && AgentIds.invocationId((String) inv))) return null;
        return new AgentMessage(cmd, (String) o.get("localId"), null, null, null, null, null, null, null, (String) inv, null);
      }
      case "agent.poll": {
        String id = Json.str(o, "invocationId");
        if (!localId(o.get("localId")) || !AgentIds.invocationId(id)) return null;
        return new AgentMessage(cmd, (String) o.get("localId"), null, null, null, null, null, null, null, id, null);
      }
      case "clipboard.copy": {
        Object t = o.get("text");
        return t instanceof String && ((String) t).length() <= MAX_CLIPBOARD ? new AgentMessage(cmd, null, null, null, null, null, null, null, null, null, (String) t) : null;
      }
      case "agent.invoke":
        return parseInvoke(o);
      default:
        return null;
    }
  }

  /** {env, version} or null when either is present but invalid. */
  private static String[] target(Map<String, Object> o) {
    Object env = o.get("env");
    Object version = o.get("version");
    if (o.containsKey("env") && !(env instanceof String && AgentIds.env((String) env))) return null;
    if (o.containsKey("version") && !(version instanceof String && AgentIds.version((String) version))) return null;
    return new String[] {(String) env, (String) version};
  }

  private static AgentMessage parseInvoke(Map<String, Object> o) {
    if (!localId(o.get("localId"))) return null;
    String agentId = Json.str(o, "agentId");
    if (!AgentIds.agentId(agentId)) return null;
    Object mode = o.get("mode");
    if (!"stream".equals(mode) && !"background".equals(mode)) return null;
    String[] t = target(o);
    if (t == null) return null;
    boolean hasInput = o.containsKey("input");
    boolean hasMessages = o.containsKey("messages");
    if (hasInput == hasMessages) return null; // exactly one of input / messages
    Map<String, Object> input = null;
    List<ChatMessage> messages = null;
    if (hasInput) {
      input = Json.asObject(o.get("input"));
      if (input == null || Json.write(input).length() > MAX_INPUT_BYTES) return null;
    } else {
      List<Object> raws = Json.list(o, "messages");
      if (raws == null || raws.isEmpty() || raws.size() > MAX_AGENT_MESSAGES) return null;
      messages = new ArrayList<>();
      for (Object x : raws) {
        Map<String, Object> r = Json.asObject(x);
        String role = Json.str(r, "role");
        String content = Json.str(r, "content");
        if (r == null || (!"user".equals(role) && !"assistant".equals(role)) || content == null || content.length() > WebviewMessage.MAX_CONTENT) return null;
        messages.add(new ChatMessage(role, content));
      }
      if (!"user".equals(messages.get(messages.size() - 1).role())) return null;
      messages = List.copyOf(messages);
    }
    Object session = o.get("sessionId");
    if (o.containsKey("sessionId") && !(session instanceof String && AgentIds.SESSION_ID.matcher((String) session).matches())) return null;
    return new AgentMessage("agent.invoke", (String) o.get("localId"), agentId, t[0], t[1], (String) mode, input, messages, (String) session, null, null);
  }
}
