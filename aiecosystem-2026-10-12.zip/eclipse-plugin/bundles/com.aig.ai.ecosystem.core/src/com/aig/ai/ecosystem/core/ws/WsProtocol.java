package com.aig.ai.ecosystem.core.ws;

import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.json.Json;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * AIG backend WebSocket protocol ({@code GET /api/v1/ws}; backend/platform-api README "WebSocket").
 * Every frame is a JSON text frame with a {@code type}. Port of vscode-extension/src/ws/protocol.ts.
 */
public final class WsProtocol {
  public static final Pattern CHAT_ID = Pattern.compile("^[A-Za-z0-9_-]{1,64}$");

  private WsProtocol() {}

  /** Backend base URL (http/https) to the WebSocket URL (ws/wss). */
  public static URI wsUrl(String backendUrl) {
    URI u = URI.create(backendUrl.replaceAll("/+$", "") + "/api/v1/ws");
    String scheme = "https".equalsIgnoreCase(u.getScheme()) ? "wss" : "ws";
    return URI.create(scheme + u.toString().substring(u.getScheme().length()));
  }

  private static String s(Map<String, Object> f, String key, String dflt) {
    String v = Json.str(f, key);
    return v == null ? dflt : v;
  }

  private static String nonEmpty(String v) {
    return v == null || v.isEmpty() ? null : v;
  }

  /**
   * {@code chat.done.route}: {@code user_tier} (required, non-empty string), optional {@code cost_mode},
   * {@code job_profile} and {@code usage_state} (normal|soft|hard|unknown; non-string or empty values are dropped);
   * {@code null} when absent or malformed.
   */
  static Map<String, Object> route(Map<String, Object> r) {
    String tier = nonEmpty(Json.str(r, "user_tier"));
    if (tier == null) return null;
    return Json.object().put("user_tier", tier).opt("cost_mode", nonEmpty(Json.str(r, "cost_mode"))).opt("job_profile", nonEmpty(Json.str(r, "job_profile")))
        .opt("usage_state", nonEmpty(Json.str(r, "usage_state"))).map();
  }

  /** Parses one server frame; {@code null} for anything malformed or unknown. */
  public static ServerFrame parse(String raw) {
    Map<String, Object> f = Json.parseObject(raw);
    if (f == null) return null;
    String type = Json.str(f, "type");
    if (type == null) return null;
    switch (type) {
      case "ready": {
        Map<String, Object> user = Json.obj(f, "user");
        String email = Json.str(user, "email");
        if (email == null) return null;
        ReadyInfo info = new ReadyInfo(email, Json.str(user, "name"), Json.str(f, "team"), Json.str(f, "env"), Json.str(f, "user_tier"),
            Json.strings(f.get("allowed_job_profiles")));
        return new ServerFrame(type, null, null, null, null, null, null, 0, null, info, null, null);
      }
      case "ping":
      case "pong":
        return ServerFrame.of(type);
      case "chat.delta": {
        String id = Json.str(f, "id");
        return id == null ? null : new ServerFrame(type, id, s(f, "text", ""), null, null, null, null, 0, null, null, null, null);
      }
      case "chat.done": {
        String id = Json.str(f, "id");
        if (id == null) return null;
        Map<String, Object> u = Json.obj(f, "usage");
        Map<String, Object> usage = u == null ? null
            : Json.object().put("prompt_tokens", (long) Json.num(u, "prompt_tokens")).put("completion_tokens", (long) Json.num(u, "completion_tokens"))
                .put("total_tokens", (long) Json.num(u, "total_tokens")).map();
        return new ServerFrame(type, id, null, Json.str(f, "trace_id"), usage, null, null, 0, null, null, nonEmpty(Json.str(f, "model")), route(Json.obj(f, "route")));
      }
      case "chat.error": {
        String id = Json.str(f, "id");
        if (id == null) return null;
        String code = s(f, "code", "error");
        return new ServerFrame(type, id, null, Json.str(f, "trace_id"), null, code, s(f, "message", code), 0, null, null, null, null);
      }
      case "usage": {
        Map<String, Object> data = Json.obj(f, "data");
        if (data == null || Json.obj(data, "totals") == null || Json.list(data, "models") == null) return null;
        return new ServerFrame(type, null, null, null, null, null, null, (int) Json.num(f, "days"), data, null, null, null);
      }
      case "usage.error":
      case "error": {
        String code = s(f, "code", "error");
        return new ServerFrame(type, null, null, null, null, code, s(f, "message", code), 0, null, null, null, null);
      }
      default:
        return null;
    }
  }

  // ---- client frames -----------------------------------------------------------------------

  public static String ping() {
    return Json.object().put("type", "ping").toString();
  }

  public static String pong() {
    return Json.object().put("type", "pong").toString();
  }

  public static String chat(String id, List<ChatMessage> messages, String jobProfile, String agentId) {
    if (!CHAT_ID.matcher(id).matches()) throw new IllegalArgumentException("bad chat id");
    List<Object> msgs = new ArrayList<>();
    for (ChatMessage m : messages) msgs.add(m.toJson());
    return Json.object().put("type", "chat").put("id", id).put("messages", msgs).opt("job_profile", jobProfile).opt("agent_id", agentId).toString();
  }

  public static String cancel(String id) {
    return Json.object().put("type", "cancel").put("id", id).toString();
  }

  public static String usageSubscribe(int days) {
    return Json.object().put("type", "usage.subscribe").put("days", days).toString();
  }

  public static String usageUnsubscribe() {
    return Json.object().put("type", "usage.unsubscribe").toString();
  }
}
