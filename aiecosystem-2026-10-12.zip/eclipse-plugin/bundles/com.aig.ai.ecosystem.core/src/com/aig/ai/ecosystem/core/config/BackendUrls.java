package com.aig.ai.ecosystem.core.config;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import java.util.Set;

/**
 * Backend URL rules (mirrors vscode-extension/src/config.ts validateBackendUrl): plain http is
 * accepted only in the {@code local} environment and only for loopback hosts; dev/stage/prod
 * always require https (loopback included). No credentials, query or fragment.
 */
public final class BackendUrls {
  static final Set<String> LOOPBACK_HOSTS = Set.of("localhost", "127.0.0.1", "[::1]", "::1");

  private BackendUrls() {}

  public static boolean isLoopbackHost(String host) {
    return host != null && LOOPBACK_HOSTS.contains(host.toLowerCase(Locale.ROOT));
  }

  public static UrlCheck validate(String raw, AigEnvironment env) {
    if (Placeholders.isPlaceholder(raw)) return UrlCheck.fail("placeholder");
    URI u;
    try {
      u = new URI(raw.trim());
    } catch (URISyntaxException e) {
      return UrlCheck.fail("invalid URL");
    }
    String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
    if (!u.isAbsolute() || u.isOpaque() || u.getHost() == null || u.getHost().isEmpty()) {
      if (!scheme.equals("http") && !scheme.equals("https") && !scheme.isEmpty()) {
        return UrlCheck.fail("unsupported protocol " + scheme + ":");
      }
      return UrlCheck.fail("invalid URL");
    }
    if (u.getRawUserInfo() != null) return UrlCheck.fail("credentials in URL are not allowed");
    if (u.getRawQuery() != null || u.getRawFragment() != null) return UrlCheck.fail("query string or fragment not allowed");
    String host = u.getHost().toLowerCase(Locale.ROOT);
    if (scheme.equals("http")) {
      if (env != AigEnvironment.LOCAL) return UrlCheck.fail("http is not allowed for " + env.id() + "; use https");
      if (!isLoopbackHost(host)) return UrlCheck.fail("http is only allowed for localhost; use https");
    } else if (!scheme.equals("https")) {
      return UrlCheck.fail("unsupported protocol " + scheme + ":");
    }
    String path = u.getRawPath() == null ? "" : u.getRawPath().replaceAll("/+$", "");
    int port = u.getPort();
    boolean defaultPort = port == -1 || (scheme.equals("http") && port == 80) || (scheme.equals("https") && port == 443);
    return UrlCheck.ok(scheme + "://" + host + (defaultPort ? "" : ":" + port) + path);
  }
}
