/** AIG core: live. */
package com.aig.ai.ecosystem.core.live;
