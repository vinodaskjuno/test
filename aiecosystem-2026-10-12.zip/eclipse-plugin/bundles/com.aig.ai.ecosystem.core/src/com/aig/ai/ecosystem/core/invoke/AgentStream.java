package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.http.SseEvent;
import com.aig.ai.ecosystem.core.http.SseParser;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Incremental decoder of an invocation stream: SSE framing (CRLF / CR / LF, chunks split anywhere,
 * {@code : keepalive} comments) via {@link SseParser}, then {@link AgentEvent}s; unknown events are dropped.
 * It also folds the events into the run {@link Result} with the contract rules: a stream with {@code done}
 * but no {@code output} succeeds with the concatenated deltas; one that ends without {@code output} or
 * {@code done} fails with {@code agent_error}. Not thread safe.
 */
public final class AgentStream {
  /** Final outcome of a stream. {@code error} is null on success; {@code output} is null on failure. */
  public record Result(String status, Object output, String text, Map<String, Object> usage, AgentEvent.Error error, String traceId, String invocationId,
      Long durationMs, boolean sawDone) {
    public boolean succeeded() {
      return "succeeded".equals(status);
    }
  }

  public static final String TRUNCATED_CODE = "agent_error";
  public static final String TRUNCATED_MESSAGE = "agent stream ended unexpectedly";

  private final SseParser parser = new SseParser();
  private final StringBuilder text = new StringBuilder();
  private AgentEvent.Output output;
  private AgentEvent.Error error;
  private AgentEvent.Done done;
  private String invocationId;
  private String traceId;

  public AgentStream() {}

  /** Seeds ids known from response headers ({@code x-aig-invocation-id}, {@code x-aig-trace-id}). */
  public AgentStream(String invocationId, String traceId) {
    this.invocationId = invocationId;
    this.traceId = traceId;
  }

  public List<AgentEvent> feed(String chunk) {
    return accept(parser.feed(chunk));
  }

  /** Flushes an unterminated trailing event. */
  public List<AgentEvent> end() {
    return accept(parser.end());
  }

  private List<AgentEvent> accept(List<SseEvent> events) {
    List<AgentEvent> out = new ArrayList<>();
    for (SseEvent e : events) {
      if (done != null) break; // done is always last
      AgentEvent ev = AgentEvent.from(e);
      if (ev == null) continue;
      if (ev.invocationId() != null && invocationId == null) invocationId = ev.invocationId();
      if (ev instanceof AgentEvent.Delta d) text.append(d.text());
      else if (ev instanceof AgentEvent.Output o) {
        output = o;
        if (o.traceId() != null) traceId = o.traceId();
      } else if (ev instanceof AgentEvent.Error er) error = er;
      else if (ev instanceof AgentEvent.Done dn) done = dn;
      out.add(ev);
    }
    return out;
  }

  public boolean isDone() {
    return done != null;
  }

  public String text() {
    return text.toString();
  }

  public String invocationId() {
    return invocationId;
  }

  /** Outcome of a stream the caller cancelled (events already decoded but not delivered do not count). */
  public Result cancelled() {
    return new Result("cancelled", null, text(), output == null ? null : output.usage(), null, traceId, invocationId, null, done != null);
  }

  /** The outcome so far; call after the stream ended (or was cancelled: {@code cancelled=true}). */
  public Result result(boolean cancelled) {
    Long ms = done == null ? null : done.durationMs();
    String doneStatus = done == null ? null : done.status();
    Map<String, Object> usage = output == null ? null : output.usage();
    if (cancelled && done == null) return new Result("cancelled", null, text(), usage, null, traceId, invocationId, null, false);
    if (error != null) {
      String status = doneStatus != null && !"succeeded".equals(doneStatus) ? doneStatus : "failed";
      return new Result(status, null, text(), usage, error, traceId, invocationId, ms, done != null);
    }
    if (output != null && (done == null || doneStatus == null || "succeeded".equals(doneStatus))) {
      return new Result("succeeded", output.output(), text(), usage, null, traceId, invocationId, ms, done != null);
    }
    if (done != null) {
      if (doneStatus == null || "succeeded".equals(doneStatus)) return new Result("succeeded", text(), text(), usage, null, traceId, invocationId, ms, true);
      return new Result(doneStatus, null, text(), usage, null, traceId, invocationId, ms, true);
    }
    return new Result("failed", null, text(), usage, new AgentEvent.Error(TRUNCATED_CODE, TRUNCATED_MESSAGE, invocationId), traceId, invocationId, null, false);
  }
}
