package com.aig.ai.ecosystem.core.ws;

import java.util.List;

/** Payload of the server's {@code ready} frame. Optional fields may be null. */
public record ReadyInfo(String email, String name, String team, String env, String userTier, List<String> allowedJobProfiles) {}
