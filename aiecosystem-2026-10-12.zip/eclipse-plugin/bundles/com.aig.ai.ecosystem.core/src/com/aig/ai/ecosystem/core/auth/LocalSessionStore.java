package com.aig.ai.ecosystem.core.auth;

/**
 * Where the local-environment sign-in email lives (not a secret: the {@code dev:<email>} token is
 * accepted only by a local dev-mode backend). The plugin keeps it in instance preferences.
 */
public interface LocalSessionStore {
  String load();

  void save(String email);

  void clear();

  /** Last email signed in locally, kept after sign-out (prefills the sign-in email field); null if none. */
  default String last() {
    return load();
  }

  /** Simple in-memory implementation. */
  final class InMemory implements LocalSessionStore {
    private volatile String email;
    private volatile String last;

    @Override
    public String load() {
      return email;
    }

    @Override
    public void save(String e) {
      email = e;
      if (e != null && !e.isEmpty()) last = e;
    }

    @Override
    public String last() {
      return last;
    }

    @Override
    public void clear() {
      email = null;
    }
  }
}
