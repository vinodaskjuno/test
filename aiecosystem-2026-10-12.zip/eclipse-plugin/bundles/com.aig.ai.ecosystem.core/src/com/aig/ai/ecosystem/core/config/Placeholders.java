package com.aig.ai.ecosystem.core.config;

import java.util.regex.Pattern;

/**
 * Placeholder detection, identical to the VSIX rule: a value is "not configured" when it is
 * missing, blank, starts with {@code __REPLACE_ME} or contains a {@code __TOKEN__} placeholder such
 * as {@code https://__AIG_BACKEND_URL_DEV__}.
 */
public final class Placeholders {
  private static final Pattern TOKEN = Pattern.compile("__[A-Za-z0-9][A-Za-z0-9_]*__");

  private Placeholders() {}

  public static boolean isPlaceholder(String value) {
    if (value == null) return true;
    String v = value.trim();
    if (v.isEmpty()) return true;
    if (v.startsWith("__REPLACE_ME")) return true;
    return TOKEN.matcher(v).find();
  }
}
