package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * "Register existing agent": an agent record ({@code POST /api/v1/agents}) plus one HTTPS version
 * ({@code POST /api/v1/agents/{id}/versions}, protocol {@code aig-http/1}). Validation mirrors
 * platform-api (routes/agents.py {@code _version_problem}, agent_secrets.py) so the wizard can say what is
 * wrong before anything is sent.
 *
 * <p>Credentials: only a <em>reference</em> to the agent's credentials is ever accepted, a Secrets Manager
 * ARN ({@code arn:aws:secretsmanager:...:secret:...}) or, for {@code env=local} only, {@code local:<NAME>}.
 * There is no field for a secret value.
 */
public final class AgentRegistration {
  public static final List<String> AUTH_TYPES = List.of("none", "api_key", "oauth_client_credentials");
  /** agent_secrets.py ARN_RE. */
  public static final Pattern SECRET_ARN = Pattern.compile("^arn:aws[a-z-]*:secretsmanager:[a-z0-9-]+:[0-9]{12}:secret:[A-Za-z0-9/_+=.@-]{1,512}$");
  /** agent_secrets.py LOCAL_REF_RE (env local only). */
  public static final Pattern LOCAL_SECRET = Pattern.compile("^local:[A-Z][A-Z0-9_]{0,127}$");
  public static final int MAX_SCHEMA_BYTES = 64 * 1024;
  private static final Set<String> LOOPBACK = Set.of("localhost", "127.0.0.1", "::1", "[::1]");

  private AgentRegistration() {}

  /** The version body. {@code inputSchema} may be null. */
  public record VersionSpec(String version, String env, String endpoint, String authType, String secretArn, Map<String, Object> inputSchema) {
    public Map<String, Object> toJson() {
      Json.Obj auth = Json.object().put("type", authType == null ? "none" : authType);
      if (secretArn != null && !secretArn.isBlank() && !"none".equals(authType)) auth.put("secret_arn", secretArn.trim());
      Json.Obj b = Json.object().put("kind", "https").put("endpoint", endpoint.trim()).put("env", env).put("version", version.trim())
          .put("protocol", "aig-http/1");
      if (inputSchema != null) b.put("input_schema", inputSchema);
      b.put("auth", auth.map());
      return b.map();
    }
  }

  /** Comma/space separated tags -> list (lower-cased, de-duplicated). */
  public static List<String> parseTags(String text) {
    List<String> out = new ArrayList<>();
    if (text == null) return out;
    for (String t : text.split("[,\\s]+")) {
      String tag = t.trim().toLowerCase(Locale.ROOT);
      if (!tag.isEmpty() && !out.contains(tag)) out.add(tag);
    }
    return out;
  }

  public static String agentProblem(String agentId, String name, String description, List<String> tags) {
    if (!AgentIds.agentId(agentId)) return "Agent id must match [A-Za-z0-9._-]{1,64}.";
    if (name != null && name.length() > 200) return "Name is longer than 200 characters.";
    if (description != null && description.length() > 500) return "Description is longer than 500 characters.";
    if (tags != null) {
      if (tags.size() > AgentIds.MAX_TAGS) return "At most " + AgentIds.MAX_TAGS + " tags.";
      for (String t : tags) if (!AgentIds.TAG.matcher(t).matches()) return "Tag '" + t + "' must match [a-z0-9][a-z0-9._-]{0,31}.";
    }
    return null;
  }

  /** Endpoint rule: https (plain http only to a loopback host with env local), no credentials, query or fragment. */
  public static String endpointProblem(String endpoint, String env) {
    if (endpoint == null || endpoint.isBlank()) return "Endpoint is required (the agent's base URL, https://...).";
    URI u;
    try {
      u = new URI(endpoint.trim());
    } catch (URISyntaxException e) {
      return "Endpoint is not a valid URL.";
    }
    if (u.getHost() == null || !u.isAbsolute()) return "Endpoint must be an absolute URL.";
    if (u.getRawUserInfo() != null || u.getRawQuery() != null || u.getRawFragment() != null) return "Endpoint must not contain credentials, a query or a fragment.";
    String scheme = u.getScheme().toLowerCase(Locale.ROOT);
    boolean loopback = LOOPBACK.contains(u.getHost().toLowerCase(Locale.ROOT));
    if ("http".equals(scheme) && loopback && "local".equals(env)) return null;
    if (!"https".equals(scheme)) return "Endpoint must use https:// (http://localhost only for env local).";
    if (loopback && !"local".equals(env)) return "Loopback endpoints are only accepted for env local.";
    return null;
  }

  /** Secret reference rule; never accepts anything that is not an ARN / local reference. */
  public static String secretProblem(String authType, String secretArn, String env) {
    if (!AUTH_TYPES.contains(authType)) return "Auth type must be one of " + AUTH_TYPES + ".";
    String ref = secretArn == null ? "" : secretArn.trim();
    if ("none".equals(authType)) return ref.isEmpty() ? null : "Leave the secret ARN empty when the auth type is none.";
    if (SECRET_ARN.matcher(ref).matches()) return null;
    if ("local".equals(env) && LOCAL_SECRET.matcher(ref).matches()) return null;
    return "Enter the Secrets Manager secret ARN (arn:aws:secretsmanager:<region>:<account>:secret:aig/<env>/agents/<id>/invoke-auth)"
        + ("local".equals(env) ? " or local:<NAME>" : "") + ". Never paste the secret itself.";
  }

  /** Parses a pasted / loaded input schema: empty = none, otherwise it must be a JSON object. */
  public static Map<String, Object> parseSchema(String text) throws IllegalArgumentException {
    if (text == null || text.isBlank()) return null;
    if (text.length() > MAX_SCHEMA_BYTES) throw new IllegalArgumentException("Input schema exceeds " + MAX_SCHEMA_BYTES + " bytes.");
    Object v;
    try {
      v = Json.parse(text.trim());
    } catch (Json.JsonException e) {
      throw new IllegalArgumentException("Input schema is not valid JSON: " + e.getMessage());
    }
    Map<String, Object> o = Json.asObject(v);
    if (o == null) throw new IllegalArgumentException("Input schema must be a JSON object (a JSON Schema).");
    Object type = o.get("type");
    if (type != null && !(type instanceof String) && Json.asList(type) == null) throw new IllegalArgumentException("Input schema: 'type' must be a string or an array.");
    return o;
  }

  public static String versionProblem(VersionSpec s) {
    if (s.version() == null || !AgentIds.version(s.version().trim())) return "Version must match [A-Za-z0-9][A-Za-z0-9._+-]{0,127}, e.g. 1.0.0.";
    if (!AgentIds.env(s.env())) return "Environment must be one of " + AgentIds.ENVS + ".";
    String p = endpointProblem(s.endpoint(), s.env());
    if (p != null) return p;
    return secretProblem(s.authType(), s.secretArn(), s.env());
  }
}
