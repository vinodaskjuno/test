package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.auth.AuthService;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.http.BackendException;
import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.http.ContractHeaders;
import com.aig.ai.ecosystem.core.json.Json;
import com.aig.ai.ecosystem.core.ws.AigSocket;
import com.aig.ai.ecosystem.core.ws.LiveStatus;
import com.aig.ai.ecosystem.core.ws.ReadyInfo;
import com.aig.ai.ecosystem.core.ws.ServerFrame;
import com.aig.ai.ecosystem.core.ws.WsProtocol;
import com.aig.ai.ecosystem.core.ws.WsTransport;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Live connection to the AIG backend shared by the AIG view and the dashboard (port of
 * vscode-extension/src/live.ts, without any Eclipse API). Owns the WebSocket lifecycle (start on
 * sign-in, stop on sign-out or environment change), keeps the latest token usage, routes chat
 * streams. Usage is the signed-in user's own ({@code GET /api/v1/usage/dashboard} /
 * {@code usage.subscribe}, answered once) and is fetched only on sign-in, when a widget opens with
 * nothing loaded, on a range change and on an explicit refresh: there is no polling and no automatic
 * refetch. While the socket is down a request is one HTTP GET. The usage limits
 * ({@code GET /api/v1/usage/limits}, always HTTP) load together with the usage: on sign-in / when a widget opens
 * with nothing loaded ({@code refresh=false}) and on a range change or explicit refresh ({@code refresh=true});
 * never on a timer, a reconnect or after a chat. Every host to widget message is broadcast as JSON text to the
 * registered listeners.
 */
public final class LiveService {

  private final Supplier<ResolvedConfig> config;
  private final AuthService auth;
  private final WsTransport transport;
  private final AigSocket.Scheduler scheduler;
  private final Function<ResolvedConfig, BackendClient> clients;
  private final Executor background;
  private final Consumer<String> log;
  private final List<Consumer<String>> listeners = new CopyOnWriteArrayList<>();
  private final List<Consumer<Boolean>> signedInListeners = new CopyOnWriteArrayList<>();
  private final List<Runnable> statusListeners = new CopyOnWriteArrayList<>();

  private AigSocket sock;
  private String key = "";
  private ReadyInfo ready;
  private Map<String, Object> session;
  private LiveStatus status = LiveStatus.IDLE;
  private String statusDetail;
  private Integer usageRange;
  private Map<String, Object> usage;
  private String[] usageError;
  private int range = 30;
  /** Latest {@code GET /api/v1/usage/limits} body, or the error ({code, message}) of the last load. */
  private Map<String, Object> limits;
  private String[] limitsError;
  /** A usage limits request is running. */
  private boolean limitsPending;
  private boolean signedIn;
  /** An HTTP usage request is running. */
  private boolean httpPending;
  private boolean disposed;
  /** TEMPORARY demo-data mode (docs/demo-data.md): while on, "signed in" is {@link #demoSession} and no socket runs. */
  private volatile BooleanSupplier demoMode = () -> false;
  private volatile boolean demoSession;

  public LiveService(Supplier<ResolvedConfig> config, AuthService auth, WsTransport transport, AigSocket.Scheduler scheduler,
      Function<ResolvedConfig, BackendClient> clients, Executor background, Consumer<String> log) {
    this.config = config;
    this.auth = auth;
    this.transport = transport;
    this.scheduler = scheduler;
    this.clients = clients;
    this.background = background;
    this.log = log == null ? s -> {} : log;
  }

  public void addListener(Consumer<String> l) {
    listeners.add(l);
  }

  public void removeListener(Consumer<String> l) {
    listeners.remove(l);
  }

  public void addSignedInListener(Consumer<Boolean> l) {
    signedInListeners.add(l);
  }

  public void removeSignedInListener(Consumer<Boolean> l) {
    signedInListeners.remove(l);
  }

  /** Called whenever the connection status changes (status line). */
  public void addStatusListener(Runnable r) {
    statusListeners.add(r);
  }

  public void removeStatusListener(Runnable r) {
    statusListeners.remove(r);
  }

  /**
   * TEMPORARY demo-data switch (docs/demo-data.md). While {@code on} answers true the pages show sample data
   * from their in-page demo host: sign-in is a demo session ({@link #setDemoSession}), no socket or backend call.
   */
  public void setDemoMode(BooleanSupplier on) {
    demoMode = on == null ? () -> false : on;
  }

  public boolean isDemo() {
    return demoMode.getAsBoolean();
  }

  /** Starts / ends the demo session (demo mode only) and re-syncs, which notifies the signed-in listeners. */
  public void setDemoSession(boolean signedIn) {
    demoSession = signedIn;
    sync();
  }

  public synchronized boolean isSignedIn() {
    return signedIn;
  }

  public synchronized LiveStatus status() {
    return status;
  }

  public synchronized String statusDetail() {
    return statusDetail;
  }

  public synchronized int range() {
    return range;
  }

  /** Team of the signed-in user (from the WebSocket ready frame or /api/v1/session), or null. */
  public synchronized String team() {
    if (ready != null && ready.team() != null) return ready.team();
    return Json.str(session, "team");
  }

  public synchronized String user() {
    if (ready != null) return ready.email();
    Map<String, Object> u = Json.obj(session, "user");
    String e = Json.str(u, "email");
    return e != null ? e : auth.account(config.get());
  }

  private void emit(String msg) {
    for (Consumer<String> l : listeners) {
      try {
        l.accept(msg);
      } catch (RuntimeException e) {
        log.accept("[live] listener failed: " + e);
      }
    }
  }

  /** Messages a freshly loaded widget needs to catch up. */
  public synchronized List<String> snapshot() {
    List<String> out = new ArrayList<>();
    out.add(HostMessages.init(initInfo()));
    out.add(HostMessages.live(status, statusDetail));
    if (usage != null && usageRange != null && usageRange == range) out.add(HostMessages.usage(range, usage));
    else if (usageError != null) out.add(HostMessages.usageError(usageError[0], usageError[1]));
    else out.add(HostMessages.usageLoading());
    if (limits != null) out.add(HostMessages.usageLimits(limits));
    else if (limitsError != null) out.add(HostMessages.usageLimitsError(limitsError[0], limitsError[1]));
    return out;
  }

  public synchronized HostMessages.InitInfo initInfo() {
    ResolvedConfig cfg = config.get();
    String user = ready != null ? ready.email() : Json.str(Json.obj(session, "user"), "email");
    if (user == null && signedIn) user = auth.account(cfg);
    String tier = ready != null && ready.userTier() != null ? ready.userTier() : Json.str(session, "user_tier");
    String costMode = Json.str(session, "cost_mode");
    if (costMode != null && costMode.isEmpty()) costMode = null;
    String team = ready != null && ready.team() != null ? ready.team() : Json.str(session, "team");
    List<String> profiles = ready != null && !ready.allowedJobProfiles().isEmpty() ? ready.allowedJobProfiles()
        : session != null && !Json.strings(session.get("allowed_job_profiles")).isEmpty() ? Json.strings(session.get("allowed_job_profiles"))
        : List.of(cfg.jobProfile());
    return new HostMessages.InitInfo(cfg.env().id(), user, tier, costMode, team, cfg.jobProfile(), profiles, range);
  }

  public void setRange(int days) {
    if (days != 7 && days != 30 && days != 90) return;
    String init;
    synchronized (this) {
      range = days;
      usageError = null;
      init = HostMessages.init(initInfo());
    }
    emit(init);
    emit(HostMessages.usageLoading());
    requestUsage(true);
    requestLimits(true);
  }

  /** Explicit refresh (refresh button): always fetches again (usage and usage limits). */
  public void refreshUsage() {
    requestUsage(true);
    requestLimits(true);
  }

  /**
   * Loads usage when nothing is loaded, failed or requested for the current range (a widget opened);
   * otherwise does nothing, so opening views never refetches.
   */
  public void ensureUsage() {
    ensureLimits();
    synchronized (this) {
      if (!signedIn || httpPending) return;
      if (usage != null && usageRange != null && usageRange == range) return;
      if (usageError != null) return;
      if (sock != null && sock.pendingUsage() != null && sock.pendingUsage() == range) return;
    }
    requestUsage(false);
  }

  /** Starts a streamed chat over the WebSocket; throws if it is not open. */
  public String chat(List<ChatMessage> messages, String jobProfile, AigSocket.ChatHandlers handlers) {
    AigSocket s;
    synchronized (this) {
      s = sock;
    }
    if (s == null || !s.isOpen()) throw new IllegalStateException("Not connected to the AIG backend (WebSocket). Check the connection and try again.");
    return s.chat(messages, handlers, jobProfile, ContractHeaders.ECLIPSE_AGENT_ID);
  }

  public void cancel(String id) {
    AigSocket s;
    synchronized (this) {
      s = sock;
    }
    if (s != null) s.cancel(id);
  }

  /**
   * Re-evaluates the configuration and session: (re)starts or stops the socket as needed. Call it
   * after sign-in, sign-out, environment or preference changes.
   */
  public void sync() {
    ResolvedConfig cfg = config.get();
    boolean demo = demoMode.getAsBoolean();
    boolean nowSignedIn = demo ? demoSession : cfg.configured() && cfg.backendUrl() != null && auth.hasSession(cfg);
    boolean changed;
    String newKey = !nowSignedIn ? "" : demo ? "demo|" + cfg.env().id()
        : cfg.env().id() + "|" + cfg.backendUrl() + "|" + cfg.auth().kind() + "|" + String.valueOf(auth.account(cfg));
    AigSocket old = null;
    AigSocket started = null;
    synchronized (this) {
      if (disposed) return;
      changed = nowSignedIn != signedIn;
      signedIn = nowSignedIn;
      if (newKey.equals(key)) {
        newKey = null; // unchanged
      } else {
        key = newKey;
        old = sock;
        sock = null;
        httpPending = false;
        usage = null;
        usageRange = null;
        usageError = null;
        limits = null;
        limitsError = null;
        limitsPending = false;
        ready = null;
        session = null;
      }
    }
    if (changed) for (Consumer<Boolean> l : signedInListeners) l.accept(nowSignedIn);
    if (newKey == null) {
      emit(HostMessages.init(initInfo()));
      return;
    }
    if (old != null) old.stop();
    if (!nowSignedIn) {
      setStatus(LiveStatus.IDLE, null);
      return;
    }
    if (demo) {
      setStatus(LiveStatus.OPEN, "sample data");
      return;
    }
    emit(HostMessages.usageLoading()); // a new session (or another user): the previous user's usage is gone
    started = new AigSocket(WsProtocol.wsUrl(cfg.backendUrl()), () -> auth.accessToken(config.get()), transport, new AigSocket.Events() {
      @Override
      public void onStatus(LiveStatus s, String detail) {
        setStatus(s, detail);
      }

      @Override
      public void onReady(ReadyInfo info) {
        synchronized (LiveService.this) {
          ready = info;
        }
        emit(HostMessages.init(initInfo()));
      }

      @Override
      public void onFrame(ServerFrame f) {
        onServerFrame(f);
      }
    }, scheduler);
    int r;
    synchronized (this) {
      sock = started;
      r = range;
    }
    started.requestUsage(r); // the session's one usage load (sent when the socket opens)
    started.start();
    emit(HostMessages.init(initInfo()));
    background.execute(this::loadSession);
    requestLimits(false); // the session's one usage limits load
  }

  private void loadSession() {
    BackendClient c = client();
    if (c == null) return;
    try {
      Map<String, Object> s = c.session();
      synchronized (this) {
        session = s;
      }
      emit(HostMessages.init(initInfo()));
    } catch (BackendException e) {
      log.accept("[live] session: " + e.getMessage());
    }
  }

  private void onServerFrame(ServerFrame f) {
    switch (f.type()) {
      case "usage": {
        boolean current;
        int r;
        synchronized (this) {
          usage = f.data();
          usageRange = f.days();
          usageError = null;
          current = f.days() == range;
          r = range;
        }
        if (current) emit(HostMessages.usage(r, f.data()));
        break;
      }
      case "usage.error":
        synchronized (this) {
          usageError = new String[] {f.code(), f.message()};
        }
        emit(HostMessages.usageError(f.code(), f.message()));
        break;
      case "error":
        log.accept("[live] backend error: " + f.code() + " " + f.message());
        break;
      default:
        break;
    }
  }

  private void setStatus(LiveStatus s, String detail) {
    synchronized (this) {
      status = s;
      statusDetail = detail;
    }
    if (s != LiveStatus.OPEN) log.accept("[live] " + s.id() + (detail != null ? ": " + detail : ""));
    emit(HostMessages.live(s, detail));
    for (Runnable r : statusListeners) r.run();
    if (s == LiveStatus.RECONNECTING || s == LiveStatus.UNAUTHORIZED) {
      // A usage request the socket could not answer becomes one HTTP GET (no polling, no retry loop).
      AigSocket so;
      synchronized (this) {
        so = sock;
      }
      if (so != null && so.cancelUsageRequest() != null) startHttpUsage();
    }
  }

  /** Fetches usage for the current range once: over the socket when it is open or still connecting, else one HTTP GET. */
  private void requestUsage(boolean force) {
    if (demoMode.getAsBoolean()) return; // demo pages get usage from their in-page demo host
    AigSocket s;
    boolean have;
    int r;
    synchronized (this) {
      if (!signedIn) return;
      s = sock;
      have = usage != null && usageRange != null && usageRange == range;
      r = range;
    }
    if (!force && have) return;
    if (s != null && (s.isOpen() || s.state() == LiveStatus.CONNECTING)) {
      s.requestUsage(r);
      return;
    }
    if (s != null) s.cancelUsageRequest();
    startHttpUsage();
  }

  private void startHttpUsage() {
    synchronized (this) {
      if (disposed) return;
      httpPending = true;
    }
    background.execute(this::httpUsage);
  }

  private BackendClient client() {
    ResolvedConfig cfg = config.get();
    if (!cfg.configured() || cfg.backendUrl() == null) return null;
    return clients.apply(cfg);
  }

  void httpUsage() {
    try {
      fetchHttpUsage();
    } finally {
      synchronized (this) {
        httpPending = false;
      }
    }
  }

  private void fetchHttpUsage() {
    BackendClient c = client();
    if (c == null) return;
    int r;
    synchronized (this) {
      r = range;
    }
    try {
      Map<String, Object> data = c.dashboard(r);
      boolean current;
      synchronized (this) {
        usage = data;
        usageRange = r;
        usageError = null;
        current = r == range;
      }
      if (current) emit(HostMessages.usage(r, data));
    } catch (BackendException e) {
      String code = e.code() == null ? "error" : e.code();
      String msg = e.describe(config.get().env().id());
      synchronized (this) {
        usageError = new String[] {code, msg};
      }
      emit(HostMessages.usageError(code, msg));
    }
  }

  /** Loads the usage limits when nothing is loaded, failed or running (a widget opened). */
  private void ensureLimits() {
    synchronized (this) {
      if (!signedIn || limits != null || limitsError != null || limitsPending) return;
    }
    requestLimits(false);
  }

  /** One {@code GET /api/v1/usage/limits} in the background; {@code refresh} only for a manual refresh / range change. */
  private void requestLimits(boolean refresh) {
    if (demoMode.getAsBoolean()) return; // demo pages answer usage limits from their in-page demo host
    String k;
    synchronized (this) {
      if (disposed || !signedIn) return;
      limitsPending = true;
      k = key;
    }
    background.execute(() -> fetchLimits(k, refresh));
  }

  void fetchLimits(String forKey, boolean refresh) {
    BackendClient c = client();
    String msg;
    try {
      if (c == null) {
        synchronized (this) {
          if (forKey.equals(key)) limitsPending = false;
        }
        return;
      }
      Map<String, Object> data = c.usageLimits(refresh);
      synchronized (this) {
        if (!forKey.equals(key)) return; // another session started meanwhile
        limits = data;
        limitsError = null;
        limitsPending = false;
      }
      msg = HostMessages.usageLimits(data);
    } catch (BackendException e) {
      String code = e.code() == null ? "error" : e.code();
      String text = e.describe(config.get().env().id());
      synchronized (this) {
        if (!forKey.equals(key)) return;
        limits = null;
        limitsError = new String[] {code, text};
        limitsPending = false;
      }
      msg = HostMessages.usageLimitsError(code, text);
    } catch (RuntimeException e) {
      synchronized (this) {
        if (forKey.equals(key)) limitsPending = false;
      }
      log.accept("[live] usage limits: " + e);
      return;
    }
    emit(msg);
  }

  public void dispose() {
    AigSocket s;
    synchronized (this) {
      disposed = true;
      s = sock;
      sock = null;
    }
    if (s != null) s.stop();
    listeners.clear();
    signedInListeners.clear();
    statusListeners.clear();
  }
}
