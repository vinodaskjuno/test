package com.aig.ai.ecosystem.core.config;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Pure settings resolution, mirroring vscode-extension/src/config.ts resolveConfig. */
public final class ConfigResolver {
  public static final Pattern EMAIL = Pattern.compile("^[^\\s@:]+@[^\\s@:]+\\.[^\\s@:]+$");
  private static final Pattern GUID_OR_DOMAIN = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9.-]{0,127}$");

  private ConfigResolver() {}

  public static boolean isValidEmail(String v) {
    return v != null && EMAIL.matcher(v).matches();
  }

  public static ResolvedConfig resolve(AigSettings raw) {
    AigEnvironment env = AigEnvironment.normalize(raw.environment());
    EnvSettings es = raw.env(env);
    List<String> problems = new ArrayList<>();

    UrlCheck url = BackendUrls.validate(es.backendUrl(), env);
    if (!url.ok()) problems.add("backend URL for " + env.id() + ": " + url.reason());

    AuthPlan auth;
    String devUser = raw.devUser() == null ? "" : raw.devUser().trim();
    if (env == AigEnvironment.LOCAL) {
      // SSO is skipped locally. The dev user is an optional shortcut; otherwise browser sign-in.
      if (devUser.isEmpty()) auth = AuthPlan.localBrowser();
      else auth = isValidEmail(devUser) ? AuthPlan.dev(devUser) : AuthPlan.unconfigured("dev user is not a valid email");
    } else {
      auth = entra(env, es);
    }
    if (auth.kind() == AuthPlan.Kind.UNCONFIGURED) problems.add(auth.reason());

    return new ResolvedConfig(env, url.ok() ? url.url() : null, problems.isEmpty(), auth, JobProfiles.normalize(raw.jobProfile()), List.copyOf(problems));
  }

  private static AuthPlan entra(AigEnvironment env, EnvSettings es) {
    List<String> missing = new ArrayList<>();
    if (Placeholders.isPlaceholder(es.tenantId())) missing.add("tenant id");
    else if (!GUID_OR_DOMAIN.matcher(es.tenantId().trim()).matches()) return AuthPlan.unconfigured("Entra tenant id for " + env.id() + " is invalid");
    if (Placeholders.isPlaceholder(es.clientId())) missing.add("client id");
    else if (!GUID_OR_DOMAIN.matcher(es.clientId().trim()).matches()) return AuthPlan.unconfigured("Entra client id for " + env.id() + " is invalid");
    if (Placeholders.isPlaceholder(es.scope())) missing.add("scope");
    if (!missing.isEmpty()) return AuthPlan.unconfigured("Entra " + String.join(", ", missing) + " for " + env.id() + ": placeholder");
    String authorityRaw = Placeholders.isPlaceholder(es.authority()) ? EnvSettings.DEFAULT_AUTHORITY : es.authority();
    // The authority is always https, even for local testing (never loopback http).
    UrlCheck authority = BackendUrls.validate(authorityRaw, AigEnvironment.PROD);
    if (!authority.ok()) return AuthPlan.unconfigured("Entra authority for " + env.id() + ": " + authority.reason());
    String scope = es.scope().trim();
    if (scope.contains("\n") || scope.contains("\r")) return AuthPlan.unconfigured("Entra scope for " + env.id() + " is invalid");
    return AuthPlan.microsoft(new AuthPlan.EntraConfig(authority.url(), es.tenantId().trim(), es.clientId().trim(), scope));
  }
}
