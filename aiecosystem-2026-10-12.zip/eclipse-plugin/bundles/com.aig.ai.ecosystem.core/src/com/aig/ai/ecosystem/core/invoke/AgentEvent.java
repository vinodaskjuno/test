package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.http.SseEvent;
import com.aig.ai.ecosystem.core.json.Json;
import java.util.Map;

/**
 * One event of an agent invocation stream ({@code mode=stream}, backend/contracts/agent-invocation.md):
 * {@code delta {text}}, {@code output {output, usage?, trace_id?}}, {@code error {code, message}},
 * {@code done {status?, duration_ms?}}. platform-api adds {@code invocation_id} to every event (null when absent).
 */
public sealed interface AgentEvent {
  String invocationId();

  record Delta(String text, String invocationId) implements AgentEvent {}

  record Output(Object output, Map<String, Object> usage, String traceId, String invocationId) implements AgentEvent {}

  record Error(String code, String message, String invocationId) implements AgentEvent {}

  record Done(String status, Long durationMs, String invocationId) implements AgentEvent {}

  /** Maps an SSE event; null for unknown events and malformed data (both ignored, as the contract says). */
  static AgentEvent from(SseEvent ev) {
    if (ev == null || ev.event() == null) return null;
    Map<String, Object> d = Json.parseObject(ev.data());
    if (d == null) return null;
    String inv = Json.str(d, "invocation_id");
    switch (ev.event()) {
      case "delta": {
        String text = Json.str(d, "text");
        return text == null ? null : new Delta(text, inv);
      }
      case "output":
        return d.containsKey("output") ? new Output(d.get("output"), Usage.clean(d.get("usage")), Json.str(d, "trace_id"), inv) : null;
      case "error": {
        String code = Json.str(d, "code");
        String message = Json.str(d, "message");
        return new Error(code == null ? "agent_error" : code, message == null ? (code == null ? "agent error" : code) : message, inv);
      }
      case "done": {
        Object ms = d.get("duration_ms");
        return new Done(Json.str(d, "status"), ms instanceof Long ? (Long) ms : null, inv);
      }
      default:
        return null;
    }
  }
}
