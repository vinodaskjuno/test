package com.aig.ai.ecosystem.core.agents;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The {@code aig} CLI (sdk/python aig_sdk/cli.py): PATH lookup and command lines. The plugin passes
 * no secret to it; registration is done by the plugin through platform-api with the user's own token.
 */
public final class AigCli {
  private AigCli() {}

  /** Finds an executable named {@code name} on {@code PATH} (honours PATHEXT on Windows). */
  public static Path find(String name, Map<String, String> env) {
    String path = env.getOrDefault("PATH", env.getOrDefault("Path", ""));
    boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    List<String> exts = new ArrayList<>();
    exts.add("");
    if (windows) for (String e : env.getOrDefault("PATHEXT", ".EXE;.CMD;.BAT").split(";")) if (!e.isEmpty()) exts.add(e.toLowerCase(Locale.ROOT));
    for (String dir : path.split(File.pathSeparator)) {
      if (dir.isEmpty()) continue;
      for (String ext : exts) {
        Path p = Path.of(dir, name + ext);
        if (Files.isRegularFile(p) && Files.isExecutable(p)) return p;
      }
    }
    return null;
  }

  /**
   * {@code aig init <template> <dir> --agent-id <id> --team <team> --description <d> --no-register --no-install}
   * (the plugin registers the agent itself, with the signed-in user's token, and creates the
   * environment itself with {@link SdkSetup} so the console shows each step). Needs aig-sdk 0.1.0+
   * with {@code --no-install} support; New Agent uses the built-in scaffolder.
   */
  public static List<String> initCommand(Path aig, String template, Path dir, String agentId, String team, String description, String templatesDir) {
    List<String> cmd = new ArrayList<>(List.of(aig.toString(), "init", template, dir.toString(), "--agent-id", agentId, "--team", team));
    if (description != null && !description.isBlank()) {
      cmd.add("--description");
      cmd.add(description.trim());
    }
    if (templatesDir != null) {
      cmd.add("--templates-dir");
      cmd.add(templatesDir);
    }
    cmd.add("--no-register");
    cmd.add("--no-install");
    return cmd;
  }

  /** {@code aig eval run --md <report.md> --out <report.json> [--offline]} in the agent project. */
  public static List<String> evalCommand(Path aig, Path markdownOut, Path jsonOut, boolean offline) {
    List<String> cmd = new ArrayList<>(List.of(aig.toString(), "eval", "run", "--md", markdownOut.toString(), "--out", jsonOut.toString()));
    if (offline) cmd.add("--offline");
    return cmd;
  }
}
