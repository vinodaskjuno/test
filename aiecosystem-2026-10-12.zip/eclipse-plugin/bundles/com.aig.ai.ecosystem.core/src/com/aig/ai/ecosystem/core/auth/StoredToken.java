package com.aig.ai.ecosystem.core.auth;

/**
 * The plugin's own Entra ID session for one environment (kept in Eclipse Secure Storage). There is
 * never a Portkey or provider key here.
 *
 * @param expiresAt epoch seconds
 * @param account display name of the signed-in account (from the ID token's preferred_username)
 */
public record StoredToken(String accessToken, String refreshToken, long expiresAt, String account) {
  public boolean expiresWithin(long nowEpochSec, long seconds) {
    return expiresAt - nowEpochSec <= seconds;
  }

  @Override
  public String toString() {
    return "StoredToken[account=" + account + ", expiresAt=" + expiresAt + ", accessToken=***, refreshToken=" + (refreshToken == null ? "none" : "***") + "]";
  }
}
