package com.aig.ai.ecosystem.core.auth;

import com.aig.ai.ecosystem.core.config.AigEnvironment;
import java.io.IOException;
import org.eclipse.equinox.security.storage.ISecurePreferences;
import org.eclipse.equinox.security.storage.SecurePreferencesFactory;
import org.eclipse.equinox.security.storage.StorageException;

/**
 * {@link TokenStore} in Eclipse Secure Storage ({@code /com.aig.ai.ecosystem/<env>}), values
 * encrypted. Only the plugin's own Entra ID access/refresh token is stored; never a Portkey key.
 */
public final class SecureStorageTokenStore implements TokenStore {
  static final String ROOT = "com.aig.ai.ecosystem";
  private final ISecurePreferences root;

  public SecureStorageTokenStore() {
    this(SecurePreferencesFactory.getDefault());
  }

  public SecureStorageTokenStore(ISecurePreferences prefs) {
    if (prefs == null) throw new IllegalStateException("Eclipse secure storage is not available");
    this.root = prefs.node(ROOT);
  }

  private ISecurePreferences node(AigEnvironment env) {
    return root.node(env.id());
  }

  @Override
  public StoredToken load(AigEnvironment env) {
    if (!root.nodeExists(env.id())) return null;
    ISecurePreferences n = node(env);
    try {
      String access = n.get("access_token", null);
      if (access == null || access.isEmpty()) return null;
      String refresh = n.get("refresh_token", null);
      long exp = Long.parseLong(n.get("expires_at", "0"));
      return new StoredToken(access, refresh == null || refresh.isEmpty() ? null : refresh, exp, n.get("account", null));
    } catch (StorageException | NumberFormatException e) {
      return null;
    }
  }

  @Override
  public void save(AigEnvironment env, StoredToken token) {
    ISecurePreferences n = node(env);
    try {
      n.put("access_token", token.accessToken(), true);
      n.put("refresh_token", token.refreshToken() == null ? "" : token.refreshToken(), true);
      n.put("expires_at", Long.toString(token.expiresAt()), false);
      n.put("account", token.account() == null ? "" : token.account(), false);
      root.flush();
    } catch (StorageException | IOException e) {
      throw new IllegalStateException("could not save the sign-in token to secure storage: " + e.getMessage(), e);
    }
  }

  @Override
  public void clear(AigEnvironment env) {
    if (!root.nodeExists(env.id())) return;
    node(env).removeNode();
    try {
      root.flush();
    } catch (IOException ignored) {
      // best effort
    }
  }
}
