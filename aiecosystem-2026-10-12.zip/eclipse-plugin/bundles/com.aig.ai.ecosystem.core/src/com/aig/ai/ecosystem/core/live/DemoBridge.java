package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.json.Json;

/**
 * TEMPORARY demo-data mode (docs/demo-data.md): the Java side of a page whose widgets are answered by the
 * in-page demo host ({@code eclipse-plugin/web/src/demoHost.ts}) instead of {@link WidgetBridge} /
 * {@link AgentBridge}. The page only posts what needs Eclipse: host commands (ready, signIn, signOut,
 * openDashboard, openPanel, selectEnvironment) and cross-view agent navigation (agent.open, agent.run.show,
 * agent.register, clipboard.copy). Nothing here calls the backend; the Run view gets {@code demo.open} /
 * {@code demo.show} host messages that the page resolves against its sample catalog. No Eclipse API, so it
 * is unit tested headless. Delete this class (and its BrowserPane branch) to drop demo mode.
 */
public final class DemoBridge {
  private final WidgetBridge.Commands commands;
  private final AgentBridge.Host host;
  private volatile boolean disposed;

  public DemoBridge(WidgetBridge.Commands commands, AgentBridge.Host host) {
    this.commands = commands;
    this.host = host;
  }

  /** Handles one raw message posted by the page. Returns false when it was rejected or is answered in the page. */
  public boolean receive(String raw) {
    if (disposed) return false;
    WebviewMessage w = WebviewMessage.parse(raw);
    if (w != null) {
      switch (w.cmd()) {
        case "ready":
        case "signIn":
        case "signOut":
        case "openDashboard":
        case "openPanel":
        case "selectEnvironment":
          commands.run(w.cmd());
          return true;
        default:
          return false; // range, refresh, chat.*: answered by the page's demo host
      }
    }
    AgentMessage m = AgentMessage.parse(raw);
    if (m == null) return false;
    switch (m.cmd()) {
      case "agent.open":
        host.openRun(open(m.agentId(), m.env(), m.version()));
        return true;
      case "agent.run.show":
        host.showRun(m.invocationId());
        return true;
      case "agent.register":
        host.register();
        return true;
      case "clipboard.copy":
        host.copy(m.text());
        return true;
      default:
        return false; // catalog / runs / invoke / cancel / poll: answered by the page's demo host
    }
  }

  /** {@code demo.open}: the page's demo host resolves it to {@code agent.target} from the sample catalog. */
  public static String open(String agentId, String env, String version) {
    return Json.object().put("type", "demo.open").put("agentId", agentId).opt("env", env).opt("version", version).toString();
  }

  /** {@code demo.show}: the page's demo host shows that sample invocation (target, status, output). */
  public static String show(String invocationId) {
    return Json.object().put("type", "demo.show").put("invocationId", invocationId).toString();
  }

  /** True for a {@code demo.open} message (AgentRunView: part name from {@code agentId}). */
  public static boolean isOpen(String message) {
    return "demo.open".equals(Json.str(Json.parseObject(message), "type"));
  }

  public void dispose() {
    disposed = true;
  }
}
