/** AIG core: ws. */
package com.aig.ai.ecosystem.core.ws;
