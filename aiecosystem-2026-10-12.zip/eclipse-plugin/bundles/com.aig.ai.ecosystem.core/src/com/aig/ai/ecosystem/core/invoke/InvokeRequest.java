package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Client body of {@code POST /api/v1/agents/{id}/invoke}: exactly one of {@code input} (structured, validated
 * server-side against the version's input schema) or {@code messages} (chat mode), optional session id.
 */
public record InvokeRequest(Map<String, Object> input, List<ChatMessage> messages, String sessionId) {
  public InvokeRequest {
    if ((input == null) == (messages == null || messages.isEmpty())) throw new IllegalArgumentException("exactly one of input or messages");
    if (sessionId != null && !AgentIds.SESSION_ID.matcher(sessionId).matches()) throw new IllegalArgumentException("invalid session id");
  }

  public static InvokeRequest input(Map<String, Object> input) {
    return new InvokeRequest(input, null, null);
  }

  public static InvokeRequest chat(List<ChatMessage> messages) {
    return new InvokeRequest(null, messages, null);
  }

  public Map<String, Object> toJson() {
    Json.Obj b = Json.object();
    if (input != null) {
      b.put("input", input);
    } else {
      List<Object> ms = new ArrayList<>();
      for (ChatMessage m : messages) ms.add(m.toJson());
      b.put("messages", ms);
    }
    b.opt("session_id", sessionId);
    return b.map();
  }
}
