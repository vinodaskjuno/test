package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.Map;

/**
 * One registered version of an agent: a catalog version ({@code GET /api/v1/catalog}) or a registry
 * version ({@code GET /api/v1/agents/{id}/versions}). Fields the source does not carry are null.
 */
public record AgentVersionInfo(String env, String version, String kind, boolean verified, String verifiedAt, Map<String, Object> inputSchema,
    Map<String, Object> outputSchema, String endpoint, String protocol, String status) {

  /** Parses a snake_case version object; null when env/version are missing or invalid. */
  public static AgentVersionInfo from(Object raw) {
    Map<String, Object> v = Json.asObject(raw);
    if (v == null) return null;
    String env = Json.str(v, "env");
    String version = Json.str(v, "version");
    if (!AgentIds.env(env) || version == null || version.isEmpty()) return null;
    String kind = Json.str(v, "kind");
    Object verified = v.get("verified");
    boolean ok = Boolean.TRUE.equals(verified) || (verified == null && Json.str(v, "verified_at") != null);
    return new AgentVersionInfo(env, version, kind == null ? "https" : kind, ok, Json.str(v, "verified_at"), Json.obj(v, "input_schema"),
        Json.obj(v, "output_schema"), Json.str(v, "endpoint"), Json.str(v, "protocol"), Json.str(v, "status"));
  }

  /** web/packages/ui {@code CatalogVersion} (camelCase). */
  public Map<String, Object> toWidget() {
    return Json.object().put("env", env).put("version", version).put("kind", kind).put("verified", verified).put("verifiedAt", verifiedAt)
        .put("inputSchema", inputSchema).put("outputSchema", outputSchema).map();
  }
}
