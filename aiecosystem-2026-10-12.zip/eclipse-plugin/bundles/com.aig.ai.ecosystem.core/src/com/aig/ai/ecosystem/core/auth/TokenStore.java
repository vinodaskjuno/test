package com.aig.ai.ecosystem.core.auth;

import com.aig.ai.ecosystem.core.config.AigEnvironment;

/** Storage for the Entra ID token per environment. */
public interface TokenStore {
  StoredToken load(AigEnvironment env);

  void save(AigEnvironment env, StoredToken token);

  void clear(AigEnvironment env);
}
