package com.aig.ai.ecosystem.core.live;

import com.aig.ai.ecosystem.core.http.BackendClient;
import com.aig.ai.ecosystem.core.http.BackendException;
import com.aig.ai.ecosystem.core.invoke.AgentEvent;
import com.aig.ai.ecosystem.core.invoke.AgentStream;
import com.aig.ai.ecosystem.core.invoke.AgentStreamListener;
import com.aig.ai.ecosystem.core.invoke.AgentVersionInfo;
import com.aig.ai.ecosystem.core.invoke.Cancellation;
import com.aig.ai.ecosystem.core.invoke.Catalog;
import com.aig.ai.ecosystem.core.invoke.CatalogAgent;
import com.aig.ai.ecosystem.core.invoke.Invocation;
import com.aig.ai.ecosystem.core.invoke.InvocationAccepted;
import com.aig.ai.ecosystem.core.invoke.InvokeRequest;
import com.aig.ai.ecosystem.core.ws.AigSocket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * The agent half of the WidgetHost contract seen from Java (catalog + run widgets of web/packages/ui):
 * handles validated {@link AgentMessage}s with the platform-api client (the signed-in user's token only) and
 * answers with {@code catalog*} / {@code agent.*} host messages. Blocking calls run on {@code background};
 * background runs are polled through {@code scheduler}. No Eclipse API, so it is unit tested headless; the
 * plugin supplies the {@link Host} (open the Run view, the Register wizard, clipboard, notifications).
 */
public final class AgentBridge {
  /** UI actions of the embedding host. Called from background threads; implementations switch to the UI thread. */
  public interface Host {
    /** Open / focus the run surface and deliver this host message ({@code agent.target} or {@code agent.target.error}). */
    void openRun(String targetMessage);

    /** Open the "Register existing agent" wizard. */
    void register();

    /** Open the run surface and show this invocation there (status, output). */
    void showRun(String invocationId);

    void copy(String text);

    /** A background run reached a final status (notification / status line). {@code name} may equal the id. */
    default void runFinished(String agentId, String name, String status, String invocationId) {}
  }

  public static final long POLL_MS = 3000;
  static final int MAX_POLL_FAILURES = 5;
  static final int RECENT_LIMIT = 20;

  private static final class Run {
    final String localId;
    final String agentId;
    final String mode;
    final String env;
    final String version;
    final Cancellation cancel = new Cancellation();
    volatile String invocationId;
    volatile AigSocket.Cancellable poll;
    volatile boolean finished;
    volatile boolean outputSent;
    volatile boolean errorSent;
    int pollFailures;

    Run(String localId, String agentId, String mode, String env, String version) {
      this.localId = localId;
      this.agentId = agentId;
      this.mode = mode;
      this.env = env;
      this.version = version;
    }
  }

  private final Supplier<BackendClient> clients;
  private final Executor background;
  private final AigSocket.Scheduler scheduler;
  private final Consumer<String> send;
  private final Host host;
  private final AtomicReference<Catalog> catalogCache;
  private final Map<String, Run> runs = new ConcurrentHashMap<>();
  private volatile String lastTarget;
  private volatile boolean disposed;

  public AgentBridge(Supplier<BackendClient> clients, Executor background, AigSocket.Scheduler scheduler, Consumer<String> send, Host host,
      AtomicReference<Catalog> catalogCache) {
    this.clients = clients;
    this.background = background;
    this.scheduler = scheduler;
    this.send = m -> {
      if (!disposed) send.accept(m);
    };
    this.host = host;
    this.catalogCache = catalogCache == null ? new AtomicReference<>() : catalogCache;
  }

  /** Handles one validated agent message. */
  public boolean receive(AgentMessage m) {
    if (m == null || disposed) return false;
    switch (m.cmd()) {
      case "catalog.refresh":
        async(this::refreshCatalog);
        return true;
      case "agent.open":
        async(() -> host.openRun(resolveTarget(m.agentId(), m.env(), m.version())));
        return true;
      case "agent.register":
        host.register();
        return true;
      case "agent.runs.refresh":
        async(this::refreshRuns);
        return true;
      case "agent.run.show":
        host.showRun(m.invocationId());
        return true;
      case "agent.invoke":
        invoke(m);
        return true;
      case "agent.cancel":
        cancel(m.localId(), m.invocationId());
        return true;
      case "agent.poll": {
        // A run this bridge already polls (background runs, runs opened from history) gets its updates from that loop.
        Run tracked = runs.get(m.localId());
        if (tracked == null || tracked.finished || !m.invocationId().equals(tracked.invocationId)) async(() -> pollOnce(m.localId(), m.invocationId()));
        return true;
      }
      case "clipboard.copy":
        host.copy(m.text());
        return true;
      default:
        return false;
    }
  }

  /** Called when the page posted {@code ready}: replays the current run target, if any. */
  public void onReady() {
    String t = lastTarget;
    if (t != null) send.accept(t);
  }

  /** Delivers a run target (or target error) host message to this widget and remembers it for reloads. */
  public void showTarget(String targetMessage) {
    lastTarget = targetMessage;
    send.accept(targetMessage);
  }

  /** Shows a past or running invocation: its agent as the target, then status / output (polling until final). */
  public void showInvocation(String invocationId) {
    async(() -> {
      BackendClient c = client();
      if (c == null) return;
      try {
        Invocation inv = c.invocation(invocationId);
        showTarget(resolveTarget(inv.agentId(), inv.env(), inv.version()));
        String localId = showLocalId(invocationId);
        if (inv.isFinal()) {
          deliver(localId, inv, null);
        } else {
          Run r = new Run(localId, inv.agentId(), "background", inv.env(), inv.version());
          r.invocationId = invocationId;
          Run old = runs.put(localId, r);
          if (old != null) stopPolling(old);
          deliver(localId, inv, r);
          schedulePoll(r);
        }
      } catch (BackendException e) {
        showTarget(HostMessages.agentTargetError(code(e), message(e)));
      }
    });
  }

  /** The widget-side id used for runs opened from history ({@code show-<invocation id>}, at most 64 chars). */
  static String showLocalId(String invocationId) {
    String id = "show-" + invocationId;
    return id.length() > 64 ? id.substring(0, 64) : id;
  }

  // ------------------------------------------------------------------------------------------

  private void async(Runnable r) {
    try {
      background.execute(() -> {
        if (!disposed) r.run();
      });
    } catch (RuntimeException e) {
      // executor shut down
    }
  }

  private BackendClient client() {
    return clients.get();
  }

  static String code(BackendException e) {
    if (e.code() != null) return e.code();
    return e.status() > 0 ? "http_" + e.status() : "network_error";
  }

  static String message(BackendException e) {
    if (e.status() == 401) return "Not signed in or the session expired. Sign in again (AIG > Sign In).";
    if (e.status() == 403) return "Access denied: " + e.getMessage();
    if (e.status() == 503) return "The AIG backend is unavailable: " + e.getMessage();
    return e.getMessage() == null ? "request failed" : e.getMessage();
  }

  private static final String NOT_CONFIGURED = "not_configured";
  private static final String NOT_CONFIGURED_MSG = "The AIG backend is not configured for this environment (Window > Preferences > AIG AI Ecosystem).";

  private Catalog catalog(BackendClient c, boolean refresh) throws BackendException {
    Catalog cached = catalogCache.get();
    if (cached != null && !refresh) return cached;
    Catalog fresh = c.catalog(null, null, null);
    catalogCache.set(fresh);
    return fresh;
  }

  void refreshCatalog() {
    send.accept(HostMessages.catalogLoading());
    BackendClient c = client();
    if (c == null) {
      send.accept(HostMessages.catalogError(NOT_CONFIGURED, NOT_CONFIGURED_MSG));
      return;
    }
    try {
      send.accept(catalog(c, true).toHostMessage());
    } catch (BackendException e) {
      send.accept(HostMessages.catalogError(code(e), message(e)));
    }
  }

  void refreshRuns() {
    BackendClient c = client();
    if (c == null) return;
    try {
      List<Invocation> list = c.invocations(true, null, null, RECENT_LIMIT);
      Catalog cat = catalogCache.get();
      List<Map<String, Object>> out = new ArrayList<>();
      for (Invocation i : list) {
        CatalogAgent a = cat == null ? null : cat.find(i.agentId());
        out.add(i.toRecentRun(a == null ? null : a.name()));
      }
      send.accept(HostMessages.agentRuns(out));
    } catch (BackendException e) {
      send.accept(HostMessages.agentRuns(List.of()));
    }
  }

  /** {@code agent.target} for an agent from the catalog, else from its registry versions (owner/team); or {@code agent.target.error}. */
  String resolveTarget(String agentId, String env, String version) {
    BackendClient c = client();
    if (c == null) return HostMessages.agentTargetError(NOT_CONFIGURED, NOT_CONFIGURED_MSG);
    try {
      CatalogAgent a = catalog(c, false).find(agentId);
      if (a == null) a = catalog(c, true).find(agentId);
      if (a != null) return HostMessages.agentTarget(a.runTarget(env, version));
    } catch (BackendException e) {
      if (e.status() == 401) return HostMessages.agentTargetError(code(e), message(e));
    }
    try {
      List<AgentVersionInfo> versions = c.agentVersions(agentId, null);
      if (versions.isEmpty()) return HostMessages.agentTargetError("agent_not_invocable", "Agent " + agentId + " has no version you can run.");
      return HostMessages.agentTarget(CatalogAgent.runTarget(agentId, versions, env, version));
    } catch (BackendException e) {
      return HostMessages.agentTargetError(code(e), message(e));
    }
  }

  private String nameOf(String agentId) {
    Catalog cat = catalogCache.get();
    CatalogAgent a = cat == null ? null : cat.find(agentId);
    return a == null ? agentId : a.name();
  }

  // ---------- runs ----------

  private void invoke(AgentMessage m) {
    InvokeRequest req;
    try {
      req = new InvokeRequest(m.input(), m.messages(), m.sessionId());
    } catch (IllegalArgumentException e) {
      send.accept(HostMessages.agentError(m.localId(), "input_invalid", e.getMessage(), null));
      send.accept(HostMessages.agentDone(m.localId(), "failed", null, null, null, null));
      return;
    }
    Run r = new Run(m.localId(), m.agentId(), m.mode(), m.env(), m.version());
    Run old = runs.put(m.localId(), r);
    if (old != null) {
      old.cancel.cancel();
      stopPolling(old);
    }
    async(() -> {
      BackendClient c = client();
      if (c == null) {
        fail(r, NOT_CONFIGURED, NOT_CONFIGURED_MSG);
        return;
      }
      if ("background".equals(r.mode)) runBackground(c, r, req);
      else runStream(c, r, req);
    });
  }

  private void fail(Run r, String code, String message) {
    if (r.finished) return;
    r.finished = true;
    runs.remove(r.localId, r);
    send.accept(HostMessages.agentError(r.localId, code, message, r.invocationId));
    send.accept(HostMessages.agentDone(r.localId, "failed", null, null, null, r.invocationId));
  }

  private void runStream(BackendClient c, Run r, InvokeRequest req) {
    send.accept(HostMessages.agentStatus(r.localId, "running", null, null, null, null, null, r.version, r.env));
    try {
      AgentStream.Result res = c.invokeStream(r.agentId, r.env, r.version, req, new AgentStreamListener() {
        @Override
        public void onOpen(String invocationId, String traceId) {
          r.invocationId = invocationId;
          if (!r.finished && invocationId != null) {
            send.accept(HostMessages.agentStatus(r.localId, "running", invocationId, traceId, null, null, null, r.version, r.env));
          }
        }

        @Override
        public void onEvent(AgentEvent ev) {
          if (r.finished) return;
          if (r.invocationId == null && ev.invocationId() != null) r.invocationId = ev.invocationId();
          if (ev instanceof AgentEvent.Delta d) {
            send.accept(HostMessages.agentDelta(r.localId, d.text()));
          } else if (ev instanceof AgentEvent.Output o) {
            r.outputSent = true;
            send.accept(HostMessages.agentOutput(r.localId, o.output(), o.usage(), o.traceId()));
          } else if (ev instanceof AgentEvent.Error e) {
            r.errorSent = true;
            send.accept(HostMessages.agentError(r.localId, e.code(), e.message(), r.invocationId));
          }
        }
      }, r.cancel);
      finishStream(r, res);
    } catch (BackendException e) {
      fail(r, code(e), message(e));
    }
  }

  private void finishStream(Run r, AgentStream.Result res) {
    if (r.finished) return;
    r.finished = true;
    runs.remove(r.localId, r);
    String inv = res.invocationId() != null ? res.invocationId() : r.invocationId;
    if (res.succeeded() && !r.outputSent) send.accept(HostMessages.agentOutput(r.localId, res.output(), res.usage(), res.traceId()));
    if (res.error() != null && !r.errorSent) send.accept(HostMessages.agentError(r.localId, res.error().code(), res.error().message(), inv));
    send.accept(HostMessages.agentDone(r.localId, res.status(), res.durationMs(), res.traceId(), res.usage(), inv));
  }

  private void runBackground(BackendClient c, Run r, InvokeRequest req) {
    try {
      InvocationAccepted a = c.invokeBackground(r.agentId, r.env, r.version, req);
      r.invocationId = a.invocationId();
      if (r.finished) {
        // cancelled while the request was in flight
        cancelRemote(c, a.invocationId());
        return;
      }
      send.accept(HostMessages.agentStatus(r.localId, a.status(), a.invocationId(), null, null, null, null,
          a.version() != null ? a.version() : r.version, a.env() != null ? a.env() : r.env));
      schedulePoll(r);
    } catch (BackendException e) {
      fail(r, code(e), message(e));
    }
  }

  private void schedulePoll(Run r) {
    if (disposed || r.finished) return;
    r.poll = scheduler.schedule(() -> async(() -> poll(r)), POLL_MS);
  }

  private void stopPolling(Run r) {
    AigSocket.Cancellable p = r.poll;
    if (p != null) p.cancel();
    r.poll = null;
  }

  private void poll(Run r) {
    if (r.finished) return;
    BackendClient c = client();
    if (c == null) {
      fail(r, NOT_CONFIGURED, NOT_CONFIGURED_MSG);
      return;
    }
    try {
      Invocation inv = c.invocation(r.invocationId);
      r.pollFailures = 0;
      if (r.finished) return;
      deliver(r.localId, inv, r);
      if (inv.isFinal()) {
        r.finished = true;
        runs.remove(r.localId, r);
        host.runFinished(inv.agentId(), nameOf(inv.agentId()), inv.status(), inv.id());
      } else {
        schedulePoll(r);
      }
    } catch (BackendException e) {
      boolean permanent = e.status() == 401 || e.status() == 403 || e.status() == 404;
      if (permanent || ++r.pollFailures >= MAX_POLL_FAILURES) fail(r, code(e), message(e));
      else schedulePoll(r);
    }
  }

  /** agent.status for a record; when final also output (if any) / error and done. */
  private void deliver(String localId, Invocation inv, Run r) {
    send.accept(HostMessages.agentStatus(localId, inv.status(), inv.id(), inv.traceId(), inv.durationMs(), inv.usage(), inv.errorCode(), inv.version(),
        inv.env()));
    if (!inv.isFinal()) return;
    if ("succeeded".equals(inv.status()) && inv.output() != null) send.accept(HostMessages.agentOutput(localId, inv.output(), inv.usage(), inv.traceId()));
    if (("failed".equals(inv.status()) || "timeout".equals(inv.status())) && (inv.errorCode() != null || inv.errorMessage() != null)) {
      String code = inv.errorCode() != null ? inv.errorCode() : "agent_error";
      send.accept(HostMessages.agentError(localId, code, inv.errorMessage() != null ? inv.errorMessage() : code, inv.id()));
    }
    send.accept(HostMessages.agentDone(localId, inv.status(), inv.durationMs(), inv.traceId(), inv.usage(), inv.id()));
  }

  void pollOnce(String localId, String invocationId) {
    BackendClient c = client();
    if (c == null) return;
    try {
      deliver(localId, c.invocation(invocationId), null);
    } catch (BackendException e) {
      send.accept(HostMessages.agentError(localId, code(e), message(e), invocationId));
    }
  }

  private void cancel(String localId, String invocationId) {
    Run r = runs.get(localId);
    String inv = r != null && r.invocationId != null ? r.invocationId : invocationId;
    if (r != null) {
      if (r.finished) return;
      stopPolling(r);
      if ("stream".equals(r.mode)) {
        r.finished = true;
        runs.remove(localId, r);
        r.cancel.cancel();
        send.accept(HostMessages.agentDone(localId, "cancelled", null, null, null, inv));
        if (inv != null) async(() -> {
          BackendClient c = client();
          if (c != null) cancelRemote(c, inv);
        });
        return;
      }
      if (inv == null) {
        // background request still in flight: runBackground cancels it once the id is known
        r.finished = true;
        runs.remove(localId, r);
        send.accept(HostMessages.agentDone(localId, "cancelled", null, null, null, null));
        return;
      }
    }
    if (inv == null) return;
    async(() -> {
      BackendClient c = client();
      if (c == null) return;
      try {
        Invocation after = c.cancelInvocation(inv);
        if (r != null) {
          r.finished = true;
          runs.remove(localId, r);
        }
        deliver(localId, after.isFinal() ? after : withStatus(after, "cancelled"), null);
      } catch (BackendException e) {
        if ("invocation_finished".equals(e.code()) || e.status() == 409) {
          if (r != null) {
            r.finished = true;
            runs.remove(localId, r);
          }
          pollOnce(localId, inv);
        } else {
          send.accept(HostMessages.agentError(localId, code(e), message(e), inv));
          if (r != null) schedulePoll(r);
        }
      }
    });
  }

  private static Invocation withStatus(Invocation i, String status) {
    return new Invocation(i.id(), i.agentId(), i.version(), i.env(), i.mode(), status, i.traceId(), i.createdAt(), i.durationMs(), i.usage(), i.errorCode(),
        i.errorMessage(), false, null);
  }

  private static void cancelRemote(BackendClient c, String invocationId) {
    try {
      c.cancelInvocation(invocationId);
    } catch (BackendException e) {
      // already finished, or the closed connection cancelled it first
    }
  }

  /** Stops polling and aborts open streams (background runs keep running server-side). */
  public void dispose() {
    disposed = true;
    for (Run r : runs.values()) {
      stopPolling(r);
      if ("stream".equals(r.mode)) r.cancel.cancel();
    }
    runs.clear();
  }

  /** For tests: the active (unfinished) local run ids. */
  List<String> activeRuns() {
    return new ArrayList<>(runs.keySet());
  }
}
