package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * One {@code GET /api/v1/catalog} item ({@code {agent, versions, default, access}}), flattened like
 * web/packages/ui {@code catalogAgentFromItem}.
 */
public record CatalogAgent(String agentId, String name, String description, String team, String owner, String lifecycle, String status,
    List<String> tags, String visibility, String access, List<AgentVersionInfo> versions, AgentVersionInfo defaultVersion, String docsUrl) {

  /** Null when malformed (no agent id or no usable version). */
  public static CatalogAgent from(Object raw) {
    Map<String, Object> it = Json.asObject(raw);
    Map<String, Object> a = Json.obj(it, "agent");
    String id = Json.str(a, "agent_id");
    if (id == null) return null;
    List<AgentVersionInfo> versions = new ArrayList<>();
    List<Object> rawVersions = Json.list(it, "versions");
    if (rawVersions != null) {
      for (Object o : rawVersions) {
        AgentVersionInfo v = AgentVersionInfo.from(o);
        if (v != null) versions.add(v);
      }
    }
    AgentVersionInfo def = AgentVersionInfo.from(it.get("default"));
    if (def == null && !versions.isEmpty()) def = versions.get(0);
    if (def == null) return null;
    if (versions.isEmpty()) versions.add(def);
    String name = Json.str(a, "name");
    String lifecycle = Json.str(a, "lifecycle");
    String status = Json.str(a, "status");
    String access = Json.str(it, "access");
    String visibility = Json.str(a, "visibility");
    return new CatalogAgent(id, name == null || name.isEmpty() ? id : name, orEmpty(Json.str(a, "description")), orEmpty(Json.str(a, "team")),
        orEmpty(Json.str(a, "owner")), lifecycle == null ? "active" : lifecycle, status == null ? "active" : status, List.copyOf(Json.strings(a.get("tags"))),
        visibility == null || visibility.isEmpty() ? null : visibility, access == null ? "org" : access, List.copyOf(versions), def, Json.str(a, "docs_url"));
  }

  private static String orEmpty(String s) {
    return s == null ? "" : s;
  }

  /** web/packages/ui {@code CatalogAgent} (camelCase). */
  public Map<String, Object> toWidget() {
    List<Object> vs = new ArrayList<>();
    for (AgentVersionInfo v : versions) vs.add(v.toWidget());
    return Json.object().put("agentId", agentId).put("name", name).put("description", description).put("team", team).put("owner", owner)
        .put("lifecycle", lifecycle).put("status", status).put("tags", tags).opt("visibility", visibility).put("access", access).put("versions", vs)
        .put("defaultVersion", defaultVersion.toWidget()).put("docsUrl", docsUrl).map();
  }

  /** The version a run uses: the first matching {@code env}/{@code version} (either may be null), else the default. */
  public AgentVersionInfo pick(String env, String version) {
    for (AgentVersionInfo v : versions) {
      if ((env == null || env.equals(v.env())) && (version == null || version.equals(v.version()))) return v;
    }
    return defaultVersion;
  }

  /** web/packages/ui {@code AgentRunTarget} (like {@code runTargetFromCatalog}). */
  public Map<String, Object> runTarget(String env, String version) {
    AgentVersionInfo chosen = pick(env, version);
    List<Object> vs = new ArrayList<>();
    for (AgentVersionInfo v : versions) vs.add(v.toWidget());
    return Json.object().put("agentId", agentId).put("name", name).put("description", description).put("team", team).put("lifecycle", lifecycle)
        .put("versions", vs).put("version", chosen.version()).put("env", chosen.env()).map();
  }

  /** Run target for an agent that is not in the caller's catalog (owner with unverified versions). */
  public static Map<String, Object> runTarget(String agentId, List<AgentVersionInfo> versions, String env, String version) {
    List<Object> vs = new ArrayList<>();
    AgentVersionInfo chosen = null;
    for (AgentVersionInfo v : versions) {
      vs.add(v.toWidget());
      if (chosen == null && (env == null || env.equals(v.env())) && (version == null || version.equals(v.version()))) chosen = v;
    }
    if (chosen == null && !versions.isEmpty()) chosen = versions.get(0);
    return Json.object().put("agentId", agentId).put("name", agentId).put("versions", vs).opt("version", chosen == null ? null : chosen.version())
        .opt("env", chosen == null ? null : chosen.env()).map();
  }
}
