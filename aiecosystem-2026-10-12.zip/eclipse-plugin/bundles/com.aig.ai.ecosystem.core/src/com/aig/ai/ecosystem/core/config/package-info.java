/** AIG core: config. */
package com.aig.ai.ecosystem.core.config;
