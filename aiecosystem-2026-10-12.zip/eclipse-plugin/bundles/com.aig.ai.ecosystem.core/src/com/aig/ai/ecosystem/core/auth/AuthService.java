package com.aig.ai.ecosystem.core.auth;

import com.aig.ai.ecosystem.core.config.AuthPlan;
import com.aig.ai.ecosystem.core.config.ConfigResolver;
import com.aig.ai.ecosystem.core.config.ResolvedConfig;
import com.aig.ai.ecosystem.core.http.ContractHeaders;
import java.io.IOException;
import java.time.Duration;
import java.util.function.LongSupplier;

/**
 * Signs in and hands out the bearer token for the selected environment.
 * <ul>
 *   <li>dev/stage/prod: Entra ID Authorization Code + PKCE in the system browser, loopback redirect
 *       {@code http://127.0.0.1:<port>/callback}; the token (and refresh token) is kept in Eclipse
 *       Secure Storage and refreshed shortly before it expires.</li>
 *   <li>local: the backend's local sign-in page, loopback redirect
 *       {@code http://127.0.0.1:<port>/auth/callback}, one-time state; or the dev-user shortcut.</li>
 * </ul>
 * The plugin never holds a Portkey key: model calls go through platform-api.
 */
public final class AuthService {
  /** Opens a URL in the system browser. */
  @FunctionalInterface
  public interface BrowserOpener {
    void open(String url) throws Exception;
  }

  public static final Duration SIGN_IN_TIMEOUT = Duration.ofMinutes(5);
  public static final String ENTRA_CALLBACK_PATH = "/callback";
  static final long REFRESH_MARGIN_SEC = 120;

  private final TokenStore tokens;
  private final LocalSessionStore local;
  private final EntraClient entra;
  private final BrowserOpener browser;
  private final LongSupplier nowSec;
  private final PendingStates pending = new PendingStates();
  private volatile LoopbackReceiver active;

  public AuthService(TokenStore tokens, LocalSessionStore local, EntraClient entra, BrowserOpener browser, LongSupplier nowSec) {
    this.tokens = tokens;
    this.local = local;
    this.entra = entra;
    this.browser = browser;
    this.nowSec = nowSec;
  }

  public AuthService(TokenStore tokens, LocalSessionStore local, BrowserOpener browser) {
    this(tokens, local, new EntraClient(), browser, () -> System.currentTimeMillis() / 1000);
  }

  PendingStates pending() {
    return pending;
  }

  /**
   * Runs the sign-in for the configured plan and blocks until it completes (call it from a
   * background job). Returns the signed-in account.
   */
  public String signIn(ResolvedConfig cfg, Duration timeout) throws Exception {
    if (!cfg.configured()) throw new NotSignedInException(cfg.notConfiguredMessage() + ": " + String.join("; ", cfg.problems()));
    AuthPlan plan = cfg.auth();
    switch (plan.kind()) {
      case DEV:
        // Local dev-user shortcut: no browser; remembered so Sign Out works the same way.
        local.save(plan.email());
        return plan.email();
      case LOCAL_BROWSER:
        return signInLocal(cfg, timeout);
      case MICROSOFT:
        return signInMicrosoft(plan.entra(), cfg, timeout);
      default:
        throw new NotSignedInException(plan.reason());
    }
  }

  /**
   * Local environment only (browser sign-in plan): signs in as {@code email} directly, without the
   * browser page, so the views can be tried with any user (the backend's test personas). The result is
   * the same stored session as the browser flow: a {@code dev:<email>} bearer, accepted only by a
   * backend running {@code AIG_ENV=local} with {@code AIG_AUTH_MODE=dev}. Returns the normalized email.
   */
  public String signInAs(ResolvedConfig cfg, String email) throws NotSignedInException {
    if (!cfg.configured()) throw new NotSignedInException(cfg.notConfiguredMessage() + ": " + String.join("; ", cfg.problems()));
    if (cfg.auth().kind() != AuthPlan.Kind.LOCAL_BROWSER) {
      throw new NotSignedInException(cfg.auth().kind() == AuthPlan.Kind.DEV
          ? "Signing in with an email is not available while a local dev user is set (" + cfg.auth().email() + "). Clear the dev user in the AIG preferences."
          : "Signing in with an email is only available in the local environment (" + cfg.env().id() + " uses Microsoft sign-in).");
    }
    String e = LocalSignIn.normalizeEmail(email);
    if (e == null || !ConfigResolver.isValidEmail(e)) throw new NotSignedInException("Not a valid email: " + email);
    cancelPending();
    local.save(e);
    return e;
  }

  /** Last local sign-in email (kept after sign-out), or null. */
  public String lastLocalEmail() {
    String e = local.last();
    return e == null || e.isEmpty() ? null : e;
  }

  private String signInLocal(ResolvedConfig cfg, Duration timeout) throws Exception {
    cancelPending();
    String state = pending.issue();
    try (LoopbackReceiver rx = new LoopbackReceiver(LocalSignIn.CALLBACK_PATH, (p, q) -> LocalSignIn.handleCallback(p, q, pending))) {
      active = rx;
      browser.open(LocalSignIn.buildSignInUrl(cfg.backendUrl(), rx.redirectUri(), state, lastLocalEmail()));
      CallbackResult r = rx.await(timeout);
      if (!r.ok()) throw new NotSignedInException(r.reason());
      local.save(r.value());
      return r.value();
    } finally {
      active = null;
      pending.consume(state);
    }
  }

  private String signInMicrosoft(AuthPlan.EntraConfig c, ResolvedConfig cfg, Duration timeout) throws Exception {
    cancelPending();
    String state = pending.issue();
    String verifier = Pkce.newVerifier();
    try (LoopbackReceiver rx = new LoopbackReceiver(ENTRA_CALLBACK_PATH, (p, q) -> EntraClient.handleCallback(q, pending))) {
      active = rx;
      browser.open(EntraClient.authorizeUrl(c, rx.redirectUri(), state, Pkce.challenge(verifier)));
      CallbackResult r = rx.await(timeout);
      if (!r.ok()) throw new NotSignedInException(r.reason());
      StoredToken t = entra.exchangeCode(c, r.value(), rx.redirectUri(), verifier);
      tokens.save(cfg.env(), t);
      return t.account() == null ? "Microsoft account" : t.account();
    } finally {
      active = null;
      pending.consume(state);
    }
  }

  /** Cancels a sign-in that is waiting for the browser. */
  public void cancelPending() {
    LoopbackReceiver rx = active;
    if (rx != null) rx.close();
  }

  /** Bearer token for the environment, refreshing the Entra token when it is about to expire. */
  public String accessToken(ResolvedConfig cfg) throws NotSignedInException {
    AuthPlan plan = cfg.auth();
    switch (plan.kind()) {
      case DEV:
        if (!plan.email().equals(local.load())) throw new NotSignedInException("Not signed in (local). Use AIG > Sign In.");
        return ContractHeaders.devToken(plan.email());
      case LOCAL_BROWSER: {
        String email = local.load();
        if (email == null || email.isEmpty()) throw new NotSignedInException("Not signed in (local). Use AIG > Sign In.");
        return ContractHeaders.devToken(email);
      }
      case MICROSOFT: {
        StoredToken t = tokens.load(cfg.env());
        if (t == null) throw new NotSignedInException("Not signed in (" + cfg.env().id() + "). Use AIG > Sign In.");
        long now = nowSec.getAsLong();
        if (!t.expiresWithin(now, REFRESH_MARGIN_SEC)) return t.accessToken();
        if (t.refreshToken() == null) {
          if (t.expiresAt() > now) return t.accessToken();
          tokens.clear(cfg.env());
          throw new NotSignedInException("Session expired (" + cfg.env().id() + "). Sign in again.");
        }
        synchronized (this) {
          StoredToken again = tokens.load(cfg.env());
          if (again != null && !again.expiresWithin(now, REFRESH_MARGIN_SEC)) return again.accessToken();
          try {
            StoredToken fresh = entra.refresh(plan.entra(), t);
            tokens.save(cfg.env(), fresh);
            return fresh.accessToken();
          } catch (IOException e) {
            if (t.expiresAt() > now) return t.accessToken();
            tokens.clear(cfg.env());
            throw new NotSignedInException("Session expired (" + cfg.env().id() + "): " + e.getMessage() + ". Sign in again.");
          }
        }
      }
      default:
        throw new NotSignedInException(plan.reason() == null ? cfg.notConfiguredMessage() : plan.reason());
    }
  }

  public boolean hasSession(ResolvedConfig cfg) {
    if (!cfg.configured()) return false;
    switch (cfg.auth().kind()) {
      case DEV:
        return cfg.auth().email().equals(local.load());
      case LOCAL_BROWSER: {
        String e = local.load();
        return e != null && !e.isEmpty();
      }
      case MICROSOFT: {
        StoredToken t = tokens.load(cfg.env());
        return t != null && (t.refreshToken() != null || t.expiresAt() > nowSec.getAsLong());
      }
      default:
        return false;
    }
  }

  /** Signed-in account to display, or null. */
  public String account(ResolvedConfig cfg) {
    switch (cfg.auth().kind()) {
      case DEV:
        return cfg.auth().email();
      case LOCAL_BROWSER:
        return local.load();
      case MICROSOFT: {
        StoredToken t = tokens.load(cfg.env());
        return t == null ? null : t.account();
      }
      default:
        return null;
    }
  }

  public void signOut(ResolvedConfig cfg) {
    cancelPending();
    if (cfg.auth().kind() == AuthPlan.Kind.MICROSOFT) tokens.clear(cfg.env());
    if (cfg.auth().kind() == AuthPlan.Kind.LOCAL_BROWSER || cfg.auth().kind() == AuthPlan.Kind.DEV) local.clear();
  }
}
