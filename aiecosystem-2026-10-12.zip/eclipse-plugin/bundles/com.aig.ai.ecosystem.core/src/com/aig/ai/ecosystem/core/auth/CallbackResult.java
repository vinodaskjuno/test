package com.aig.ai.ecosystem.core.auth;

/** Outcome of validating a sign-in redirect. Exactly one of {@code value} / {@code reason} is set. */
public record CallbackResult(String value, String reason) {
  public static CallbackResult ok(String value) {
    return new CallbackResult(value, null);
  }

  public static CallbackResult fail(String reason) {
    return new CallbackResult(null, reason);
  }

  public boolean ok() {
    return value != null;
  }
}
