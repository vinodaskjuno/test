package com.aig.ai.ecosystem.core.json;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal, dependency-free JSON reader/writer (RFC 8259). Objects become {@link LinkedHashMap}
 * (insertion order kept), arrays {@link ArrayList}, numbers {@link Long} when integral and in range
 * otherwise {@link Double}, plus String, Boolean and {@code null}.
 *
 * <p>The writer escapes {@code < > & U+2028 U+2029} as well, so its output is safe to embed in a
 * JavaScript string or a {@code <script>} element (used by the Java to browser bridge).
 */
public final class Json {
  private static final int MAX_DEPTH = 64;

  private Json() {}

  /** Thrown for malformed input. */
  public static final class JsonException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public JsonException(String message) {
      super(message);
    }
  }

  public static Object parse(String text) {
    if (text == null) throw new JsonException("null input");
    Parser p = new Parser(text);
    p.ws();
    Object v = p.value(0);
    p.ws();
    if (p.i != text.length()) throw new JsonException("trailing characters at " + p.i);
    return v;
  }

  /** Parses and returns the object, or {@code null} if the text is not a JSON object. */
  public static Map<String, Object> parseObject(String text) {
    try {
      Object v = parse(text);
      return asObject(v);
    } catch (JsonException e) {
      return null;
    }
  }

  @SuppressWarnings("unchecked")
  public static Map<String, Object> asObject(Object v) {
    return v instanceof Map ? (Map<String, Object>) v : null;
  }

  @SuppressWarnings("unchecked")
  public static List<Object> asList(Object v) {
    return v instanceof List ? (List<Object>) v : null;
  }

  public static String str(Map<String, Object> m, String key) {
    if (m == null) return null;
    Object v = m.get(key);
    return v instanceof String ? (String) v : null;
  }

  public static Map<String, Object> obj(Map<String, Object> m, String key) {
    return m == null ? null : asObject(m.get(key));
  }

  public static List<Object> list(Map<String, Object> m, String key) {
    return m == null ? null : asList(m.get(key));
  }

  /** Non-negative finite number or 0 (mirrors the TS helpers). */
  public static double num(Map<String, Object> m, String key) {
    if (m == null) return 0;
    Object v = m.get(key);
    if (v instanceof Number) {
      double d = ((Number) v).doubleValue();
      return Double.isFinite(d) && d >= 0 ? d : 0;
    }
    return 0;
  }

  public static List<String> strings(Object v) {
    List<Object> l = asList(v);
    if (l == null) return Collections.emptyList();
    List<String> out = new ArrayList<>();
    for (Object o : l) if (o instanceof String) out.add((String) o);
    return out;
  }

  // ------------------------------------------------------------------------------------------
  // Writer
  // ------------------------------------------------------------------------------------------

  public static String write(Object v) {
    StringBuilder sb = new StringBuilder();
    write(sb, v, 0);
    return sb.toString();
  }

  private static void write(StringBuilder sb, Object v, int depth) {
    if (depth > MAX_DEPTH) throw new JsonException("nesting too deep");
    if (v == null) {
      sb.append("null");
    } else if (v instanceof String) {
      quote(sb, (String) v);
    } else if (v instanceof Boolean) {
      sb.append(v.toString());
    } else if (v instanceof Double || v instanceof Float) {
      double d = ((Number) v).doubleValue();
      if (!Double.isFinite(d)) sb.append("null");
      else if (d == Math.rint(d) && Math.abs(d) < 1e15) sb.append((long) d);
      else sb.append(d);
    } else if (v instanceof Number) {
      sb.append(v.toString());
    } else if (v instanceof Map) {
      sb.append('{');
      boolean first = true;
      for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
        if (!first) sb.append(',');
        first = false;
        quote(sb, String.valueOf(e.getKey()));
        sb.append(':');
        write(sb, e.getValue(), depth + 1);
      }
      sb.append('}');
    } else if (v instanceof Iterable) {
      sb.append('[');
      boolean first = true;
      for (Object o : (Iterable<?>) v) {
        if (!first) sb.append(',');
        first = false;
        write(sb, o, depth + 1);
      }
      sb.append(']');
    } else {
      quote(sb, v.toString());
    }
  }

  public static String quote(String s) {
    StringBuilder sb = new StringBuilder(s.length() + 2);
    quote(sb, s);
    return sb.toString();
  }

  private static void quote(StringBuilder sb, String s) {
    sb.append('"');
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      switch (c) {
        case '"': sb.append("\\\""); break;
        case '\\': sb.append("\\\\"); break;
        case '\n': sb.append("\\n"); break;
        case '\r': sb.append("\\r"); break;
        case '\t': sb.append("\\t"); break;
        case '\b': sb.append("\\b"); break;
        case '\f': sb.append("\\f"); break;
        case '<': case '>': case '&': case ' ': case ' ':
          sb.append(String.format("\\u%04x", (int) c));
          break;
        default:
          if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
          else sb.append(c);
      }
    }
    sb.append('"');
  }

  /** Small builder for ordered JSON objects. */
  public static Obj object() {
    return new Obj();
  }

  public static final class Obj {
    private final Map<String, Object> map = new LinkedHashMap<>();

    public Obj put(String k, Object v) {
      map.put(k, v);
      return this;
    }

    /** Puts only when the value is non-null. */
    public Obj opt(String k, Object v) {
      if (v != null) map.put(k, v);
      return this;
    }

    public Map<String, Object> map() {
      return map;
    }

    @Override
    public String toString() {
      return write(map);
    }
  }

  // ------------------------------------------------------------------------------------------
  // Parser
  // ------------------------------------------------------------------------------------------

  private static final class Parser {
    final String s;
    int i;

    Parser(String s) {
      this.s = s;
    }

    void ws() {
      while (i < s.length()) {
        char c = s.charAt(i);
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
        else break;
      }
    }

    JsonException err(String m) {
      return new JsonException(m + " at " + i);
    }

    Object value(int depth) {
      if (depth > MAX_DEPTH) throw err("nesting too deep");
      if (i >= s.length()) throw err("unexpected end");
      char c = s.charAt(i);
      switch (c) {
        case '{': return object(depth);
        case '[': return array(depth);
        case '"': return string();
        case 't': return literal("true", Boolean.TRUE);
        case 'f': return literal("false", Boolean.FALSE);
        case 'n': return literal("null", null);
        default:
          if (c == '-' || (c >= '0' && c <= '9')) return number();
          throw err("unexpected character '" + c + "'");
      }
    }

    Object literal(String word, Object v) {
      if (!s.startsWith(word, i)) throw err("bad literal");
      i += word.length();
      return v;
    }

    Map<String, Object> object(int depth) {
      Map<String, Object> m = new LinkedHashMap<>();
      i++;
      ws();
      if (i < s.length() && s.charAt(i) == '}') {
        i++;
        return m;
      }
      while (true) {
        ws();
        if (i >= s.length() || s.charAt(i) != '"') throw err("expected key");
        String k = string();
        ws();
        if (i >= s.length() || s.charAt(i) != ':') throw err("expected ':'");
        i++;
        ws();
        m.put(k, value(depth + 1));
        ws();
        if (i >= s.length()) throw err("unterminated object");
        char c = s.charAt(i++);
        if (c == '}') return m;
        if (c != ',') throw err("expected ',' or '}'");
      }
    }

    List<Object> array(int depth) {
      List<Object> l = new ArrayList<>();
      i++;
      ws();
      if (i < s.length() && s.charAt(i) == ']') {
        i++;
        return l;
      }
      while (true) {
        ws();
        l.add(value(depth + 1));
        ws();
        if (i >= s.length()) throw err("unterminated array");
        char c = s.charAt(i++);
        if (c == ']') return l;
        if (c != ',') throw err("expected ',' or ']'");
      }
    }

    String string() {
      i++; // opening quote
      StringBuilder sb = new StringBuilder();
      while (true) {
        if (i >= s.length()) throw err("unterminated string");
        char c = s.charAt(i++);
        if (c == '"') return sb.toString();
        if (c < 0x20) throw err("control character in string");
        if (c != '\\') {
          sb.append(c);
          continue;
        }
        if (i >= s.length()) throw err("bad escape");
        char e = s.charAt(i++);
        switch (e) {
          case '"': sb.append('"'); break;
          case '\\': sb.append('\\'); break;
          case '/': sb.append('/'); break;
          case 'b': sb.append('\b'); break;
          case 'f': sb.append('\f'); break;
          case 'n': sb.append('\n'); break;
          case 'r': sb.append('\r'); break;
          case 't': sb.append('\t'); break;
          case 'u':
            if (i + 4 > s.length()) throw err("bad unicode escape");
            try {
              sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
            } catch (NumberFormatException ex) {
              throw err("bad unicode escape");
            }
            i += 4;
            break;
          default:
            throw err("bad escape");
        }
      }
    }

    Object number() {
      int start = i;
      if (s.charAt(i) == '-') i++;
      if (i >= s.length()) throw err("bad number");
      if (s.charAt(i) == '0') i++;
      else if (s.charAt(i) >= '1' && s.charAt(i) <= '9') while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
      else throw err("bad number");
      boolean fractional = false;
      if (i < s.length() && s.charAt(i) == '.') {
        fractional = true;
        i++;
        int d = i;
        while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        if (d == i) throw err("bad fraction");
      }
      if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
        fractional = true;
        i++;
        if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
        int d = i;
        while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        if (d == i) throw err("bad exponent");
      }
      String t = s.substring(start, i);
      if (!fractional) {
        try {
          return Long.parseLong(t);
        } catch (NumberFormatException ignored) {
          // fall through to double
        }
      }
      return Double.parseDouble(t);
    }
  }
}
