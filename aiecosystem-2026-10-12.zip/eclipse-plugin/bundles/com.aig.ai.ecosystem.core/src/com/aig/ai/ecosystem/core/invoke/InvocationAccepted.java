package com.aig.ai.ecosystem.core.invoke;

import com.aig.ai.ecosystem.core.json.Json;
import java.util.Map;

/**
 * {@code mode=background} answer (202): {@code {invocation_id, status: "queued", location, ...}}. The
 * location is informational only: status is always read from the configured backend via
 * {@code GET /api/v1/invocations/{id}}, never from a URL the server returned.
 */
public record InvocationAccepted(String invocationId, String status, String location, String agentId, String version, String env) {
  public static InvocationAccepted from(Map<String, Object> b) {
    String status = Json.str(b, "status");
    return new InvocationAccepted(Json.str(b, "invocation_id"), status == null ? "queued" : status, Json.str(b, "location"), Json.str(b, "agent_id"),
        Json.str(b, "version"), Json.str(b, "env"));
  }
}
