/** AIG core: auth. */
package com.aig.ai.ecosystem.core.auth;
