package com.aig.ai.ecosystem.core.ws;

import com.aig.ai.ecosystem.core.http.ChatMessage;
import com.aig.ai.ecosystem.core.http.ContractHeaders;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Reconnecting WebSocket client for the AIG backend (port of vscode-extension/src/ws/socket.ts).
 * Authenticates with {@code Authorization: Bearer <token>} on the upgrade request. Closes with 4401,
 * 4403 or 1008 stop reconnecting and report {@link LiveStatus#UNAUTHORIZED}.
 */
public final class AigSocket {
  /** Per-chat callbacks. */
  public interface ChatHandlers {
    void onDelta(String text);

    /**
     * {@code model}: the model the gateway served; {@code route}: {@code user_tier} + optional {@code cost_mode} /
     * {@code job_profile} / {@code usage_state}. Every argument may be null.
     */
    void onDone(String traceId, Map<String, Object> usage, String model, Map<String, Object> route);

    void onError(String code, String message);
  }

  /** Connection events. All methods are optional. */
  public interface Events {
    default void onStatus(LiveStatus status, String detail) {}

    default void onReady(ReadyInfo info) {}

    default void onFrame(ServerFrame frame) {}
  }

  /** Schedules reconnect attempts (a ScheduledExecutorService in the plugin, manual in tests). */
  public interface Scheduler {
    Cancellable schedule(Runnable task, long delayMs);
  }

  public interface Cancellable {
    void cancel();
  }

  /** Supplies the bearer token for each connect attempt. */
  @FunctionalInterface
  public interface TokenSource {
    String get() throws Exception;
  }

  static final long[] BACKOFF_MS = {1000, 2000, 5000, 10000, 30000};

  private final URI url;
  private final TokenSource tokens;
  private final WsTransport transport;
  private final Events events;
  private final Scheduler scheduler;
  private final Map<String, ChatHandlers> chats = new LinkedHashMap<>();
  private final AtomicLong seq = new AtomicLong();

  private WsTransport.Connection conn;
  private Object connToken; // identifies the current connection's listener
  private LiveStatus status = LiveStatus.IDLE;
  private int attempt;
  private Cancellable timer;
  private boolean stopped = true;
  /** Range of a usage request not answered yet (sent on open; cleared by a usage / usage.error frame). */
  private Integer usageDays;

  public AigSocket(URI url, TokenSource tokens, WsTransport transport, Events events, Scheduler scheduler) {
    this.url = url;
    this.tokens = tokens;
    this.transport = transport;
    this.events = events == null ? new Events() {} : events;
    this.scheduler = scheduler;
  }

  public synchronized LiveStatus state() {
    return status;
  }

  public synchronized boolean isOpen() {
    return status == LiveStatus.OPEN && conn != null;
  }

  public void start() {
    synchronized (this) {
      if (!stopped) return;
      stopped = false;
    }
    connect();
  }

  public void stop() {
    WsTransport.Connection c;
    synchronized (this) {
      stopped = true;
      if (timer != null) timer.cancel();
      timer = null;
      c = conn;
      conn = null;
      connToken = null;
    }
    failAllChats("disconnected", "connection closed");
    if (c != null) {
      try {
        c.close(1000, "client stop");
      } catch (RuntimeException ignored) {
        // already closed
      }
    }
    setStatus(LiveStatus.CLOSED, null);
  }

  /**
   * Asks once for the usage of {@code days} ({@code usage.subscribe}; the backend answers with a single
   * {@code usage} frame, no periodic pushes). Sent now when open, otherwise on the next open; a reconnect
   * re-sends it only while the request is still unanswered.
   */
  public void requestUsage(int days) {
    synchronized (this) {
      usageDays = days;
    }
    send(WsProtocol.usageSubscribe(days));
  }

  /** Range of the unanswered usage request, or null. */
  public synchronized Integer pendingUsage() {
    return usageDays;
  }

  /** Drops the unanswered usage request (answered another way, e.g. over HTTP); returns its range or null. */
  public synchronized Integer cancelUsageRequest() {
    Integer d = usageDays;
    usageDays = null;
    return d;
  }

  /** Starts a streamed chat and returns its id. */
  public String chat(List<ChatMessage> messages, ChatHandlers handlers, String jobProfile, String agentId) {
    if (!isOpen()) throw new IllegalStateException("not connected to the AIG backend");
    if (agentId != null && !ContractHeaders.AGENT_ID.matcher(agentId).matches()) throw new IllegalArgumentException("invalid agent id");
    String id = "c" + Long.toString(System.currentTimeMillis(), 36) + Long.toString(seq.incrementAndGet(), 36);
    synchronized (this) {
      chats.put(id, handlers);
    }
    if (!send(WsProtocol.chat(id, messages, jobProfile, agentId))) {
      synchronized (this) {
        chats.remove(id);
      }
      throw new IllegalStateException("not connected to the AIG backend");
    }
    return id;
  }

  public void cancel(String id) {
    boolean known;
    synchronized (this) {
      known = chats.containsKey(id);
    }
    if (known) send(WsProtocol.cancel(id));
  }

  private boolean send(String frame) {
    WsTransport.Connection c;
    synchronized (this) {
      if (status != LiveStatus.OPEN || conn == null) return false;
      c = conn;
    }
    c.send(frame);
    return true;
  }

  private void setStatus(LiveStatus s, String detail) {
    synchronized (this) {
      status = s;
    }
    events.onStatus(s, detail);
  }

  private void connect() {
    int a;
    synchronized (this) {
      if (stopped) return;
      a = attempt;
    }
    setStatus(a > 0 ? LiveStatus.RECONNECTING : LiveStatus.CONNECTING, null);
    String token;
    try {
      token = tokens.get();
    } catch (Exception e) {
      setStatus(LiveStatus.UNAUTHORIZED, e.getMessage());
      return;
    }
    Object me = new Object();
    synchronized (this) {
      if (stopped) return;
      connToken = me;
    }
    Map<String, String> headers = new LinkedHashMap<>();
    headers.put("Authorization", ContractHeaders.bearer(token));
    WsTransport.Connection c;
    try {
      c = transport.connect(url, headers, new WsTransport.Listener() {
        @Override
        public void onOpen() {
          Integer days;
          synchronized (AigSocket.this) {
            if (connToken != me) return;
            attempt = 0;
            days = usageDays;
          }
          setStatus(LiveStatus.OPEN, null);
          if (days != null) send(WsProtocol.usageSubscribe(days));
        }

        @Override
        public void onText(String text) {
          synchronized (AigSocket.this) {
            if (connToken != me) return;
          }
          ServerFrame f = WsProtocol.parse(text);
          if (f != null) dispatch(f);
        }

        @Override
        public void onClose(int code, String reason) {
          synchronized (AigSocket.this) {
            if (connToken != me) return;
            connToken = null;
            conn = null;
          }
          failAllChats("disconnected", "connection lost");
          synchronized (AigSocket.this) {
            if (stopped) return;
          }
          if (code == 4401 || code == 4403 || code == 1008) {
            setStatus(LiveStatus.UNAUTHORIZED, reason == null || reason.isEmpty() ? "unauthorized" : reason);
            return;
          }
          retry("closed (" + code + ")");
        }

        @Override
        public void onError(Throwable error) {
          // onClose follows and handles reconnects.
        }
      });
    } catch (RuntimeException e) {
      synchronized (this) {
        if (connToken == me) connToken = null;
      }
      retry(e.getMessage());
      return;
    }
    Integer resubscribe = null;
    synchronized (this) {
      if (connToken == me) {
        conn = c;
        // onOpen may have raced ahead of this assignment: make sure the subscription went out.
        if (status == LiveStatus.OPEN) resubscribe = usageDays;
      }
    }
    if (resubscribe != null) send(WsProtocol.usageSubscribe(resubscribe));
  }

  private void retry(String detail) {
    long delay;
    synchronized (this) {
      if (stopped) return;
      delay = BACKOFF_MS[Math.min(attempt, BACKOFF_MS.length - 1)];
      attempt++;
    }
    setStatus(LiveStatus.RECONNECTING, detail + "; retrying in " + Math.round(delay / 1000.0) + "s");
    Cancellable t = scheduler.schedule(this::connect, delay);
    synchronized (this) {
      timer = t;
    }
  }

  private void dispatch(ServerFrame f) {
    ChatHandlers h = null;
    switch (f.type()) {
      case "ready":
        events.onReady(f.ready());
        break;
      case "ping":
        send(WsProtocol.pong());
        break;
      case "usage":
        synchronized (this) {
          if (usageDays != null && usageDays == f.days()) usageDays = null; // answered: a reconnect does not ask again
        }
        break;
      case "usage.error":
        synchronized (this) {
          usageDays = null;
        }
        break;
      case "chat.delta":
        synchronized (this) {
          h = chats.get(f.id());
        }
        if (h != null) h.onDelta(f.text());
        break;
      case "chat.done":
        synchronized (this) {
          h = chats.remove(f.id());
        }
        if (h != null) h.onDone(f.traceId(), f.usage(), f.model(), f.route());
        break;
      case "chat.error":
        synchronized (this) {
          h = chats.remove(f.id());
        }
        if (h != null) h.onError(f.code(), f.message());
        break;
      default:
        break;
    }
    events.onFrame(f);
  }

  private void failAllChats(String code, String message) {
    List<ChatHandlers> all;
    synchronized (this) {
      all = new ArrayList<>(chats.values());
      chats.clear();
    }
    for (ChatHandlers h : all) h.onError(code, message);
  }

  /** Number of chats still streaming (tests). */
  public synchronized int activeChats() {
    return chats.size();
  }
}
