package com.aig.ai.ecosystem.core.ws;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicReference;

/**
 * {@link WsTransport} over {@link java.net.http.WebSocket}. The bearer token goes in the
 * {@code Authorization} header of the upgrade request (never in the URL); no {@code Origin} header
 * is sent, like the VSIX's Node client. Fragmented text messages are reassembled; messages larger
 * than 4 MiB close the socket.
 */
public final class JdkWsTransport implements WsTransport {
  private static final int MAX_MESSAGE = 4 * 1024 * 1024;
  private final HttpClient http;

  public JdkWsTransport() {
    this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
  }

  @Override
  public Connection connect(URI uri, Map<String, String> headers, Listener listener) {
    WebSocket.Builder b = http.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(10));
    headers.forEach(b::header);
    AtomicReference<WebSocket> ref = new AtomicReference<>();
    StringBuilder partial = new StringBuilder();
    WebSocket.Listener l = new WebSocket.Listener() {
      @Override
      public void onOpen(WebSocket ws) {
        ref.set(ws);
        listener.onOpen();
        ws.request(1);
      }

      @Override
      public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
        partial.append(data);
        if (partial.length() > MAX_MESSAGE) {
          partial.setLength(0);
          ws.sendClose(1009, "message too big");
          return null;
        }
        if (last) {
          String msg = partial.toString();
          partial.setLength(0);
          listener.onText(msg);
        }
        ws.request(1);
        return null;
      }

      @Override
      public CompletionStage<?> onBinary(WebSocket ws, java.nio.ByteBuffer data, boolean last) {
        ws.request(1); // protocol is text-only; ignore binary frames
        return null;
      }

      @Override
      public CompletionStage<?> onClose(WebSocket ws, int statusCode, String reason) {
        listener.onClose(statusCode, reason);
        return null;
      }

      @Override
      public void onError(WebSocket ws, Throwable error) {
        listener.onError(error);
        listener.onClose(1006, error.getMessage() == null ? "error" : error.getMessage());
      }
    };
    CompletableFuture<WebSocket> f = b.buildAsync(uri, l);
    f.whenComplete((ws, err) -> {
      if (err != null) {
        Throwable cause = err.getCause() != null ? err.getCause() : err;
        listener.onError(cause);
        listener.onClose(1006, cause.getMessage() == null ? "connect failed" : cause.getMessage());
      }
    });
    return new Connection() {
      // java.net.http.WebSocket allows one outstanding send at a time: chain them.
      private CompletableFuture<?> tail = CompletableFuture.completedFuture(null);

      @Override
      public synchronized void send(String text) {
        WebSocket ws = ref.get();
        if (ws == null) return;
        tail = tail.handle((x, e) -> null).thenCompose(x -> ws.sendText(text, true));
      }

      @Override
      public void close(int code, String reason) {
        WebSocket ws = ref.get();
        if (ws != null) ws.sendClose(code, reason);
        else f.cancel(true);
      }
    };
  }
}
