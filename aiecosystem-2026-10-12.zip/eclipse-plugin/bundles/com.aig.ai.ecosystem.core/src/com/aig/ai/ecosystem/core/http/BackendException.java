package com.aig.ai.ecosystem.core.http;

/** A failed platform-api call. {@code status} is 0 when no HTTP response was received. */
public final class BackendException extends Exception {
  private static final long serialVersionUID = 1L;
  private final int status;
  private final String code;
  private final String traceId;

  public BackendException(String message, int status, String code, String traceId) {
    super(message);
    this.status = status;
    this.code = code;
    this.traceId = traceId;
  }

  public BackendException(String message) {
    this(message, 0, null, null);
  }

  public int status() {
    return status;
  }

  public String code() {
    return code;
  }

  public String traceId() {
    return traceId;
  }

  /** User-facing description (mirrors the VSIX describeBackendError). */
  public String describe(String env) {
    if (status == 401) return "Not signed in or the session expired (" + env + "). Sign in again.";
    if (status == 403) return "Access denied by the AIG backend: " + getMessage();
    if (status == 501 && "usage_not_configured".equals(code)) return "Token usage is not configured on the backend (" + env + ").";
    if (status == 503) return "The AIG backend is unavailable: " + getMessage();
    return getMessage();
  }
}
