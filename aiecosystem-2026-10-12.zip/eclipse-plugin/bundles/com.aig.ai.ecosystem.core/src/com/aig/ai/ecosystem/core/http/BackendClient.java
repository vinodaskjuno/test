package com.aig.ai.ecosystem.core.http;

import com.aig.ai.ecosystem.core.invoke.AgentEvent;
import com.aig.ai.ecosystem.core.invoke.AgentIds;
import com.aig.ai.ecosystem.core.invoke.AgentRegistration;
import com.aig.ai.ecosystem.core.invoke.AgentStream;
import com.aig.ai.ecosystem.core.invoke.AgentStreamListener;
import com.aig.ai.ecosystem.core.invoke.AgentVersionInfo;
import com.aig.ai.ecosystem.core.invoke.Cancellation;
import com.aig.ai.ecosystem.core.invoke.Catalog;
import com.aig.ai.ecosystem.core.invoke.Invocation;
import com.aig.ai.ecosystem.core.invoke.InvocationAccepted;
import com.aig.ai.ecosystem.core.invoke.InvokeRequest;
import com.aig.ai.ecosystem.core.invoke.InvokeResult;
import com.aig.ai.ecosystem.core.invoke.VerifyResult;
import com.aig.ai.ecosystem.core.json.Json;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * java.net.http client for the AIG platform-api. The only credential it handles is the caller's own
 * bearer token (Entra ID access token, or {@code dev:<email>} on a local dev-mode backend), fetched
 * per call. Model calls go to the backend's OpenAI-compatible proxy, which adds the Portkey key and
 * the contract headers server-side; the plugin never sees a Portkey key.
 *
 * <p>Requests always target the configured base URL (redirects are never followed), never a URL
 * returned by the backend (e.g. {@code session.llm.base_url}).
 */
public final class BackendClient {
  /** Supplies the bearer token for each call. */
  @FunctionalInterface
  public interface TokenSupplier {
    String get() throws Exception;
  }

  /** Result of a streamed chat. {@code complete} is false when the stream ended without [DONE]. */
  public record ChatResult(String text, String traceId, boolean complete) {}

  private final String baseUrl;
  private final TokenSupplier tokens;
  private final HttpClient http;
  private final Duration timeout;
  private final Duration streamTimeout;
  private final String userAgent;

  public BackendClient(String baseUrl, TokenSupplier tokens) {
    this(baseUrl, tokens, Duration.ofSeconds(15), Duration.ofSeconds(120), "aig-eclipse-plugin");
  }

  public BackendClient(String baseUrl, TokenSupplier tokens, Duration timeout, Duration streamTimeout, String userAgent) {
    this.baseUrl = baseUrl.replaceAll("/+$", "");
    this.tokens = tokens;
    this.timeout = timeout;
    this.streamTimeout = streamTimeout;
    this.userAgent = userAgent;
    this.http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).connectTimeout(Duration.ofSeconds(10)).build();
  }

  public String baseUrl() {
    return baseUrl;
  }

  public String url(String path) {
    return baseUrl + path;
  }

  private String token() throws BackendException {
    try {
      return tokens.get();
    } catch (BackendException e) {
      throw e;
    } catch (Exception e) {
      throw new BackendException(e.getMessage() == null ? "not signed in" : e.getMessage(), 401, "unauthenticated", null);
    }
  }

  private HttpRequest.Builder request(String path, Map<String, String> headers, Duration t) {
    HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url(path))).timeout(t).header("user-agent", userAgent);
    headers.forEach(b::header);
    return b;
  }

  private static BackendException readError(HttpResponse<String> res) {
    return readError(res.statusCode(), res.headers(), res.body());
  }

  private static BackendException readError(int status, java.net.http.HttpHeaders headers, String raw) {
    String code = null;
    String message = null;
    Map<String, Object> body = Json.parseObject(raw);
    if (body != null) {
      Map<String, Object> err = Json.obj(body, "error");
      if (err != null) {
        code = Json.str(err, "code");
        message = Json.str(err, "message");
        if (message == null) message = code;
      } else if (Json.str(body, "detail") != null) {
        message = Json.str(body, "detail");
      }
    }
    String trace = headers.firstValue("x-aig-trace-id").orElse(null);
    return new BackendException(message != null ? message : "HTTP " + status, status, code, trace);
  }

  private HttpResponse<String> send(HttpRequest req) throws BackendException {
    try {
      return http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    } catch (java.net.http.HttpTimeoutException e) {
      throw new BackendException("request timed out");
    } catch (IOException e) {
      throw new BackendException(e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new BackendException("cancelled", 0, "cancelled", null);
    }
  }

  private Map<String, Object> getJson(String path, boolean auth) throws BackendException {
    Map<String, String> headers = auth ? ContractHeaders.authHeaders(token()) : Map.of("accept", "application/json");
    HttpResponse<String> res = send(request(path, headers, timeout).GET().build());
    if (res.statusCode() / 100 != 2) throw readError(res);
    Map<String, Object> body = Json.parseObject(res.body());
    if (body == null) throw new BackendException("response from " + path + " is not a JSON object", res.statusCode(), "invalid_response", null);
    return body;
  }

  private Map<String, Object> postJson(String path, Map<String, Object> payload) throws BackendException {
    return postJson(path, payload, timeout);
  }

  /** POST with the caller's token; {@code payload == null} sends no body. */
  private Map<String, Object> postJson(String path, Map<String, Object> payload, Duration t) throws BackendException {
    Map<String, String> headers = ContractHeaders.authHeaders(token());
    HttpRequest.Builder b = request(path, headers, t);
    if (payload == null) b.POST(HttpRequest.BodyPublishers.noBody());
    else b.header("content-type", "application/json").POST(HttpRequest.BodyPublishers.ofString(Json.write(payload), StandardCharsets.UTF_8));
    HttpRequest req = b.build();
    HttpResponse<String> res = send(req);
    if (res.statusCode() / 100 != 2) throw readError(res);
    Map<String, Object> body = Json.parseObject(res.body());
    if (body == null) throw new BackendException("response from " + path + " is not a JSON object", res.statusCode(), "invalid_response", null);
    return body;
  }

  public Map<String, Object> health() throws BackendException {
    return getJson("/healthz", false);
  }

  /** {@code GET /api/v1/session}, validated (user.email, env, llm.base_url required). */
  public Map<String, Object> session() throws BackendException {
    Map<String, Object> s = getJson("/api/v1/session", true);
    Map<String, Object> user = Json.obj(s, "user");
    if (user == null || Json.str(user, "email") == null || Json.str(user, "email").isEmpty()) {
      throw new BackendException("unexpected session response: session.user.email is missing", 0, "invalid_session", null);
    }
    if (Json.str(s, "env") == null) throw new BackendException("unexpected session response: session.env is not a string", 0, "invalid_session", null);
    if (Json.str(Json.obj(s, "llm"), "base_url") == null) {
      throw new BackendException("unexpected session response: session.llm.base_url is not a string", 0, "invalid_session", null);
    }
    return s;
  }

  /**
   * {@code GET /api/v1/usage/dashboard?days=N} (7, 30 or 90): the caller's own usage. The JSON is passed to the
   * widgets as is, so fields this client does not know ({@code scope}, {@code user}, {@code unavailable},
   * {@code previous}, ...) are kept.
   */
  public Map<String, Object> dashboard(int days) throws BackendException {
    if (days != 7 && days != 30 && days != 90) throw new BackendException("invalid range: " + days, 0, "invalid_range", null);
    Map<String, Object> d = getJson("/api/v1/usage/dashboard?days=" + days, true);
    if (Json.obj(d, "totals") == null || Json.list(d, "models") == null) {
      throw new BackendException("unexpected dashboard response", 0, "invalid_dashboard", null);
    }
    return d;
  }

  /**
   * {@code GET /api/v1/usage/limits?refresh=true|false}: the caller's own usage-based routing limits, live usage per
   * limit and the resulting state. Passed to the widgets as is after a light check (a JSON object with a boolean
   * {@code configured}); {@code refresh} bypasses the backend's short cache (manual refresh / range change only).
   */
  public Map<String, Object> usageLimits(boolean refresh) throws BackendException {
    Map<String, Object> d;
    try {
      d = getJson("/api/v1/usage/limits?refresh=" + refresh, true);
    } catch (BackendException e) {
      if (!"invalid_response".equals(e.code())) throw e;
      throw new BackendException("unexpected usage limits response", 0, "invalid_usage_limits", null);
    }
    if (!(d.get("configured") instanceof Boolean)) {
      throw new BackendException("unexpected usage limits response", 0, "invalid_usage_limits", null);
    }
    return d;
  }

  public Map<String, Object> listAgents() throws BackendException {
    return getJson("/api/v1/agents", true);
  }

  /**
   * {@code POST /api/v1/agents}: registers an agent for the caller (owner/team default server-side) as a
   * draft ({@code lifecycle: "draft"}; platform-api ignores request fields it does not know and defaults
   * new registrations to draft with the registry v2).
   */
  public Map<String, Object> registerAgent(String agentId, String name, String description) throws BackendException {
    return registerAgent(agentId, name, description, null);
  }

  /** As {@link #registerAgent(String, String, String)}, with tags ({@code [a-z0-9][a-z0-9._-]{0,31}}, at most 20). */
  public Map<String, Object> registerAgent(String agentId, String name, String description, List<String> tags) throws BackendException {
    if (agentId == null || !ContractHeaders.AGENT_ID.matcher(agentId).matches()) {
      throw new BackendException("invalid agent id (use [A-Za-z0-9._-]{1,64})", 0, "invalid_agent_id", null);
    }
    String problem = AgentRegistration.agentProblem(agentId, name, description, tags);
    if (problem != null) throw new BackendException(problem, 0, "invalid_agent", null);
    Json.Obj body = Json.object().put("agent_id", agentId);
    if (name != null && !name.isBlank()) body.put("name", name.trim());
    body.put("description", description == null ? "" : description.trim());
    if (tags != null && !tags.isEmpty()) body.put("tags", List.copyOf(tags));
    body.put("lifecycle", "draft");
    return postJson("/api/v1/agents", body.map());
  }

  // ------------------------------------------------------------------------------------------
  // Registry v2 + invoke API (agent catalog, versions, invocations)
  // ------------------------------------------------------------------------------------------

  private static String agentPath(String agentId) throws BackendException {
    if (!AgentIds.agentId(agentId)) throw new BackendException("invalid agent id (use [A-Za-z0-9._-]{1,64})", 0, "invalid_agent_id", null);
    return "/api/v1/agents/" + AgentIds.encode(agentId);
  }

  private static void checkEnv(String env) throws BackendException {
    if (env != null && !AgentIds.env(env)) throw new BackendException("invalid environment: " + env, 0, "invalid_env", null);
  }

  private static void checkVersion(String version) throws BackendException {
    if (version != null && !AgentIds.version(version)) throw new BackendException("invalid version", 0, "invalid_version", null);
  }

  private static String invocationPath(String id) throws BackendException {
    if (!AgentIds.invocationId(id)) throw new BackendException("invalid invocation id", 0, "invalid_invocation_id", null);
    return "/api/v1/invocations/" + AgentIds.encode(id);
  }

  /** Builds {@code ?k=v&...} from key/value pairs, skipping null or blank values; values are percent-encoded. */
  static String query(String... kv) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i + 1 < kv.length; i += 2) {
      String v = kv[i + 1];
      if (v == null || v.isBlank()) continue;
      sb.append(sb.length() == 0 ? '?' : '&').append(kv[i]).append('=').append(AgentIds.encode(v.trim()));
    }
    return sb.toString();
  }

  /** Path of {@code POST /api/v1/agents/{id}/invoke?mode=...&env=...&version=...} (validated, encoded). */
  static String invokePath(String agentId, String env, String version, String mode) throws BackendException {
    String base = agentPath(agentId);
    checkEnv(env);
    checkVersion(version);
    return base + "/invoke" + query("mode", mode, "env", env, "version", version);
  }

  private Duration longTimeout() {
    Duration min = Duration.ofSeconds(135);
    return streamTimeout.compareTo(min) > 0 ? streamTimeout : min;
  }

  /** {@code GET /api/v1/catalog?q=&team=&tag=}: the agents the caller may run (any filter may be null). */
  public Catalog catalog(String q, String team, String tag) throws BackendException {
    if (q != null && q.length() > 200) throw new BackendException("search text is longer than 200 characters", 0, "invalid_query", null);
    if (team != null && team.length() > 64) throw new BackendException("invalid team", 0, "invalid_query", null);
    if (tag != null && tag.length() > 32) throw new BackendException("invalid tag", 0, "invalid_query", null);
    Map<String, Object> body = getJson("/api/v1/catalog" + query("q", q, "team", team, "tag", tag), true);
    if (Json.list(body, "items") == null) throw new BackendException("unexpected catalog response", 0, "invalid_response", null);
    return Catalog.from(body);
  }

  /** {@code GET /api/v1/agents/{id}/versions[?env=]}. */
  public List<AgentVersionInfo> agentVersions(String agentId, String env) throws BackendException {
    String path = agentPath(agentId) + "/versions";
    checkEnv(env);
    Map<String, Object> body = getJson(path + query("env", env), true);
    List<AgentVersionInfo> out = new ArrayList<>();
    List<Object> items = Json.list(body, "items");
    if (items != null) {
      for (Object o : items) {
        AgentVersionInfo v = AgentVersionInfo.from(o);
        if (v != null) out.add(v);
      }
    }
    return out;
  }

  /**
   * {@code POST /api/v1/agents/{id}/versions}: one HTTPS version ({@code protocol aig-http/1}); the auth part
   * is a secret ARN reference only. Validated locally first ({@code version_invalid}).
   */
  public AgentVersionInfo registerVersion(String agentId, AgentRegistration.VersionSpec spec) throws BackendException {
    String path = agentPath(agentId) + "/versions";
    String problem = AgentRegistration.versionProblem(spec);
    if (problem != null) throw new BackendException(problem, 0, "version_invalid", null);
    Map<String, Object> body = postJson(path, spec.toJson());
    AgentVersionInfo v = AgentVersionInfo.from(body.get("version"));
    if (v == null) throw new BackendException("unexpected version response", 0, "invalid_response", null);
    return v;
  }

  /** {@code POST /api/v1/agents/{id}/versions/{v}/verify?env=}: health, test invocation, gateway and trace checks. */
  public VerifyResult verifyVersion(String agentId, String version, String env) throws BackendException {
    String base = agentPath(agentId);
    if (!AgentIds.version(version)) throw new BackendException("invalid version", 0, "invalid_version", null);
    checkEnv(env);
    Map<String, Object> body = postJson(base + "/versions/" + AgentIds.encode(version) + "/verify" + query("env", env), Map.of(), longTimeout());
    return VerifyResult.from(body);
  }

  /** {@code POST /api/v1/agents/{id}/invoke?mode=sync}. env/version may be null (server default). */
  public InvokeResult invoke(String agentId, String env, String version, InvokeRequest request) throws BackendException {
    return InvokeResult.from(postJson(invokePath(agentId, env, version, "sync"), request.toJson(), longTimeout()));
  }

  /** {@code POST /api/v1/agents/{id}/invoke?mode=background}: 202 {@code {invocation_id, status: "queued", location}}. */
  public InvocationAccepted invokeBackground(String agentId, String env, String version, InvokeRequest request) throws BackendException {
    InvocationAccepted a = InvocationAccepted.from(postJson(invokePath(agentId, env, version, "background"), request.toJson()));
    if (!AgentIds.invocationId(a.invocationId())) throw new BackendException("unexpected background response", 0, "invalid_response", null);
    return a;
  }

  /** {@code GET /api/v1/invocations?mine=1&agent_id=&status=&limit=}. */
  public List<Invocation> invocations(boolean mine, String agentId, String status, int limit) throws BackendException {
    if (agentId != null && !AgentIds.agentId(agentId)) throw new BackendException("invalid agent id", 0, "invalid_agent_id", null);
    if (status != null && !AgentIds.RUN_STATUSES.contains(status)) throw new BackendException("invalid status", 0, "invalid_status", null);
    int lim = Math.max(1, Math.min(500, limit));
    return Invocation.list(getJson("/api/v1/invocations" + query("mine", mine ? "1" : null, "agent_id", agentId, "status", status, "limit", String.valueOf(lim)), true));
  }

  /** {@code GET /api/v1/invocations/{id}} (output included for the caller's own background runs). */
  public Invocation invocation(String id) throws BackendException {
    Invocation i = Invocation.from(getJson(invocationPath(id), true));
    if (i == null) throw new BackendException("unexpected invocation response", 0, "invalid_response", null);
    return i;
  }

  /** {@code POST /api/v1/invocations/{id}/cancel} (409 {@code invocation_finished} when it already ended). */
  public Invocation cancelInvocation(String id) throws BackendException {
    Invocation i = Invocation.from(postJson(invocationPath(id) + "/cancel", null));
    if (i == null) throw new BackendException("unexpected invocation response", 0, "invalid_response", null);
    return i;
  }

  /**
   * {@code POST /api/v1/agents/{id}/invoke?mode=stream} (SSE). Blocking: run it off the UI thread. Events go to
   * {@code listener} as they arrive; {@code cancel} (may be null) aborts the read and closes the connection,
   * which makes platform-api record the run as cancelled. HTTP errors before the stream starts are thrown;
   * once streaming, the outcome (including in-stream errors and truncation) is the returned result.
   */
  public AgentStream.Result invokeStream(String agentId, String env, String version, InvokeRequest request, AgentStreamListener listener,
      Cancellation cancel) throws BackendException {
    String path = invokePath(agentId, env, version, "stream");
    Map<String, String> headers = ContractHeaders.authHeaders(token());
    headers.put("accept", "text/event-stream");
    HttpRequest req = request(path, headers, streamTimeout)
        .header("content-type", "application/json")
        .POST(HttpRequest.BodyPublishers.ofString(Json.write(request.toJson()), StandardCharsets.UTF_8))
        .build();
    if (cancel != null && cancel.isCancelled()) return new AgentStream().cancelled();
    HttpResponse<InputStream> res;
    try {
      res = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
    } catch (java.net.http.HttpTimeoutException e) {
      throw new BackendException("request timed out");
    } catch (IOException e) {
      throw new BackendException(e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new BackendException("cancelled", 0, "cancelled", null);
    }
    String invocationId = res.headers().firstValue("x-aig-invocation-id").filter(AgentIds::invocationId).orElse(null);
    String trace = res.headers().firstValue("x-aig-trace-id").orElse(null);
    String ctype = res.headers().firstValue("content-type").orElse("");
    InputStream in = res.body();
    if (cancel != null) cancel.onCancel(() -> {
      try {
        in.close();
      } catch (IOException e) {
        // ignore
      }
    });
    try (in; Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
      if (res.statusCode() / 100 != 2) {
        BackendException e = readError(res.statusCode(), res.headers(), new String(in.readAllBytes(), StandardCharsets.UTF_8));
        throw new BackendException(e.getMessage(), e.status(), e.code(), e.traceId());
      }
      if (listener != null) listener.onOpen(invocationId, trace);
      AgentStream stream = new AgentStream(invocationId, trace);
      if (!ctype.contains("text/event-stream")) {
        // A JSON answer (sync shape): surface it as output + done.
        Map<String, Object> body = Json.parseObject(new String(in.readAllBytes(), StandardCharsets.UTF_8));
        if (body == null) throw new BackendException("unexpected invoke response", res.statusCode(), "invalid_response", trace);
        InvokeResult r = InvokeResult.from(body);
        String sse = "event: output\ndata: " + Json.object().put("output", r.output()).put("usage", r.usage()).put("trace_id", r.traceId()).opt("invocation_id", r.invocationId())
            + "\n\nevent: done\ndata: " + Json.object().put("status", r.status()).put("duration_ms", r.durationMs()).opt("invocation_id", r.invocationId()) + "\n\n";
        boolean delivered = deliver(stream.feed(sse), listener, cancel);
        return delivered ? stream.result(false) : stream.cancelled();
      }
      return readAgentStream(reader, stream, listener, cancel);
    } catch (IOException e) {
      AgentStream empty = new AgentStream(invocationId, trace);
      return cancel != null && cancel.isCancelled() ? empty.cancelled() : empty.result(false);
    }
  }

  /** Reads SSE text into {@code stream} until done, EOF or cancellation. */
  static AgentStream.Result readAgentStream(Reader reader, AgentStream stream, AgentStreamListener listener, Cancellation cancel) {
    char[] buf = new char[4096];
    try {
      int n;
      while (!stream.isDone() && (n = reader.read(buf)) >= 0) {
        if (cancel != null && cancel.isCancelled()) return stream.cancelled();
        if (!deliver(stream.feed(new String(buf, 0, n)), listener, cancel)) return stream.cancelled();
      }
      if (!stream.isDone() && !deliver(stream.end(), listener, cancel)) return stream.cancelled();
    } catch (IOException e) {
      // connection dropped or closed by cancel
    }
    return cancel != null && cancel.isCancelled() ? stream.cancelled() : stream.result(false);
  }

  private static boolean deliver(List<AgentEvent> events, AgentStreamListener listener, Cancellation cancel) {
    for (AgentEvent ev : events) {
      if (cancel != null && cancel.isCancelled()) return false;
      if (listener != null) listener.onEvent(ev);
    }
    return cancel == null || !cancel.isCancelled();
  }

  /**
   * Streams a chat completion through {@code POST /api/v1/llm/chat/completions} (SSE). Blocking;
   * run it off the UI thread. {@code cancelled} is polled between chunks.
   */
  public ChatResult chat(List<ChatMessage> messages, String jobProfile, String agentId, String traceId, Consumer<String> onDelta,
      BooleanSupplier cancelled) throws BackendException {
    Map<String, String> headers = ContractHeaders.chatHeaders(token(), jobProfile, agentId, traceId, true);
    List<Object> msgs = new ArrayList<>();
    for (ChatMessage m : messages) msgs.add(m.toJson());
    String body = Json.object().put("messages", msgs).put("stream", true).toString();
    HttpRequest req = request("/api/v1/llm/chat/completions", headers, streamTimeout)
        .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
        .build();
    HttpResponse<InputStream> res;
    try {
      res = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
    } catch (IOException e) {
      throw new BackendException(e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new BackendException("cancelled", 0, "cancelled", headers.get(ContractHeaders.TRACE));
    }
    String trace = res.headers().firstValue("x-aig-trace-id").orElse(headers.get(ContractHeaders.TRACE));
    String ctype = res.headers().firstValue("content-type").orElse("");
    try (InputStream in = res.body(); Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
      if (res.statusCode() / 100 != 2) {
        String errBody = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        BackendException e = readError(res.statusCode(), res.headers(), errBody);
        throw new BackendException(e.getMessage(), e.status(), e.code(), trace);
      }
      if (!ctype.contains("text/event-stream")) {
        String text = ChatChunks.deltaText(new String(in.readAllBytes(), StandardCharsets.UTF_8));
        if (!text.isEmpty() && onDelta != null) onDelta.accept(text);
        return new ChatResult(text, trace, true);
      }
      return readStream(reader, trace, onDelta, cancelled);
    } catch (IOException e) {
      if (cancelled != null && cancelled.getAsBoolean()) throw new BackendException("cancelled", 0, "cancelled", trace);
      throw new BackendException("stream interrupted: " + e.getMessage(), 0, "stream_error", trace);
    }
  }

  static ChatResult readStream(Reader reader, String trace, Consumer<String> onDelta, BooleanSupplier cancelled)
      throws IOException, BackendException {
    SseParser parser = new SseParser();
    StringBuilder text = new StringBuilder();
    char[] buf = new char[4096];
    boolean done = false;
    int n;
    outer:
    while ((n = reader.read(buf)) >= 0) {
      if (cancelled != null && cancelled.getAsBoolean()) throw new BackendException("cancelled", 0, "cancelled", trace);
      for (SseEvent ev : parser.feed(new String(buf, 0, n))) {
        if (handle(ev, text, trace, onDelta)) {
          done = true;
          break outer;
        }
      }
    }
    if (!done) {
      for (SseEvent ev : parser.end()) {
        if (handle(ev, text, trace, onDelta)) {
          done = true;
          break;
        }
      }
    }
    return new ChatResult(text.toString(), trace, done);
  }

  private static boolean handle(SseEvent ev, StringBuilder text, String trace, Consumer<String> onDelta) throws BackendException {
    if (ev.isDone()) return true;
    String err = ChatChunks.streamError(ev.data());
    if (err != null) throw new BackendException(err, 0, "stream_error", trace);
    String delta = ChatChunks.deltaText(ev.data());
    if (!delta.isEmpty()) {
      text.append(delta);
      if (onDelta != null) onDelta.accept(delta);
    }
    return false;
  }
}
