package com.aig.ai.ecosystem.core.config;

/** Result of validating a backend or authority URL. */
public final class UrlCheck {
  private final String url;
  private final String reason;

  private UrlCheck(String url, String reason) {
    this.url = url;
    this.reason = reason;
  }

  public static UrlCheck ok(String url) {
    return new UrlCheck(url, null);
  }

  public static UrlCheck fail(String reason) {
    return new UrlCheck(null, reason);
  }

  public boolean ok() {
    return url != null;
  }

  /** Normalised URL (no trailing slash) when {@link #ok()}. */
  public String url() {
    return url;
  }

  public String reason() {
    return reason;
  }

  @Override
  public String toString() {
    return ok() ? "ok(" + url + ")" : "fail(" + reason + ")";
  }
}
