package com.aig.ai.ecosystem.core.auth;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.function.LongSupplier;

/** One-time sign-in state nonces with a 10 minute expiry (port of the VSIX PendingStates). */
public final class PendingStates {
  public static final long STATE_TTL_MS = 10 * 60 * 1000L;
  private static final SecureRandom RANDOM = new SecureRandom();

  private final Map<String, Long> pending = new HashMap<>();
  private final LongSupplier now;
  private final long ttlMs;

  public PendingStates() {
    this(System::currentTimeMillis, STATE_TTL_MS);
  }

  public PendingStates(LongSupplier now, long ttlMs) {
    this.now = now;
    this.ttlMs = ttlMs;
  }

  /** 24 random bytes, base64url without padding (32 chars; matches the backend's state pattern). */
  public static String newState() {
    byte[] b = new byte[24];
    RANDOM.nextBytes(b);
    return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
  }

  public synchronized String issue() {
    prune();
    String s = newState();
    pending.put(s, now.getAsLong() + ttlMs);
    return s;
  }

  /** True once per issued, unexpired state; the state is consumed either way. */
  public synchronized boolean consume(String state) {
    if (state == null) return false;
    Long exp = pending.remove(state);
    return exp != null && exp >= now.getAsLong();
  }

  public synchronized int size() {
    prune();
    return pending.size();
  }

  private void prune() {
    long t = now.getAsLong();
    pending.values().removeIf(exp -> exp < t);
  }
}
