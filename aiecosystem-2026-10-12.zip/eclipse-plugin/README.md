# AIG AI Ecosystem: Eclipse plugin

Connects Eclipse to the AIG platform backend (`backend/platform-api`). It has the same features as the
VS Code extension: sign-in, a token usage and chat view, the tokenomics dashboard, agent scaffolding and
registration, local evals, and AIG light and dark themes.

**The plugin never holds a Portkey (or provider) key.** Model calls go to platform-api's
OpenAI-compatible proxy, and the backend adds the gateway key, config and metadata server-side.

## Install

1. Build it, or download the `aig-eclipse-update-site` artifact from CI:
   `releng/com.aig.ai.ecosystem.site/target/aig-eclipse-plugin-site-<version>.zip`.
2. In Eclipse 2024-09 (4.33) or newer, running on Java 17+: **Help > Install New Software... > Add... >
   Archive...**, pick the zip, select **AIG AI Ecosystem** and finish.
3. Restart. Then use **Window > Preferences > AIG AI Ecosystem** to set the backend URL and the Entra ID
   values for your environment.

The minimum Eclipse version is still an open item in the plan. The target platform is pinned to 4.33
because it is the last platform line that runs on Java 17.

## Features

| Where | What |
|---|---|
| **Window > Show View > AIG > AIG** | The `@aig/ui` sidebar: Token usage and Chat tabs. When you are signed out it shows the sign-in card |
| **Window > Show View > AIG > AIG Dashboard** | Your own live token usage (`GET /api/v1/usage/dashboard`, scoped to the signed-in user): tokens, requests, cost and usage per model for 7/30/90 days. Refresh only with the refresh icon; view toolbar: Switch User... |
| **Window > Show View > AIG > AIG Agents** | Agent catalog (`@aig/ui` `mountCatalog`): the agents you may run, search, team and tag filters, **Run**, **Register existing agent**, My recent runs. See [Agents](#agents-discover-run-register) |
| **Window > Show View > AIG > AIG Run** | Run one agent (`@aig/ui` `mountAgentRun`): form generated from the input schema or chat mode, streamed output, background runs with status |
| **AIG menu** | Sign In, Sign Out, Switch User..., Select Environment..., Open AIG View, Open Dashboard, Open Agents, New Agent..., Run Agent..., Register Existing Agent..., Run Evals, Update SDK in this project, Install / Update aig CLI, Ask AIG |
| Main toolbar | AIG view, Dashboard and Agents buttons |
| Status line | `AIG <env> · <connection>`, for example `AIG dev · open` or `not configured`. Click it to switch environment |
| Editor context menu | **Ask AIG**: the selection plus an instruction goes through the proxy, and the answer streams into the **AIG** console |
| **New Agent...** | Wizard (template, agent id, name, description, team, location). It scaffolds from the copy of `sdk/templates/` bundled at build time (built-in scaffolder, same rules as `aig init`), fills `aig-agent.yaml` (name, display name, description; the template's input/output schema), registers the agent as a **draft** with `POST /api/v1/agents` (`lifecycle: "draft"`) using your token, then creates the environment and installs the pinned SDK in a Job (console output, cancellable): Python `python3 -m venv .venv` + `.venv/bin/python -m pip install [--index-url ...] -e .[dev]`, Node `npm install`; a failed registry install is retried with the SDK bundled in the plugin (copied to `.aig-wheels/`). Finally it runs `aig doctor --json` and logs the summary |
| **Update SDK in this project** | Detects the selected Python / Node project, sets `aig-sdk[...]==<pin>` in `pyproject.toml` or `@aig/sdk` in `package.json` (bundled: `file:.aig-wheels/...`; monorepo: the repo's `sdk/typescript`), reinstalls and shows the `aig doctor` result |
| **Install / Update aig CLI** | `pipx install --force aig-sdk[evals]==<pin>` (index from the preferences, or the bundled wheel), else a private venv in `~/.aig/cli`; guidance when neither pipx nor Python is on `PATH` |
| **Run Evals** | Runs `aig eval run --md --out` in the selected project (it needs `aig-eval.yaml`). Output goes to the AIG console, and the Markdown summary goes to the **AIG Eval Report** view |
| Appearance | **AIG Light** and **AIG Dark** e4 themes (**Preferences > General > Appearance**). The embedded widgets follow whichever Eclipse theme is active: light, dark or high contrast |

Live data comes over the backend WebSocket (`GET /api/v1/ws`, `Authorization: Bearer` on the upgrade
request). The views show only the signed-in user's usage, and it is fetched once per sign-in, when a view opens
with nothing loaded, on a 7D/30D/90D change and when you click refresh: there is no auto refresh, polling or
refetch after chats or reconnects. A request uses `usage.subscribe` (answered with one `usage` frame), or one
`GET /api/v1/usage/dashboard` while the socket is down. Chats from Eclipse are sent with
`x-aig-agent-id: ide.eclipse`, the plugin's pre-registered agent.

## Agents: discover, run, register

Agents registered in platform-api (registry v2) can be found and run from Eclipse with the same widgets as the
VS Code extension and the web portal (`web/packages/ui` `mountCatalog` / `mountAgentRun`, built into
`web/agents.html` and `web/agentRun.html`). All calls go to the configured backend with your own token.

| Where | What |
|---|---|
| **AIG Agents** view | `GET /api/v1/catalog`: only the agents you may run (active, verified, shared with your team, your groups or org-wide). **Run** opens the AIG Run view for that agent (default version, normally prod). **Register existing agent** opens the wizard below. **My recent runs** is `GET /api/v1/invocations?mine=1`; clicking a run shows its status and, for your background runs, the stored output in the AIG Run view. View toolbar: Refresh, Register... |
| **AIG Run** view | Title `AIG Run: <agent id>`, description `<env> v<version>`. Form mode (fields from the version's input schema) or chat mode. **Run** streams (`POST /api/v1/agents/{id}/invoke?mode=stream`, SSE `delta` / `output` / `error` / `done`); **Cancel** closes the stream and calls `POST /api/v1/invocations/{id}/cancel`. **Run in background** uses `mode=background` (202, `queued`); the plugin polls `GET /api/v1/invocations/{id}` every 3 s until the run is final, then shows the output, writes a status-line message and the AIG console line, and pops up a small notification with **Show in AIG Run**. Copy puts the output on the clipboard (SWT `Clipboard`) |
| **AIG > Run Agent...** | Loads the catalog in a job and shows a filterable list; the picked agent opens in the AIG Run view |
| **AIG > Register Existing Agent...** | Wizard for an agent that already serves the `aig-http/1` contract (`POST /invocations`, `GET /ping`) behind HTTPS. Page 1: agent id, name, description, tags. Page 2: endpoint (`https://`, `http://localhost` only for env `local`; no credentials, query or fragment), environment, version, auth type (`none`, `api_key`, `oauth_client_credentials`) with the **Secrets Manager secret ARN** (`local:<NAME>` for env `local`), input schema JSON (paste, or **Load from file...**; must be a JSON object, at most 64 KiB), and **Verify after registering**. Finish: `POST /api/v1/agents` (draft; an existing agent you own gets the new version), `POST /api/v1/agents/{id}/versions` (`kind: https`, `protocol: aig-http/1`), then optionally `POST .../versions/{v}/verify?env=` and shows each check (health, invocation, gateway, trace). Values are validated with the same rules as platform-api before anything is sent |

Security of the agent features:

- The only credential the plugin sends is your own bearer token, in the `Authorization` header; it is never part of
  a URL. Agent ids, versions, environments and invocation ids are validated (`[A-Za-z0-9._-]{1,64}` and the
  contract patterns) and percent-encoded before they go into a path or query.
- The plugin never talks to an agent directly and never holds agent credentials. The Register wizard has no field
  for a secret: it accepts only a Secrets Manager ARN (`arn:aws:secretsmanager:...:secret:...`) or, for `local`,
  `local:<NAME>`; anything else (for example a pasted key) is refused. platform-api reads the secret with its own
  role when it invokes the agent.
- Background-run status is always read from the configured backend (`/api/v1/invocations/{id}`), never from the
  `location` the server returns. Redirects are still not followed.
- Widget messages (`catalog.refresh`, `agent.open`, `agent.invoke`, `agent.cancel`, `agent.poll`, `agent.run.show`,
  `agent.runs.refresh`, `agent.register`, `clipboard.copy`) are untrusted: `AgentMessage.parse` applies the rules of
  `parseWebviewMessage` (id regexes, exactly one of `input` / `messages`, input a plain object of at most 256 KiB,
  at most 200 chat messages of 32 000 characters, clipboard text at most 1 000 000 characters).
- Input and output are shown in the view only; they are not written to the AIG console or the Eclipse log.

## Preferences

All values are instance preferences of `com.aig.ai.ecosystem.ui`. They can be preset for a whole
installation with a `plugin_customization.ini` (see the template in the ui bundle).

| Key | Default | Meaning |
|---|---|---|
| `environment` | `dev` | `local`, `dev`, `stage` or `prod` |
| `jobProfile` | `general` | Sent as `x-aig-job-profile` |
| `devUser` | empty | Local only, optional: skips the browser and uses `dev:<email>` |
| `sdk.source` | `registry` | Where New Agent / Update SDK / Install aig CLI get the SDK: `registry` (pinned version from the internal index, bundled fallback), `bundled` (shipped in the plugin), `monorepo` (platform development: the repo's `sdk/` when the project is inside it) |
| `sdk.indexUrl` | empty | Python index serving `aig-sdk` (`pip --index-url`); empty = `PIP_INDEX_URL` / pip.conf. Placeholders and URLs with credentials are ignored |
| `sdk.npmRegistry` | empty | npm registry for the `@aig` scope; empty = `.npmrc` |
| `newAgent.setupEnvironment` | `true` | New Agent creates the environment, installs the SDK and runs `aig doctor` |
| `demoData` | `false` | **Temporary**, opt-in: the AIG views show sample data with a *Sample data* badge and Sign In starts a demo session; no backend is used. See [docs/demo-data.md](../docs/demo-data.md) |
| `<env>.backendUrl` | `http://localhost:8080` (local), `https://__AIG_BACKEND_URL_<ENV>__` | platform-api base URL |
| `<env>.tenantId` | `__AIG_ENTRA_TENANT_ID_<ENV>__` | Entra ID tenant (dev/stage/prod) |
| `<env>.clientId` | `__AIG_ENTRA_IDE_CLIENT_ID_<ENV>__` | Entra ID **public client** app registration for the IDE (redirect `http://127.0.0.1/callback`, any port) |
| `<env>.scope` | `api://__AIG_API_CLIENT_ID_<ENV>__/.default` | platform-api scope |
| `<env>.authority` | `https://login.microsoftonline.com` | Entra authority (always https) |

Placeholder rule, which is the same as the VSIX: a value that is empty, starts with `__REPLACE_ME`, or
contains a `__TOKEN__` is **not configured**. Plain `http` is allowed only for `local` with a loopback
host (`localhost`, `127.0.0.1`, `[::1]`). dev, stage and prod need `https`. URLs with credentials, a
query or a fragment are rejected.

## Sign-in modes

| Environment | Flow |
|---|---|
| dev / stage / prod | **Microsoft Entra ID, Authorization Code + PKCE** in the system browser (RFC 8252). The plugin listens on `http://127.0.0.1:<random port>/callback`, checks a one-time `state` (10 minute expiry), and exchanges the code with the PKCE verifier. There is no client secret. The access and refresh tokens are stored in **Eclipse Secure Storage** (`/com.aig.ai.ecosystem/<env>`) and refreshed 2 minutes before they expire |
| local | The backend's **local sign-in page** (`/auth/local/signin`, only when the backend runs `AIG_ENV=local` and `AIG_AUTH_MODE=dev`) with `redirect_uri=http://127.0.0.1:<random port>/auth/callback` and a one-time `state`. The resulting `dev:<email>` token only works on a local dev-mode backend. You can also set `devUser` to skip the browser. **Test with any user:** the sign-in card has an email field and a persona list (premium / standard / free, finance, routing admin, all `@aig.example`); **Sign In** with an email signs in as that user directly (no browser) and the views reload with that user's live data. **AIG > Switch User...** (also on the AIG and Dashboard view toolbars) asks for another email; Sign Out returns to the card, prefilled with the last email. Unavailable while `devUser` is set or outside local |

platform-api accepts these loopback redirects (IP literals only, plain http, explicit port) only in
local dev mode. See `backend/platform-api/tests/test_local_auth_loopback.py`.

## Security model

- No Portkey, provider or admin key exists in the plugin, its preferences or its storage. The only
  credential it holds is your own Entra ID token, or the local `dev:<email>`. CI unzips the update site
  and fails if it finds a key-shaped string.
- Requests carry only `authorization`, `x-aig-job-profile`, `x-aig-trace-id` and an optional
  `x-aig-agent-id` (backend/contracts/headers.md section 2). The plugin never sends `x-portkey-*`, and the Java
  contract tests check its headers byte for byte against `backend/contracts/fixtures`.
- Requests go only to the configured backend URL. Redirects are not followed, and `session.llm.base_url`
  is never used as a target.
- Embedded widgets are self-contained pages loaded with `setText`: inline CSS and JS under a nonce CSP
  (`default-src 'none'`) with a fresh nonce on every load, and logos as `data:` URIs. There are no remote
  resources, and any navigation away from the page is blocked. Widget messages are untrusted and are
  validated by `WebviewMessage.parse`, which applies the same rules as `parseWebviewMessage`. Host
  messages are serialised with a script-safe JSON writer.
- The loopback receiver binds `127.0.0.1` only and answers a single callback on the expected path.

## Layout

```
pom.xml                                   parent (Tycho 4.0.13)
releng/com.aig.ai.ecosystem.target/       pinned target platform (Eclipse 4.33 R-4.33-202409030240)
bundles/com.aig.ai.ecosystem.core/        pure Java, no UI: config, clients (REST, SSE, WebSocket), auth, live service, scaffolder,
                                          agent catalog / registration / invocation (core.invoke) and the agent widget bridge
bundles/com.aig.ai.ecosystem.ui/          views, commands, preferences, themes, wizard, status line
tests/com.aig.ai.ecosystem.core.tests/    fragment of core, JUnit 5, headless (tycho-surefire)
features/com.aig.ai.ecosystem.feature/    feature
releng/com.aig.ai.ecosystem.site/         p2 repository + zip
web/                                      esbuild script: @aig/ui + Eclipse host shim into ui/web/*.html
```

## Build and test

Needs Java 17, Maven 3.9 and Node 22 (for the widget bundle). Run these from the repo root:

```sh
make eclipse-build    # npm ci in web/ if needed, then mvn -B verify (all modules + site zip)
make eclipse-test     # core + headless tests only
make test             # scripts/test-all.sh runs mvn -B -q verify when mvn is installed
```

Or run `cd eclipse-plugin && mvn -B verify` directly. During `generate-resources`, the ui bundle
runs `node web/build.mjs --out bundles/com.aig.ai.ecosystem.ui` through `exec-maven-plugin`. That step:

1. builds `web/packages/design-tokens` and copies `dist/eclipse/aig-{light,dark}.css` to `css/`,
2. bundles `web/packages/ui` (`mountSidebar`, `mountDashboard`, `mountSignin`, `mountCatalog`, `mountAgentRun`) with `web/src/eclipseHost.ts`
   as minified IIFEs, and inlines each one into the real `renderShell` page as `web/<app>.html`. The
   build fails if a page references a remote resource or contains a key-shaped string,
3. copies `web/packages/brand-assets/eclipse/icons` (with `dark/`) to `icons/`,
4. copies `sdk/templates/*` without `.venv`, `node_modules`, caches, `.aig-wheels` or `.env` to `templates/`,
5. writes `sdk/manifest.json` (SDK pins) and builds the bundled aig-sdk wheel and @aig/sdk tarball into `sdk/`
   (`scripts/sdk-artifacts.mjs`: `pip wheel --no-deps sdk/python`, `npm pack sdk/typescript`, size budget 2 MiB each).
   This needs Python and `sdk/typescript/node_modules`; `AIG_SKIP_SDK_ARTIFACTS=1` writes the pins only.

These generated folders are gitignored. esbuild comes from `web/node_modules` (`npm ci` in `web/`) or,
failing that, from the toolchain `web/packages/ui` already uses. You can pass `-Daig.skipWeb=true` to reuse
existing output, and `-Dnode.executable=/path/to/node` to choose the Node binary.

### Java <-> JS bridge (WidgetHost)

| Direction | Mechanism |
|---|---|
| widget -> Java | `window.aigPost(json)`, an SWT `BrowserFunction`. It feeds `WidgetBridge.receive` -> `LiveService`; agent messages go to `AgentBridge` (platform-api client, background-run polling) whose UI actions run in `AgentUiHost` |
| Java -> widget | `browser.execute("window.__aigReceive(<json>)")`. The shim runs `usage` data through `parseDashboard` |
| theme | `window.__aigTheme('light' \| 'dark' \| 'hc' \| 'hc-light')` on e4 `THEME_CHANGED`. The initial theme is set in the page |
| widget state | `window.aigSaveState(json)`, restored as `window.__aigInitialState` when the page reloads |

## Known gaps

- The SWT views, menus, wizard and status line compile and are packaged, but the automated build does not
  run them because there is no display. Check them by hand under the Default and Dark themes, as the plan
  says.
- Entra ID sign-in is tested against a mock token endpoint only, not against a real tenant.
- Eclipse has no built-in automatic dark-icon switching. The plugin picks `icons/dark/` at runtime for view
  title images and the console. Icons declared statically in `plugin.xml` (menus and toolbar) use the
  light set.
- The bundled template copy stores `.gitignore` as `__dot__gitignore` (Tycho's default excludes would drop
  dotfiles); the built-in scaffolder restores it.
- Eclipse has no workspace-trust concept: New Agent / Update SDK / Install aig CLI run pip / npm / pipx only
  on an explicit user action, never on startup.
