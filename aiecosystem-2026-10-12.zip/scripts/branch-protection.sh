#!/usr/bin/env bash
# Branch protection for the AIG platform repo and for agent repos (docs/branch-protection.md).
# DRY RUN by default: prints the JSON body and the `gh api` call. --apply sends it (repo admin only).
#
#   scripts/branch-protection.sh --repo ORG/aiecosystem                    # platform profile, dry run
#   scripts/branch-protection.sh --repo ORG/claims-agent --profile agent   # agent repo, dry run
#   scripts/branch-protection.sh --repo ORG/claims-agent --profile agent --check "CI / test" --apply
#
# Options:
#   --repo OWNER/NAME   target repository (default: the `origin` remote of this checkout)
#   --branch NAME       protected branch (default: main)
#   --profile P         platform (every job of .github/workflows/ci.yml, incl. the image build check) |
#                       agent (evals gate "evals / Evals gate (.)" from sdk/templates/*/.github/workflows/evals.yml)
#   --check NAME        extra required status check (repeatable), e.g. the agent repo's own CI or image check
#   --reviewers N       required approving reviews (default 1)
#   --apply             call `gh api -X PUT repos/OWNER/NAME/branches/BRANCH/protection` (needs admin rights)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

repo="" branch="main" profile="platform" reviewers=1 apply=0
extra=()
while [ $# -gt 0 ]; do
  case "$1" in
    --repo) repo="${2:?--repo needs OWNER/NAME}"; shift 2 ;;
    --branch) branch="${2:?--branch needs a name}"; shift 2 ;;
    --profile) profile="${2:?--profile needs platform|agent}"; shift 2 ;;
    --check) extra+=("${2:?--check needs a name}"); shift 2 ;;
    --reviewers) reviewers="${2:?--reviewers needs a number}"; shift 2 ;;
    --apply) apply=1; shift ;;
    -h|--help) sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "branch-protection: unknown option $1 (see --help)" >&2; exit 2 ;;
  esac
done

case "$reviewers" in ''|*[!0-9]*) echo "branch-protection: --reviewers must be a number" >&2; exit 2 ;; esac
[ "$reviewers" -ge 1 ] || { echo "branch-protection: at least 1 reviewer is required (code-agent PRs need a human approval)" >&2; exit 2; }

if [ -z "$repo" ]; then
  url="$(git -C "$ROOT" remote get-url origin 2>/dev/null || true)"
  repo="$(printf '%s' "$url" | sed -E 's#^(git@[^:]+:|https?://[^/]+/)##; s#\.git$##')"
fi
case "$repo" in */*) ;; *) echo "branch-protection: pass --repo OWNER/NAME (no origin remote found)" >&2; exit 2 ;; esac

# Required status checks = check-run names (a job's `name:`; reusable workflows: "<caller job> / <job name>").
# Path-filtered CI jobs that are skipped report success, so requiring every job is safe.
checks=()
case "$profile" in
  platform)
    while IFS= read -r name; do [ -n "$name" ] && checks+=("$name"); done < <(
      python3 - "$ROOT/.github/workflows/ci.yml" <<'PY'
import re, sys
text = open(sys.argv[1]).read()
jobs = text[text.index("\njobs:\n"):]
for m in re.finditer(r"^  ([A-Za-z0-9_-]+):\n(?:    .*\n)*?    name: (.+)$", jobs, flags=re.M):
    print(m.group(2).strip().strip("'\""))
PY
    ) ;;
  agent) checks+=("evals / Evals gate (.)") ;;
  *) echo "branch-protection: --profile must be platform or agent" >&2; exit 2 ;;
esac
checks+=("${extra[@]+"${extra[@]}"}")
[ ${#checks[@]} -gt 0 ] || { echo "branch-protection: no required checks found" >&2; exit 2; }

body="$(python3 - "$reviewers" "${checks[@]}" <<'PY'
import json, sys
reviewers, checks = int(sys.argv[1]), sys.argv[2:]
print(json.dumps({
    # CI, evals gate and image check must pass on the latest commit of the PR branch.
    "required_status_checks": {"strict": True, "checks": [{"context": c} for c in dict.fromkeys(checks)]},
    # No admin bypass: the rules apply to everyone, including automation with admin rights.
    "enforce_admins": True,
    "required_pull_request_reviews": {
        "required_approving_review_count": reviewers,
        "dismiss_stale_reviews": True,
        "require_code_owner_reviews": False,
        # The last pusher cannot provide the approval: a PR opened or updated by the code agent
        # (workspace-orchestrator GitHub App) always needs a human approval.
        "require_last_push_approval": True,
        "bypass_pull_request_allowances": {"users": [], "teams": [], "apps": []},
    },
    "restrictions": None,
    "required_conversation_resolution": True,
    "required_linear_history": False,
    "allow_force_pushes": False,
    "allow_deletions": False,
    "block_creations": False,
}, indent=2))
PY
)"

endpoint="repos/$repo/branches/$branch/protection"
echo "# branch protection for $repo@$branch (profile: $profile)"
echo "# gh api -X PUT $endpoint -H 'Accept: application/vnd.github+json' --input - <<'JSON'"
echo "$body"
echo "# JSON"
if [ "$apply" -ne 1 ]; then
  echo "# dry run: nothing was changed. Re-run with --apply (repository admin) to set it." >&2
  exit 0
fi
command -v gh >/dev/null || { echo "branch-protection: gh (GitHub CLI) is not installed" >&2; exit 2; }
printf '%s' "$body" | gh api -X PUT "$endpoint" -H 'Accept: application/vnd.github+json' --input - >/dev/null
echo "branch-protection: applied to $repo@$branch" >&2
