#!/usr/bin/env python3
"""A tiny local stand-in for the self-hosted Portkey gateway (plus Fiddler and platform-api), for
running the starter templates without keys. Standard library only.

    python3 scripts/fake-portkey.py --port 0 --record /tmp/requests.jsonl --team sample-team

Prints ``listening <url>`` once ready. Endpoints:

- ``GET  /v1``                        Portkey gateway health probe (200)
- ``POST /v1/chat/completions``       OpenAI-style completion; first a ``tool_calls`` reply when
                                      the request carries tools, then a text answer that quotes
                                      the tool result
- ``GET  /v1/mcp-servers``            MCP registry (``aig-jira``)
- ``GET  /fiddler/v3/server-info``    Fiddler probe; ``POST /fiddler/v1/traces`` (and ``/v1/traces``) OTLP sink
- ``GET  /platform/api/v1/agents/ID`` agent registry (every id active, team ``--team``)

Every request is appended to ``--record`` as JSON (method, path, headers, body as base64).
This is NOT Portkey: it does no routing, guardrails or required-metadata enforcement.
"""

from __future__ import annotations

import argparse
import base64
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

LOCK = threading.Lock()


def completion(message: dict, finish: str, n: int) -> dict:
    return {
        "id": f"chatcmpl-fake-{n}",
        "object": "chat.completion",
        "created": 1,
        "model": "fake-served-model",
        "choices": [{"index": 0, "message": message, "finish_reason": finish}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }


def make_handler(record: str, team: str):
    counter = {"n": 0}

    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, body: object) -> None:
            data = json.dumps(body).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _serve(self) -> None:
            length = int(self.headers.get("content-length") or 0)
            raw = self.rfile.read(length) if length else b""
            with LOCK, open(record, "a") as fh:
                fh.write(json.dumps({
                    "method": self.command,
                    "path": self.path,
                    "headers": {k.lower(): v for k, v in self.headers.items()},
                    "body_b64": base64.b64encode(raw).decode(),
                }) + "\n")
            path = self.path.split("?", 1)[0]
            if path == "/v1" or path == "/v1/":
                return self._send(200, {"status": "fake portkey gateway"})
            if path == "/v1/chat/completions":
                counter["n"] += 1
                req = json.loads(raw or b"{}")
                msgs = req.get("messages") or []
                last = msgs[-1] if msgs else {}
                if last.get("role") == "tool":
                    msg = {"role": "assistant", "content": f"The indicative premium is {last.get('content')}."}
                    return self._send(200, completion(msg, "stop", counter["n"]))
                tools = req.get("tools") or []
                if tools:
                    name = tools[0]["function"]["name"]
                    args = {"insured_sum": 250000, "risk_class": "standard"} if name == "quote_premium" else {}
                    msg = {"role": "assistant", "content": None, "tool_calls": [
                        {"id": "call_1", "type": "function", "function": {"name": name, "arguments": json.dumps(args)}}
                    ]}
                    return self._send(200, completion(msg, "tool_calls", counter["n"]))
                return self._send(200, completion({"role": "assistant", "content": "hello from fake portkey"}, "stop",
                                                  counter["n"]))
            if path == "/v1/mcp-servers":
                return self._send(200, {"data": [{"slug": "aig-jira", "status": "active"}]})
            if path == "/fiddler/v3/server-info":
                return self._send(200, {"server_version": "fake"})
            if path in ("/fiddler/v1/traces", "/v1/traces"):  # fiddler-langgraph keeps only scheme://host
                return self._send(200, {})
            if path.startswith("/platform/api/v1/agents/"):
                agent = path.rsplit("/", 1)[-1]
                return self._send(200, {"agent_id": agent, "team": team, "status": "active"})
            return self._send(404, {"error": "not found"})

        do_GET = do_POST = do_HEAD = _serve

        def log_message(self, *args: object) -> None:
            return None

    return Handler


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=0)
    ap.add_argument("--record", required=True)
    ap.add_argument("--team", default="sample-team")
    args = ap.parse_args()
    open(args.record, "w").close()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(args.record, args.team))
    print(f"listening http://127.0.0.1:{server.server_address[1]}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
