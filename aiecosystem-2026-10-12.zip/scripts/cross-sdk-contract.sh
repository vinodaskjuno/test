#!/usr/bin/env bash
# Cross-SDK contract check: the Python SDK (aig_sdk) and the TypeScript SDK (@aig/sdk) must emit
# byte-identical Portkey headers and Fiddler span tags (or the same error code/field) for every
# `kind: sdk` fixture in backend/contracts/fixtures, and both must equal the fixtures' `expected` blocks.
# Backend mode (`@aig/sdk/platform`, TypeScript only) must reproduce every `kind: backend_client`
# fixture (`x-aig-*` headers) byte for byte, from both its CJS and ESM builds.
# The serve helpers (`aig_sdk.serve`, `@aig/sdk/serve`) must answer every `kind: agent_invocation`
# fixture byte-identically (JSON bodies, SSE framing, error envelopes, and the Portkey metadata / span
# tags of a model call made inside the invocation), and read every template's aig-agent.yaml (plus a
# YAML-subset fixture) into the same document (`GET /schema`).
#
#   scripts/cross-sdk-contract.sh        (needs sdk/python/.venv and sdk/typescript/node_modules: make setup)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FIXTURES="$ROOT/backend/contracts/fixtures"
PY="$ROOT/sdk/python/.venv/bin/python"
TS_DIR="$ROOT/sdk/typescript"

[ -x "$PY" ] || { echo "cross-sdk: no sdk/python/.venv (run: make setup)" >&2; exit 2; }
[ -d "$TS_DIR/node_modules" ] || { echo "cross-sdk: no sdk/typescript/node_modules (run: make setup)" >&2; exit 2; }

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

(cd "$TS_DIR" && npx --no-install tsup --silent >/dev/null)
"$PY" -m aig_sdk.conformance "$FIXTURES" > "$tmp/python.json"
node "$TS_DIR/dist/conformance.cjs" "$FIXTURES" > "$tmp/typescript-cjs.json"
node "$TS_DIR/dist/conformance.js" "$FIXTURES" > "$tmp/typescript-esm.json"

# The fixtures' own expected blocks, in the same canonical layout.
"$PY" - "$FIXTURES" > "$tmp/expected.json" <<'PYEOF'
import json, pathlib, sys
fx = [json.loads(p.read_text()) for p in sorted(pathlib.Path(sys.argv[1]).glob("*.json"))]
out = {f["name"]: f["expected"] for f in fx if f["kind"] == "sdk"}
sys.stdout.write(json.dumps(out, sort_keys=True, indent=2) + "\n")
PYEOF
node "$TS_DIR/dist/conformance.cjs" --kind backend_client "$FIXTURES" > "$tmp/backend-cjs.json"
node "$TS_DIR/dist/conformance.js" --kind backend_client "$FIXTURES" > "$tmp/backend-esm.json"
"$PY" - "$FIXTURES" > "$tmp/backend-expected.json" <<'PYEOF'
import json, pathlib, sys
fx = [json.loads(p.read_text()) for p in sorted(pathlib.Path(sys.argv[1]).glob("*.json"))]
out = {f["name"]: f["expected"] for f in fx if f["kind"] == "backend_client"}
sys.stdout.write(json.dumps(out, sort_keys=True, indent=2) + "\n")
PYEOF

"$PY" -m aig_sdk.conformance --kind agent_invocation "$FIXTURES" > "$tmp/invocation-python.json"
node "$TS_DIR/dist/conformance.cjs" --kind agent_invocation "$FIXTURES" > "$tmp/invocation-cjs.json"
node "$TS_DIR/dist/conformance.js" --kind agent_invocation "$FIXTURES" > "$tmp/invocation-esm.json"

descriptors=("$ROOT"/sdk/templates/*/aig-agent.yaml "$TS_DIR/test/serve/descriptor-subset.yaml")
"$PY" - "${descriptors[@]}" > "$tmp/descriptors-python.json" <<'PYEOF'
import json, os, sys
from aig_sdk.serve import load_descriptor
out = {os.path.relpath(p): load_descriptor(p) for p in sys.argv[1:]}
sys.stdout.write(json.dumps(out, sort_keys=True, indent=2, ensure_ascii=False) + "\n")
PYEOF
node - "${descriptors[@]}" > "$tmp/descriptors-typescript.json" <<JSEOF
const path = require("node:path");
const { loadDescriptor } = require("$TS_DIR/dist/serve.cjs");
const sort = (o) => Array.isArray(o) ? o.map(sort) : o && typeof o === "object" ? Object.fromEntries(Object.keys(o).sort().map((k) => [k, sort(o[k])])) : o;
const out = {};
for (const p of process.argv.slice(2)) out[path.relative(process.cwd(), p)] = loadDescriptor(p);
process.stdout.write(JSON.stringify(sort(out), null, 2) + "\n");
JSEOF

status=0
for pair in "python.json typescript-cjs.json" "python.json typescript-esm.json" "expected.json python.json" \
  "backend-expected.json backend-cjs.json" "backend-expected.json backend-esm.json" \
  "invocation-python.json invocation-cjs.json" "invocation-python.json invocation-esm.json" \
  "descriptors-python.json descriptors-typescript.json"; do
  set -- $pair
  if diff -u "$tmp/$1" "$tmp/$2" > "$tmp/diff.txt"; then
    echo "identical: $1 == $2"
  else
    echo "MISMATCH: $1 != $2" >&2
    cat "$tmp/diff.txt" >&2
    status=1
  fi
done
count=$("$PY" -c 'import json,sys; print(len(json.load(open(sys.argv[1]))))' "$tmp/python.json")
sha=$(shasum -a 256 "$tmp/python.json" | cut -c1-16)
bcount=$("$PY" -c 'import json,sys; print(len(json.load(open(sys.argv[1]))))' "$tmp/backend-expected.json")
icount=$("$PY" -c 'import json,sys; print(len(json.load(open(sys.argv[1]))))' "$tmp/invocation-python.json")
isha=$(shasum -a 256 "$tmp/invocation-python.json" | cut -c1-16)
[ $status -eq 0 ] && echo "cross-sdk contract: OK ($count sdk fixtures, Python == TypeScript (CJS, ESM) == expected, sha256 $sha; $bcount backend_client fixtures, backend-mode x-aig-* builder (CJS, ESM) == expected; $icount agent_invocation fixtures, serve helpers Python == TypeScript (CJS, ESM), sha256 $isha; ${#descriptors[@]} aig-agent.yaml documents identical)"
exit $status
