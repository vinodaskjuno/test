## What and why

<!-- What does this change do, and which docs/IMPLEMENTATION_PLAN.md phase/task does it advance? -->

Phase / task:

## How it was tested

- [ ] `make test` passes locally (contracts, backend, VS Code extension, packages)
- [ ] New behaviour has tests
- [ ] Verified against a real system (Portkey / Fiddler / Entra ID / AWS)? If yes, which one:

## Contract and security checklist

- [ ] No real keys, `.env` files, `config/users.yaml` or private keys are added (`make secrets-scan`)
- [ ] Clients (VSIX, Eclipse, web) still hold no Portkey key; model calls go through platform-api
- [ ] If headers, metadata, span tags, `AIG_*` variables or error codes changed: `backend/contracts/` is
      updated first, fixtures regenerated, and both SDKs / platform-api follow
- [ ] No fail-open switches added (no gateway, no Fiddler, no agent)
- [ ] `docs/PROGRESS.md` updated
