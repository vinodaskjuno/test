"""Agent eval suite: score agent outputs against expected properties, for registry promotion.

``suite.yaml`` lists cases: an agent, the sample spec and fixtures it reads (``evals/specs``), and checks on its
typed output (``AgentResult.output``). Property checks are pure and deterministic. ``rubric`` checks are judged by
the Agent Evaluation agent (``aidlc.orchestrator.evaluation.grade``) in live mode; their grades are recorded with
the results, so re-scoring recorded results stays deterministic. A rubric check without a grade is skipped.

    # score recorded results (JSONL of {"case": id, "result": AgentResult, "grades": {check: score}}), no model access
    python evals/agent-evals/run_evals.py --results results.jsonl
    # run the agents (and the rubric grader) through the configured backend, then score (needs model access:
    # AWS credentials for Amazon Bedrock, or ANTHROPIC_API_KEY with AIDLC_BEDROCK_ENABLED=false)
    python evals/agent-evals/run_evals.py --agent adversary --record results.jsonl
    # also record each agent's score for its version in the registry, which gates promotion (maintainer token)
    python evals/agent-evals/run_evals.py --results results.jsonl --submit --api https://aidlc.example --token T

Exit codes: 0 every scored agent meets ``min_score``; 1 at least one does not; 2 cannot run (no model access, bad input,
submission refused).
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml
from aidlc_sdk import AidlcError, Client

from aidlc.contracts import AgentCall, AgentResult, SourceDoc
from aidlc.platform import model_access

HERE = Path(__file__).resolve().parent
SPECS_DIR = HERE.parent / "specs"
DEFAULT_SUITE = HERE / "suite.yaml"
SEVERITY_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
CHECK_TYPES = {
    "min_count",
    "max_count",
    "nonempty",
    "equals",
    "all_cited",
    "list_matches",
    "finding_matches",
    "no_finding_matches",
    "max_cost_usd",
    "rubric",
}
DEFAULT_RUBRIC_PASS = 0.7


# ---------- suite model ----------


@dataclass(frozen=True)
class Check:
    type: str
    params: dict[str, Any]
    weight: float = 1.0

    @property
    def label(self) -> str:
        detail = ", ".join(f"{k}={v}" for k, v in sorted(self.params.items()))
        return f"{self.type}({detail})"


@dataclass(frozen=True)
class Case:
    id: str
    agent: str
    checks: list[Check]
    sources: list[str] = field(default_factory=list)  # spec files (relative to evals/specs) -> inputs["sources"]
    files: dict[str, str] = field(default_factory=dict)  # input key -> file (relative to evals/specs), text inlined
    inputs: dict[str, Any] = field(default_factory=dict)  # literal inputs, e.g. {"mode": "diff"}
    description: str = ""


@dataclass(frozen=True)
class Suite:
    version: int
    min_score: float
    cases: list[Case]

    def for_agent(self, agent: str | None) -> list[Case]:
        return [c for c in self.cases if agent is None or c.agent == agent]


class SuiteError(ValueError):
    pass


def parse_suite(raw: Mapping[str, Any]) -> Suite:
    cases: list[Case] = []
    seen: set[str] = set()
    for item in raw.get("cases") or []:
        case_id = item.get("id")
        if not case_id or case_id in seen:
            raise SuiteError(f"case ids must be present and unique: {case_id!r}")
        seen.add(case_id)
        if not item.get("agent"):
            raise SuiteError(f"{case_id}: missing agent")
        checks = []
        for spec in item.get("checks") or []:
            params = {k: v for k, v in spec.items() if k not in {"type", "weight"}}
            if spec.get("type") not in CHECK_TYPES:
                raise SuiteError(f"{case_id}: unknown check type {spec.get('type')!r}")
            if spec["type"] == "rubric" and not str(params.get("criteria", "")).strip():
                raise SuiteError(f"{case_id}: a rubric check needs criteria")
            checks.append(Check(type=spec["type"], params=params, weight=float(spec.get("weight", 1.0))))
        if not checks:
            raise SuiteError(f"{case_id}: no checks")
        cases.append(
            Case(
                id=case_id,
                agent=item["agent"],
                checks=checks,
                sources=list(item.get("sources") or []),
                files=dict(item.get("files") or {}),
                inputs=dict(item.get("inputs") or {}),
                description=item.get("description", ""),
            )
        )
    if not cases:
        raise SuiteError("suite has no cases")
    return Suite(version=int(raw.get("version", 1)), min_score=float(raw.get("min_score", 0.8)), cases=cases)


def load_suite(path: Path = DEFAULT_SUITE) -> Suite:
    return parse_suite(yaml.safe_load(path.read_text(encoding="utf-8")) or {})


# ---------- scoring (pure) ----------


@dataclass(frozen=True)
class CheckResult:
    check: str
    passed: bool
    detail: str = ""
    skipped: bool = False  # an ungraded rubric check: excluded from the score


Grades = Mapping[str, float]  # rubric check label -> grade in [0, 1]


@dataclass(frozen=True)
class CaseScore:
    case_id: str
    agent: str
    score: float
    checks: list[CheckResult]
    error: str | None = None


@dataclass(frozen=True)
class AgentScore:
    agent: str
    score: float
    cases: int
    passed: bool
    version: str | None = None  # the agent version the results came from


def resolve(output: Any, path: str) -> Any:
    """Dotted path into dicts/lists: ``fix_tickets.0.files``. Missing keys resolve to ``None``."""
    node = output
    for part in path.split(".") if path else []:
        if isinstance(node, Mapping):
            node = node.get(part)
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            return None
    return node


def _text(item: Any) -> str:
    return item if isinstance(item, str) else json.dumps(item, sort_keys=True, default=str)


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _findings(output: Mapping[str, Any], path: str | None) -> list[Mapping[str, Any]]:
    if path:
        return [f for f in _as_list(resolve(output, path)) if isinstance(f, Mapping)]
    # FindingsOutput.findings, VerdictsOutput.findings, JudgeOutput.blocking/non_blocking
    found: list[Mapping[str, Any]] = []
    for key in ("findings", "blocking", "non_blocking"):
        found.extend(f for f in _as_list(output.get(key)) if isinstance(f, Mapping))
    return found


def _finding_hits(output: Mapping[str, Any], params: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    pattern = re.compile(params["pattern"])
    min_rank = SEVERITY_RANK[params.get("min_severity", "info")]
    hits = []
    for f in _findings(output, params.get("path")):
        haystack = " ".join(str(f.get(k) or "") for k in ("rule", "message", "evidence", "file"))
        if not pattern.search(haystack):
            continue
        if SEVERITY_RANK.get(str(f.get("severity")), -1) < min_rank:
            continue
        if params.get("blocking") is not None and bool(f.get("blocking")) != bool(params["blocking"]):
            continue
        hits.append(f)
    return hits


def evaluate_check(check: Check, result: AgentResult) -> CheckResult:
    p, out = check.params, result.output
    match check.type:
        case "min_count":
            n = len(_as_list(resolve(out, p["path"])))
            return CheckResult(check.label, n >= int(p["min"]), f"count={n}")
        case "max_count":
            n = len(_as_list(resolve(out, p["path"])))
            return CheckResult(check.label, n <= int(p["max"]), f"count={n}")
        case "nonempty":
            value = resolve(out, p["path"])
            return CheckResult(check.label, bool(value), f"value={_text(value)[:80]}")
        case "equals":
            value = resolve(out, p["path"])
            return CheckResult(check.label, value == p["value"], f"value={value!r}")
        case "all_cited":
            items = [i for i in _as_list(resolve(out, p["path"])) if isinstance(i, Mapping)]
            uncited = [str(i.get("id", "?")) for i in items if not i.get("citations")]
            ok = bool(items) and not uncited
            return CheckResult(check.label, ok, f"uncited={uncited}" if uncited else f"items={len(items)}")
        case "list_matches":
            pattern = re.compile(p["pattern"])
            n = sum(1 for item in _as_list(resolve(out, p["path"])) if pattern.search(_text(item)))
            return CheckResult(check.label, n >= int(p.get("min", 1)), f"matches={n}")
        case "finding_matches":
            n = len(_finding_hits(out, p))
            return CheckResult(check.label, n >= int(p.get("min", 1)), f"matches={n}")
        case "no_finding_matches":
            n = len(_finding_hits(out, p))
            return CheckResult(check.label, n == 0, f"matches={n}")
        case "max_cost_usd":
            return CheckResult(check.label, result.cost_usd <= float(p["value"]), f"cost={result.cost_usd:.4f}")
        case "rubric":
            raise SuiteError("rubric checks are scored from grades (see score_case)")
    raise SuiteError(f"unknown check type {check.type!r}")


def rubric_result(check: Check, grades: Grades) -> CheckResult:
    grade = grades.get(check.label)
    if grade is None:
        return CheckResult(check.label, False, "not graded (needs the live rubric grader)", skipped=True)
    threshold = float(check.params.get("min", DEFAULT_RUBRIC_PASS))
    return CheckResult(check.label, grade >= threshold, f"grade={grade:.2f} (pass >= {threshold:.2f})")


def score_case(case: Case, result: AgentResult, grades: Grades | None = None) -> CaseScore:
    if result.agent_id != case.agent:
        return CaseScore(case.id, case.agent, 0.0, [], error=f"result is for {result.agent_id}, not {case.agent}")
    if not result.ok:
        return CaseScore(case.id, case.agent, 0.0, [], error=result.error or "agent call failed")
    checks = [rubric_result(c, grades or {}) if c.type == "rubric" else evaluate_check(c, result) for c in case.checks]
    scored = [(c, r) for c, r in zip(case.checks, checks, strict=True) if not r.skipped]
    if not scored:
        return CaseScore(case.id, case.agent, 0.0, checks, error="no graded checks")
    total = sum(c.weight for c, _ in scored)
    earned = sum(c.weight for c, r in scored if r.passed)
    return CaseScore(case.id, case.agent, round(earned / total, 4), checks)


def score_agents(
    scores: Iterable[CaseScore], min_score: float, results: Mapping[str, AgentResult] | None = None
) -> list[AgentScore]:
    by_agent: dict[str, list[float]] = {}
    versions: dict[str, set[str]] = {}
    for s in scores:
        by_agent.setdefault(s.agent, []).append(s.score)
        result = (results or {}).get(s.case_id)
        if result is not None and result.agent_id == s.agent:
            versions.setdefault(s.agent, set()).add(result.agent_version)
    out = []
    for agent, values in sorted(by_agent.items()):
        mean = round(sum(values) / len(values), 4)
        seen = versions.get(agent, set())
        version = next(iter(seen)) if len(seen) == 1 else None
        out.append(AgentScore(agent, mean, len(values), mean >= min_score, version))
    return out


def score_results(
    suite: Suite, results: Mapping[str, AgentResult], grades: Mapping[str, Grades] | None = None
) -> list[CaseScore]:
    """Score every case that has a result; a case without one scores 0 with an error."""
    scores = []
    for case in suite.cases:
        result = results.get(case.id)
        if result is None:
            scores.append(CaseScore(case.id, case.agent, 0.0, [], error="no result recorded"))
        else:
            scores.append(score_case(case, result, (grades or {}).get(case.id)))
    return scores


# ---------- inputs and live runs ----------


def build_inputs(case: Case, specs_dir: Path = SPECS_DIR) -> dict[str, Any]:
    """Assemble ``AgentCall.inputs`` for a case. Spec text goes in ``sources`` (untrusted; wrapped by the runner)."""
    inputs: dict[str, Any] = dict(case.inputs)
    if case.sources:
        inputs["sources"] = [
            SourceDoc(kind="markdown", name=src, content=(specs_dir / src).read_text(encoding="utf-8")).model_dump()
            for src in case.sources
        ]
    for key, rel in case.files.items():
        inputs[key] = (specs_dir / rel).read_text(encoding="utf-8")
    return inputs


def missing_files(suite: Suite, specs_dir: Path = SPECS_DIR) -> list[str]:
    paths = [p for c in suite.cases for p in [*c.sources, *c.files.values()]]
    return sorted({p for p in paths if not (specs_dir / p).is_file()})


def load_results(path: Path) -> tuple[dict[str, AgentResult], dict[str, dict[str, float]]]:
    """Recorded results and rubric grades, by case id."""
    results: dict[str, AgentResult] = {}
    grades: dict[str, dict[str, float]] = {}
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        record = json.loads(line)
        if "case" not in record or "result" not in record:
            raise SuiteError(f"{path}:{n}: expected {{'case': ..., 'result': ...}}")
        results[record["case"]] = AgentResult.model_validate(record["result"])
        grades[record["case"]] = {str(k): float(v) for k, v in (record.get("grades") or {}).items()}
    return results, grades


def write_results(path: Path, results: Mapping[str, AgentResult], grades: Mapping[str, Grades]) -> None:
    with path.open("w", encoding="utf-8") as fh:
        for case_id, result in results.items():
            grade = dict(grades.get(case_id, {}))
            record = {"case": case_id, "result": result.model_dump(mode="json"), "grades": grade}
            fh.write(json.dumps(record) + "\n")


async def run_live(cases: Sequence[Case]) -> dict[str, AgentResult]:
    """Invoke each case's agent through the platform's agent backend (Claude Agent SDK)."""
    from aidlc.platform.factory import get_agent_backend
    from aidlc.platform.registry import get_registry
    from aidlc.platform.security.untrusted_input import wrap_untrusted

    registry = get_registry()
    backend = get_agent_backend()
    results: dict[str, AgentResult] = {}
    for case in cases:
        spec = registry.get(case.agent)
        inputs = build_inputs(case)
        sources = inputs.pop("sources", [])
        system_prompt = "\n\n".join(
            part
            for part in (
                registry.ethos,
                spec.prompt,
                "Respond with JSON only, matching this schema:\n" + json.dumps(spec.output_json_schema()),
            )
            if part
        )
        user_parts = [f"## {key}\n{_text(value)}" for key, value in inputs.items()]
        user_parts += [wrap_untrusted(s["name"], s["content"]) for s in sources]
        call = AgentCall(agent_id=case.agent, run_id=f"eval-{case.id}", project_id="evals", inputs=inputs)
        results[case.id] = await backend.invoke(call, system_prompt=system_prompt, user_prompt="\n\n".join(user_parts))
    return results


async def grade_rubrics(cases: Sequence[Case], results: Mapping[str, AgentResult]) -> dict[str, dict[str, float]]:
    """Ask the Agent Evaluation grader to judge every rubric check whose case has a successful result.

    Returns no grades when the orchestrator's grader is not installed; the rubric checks are then skipped."""
    try:
        from aidlc.orchestrator.evaluation import grade
    except ImportError:
        return {}
    grades: dict[str, dict[str, float]] = {}
    for case in cases:
        result = results.get(case.id)
        if result is None or not result.ok:
            continue
        for check in (c for c in case.checks if c.type == "rubric"):
            rubric = {
                "id": case.id,
                "description": case.description,
                "rubric": check.params["criteria"],
                "inputs": build_inputs(case),
            }
            graded = await grade(rubric, case.agent, result.output)
            value = float(getattr(graded, "score", graded))
            grades.setdefault(case.id, {})[check.label] = min(max(value, 0.0), 1.0)
    return grades


# ---------- registry submission ----------


def submission_report(suite: Suite, agent: AgentScore, scores: Sequence[CaseScore]) -> dict[str, Any]:
    return {
        "suite_version": suite.version,
        "min_score": suite.min_score,
        "passed": agent.passed,
        "cases": [asdict(s) for s in scores if s.agent == agent.agent],
    }


def submit(client: Client, suite: Suite, agents: Sequence[AgentScore], scores: Sequence[CaseScore]) -> list[str]:
    """Record each agent's aggregate score for the version it was evaluated at; returns the problems found."""
    problems: list[str] = []
    for agent in agents:
        if agent.version is None:
            problems.append(f"{agent.agent}: no single agent version in the results; not submitted")
            continue
        try:
            client.record_agent_eval(agent.agent, agent.version, agent.score, submission_report(suite, agent, scores))
        except AidlcError as exc:
            problems.append(f"{agent.agent}@{agent.version}: {exc}")
    return problems


# ---------- CLI ----------


def _report(scores: list[CaseScore], agents: list[AgentScore], min_score: float) -> str:
    lines = [f"{'case':<40} {'agent':<32} score"]
    for s in scores:
        lines.append(f"{s.case_id:<40} {s.agent:<32} {s.score:.2f}" + (f"  ({s.error})" if s.error else ""))
        lines.extend(
            f"    {'SKIP' if c.skipped else 'PASS' if c.passed else 'FAIL'} {c.check} -> {c.detail}" for c in s.checks
        )
    lines.append("")
    lines.append(f"{'agent':<32} cases score  (min {min_score:.2f})")
    lines.extend(f"{a.agent:<32} {a.cases:>5} {a.score:.2f}  {'ok' if a.passed else 'BELOW'}" for a in agents)
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run and score the AIDLC agent eval suite.")
    parser.add_argument("--suite", type=Path, default=DEFAULT_SUITE)
    parser.add_argument("--agent", help="only cases for this agent id")
    parser.add_argument("--results", type=Path, help="score recorded results (JSONL) instead of calling agents")
    parser.add_argument("--record", type=Path, help="write live results to this JSONL file")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument("--submit", action="store_true", help="record each agent's score in the platform registry")
    parser.add_argument("--api", default=os.environ.get("AIDLC_API_URL"), help="control-plane URL (AIDLC_API_URL)")
    parser.add_argument("--token", default=os.environ.get("AIDLC_TOKEN"), help="maintainer API token (AIDLC_TOKEN)")
    args = parser.parse_args(argv)
    if args.submit and not (args.api and args.token):
        print("--submit needs --api and --token (or AIDLC_API_URL and AIDLC_TOKEN)", file=sys.stderr)
        return 2

    try:
        suite = load_suite(args.suite)
    except (OSError, SuiteError, yaml.YAMLError) as exc:
        print(f"cannot load suite: {exc}", file=sys.stderr)
        return 2
    cases = suite.for_agent(args.agent)
    if not cases:
        print(f"no cases for agent {args.agent!r}", file=sys.stderr)
        return 2
    selected = Suite(suite.version, suite.min_score, cases)

    if args.results:
        results, grades = load_results(args.results)
    else:
        problem = model_access.local_problem()
        if problem:
            print(
                f"{problem}: live agent evals call Claude ({model_access.local_fix()}). "
                "Or score recorded results with --results <file.jsonl>.",
                file=sys.stderr,
            )
            return 2
        results = asyncio.run(run_live(cases))
        grades = asyncio.run(grade_rubrics(cases, results))
        if args.record:
            write_results(args.record, results, grades)

    scores = score_results(selected, results, grades)
    agents = score_agents(scores, suite.min_score, results)
    if args.json:
        print(json.dumps({"cases": [asdict(s) for s in scores], "agents": [asdict(a) for a in agents]}, indent=2))
    else:
        print(_report(scores, agents, suite.min_score))
    if args.submit:
        with Client(args.api, args.token) as client:
            problems = submit(client, selected, agents, scores)
        for problem in problems:
            print(f"submit: {problem}", file=sys.stderr)
        if problems:
            return 2
    return 0 if all(a.passed for a in agents) else 1


if __name__ == "__main__":
    sys.exit(main())
