# Sample target repositories

Small but real applications that the brownfield sample specs, the golden end-to-end tests and the guide run
against. They are fixtures: the platform never runs them in production.

| Path | Repo id(s) | What it is | Baseline tests |
|---|---|---|---|
| `sample-fastapi-nextjs/` | `storefront` | Single repo: FastAPI orders API (SQLite repository layer, inventory client with retry/backoff) + Next.js orders table | `cd api && pytest -q`; `cd web && npm install && npm test` |
| `multi/api/` | `api` | FastAPI orders API with an `openapi.yaml` contract (orders have no `notes` yet) | `pytest -q` (includes a contract drift test) |
| `multi/web/` | `web` | Next.js orders list + detail pages consuming the api | `npm install && npm test` |
| `multi/infra/` | `infra` | Helm values and `env/{dev,staging,prod}.yaml` with a `feature_flags` section | `pytest -q` |

Each repo carries its own `.adlc/` folder (`config.yml`, `ETHOS.md`, `context/{project-overview,architecture,
conventions}.md`). The three multi repos list each other as siblings (`path: ../api`, ...) with mirror-image
`primary` flags and `merge_order: [infra, api, web]`.

## Making git repos

```bash
.venv/bin/python evals/repos/make_git_repos.py /tmp/aidlc-samples            # all four repos
.venv/bin/python evals/repos/make_git_repos.py /tmp/aidlc-samples --only multi
```

Every repo gets one commit on `main` and a bare `origin` under `<target>/remotes/`, so branches can be pushed
and trial-merged without a hosted forge.

## Seeded defects

These are deliberate and must not be "fixed" in this folder; the evals depend on them.

| Repo | Location | Defect | Exercised by |
|---|---|---|---|
| `sample-fastapi-nextjs` | `api/app/retry.py`, `call_with_retry` | **Infinite loop.** `attempt += 1` only runs while the delay is still growing (`if delay < max_delay_s:`). Once the delay reaches `max_delay_s` the attempt counter stops, so a permanently failing call retries forever. With the defaults (`base 0.05 s`, `max 1.0 s`) any `ORDERS_RETRY_ATTEMPTS` above 6 hangs `POST /orders` when the inventory service keeps returning 5xx. Baseline tests use 3 attempts and never reach the cap. | `evals/specs/bugfix/retry-infinite-loop.md` (BugfixWorkflow: Debugger writes the failing test, Backend Dev fixes); Runtime Hazard in health audits |

The web parts are not installed in this repository (no `node_modules` committed); run `npm install` in a copy.
