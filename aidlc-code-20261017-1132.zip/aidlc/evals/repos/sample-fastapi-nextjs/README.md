# Storefront orders

Back-office orders service: a FastAPI API (`api/`) and a Next.js admin UI (`web/`).

## API

```bash
cd api
python -m venv .venv && .venv/bin/pip install -e ".[dev]"
.venv/bin/pytest -q
.venv/bin/uvicorn --factory app.main:create_app --reload
```

Configuration is read from `ORDERS_*` environment variables (see `app/settings.py`). When `ORDERS_INVENTORY_URL`
is set, stock is reserved with the inventory service before an order is stored; failures are retried with
exponential backoff.

## Web

```bash
cd web
npm install
npm test
ORDERS_API_URL=http://localhost:8000 npm run dev
```
