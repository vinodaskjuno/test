# Architecture

```
web (Next.js, server components) --HTTP--> api (FastAPI) --SQLite--> orders.db
                                                 \--HTTP--> inventory service (POST /reservations)
```

## API layers
| Module | Responsibility |
|---|---|
| `app/main.py` | `create_app(settings)` factory: wires repository, inventory client and routers |
| `app/routes/orders.py` | HTTP endpoints `GET /orders`, `GET /orders/{id}`, `POST /orders`; maps domain errors to status codes |
| `app/repository.py` | `OrderRepository`: all SQL lives here |
| `app/inventory.py` | `InventoryClient.reserve(sku, quantity)`; 409 → `OutOfStockError`, 5xx/transport → `TransientError` |
| `app/retry.py` | `call_with_retry`: exponential backoff shared by outbound calls |
| `app/settings.py` | `Settings` from `ORDERS_*` env vars |

Routes currently call the repository and the inventory client directly; there is no service layer yet.

## Web
| Path | Responsibility |
|---|---|
| `lib/api.ts` | Typed fetch helpers and the `Order` type (mirror of the API model) |
| `components/OrdersTable.tsx` | Presentational table, no data fetching |
| `app/orders/page.tsx` | Server component that loads orders and renders the table |
