# Project overview

Storefront orders is the back-office system the support and fulfilment teams use to see and create customer
orders.

- **Users:** support agents (look up orders, create orders on behalf of customers by phone) and fulfilment leads
  (watch what needs to ship).
- **API (`api/`):** FastAPI service. Orders are stored in SQLite (one file per environment). Creating an order
  reserves stock with the external inventory service first.
- **Web (`web/`):** Next.js App Router admin UI. Server components call the API; there is no client-side state
  library.
- **Volumes:** about 2,000 orders per day; the busiest list views show the last few thousand orders.
