# Conventions

## Python (api/)
- Python 3.12, type hints on every function, `from __future__ import annotations`.
- Pydantic models in `app/models.py`; request models end in `Create`/`Update`, response models are plain nouns.
- SQL only in `app/repository.py`, always parameterised (`?` placeholders). No ORM.
- Routes stay thin: validate, call one collaborator, map errors to `HTTPException`.
- Outbound HTTP goes through a client class in its own module and uses `call_with_retry` for transient failures.
- Tests use `pytest` with the `client` fixture (`tests/conftest.py`) and a temporary SQLite file. External
  services are faked with `httpx.MockTransport`; tests never sleep (inject `sleep=`).
- Customer email is personal data: never log it and never return it from list endpoints added in future.

## TypeScript (web/)
- Strict TypeScript; types for API payloads live in `lib/api.ts`.
- Components are presentational and receive data via props; pages (server components) fetch.
- Tests use vitest with `renderToStaticMarkup`; one test file per component under `tests/`.
- Accessible markup: tables have a `<caption>` and `scope` on headers; every image has `alt`.

## Git
- Conventional commits (`feat:`, `fix:`, `refactor:`, `test:`, `docs:`).
- Branch from and merge into `main`.
