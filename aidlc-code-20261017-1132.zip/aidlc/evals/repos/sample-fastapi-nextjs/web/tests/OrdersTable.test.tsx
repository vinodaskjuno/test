import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { OrdersTable } from "@/components/OrdersTable";
import type { Order } from "@/lib/api";

const order: Order = {
  id: 7,
  customer_name: "Ada Lovelace",
  customer_email: "ada@example.com",
  sku: "BOOK-001",
  quantity: 2,
  total_cents: 4598,
  status: "paid",
  created_at: "2026-01-05T10:00:00Z",
};

describe("OrdersTable", () => {
  it("renders one row per order with a formatted total", () => {
    const html = renderToStaticMarkup(<OrdersTable orders={[order, { ...order, id: 8, status: "shipped" }]} />);
    expect(html.match(/<tr>/g)).toHaveLength(3);
    expect(html).toContain("$45.98");
    expect(html).toContain("shipped");
  });

  it("does not show customer emails", () => {
    expect(renderToStaticMarkup(<OrdersTable orders={[order]} />)).not.toContain("ada@example.com");
  });

  it("shows an empty state", () => {
    expect(renderToStaticMarkup(<OrdersTable orders={[]} />)).toContain("No orders yet.");
  });
});
