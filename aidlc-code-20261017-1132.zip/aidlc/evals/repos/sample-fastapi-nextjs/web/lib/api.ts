export type OrderStatus = "pending" | "paid" | "shipped" | "cancelled";

export interface Order {
  id: number;
  customer_name: string;
  customer_email: string;
  sku: string;
  quantity: number;
  total_cents: number;
  status: OrderStatus;
  created_at: string;
}

const API_URL = process.env.ORDERS_API_URL ?? "http://localhost:8000";

export async function fetchOrders(): Promise<Order[]> {
  const response = await fetch(`${API_URL}/orders`, { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`orders API returned ${response.status}`);
  }
  return (await response.json()) as Order[];
}

export function formatCents(cents: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);
}
