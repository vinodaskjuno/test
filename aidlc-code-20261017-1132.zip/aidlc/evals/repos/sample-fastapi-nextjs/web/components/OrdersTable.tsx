import { formatCents, type Order } from "@/lib/api";

export function OrdersTable({ orders }: { orders: Order[] }) {
  if (orders.length === 0) {
    return <p role="status">No orders yet.</p>;
  }
  return (
    <table>
      <caption>Orders</caption>
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Customer</th>
          <th scope="col">SKU</th>
          <th scope="col">Qty</th>
          <th scope="col">Total</th>
          <th scope="col">Status</th>
        </tr>
      </thead>
      <tbody>
        {orders.map((order) => (
          <tr key={order.id}>
            <td>{order.id}</td>
            <td>{order.customer_name}</td>
            <td>{order.sku}</td>
            <td>{order.quantity}</td>
            <td>{formatCents(order.total_cents)}</td>
            <td>{order.status}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
