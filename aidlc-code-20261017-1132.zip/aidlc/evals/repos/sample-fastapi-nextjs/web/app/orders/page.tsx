import { OrdersTable } from "@/components/OrdersTable";
import { fetchOrders } from "@/lib/api";

export const dynamic = "force-dynamic";

export default async function OrdersPage() {
  const orders = await fetchOrders();
  return (
    <>
      <h1>Orders</h1>
      <OrdersTable orders={orders} />
    </>
  );
}
