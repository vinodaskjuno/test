import Link from "next/link";

export default function Home() {
  return (
    <>
      <h1>Storefront back office</h1>
      <Link href="/orders">View orders</Link>
    </>
  );
}
