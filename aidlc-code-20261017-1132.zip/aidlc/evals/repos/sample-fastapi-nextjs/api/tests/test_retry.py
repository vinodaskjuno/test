from __future__ import annotations

from collections.abc import Callable

import pytest
from app.retry import TransientError, call_with_retry


def _flaky(failures: int) -> tuple[list[int], Callable[[], str]]:
    calls: list[int] = []

    def fn() -> str:
        calls.append(1)
        if len(calls) <= failures:
            raise TransientError("boom")
        return "ok"

    return calls, fn


def test_returns_first_success() -> None:
    calls, fn = _flaky(0)
    assert call_with_retry(fn, attempts=3, base_delay_s=0.05, max_delay_s=1.0, sleep=lambda _s: None) == "ok"
    assert len(calls) == 1


def test_retries_then_succeeds_with_doubling_delays() -> None:
    delays: list[float] = []
    calls, fn = _flaky(2)
    assert call_with_retry(fn, attempts=3, base_delay_s=0.05, max_delay_s=1.0, sleep=delays.append) == "ok"
    assert len(calls) == 3
    assert delays == [0.05, 0.1]


def test_gives_up_after_attempts() -> None:
    calls, fn = _flaky(10)
    with pytest.raises(TransientError):
        call_with_retry(fn, attempts=3, base_delay_s=0.05, max_delay_s=1.0, sleep=lambda _s: None)
    assert len(calls) == 3


def test_non_transient_errors_are_not_retried() -> None:
    calls: list[int] = []

    def fn() -> None:
        calls.append(1)
        raise KeyError("nope")

    with pytest.raises(KeyError):
        call_with_retry(fn, attempts=3, base_delay_s=0.05, max_delay_s=1.0, sleep=lambda _s: None)
    assert len(calls) == 1


def test_rejects_zero_attempts() -> None:
    with pytest.raises(ValueError):
        call_with_retry(lambda: None, attempts=0, base_delay_s=0.05, max_delay_s=1.0)
