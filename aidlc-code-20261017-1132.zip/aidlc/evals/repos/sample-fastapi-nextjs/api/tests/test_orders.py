from __future__ import annotations

import httpx
from app.inventory import InventoryClient
from app.main import create_app
from app.settings import Settings
from fastapi.testclient import TestClient


def test_health(client: TestClient) -> None:
    assert client.get("/health").json() == {"status": "ok"}


def test_create_then_get(client: TestClient, new_order: dict[str, object]) -> None:
    created = client.post("/orders", json=new_order)
    assert created.status_code == 201
    body = created.json()
    assert body["status"] == "pending"
    assert body["customer_email"] == "ada@example.com"

    fetched = client.get(f"/orders/{body['id']}")
    assert fetched.status_code == 200
    assert fetched.json() == body


def test_list_returns_orders_in_creation_order(client: TestClient, new_order: dict[str, object]) -> None:
    for sku in ("A-1", "B-2", "C-3"):
        client.post("/orders", json={**new_order, "sku": sku})
    skus = [o["sku"] for o in client.get("/orders").json()]
    assert skus == ["A-1", "B-2", "C-3"]


def test_get_missing_order_is_404(client: TestClient) -> None:
    assert client.get("/orders/999").status_code == 404


def test_create_rejects_invalid_payload(client: TestClient, new_order: dict[str, object]) -> None:
    assert client.post("/orders", json={**new_order, "quantity": 0}).status_code == 422
    assert client.post("/orders", json={**new_order, "customer_email": "not-an-email"}).status_code == 422


def _client_with_inventory(settings: Settings, handler: httpx.MockTransport) -> TestClient:
    inventory = InventoryClient(
        "http://inventory.test",
        timeout_s=1,
        retry_attempts=3,
        base_delay_s=0.01,
        max_delay_s=1.0,
        transport=handler,
        sleep=lambda _s: None,
    )
    return TestClient(create_app(settings, inventory=inventory))


def test_create_reserves_stock(settings: Settings, new_order: dict[str, object]) -> None:
    seen: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append({"path": request.url.path, "body": request.read().decode()})
        return httpx.Response(201)

    with _client_with_inventory(settings, httpx.MockTransport(handler)) as c:
        assert c.post("/orders", json=new_order).status_code == 201
    assert seen == [{"path": "/reservations", "body": '{"sku":"BOOK-001","quantity":2}'}]


def test_out_of_stock_is_409(settings: Settings, new_order: dict[str, object]) -> None:
    with _client_with_inventory(settings, httpx.MockTransport(lambda _r: httpx.Response(409))) as c:
        assert c.post("/orders", json=new_order).status_code == 409
        assert c.get("/orders").json() == []


def test_inventory_down_is_503_after_retries(settings: Settings, new_order: dict[str, object]) -> None:
    calls: list[int] = []

    def handler(_request: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(503)

    with _client_with_inventory(settings, httpx.MockTransport(handler)) as c:
        assert c.post("/orders", json=new_order).status_code == 503
    assert len(calls) == 3
