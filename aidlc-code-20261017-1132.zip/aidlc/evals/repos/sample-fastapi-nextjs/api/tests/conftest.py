from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from app.main import create_app
from app.settings import Settings
from fastapi.testclient import TestClient


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(database_path=str(tmp_path / "orders.db"))


@pytest.fixture
def client(settings: Settings) -> Iterator[TestClient]:
    with TestClient(create_app(settings)) as c:
        yield c


@pytest.fixture
def new_order() -> dict[str, object]:
    return {
        "customer_name": "Ada Lovelace",
        "customer_email": "ada@example.com",
        "sku": "BOOK-001",
        "quantity": 2,
        "total_cents": 4598,
    }
