"""Service configuration, read from ``ORDERS_*`` environment variables."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ORDERS_")

    database_path: str = "orders.db"
    # When unset, stock is not reserved (local development without the inventory service).
    inventory_url: str | None = None
    inventory_timeout_s: float = 2.0
    retry_attempts: int = 3
    retry_base_delay_s: float = 0.05
    retry_max_delay_s: float = 1.0
