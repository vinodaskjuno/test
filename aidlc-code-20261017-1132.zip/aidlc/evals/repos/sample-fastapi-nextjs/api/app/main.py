"""Application factory."""

from __future__ import annotations

from fastapi import FastAPI

from app.inventory import InventoryClient
from app.repository import OrderRepository
from app.routes import orders
from app.settings import Settings


def create_app(settings: Settings | None = None, *, inventory: InventoryClient | None = None) -> FastAPI:
    settings = settings or Settings()
    app = FastAPI(title="Orders API", version="0.4.0")
    app.state.repository = OrderRepository(settings.database_path)
    if inventory is None and settings.inventory_url:
        inventory = InventoryClient(
            settings.inventory_url,
            timeout_s=settings.inventory_timeout_s,
            retry_attempts=settings.retry_attempts,
            base_delay_s=settings.retry_base_delay_s,
            max_delay_s=settings.retry_max_delay_s,
        )
    app.state.inventory = inventory
    app.include_router(orders.router)

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    return app
