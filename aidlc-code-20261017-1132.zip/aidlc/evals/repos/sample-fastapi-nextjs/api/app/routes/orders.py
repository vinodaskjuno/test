"""Order endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from app.inventory import InventoryClient, OutOfStockError
from app.models import Order, OrderCreate
from app.repository import OrderRepository
from app.retry import TransientError

router = APIRouter(prefix="/orders", tags=["orders"])


def _repo(request: Request) -> OrderRepository:
    return request.app.state.repository


def _inventory(request: Request) -> InventoryClient | None:
    return request.app.state.inventory


@router.get("", response_model=list[Order])
def list_orders(request: Request) -> list[Order]:
    return _repo(request).list()


@router.get("/{order_id}", response_model=Order)
def get_order(order_id: int, request: Request) -> Order:
    order = _repo(request).get(order_id)
    if order is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"order {order_id} not found")
    return order


@router.post("", response_model=Order, status_code=status.HTTP_201_CREATED)
def create_order(body: OrderCreate, request: Request) -> Order:
    inventory = _inventory(request)
    if inventory is not None:
        try:
            inventory.reserve(body.sku, body.quantity)
        except OutOfStockError as exc:
            raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
        except TransientError as exc:
            raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "inventory service unavailable") from exc
    return _repo(request).create(body)
