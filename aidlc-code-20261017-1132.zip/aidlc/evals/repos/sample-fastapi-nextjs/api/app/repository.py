"""SQLite persistence for orders."""

from __future__ import annotations

import sqlite3
import threading
from datetime import UTC, datetime

from app.models import Order, OrderCreate

_SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    sku TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    total_cents INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL
)
"""

_COLUMNS = "id, customer_name, customer_email, sku, quantity, total_cents, status, created_at"


class OrderRepository:
    def __init__(self, database_path: str) -> None:
        self._conn = sqlite3.connect(database_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.execute(_SCHEMA)

    def list(self) -> list[Order]:
        with self._lock:
            rows = self._conn.execute(f"SELECT {_COLUMNS} FROM orders ORDER BY id").fetchall()
        return [Order(**dict(row)) for row in rows]

    def get(self, order_id: int) -> Order | None:
        with self._lock:
            row = self._conn.execute(f"SELECT {_COLUMNS} FROM orders WHERE id = ?", (order_id,)).fetchone()
        return Order(**dict(row)) if row else None

    def create(self, data: OrderCreate) -> Order:
        created_at = datetime.now(UTC).isoformat()
        with self._lock, self._conn:
            cursor = self._conn.execute(
                "INSERT INTO orders (customer_name, customer_email, sku, quantity, total_cents, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (data.customer_name, data.customer_email, data.sku, data.quantity, data.total_cents, created_at),
            )
            order_id = cursor.lastrowid
        order = self.get(int(order_id or 0))
        if order is None:
            raise RuntimeError("order vanished after insert")
        return order

    def close(self) -> None:
        self._conn.close()
