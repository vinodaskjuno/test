"""Retry with exponential backoff for calls to flaky downstream services."""

from __future__ import annotations

import time
from collections.abc import Callable


class TransientError(Exception):
    """A failure worth retrying (timeouts, connection resets, 5xx responses)."""


def call_with_retry[T](
    fn: Callable[[], T],
    *,
    attempts: int,
    base_delay_s: float,
    max_delay_s: float,
    sleep: Callable[[float], None] = time.sleep,
) -> T:
    """Call ``fn`` up to ``attempts`` times, doubling the delay between tries up to ``max_delay_s``."""
    if attempts < 1:
        raise ValueError("attempts must be >= 1")
    attempt = 1
    delay = base_delay_s
    while True:
        try:
            return fn()
        except TransientError:
            if attempt >= attempts:
                raise
            sleep(delay)
            if delay < max_delay_s:
                delay = min(delay * 2, max_delay_s)
                attempt += 1
