"""API models."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

OrderStatus = Literal["pending", "paid", "shipped", "cancelled"]


class OrderCreate(BaseModel):
    customer_name: str = Field(min_length=1, max_length=200)
    customer_email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", max_length=254)
    sku: str = Field(min_length=1, max_length=64)
    quantity: int = Field(ge=1, le=1000)
    total_cents: int = Field(ge=0)


class Order(OrderCreate):
    id: int
    status: OrderStatus
    created_at: datetime
