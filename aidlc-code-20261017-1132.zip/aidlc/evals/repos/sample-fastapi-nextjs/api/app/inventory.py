"""Client for the inventory service: reserves stock when an order is placed."""

from __future__ import annotations

import time
from collections.abc import Callable

import httpx

from app.retry import TransientError, call_with_retry


class OutOfStockError(Exception):
    def __init__(self, sku: str) -> None:
        super().__init__(f"insufficient stock for {sku}")
        self.sku = sku


class InventoryClient:
    def __init__(
        self,
        base_url: str,
        *,
        timeout_s: float,
        retry_attempts: int,
        base_delay_s: float,
        max_delay_s: float,
        transport: httpx.BaseTransport | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._http = httpx.Client(base_url=base_url, timeout=timeout_s, transport=transport)
        self._attempts = retry_attempts
        self._base_delay_s = base_delay_s
        self._max_delay_s = max_delay_s
        self._sleep = sleep

    def reserve(self, sku: str, quantity: int) -> None:
        def attempt() -> None:
            try:
                response = self._http.post("/reservations", json={"sku": sku, "quantity": quantity})
            except httpx.TransportError as exc:
                raise TransientError(str(exc)) from exc
            if response.status_code >= 500:
                raise TransientError(f"inventory returned {response.status_code}")
            if response.status_code == 409:
                raise OutOfStockError(sku)
            response.raise_for_status()

        call_with_retry(
            attempt,
            attempts=self._attempts,
            base_delay_s=self._base_delay_s,
            max_delay_s=self._max_delay_s,
            sleep=self._sleep,
        )
