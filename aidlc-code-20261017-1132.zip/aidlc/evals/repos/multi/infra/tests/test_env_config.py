"""Every environment file parses, names its environment and declares the same feature flags as booleans."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).parents[1]
ENVS = sorted((ROOT / "env").glob("*.yaml"))


def _load(path: Path) -> dict:
    return yaml.safe_load(path.read_text())


def test_all_environments_present() -> None:
    assert {p.stem for p in ENVS} == {"dev", "staging", "prod"}


@pytest.mark.parametrize("path", ENVS, ids=lambda p: p.stem)
def test_environment_file(path: Path) -> None:
    cfg = _load(path)
    assert cfg["environment"] == path.stem
    assert cfg["api"]["env"]["ORDERS_API_ENVIRONMENT"] == path.stem
    assert all(isinstance(v, bool) for v in cfg["feature_flags"].values())


def test_flags_are_declared_in_every_environment() -> None:
    flag_sets = {p.stem: set(_load(p)["feature_flags"]) for p in ENVS}
    assert len({frozenset(s) for s in flag_sets.values()}) == 1, flag_sets


@pytest.mark.parametrize("chart", ["orders-api", "orders-web"])
def test_chart_values(chart: str) -> None:
    values = _load(ROOT / "helm" / chart / "values.yaml")
    assert values["image"]["tag"]
    assert values["replicaCount"] >= 1
