# orders-infra

Deployment configuration for the orders platform.

- `helm/orders-api/values.yaml`, `helm/orders-web/values.yaml` — base Helm values per service.
- `env/{dev,staging,prod}.yaml` — per-environment overrides, including the `feature_flags` map.
- `tests/test_env_config.py` — structural checks (`pip install -e ".[dev]" && pytest -q`).

Changes here merge **first** in cross-repo work (merge order: infra → api → web).
