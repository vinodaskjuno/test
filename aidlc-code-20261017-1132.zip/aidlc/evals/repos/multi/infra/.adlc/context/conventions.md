# Conventions (orders-infra)

- YAML, two-space indent, keys in `snake_case` except environment variable names.
- Every flag is declared in every environment file (tests enforce it); new flags start `false` in prod.
- No secrets in this repo; secrets come from the cluster's secret store.
- Conventional commits; branch from and merge into `main`.
