# Architecture (orders-infra)

- Both services are deployed with a shared Helm chart; this repo holds only values.
- Layering: `helm/<service>/values.yaml` (base) → `env/<environment>.yaml` (overrides).
- `feature_flags` in each env file is the single source of truth for flags. The api service reads them from the
  `ORDERS_API_FEATURE_FLAGS` environment variable (JSON object) once that wiring exists.
