"""The served schema must match the committed contract in ``openapi.yaml`` (fields and required lists)."""

from __future__ import annotations

from pathlib import Path

import yaml
from fastapi.testclient import TestClient

CONTRACT = yaml.safe_load((Path(__file__).parents[1] / "openapi.yaml").read_text())


def test_paths_match(client: TestClient) -> None:
    served = client.get("/openapi.json").json()
    assert set(served["paths"]) == set(CONTRACT["paths"])


def test_order_schema_matches(client: TestClient) -> None:
    served = client.get("/openapi.json").json()["components"]["schemas"]
    for name in ("Order", "OrderCreate"):
        assert set(served[name]["properties"]) == set(CONTRACT["components"]["schemas"][name]["properties"])
        assert set(served[name]["required"]) == set(CONTRACT["components"]["schemas"][name]["required"])
