from __future__ import annotations

from fastapi.testclient import TestClient


def test_health(client: TestClient) -> None:
    assert client.get("/health").json() == {"status": "ok", "environment": "dev"}


def test_create_get_list(client: TestClient) -> None:
    created = client.post("/orders", json={"customer_name": "Grace Hopper", "total_cents": 1250})
    assert created.status_code == 201
    order = created.json()
    assert order["status"] == "pending"
    assert client.get(f"/orders/{order['id']}").json() == order
    assert client.get("/orders").json() == [order]


def test_missing_order_is_404(client: TestClient) -> None:
    assert client.get("/orders/41").status_code == 404


def test_rejects_negative_total(client: TestClient) -> None:
    assert client.post("/orders", json={"customer_name": "X", "total_cents": -1}).status_code == 422
