# Architecture (orders-api)

- `app/main.py` — `create_app(settings)`; CORS for the web origin; mounts routers.
- `app/routes/orders.py` — `GET /orders`, `GET /orders/{id}`, `POST /orders`. New order endpoints are appended to
  this module.
- `app/store.py` — `OrderStore`, an in-memory, thread-safe store.
- `app/models.py` — pydantic models; must match `openapi.yaml`.
- `openapi.yaml` — the published contract. `tests/test_contract.py` fails when the served schema drifts from it.
