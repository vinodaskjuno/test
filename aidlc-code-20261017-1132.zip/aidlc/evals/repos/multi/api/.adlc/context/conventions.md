# Conventions (orders-api)

- Python 3.12, type hints everywhere, `from __future__ import annotations`.
- Every API change updates `openapi.yaml` in the same PR; additive changes only unless a breaking change is
  agreed with the web repo owners.
- New optional fields default to `null`/empty so existing clients keep working.
- Tests: pytest + `TestClient` fixture `client`; one test module per router plus `test_contract.py`.
- Conventional commits; branch from and merge into `main`.
