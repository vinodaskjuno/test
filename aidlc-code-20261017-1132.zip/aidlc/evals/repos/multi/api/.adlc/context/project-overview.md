# Project overview (orders-api)

Part of the **orders platform**, three repositories that ship together:

| Repo | Role |
|---|---|
| `api` (this repo) | FastAPI service exposing orders over HTTP; contract in `openapi.yaml` |
| `web` | Next.js UI that lists and shows orders; builds against `api/openapi.yaml` |
| `infra` | Helm values and per-environment configuration (including feature flags) for both services |

Cross-repo changes merge in the order **infra → api → web**: configuration first, then the backend that reads
it, then the UI that depends on the new API.
