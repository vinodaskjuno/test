Shared principles are maintained by the AIDLC platform (`agents/common/ETHOS.md`) and prepended to every agent prompt.
