# orders-api

FastAPI service that exposes orders to the orders web app. The HTTP contract is `openapi.yaml`; the web repo
builds against it, so any change to it is a cross-repo change.

```bash
python -m venv .venv && .venv/bin/pip install -e ".[dev]"
.venv/bin/pytest -q
.venv/bin/uvicorn --factory app.main:create_app --port 8000
```

Configuration: `ORDERS_API_ENVIRONMENT`, `ORDERS_API_CORS_ORIGINS` (JSON list). Deployed by the `infra` repo.
