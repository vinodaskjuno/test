"""API models. Keep in sync with ``openapi.yaml`` (the published contract the web repo builds against)."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

OrderStatus = Literal["pending", "paid", "shipped", "cancelled"]


class OrderCreate(BaseModel):
    customer_name: str = Field(min_length=1, max_length=200)
    total_cents: int = Field(ge=0)


class Order(OrderCreate):
    id: int
    status: OrderStatus
    created_at: datetime
