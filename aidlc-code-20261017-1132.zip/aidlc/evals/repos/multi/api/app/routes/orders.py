"""Order endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from app.models import Order, OrderCreate
from app.store import OrderStore

router = APIRouter(prefix="/orders", tags=["orders"])


def _store(request: Request) -> OrderStore:
    return request.app.state.store


@router.get("", response_model=list[Order])
def list_orders(request: Request) -> list[Order]:
    return _store(request).list()


@router.get("/{order_id}", response_model=Order)
def get_order(order_id: int, request: Request) -> Order:
    order = _store(request).get(order_id)
    if order is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"order {order_id} not found")
    return order


@router.post("", response_model=Order, status_code=status.HTTP_201_CREATED)
def create_order(body: OrderCreate, request: Request) -> Order:
    return _store(request).create(body)
