"""Service configuration, read from ``ORDERS_API_*`` environment variables."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ORDERS_API_")

    environment: str = "dev"
    cors_origins: list[str] = ["http://localhost:3000"]
