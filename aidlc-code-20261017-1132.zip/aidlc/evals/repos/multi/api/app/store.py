"""In-memory order store (the service is a façade over the ERP; persistence is out of scope here)."""

from __future__ import annotations

import itertools
import threading
from datetime import UTC, datetime

from app.models import Order, OrderCreate


class OrderStore:
    def __init__(self) -> None:
        self._orders: dict[int, Order] = {}
        self._ids = itertools.count(1)
        self._lock = threading.Lock()

    def list(self) -> list[Order]:
        with self._lock:
            return sorted(self._orders.values(), key=lambda o: o.id)

    def get(self, order_id: int) -> Order | None:
        with self._lock:
            return self._orders.get(order_id)

    def create(self, data: OrderCreate) -> Order:
        with self._lock:
            order = Order(id=next(self._ids), status="pending", created_at=datetime.now(UTC), **data.model_dump())
            self._orders[order.id] = order
            return order
