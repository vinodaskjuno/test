# Architecture (orders-web)

- `app/orders/page.tsx` — list page (server component) using `listOrders()`.
- `app/orders/[id]/page.tsx` — detail page using `getOrder(id)`; 404 → `notFound()`.
- `components/OrdersTable.tsx`, `components/OrderDetail.tsx` — presentational components, props only.
- `lib/api.ts` — fetch helpers; `lib/types.ts` — API types mirroring `api/openapi.yaml`.
- Feature flags (when present) are read server-side from the API, never from client-side env vars.
