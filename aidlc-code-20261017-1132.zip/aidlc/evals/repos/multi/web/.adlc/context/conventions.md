# Conventions (orders-web)

- Strict TypeScript. API types change only together with `api/openapi.yaml`.
- Pages fetch; components render props. No client components unless interaction requires it.
- vitest + `renderToStaticMarkup`; one test file per feature area under `tests/`.
- Accessibility: WCAG 2.2 AA. Tables have captions and scoped headers; form fields have labels.
- Conventional commits; branch from and merge into `main`.
