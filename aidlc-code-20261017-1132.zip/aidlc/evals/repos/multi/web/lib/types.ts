// Mirrors components.schemas in the api repo's openapi.yaml. Update both in the same cross-repo change.
export type OrderStatus = "pending" | "paid" | "shipped" | "cancelled";

export interface Order {
  id: number;
  customer_name: string;
  total_cents: number;
  status: OrderStatus;
  created_at: string;
}
