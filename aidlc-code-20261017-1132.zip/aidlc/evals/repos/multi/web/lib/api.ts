import type { Order } from "./types";

const API_URL = process.env.ORDERS_API_URL ?? "http://localhost:8000";

async function getJson<T>(path: string): Promise<T | null> {
  const response = await fetch(`${API_URL}${path}`, { cache: "no-store" });
  if (response.status === 404) {
    return null;
  }
  if (!response.ok) {
    throw new Error(`orders API ${path} returned ${response.status}`);
  }
  return (await response.json()) as T;
}

export async function listOrders(): Promise<Order[]> {
  return (await getJson<Order[]>("/orders")) ?? [];
}

export async function getOrder(id: number): Promise<Order | null> {
  return getJson<Order>(`/orders/${id}`);
}

export function formatCents(cents: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);
}
