import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { OrderDetail } from "@/components/OrderDetail";
import { OrdersTable } from "@/components/OrdersTable";
import type { Order } from "@/lib/types";

const order: Order = {
  id: 3,
  customer_name: "Grace Hopper",
  total_cents: 1250,
  status: "pending",
  created_at: "2026-02-01T09:30:00Z",
};

describe("OrdersTable", () => {
  it("links each order to its detail page", () => {
    const html = renderToStaticMarkup(<OrdersTable orders={[order]} />);
    expect(html).toContain('href="/orders/3"');
    expect(html).toContain("$12.50");
  });

  it("shows an empty state", () => {
    expect(renderToStaticMarkup(<OrdersTable orders={[]} />)).toContain("No orders yet.");
  });
});

describe("OrderDetail", () => {
  it("renders the order fields", () => {
    const html = renderToStaticMarkup(<OrderDetail order={order} />);
    expect(html).toContain("Order #3");
    expect(html).toContain("Grace Hopper");
    expect(html).toContain('dateTime="2026-02-01T09:30:00Z"');
  });
});
