import { notFound } from "next/navigation";

import { OrderDetail } from "@/components/OrderDetail";
import { getOrder } from "@/lib/api";

export const dynamic = "force-dynamic";

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await getOrder(Number(id));
  if (order === null) {
    notFound();
  }
  return <OrderDetail order={order} />;
}
