import Link from "next/link";

import { formatCents } from "@/lib/api";
import type { Order } from "@/lib/types";

export function OrdersTable({ orders }: { orders: Order[] }) {
  if (orders.length === 0) {
    return <p role="status">No orders yet.</p>;
  }
  return (
    <table>
      <caption>Orders</caption>
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Customer</th>
          <th scope="col">Total</th>
          <th scope="col">Status</th>
        </tr>
      </thead>
      <tbody>
        {orders.map((order) => (
          <tr key={order.id}>
            <td>
              <Link href={`/orders/${order.id}`}>{order.id}</Link>
            </td>
            <td>{order.customer_name}</td>
            <td>{formatCents(order.total_cents)}</td>
            <td>{order.status}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
