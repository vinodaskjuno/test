import { formatCents } from "@/lib/api";
import type { Order } from "@/lib/types";

export function OrderDetail({ order }: { order: Order }) {
  return (
    <article aria-labelledby="order-title">
      <h1 id="order-title">Order #{order.id}</h1>
      <dl>
        <dt>Customer</dt>
        <dd>{order.customer_name}</dd>
        <dt>Total</dt>
        <dd>{formatCents(order.total_cents)}</dd>
        <dt>Status</dt>
        <dd>{order.status}</dd>
        <dt>Placed</dt>
        <dd>
          <time dateTime={order.created_at}>{order.created_at.slice(0, 10)}</time>
        </dd>
      </dl>
    </article>
  );
}
