# orders-web

Next.js (App Router) UI for the orders platform. Server components call the orders API
(`ORDERS_API_URL`, default `http://localhost:8000`). Types in `lib/types.ts` mirror the api repo's `openapi.yaml`.

```bash
npm install
npm test
npm run typecheck
ORDERS_API_URL=http://localhost:8000 npm run dev
```
