"""Materialise the sample target repos as real git repositories.

Copies ``evals/repos/sample-fastapi-nextjs`` and ``evals/repos/multi/{api,web,infra}`` into a target directory,
initialises each as a git repo with one commit on ``main`` and pushes it to a bare ``origin`` remote, so the
platform can clone, branch, open (local) PRs and trial-merge exactly as it would against a hosted forge.

Layout produced under ``<target>``::

    sample-fastapi-nextjs/          working copy, origin -> remotes/sample-fastapi-nextjs.git
    multi/api|web|infra/            working copies (siblings, so ``../api`` paths in .adlc/config.yml resolve)
    remotes/<name>.git              bare remotes (multi repos are named multi-api.git, ...)

Usage: ``python evals/repos/make_git_repos.py <target> [--only sample|multi]``
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

REPOS_DIR = Path(__file__).resolve().parent
SAMPLES: dict[str, str] = {
    "sample-fastapi-nextjs": "sample",
    "multi/api": "multi",
    "multi/web": "multi",
    "multi/infra": "multi",
}
IGNORED = shutil.ignore_patterns(
    "__pycache__", ".pytest_cache", ".ruff_cache", ".venv", "node_modules", ".next", "*.db", "*.tsbuildinfo"
)
# Deterministic identity so the initial commits do not depend on the caller's git config.
GIT_IDENTITY = ["-c", "user.name=AIDLC Evals", "-c", "user.email=evals@aidlc.invalid", "-c", "commit.gpgsign=false"]


def _git(cwd: Path, *args: str) -> str:
    result = subprocess.run(["git", *GIT_IDENTITY, *args], cwd=cwd, check=True, capture_output=True, text=True)
    return result.stdout.strip()


def _init_repo(work: Path, remote: Path) -> None:
    _git(work, "init", "--quiet", "--initial-branch=main")
    _git(work, "add", "--all")
    _git(work, "commit", "--quiet", "--message", "chore: initial import")
    remote.parent.mkdir(parents=True, exist_ok=True)
    _git(remote.parent, "init", "--quiet", "--bare", "--initial-branch=main", remote.name)
    _git(work, "remote", "add", "origin", str(remote))
    _git(work, "push", "--quiet", "--set-upstream", "origin", "main")


def make_repos(target: Path, only: str | None = None) -> dict[str, Path]:
    """Create the repos under ``target``; returns ``{sample name: working copy path}``."""
    target = target.resolve()
    created: dict[str, Path] = {}
    for name, group in SAMPLES.items():
        if only and group != only:
            continue
        work = target / name
        if work.exists():
            raise FileExistsError(f"{work} already exists")
        shutil.copytree(REPOS_DIR / name, work, ignore=IGNORED)
        _init_repo(work, target / "remotes" / f"{name.replace('/', '-')}.git")
        created[name] = work
    return created


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("target", type=Path, help="directory to create the repos in")
    parser.add_argument("--only", choices=sorted(set(SAMPLES.values())), help="create only one group")
    args = parser.parse_args(argv)
    for name, path in make_repos(args.target, args.only).items():
        print(f"{name}: {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
