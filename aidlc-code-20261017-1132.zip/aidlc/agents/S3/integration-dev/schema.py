"""Output schema for the Integration Dev agent (#20)."""

from aidlc.agent_outputs import DevOutput


class Output(DevOutput):
    """Summary of the change, files changed and the commands that verify it."""
