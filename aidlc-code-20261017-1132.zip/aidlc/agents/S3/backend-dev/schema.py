"""Output schema for the Backend Dev agent (#17)."""

from aidlc.agent_outputs import DevOutput


class Output(DevOutput):
    """Summary of the change, files changed and the commands that verify it."""
