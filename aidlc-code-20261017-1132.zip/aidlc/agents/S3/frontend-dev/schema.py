"""Output schema for the Frontend Dev agent (#18)."""

from aidlc.agent_outputs import DevOutput


class Output(DevOutput):
    """Summary of the change, files changed and the commands that verify it."""
