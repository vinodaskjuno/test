"""Output schema for the Spec Conformance Validator agent (#37)."""

from aidlc.agent_outputs import VerdictsOutput


class Output(VerdictsOutput):
    """One verdict per acceptance criterion, with evidence."""
