"""Output schema for the Visual/UX Validator agent (#38)."""

from aidlc.agent_outputs import VerdictsOutput


class Output(VerdictsOutput):
    """One verdict per UI acceptance criterion, plus visual/UX findings."""
