"""Output schema for the Debugger / Root-Cause agent (#40)."""

from aidlc.agent_outputs import TicketsOutput


class Output(TicketsOutput):
    """Fix tickets with the reproduction test as evidence, plus the diagnosis narrative."""
