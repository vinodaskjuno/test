"""Output schema for the Triage agent (#39)."""

from aidlc.agent_outputs import TicketsOutput


class Output(TicketsOutput):
    """Root-cause-grouped fix tickets, each routed to the owning dev agent."""
