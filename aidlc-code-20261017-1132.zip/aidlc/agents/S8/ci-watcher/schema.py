"""Output schema for the CI Watcher agent (#53)."""

from aidlc.agent_outputs import TicketsOutput


class Output(TicketsOutput):
    """Fix tickets for real CI failures and a diagnosis of the CI run."""
