"""Output schema for the Release Notes agent (#52)."""

from aidlc.agent_outputs import ReleaseNotesOutput


class Output(ReleaseNotesOutput):
    """Changelog entry and optional release notes."""
