"""Output schema for the Commit agent (#50)."""

from aidlc.agent_outputs import CommitOutput


class Output(CommitOutput):
    """Conventional Commits message per repository id."""
