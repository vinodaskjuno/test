"""Output schema for the PR agent (#51)."""

from aidlc.agent_outputs import PROutput


class Output(PROutput):
    """PR title and one Markdown body per repository id."""
