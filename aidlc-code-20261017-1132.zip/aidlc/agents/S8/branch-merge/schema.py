"""Output schema for the Branch & Merge agent (#49)."""

from aidlc.agent_outputs import MergeOutput


class Output(MergeOutput):
    """Whether integration succeeded, with every auto-resolution or blocker in ``notes``."""
