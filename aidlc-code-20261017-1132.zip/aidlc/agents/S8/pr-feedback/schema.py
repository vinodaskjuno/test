"""Output schema for the PR Feedback agent (#54)."""

from aidlc.agent_outputs import FeedbackOutput


class Output(FeedbackOutput):
    """Replies per comment, fix tickets for actionable feedback and an escalation flag."""
