"""Output schema for the Workflow Diagnostics agent (#61)."""

from aidlc.agent_outputs import ReportOutput


class Output(ReportOutput):
    """Diagnosis of the run in ``report_md`` and recommended actions."""
