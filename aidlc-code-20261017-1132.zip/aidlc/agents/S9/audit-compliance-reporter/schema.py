"""Output schema for the Audit & Compliance Reporter agent (#57)."""

from aidlc.agent_outputs import ReportOutput


class Output(ReportOutput):
    """The evidence pack in ``report_md`` and a completeness ``score``."""
