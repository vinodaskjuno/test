"""Output schema for the Cost Optimization agent (#60)."""

from aidlc.agent_outputs import ReportOutput


class Output(ReportOutput):
    """Spend analysis in ``report_md`` and concrete savings recommendations."""
