"""Output schema for the Data Privacy & Governance agent (#58)."""

from aidlc.agent_outputs import FindingsOutput


class Output(FindingsOutput):
    """Verified findings with file, line, severity and evidence."""
