"""Output schema for the Knowledge Curator agent (#55)."""

from aidlc.agent_outputs import ReportOutput


class Output(ReportOutput):
    """Briefing of relevant lessons, assumptions and docs in ``report_md``."""
