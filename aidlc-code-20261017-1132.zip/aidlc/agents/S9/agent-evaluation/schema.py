"""Output schema for the Agent Evaluation agent (#59)."""

from aidlc.agent_outputs import ReportOutput


class Output(ReportOutput):
    """Evaluation report, aggregate ``score`` and a promote/reject recommendation."""
