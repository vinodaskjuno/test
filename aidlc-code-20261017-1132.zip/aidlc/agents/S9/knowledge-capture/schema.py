"""Output schema for the Knowledge Capture agent (#56)."""

from aidlc.agent_outputs import KnowledgeOutput


class Output(KnowledgeOutput):
    """New lessons and assumptions to record under ``.adlc/knowledge/``."""
