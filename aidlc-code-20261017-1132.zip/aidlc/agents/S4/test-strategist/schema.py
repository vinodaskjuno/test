"""Output schema for the Test Strategist agent (#24)."""

from aidlc.agent_outputs import TestPlanOutput


class Output(TestPlanOutput):
    """AC id to planned test names, test levels and coverage target."""
