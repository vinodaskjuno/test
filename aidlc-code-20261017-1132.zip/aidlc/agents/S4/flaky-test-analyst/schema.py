"""Output schema for the Flaky-Test Analyst agent (#31)."""

from aidlc.agent_outputs import FindingsOutput


class Output(FindingsOutput):
    """One finding per flaky or deterministic failure, with the observed pass/fail pattern."""
