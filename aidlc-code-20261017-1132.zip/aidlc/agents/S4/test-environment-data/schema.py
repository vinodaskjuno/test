"""Output schema for the Test Environment & Data agent (#25)."""

from aidlc.agent_outputs import EnvOutput


class Output(EnvOutput):
    """Compose environment, seed commands and service URLs for tests and previews."""
