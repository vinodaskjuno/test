"""Output schema for the Performance & Resilience agent (#29)."""

from aidlc.agent_outputs import DevOutput


class Output(DevOutput):
    """Summary of the change, files changed and the commands that verify it."""
