"""Output schema for the Work Planner agent (#14)."""

from aidlc.agent_outputs import PlanOutput


class Output(PlanOutput):
    """The plan: repo-scoped tasks with file ownership, dependencies, AC ids and the activation set."""
