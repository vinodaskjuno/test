"""Output schema for the Architecture Mapper agent (#8)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """Blast radius: touched modules and layers in ``items``, map in ``details_md``."""
