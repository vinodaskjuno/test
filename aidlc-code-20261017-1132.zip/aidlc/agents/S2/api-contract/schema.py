"""Output schema for the API Contract agent (#12)."""

from aidlc.agent_outputs import ContractOutput


class Output(ContractOutput):
    """Complete OpenAPI YAML and the list of breaking changes."""
