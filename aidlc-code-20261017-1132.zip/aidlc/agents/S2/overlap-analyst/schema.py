"""Output schema for the Overlap Analyst agent (#15)."""

from aidlc.agent_outputs import OverlapOutput


class Output(OverlapOutput):
    """Overlaps with in-flight runs and the components this plan touches."""
