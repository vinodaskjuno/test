"""Output schema for the Integration Explorer agent (#10)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """Extension points, relevant tests and contracts to respect."""
