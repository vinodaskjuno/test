"""Output schema for the Feature Tracer agent (#9)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """Similar features and patterns to follow, as ``path`` references in ``items``."""
