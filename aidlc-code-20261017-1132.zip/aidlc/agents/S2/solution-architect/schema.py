"""Output schema for the Solution Architect agent (#11)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """``details_md`` is the full architecture.md (with the ADR section)."""
