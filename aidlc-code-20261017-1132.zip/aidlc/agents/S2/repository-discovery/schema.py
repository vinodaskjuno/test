"""Output schema for the Repository Discovery agent (#7)."""

from aidlc.agent_outputs import RepoProfileOutput


class Output(RepoProfileOutput):
    """Repository profile, including the detected integration branch and toolchain commands."""
