"""Output schema for the Data Modeler agent (#13)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """Schema changes and a backward-compatible migration plan in ``details_md``."""
