"""Output schema for the Plan Validator agent (#16)."""

from aidlc.agent_outputs import ValidationOutput


class Output(ValidationOutput):
    """V2 gate verdict: ``passed`` plus actionable ``issues``."""
