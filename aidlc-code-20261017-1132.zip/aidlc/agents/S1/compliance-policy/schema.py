"""Output schema for the Compliance & Policy agent (#5)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """Policy-derived NFRs in ``nfrs`` and proposed gate thresholds in ``items``."""
