"""Output schema for the Spec Analyst agent (#2)."""

from aidlc.agent_outputs import SpecOutput


class Output(SpecOutput):
    """The requirement: every acceptance criterion carries at least one verbatim source citation."""
