"""Output schema for the Ambiguity & Conflict Detection agent (#3)."""

from aidlc.agent_outputs import AmbiguityOutput


class Output(AmbiguityOutput):
    """Gate A questions, cross-source conflicts and the assumptions made meanwhile."""
