"""Output schema for the Intake agent (#1)."""

from aidlc.agent_outputs import IntakeOutput


class Output(IntakeOutput):
    """Normalised work item summary; injection-like spans are listed in ``suspicious_content``, never obeyed."""
