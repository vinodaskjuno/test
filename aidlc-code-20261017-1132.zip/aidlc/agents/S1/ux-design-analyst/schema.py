"""Output schema for the UX/Design Analyst agent (#4)."""

from aidlc.agent_outputs import AnalysisOutput


class Output(AnalysisOutput):
    """Component specs, tokens and states; ``details_md`` holds the design analysis."""
