"""Output schema for the Spec Validator agent (#6)."""

from aidlc.agent_outputs import ValidationOutput


class Output(ValidationOutput):
    """V1 gate verdict: ``passed`` plus actionable ``issues``."""
