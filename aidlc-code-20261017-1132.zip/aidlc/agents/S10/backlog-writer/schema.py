"""Output schema for the Backlog Writer agent (#65)."""

from aidlc.agent_outputs import BacklogOutput


class Output(BacklogOutput):
    """Draft REQ and BUG specs derived from ranked findings."""
