"""Output schema for the Test Coverage Auditor agent (#63)."""

from aidlc.agent_outputs import FindingsOutput


class Output(FindingsOutput):
    """Verified findings with file, line, severity and evidence."""
