"""Output schema for the Convention Auditor agent (#62)."""

from aidlc.agent_outputs import FindingsOutput


class Output(FindingsOutput):
    """Verified findings with file, line, severity and evidence."""
