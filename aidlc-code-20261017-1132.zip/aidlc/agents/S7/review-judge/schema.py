"""Output schema for the Review Judge agent (#48)."""

from aidlc.agent_outputs import JudgeOutput


class Output(JudgeOutput):
    """Verified findings split into blocking and non-blocking; ids of dropped findings."""
