"""Output schema for the Maintainability Reviewer agent (#46)."""

from aidlc.agent_outputs import FindingsOutput


class Output(FindingsOutput):
    """Verified findings with file, line, severity and evidence."""
