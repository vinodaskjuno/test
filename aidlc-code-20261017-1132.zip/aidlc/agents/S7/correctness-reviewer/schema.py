"""Output schema for the Correctness Reviewer agent (#43)."""

from aidlc.agent_outputs import FindingsOutput


class Output(FindingsOutput):
    """Verified findings with file, line, severity and evidence."""
