"""Sample specs, expected outcomes, sample repos and the agent eval scorer under ``evals/``."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

import pytest
import yaml

from aidlc.contracts import AgentResult
from aidlc.settings import get_settings

ROOT = Path(__file__).resolve().parents[2]
EVALS = ROOT / "evals"
SPECS = EVALS / "specs"
REPOS = EVALS / "repos"

REQUIRED_KEYS = {
    "id",
    "title",
    "category",
    "workflow",
    "work_item_kind",
    "spec_files",
    "attachments",
    "target",
    "repos_touched",
    "agents_expected",
    "gate_a_questions",
    "expected_prs",
    "merge_order",
    "gates",
    "seeded_defects",
    "expected_outcome",
    "verify",
}
CATEGORIES = {"greenfield", "brownfield-single", "brownfield-multi", "bugfix", "edge", "seeded-defect"}
WORKFLOWS = {"feature", "bugfix", "sprint", "onboarding", "none"}
GATES = {"V1", "V2", "A", "B", "quality", "trial_merge_early", "trial_merge_final"}
GATE_VALUES = {"pass", "fail", "skip", "asked", "pass_after_fix", "blocked", "escalated"}
OUTCOMES = {"pr-ready", "completed", "blocked", "failed", "cancelled", "rejected"}


def _load_module(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module  # dataclasses resolve annotations through sys.modules
    spec.loader.exec_module(module)
    return module


run_evals = _load_module("aidlc_run_evals", EVALS / "agent-evals" / "run_evals.py")
make_git_repos = _load_module("aidlc_make_git_repos", REPOS / "make_git_repos.py")
upload_fixtures = _load_module("aidlc_upload_fixtures", SPECS / "edge" / "upload_fixtures.py")


def _roster() -> set[str]:
    """Agent ids from the roster table in CLAUDE.md (the registry's source of truth for ids)."""
    text = (ROOT / "CLAUDE.md").read_text(encoding="utf-8")
    ids = set(re.findall(r"^\| \d+ \| ([a-z0-9-]+) \| S\d+ \|", text, re.M))
    assert len(ids) == 65
    return ids


ROSTER = _roster()
EXPECTED_FILES = sorted([*SPECS.rglob("*.expected.yaml"), *SPECS.rglob("expected.yaml")])
SPEC_MDS = sorted(p for p in SPECS.rglob("*.md") if p.name != "README.md" and "fixtures" not in p.parts)


def _expected_id(path: Path) -> str:
    return path.parent.name if path.name == "expected.yaml" else path.name.removesuffix(".expected.yaml")


# ---------- sample specs ----------


def test_every_sample_category_is_present() -> None:
    for directory in ("greenfield", "brownfield-single", "brownfield-multi", "bugfix", "edge", "seeded-defects"):
        assert any((SPECS / directory).rglob("*.md")), directory
    assert len(EXPECTED_FILES) >= 20


@pytest.mark.parametrize("path", SPEC_MDS, ids=lambda p: str(p.relative_to(SPECS)))
def test_spec_has_numbered_acceptance_criteria(path: Path) -> None:
    numbers = sorted({int(n) for n in re.findall(r"\bAC-(\d+)\b", path.read_text(encoding="utf-8"))})
    assert numbers and numbers[0] == 1, f"{path.name}: no AC-1"


def test_every_spec_has_an_expected_outcome() -> None:
    covered = {(p.parent / f).resolve() for p in EXPECTED_FILES for f in _load(p)["spec_files"]}
    assert {p.resolve() for p in SPEC_MDS} <= covered


def _load(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


@pytest.mark.parametrize("path", EXPECTED_FILES, ids=lambda p: str(p.relative_to(SPECS)))
def test_expected_yaml(path: Path) -> None:
    exp = _load(path)
    assert set(exp) == REQUIRED_KEYS, f"missing {REQUIRED_KEYS - set(exp)}, extra {set(exp) - REQUIRED_KEYS}"
    assert exp["id"] == _expected_id(path)
    assert exp["category"] in CATEGORIES
    assert exp["workflow"] in WORKFLOWS
    assert exp["work_item_kind"] in {"feature", "bug"}
    assert exp["expected_outcome"] in OUTCOMES
    assert isinstance(exp["expected_prs"], int) and exp["expected_prs"] >= 0
    assert exp["verify"], "verify checklist is empty"
    for rel in exp["spec_files"]:
        assert (path.parent / rel).is_file(), rel
    for att in exp["attachments"]:
        assert att.startswith("https://") or (path.parent / att).is_file(), att
    assert exp["target"]["mode"] in {"new", "existing"}
    for repo in exp["target"]["repos"]:
        assert (REPOS / repo / ".adlc" / "config.yml").is_file(), repo
    assert set(exp["agents_expected"]) <= ROSTER, sorted(set(exp["agents_expected"]) - ROSTER)
    assert set(exp["gates"]) <= GATES
    assert set(exp["gates"].values()) <= GATE_VALUES
    assert (exp["gates"].get("A") == "asked") == bool(exp["gate_a_questions"])
    assert set(exp["merge_order"]) <= set(exp["repos_touched"])
    for defect in exp["seeded_defects"]:
        assert {"id", "description", "location", "caught_by"} <= set(defect)
        caught_by = defect["caught_by"]
        assert caught_by in ROSTER or caught_by.startswith("platform:"), caught_by
        location = defect["location"]
        assert (path.parent / location).exists() or (REPOS / location).exists(), location


def test_seeded_defect_samples_name_their_catcher() -> None:
    expected = {
        "infinite-loop": "runtime-hazard",
        "n-plus-one": "performance-smell",
        "hardcoded-secret": "security-scanner",
        "a11y-violation": "accessibility-test",
        "missing-ac": "adversary",
        "contract-drift": "architecture-conformance",
        "pii-in-fixture": "data-privacy-governance",
        "parallel-edit-conflict": "platform:trial_merge",
        "uncited-ac": "spec-validator",
    }
    for name, agent in expected.items():
        exp = _load(SPECS / "seeded-defects" / f"{name}.expected.yaml")
        assert agent in {d["caught_by"] for d in exp["seeded_defects"]}, name


def test_multi_repo_samples_merge_in_config_order() -> None:
    flags = _load(SPECS / "brownfield-multi" / "feature-flags.expected.yaml")
    assert flags["merge_order"] == ["infra", "api", "web"] and flags["expected_prs"] == 3
    notes = _load(SPECS / "brownfield-multi" / "order-notes.expected.yaml")
    assert notes["merge_order"] == ["api", "web"] and notes["expected_prs"] == 2


def test_readme_indexes_every_sample() -> None:
    readme = (SPECS / "README.md").read_text(encoding="utf-8")
    for path in EXPECTED_FILES:
        assert _expected_id(path) in readme, _expected_id(path)


def test_room_booking_attachments_are_valid() -> None:
    openapi = _load(SPECS / "greenfield" / "room-booking.openapi.yaml")
    assert openapi["openapi"].startswith("3.") and openapi["paths"]
    png = (SPECS / "greenfield" / "room-booking-mockup.png").read_bytes()
    assert png.startswith(b"\x89PNG\r\n\x1a\n") and b"IEND" in png[-12:]


@pytest.mark.parametrize(
    "path", sorted((SPECS / "seeded-defects" / "fixtures").rglob("*.py")), ids=lambda p: p.parent.name
)
def test_python_fixtures_compile(path: Path) -> None:
    compile(path.read_text(encoding="utf-8"), str(path), "exec")


def test_no_malware_test_string_is_committed() -> None:
    eicar = upload_fixtures.eicar_bytes()
    for path in EVALS.rglob("*"):
        if path.is_file() and "node_modules" not in path.parts:
            assert eicar not in path.read_bytes(), path


# ---------- runtime upload fixtures ----------


def test_eicar_is_generated_at_runtime(tmp_path: Path) -> None:
    data = upload_fixtures.write_eicar(tmp_path / "eicar.txt").read_bytes()
    assert len(data) == 68
    assert hashlib.md5(data).hexdigest() == "44d88612fea8a8f36de82e1278abb02f"  # the published EICAR digest


def test_oversized_upload_is_one_byte_over_the_limit(tmp_path: Path) -> None:
    path = upload_fixtures.write_oversized(tmp_path / "big.md", limit_bytes=4096)
    data = path.read_bytes()
    assert len(data) == 4097
    assert data.startswith(b"# Oversized spec") and b"\0" not in data


# ---------- sample repos ----------


def _git(cwd: Path, *args: str) -> str:
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()


def test_make_git_repos(tmp_path: Path) -> None:
    created = make_git_repos.make_repos(tmp_path)
    assert set(created) == {"sample-fastapi-nextjs", "multi/api", "multi/web", "multi/infra"}
    for name, work in created.items():
        assert _git(work, "rev-parse", "--abbrev-ref", "HEAD") == "main"
        assert _git(work, "rev-list", "--count", "HEAD") == "1"
        assert _git(work, "status", "--porcelain") == ""
        origin = Path(_git(work, "remote", "get-url", "origin"))
        assert _git(origin, "rev-parse", "--is-bare-repository") == "true"
        assert _git(origin, "rev-parse", "main") == _git(work, "rev-parse", "HEAD")
        assert not list(work.rglob("node_modules")) and not list(work.rglob("__pycache__")), name
    for repo in ("api", "web", "infra"):
        cfg = _load(created[f"multi/{repo}"] / ".adlc" / "config.yml")
        for sibling, ref in cfg["repos"].items():
            assert (created[f"multi/{repo}"] / ref["path"] / ".adlc" / "config.yml").is_file(), (repo, sibling)
    with pytest.raises(FileExistsError):
        make_git_repos.make_repos(tmp_path, only="sample")


def test_make_git_repos_cli_only_group(tmp_path: Path) -> None:
    assert make_git_repos.main([str(tmp_path), "--only", "multi"]) == 0
    assert sorted(p.name for p in (tmp_path / "multi").iterdir()) == ["api", "infra", "web"]
    assert not (tmp_path / "sample-fastapi-nextjs").exists()


def test_multi_repo_configs_mirror_each_other() -> None:
    for repo in ("api", "web", "infra"):
        cfg = _load(REPOS / "multi" / repo / ".adlc" / "config.yml")
        assert cfg["integration_branch"] == "main"
        assert cfg["merge_order"] == ["infra", "api", "web"]
        assert set(cfg["repos"]) == {"api", "web", "infra"}
        primary = [r for r, v in cfg["repos"].items() if v["primary"]]
        assert primary == [repo]
        assert cfg["repos"][repo]["path"] == "."


def test_every_sample_repo_has_adlc_context() -> None:
    for repo in (REPOS / "sample-fastapi-nextjs", *(REPOS / "multi").iterdir()):
        for rel in ("config.yml", "ETHOS.md", "context/project-overview.md", "context/architecture.md"):
            assert (repo / ".adlc" / rel).is_file(), (repo.name, rel)
        assert (repo / ".adlc" / "context" / "conventions.md").is_file()


def _pytest_in_copy(src: Path, tmp_path: Path) -> subprocess.CompletedProcess[str]:
    work = tmp_path / src.name
    shutil.copytree(src, work, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", "*.db"))
    env = {k: v for k, v in os.environ.items() if not k.startswith(("PYTEST_", "ORDERS_", "APP_"))}
    return subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"],
        cwd=work,
        env=env,
        capture_output=True,
        text=True,
        timeout=180,
    )


@pytest.mark.parametrize(
    "app",
    [
        REPOS / "sample-fastapi-nextjs" / "api",
        REPOS / "multi" / "api",
        REPOS / "multi" / "infra",
        ROOT / "presets" / "templates" / "nextjs-fastapi" / "api",
    ],
    ids=lambda p: str(p.relative_to(ROOT)),
)
def test_baseline_tests_pass(app: Path, tmp_path: Path) -> None:
    result = _pytest_in_copy(app, tmp_path)
    assert result.returncode == 0, result.stdout + result.stderr
    assert " passed" in result.stdout


def test_seeded_retry_defect_is_still_present(tmp_path: Path) -> None:
    """The bugfix sample depends on this bug: once the delay hits the cap, attempts stop counting."""
    work = tmp_path / "api"
    shutil.copytree(REPOS / "sample-fastapi-nextjs" / "api", work, ignore=shutil.ignore_patterns("__pycache__"))
    probe = (
        "from app.retry import TransientError, call_with_retry\n"
        "calls = []\n"
        "def fail():\n"
        "    calls.append(1)\n"
        "    if len(calls) > 50:\n"
        "        raise SystemExit(f'looping:{len(calls)}')\n"
        "    raise TransientError('down')\n"
        "call_with_retry(fail, attempts=8, base_delay_s=0.05, max_delay_s=1.0, sleep=lambda _s: None)\n"
    )
    result = subprocess.run([sys.executable, "-c", probe], cwd=work, capture_output=True, text=True, timeout=60)
    assert "looping:51" in result.stderr, result.stderr


# ---------- agent eval suite ----------


def _result(agent: str = "adversary", output: dict[str, Any] | None = None, **kw: Any) -> AgentResult:
    return AgentResult(agent_id=agent, agent_version="1.0.0", ok=kw.pop("ok", True), output=output or {}, **kw)


def _case(checks: list[dict[str, Any]], agent: str = "adversary") -> Any:
    return run_evals.parse_suite({"cases": [{"id": "c", "agent": agent, "checks": checks}]}).cases[0]


def _finding(**kw: Any) -> dict[str, Any]:
    base = {"id": "F-1", "source_agent": "adversary", "severity": "high", "rule": "r", "message": "", "blocking": False}
    return {**base, **kw}


def test_real_suite_loads_and_references_existing_files() -> None:
    suite = run_evals.load_suite()
    assert suite.min_score == 0.8
    assert {c.agent for c in suite.cases} <= ROSTER
    assert run_evals.missing_files(suite) == []
    for case in suite.cases:
        inputs = run_evals.build_inputs(case)
        assert all(s["kind"] == "markdown" and s["content"] for s in inputs.get("sources", []))
    covered = {c.agent for c in suite.cases}
    assert {"spec-analyst", "adversary", "intake", "runtime-hazard", "security-scanner"} <= covered


@pytest.mark.parametrize(
    "raw",
    [
        {"cases": []},
        {"cases": [{"id": "a", "agent": "x", "checks": [{"type": "bogus"}]}]},
        {"cases": [{"id": "a", "agent": "x", "checks": []}]},
        {"cases": [{"id": "a", "checks": [{"type": "nonempty", "path": "x"}]}]},
        {
            "cases": [
                {"id": "a", "agent": "x", "checks": [{"type": "nonempty", "path": "x"}]},
                {"id": "a", "agent": "y", "checks": [{"type": "nonempty", "path": "x"}]},
            ]
        },
    ],
)
def test_parse_suite_rejects_bad_input(raw: dict[str, Any]) -> None:
    with pytest.raises(run_evals.SuiteError):
        run_evals.parse_suite(raw)


def test_resolve_dotted_paths() -> None:
    out = {"fix_tickets": [{"files": ["a.py"], "owner_agent": "backend-dev"}]}
    assert run_evals.resolve(out, "fix_tickets.0.owner_agent") == "backend-dev"
    assert run_evals.resolve(out, "fix_tickets.3.owner_agent") is None
    assert run_evals.resolve(out, "missing.key") is None


def test_spec_analyst_checks() -> None:
    case = _case(
        [
            {"type": "min_count", "path": "acceptance_criteria", "min": 2},
            {"type": "all_cited", "path": "acceptance_criteria", "weight": 2},
            {"type": "list_matches", "path": "nfrs", "pattern": "(?i)p95"},
        ],
        agent="spec-analyst",
    )
    cited = {"source_name": "s.md", "quote": "q"}
    good = {
        "acceptance_criteria": [{"id": "AC-1", "citations": [cited]}, {"id": "AC-2", "citations": [cited]}],
        "nfrs": ["p95 < 300 ms"],
    }
    assert run_evals.score_case(case, _result("spec-analyst", good)).score == 1.0
    uncited = {**good, "acceptance_criteria": [good["acceptance_criteria"][0], {"id": "AC-2", "citations": []}]}
    score = run_evals.score_case(case, _result("spec-analyst", uncited))
    assert score.score == 0.5  # weights 1 + 2 + 1, the weight-2 citation check fails
    assert "uncited=['AC-2']" in score.checks[1].detail


def test_finding_checks_respect_severity_and_blocking() -> None:
    case = _case(
        [
            {"type": "finding_matches", "pattern": "(?i)manager", "min_severity": "medium", "blocking": True},
            {"type": "no_finding_matches", "pattern": "AKIA"},
        ]
    )
    hit = {"findings": [_finding(message="No AC: only managers may approve", blocking=True)]}
    assert run_evals.score_case(case, _result(output=hit)).score == 1.0
    low = {"findings": [_finding(message="managers", severity="low", blocking=True)]}
    assert run_evals.score_case(case, _result(output=low)).score == 0.5
    leaked = {"findings": [*hit["findings"], _finding(evidence="key AKIA123")]}
    assert run_evals.score_case(case, _result(output=leaked)).score == 0.5
    judge = {"blocking": hit["findings"], "non_blocking": []}  # JudgeOutput shape is searched too
    assert run_evals.score_case(case, _result(output=judge)).score == 1.0


def test_equals_count_and_cost_checks() -> None:
    case = _case(
        [
            {"type": "equals", "path": "passed", "value": False},
            {"type": "max_count", "path": "issues", "max": 1},
            {"type": "nonempty", "path": "issues"},
            {"type": "max_cost_usd", "value": 0.5},
        ],
        agent="spec-validator",
    )
    result = _result("spec-validator", {"passed": False, "issues": ["AC-3 quote not in source"]}, cost_usd=0.2)
    assert run_evals.score_case(case, result).score == 1.0
    pricey = _result("spec-validator", {"passed": True, "issues": []}, cost_usd=0.9)
    assert run_evals.score_case(case, pricey).score == 0.25


def test_failed_or_mismatched_results_score_zero() -> None:
    case = _case([{"type": "nonempty", "path": "summary"}])
    failed = run_evals.score_case(case, _result(ok=False, error="schema invalid"))
    assert failed.score == 0.0 and failed.error == "schema invalid"
    wrong = run_evals.score_case(case, _result("reflector", {"summary": "x"}))
    assert wrong.score == 0.0 and "reflector" in (wrong.error or "")


def test_score_agents_and_missing_results() -> None:
    suite = run_evals.parse_suite(
        {
            "min_score": 0.75,
            "cases": [
                {"id": "a1", "agent": "adversary", "checks": [{"type": "nonempty", "path": "findings"}]},
                {"id": "a2", "agent": "adversary", "checks": [{"type": "nonempty", "path": "findings"}]},
                {"id": "r1", "agent": "reflector", "checks": [{"type": "nonempty", "path": "findings"}]},
            ],
        }
    )
    results = {"a1": _result(output={"findings": [_finding()]}), "a2": _result(output={"findings": [_finding()]})}
    scores = run_evals.score_results(suite, results)
    assert [s.error for s in scores] == [None, None, "no result recorded"]
    agents = {a.agent: a for a in run_evals.score_agents(scores, suite.min_score)}
    assert agents["adversary"].passed and agents["adversary"].cases == 2
    assert not agents["reflector"].passed


def test_cli_scores_recorded_results(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    suite_path = tmp_path / "suite.yaml"
    suite_path.write_text(
        yaml.safe_dump(
            {"cases": [{"id": "c1", "agent": "adversary", "checks": [{"type": "nonempty", "path": "findings"}]}]}
        )
    )
    results = tmp_path / "results.jsonl"
    good = _result(output={"findings": [_finding()]}).model_dump(mode="json")
    results.write_text(json.dumps({"case": "c1", "result": good}) + "\n")
    assert run_evals.main(["--suite", str(suite_path), "--results", str(results), "--json"]) == 0
    assert json.loads(capsys.readouterr().out)["agents"][0]["score"] == 1.0

    results.write_text(json.dumps({"case": "c1", "result": _result(output={}).model_dump(mode="json")}) + "\n")
    assert run_evals.main(["--suite", str(suite_path), "--results", str(results)]) == 1
    assert run_evals.main(["--suite", str(suite_path), "--results", str(results), "--agent", "nobody"]) == 2


def test_cli_live_mode_needs_model_access(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> None:
    assert run_evals.main([]) == 2  # Bedrock with an empty AWS credential chain
    assert "no AWS credentials for Bedrock" in capsys.readouterr().err
    monkeypatch.setenv("AIDLC_BEDROCK_ENABLED", "false")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    get_settings.cache_clear()
    assert run_evals.main([]) == 2
    assert "ANTHROPIC_API_KEY is not set" in capsys.readouterr().err
