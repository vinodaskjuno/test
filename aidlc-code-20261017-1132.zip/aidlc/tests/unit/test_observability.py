from __future__ import annotations

import sys

import pytest
from prometheus_client import REGISTRY, generate_latest

from aidlc.platform import observability as obs


def _value(name: str, labels: dict[str, str]) -> float:
    return REGISTRY.get_sample_value(name, labels) or 0.0


def test_metrics_are_recorded() -> None:
    before = _value("aidlc_runs_started_total", {"kind": "feature"})
    obs.record_run_started("feature")
    assert _value("aidlc_runs_started_total", {"kind": "feature"}) == before + 1

    obs.record_run_finished("feature", "pr-ready")
    assert _value("aidlc_runs_finished_total", {"kind": "feature", "outcome": "pr-ready"}) >= 1

    cost_before = _value("aidlc_agent_cost_usd_total", {"agent": "intake", "squad": "S1", "model": "claude-haiku-5-5"})
    obs.record_agent_call("intake", "S1", "claude-haiku-5-5", ok=True, cost_usd=0.25, duration_s=12)
    assert _value(
        "aidlc_agent_cost_usd_total", {"agent": "intake", "squad": "S1", "model": "claude-haiku-5-5"}
    ) == pytest.approx(cost_before + 0.25)
    assert _value("aidlc_agent_calls_total", {"agent": "intake", "ok": "true"}) >= 1
    assert _value("aidlc_agent_duration_seconds_count", {"agent": "intake"}) >= 1

    obs.record_gate("quality", False)
    assert _value("aidlc_gate_results_total", {"gate": "quality", "passed": "false"}) >= 1
    obs.record_fix_loop(3)
    assert _value("aidlc_fix_loop_iterations_count", {}) >= 1

    exposition = generate_latest().decode()
    for name in ("aidlc_runs_started_total", "aidlc_agent_duration_seconds_bucket", "aidlc_fix_loop_iterations_bucket"):
        assert name in exposition


def test_setup_tracing_without_exporter(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    monkeypatch.setattr(obs, "_provider", None)
    monkeypatch.setattr(obs.trace, "set_tracer_provider", lambda provider: None)
    provider = obs.setup_tracing("aidlc-test")
    assert provider.resource.attributes["service.name"] == "aidlc-test"
    assert obs.setup_tracing() is provider
    with obs.tracer().start_as_current_span("unit"):
        pass


def test_setup_tracing_with_endpoint_but_no_exporter_package(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://otel:4318")
    monkeypatch.setitem(sys.modules, "opentelemetry.exporter.otlp.proto.http.trace_exporter", None)
    monkeypatch.setattr(obs, "_provider", None)
    monkeypatch.setattr(obs.trace, "set_tracer_provider", lambda provider: None)
    obs.setup_tracing()
    assert "not installed" in caplog.text
