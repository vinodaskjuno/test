from __future__ import annotations

import io
from pathlib import Path

import boto3
import pytest
from botocore.response import StreamingBody
from botocore.stub import Stubber

from aidlc.platform.artifacts import check_key
from aidlc.platform.artifacts.fs import FsArtifactStore
from aidlc.platform.artifacts.s3 import S3ArtifactStore


@pytest.mark.parametrize("key", ["", "/abs", "../x", "a/../b", "a//b", "a\\b", "./a"])
def test_invalid_keys(key: str) -> None:
    with pytest.raises(ValueError):
        check_key(key)


async def test_fs_roundtrip_and_listing(tmp_path: Path) -> None:
    store = FsArtifactStore(tmp_path / "art")
    assert await store.keys() == []
    uri = await store.put("runs/r1/report.json", b'{"ok": true}', "application/json")
    assert uri == (tmp_path / "art" / "runs/r1/report.json").resolve().as_uri()
    assert await store.get("runs/r1/report.json") == b'{"ok": true}'
    await store.put("runs/r1/report.json", b"v2")
    assert await store.get("runs/r1/report.json") == b"v2"
    await store.put("runs/r2/a.txt", b"a")
    assert await store.keys("runs/r1/") == ["runs/r1/report.json"]
    assert await store.keys() == ["runs/r1/report.json", "runs/r2/a.txt"]
    with pytest.raises(KeyError):
        await store.get("runs/r1/missing")
    with pytest.raises(ValueError):
        await store.put("../escape", b"x")


def _stubbed() -> tuple[S3ArtifactStore, Stubber]:
    client = boto3.client("s3", region_name="us-east-1", aws_access_key_id="a", aws_secret_access_key="b")
    return S3ArtifactStore("bucket", client=client), Stubber(client)


async def test_s3_put_get_list() -> None:
    store, stub = _stubbed()
    stub.add_response(
        "put_object", {}, {"Bucket": "bucket", "Key": "runs/r1/x.md", "Body": b"# hi", "ContentType": "text/markdown"}
    )
    stub.add_response(
        "get_object", {"Body": StreamingBody(io.BytesIO(b"# hi"), 4)}, {"Bucket": "bucket", "Key": "runs/r1/x.md"}
    )
    stub.add_response(
        "list_objects_v2",
        {"Contents": [{"Key": "runs/r1/z"}, {"Key": "runs/r1/x.md"}], "IsTruncated": False},
        {"Bucket": "bucket", "Prefix": "runs/r1/"},
    )
    stub.add_client_error("get_object", service_error_code="NoSuchKey", http_status_code=404)
    with stub:
        assert await store.put("runs/r1/x.md", b"# hi", "text/markdown") == "s3://bucket/runs/r1/x.md"
        assert await store.get("runs/r1/x.md") == b"# hi"
        assert await store.keys("runs/r1/") == ["runs/r1/x.md", "runs/r1/z"]
        with pytest.raises(KeyError):
            await store.get("runs/r1/missing")
    stub.assert_no_pending_responses()


async def test_s3_rejects_bad_keys() -> None:
    store, _ = _stubbed()
    with pytest.raises(ValueError):
        await store.put("/etc/passwd", b"")


def test_s3_uses_explicit_keys_only_for_compatible_stores(monkeypatch: pytest.MonkeyPatch) -> None:
    """MinIO keys go to the S3 client only; Bedrock and AWS S3 keep the default credential chain."""
    import boto3

    calls: list[dict[str, object]] = []
    monkeypatch.setattr(boto3, "client", lambda service, **kwargs: calls.append({"service": service, **kwargs}))
    _ = S3ArtifactStore("b", "http://minio:9000", access_key_id="aidlc", secret_access_key="minio-secret").client
    _ = S3ArtifactStore("b").client
    assert calls == [
        {
            "service": "s3",
            "endpoint_url": "http://minio:9000",
            "aws_access_key_id": "aidlc",
            "aws_secret_access_key": "minio-secret",
        },
        {"service": "s3", "endpoint_url": None},
    ]
