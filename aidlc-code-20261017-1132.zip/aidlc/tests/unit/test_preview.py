from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import timedelta
from pathlib import Path
from typing import Any

import pytest

from aidlc.contracts import utcnow
from aidlc.interfaces import ExecResult
from aidlc.platform import factory, preview
from aidlc.settings import get_settings

COMPOSE = "services:\n  web:\n    image: nginx\n    ports: ['80:80']\n"


class FakeExecutor:
    def __init__(self, exit_code: int = 0) -> None:
        self.runs: list[tuple[list[str], Path]] = []
        self.exit_code = exit_code

    async def run(
        self, command: Sequence[str], cwd: Path, *, timeout_s: int = 600, env: Mapping[str, str] | None = None
    ) -> ExecResult:
        self.runs.append((list(command), cwd))
        return ExecResult(" ".join(command), self.exit_code, "", "boom" if self.exit_code else "", 5)


class FakeCluster(FakeExecutor):
    def __init__(self) -> None:
        super().__init__()
        self.applied: list[list[dict[str, Any]]] = []
        self.deleted: list[str] = []

    async def apply_manifests(self, manifests: Sequence[dict[str, Any]]) -> None:
        self.applied.append(list(manifests))

    async def delete_namespace(self, name: str) -> None:
        self.deleted.append(name)


def test_env_name_is_dns_safe() -> None:
    assert preview.env_name("Shop_API", 12) == "pr-shop-api-12"
    assert preview.env_name("x" * 80, 1) == f"pr-{'x' * 40}-1"


async def test_local_up_down_and_expiry() -> None:
    ex = FakeExecutor()
    factory.set_override("executor", ex)
    url = await preview.up("shop-api", 7, COMPOSE, "run-1", ttl_hours=1)
    assert url == "https://pr-shop-api-7.preview.localhost"
    command, cwd = ex.runs[0]
    assert command == [
        "docker",
        "compose",
        "-p",
        "pr-shop-api-7",
        "-f",
        "docker-compose.yml",
        "up",
        "-d",
        "--remove-orphans",
    ]
    assert (cwd / "docker-compose.yml").read_text() == COMPOSE
    assert cwd == get_settings().workspace_dir / "previews" / "pr-shop-api-7"

    [view] = preview.for_run("run-1")
    assert view.status == "up" and view.url == url
    assert preview.expired() == []
    assert [v.id for v in preview.expired(utcnow() + timedelta(hours=2))] == ["pr-shop-api-7"]

    await preview.down("shop-api", 7)
    assert ex.runs[-1][0][-3:] == ["down", "-v", "--remove-orphans"]
    assert preview.for_run("run-1")[0].status == "down"
    assert preview.expired(utcnow() + timedelta(hours=2)) == []
    await preview.down("shop-api", 7)  # idempotent
    await preview.down("unknown", 1)
    assert len(ex.runs) == 2


async def test_local_failure_raises() -> None:
    factory.set_override("executor", FakeExecutor(exit_code=1))
    with pytest.raises(preview.PreviewError, match="boom"):
        await preview.up("shop", 1, COMPOSE, None)
    assert preview.for_run("x") == []


async def test_k8s_applies_manifests_and_deletes_namespace(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_EXECUTOR", "k8s")
    monkeypatch.setenv("AIDLC_PREVIEW_DOMAIN", "preview.acme.io")
    get_settings.cache_clear()
    cluster = FakeCluster()
    factory.set_override("executor", cluster)
    url = await preview.up("web", 3, COMPOSE, "run-9")
    assert url == "https://pr-web-3.preview.acme.io"
    kinds = [m["kind"] for m in cluster.applied[0]]
    assert kinds == ["Namespace", "ConfigMap", "Deployment", "Service", "Ingress"]
    by_kind = {m["kind"]: m for m in cluster.applied[0]}
    assert by_kind["ConfigMap"]["data"]["docker-compose.yml"] == COMPOSE
    assert by_kind["Ingress"]["spec"]["rules"][0]["host"] == "pr-web-3.preview.acme.io"
    assert all(m["metadata"].get("namespace", m["metadata"]["name"]) == "pr-web-3" for m in cluster.applied[0])
    containers = by_kind["Deployment"]["spec"]["template"]["spec"]["containers"]
    assert "docker compose -p pr-web-3" in containers[1]["command"][2]
    assert cluster.runs == []

    # Re-running refreshes rather than duplicates.
    await preview.up("web", 3, COMPOSE, "run-9")
    assert len(preview.for_run("run-9")) == 1

    await preview.down("web", 3)
    assert cluster.deleted == ["pr-web-3"]


async def test_k8s_requires_cluster_capable_executor(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_EXECUTOR", "k8s")
    get_settings.cache_clear()
    factory.set_override("executor", FakeExecutor())
    with pytest.raises(preview.PreviewError):
        await preview.up("web", 1, COMPOSE, None)
