from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path

import pytest

from aidlc.platform.sandbox.local import LocalExecutor, scrub_env


async def test_runs_command_in_cwd(tmp_path: Path) -> None:
    (tmp_path / "f.txt").write_text("hello")
    result = await LocalExecutor().run(["cat", "f.txt"], tmp_path)
    assert result.exit_code == 0
    assert result.stdout == "hello"
    assert result.command == "cat f.txt"
    assert not result.timed_out


async def test_nonzero_exit_and_stderr(tmp_path: Path) -> None:
    result = await LocalExecutor().run(
        [sys.executable, "-c", "import sys; print('bad', file=sys.stderr); sys.exit(3)"], tmp_path
    )
    assert result.exit_code == 3
    assert "bad" in result.stderr


async def test_missing_binary_returns_127(tmp_path: Path) -> None:
    result = await LocalExecutor().run(["definitely-not-a-binary-xyz"], tmp_path)
    assert result.exit_code == 127


async def test_timeout_kills_process_group(tmp_path: Path) -> None:
    marker = tmp_path / "late"
    script = f"sleep 5 && touch {marker} & sleep 5"
    started = time.monotonic()
    result = await LocalExecutor().run(["sh", "-c", script], tmp_path, timeout_s=1)
    assert result.timed_out
    assert time.monotonic() - started < 4
    assert "timeout" in result.stderr
    time.sleep(0.2)
    assert not marker.exists()


async def test_cancellation_kills_process_group(tmp_path: Path) -> None:
    marker = tmp_path / "late"
    task = asyncio.ensure_future(LocalExecutor().run(["sh", "-c", f"sleep 2 && touch {marker}"], tmp_path))
    await asyncio.sleep(0.3)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    await asyncio.sleep(2.2)
    assert not marker.exists()


async def test_output_truncated(tmp_path: Path) -> None:
    result = await LocalExecutor(max_output_bytes=1000).run([sys.executable, "-c", "print('x' * 5000)"], tmp_path)
    assert result.stdout.startswith("x" * 1000)
    assert "[truncated 4001 bytes]" in result.stdout


async def test_secrets_scrubbed_unless_passed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-secret")
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_secret")
    monkeypatch.setenv("HARMLESS_VAR", "ok")
    names = ["ANTHROPIC_API_KEY", "GITHUB_TOKEN", "HARMLESS_VAR", "NPM_TOKEN"]
    code = f"import os; print(*[os.environ.get(n) for n in {names!r}])"
    result = await LocalExecutor().run([sys.executable, "-c", code], tmp_path, env={"NPM_TOKEN": "given"})
    assert result.stdout.split() == ["None", "None", "ok", "given"]


def test_scrub_env_patterns() -> None:
    env = scrub_env(
        {"PATH": "/bin", "AWS_REGION": "x", "DB_PASSWORD": "p", "MY_SECRET_THING": "s", "AIDLC_X": "y", "LANG": "C"}
    )
    assert env == {"PATH": "/bin", "LANG": "C"}
