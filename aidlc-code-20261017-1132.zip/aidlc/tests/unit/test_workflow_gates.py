from __future__ import annotations

from aidlc.contracts import Task
from aidlc.orchestrator.workflows.gates import blocks, dependency_tiers, infer_dependencies, is_minor


def task(task_id: str, files: list[str], description: str = "", depends_on: list[str] | None = None) -> Task:
    return Task(
        id=task_id,
        title=task_id,
        repo="web",
        owner_agent="frontend-dev",
        description=description,
        files=files,
        depends_on=depends_on or [],
        ac_ids=["AC-1"],
    )


def test_a_task_that_names_another_tasks_file_depends_on_it() -> None:
    tasks = [
        task("TASK-001", ["package.json"]),
        task("TASK-005", ["src/utils/time.ts"], "Pure helpers; set up by package.json.", ["TASK-001"]),
        task("TASK-007", ["src/mocks/service.ts"], "Use formatRelativeTime from `src/utils/time.ts`.", ["TASK-001"]),
    ]
    inferred = {t.id: t.depends_on for t in infer_dependencies(tasks)}
    assert inferred == {"TASK-001": [], "TASK-005": ["TASK-001"], "TASK-007": ["TASK-001", "TASK-005"]}
    assert [[t.id for t in tier] for tier in dependency_tiers(infer_dependencies(tasks))] == [
        ["TASK-001"],
        ["TASK-005"],
        ["TASK-007"],
    ]


def test_inference_never_creates_a_cycle_or_removes_a_dependency() -> None:
    tasks = [
        task("TASK-001", ["src/a.ts"], "Exports used by `src/b.ts`.", ["TASK-002"]),
        task("TASK-002", ["src/b.ts"], "Imports from `src/a.ts`."),
    ]
    inferred = {t.id: t.depends_on for t in infer_dependencies(tasks)}
    assert inferred == {"TASK-001": ["TASK-002"], "TASK-002": []}  # TASK-002 -> TASK-001 would close a cycle
    dependency_tiers(infer_dependencies(tasks))  # still acyclic


def test_a_task_that_names_only_its_own_files_is_unchanged() -> None:
    only = task("TASK-003", ["src/c.ts"], "Writes `src/c.ts`.")
    assert infer_dependencies([only]) == [only]


def test_ids_file_names_rendered_components_and_tests_imply_dependencies() -> None:
    tasks = [
        task("TASK-001", ["src/components/Toast.tsx"], "The toast component."),
        task("TASK-002", ["src/mocks/service.ts"], "Sample data service."),
        task("TASK-003", ["src/Layout.tsx"], "Renders <Toast /> at the bottom and loads data from service.ts."),
        task("TASK-004", ["src/App.tsx"], "Wires the routes; uses the layout from TASK-003."),
        task("TASK-005", ["src/components/__tests__/Toast.test.tsx"], "Tests the toast."),
        task("TASK-006", ["api/tests/test_orders.py"], "Covers the order routes."),
        task("TASK-007", ["api/app/orders.py"], "Order routes."),
    ]
    inferred = {t.id: sorted(t.depends_on) for t in infer_dependencies(tasks)}
    assert inferred["TASK-003"] == ["TASK-001", "TASK-002"]  # <Toast and a file name only TASK-002 creates
    assert inferred["TASK-004"] == ["TASK-003"]  # names the task id
    assert inferred["TASK-005"] == ["TASK-001"]  # a test depends on the code it tests
    assert inferred["TASK-006"] == ["TASK-007"]  # test_orders.py tests orders.py


def test_a_file_name_two_tasks_create_is_too_ambiguous_to_link() -> None:
    tasks = [
        task("TASK-001", ["web/src/index.ts"], "Web entry."),
        task("TASK-002", ["api/src/index.ts"], "API entry."),
        task("TASK-003", ["web/src/main.ts"], "Imports index.ts."),
    ]
    assert {t.id: t.depends_on for t in infer_dependencies(tasks)}["TASK-003"] == []


def test_shallow_inference_keeps_plans_from_before_the_deeper_rules() -> None:
    tasks = [task("TASK-001", ["src/Toast.tsx"]), task("TASK-002", ["src/App.tsx"], "Renders <Toast /> (TASK-001).")]
    assert {t.id: t.depends_on for t in infer_dependencies(tasks, deep=False)}["TASK-002"] == []


def test_minor_issues_never_block_a_gate() -> None:
    assert is_minor("(minor) [AC-4] wording") and is_minor("  (Minor) x")
    assert not blocks(["(minor) a", "(minor) b"]) and not blocks([])
    assert blocks(["(minor) a", "AC-2 is not testable"])
