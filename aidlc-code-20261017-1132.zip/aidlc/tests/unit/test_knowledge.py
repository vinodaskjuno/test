from __future__ import annotations

from pathlib import Path

from aidlc.platform import knowledge


def _repo(tmp_path: Path) -> Path:
    root = tmp_path / "shop-api"
    (root / "src" / "billing").mkdir(parents=True)
    (root / "src" / "billing" / "invoices.py").write_text(
        '"""Invoices."""\n\n'
        "def export_invoices_csv(account_id: str, *, since=None) -> str:\n"
        '    """Export invoices for an account as CSV."""\n'
        "    return ''\n\n"
        "class InvoiceRepo:\n"
        '    """Persistence for invoices."""\n\n'
        "    def find(self, invoice_id):\n        return None\n\n"
        "    def __repr__(self):\n        return 'x'\n"
    )
    (root / "src" / "broken.py").write_text("def (:\n")
    (root / "web").mkdir()
    (root / "web" / "cart.tsx").write_text(
        "export default function CartPage() {}\nexport const cartTotal = 1\nexport interface CartLine {}\nconst x = 1\n"
    )
    lessons = root / ".adlc" / "knowledge" / "lessons"
    lessons.mkdir(parents=True)
    (lessons / "LESSON-001.md").write_text(
        "---\nid: LESSON-001\ntitle: Retry Stripe webhooks idempotently\ntags: [payments, webhooks]\n---\n"
        "Stripe may deliver a webhook twice; dedupe on event id.\n"
    )
    assumptions = root / ".adlc" / "knowledge" / "assumptions"
    assumptions.mkdir(parents=True)
    (assumptions / "ASSUME-001.md").write_text("---\ntags: payments\n---\n# Currency is always EUR\n\nFor now.\n")
    (root / "README.md").write_text("# Shop API\n\nHandles carts, invoices and payments.\n")
    (root / "node_modules" / "dep").mkdir(parents=True)
    (root / "node_modules" / "dep" / "index.js").write_text("export function hidden() {}\n")
    return root


def test_index_and_search(tmp_path: Path) -> None:
    count = knowledge.index_repo("p1", _repo(tmp_path))
    # 3 python symbols (function, class, method), 3 TS exports, 2 knowledge notes, 1 doc
    assert count == 9

    hits = knowledge.search("p1", "export invoices csv")
    assert hits[0].title == "export_invoices_csv"
    assert hits[0].kind == "symbol"
    assert hits[0].path == "shop-api/src/billing/invoices.py"
    assert "def export_invoices_csv(account_id: str, *, since=None)" in hits[0].body

    method = knowledge.search("p1", "InvoiceRepo find", kind="symbol")
    assert "InvoiceRepo.find" in [h.title for h in method]

    lesson = knowledge.search("p1", "webhook", kind="lesson")
    assert [h.title for h in lesson] == ["Retry Stripe webhooks idempotently"]
    assert set(lesson[0].tags) == {"payments", "webhooks", "LESSON-001"}

    tagged = knowledge.search("p1", "EUR stripe currency", tags=["payments"])
    assert {h.kind for h in tagged} == {"lesson", "assumption"}
    assert knowledge.search("p1", "Currency", kind="assumption")[0].title == "Currency is always EUR"

    ts = knowledge.search("p1", "CartPage")
    assert ts[0].tags == ["typescript", "function"]
    assert knowledge.search("p1", "hidden") == []  # node_modules skipped
    assert knowledge.search("other-project", "invoices") == []
    assert knowledge.search("p1", "?!") == []


def test_reindex_replaces_repo_entries(tmp_path: Path) -> None:
    root = _repo(tmp_path)
    knowledge.index_repo("p1", root)
    (root / "src" / "billing" / "invoices.py").write_text("def renamed_fn():\n    pass\n")
    knowledge.index_repo("p1", root)
    assert knowledge.search("p1", "export_invoices_csv") == []
    assert knowledge.search("p1", "renamed_fn")[0].title == "renamed_fn"


def test_record_upserts_and_is_searchable() -> None:
    first = knowledge.record("p1", "lesson", "Flaky e2e on CI", "Use data-testid selectors.", ["e2e"])
    second = knowledge.record("p1", "lesson", "Flaky e2e on CI", "Use role selectors.", ["e2e", "ci"])
    assert first == second
    hits = knowledge.search("p1", "selectors")
    assert len(hits) == 1 and hits[0].body == "Use role selectors." and hits[0].tags == ["e2e", "ci"]


def test_limit_and_ranking() -> None:
    for i in range(15):
        knowledge.record("p1", "doc", f"Doc {i}", "cache " * (i + 1), [])
    hits = knowledge.search("p1", "cache", limit=5)
    assert len(hits) == 5
    assert hits[0].score >= hits[-1].score
