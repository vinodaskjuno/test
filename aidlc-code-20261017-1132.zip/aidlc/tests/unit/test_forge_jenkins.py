from __future__ import annotations

import httpx
import pytest
import respx

from aidlc.interfaces import CheckStatus
from aidlc.platform.forge.jenkins import JenkinsConfig, branch_check, build_check

CFG = JenkinsConfig(base_url="https://ci.acme.test", user="bot", api_token="t", job_path="/job/{repo}/job/{branch}/")


def test_config_needs_every_field() -> None:
    raw = {"base_url": "https://ci", "user": "u", "api_token": "t", "job_path": "job/{repo}"}
    assert JenkinsConfig.from_integration(raw) == JenkinsConfig("https://ci", "u", "t", "job/{repo}")
    assert JenkinsConfig.from_integration({**raw, "api_token": ""}) is None
    assert JenkinsConfig.from_integration(None) is None


def test_build_url_encodes_branch_like_multibranch_jobs() -> None:
    assert CFG.build_url("orders api", "aidlc/REQ-001-x") == (
        "https://ci.acme.test/job/orders%20api/job/aidlc%252FREQ-001-x/lastBuild/api/json"
    )


@pytest.mark.parametrize(
    ("build", "expected"),
    [
        ({"building": True, "result": None}, ("in_progress", None)),
        ({"building": False, "result": None}, ("queued", None)),
        ({"result": "SUCCESS"}, ("completed", "success")),
        ({"result": "FAILURE"}, ("completed", "failure")),
        ({"result": "UNSTABLE"}, ("completed", "failure")),
        ({"result": "ABORTED"}, ("completed", "cancelled")),
        ({"result": "NOT_BUILT"}, ("completed", "skipped")),
        ({"result": "WEIRD"}, ("completed", "failure")),
    ],
)
def test_build_results_map_to_checks(build: dict, expected: tuple[str, str | None]) -> None:
    check = build_check({"url": "https://ci/1", **build})
    assert (check.status, check.conclusion) == expected and check.name == "jenkins"


@respx.mock
async def test_branch_without_a_job_is_queued_and_errors_raise() -> None:
    route = respx.get("https://ci.acme.test/job/api/job/main/lastBuild/api/json")
    route.mock(return_value=httpx.Response(404))
    assert await branch_check(CFG, "api", "main") == CheckStatus("jenkins", "queued")
    route.mock(return_value=httpx.Response(500))
    with pytest.raises(httpx.HTTPStatusError):
        await branch_check(CFG, "api", "main")
