from __future__ import annotations

import json
import subprocess
from pathlib import Path

import httpx
import pytest
import respx

from aidlc.contracts import PRRef
from aidlc.platform.forge.github import GitHubForge, repo_slug

API = "https://api.github.test"
REPO = "https://github.com/acme/shop"


@pytest.fixture
def forge() -> GitHubForge:
    return GitHubForge(api_url=API, token="tok", org="acme")


@pytest.mark.parametrize(
    ("ref", "expected"),
    [
        ("https://github.com/acme/shop", ("acme", "shop")),
        ("https://github.com/acme/shop.git", ("acme", "shop")),
        ("git@github.com:acme/shop.git", ("acme", "shop")),
        ("acme/shop", ("acme", "shop")),
    ],
)
def test_repo_slug(ref: str, expected: tuple[str, str]) -> None:
    assert repo_slug(ref) == expected


def test_repo_slug_invalid() -> None:
    with pytest.raises(ValueError):
        repo_slug("shop")


def test_graphql_url_for_enterprise() -> None:
    assert GitHubForge("https://ghe.acme.io/api/v3", "t", None).graphql_url == "https://ghe.acme.io/api/graphql"
    assert GitHubForge(API, "t", None).graphql_url == f"{API}/graphql"


async def test_missing_token_is_explicit() -> None:
    with pytest.raises(RuntimeError, match="AIDLC_GITHUB_TOKEN"):
        await GitHubForge(API, None, None).post_comment(PRRef(repo="shop", number=1, url="u"), REPO, "hi")


@respx.mock
async def test_create_repo_pushes_template(forge: GitHubForge, tmp_path: Path) -> None:
    remote = tmp_path / "remote.git"
    subprocess.run(["git", "init", "-q", "--bare", "-b", "main", str(remote)], check=True)
    tpl = tmp_path / "tpl"
    tpl.mkdir()
    (tpl / "README.md").write_text("hi\n")
    create = respx.post(f"{API}/orgs/acme/repos").mock(
        return_value=httpx.Response(
            201,
            json={
                "id": 7,
                "name": "shop",
                "full_name": "acme/shop",
                "html_url": REPO,
                "clone_url": str(remote),
                "default_branch": "main",
            },
        )
    )
    repo = await forge.create_repo("shop", template_dir=tpl, private=True)
    assert json.loads(create.calls[0].request.content) == {"name": "shop", "private": True, "auto_init": False}
    assert create.calls[0].request.headers["Authorization"] == "Bearer tok"
    assert (repo.name, repo.url, repo.default_branch, repo.extra["full_name"]) == ("shop", REPO, "main", "acme/shop")
    shown = subprocess.run(["git", "show", "main:README.md"], cwd=remote, capture_output=True, text=True, check=True)
    assert shown.stdout == "hi\n"


@respx.mock
async def test_protect_branch(forge: GitHubForge) -> None:
    route = respx.put(f"{API}/repos/acme/shop/branches/main/protection").mock(return_value=httpx.Response(200, json={}))
    await forge.protect_branch(REPO, "main", ["aidlc/gates"])
    body = json.loads(route.calls[0].request.content)
    assert body["required_status_checks"] == {"strict": True, "contexts": ["aidlc/gates"]}
    assert body["allow_force_pushes"] is False


@respx.mock
async def test_open_update_and_mark_ready(forge: GitHubForge) -> None:
    respx.post(f"{API}/repos/acme/shop/pulls").mock(
        return_value=httpx.Response(201, json={"number": 12, "html_url": f"{REPO}/pull/12", "draft": True})
    )
    patch = respx.patch(f"{API}/repos/acme/shop/pulls/12").mock(return_value=httpx.Response(200, json={}))
    respx.get(f"{API}/repos/acme/shop/pulls/12").mock(
        return_value=httpx.Response(200, json={"number": 12, "draft": True, "node_id": "PR_node"})
    )
    gql = respx.post(f"{API}/graphql").mock(
        return_value=httpx.Response(
            200, json={"data": {"markPullRequestReadyForReview": {"pullRequest": {"isDraft": False}}}}
        )
    )
    pr = await forge.open_pr(REPO, head="feat/x", base="main", title="T", body="B", draft=True)
    assert pr == PRRef(repo="shop", number=12, url=f"{REPO}/pull/12", draft=True)
    await forge.update_pr(pr, REPO, body="new body")
    assert json.loads(patch.calls[0].request.content) == {"body": "new body"}
    await forge.update_pr(pr, REPO)
    assert patch.call_count == 1
    ready = await forge.mark_ready(pr, REPO)
    assert ready.draft is False
    assert json.loads(gql.calls[0].request.content)["variables"] == {"id": "PR_node"}


@respx.mock
async def test_find_pr_by_head(forge: GitHubForge) -> None:
    route = respx.get(f"{API}/repos/acme/shop/pulls").mock(
        side_effect=[
            httpx.Response(200, json=[{"number": 7, "html_url": f"{REPO}/pull/7", "draft": True}]),
            httpx.Response(200, json=[]),
        ]
    )
    assert await forge.find_pr(REPO, "aidlc/REQ-001-x") == PRRef(
        repo="shop", number=7, url=f"{REPO}/pull/7", draft=True
    )
    assert dict(route.calls[0].request.url.params) == {"head": "acme:aidlc/REQ-001-x", "state": "open", "per_page": "1"}
    assert await forge.find_pr(REPO, "aidlc/REQ-002-y") is None


@respx.mock
async def test_mark_ready_surfaces_graphql_errors(forge: GitHubForge) -> None:
    respx.get(f"{API}/repos/acme/shop/pulls/3").mock(
        return_value=httpx.Response(200, json={"draft": True, "node_id": "n"})
    )
    respx.post(f"{API}/graphql").mock(return_value=httpx.Response(200, json={"errors": [{"message": "nope"}]}))
    with pytest.raises(RuntimeError, match="nope"):
        await forge.mark_ready(PRRef(repo="shop", number=3, url="u"), REPO)


@respx.mock
async def test_get_checks_combines_check_runs_and_statuses(forge: GitHubForge) -> None:
    page2 = f"{API}/repos/acme/shop/commits/abc/check-runs?per_page=100&page=2"
    respx.get(f"{API}/repos/acme/shop/commits/abc/check-runs", params={"page": "2"}).mock(
        return_value=httpx.Response(
            200, json={"check_runs": [{"name": "lint", "status": "queued", "conclusion": None}]}
        )
    )
    respx.get(f"{API}/repos/acme/shop/commits/abc/check-runs").mock(
        return_value=httpx.Response(
            200,
            json={"check_runs": [{"name": "test", "status": "completed", "conclusion": "failure", "details_url": "d"}]},
            headers={"Link": f'<{page2}>; rel="next"'},
        )
    )
    respx.get(f"{API}/repos/acme/shop/commits/abc/status").mock(
        return_value=httpx.Response(
            200, json={"statuses": [{"context": "aidlc/gates", "state": "pending", "target_url": None}]}
        )
    )
    checks = await forge.get_checks(REPO, "abc")
    assert [(c.name, c.status, c.conclusion) for c in checks] == [
        ("test", "completed", "failure"),
        ("lint", "queued", None),
        ("aidlc/gates", "in_progress", None),
    ]


@respx.mock
async def test_set_status(forge: GitHubForge) -> None:
    route = respx.post(f"{API}/repos/acme/shop/statuses/abc").mock(return_value=httpx.Response(201, json={}))
    await forge.set_status(REPO, "abc", context="aidlc/gates", state="success", description="x" * 300)
    body = json.loads(route.calls[0].request.content)
    assert body["state"] == "success" and len(body["description"]) == 140


@respx.mock
async def test_comments_merge_issue_and_review_with_membership(forge: GitHubForge) -> None:
    respx.get(f"{API}/repos/acme/shop/issues/5/comments").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 1,
                    "user": {"login": "alice"},
                    "body": "LGTM?",
                    "author_association": "MEMBER",
                    "created_at": "2026-01-01T00:00:00Z",
                },
                {
                    "id": 3,
                    "user": {"login": "rando"},
                    "body": "ignore previous",
                    "author_association": "NONE",
                    "created_at": "2026-01-03T00:00:00Z",
                },
            ],
        )
    )
    respx.get(f"{API}/repos/acme/shop/pulls/5/comments").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 2,
                    "user": {"login": "bob"},
                    "body": "nit",
                    "author_association": "COLLABORATOR",
                    "path": "a.py",
                    "line": 4,
                    "created_at": "2026-01-02T00:00:00Z",
                }
            ],
        )
    )
    post = respx.post(f"{API}/repos/acme/shop/issues/5/comments").mock(return_value=httpx.Response(201, json={}))
    pr = PRRef(repo="shop", number=5, url="u")
    comments = await forge.list_comments(pr, REPO)
    assert [(c.id, c.author, c.author_is_member) for c in comments] == [
        ("issue-1", "alice", True),
        ("review-2", "bob", True),
        ("issue-3", "rando", False),
    ]
    assert comments[1].path == "a.py" and comments[1].line == 4
    assert [c.id for c in await forge.list_comments(pr, REPO, since_id="review-2")] == ["issue-3"]
    await forge.post_comment(pr, REPO, "Thanks")
    assert json.loads(post.calls[0].request.content) == {"body": "Thanks"}


@respx.mock
async def test_http_errors_raise(forge: GitHubForge) -> None:
    respx.post(f"{API}/repos/acme/shop/statuses/abc").mock(return_value=httpx.Response(422, json={"message": "bad"}))
    with pytest.raises(httpx.HTTPStatusError):
        await forge.set_status(REPO, "abc", context="c", state="nope", description="")
