from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any

import httpx
import pytest
import respx
from sqlalchemy import select

from aidlc.contracts import RunEvent
from aidlc.platform import events, factory, tenancy
from aidlc.platform.db import (
    AuditLog,
    CostRecord,
    InboxItem,
    Run,
    RunEventRow,
    WebhookDelivery,
    WebhookSubscription,
    session_scope,
)
from aidlc.platform.events import DbEventSink, sign, verify

HOOK = "https://hooks.example.test/aidlc"


class RecordingNotifier:
    def __init__(self) -> None:
        self.subjects: list[str] = []

    async def send(self, *, to: Sequence[str], subject: str, body: str, link: str | None = None) -> None:
        self.subjects.append(subject)


@pytest.fixture
def notifier() -> RecordingNotifier:
    org = tenancy.create_org("Acme")
    team = tenancy.create_team(org.id, "T")
    tenancy.create_project(team.id, "Shop", project_id="shop")
    tenancy.add_member(team.id, "dev@acme.io", "contributor")
    with session_scope() as s:
        s.add(
            Run(
                id="run-1",
                project_id="shop",
                kind="feature",
                title="CSV export",
                workflow_id="wf",
                created_by="dev@acme.io",
            )
        )
    rec = RecordingNotifier()
    factory.set_override("notifier", rec)
    return rec


def _subscribe(events_filter: list[str], url: str = HOOK, sub_id: str = "s1", active: bool = True) -> None:
    with session_scope() as s:
        s.add(
            WebhookSubscription(
                id=sub_id, project_id="shop", url=url, events=events_filter, secret="shh", active=active
            )
        )


def test_sign_and_verify() -> None:
    body = b'{"a":1}'
    header = sign("k", body)
    assert header.startswith("sha256=") and len(header) == 7 + 64
    assert verify("k", body, header)
    assert not verify("other", body, header)
    assert not verify("k", body + b" ", header)
    assert not verify("k", body, None)


async def test_stage_cost_and_event_rows(notifier: RecordingNotifier) -> None:
    sink = DbEventSink()
    await sink.emit(RunEvent(run_id="run-1", type="run_started", stage="intake"))
    await sink.emit(
        RunEvent(
            run_id="run-1",
            type="agent_completed",
            stage="S1",
            agent_id="intake",
            data={"cost_usd": 0.4, "squad": "S1", "model": "claude-haiku-5-5", "input_tokens": 10, "output_tokens": 5},
        )
    )
    await sink.emit(RunEvent(run_id="run-1", type="agent_completed", agent_id="spec-analyst", data={"cost_usd": 1.1}))
    with session_scope() as s:
        run = s.get(Run, "run-1")
        assert run is not None and run.stage == "S1" and run.cost_usd == pytest.approx(1.5)
        assert [r.type for r in s.scalars(select(RunEventRow).order_by(RunEventRow.seq))] == [
            "run_started",
            "agent_completed",
            "agent_completed",
        ]
        costs = list(s.scalars(select(CostRecord).order_by(CostRecord.id)))
        assert [(c.agent_id, c.squad, c.model, c.input_tokens) for c in costs] == [
            ("intake", "S1", "claude-haiku-5-5", 10),
            ("spec-analyst", "", "", 0),
        ]
    assert notifier.subjects == []


async def test_unknown_run_raises(notifier: RecordingNotifier) -> None:
    with pytest.raises(LookupError):
        await DbEventSink().emit(RunEvent(run_id="nope", type="log"))


async def test_answers_and_decisions_the_run_accepted_resolve_their_inbox_items(notifier: RecordingNotifier) -> None:
    sink = DbEventSink()
    questions = [{"id": "Q-1", "text": "Currency?"}, {"id": "Q-2", "text": "Locale?"}]
    await sink.emit(RunEvent(run_id="run-1", type="question", stage="gate_a", data={"questions": questions}))
    await sink.emit(
        RunEvent(run_id="run-1", type="escalation", data={"id": "ESC-1", "reason": "budget", "detail": "$60"})
    )
    with session_scope() as s:
        api_answered = s.get(InboxItem, "run-1:Q-2")
        assert api_answered is not None
        api_answered.status, api_answered.resolution = "resolved", {"answer": "en-GB", "user": "pm"}
    answer = {"question_id": "Q-1", "answer": "EUR", "user": "", "source": "temporal"}  # typed into the Temporal UI
    await sink.emit(RunEvent(run_id="run-1", type="answer", data=answer))
    await sink.emit(
        RunEvent(run_id="run-1", type="answer", data={"question_id": "Q-2", "answer": "en-US", "user": "x"})
    )
    decision = {"escalation_id": "ESC-1", "decision": "retry", "user": "lead@x", "source": "api"}
    await sink.emit(RunEvent(run_id="run-1", type="decision", data=decision))
    with session_scope() as s:
        q1, q2, esc = (s.get(InboxItem, f"run-1:{ref}") for ref in ("Q-1", "Q-2", "ESC-1"))
        assert q1 is not None and q2 is not None and esc is not None
        assert (q1.status, q1.resolution) == (
            "resolved",
            {"answer": "EUR", "user": "temporal-ui", "source": "temporal"},
        )
        assert q2.resolution == {"answer": "en-GB", "user": "pm"}  # resolved by the API first: left as it was
        assert esc.status == "resolved" and esc.resolution["decision"] == "retry"
        audit = [(a.actor, a.action, a.target) for a in s.scalars(select(AuditLog))]
        assert audit == [("temporal-ui", "inbox.answer", "run-1:Q-1"), ("lead@x", "inbox.decide", "run-1:ESC-1")]


async def test_questions_escalations_and_gate_b_create_inbox_items(notifier: RecordingNotifier) -> None:
    sink = DbEventSink()
    questions = [{"id": "Q-1", "text": "Currency?"}, {"id": "Q-2", "text": "Row limit?", "options": ["1k", "10k"]}]
    await sink.emit(RunEvent(run_id="run-1", type="question", stage="gate_a", data={"questions": questions}))
    await sink.emit(RunEvent(run_id="run-1", type="question", data={"questions": questions}))  # replay: no duplicates
    await sink.emit(RunEvent(run_id="run-1", type="question", data={"question": {"id": "Q-3", "text": "Locale?"}}))
    await sink.emit(
        RunEvent(
            run_id="run-1",
            type="escalation",
            data={
                "id": "ESC-1",
                "reason": "loop_cap",
                "detail": "5 iterations",
                "options": ["retry", "cancel"],
                "diagnosis": "## Diagnosis\nThe same test fails every iteration.",
            },
        )
    )
    await sink.emit(RunEvent(run_id="run-1", type="pr", data={"ready": False, "number": 4}))
    await sink.emit(RunEvent(run_id="run-1", type="pr", data={"ready": True, "repo": "api", "number": 4, "url": "u4"}))
    await sink.emit(RunEvent(run_id="run-1", type="pr", data={"ready": True, "repo": "web", "number": 4, "url": "w4"}))
    await sink.emit(
        RunEvent(run_id="run-1", type="pr", data={"ready": True, "prs": [{"repo": "api", "number": 4, "url": "u4b"}]})
    )
    with session_scope() as s:
        items = {i.id: i for i in s.scalars(select(InboxItem))}
        assert set(items) == {"run-1:Q-1", "run-1:Q-2", "run-1:Q-3", "run-1:ESC-1", "run-1:gate_b:1"}
        assert items["run-1:Q-2"].payload["options"] == ["1k", "10k"]
        assert items["run-1:ESC-1"].title == "loop_cap: 5 iterations"
        assert items["run-1:ESC-1"].payload["diagnosis"].startswith("## Diagnosis")
        stored = {e.type: e.data for e in s.scalars(select(RunEventRow).where(RunEventRow.type != "pr"))}
        assert stored["question"]["inbox_ids"] == {"Q-3": "run-1:Q-3"}  # the last question event
        assert stored["escalation"]["inbox_ids"] == {"ESC-1": "run-1:ESC-1"}
        first = s.scalars(select(RunEventRow).where(RunEventRow.type == "question")).first()
        assert first is not None and first.data["inbox_ids"] == {"Q-1": "run-1:Q-1", "Q-2": "run-1:Q-2"}
        gate_b = items["run-1:gate_b:1"]
        assert gate_b.ref_id == "4,4"
        assert [(p["repo"], p["url"]) for p in gate_b.payload["prs"]] == [("api", "u4b"), ("web", "w4")]
        gate_b.status = "resolved"
    await sink.emit(RunEvent(run_id="run-1", type="pr", data={"ready": True, "number": 4, "url": "u"}))
    with session_scope() as s:
        assert s.get(InboxItem, "run-1:gate_b:2") is not None
    assert notifier.subjects[:2] == [
        "[AIDLC] Gate A questions waiting: CSV export",
        "[AIDLC] Gate A questions waiting: CSV export",
    ]
    assert "[AIDLC] Escalation (loop_cap): CSV export" in notifier.subjects
    assert notifier.subjects.count("[AIDLC] PR(s) ready for review: CSV export") == 4


async def test_outcome_sets_run_outcome_and_notifies(notifier: RecordingNotifier) -> None:
    await DbEventSink().emit(
        RunEvent(run_id="run-1", type="outcome", stage="done", message="tests failing", data={"outcome": "failed"})
    )
    with session_scope() as s:
        run = s.get(Run, "run-1")
        assert run is not None and (run.outcome, run.stage) == ("failed", "done")
    assert notifier.subjects == ["[AIDLC] Run failed: CSV export"]


async def test_retitled_log_event_renames_the_run(notifier: RecordingNotifier) -> None:
    await DbEventSink().emit(
        RunEvent(run_id="run-1", type="log", message="titled", data={"retitled": "  Paginate orders  "})
    )
    with session_scope() as s:
        run = s.get(Run, "run-1")
        assert run is not None and run.title == "Paginate orders"


async def test_notification_failure_does_not_break_emit(notifier: RecordingNotifier) -> None:
    class Broken:
        async def send(self, **kwargs: Any) -> None:
            raise RuntimeError("smtp down")

    factory.set_override("notifier", Broken())
    await DbEventSink().emit(RunEvent(run_id="run-1", type="outcome", data={"outcome": "failed"}))
    with session_scope() as s:
        assert s.get(Run, "run-1").outcome == "failed"  # type: ignore[union-attr]


@pytest.mark.parametrize(
    ("etype", "data", "expected"),
    [
        ("question", {}, "run.gate_waiting"),
        ("escalation", {}, "run.gate_waiting"),
        ("pr", {"ready": True}, "run.pr_ready"),
        ("pr", {}, None),
        ("outcome", {"outcome": "failed"}, "run.failed"),
        ("outcome", {"outcome": "blocked"}, "run.failed"),
        ("outcome", {"outcome": "pr-ready"}, "run.completed"),
        ("log", {}, None),
    ],
)
def test_webhook_event_mapping(etype: str, data: dict[str, Any], expected: str | None) -> None:
    assert events.webhook_event(RunEvent(run_id="r", type=etype, data=data)) == expected  # type: ignore[arg-type]


@respx.mock
async def test_webhook_signed_delivery(notifier: RecordingNotifier) -> None:
    route = respx.post(HOOK).mock(return_value=httpx.Response(204))
    _subscribe(["run.failed"])
    _subscribe(["run.pr_ready"], url="https://other.test/x", sub_id="s2")
    _subscribe([], url="https://inactive.test/x", sub_id="s3", active=False)
    await DbEventSink(backoff_s=0).emit(RunEvent(run_id="run-1", type="outcome", data={"outcome": "failed"}))
    await events.drain()
    assert route.call_count == 1
    request = route.calls[0].request
    assert request.headers["X-AIDLC-Event"] == "run.failed"
    assert verify("shh", request.content, request.headers["X-AIDLC-Signature"])
    body = json.loads(request.content)
    assert body["event"] == "run.failed" and body["run_id"] == "run-1" and body["project_id"] == "shop"
    assert body["data"]["data"] == {"outcome": "failed"}
    with session_scope() as s:
        [delivery] = list(s.scalars(select(WebhookDelivery)))
        assert (delivery.status, delivery.attempts, delivery.subscription_id) == ("delivered", 1, "s1")


@respx.mock
async def test_webhook_retries_then_succeeds_or_fails(notifier: RecordingNotifier) -> None:
    flaky = respx.post(HOOK).mock(side_effect=[httpx.Response(500), httpx.ConnectError("down"), httpx.Response(200)])
    _subscribe(["*"])
    await DbEventSink(backoff_s=0).emit(RunEvent(run_id="run-1", type="question", data={"questions": []}))
    await events.drain()
    assert flaky.call_count == 3
    with session_scope() as s:
        [delivery] = list(s.scalars(select(WebhookDelivery)))
        assert (delivery.status, delivery.attempts, delivery.last_error) == ("delivered", 3, "")

    dead = respx.post("https://dead.test/h").mock(return_value=httpx.Response(503))
    _subscribe([], url="https://dead.test/h", sub_id="dead")
    with session_scope() as s:
        s.get(WebhookSubscription, "s1").active = False  # type: ignore[union-attr]
    await DbEventSink(backoff_s=0).emit(RunEvent(run_id="run-1", type="outcome", data={"outcome": "pr-ready"}))
    await events.drain()
    assert dead.call_count == events.MAX_ATTEMPTS
    with session_scope() as s:
        failed = s.scalar(select(WebhookDelivery).where(WebhookDelivery.subscription_id == "dead"))
        assert failed is not None
        assert (failed.status, failed.attempts, failed.last_error, failed.event) == (
            "failed",
            5,
            "HTTP 503",
            "run.completed",
        )


async def test_deliver_unknown_id() -> None:
    with pytest.raises(LookupError):
        await events.deliver(12345)


async def test_resend_pending_delivers_rows_left_by_a_previous_process(respx_mock) -> None:
    from aidlc.platform import db, events

    with db.session_scope() as s:
        s.add(db.Org(id="o", name="o"))
        s.add(db.Team(id="t", org_id="o", name="t"))
        s.add(db.Project(id="p", team_id="t", name="p"))
        s.add(db.WebhookSubscription(id="w", project_id="p", url="https://hooks.example/x", events=[], secret="s"))
        s.flush()
        s.add(db.WebhookDelivery(subscription_id="w", event="run.completed", payload={"a": 1}, status="pending"))
    route = respx_mock.post("https://hooks.example/x").respond(204)
    assert await events.resend_pending(backoff_s=0) == ["delivered"]
    assert route.called


def _sample(name: str, labels: dict[str, str]) -> float:
    from prometheus_client import REGISTRY

    return REGISTRY.get_sample_value(name, labels) or 0.0


async def test_lead_time_is_observed_once_at_the_first_pr_ready(notifier: RecordingNotifier) -> None:
    from datetime import timedelta

    with session_scope() as s:
        created = s.get(Run, "run-1").created_at
    count = ("aidlc_run_lead_time_seconds_count", {"kind": "feature"})
    total = ("aidlc_run_lead_time_seconds_sum", {"kind": "feature"})
    before_count, before_sum = _sample(*count), _sample(*total)
    at = created + timedelta(hours=2)
    sink = DbEventSink()
    await sink.emit(RunEvent(run_id="run-1", type="pr", message="draft", data={"ready": False, "number": 1}, at=at))
    assert _sample(*count) == before_count  # a draft PR is not PR-ready
    await sink.emit(RunEvent(run_id="run-1", type="pr", message="ready", data={"ready": True, "number": 1}, at=at))
    assert _sample(*count) == before_count + 1
    assert _sample(*total) - before_sum == pytest.approx(7200, abs=1)
    later = at + timedelta(hours=1)
    await sink.emit(RunEvent(run_id="run-1", type="outcome", data={"outcome": "pr-ready", "iterations": 0}, at=later))
    await sink.emit(RunEvent(run_id="run-1", type="pr", message="again", data={"ready": True, "number": 2}, at=later))
    assert _sample(*count) == before_count + 1  # only the first PR-ready signal counts


async def test_pr_ready_outcome_alone_records_lead_time_and_fix_loops(notifier: RecordingNotifier) -> None:
    lead_before = _sample("aidlc_run_lead_time_seconds_count", {"kind": "feature"})
    loops_before = _sample("aidlc_fix_loop_iterations_count", {})
    events_before = _sample("aidlc_run_events_total", {"type": "outcome"})
    await DbEventSink().emit(RunEvent(run_id="run-1", type="outcome", data={"outcome": "pr-ready", "iterations": 2}))
    assert _sample("aidlc_run_lead_time_seconds_count", {"kind": "feature"}) == lead_before + 1
    assert _sample("aidlc_fix_loop_iterations_count", {}) == loops_before + 1
    assert _sample("aidlc_run_events_total", {"type": "outcome"}) == events_before + 1
