"""Structural checks for infra/, sandbox/, .github/ and the greenfield preset template.

Docker, Helm and kubectl are not available to the unit suite, so these tests parse every file and cross-check it
against the code (settings fields, metric names) instead of running it.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import pytest
import yaml

from aidlc.settings import Settings

ROOT = Path(__file__).resolve().parents[2]
INFRA = ROOT / "infra"
CHART = INFRA / "helm" / "aidlc"
TEMPLATE = ROOT / "presets" / "templates" / "nextjs-fastapi"

SETTINGS_ENV = {f"AIDLC_{name.upper()}" for name in Settings.model_fields}
# Read directly from the environment by individual entrypoints rather than through Settings.
ENTRYPOINT_ENV = {"AIDLC_API_PORT", "AIDLC_API_HOST"}
KNOWN_ENV = SETTINGS_ENV | ENTRYPOINT_ENV

METRICS = [
    "aidlc_runs_started_total",
    "aidlc_runs_finished_total",
    "aidlc_agent_calls_total",
    "aidlc_agent_cost_usd_total",
    "aidlc_agent_duration_seconds",
    "aidlc_gate_results_total",
    "aidlc_fix_loop_iterations",
    "aidlc_run_lead_time_seconds",
    "aidlc_run_events_total",
]
REMOVED_STACK = re.compile(r"langfuse|grafana|clamav|clamd", re.IGNORECASE)


def _yaml_files() -> list[Path]:
    roots = [INFRA, ROOT / ".github", TEMPLATE]
    files = [p for r in roots for p in [*r.rglob("*.yml"), *r.rglob("*.yaml")]]
    # Helm templates are Go templates, not YAML; they are checked separately below.
    return sorted(p for p in files if not p.is_relative_to(CHART / "templates"))


def _load(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


@pytest.mark.parametrize("path", _yaml_files(), ids=lambda p: str(p.relative_to(ROOT)))
def test_yaml_parses(path: Path) -> None:
    assert _load(path) is not None


# ---------- docker compose ----------


@pytest.fixture(scope="module")
def compose() -> dict[str, Any]:
    return _load(INFRA / "docker-compose.yml")


def test_compose_has_every_service(compose: dict[str, Any]) -> None:
    required = {
        "temporal",
        "temporal-db",
        "temporal-ui",
        "postgres",
        "minio",
        "minio-init",
        "prometheus",
        "mailpit",
        "api",
        "worker",
        "web",
        "mcp",
    }
    assert required <= set(compose["services"])


def test_compose_has_no_removed_services(compose: dict[str, Any]) -> None:
    """Revision 2 removed the old trace store, dashboards and clamd scanner (Fiddler, Prometheus rules, CrowdStrike)."""
    leftovers = [name for name in [*compose["services"], *(compose.get("volumes") or {})] if REMOVED_STACK.search(name)]
    assert not leftovers
    text = (INFRA / "docker-compose.yml").read_text() + (INFRA / ".env.example").read_text()
    assert not REMOVED_STACK.search(text)
    assert not (INFRA / "grafana").exists() and not (INFRA / "postgres").exists()


@pytest.mark.parametrize("service", ["api", "worker", "mcp"])
def test_compose_platform_env(compose: dict[str, Any], service: str) -> None:
    svc = compose["services"][service]
    env = svc["environment"]
    for key in (
        "AIDLC_DATABASE_URL",
        "AIDLC_TEMPORAL_ADDRESS",
        "AIDLC_ARTIFACT_BACKEND",
        "AIDLC_S3_ENDPOINT_URL",
        "AIDLC_AUTH_MODE",
        "AIDLC_SMTP_HOST",
        "AIDLC_WORKSPACE_DIR",
    ):
        assert key in env, f"{service} misses {key}"
    assert env["AIDLC_DATABASE_URL"].startswith("postgresql+psycopg://")
    assert env["AIDLC_TEMPORAL_ADDRESS"] == "temporal:7233"
    assert env["AIDLC_SMTP_HOST"] == "mailpit"
    assert svc["build"]["dockerfile"] == "infra/docker/Dockerfile.python"
    assert svc["command"] == [f"aidlc-{service}"]


def test_compose_worker_runs_agents_on_bedrock(compose: dict[str, Any]) -> None:
    worker = compose["services"]["worker"]
    env = worker["environment"]
    assert env["AIDLC_BEDROCK_ENABLED"] == "${AIDLC_BEDROCK_ENABLED:-true}"
    assert {"AIDLC_AWS_REGION", "AIDLC_BEDROCK_MODEL_MAP", "AWS_REGION", "AWS_PROFILE", "AWS_ACCESS_KEY_ID"} <= set(env)
    assert any(v.endswith(":/home/aidlc/.aws:ro") for v in worker["volumes"])  # optional host ~/.aws, read-only
    api_env = compose["services"]["api"]["environment"]
    # AWS and Anthropic credentials reach the worker only; MinIO keys are scoped to the artifact store.
    assert not {"ANTHROPIC_API_KEY", "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY"} & set(api_env)
    assert {"AIDLC_S3_ACCESS_KEY_ID", "AIDLC_S3_SECRET_ACCESS_KEY"} <= set(api_env)


def test_compose_scans_uploads_with_crowdstrike_and_traces_to_fiddler(compose: dict[str, Any]) -> None:
    env = compose["services"]["api"]["environment"]
    assert env["AIDLC_MALWARE_SCANNER"] == "${AIDLC_MALWARE_SCANNER:-crowdstrike}"
    assert {"AIDLC_CROWDSTRIKE_CLIENT_ID", "AIDLC_CROWDSTRIKE_CLIENT_SECRET", "AIDLC_CROWDSTRIKE_BASE_URL"} <= set(env)
    assert {"AIDLC_FIDDLER_URL", "AIDLC_FIDDLER_TOKEN", "AIDLC_FIDDLER_PROJECT", "AIDLC_FIDDLER_MODEL"} <= set(env)


def test_compose_env_names_match_settings(compose: dict[str, Any]) -> None:
    for name, svc in compose["services"].items():
        env = svc.get("environment") or {}
        unknown = {k for k in env if k.startswith("AIDLC_")} - KNOWN_ENV
        assert not unknown, f"{name}: AIDLC_* variables that no code reads: {sorted(unknown)}"


def test_compose_egress_allowlist_is_json_list(compose: dict[str, Any]) -> None:
    raw = compose["services"]["worker"]["environment"]["AIDLC_EGRESS_ALLOWLIST"]
    default = re.fullmatch(r"\$\{AIDLC_EGRESS_ALLOWLIST:-(.*)\}", raw)
    assert default, raw
    assert json.loads(default.group(1)) == Settings.model_fields["egress_allowlist"].default


def test_compose_mounts_exist(compose: dict[str, Any]) -> None:
    for name, svc in compose["services"].items():
        for volume in svc.get("volumes") or []:
            source = volume.split(":", 1)[0]
            if source.startswith("./"):
                assert (INFRA / source).exists(), f"{name}: missing {source}"


def test_env_example_vars_are_known() -> None:
    names = {
        line.split("=", 1)[0]
        for line in (INFRA / ".env.example").read_text().splitlines()
        if "=" in line and not line.startswith("#")
    }
    assert {"AIDLC_AWS_REGION", "AIDLC_BEDROCK_MODEL_MAP", "AWS_PROFILE", "AIDLC_CROWDSTRIKE_CLIENT_ID"} <= names
    assert {n for n in names if n.startswith("AIDLC_")} <= KNOWN_ENV


# ---------- Dockerfiles ----------


def test_python_dockerfile_is_multistage_nonroot_and_installs_package() -> None:
    text = (INFRA / "docker" / "Dockerfile.python").read_text()
    assert len(re.findall(r"^FROM .+ AS \w+", text, re.M)) >= 2
    assert re.search(r"pip install -e \.", text)
    assert re.search(r"^USER 10001", text, re.M)
    assert "psycopg" in text


def test_web_dockerfile_builds_control_plane_as_non_root() -> None:
    text = (INFRA / "docker" / "Dockerfile.web").read_text()
    assert "control-plane/web" in text
    assert "npm run build" in text
    assert re.search(r"^USER node", text, re.M)
    assert "AIDLC_API_ORIGIN" in text


def test_sandbox_dockerfile_has_every_tool() -> None:
    text = (ROOT / "sandbox" / "Dockerfile").read_text()
    for tool in (
        "node-v",
        "python3.12",
        "git",
        "gh_",
        "uv",
        "pnpm",
        "playwright",
        "semgrep",
        "gitleaks",
        "trivy",
        "osv-scanner",
        "k6",
        "@axe-core/cli",
        "ruff",
        "mypy",
        "eslint",
    ):
        assert tool in text, tool
    assert re.search(r"^USER 10001", text, re.M)
    assert re.search(r"^WORKDIR /workspace", text, re.M)


# ---------- Helm ----------


@pytest.fixture(scope="module")
def values() -> dict[str, Any]:
    return _load(CHART / "values.yaml")


def _templates() -> dict[str, str]:
    return {p.name: p.read_text() for p in sorted((CHART / "templates").iterdir()) if p.is_file()}


def test_chart_metadata() -> None:
    chart = _load(CHART / "Chart.yaml")
    assert chart["apiVersion"] == "v2"
    assert chart["name"] == "aidlc"


def test_helm_values_references_resolve(values: dict[str, Any]) -> None:
    for name, text in _templates().items():
        for ref in re.findall(r"\.Values\.([A-Za-z0-9_.]+)", text):
            node: Any = values
            for part in ref.split("."):
                assert isinstance(node, dict) and part in node, f"{name}: .Values.{ref} is not in values.yaml"
                node = node[part]


def test_helm_template_blocks_balance() -> None:
    for name, text in _templates().items():
        if name == "NOTES.txt":
            continue
        opened = len(re.findall(r"\{\{-?\s*(?:if|range|with|define)\b", text))
        closed = len(re.findall(r"\{\{-?\s*end\s*-?\}\}", text))
        assert opened == closed, f"{name}: {opened} blocks opened, {closed} closed"
        for n, line in enumerate(text.splitlines(), start=1):
            assert line.count("{{") <= line.count("}}"), f"{name}:{n}: unterminated template action"


def test_helm_renders_required_kinds() -> None:
    kinds = set()
    for text in _templates().values():
        kinds.update(re.findall(r"^kind: (\w+)", text, re.M))
    assert {
        "Deployment",
        "Service",
        "HorizontalPodAutoscaler",
        "Ingress",
        "ConfigMap",
        "ExternalSecret",
        "ServiceAccount",
        "Role",
        "RoleBinding",
        "NetworkPolicy",
        "PodDisruptionBudget",
        "Namespace",
        "ValidatingAdmissionPolicy",
    } <= kinds


def test_helm_worker_rbac_is_scoped_to_sandbox_namespace() -> None:
    rbac = _templates()["rbac.yaml"]
    role = rbac.split("---")[0]
    assert "kind: Role\n" in role
    assert "namespace: {{ .Values.sandbox.namespace }}" in role
    for resource in ('"jobs"', '"networkpolicies"'):
        assert resource in role
    # Namespaces are cluster-scoped: creation is limited by an admission policy to the preview prefix.
    assert "startsWith" in rbac and "previewNamespaces.prefix" in rbac


def test_helm_sandbox_network_policy_defaults_to_deny(values: dict[str, Any]) -> None:
    policy = _templates()["networkpolicy.yaml"]
    assert 'policyTypes: ["Ingress", "Egress"]' in policy
    assert "egressCidrs" in policy and "kube-dns" in policy
    assert values["sandbox"]["egressAllowlist"] == Settings.model_fields["egress_allowlist"].default


def test_helm_configmap_env_names_match_settings() -> None:
    names = set(re.findall(r"^\s+(AIDLC_[A-Z0-9_]+):", _templates()["configmap.yaml"], re.M))
    assert names, "configmap renders no AIDLC_* keys"
    assert names <= KNOWN_ENV, sorted(names - KNOWN_ENV)


def test_helm_secret_keys_cover_sensitive_settings(values: dict[str, Any]) -> None:
    keys = set(values["secrets"]["externalSecret"]["keys"])
    assert {
        "AIDLC_DATABASE_URL",
        "AIDLC_GITHUB_TOKEN",
        "AIDLC_WEBHOOK_SECRET",
        "AIDLC_CROWDSTRIKE_CLIENT_ID",
        "AIDLC_CROWDSTRIKE_CLIENT_SECRET",
        "AIDLC_FIDDLER_TOKEN",
    } <= keys
    # Bedrock authenticates with the worker's IAM role: no model key, and no static AWS keys overriding IRSA.
    assert not {"ANTHROPIC_API_KEY", "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY"} & keys
    assert keys <= KNOWN_ENV
    assert "AIDLC_DATABASE_URL" not in _templates()["configmap.yaml"]


def test_helm_bedrock_role_and_region(values: dict[str, Any]) -> None:
    assert values["bedrock"] == {"enabled": True, "region": "us-east-1", "modelMap": {}, "roleArn": ""}
    configmap = _templates()["configmap.yaml"]
    for key in ("AIDLC_BEDROCK_ENABLED", "AIDLC_AWS_REGION", "AWS_REGION", "AIDLC_BEDROCK_MODEL_MAP"):
        assert f"  {key}:" in configmap, key
    sa = _templates()["serviceaccount.yaml"]
    assert '"eks.amazonaws.com/role-arn" $.Values.bedrock.roleArn' in sa and 'eq $component "worker"' in sa


def test_helm_has_no_removed_stack(values: dict[str, Any]) -> None:
    texts = [(CHART / "values.yaml").read_text(), *_templates().values()]
    assert not any(REMOVED_STACK.search(t) for t in texts)
    assert values["config"]["malwareScanner"] == "crowdstrike"


def test_helm_worker_has_hpa_and_external_deps_in_values(values: dict[str, Any]) -> None:
    assert values["worker"]["hpa"]["enabled"] is True
    assert values["config"]["temporalAddress"]
    assert "postgres" not in {k.lower() for k in values}  # Postgres is external (AIDLC_DATABASE_URL secret)


# ---------- observability ----------


def test_prometheus_scrapes_platform() -> None:
    cfg = _load(INFRA / "prometheus" / "prometheus.yml")
    targets = {t for job in cfg["scrape_configs"] for sc in job["static_configs"] for t in sc["targets"]}
    assert {"api:8000", "worker:9464"} <= targets


def test_prometheus_loads_the_rules_file() -> None:
    cfg = _load(INFRA / "prometheus" / "prometheus.yml")
    assert cfg["rule_files"] == ["/etc/prometheus/rules.yml"]
    compose = _load(INFRA / "docker-compose.yml")
    assert "./prometheus/rules.yml:/etc/prometheus/rules.yml:ro" in compose["services"]["prometheus"]["volumes"]


@pytest.fixture(scope="module")
def rules() -> list[dict[str, Any]]:
    groups = _load(INFRA / "prometheus" / "rules.yml")["groups"]
    assert {g["name"] for g in groups} == {"aidlc-recording", "aidlc-alerts"}
    return [rule for group in groups for rule in group["rules"]]


def test_rules_reference_existing_metrics(rules: list[dict[str, Any]]) -> None:
    from prometheus_client import REGISTRY

    import aidlc.platform.observability  # noqa: F401  registers the platform metrics

    suffixes = {"counter": ("_total",), "histogram": ("_bucket", "_count", "_sum"), "gauge": ("",)}
    exported = {m.name + sfx for m in REGISTRY.collect() for sfx in suffixes.get(m.type, ("",))}
    used = {name for rule in rules for name in re.findall(r"\baidlc_[a-z_]+", rule["expr"])}
    assert used and used <= exported, sorted(used - exported)
    for metric in METRICS:
        assert any(metric in rule["expr"] for rule in rules), f"no rule uses {metric}"
    recorded = {rule["record"] for rule in rules if "record" in rule}
    for rule in rules:
        for name in re.findall(r"\baidlc:[a-z0-9_:]+", rule["expr"]):
            assert name in recorded, f"{rule.get('alert') or rule.get('record')}: unknown recording rule {name}"


def test_rules_cover_the_platform_kpis(rules: list[dict[str, Any]]) -> None:
    recorded = {rule["record"] for rule in rules if "record" in rule}
    assert {
        "aidlc:first_pass_rate:ratio_1d",
        "aidlc:cost_per_pr_usd:1d",
        "aidlc:gate_failure_rate:ratio_1h",
        "aidlc:agent_error_rate:ratio_1h",
        "aidlc:run_lead_time_seconds:p90_1d",
    } <= recorded
    alerts = {rule["alert"]: rule for rule in rules if "alert" in rule}
    assert {
        "AidlcAgentErrorRateHigh",
        "AidlcGateFailureRateHigh",
        "AidlcFirstPassRateLow",
        "AidlcCostPerPrHigh",
        "AidlcLeadTimeP90High",
        "AidlcRunsStuck",
    } <= set(alerts)
    for name, alert in alerts.items():
        assert alert["labels"]["severity"] in {"info", "warning", "critical"}, name
        assert alert["annotations"]["summary"], name
    assert "aidlc_run_events_total" in alerts["AidlcRunsStuck"]["expr"]


# ---------- CI ----------


def _workflow(path: Path) -> dict[str, Any]:
    wf = _load(path)
    wf["on"] = wf.pop(True, wf.get("on"))  # PyYAML reads the bare key `on` as boolean True
    return wf


def test_ci_workflow_jobs() -> None:
    wf = _workflow(ROOT / ".github" / "workflows" / "ci.yml")
    assert {"python", "web", "sdk-ts", "guide"} <= set(wf["jobs"])
    runs = "\n".join(step.get("run", "") for job in wf["jobs"].values() for step in job["steps"])
    for command in (
        "ruff check",
        "pytest -q",
        "npm run typecheck",
        "npm run lint",
        "npm test",
        "npm run build",
        "npm run e2e",
        "node docs/guide/build.mjs --check",
        "node scripts/sync-aig-style.mjs --check",
        "AIG_WEB_DIR",
        "openapi",
    ):
        assert command in runs, command


# ---------- greenfield template ----------


def test_template_layout() -> None:
    for rel in (
        "api/app/main.py",
        "api/app/settings.py",
        "api/tests/test_health.py",
        "api/pyproject.toml",
        "web/package.json",
        "web/app/page.tsx",
        "web/tests/page.test.tsx",
        ".github/workflows/ci.yml",
        "CODEOWNERS",
        "README.md",
        ".adlc/config.yml",
        ".adlc/ETHOS.md",
        ".adlc/context/project-overview.md",
        ".adlc/context/architecture.md",
        ".adlc/context/conventions.md",
    ):
        assert (TEMPLATE / rel).is_file(), rel
    assert not list(TEMPLATE.rglob("node_modules"))


def test_template_adlc_config() -> None:
    cfg = _load(TEMPLATE / ".adlc" / "config.yml")
    assert cfg["integration_branch"] == "main"
    assert set(cfg["merge_order"]) == set(cfg["repos"])
    assert [r for r, v in cfg["repos"].items() if v.get("primary")] == ["app"]


def test_template_ci_runs_api_and_web_tests() -> None:
    wf = _workflow(TEMPLATE / ".github" / "workflows" / "ci.yml")
    assert {"api", "web"} <= set(wf["jobs"])
    runs = "\n".join(step.get("run", "") for job in wf["jobs"].values() for step in job["steps"])
    assert "pytest" in runs and "npm test" in runs
