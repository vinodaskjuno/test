"""Registry: the 65 shipped agents load and match the roster; malformed agent folders are rejected."""

from __future__ import annotations

from pathlib import Path

import pytest

from aidlc.platform.registry import MUTATING_TOOLS, Registry, RegistryError, load_agent

AGENTS_DIR = Path(__file__).resolve().parents[2] / "agents"

OPUS, SONNET, HAIKU = "claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"

# Roster from CLAUDE.md: number -> (id, squad, model, output base class)
ROSTER: dict[int, tuple[str, str, str, str]] = {
    1: ("intake", "S1", HAIKU, "IntakeOutput"),
    2: ("spec-analyst", "S1", OPUS, "SpecOutput"),
    3: ("ambiguity-conflict-detection", "S1", SONNET, "AmbiguityOutput"),
    4: ("ux-design-analyst", "S1", SONNET, "AnalysisOutput"),
    5: ("compliance-policy", "S1", SONNET, "AnalysisOutput"),
    6: ("spec-validator", "S1", SONNET, "ValidationOutput"),
    7: ("repository-discovery", "S2", SONNET, "RepoProfileOutput"),
    8: ("architecture-mapper", "S2", HAIKU, "AnalysisOutput"),
    9: ("feature-tracer", "S2", HAIKU, "AnalysisOutput"),
    10: ("integration-explorer", "S2", HAIKU, "AnalysisOutput"),
    11: ("solution-architect", "S2", OPUS, "AnalysisOutput"),
    12: ("api-contract", "S2", OPUS, "ContractOutput"),
    13: ("data-modeler", "S2", OPUS, "AnalysisOutput"),
    14: ("work-planner", "S2", OPUS, "PlanOutput"),
    15: ("overlap-analyst", "S2", HAIKU, "OverlapOutput"),
    16: ("plan-validator", "S2", SONNET, "ValidationOutput"),
    17: ("backend-dev", "S3", OPUS, "DevOutput"),
    18: ("frontend-dev", "S3", OPUS, "DevOutput"),
    19: ("db-migration-dev", "S3", OPUS, "DevOutput"),
    20: ("integration-dev", "S3", OPUS, "DevOutput"),
    21: ("refactoring", "S3", OPUS, "DevOutput"),
    22: ("devops-iac", "S3", SONNET, "DevOutput"),
    23: ("docs", "S3", HAIKU, "DevOutput"),
    24: ("test-strategist", "S4", SONNET, "TestPlanOutput"),
    25: ("test-environment-data", "S4", SONNET, "EnvOutput"),
    26: ("unit-test", "S4", SONNET, "DevOutput"),
    27: ("integration-contract-test", "S4", SONNET, "DevOutput"),
    28: ("e2e-ui-test", "S4", SONNET, "DevOutput"),
    29: ("performance-resilience", "S4", SONNET, "DevOutput"),
    30: ("accessibility-test", "S4", SONNET, "DevOutput"),
    31: ("flaky-test-analyst", "S4", HAIKU, "FindingsOutput"),
    32: ("static-analysis", "S5", SONNET, "FindingsOutput"),
    33: ("runtime-hazard", "S5", OPUS, "FindingsOutput"),
    34: ("security-scanner", "S5", SONNET, "FindingsOutput"),
    35: ("dependency-license", "S5", HAIKU, "FindingsOutput"),
    36: ("performance-smell", "S5", SONNET, "FindingsOutput"),
    37: ("spec-conformance-validator", "S6", SONNET, "VerdictsOutput"),
    38: ("visual-ux-validator", "S6", SONNET, "VerdictsOutput"),
    39: ("triage", "S6", SONNET, "TicketsOutput"),
    40: ("debugger", "S6", OPUS, "TicketsOutput"),
    41: ("reflector", "S7", OPUS, "FindingsOutput"),
    42: ("adversary", "S7", OPUS, "FindingsOutput"),
    43: ("correctness-reviewer", "S7", OPUS, "FindingsOutput"),
    44: ("security-reviewer", "S7", OPUS, "FindingsOutput"),
    45: ("performance-reviewer", "S7", OPUS, "FindingsOutput"),
    46: ("maintainability-reviewer", "S7", OPUS, "FindingsOutput"),
    47: ("architecture-conformance", "S7", OPUS, "FindingsOutput"),
    48: ("review-judge", "S7", OPUS, "JudgeOutput"),
    49: ("branch-merge", "S8", SONNET, "MergeOutput"),
    50: ("commit", "S8", HAIKU, "CommitOutput"),
    51: ("pr", "S8", SONNET, "PROutput"),
    52: ("release-notes", "S8", HAIKU, "ReleaseNotesOutput"),
    53: ("ci-watcher", "S8", SONNET, "TicketsOutput"),
    54: ("pr-feedback", "S8", OPUS, "FeedbackOutput"),
    55: ("knowledge-curator", "S9", SONNET, "ReportOutput"),
    56: ("knowledge-capture", "S9", SONNET, "KnowledgeOutput"),
    57: ("audit-compliance-reporter", "S9", SONNET, "ReportOutput"),
    58: ("data-privacy-governance", "S9", SONNET, "FindingsOutput"),
    59: ("agent-evaluation", "S9", SONNET, "ReportOutput"),
    60: ("cost-optimization", "S9", HAIKU, "ReportOutput"),
    61: ("workflow-diagnostics", "S9", SONNET, "ReportOutput"),
    62: ("convention-auditor", "S10", HAIKU, "FindingsOutput"),
    63: ("test-coverage-auditor", "S10", SONNET, "FindingsOutput"),
    64: ("ai-api-cost-scanner", "S10", SONNET, "FindingsOutput"),
    65: ("backlog-writer", "S10", SONNET, "BacklogOutput"),
}

# Agents the roster marks as reading external content; they must never hold write or exec tools.
UNTRUSTED_READERS = {"intake", "spec-analyst", "ambiguity-conflict-detection", "ux-design-analyst", "pr-feedback"}
# Agents the roster gives code-changing tools.
MUTATORS = {
    "backend-dev",
    "frontend-dev",
    "db-migration-dev",
    "integration-dev",
    "refactoring",
    "devops-iac",
    "docs",
    "test-environment-data",
    "unit-test",
    "integration-contract-test",
    "e2e-ui-test",
    "performance-resilience",
    "accessibility-test",
    "runtime-hazard",
}


@pytest.fixture(scope="module")
def registry() -> Registry:
    return Registry(AGENTS_DIR)


def test_loads_exactly_the_65_roster_agents(registry: Registry) -> None:
    assert len(registry) == 65
    assert [a.number for a in registry.all()] == list(range(1, 66))
    assert {a.id for a in registry.all()} == {row[0] for row in ROSTER.values()}


@pytest.mark.parametrize("number", sorted(ROSTER))
def test_agent_matches_roster(registry: Registry, number: int) -> None:
    agent_id, squad, model, base = ROSTER[number]
    spec = registry.get(agent_id)
    assert spec.number == number
    assert spec.squad == squad
    assert spec.model == model
    assert spec.version == "1.0.0"
    assert spec.path is not None
    assert spec.path.name == agent_id
    assert spec.path.parent.name == squad
    assert base in [cls.__name__ for cls in spec.output_model.__mro__]
    assert spec.prompt.startswith("# ")


def test_every_output_schema_generates_json_schema(registry: Registry) -> None:
    for spec in registry.all():
        schema = spec.output_json_schema()
        assert schema["type"] == "object", spec.id
        assert schema["properties"], spec.id


def test_untrusted_readers_have_no_mutating_tools(registry: Registry) -> None:
    flagged = {a.id for a in registry.all() if a.reads_untrusted}
    assert flagged >= UNTRUSTED_READERS
    for spec in registry.all():
        if spec.reads_untrusted:
            assert not set(spec.tools) & MUTATING_TOOLS, spec.id
            assert not spec.mutates, spec.id


def test_only_code_changing_agents_can_edit(registry: Registry) -> None:
    for spec in registry.all():
        can_edit = bool({"Write", "Edit"} & set(spec.tools))
        if spec.id in MUTATORS:
            assert can_edit, spec.id
        elif spec.id != "debugger":  # writes only its reproduction test
            assert not can_edit, spec.id


def test_code_issue_agents_run_in_audits_and_branch_verification(registry: Registry) -> None:
    s5 = registry.by_squad("S5")
    assert len(s5) == 5
    for spec in s5:
        assert {"health_audit", "verify_branch"} <= set(spec.workflows), spec.id


def test_workflow_membership(registry: Registry) -> None:
    def runs_in(workflow: str) -> set[str]:
        return {a.id for a in registry.all() if workflow in a.workflows}

    for squad in ("S4", "S6", "S7"):
        for spec in registry.by_squad(squad):
            assert "verify_branch" in spec.workflows, spec.id
    assert {a.id for a in registry.by_squad("S10")} <= runs_in("health_audit")
    assert "knowledge-curator" in runs_in("health_audit")
    assert {"repository-discovery", "docs"} <= runs_in("onboarding")
    assert "test-environment-data" in runs_in("preview")
    assert {"intake", "debugger", "unit-test", "reflector", "review-judge"} <= runs_in("bugfix")


def test_mcp_servers_where_relevant(registry: Registry) -> None:
    assert "figma" in registry.get("ux-design-analyst").mcp_servers
    assert "knowledge" in registry.get("knowledge-curator").mcp_servers
    assert "knowledge" in registry.get("reflector").mcp_servers


def test_ethos_loaded(registry: Registry) -> None:
    assert registry.ethos
    assert "untrusted" in registry.ethos.lower()
    assert "json" in registry.ethos.lower()


# ---------- negative cases: malformed agent folders ----------

VALID_YAML = """\
id: {id}
number: 1
name: Sample
squad: S1
version: {version}
model: claude-haiku-5-5
effort: low
description: Sample agent.
tools: {tools}
mcp_servers: []
reads_untrusted: {untrusted}
max_turns: 5
budget_usd: 0.5
timeout_s: 60
workflows: [feature]
output_schema: Output
"""
VALID_SCHEMA = "from aidlc.agent_outputs import AnalysisOutput\n\n\nclass Output(AnalysisOutput):\n    pass\n"


def make_agent(
    root: Path,
    *,
    squad_dir: str = "S1",
    folder: str = "sample",
    agent_id: str = "sample",
    version: str = "1.0.0",
    tools: str = "[Read]",
    untrusted: str = "false",
    prompt: str | None = "# Sample\n",
) -> Path:
    path = root / squad_dir / folder
    path.mkdir(parents=True)
    (path / "agent.yaml").write_text(
        VALID_YAML.format(id=agent_id, version=version, tools=tools, untrusted=untrusted), encoding="utf-8"
    )
    (path / "schema.py").write_text(VALID_SCHEMA, encoding="utf-8")
    if prompt is not None:
        (path / "prompt.md").write_text(prompt, encoding="utf-8")
    return path


def test_valid_sample_agent_loads(tmp_path: Path) -> None:
    spec = load_agent(make_agent(tmp_path))
    assert spec.id == "sample"
    assert Registry(tmp_path).get("sample").prompt == "# Sample"


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"version": "v1.0.0"}, "semver"),
        ({"tools": "[Read, Teleport]"}, "unknown tools"),
        ({"folder": "other-name"}, "folder name must equal id"),
        ({"tools": "[Read, Bash]", "untrusted": "true"}, "reads_untrusted"),
        ({"prompt": None}, "missing prompt.md"),
        ({"prompt": "   \n"}, "prompt.md is empty"),
    ],
)
def test_malformed_agent_rejected(tmp_path: Path, kwargs: dict[str, str | None], message: str) -> None:
    folder = make_agent(tmp_path, **kwargs)
    with pytest.raises(RegistryError, match=message):
        load_agent(folder)


def test_squad_folder_mismatch_rejected(tmp_path: Path) -> None:
    make_agent(tmp_path, squad_dir="S2")
    with pytest.raises(RegistryError, match="declares squad"):
        Registry(tmp_path)


def test_duplicate_numbers_rejected(tmp_path: Path) -> None:
    make_agent(tmp_path, folder="one", agent_id="one")
    make_agent(tmp_path, folder="two", agent_id="two")
    with pytest.raises(RegistryError, match="duplicate agent numbers"):
        Registry(tmp_path)
