from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from aidlc.contracts import ACVerdict, Finding, TestReport, TestResult
from aidlc.platform.gates import GatesConfig, evaluate_quality, load_gates, parse_repo_gates, with_risk_tier
from aidlc.settings import get_settings


def _result(name: str, status: str = "pass", level: str = "unit") -> TestResult:
    return TestResult(id=name, name=name, level=level, status=status)  # type: ignore[arg-type]


def _finding(fid: str, severity: str, blocking: bool = False) -> Finding:
    return Finding(
        id=fid,
        source_agent="security-scanner",
        severity=severity,
        rule="R1",
        message="bad",
        file="a.py",
        line=3,
        blocking=blocking,
    )  # type: ignore[arg-type]


def test_defaults_without_preset(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_PRESETS_DIR", str(tmp_path))
    get_settings.cache_clear()
    cfg = load_gates(None)
    assert cfg == GatesConfig()
    assert cfg.coverage_min_pct == 80 and cfg.block_severities == ["critical", "high"]
    assert (cfg.v1_max_attempts, cfg.fix_loop_max_iterations, cfg.run_budget_usd) == (3, 5, 50.0)


def test_preset_file_then_project_overrides(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    (tmp_path / "gates.default.yaml").write_text("gates:\n  coverage_min_pct: 70\n  a11y: A\n")
    monkeypatch.setenv("AIDLC_PRESETS_DIR", str(tmp_path))
    get_settings.cache_clear()
    cfg = load_gates({"a11y": "off"})
    assert cfg.coverage_min_pct == 70 and cfg.a11y == "off"
    with pytest.raises(ValidationError):
        load_gates({"coverage_minimum": 10})


def test_economy_is_off_by_default_and_project_settings_override_the_preset(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    (tmp_path / "gates.default.yaml").write_text("economy:\n  enabled: false\n  max_turns_cap: 30\n")
    monkeypatch.setenv("AIDLC_PRESETS_DIR", str(tmp_path))
    get_settings.cache_clear()
    assert load_gates(None).economy.model_dump() == {"enabled": False, "effort_cap": "medium", "max_turns_cap": 30}
    project = load_gates({"economy": {"enabled": True, "effort_cap": "low"}})
    assert (project.economy.enabled, project.economy.effort_cap, project.economy.max_turns_cap) == (True, "low", 40)
    with pytest.raises(ValidationError):
        load_gates({"economy": {"enabled": True, "effort_cap": "tiny"}})


def test_quality_passes() -> None:
    report = TestReport(results=[_result("t1"), _result("base", "fail", "baseline")], coverage_pct=91.0)
    result = evaluate_quality(
        GatesConfig(), report, [_finding("F1", "medium")], [ACVerdict(ac_id="AC-1", passed=True)], []
    )
    assert result.gate == "quality" and result.passed and result.issues == []


def test_quality_collects_readable_issues() -> None:
    report = TestReport(
        results=[_result("t1", "fail"), _result("axe-home", "fail", "accessibility")], coverage_pct=60.0
    )
    result = evaluate_quality(
        GatesConfig(),
        report,
        [_finding("F1", "high"), _finding("F2", "low", blocking=True), _finding("F3", "low")],
        [ACVerdict(ac_id="AC-2", passed=False)],
        ["DELETE /v1/items removed"],
    )
    assert not result.passed
    assert result.issues == [
        "1 failing test(s): t1",
        "accessibility (WCAG AA): 1 failing check(s): axe-home",
        "coverage 60.0% is below the 80% minimum",
        "high finding F1 (security-scanner, R1): bad [a.py:3]",
        "low finding F2 (security-scanner, R1): bad [a.py:3]",
        "acceptance criterion AC-2 is not satisfied",
        "breaking API change: DELETE /v1/items removed",
    ]


def test_quality_respects_config_switches() -> None:
    cfg = GatesConfig(
        coverage_min_pct=0, a11y="off", require_all_acs=False, allow_breaking_api_changes=True, block_severities=[]
    )
    report = TestReport(results=[_result("axe", "fail", "accessibility")])
    result = evaluate_quality(cfg, report, [_finding("F1", "critical")], [ACVerdict(ac_id="AC-1", passed=False)], ["x"])
    assert result.passed


def test_missing_coverage_is_a_non_blocking_note_unless_required() -> None:
    report = TestReport(results=[_result("t")])
    lenient = evaluate_quality(GatesConfig(), report, [], [], [])
    assert lenient.passed and lenient.issues == ["coverage not reported (minimum 80%) (non-blocking)"]
    strict = evaluate_quality(GatesConfig(require_coverage_report=True), report, [], [], [])
    assert not strict.passed and strict.issues == ["coverage not reported (minimum 80%)"]
    failing = evaluate_quality(GatesConfig(), TestReport(results=[_result("t", "fail")]), [], [], [])
    assert failing.issues == ["1 failing test(s): t", "coverage not reported (minimum 80%) (non-blocking)"]


def test_repo_gates_sit_between_defaults_and_project_overrides(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    (tmp_path / "gates.default.yaml").write_text("coverage_min_pct: 70\na11y: A\nrun_budget_usd: 40\n")
    monkeypatch.setenv("AIDLC_PRESETS_DIR", str(tmp_path))
    get_settings.cache_clear()
    repo = parse_repo_gates("gates:\n  coverage_min_pct: 85\n  a11y: AAA\n  require_coverage_report: true\n")
    cfg = load_gates({"a11y": "off"}, repo)
    assert (cfg.coverage_min_pct, cfg.a11y, cfg.require_coverage_report, cfg.run_budget_usd) == (85, "off", True, 40)


def test_repo_gates_file_problems_are_ignored(caplog: pytest.LogCaptureFixture) -> None:
    assert parse_repo_gates("coverage_min_pct: [unclosed") == {}
    assert parse_repo_gates("- just\n- a list\n") == {}
    assert parse_repo_gates("coverage_min_pct: 75\nbogus: 1\na11y:\n") == {"coverage_min_pct": 75}
    assert "bogus" in caplog.text


def test_a_risk_tier_applies_its_overrides_from_the_preset() -> None:
    cfg = load_gates({})
    high = with_risk_tier(cfg, "high")
    assert (high.coverage_min_pct, high.require_coverage_report) == (90, True)
    assert "medium" in high.block_severities
    assert with_risk_tier(cfg, "low") == cfg and with_risk_tier(cfg, None) == cfg


def test_a_risk_tier_may_only_override_known_gate_keys() -> None:
    with pytest.raises(ValidationError, match="unknown gate keys"):
        GatesConfig(risk_tiers={"high": {"coverage": 95}})
