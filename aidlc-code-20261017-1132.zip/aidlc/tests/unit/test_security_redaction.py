from __future__ import annotations

import pytest

from aidlc.platform.security.redaction import redact

PRIVATE_KEY = "-----BEGIN RSA PRIVATE KEY-----\nMIIEow\nabc\n-----END RSA PRIVATE KEY-----"


@pytest.mark.parametrize(
    ("text", "secret", "label"),
    [
        ("key AKIAIOSFODNN7EXAMPLE here", "AKIAIOSFODNN7EXAMPLE", "aws_access_key"),
        ("t=ghp_" + "a1" * 18, "ghp_" + "a1" * 18, "github_token"),
        ("gho_" + "Z" * 36, "gho_" + "Z" * 36, "github_token"),
        ("github_pat_11ABCDEFG0123456789_abcdefghijklmnop", "github_pat_11ABCDEFG", "github_token"),
        ("sk-ant-api03-abcdefghijklmnopqrstuvwxyz", "sk-ant-api03", "anthropic_key"),
        ("Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.dozjgNryP4J3jVmNHl0w5N", "eyJhbGci", "jwt"),
        (PRIVATE_KEY, "MIIEow", "private_key"),
        ("postgres://admin:hunter2@db:5432/x", "hunter2", "password"),
        ("API_KEY=abcd1234efgh", "abcd1234efgh", "secret"),
        ('"client_secret": "s3cr3tvalue"', "s3cr3tvalue", "secret"),
        ("password: correcthorse", "correcthorse", "secret"),
        ("card 4111 1111 1111 1111 ok", "4111 1111 1111 1111", "card"),
        ("mail alice@acme-corp.com now", "alice@acme-corp.com", "email"),
    ],
)
def test_redacts(text: str, secret: str, label: str) -> None:
    out = redact(text)
    assert secret not in out
    assert f"[REDACTED:{label}]" in out


def test_keeps_url_user_and_host() -> None:
    assert (
        redact("https://bob:pw123@example.org/repo", emails=False) == "https://bob:[REDACTED:password]@example.org/repo"
    )


def test_non_luhn_numbers_untouched() -> None:
    assert redact("order 1234 5678 9012 3456") == "order 1234 5678 9012 3456"


def test_emails_optional() -> None:
    assert redact("alice@acme-corp.com", emails=False) == "alice@acme-corp.com"


@pytest.mark.parametrize(
    "address", ["alex.morgan@aig.example", "admin@acme.test", "a@example.com", "b@sub.example.org", "c@host.invalid"]
)
def test_reserved_test_domains_are_mock_data_not_personal_data(address: str) -> None:
    assert redact(f"user {address} signed in") == f"user {address} signed in"


def test_lookalike_domains_are_still_redacted() -> None:
    assert redact("alice@example.co and bob@aig.com") == "[REDACTED:email] and [REDACTED:email]"


def test_plain_text_untouched() -> None:
    text = "def tokenize(s):\n    return s.split()  # no secrets"
    assert redact(text) == text


@pytest.mark.parametrize(
    "text",
    [
        "tokens: number | null",
        '"output_tokens": 12163',
        "max_tokens=4096",
        "tokenCount: 1234",
        "TOKENS_TODAY = 1284500",
        "tokensToday: 1284500",
        "inputTokens=4096",
        "token: string;",
        "password: string",
        "access_token: Optional[str]",
        "apiKey?: string[]",
        "token = process.env.AIG_TOKEN",
        "token: ${AIG_TOKEN}",
        "secret: <your-secret>",
    ],
)
def test_counts_types_and_references_are_not_secrets(text: str) -> None:
    assert redact(text) == text


@pytest.mark.parametrize(
    "text", ["token: abcd1234efgh", "password=hunter2!", "api_key=sk_live_51HxYz", "auth_token: stringent123"]
)
def test_secret_values_still_redacted(text: str) -> None:
    assert redact(text).endswith("[REDACTED:secret]")
