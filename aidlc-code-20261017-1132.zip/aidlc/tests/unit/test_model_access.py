from __future__ import annotations

import pytest

from aidlc.platform import model_access
from aidlc.settings import Settings


def test_bedrock_is_the_default() -> None:
    s = Settings()
    assert s.bedrock_enabled and s.aws_region == "us-east-1"
    assert model_access.model_id("claude-haiku-5-5", s) == "anthropic.claude-haiku-5-5"
    assert model_access.sdk_env(s) == {
        "CLAUDE_CODE_USE_BEDROCK": "1",
        "AWS_REGION": "us-east-1",
        # the CLI's own aliases resolve to the mapped ids, never to a model the account cannot use
        "ANTHROPIC_DEFAULT_OPUS_MODEL": "anthropic.claude-opus-5-5",
        "ANTHROPIC_DEFAULT_SONNET_MODEL": "anthropic.claude-sonnet-5-5",
        "ANTHROPIC_DEFAULT_HAIKU_MODEL": "anthropic.claude-haiku-5-5",
        "ANTHROPIC_SMALL_FAST_MODEL": "anthropic.claude-haiku-5-5",
    }
    described = model_access.describe(s)
    assert "Amazon Bedrock in us-east-1" in described and "worker's IAM role" in described


def test_model_map_overrides_from_env_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(
        "AIDLC_BEDROCK_MODEL_MAP", '{"claude-opus-5-5": "arn:aws:bedrock:eu-west-1:1:inference-profile/x"}'
    )
    s = Settings()
    assert model_access.model_id("claude-opus-5-5", s).endswith("inference-profile/x")
    with pytest.raises(model_access.ModelAccessError, match="claude-haiku-5-5"):
        model_access.model_id("claude-haiku-5-5", s)


def test_anthropic_api_mode_is_development_only(monkeypatch: pytest.MonkeyPatch) -> None:
    s = Settings(bedrock_enabled=False)
    assert model_access.model_id("claude-opus-5-5", s) == "claude-opus-5-5" and model_access.sdk_env(s) == {}
    assert model_access.local_problem(s) == "ANTHROPIC_API_KEY is not set"
    assert "ANTHROPIC_API_KEY" in model_access.local_fix(s)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    assert model_access.local_problem(s) is None


def test_local_bedrock_credentials_come_from_the_aws_chain(monkeypatch: pytest.MonkeyPatch) -> None:
    s = Settings(aws_region="ap-southeast-2")
    assert "no AWS credentials for Bedrock in ap-southeast-2" in (model_access.local_problem(s) or "")
    assert "aws sso login" in model_access.local_fix(s)
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
    assert model_access.local_problem(s) is None
    assert "local AWS credentials" in model_access.describe(s, local=True)
