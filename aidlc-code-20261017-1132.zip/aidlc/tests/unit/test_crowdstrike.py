from __future__ import annotations

import hashlib
import sys
import time
from types import SimpleNamespace
from typing import Any

import pytest

from aidlc.interfaces import ScannerUnavailable
from aidlc.platform import factory
from aidlc.platform.security import crowdstrike
from aidlc.platform.security.crowdstrike import CrowdStrikeScanner, FalconApis
from aidlc.platform.security.malware import DisabledScanner
from aidlc.settings import Settings, get_settings

DATA = b"# Spec\nUsers export orders as CSV.\n"
SHA = hashlib.sha256(DATA).hexdigest()


def ok(resources: list[Any], status: int = 200) -> dict[str, Any]:
    return {"status_code": status, "headers": {}, "body": {"resources": resources, "errors": []}}


def err(status: int, message: str) -> dict[str, Any]:
    return {"status_code": status, "headers": {}, "body": {"resources": [], "errors": [{"message": message}]}}


class StubSamples:
    def __init__(self, upload: dict[str, Any] | Exception | None = None) -> None:
        self.upload = upload if upload is not None else ok([{"sha256": SHA, "file_name": "spec.md"}])
        self.uploads: list[dict[str, Any]] = []
        self.deleted: list[str] = []

    def upload_sample(self, **kwargs: Any) -> dict[str, Any]:
        self.uploads.append(kwargs)
        if isinstance(self.upload, Exception):
            raise self.upload
        return self.upload

    def delete_sample(self, **kwargs: Any) -> dict[str, Any]:
        self.deleted.append(kwargs["ids"])
        return ok([])


class StubQuickScan:
    def __init__(self, *results: dict[str, Any], submit: dict[str, Any] | None = None, delay: float = 0) -> None:
        self.results = list(results)
        self.submit = submit or ok(["scan-1"])
        self.submitted: list[dict[str, Any]] = []
        self.polls = 0
        self.delay = delay

    def scan_samples(self, **kwargs: Any) -> dict[str, Any]:
        self.submitted.append(kwargs["body"])
        return self.submit

    def get_scans(self, **kwargs: Any) -> dict[str, Any]:
        assert kwargs == {"ids": "scan-1"}
        self.polls += 1
        time.sleep(self.delay)
        return self.results.pop(0) if len(self.results) > 1 else self.results[0]


def scan_result(status: str, verdict: str | None = None, error: str | None = None) -> dict[str, Any]:
    sample: dict[str, Any] = {"sha256": SHA}
    if verdict:
        sample["verdict"] = verdict
    if error:
        sample["error"] = error
    return ok([{"id": "scan-1", "status": status, "samples": [sample] if status == "done" else []}])


def scanner(samples: StubSamples, quick: StubQuickScan, *, timeout_s: float = 5) -> CrowdStrikeScanner:
    connects: list[tuple[str, str, str]] = []

    def connect(client_id: str, client_secret: str, base_url: str) -> FalconApis:
        connects.append((client_id, client_secret, base_url))
        return FalconApis(samples=samples, quick_scan=quick)

    s = CrowdStrikeScanner(
        "cid",
        "secret",
        base_url="https://api.eu-1.crowdstrike.com",
        timeout_s=timeout_s,
        poll_every_s=0.01,
        connect=connect,
    )
    s.connects = connects  # type: ignore[attr-defined]
    return s


async def test_clean_verdict_after_polling() -> None:
    samples = StubSamples()
    quick = StubQuickScan(scan_result("pending"), scan_result("done", "no specific threat"))
    s = scanner(samples, quick)
    verdict = await s.scan("spec.md", DATA)
    assert verdict.clean and "no specific threat" in verdict.reason
    assert s.connects == [("cid", "secret", "https://api.eu-1.crowdstrike.com")]  # type: ignore[attr-defined]
    [upload] = samples.uploads
    assert upload["file_name"] == "spec.md" and upload["file_data"] == DATA and upload["is_confidential"] is True
    assert quick.submitted == [{"samples": [SHA]}] and quick.polls == 2
    assert samples.deleted == [SHA]  # the sample does not stay in the tenant's collection


@pytest.mark.parametrize("verdict", ["malware", "suspicious", "Malicious"])
async def test_malicious_and_suspicious_verdicts_reject(verdict: str) -> None:
    samples = StubSamples()
    result = await scanner(samples, StubQuickScan(scan_result("done", verdict))).scan("spec.md", DATA)
    assert not result.clean and verdict.lower() in result.reason
    assert samples.deleted == [SHA]


async def test_timeout_fails_closed() -> None:
    samples = StubSamples()
    s = scanner(samples, StubQuickScan(scan_result("pending")), timeout_s=0.1)
    with pytest.raises(ScannerUnavailable, match="timed out"):
        await s.scan("spec.md", DATA)
    assert samples.deleted == [SHA]


async def test_unreachable_api_fails_closed() -> None:
    samples = StubSamples(upload=ConnectionError("Max retries exceeded"))
    with pytest.raises(ScannerUnavailable, match=r"unreachable.*Max retries"):
        await scanner(samples, StubQuickScan(scan_result("done", "clean"))).scan("spec.md", DATA)


@pytest.mark.parametrize(
    ("samples", "quick", "match"),
    [
        (StubSamples(upload=err(403, "access denied, authorization failed")), StubQuickScan(), "access denied"),
        (StubSamples(), StubQuickScan(submit=err(500, "internal error")), "QuickScan submit failed"),
        (StubSamples(), StubQuickScan(scan_result("failed")), "scan-1 failed"),
        (StubSamples(), StubQuickScan(scan_result("done", error="unsupported file")), "unsupported file"),
    ],
)
async def test_api_errors_fail_closed(samples: StubSamples, quick: StubQuickScan, match: str) -> None:
    with pytest.raises(ScannerUnavailable, match=match):
        await scanner(samples, quick).scan("spec.md", DATA)


async def test_auth_failure_fails_closed(monkeypatch: pytest.MonkeyPatch) -> None:
    """falcon_apis uses falconpy's OAuth2 login; a rejected client credential never reaches the upload."""

    class StubOAuth2:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

        def login(self) -> dict[str, Any]:
            return err(401, "access denied, invalid bearer token")

    fake = SimpleNamespace(OAuth2=StubOAuth2, SampleUploads=None, QuickScan=None)
    monkeypatch.setitem(sys.modules, "falconpy", fake)
    s = CrowdStrikeScanner("cid", "bad", timeout_s=5)
    with pytest.raises(ScannerUnavailable, match="authentication failed: access denied"):
        await s.scan("spec.md", DATA)


def test_falcon_apis_share_one_oauth2_session(monkeypatch: pytest.MonkeyPatch) -> None:
    created: dict[str, Any] = {}

    class StubOAuth2:
        def __init__(self, **kwargs: Any) -> None:
            created["auth"] = kwargs

        def login(self) -> dict[str, Any]:
            return {"status_code": 201, "body": {"access_token": "t", "expires_in": 1799}}

    class Service:
        def __init__(self, auth_object: Any) -> None:
            self.auth_object = auth_object

    monkeypatch.setitem(
        sys.modules, "falconpy", SimpleNamespace(OAuth2=StubOAuth2, SampleUploads=Service, QuickScan=Service)
    )
    apis = crowdstrike.falcon_apis("cid", "secret", "https://api.us-2.crowdstrike.com")
    assert created["auth"] == {
        "client_id": "cid",
        "client_secret": "secret",
        "base_url": "https://api.us-2.crowdstrike.com",
        "timeout": crowdstrike.REQUEST_TIMEOUT_S,
    }
    assert apis.samples.auth_object is apis.quick_scan.auth_object  # type: ignore[attr-defined]


async def test_missing_credentials_fail_closed() -> None:
    with pytest.raises(ScannerUnavailable, match="not configured"):
        await CrowdStrikeScanner(None, None).scan("spec.md", DATA)


def test_factory_picks_the_scanner_from_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    factory.clear_overrides()
    monkeypatch.setenv("AIDLC_CROWDSTRIKE_CLIENT_ID", "cid")
    monkeypatch.setenv("AIDLC_CROWDSTRIKE_CLIENT_SECRET", "secret")
    monkeypatch.setenv("AIDLC_CROWDSTRIKE_TIMEOUT_S", "45")
    get_settings.cache_clear()
    picked = factory.get_malware_scanner()
    assert isinstance(picked, CrowdStrikeScanner)
    assert (picked.client_id, picked.timeout_s, picked.base_url) == ("cid", 45, "https://api.crowdstrike.com")
    monkeypatch.setenv("AIDLC_MALWARE_SCANNER", "none")
    get_settings.cache_clear()
    assert isinstance(factory.get_malware_scanner(), DisabledScanner)


def test_scanner_can_only_be_disabled_in_dev_auth_mode() -> None:
    assert Settings(malware_scanner="none", auth_mode="dev").malware_scanner == "none"
    with pytest.raises(ValueError, match="only allowed with auth_mode"):
        Settings(malware_scanner="none", auth_mode="oidc")
