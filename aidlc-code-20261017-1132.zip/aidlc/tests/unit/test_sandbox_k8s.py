from __future__ import annotations

import json
from pathlib import Path

import pytest

from aidlc.platform.sandbox.k8s import K8sError, K8sJobExecutor


def _executor(tmp_path: Path) -> K8sJobExecutor:
    return K8sJobExecutor(
        namespace="sbx",
        image="img:1",
        egress_allowlist=["pypi.org", "github.com"],
        workspace_root=tmp_path,
        poll_interval_s=0,
    )


class FakeKubectl:
    def __init__(self, job_states: list[dict], exit_code: int = 0, logs: str = "out") -> None:
        self.calls: list[tuple[tuple[str, ...], bytes | None]] = []
        self.job_states = job_states
        self.exit_code = exit_code
        self.logs = logs

    async def __call__(self, *args: str, stdin: bytes | None = None) -> tuple[int, str, str]:
        self.calls.append((args, stdin))
        if args[:2] == ("get", "job"):
            status = self.job_states.pop(0) if len(self.job_states) > 1 else self.job_states[0]
            return 0, json.dumps({"status": status}), ""
        if args[:2] == ("get", "pods"):
            pod = {"status": {"containerStatuses": [{"state": {"terminated": {"exitCode": self.exit_code}}}]}}
            return 0, json.dumps({"items": [pod]}), ""
        if args[0] == "logs":
            return 0, self.logs, ""
        return 0, "", ""


def test_job_manifest_is_hardened(tmp_path: Path) -> None:
    ex = _executor(tmp_path)
    job = ex.job_manifest("j1", ["pytest", "-q"], tmp_path / "run1" / "repo", timeout_s=300, env={"CI": "1"})
    spec = job["spec"]
    assert spec["activeDeadlineSeconds"] == 300
    assert spec["backoffLimit"] == 0
    pod = spec["template"]["spec"]
    assert pod["automountServiceAccountToken"] is False
    assert pod["securityContext"]["runAsNonRoot"] is True
    container = pod["containers"][0]
    assert container["command"] == ["pytest", "-q"]
    assert container["workingDir"] == "/workspace/run1/repo"
    assert container["securityContext"]["readOnlyRootFilesystem"] is True
    assert container["securityContext"]["allowPrivilegeEscalation"] is False
    assert container["securityContext"]["capabilities"] == {"drop": ["ALL"]}
    assert container["resources"]["limits"] == {"cpu": "2", "memory": "4Gi"}
    assert {"name": "CI", "value": "1"} in container["env"]
    assert {m["mountPath"] for m in container["volumeMounts"]} == {"/workspace", "/tmp"}


def test_cwd_outside_workspace_rejected(tmp_path: Path) -> None:
    with pytest.raises(K8sError):
        _executor(tmp_path / "ws").workdir_for(tmp_path / "elsewhere")


def test_egress_policy_lists_allowlist(tmp_path: Path) -> None:
    policy = _executor(tmp_path).egress_policy_manifest()
    fqdn_rule = policy["spec"]["egress"][1]
    assert fqdn_rule["toFQDNs"] == [{"matchName": "pypi.org"}, {"matchName": "github.com"}]
    assert policy["spec"]["endpointSelector"] == {"matchLabels": {"app": "aidlc-sandbox"}}


async def test_run_applies_waits_logs_and_deletes(tmp_path: Path) -> None:
    ex = _executor(tmp_path)
    fake = FakeKubectl([{}, {"conditions": [{"type": "Complete", "status": "True"}]}], exit_code=0, logs="ok\n")
    ex._kubectl = fake  # type: ignore[method-assign]
    result = await ex.run(["make", "test"], tmp_path / "w")
    assert result.exit_code == 0
    assert result.stdout == "ok\n"
    assert not result.timed_out
    verbs = [c[0][0] for c in fake.calls]
    assert verbs[0] == "apply" and verbs[-1] == "delete"
    applied = json.loads(fake.calls[0][1] or b"{}")
    assert [i["kind"] for i in applied["items"]] == ["CiliumNetworkPolicy", "Job"]
    # The policy is applied only once per executor.
    fake.job_states = [{"conditions": [{"type": "Failed", "status": "True", "reason": "BackoffLimitExceeded"}]}]
    fake.exit_code = 2
    fake.calls.clear()
    result = await ex.run(["make", "test"], tmp_path / "w")
    assert result.exit_code == 2
    assert [i["kind"] for i in json.loads(fake.calls[0][1] or b"{}")["items"]] == ["Job"]


async def test_deadline_exceeded_is_timeout(tmp_path: Path) -> None:
    ex = _executor(tmp_path)
    ex._kubectl = FakeKubectl([{"conditions": [{"type": "Failed", "status": "True", "reason": "DeadlineExceeded"}]}])  # type: ignore[method-assign]
    result = await ex.run(["sleep", "999"], tmp_path, timeout_s=5)
    assert result.timed_out
    assert result.exit_code == -1


async def test_apply_failure_raises(tmp_path: Path) -> None:
    ex = _executor(tmp_path)

    async def failing(*args: str, stdin: bytes | None = None) -> tuple[int, str, str]:
        return 1, "", "forbidden"

    ex._kubectl = failing  # type: ignore[method-assign]
    with pytest.raises(K8sError, match="forbidden"):
        await ex.run(["true"], tmp_path)
