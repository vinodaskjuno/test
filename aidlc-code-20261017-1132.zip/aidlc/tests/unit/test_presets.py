"""Structural checks for the stack presets (``presets/*.yml``) and their scaffolds (``presets/templates/<id>/``)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
import yaml

from aidlc.adlc_config import load_config
from aidlc.orchestrator.workflows.runtime import OWNER_AGENTS

PRESETS = Path(__file__).resolve().parents[2] / "presets"
TEMPLATES = PRESETS / "templates"
REQUIRED_KEYS = {
    "id",
    "name",
    "description",
    "stack",
    "repos",
    "merge_order",
    "integration_branch",
    "modules",
    "commands",
}

EXPECTED = {"nextjs-fastapi", "vite-react", "fastapi", "vscode-extension"}

PRESET_FILES = sorted(PRESETS.glob("*.yml"))
SCAFFOLDS = sorted(p for p in TEMPLATES.iterdir() if p.is_dir())


def _load(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _scaffold_files(pattern: str) -> list[Path]:
    return sorted(p for root in SCAFFOLDS for p in root.rglob(pattern) if "node_modules" not in p.parts)


def _rel(path: Path) -> str:
    return str(path.relative_to(PRESETS))


def test_presets_and_scaffolds_found() -> None:
    assert {p.stem for p in PRESET_FILES} >= EXPECTED
    assert {p.name for p in SCAFFOLDS} >= EXPECTED


@pytest.mark.parametrize("path", PRESET_FILES, ids=lambda p: p.stem)
def test_preset_has_required_keys(path: Path) -> None:
    preset = _load(path)
    assert set(preset) >= REQUIRED_KEYS, sorted(REQUIRED_KEYS - set(preset))
    assert preset["id"] == path.stem
    assert preset["name"] and preset["description"]
    for kind in ("install", "test"):
        commands = preset["commands"][kind]
        assert isinstance(commands, list) and commands, kind
        assert all(isinstance(c, str) and c for c in commands), kind


@pytest.mark.parametrize("path", PRESET_FILES, ids=lambda p: p.stem)
def test_preset_modules_have_owner_agents(path: Path) -> None:
    modules = _load(path)["modules"]
    assert modules
    for name, module in modules.items():
        assert module["path"], name
        assert module["owner_agent"] in OWNER_AGENTS, f"{name}: {module['owner_agent']}"


@pytest.mark.parametrize("path", PRESET_FILES, ids=lambda p: p.stem)
def test_preset_parses_as_project_config(path: Path) -> None:
    cfg = load_config(path, project_id="demo")
    assert cfg.stack_preset == path.stem
    assert [r.id for r in cfg.repos if r.primary] == [cfg.repos[0].id]


@pytest.mark.parametrize("scaffold", SCAFFOLDS, ids=lambda p: p.name)
def test_scaffold_matches_a_preset(scaffold: Path) -> None:
    preset = PRESETS / f"{scaffold.name}.yml"
    assert preset.is_file(), f"no preset for scaffold {scaffold.name}"
    for rel in ("README.md", ".gitignore", ".adlc/config.yml"):
        assert (scaffold / rel).is_file(), rel
    assert not list(scaffold.rglob("node_modules"))


@pytest.mark.parametrize("scaffold", SCAFFOLDS, ids=lambda p: p.name)
def test_scaffold_adlc_config_names_its_stack(scaffold: Path) -> None:
    cfg = load_config(scaffold / ".adlc" / "config.yml")
    assert cfg.stack_preset == scaffold.name
    assert {r.id for r in cfg.repos} == set(_load(PRESETS / f"{scaffold.name}.yml")["repos"])


@pytest.mark.parametrize("path", _scaffold_files("*.json"), ids=_rel)
def test_scaffold_json_parses(path: Path) -> None:
    assert json.loads(path.read_text(encoding="utf-8")) is not None


@pytest.mark.parametrize("path", [*_scaffold_files("*.yml"), *_scaffold_files("*.yaml")], ids=_rel)
def test_scaffold_yaml_parses(path: Path) -> None:
    assert _load(path) is not None
