from __future__ import annotations

import pytest

from aidlc.platform.git.conflict_bound import balance_problem, resolve_text


def region(ours: str, base: str, theirs: str) -> str:
    return f"<<<<<<< ours\n{ours}||||||| base\n{base}=======\n{theirs}>>>>>>> theirs\n"


def test_no_markers_is_unchanged() -> None:
    text = "a\nb\n"
    result = resolve_text(text)
    assert result.ok and result.text == text and result.regions == 0


def test_pure_append_both_sides_resolves_ours_then_theirs() -> None:
    text = "import x\n" + region("def a():\n    return 1\n", "", "def b():\n    return [2]\n") + "tail\n"
    result = resolve_text(text)
    assert result.ok, result.reason
    assert result.text == "import x\ndef a():\n    return 1\ndef b():\n    return [2]\ntail\n"
    assert result.regions == 1


def test_multiple_regions_all_resolvable() -> None:
    text = "h\n" + region("a()\n", "", "b()\n") + "mid\n" + region("{x: 1}\n", "", "") + "end"
    result = resolve_text(text)
    assert result.ok
    assert result.text == "h\na()\nb()\nmid\n{x: 1}\nend"
    assert result.regions == 2


def test_side_modifying_existing_line_is_refused() -> None:
    text = region("x = 2\n", "x = 1\n", "x = 3\n")
    result = resolve_text(text)
    assert not result.ok
    assert "base not empty" in result.reason
    assert result.text == text


def test_one_resolvable_and_one_not_refuses_everything() -> None:
    text = region("a\n", "", "b\n") + region("c\n", "old\n", "d\n")
    result = resolve_text(text)
    assert not result.ok and "region 2" in result.reason


@pytest.mark.parametrize(
    ("ours", "theirs", "fragment"),
    [
        ("def f(\n", "g()\n", "ours side leaves '('"),
        ("a()\n", "}\n", "theirs side closes '}'"),
        ("[1, 2)\n", "x\n", "ours side closes ')'"),
        ("ok()\n", "if (a) {\n", "theirs side leaves '{'"),
    ],
)
def test_unbalanced_side_is_refused(ours: str, theirs: str, fragment: str) -> None:
    result = resolve_text(region(ours, "", theirs))
    assert not result.ok
    assert fragment in result.reason


def test_non_diff3_markers_refused() -> None:
    result = resolve_text("<<<<<<< ours\na\n=======\nb\n>>>>>>> theirs\n")
    assert not result.ok and "diff3" in result.reason


def test_unterminated_region_refused() -> None:
    result = resolve_text("<<<<<<< ours\na\n||||||| base\n=======\nb\n")
    assert not result.ok and "unterminated" in result.reason


def test_lookalike_text_is_not_a_marker() -> None:
    text = "x = '<<<<<<<<'\n"
    assert resolve_text(text).ok


def test_balance_problem() -> None:
    assert balance_problem(["f(a[1], {b: 2})\n"]) is None
    assert balance_problem([")("]) == "closes ')' it did not open"
    assert balance_problem(["(["]) == "leaves '([' unclosed"


def test_a_file_both_branches_created_is_refused_not_concatenated() -> None:
    ours = "import React from 'react';\nexport function SearchBox() {\n  return null;\n}\n"
    theirs = "import { useState } from 'react';\nexport function Search() {\n  return 1;\n}\n"
    result = resolve_text(region(ours, "", theirs))
    assert not result.ok and result.reason == "both branches created the whole file (add/add conflict)"


def test_sides_adding_the_same_declaration_are_refused() -> None:
    react = "import React from 'react';\n"
    text = "header\n" + region(f"{react}const a = 1;\n", "", f"{react}const b = 2;\n")
    result = resolve_text(text)
    assert not result.ok and "both sides add \"import React from 'react';\"" in result.reason


def test_shared_body_lines_do_not_block_two_new_functions() -> None:
    body = "    store = _store(request)\n    order = store.get(order_id)\n"
    ours = f"def cancel(order_id):\n{body}    return store.cancel(order_id)\n"
    theirs = f"def set_status(order_id):\n{body}    return store.set(order_id)\n"
    assert resolve_text("routes\n" + region(ours, "", theirs)).ok


def test_short_identical_lines_do_not_block_honest_additions() -> None:
    # both sides end their entry with the same short line ("  },"): too short to mean the additions overlap
    text = "routes = [\n" + region("  {\n    path: '/home',\n  },\n", "", "  {\n    path: '/admin',\n  },\n") + "]\n"
    assert resolve_text(text).ok
