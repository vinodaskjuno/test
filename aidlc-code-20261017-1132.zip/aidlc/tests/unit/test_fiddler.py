from __future__ import annotations

import sys
import time
from types import SimpleNamespace
from typing import Any

import pytest

from aidlc.contracts import AgentCall, AgentResult
from aidlc.platform.observability import fiddler
from aidlc.settings import get_settings

SPEC = SimpleNamespace(id="spec-analyst", squad="S1", model="claude-opus-5-5", version="1.2.0")
CALL = AgentCall(
    agent_id="spec-analyst",
    run_id="run-1",
    project_id="p1",
    inputs={"requirement": "Use token=abcd1234secret and mail ada@acme-corp.com", "untrusted_keys": ["requirement"]},
    attempt=2,
)
RESULT = AgentResult(
    agent_id="spec-analyst",
    agent_version="1.2.0",
    ok=True,
    output={"summary": "done", "key": "AKIAABCDEFGHIJKLMNOP"},
    cost_usd=0.42,
    input_tokens=1200,
    output_tokens=300,
    duration_ms=4100,
    num_turns=3,
)


class StubModel:
    def __init__(self) -> None:
        self.published: list[tuple[list[dict[str, Any]], Any]] = []

    def publish_stream(self, events: list[dict[str, Any]], environment: Any) -> list[str]:
        self.published.append((events, environment))
        return ["id-1"]


class StubFiddler:
    """Stands in for the ``fiddler`` package: init / Project.from_name / Model.from_name / EnvType."""

    class EnvType:
        PRODUCTION = "PRODUCTION"

    def __init__(self) -> None:
        self.model = StubModel()
        self.inits: list[dict[str, Any]] = []
        self.lookups: list[tuple[str, Any]] = []
        stub = self

        class Project:
            @staticmethod
            def from_name(name: str) -> Any:
                stub.lookups.append(("project", name))
                return SimpleNamespace(id="proj-uuid")

        class Model:
            @staticmethod
            def from_name(name: str, project_id: str, latest: bool = False) -> Any:
                stub.lookups.append(("model", (name, project_id, latest)))
                return stub.model

        self.Project = Project
        self.Model = Model

    def init(self, **kwargs: Any) -> None:
        self.inits.append(kwargs)


@pytest.fixture
def configured(monkeypatch: pytest.MonkeyPatch) -> StubFiddler:
    for key, value in {
        "AIDLC_FIDDLER_URL": "https://acme.fiddler.test",
        "AIDLC_FIDDLER_TOKEN": "fid-token",
        "AIDLC_FIDDLER_PROJECT": "aidlc",
        "AIDLC_FIDDLER_MODEL": "aidlc-agents",
    }.items():
        monkeypatch.setenv(key, value)
    get_settings.cache_clear()
    stub = StubFiddler()
    monkeypatch.setitem(sys.modules, "fiddler", stub)
    monkeypatch.setattr(fiddler, "_models", {})
    return stub


async def test_unconfigured_is_a_no_op(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(fiddler, "_publish", lambda *a: pytest.fail("must not publish"))
    assert await fiddler.publish_agent_call(SPEC, CALL, RESULT) is False


async def test_publishes_one_redacted_event_per_call(configured: StubFiddler) -> None:
    assert await fiddler.publish_agent_call(SPEC, CALL, RESULT) is True
    assert configured.inits == [
        {
            "url": "https://acme.fiddler.test",
            "token": "fid-token",
            "timeout": (5.0, 10.0),
            "auto_attach_log_handler": False,
        }
    ]
    assert configured.lookups == [("project", "aidlc"), ("model", ("aidlc-agents", "proj-uuid", True))]
    [(events, environment)] = configured.model.published
    assert environment == "PRODUCTION"
    [event] = events
    assert {k: event[k] for k in ("run_id", "project_id", "agent_id", "squad", "model", "agent_version")} == {
        "run_id": "run-1",
        "project_id": "p1",
        "agent_id": "spec-analyst",
        "squad": "S1",
        "model": "claude-opus-5-5",
        "agent_version": "1.2.0",
    }
    assert (event["ok"], event["input_tokens"], event["output_tokens"], event["cost_usd"]) == (True, 1200, 300, 0.42)
    assert (event["duration_ms"], event["num_turns"], event["outcome"]) == (4100, 3, "ok")
    assert event["event_id"].startswith("run-1:spec-analyst:2:")
    assert "abcd1234secret" not in event["prompt_summary"] and "ada@acme-corp.com" not in event["prompt_summary"]
    assert "untrusted_keys" not in event["prompt_summary"]
    assert "AKIAABCDEFGHIJKLMNOP" not in event["output_summary"] and "done" in event["output_summary"]


async def test_connection_is_reused_and_outcome_can_be_given(configured: StubFiddler) -> None:
    await fiddler.publish_agent_call(SPEC, CALL, RESULT)
    await fiddler.publish_agent_call(SPEC, CALL, RESULT, outcome="pr-ready")
    assert len(configured.inits) == 1 and len(configured.model.published) == 2
    assert configured.model.published[1][0][0]["outcome"] == "pr-ready"


def test_failed_calls_summarise_the_error_and_classify_the_outcome() -> None:
    timeout = RESULT.model_copy(update={"ok": False, "output": {}, "error": "timed out after 60s"})
    event = fiddler.agent_event(SPEC, CALL, timeout)
    assert event["ok"] is False and event["outcome"] == "timeout" and event["output_summary"] == "timed out after 60s"
    invalid = RESULT.model_copy(update={"ok": False, "error": "invalid output after one correction: x"})
    assert fiddler.call_outcome(invalid) == "invalid-output"
    assert fiddler.call_outcome(RESULT.model_copy(update={"ok": False, "error": "boom"})) == "error"


def test_summaries_are_short() -> None:
    assert len(fiddler.summary("x" * 10_000)) == fiddler.SUMMARY_CHARS


async def test_errors_are_logged_never_raised(configured: StubFiddler, caplog: pytest.LogCaptureFixture) -> None:
    def broken(**_: Any) -> Any:
        raise ConnectionError("fiddler down")

    configured.Project.from_name = staticmethod(broken)  # type: ignore[method-assign]
    assert await fiddler.publish_agent_call(SPEC, CALL, RESULT) is False
    assert "fiddler down" in caplog.text
    assert fiddler._models == {}  # a failed connection is retried on the next call


async def test_publishing_is_bounded_by_a_timeout(configured: StubFiddler, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(fiddler, "TIMEOUT_S", 0.05)
    monkeypatch.setattr(configured.model, "publish_stream", lambda **_: time.sleep(0.5))
    started = time.monotonic()
    assert await fiddler.publish_agent_call(SPEC, CALL, RESULT) is False
    assert time.monotonic() - started < 0.4
