from __future__ import annotations

import io

import docx
import pytest

from aidlc.api.confluence import storage_to_markdown
from aidlc.api.convert import docx_to_markdown
from aidlc.platform.spec_templates import TEMPLATE_TYPES, assemble, check_spec, example_text, template_text
from aidlc.platform.spec_templates.render import to_confluence, to_docx


@pytest.mark.parametrize("type_id", list(TEMPLATE_TYPES))
def test_committed_templates_match_their_parts(type_id: str) -> None:
    assert template_text(type_id) == assemble(type_id), "run scripts/build_spec_templates.py"


def test_each_template_carries_its_surfaces_and_add_ons() -> None:
    text = template_text("integration")
    assert "| Template | aidlc-spec/1 · integration |" in text and "| Surfaces | backend, integration |" in text
    assert "### X1. Counterparty and contract" in text and "### B1. Endpoints" in text
    assert "### U1." not in text and "[[" not in text and "<!-- addons -->" not in text


@pytest.mark.parametrize("type_id", ["ui-backend", "vsix", "bug"])
@pytest.mark.parametrize("source", ["template", "example"])
def test_word_and_confluence_versions_check_the_same_as_markdown(type_id: str, source: str) -> None:
    markdown = template_text(type_id) if source == "template" else example_text(type_id)
    expected = check_spec(markdown)
    from_word = check_spec(docx_to_markdown(f"{type_id}.docx", to_docx(markdown)))
    from_confluence = check_spec(storage_to_markdown(to_confluence(markdown)))
    for result in (from_word, from_confluence):
        assert result.templated
        assert (result.errors, result.warnings, result.gaps) == (expected.errors, expected.warnings, expected.gaps)
        assert result.surfaces == expected.surfaces


def test_word_guidance_is_a_small_grey_italic_note() -> None:
    document = docx.Document(io.BytesIO(to_docx(template_text("bug"))))
    guides = [p for p in document.paragraphs if p.text.startswith("Guide: ")]
    assert guides and all(run.italic for p in guides for run in p.runs)
    assert document.paragraphs[0].style.name == "Title"
    assert any(p.style.name == "Heading 3" and p.text == "1. Observed behaviour" for p in document.paragraphs)


def test_confluence_escapes_text_and_keeps_code_blocks() -> None:
    xhtml = to_confluence("# A <b>\n\n```svg\n<svg/>\n```\n")
    assert "<h1>A &lt;b&gt;</h1>" in xhtml
    assert '<ac:structured-macro ac:name="code"><ac:plain-text-body><![CDATA[<svg/>]]>' in xhtml
