from __future__ import annotations

import pytest

from aidlc.platform import tenancy


@pytest.fixture
def setup() -> dict[str, str]:
    org = tenancy.create_org("Acme")
    team = tenancy.create_team(org.id, "Payments")
    other_team = tenancy.create_team(org.id, "Search")
    project = tenancy.create_project(team.id, "Shop API")
    other = tenancy.create_project(other_team.id, "Search UI", project_id="search-ui")
    tenancy.add_member(team.id, "dev@acme.io", "contributor")
    tenancy.add_member(team.id, "lead@acme.io", "maintainer")
    tenancy.add_member(team.id, "pm@acme.io", "viewer")
    tenancy.ensure_user("root@acme.io", is_admin=True)
    return {"team": team.id, "project": project.id, "other": other.id}


def test_ids_are_slugged(setup: dict[str, str]) -> None:
    assert setup["project"].startswith("shop-api-")
    assert setup["other"] == "search-ui"


def test_effective_roles(setup: dict[str, str]) -> None:
    p = setup["project"]
    assert tenancy.effective_role("dev@acme.io", p) == "contributor"
    assert tenancy.effective_role("lead@acme.io", p) == "maintainer"
    assert tenancy.effective_role("root@acme.io", p) == "admin"
    assert tenancy.effective_role("dev@acme.io", setup["other"]) is None
    assert tenancy.effective_role("nobody@acme.io", p) is None
    assert tenancy.effective_role("dev@acme.io", "missing") is None


def test_require_role(setup: dict[str, str]) -> None:
    p = setup["project"]
    assert tenancy.require_role("lead@acme.io", p, "contributor") == "maintainer"
    with pytest.raises(PermissionError, match="needs maintainer"):
        tenancy.require_role("dev@acme.io", p, "maintainer")
    with pytest.raises(PermissionError, match="no access"):
        tenancy.require_role("dev@acme.io", setup["other"], "viewer")


def test_role_changes_and_removal(setup: dict[str, str]) -> None:
    tenancy.add_member(setup["team"], "dev@acme.io", "admin")
    assert tenancy.effective_role("dev@acme.io", setup["project"]) == "admin"
    tenancy.remove_member(setup["team"], "dev@acme.io")
    assert tenancy.effective_role("dev@acme.io", setup["project"]) is None
    with pytest.raises(ValueError):
        tenancy.add_member(setup["team"], "x@acme.io", "owner")


def test_roles_for_and_members(setup: dict[str, str]) -> None:
    assert tenancy.roles_for("pm@acme.io") == {setup["project"]: "viewer"}
    assert tenancy.roles_for("root@acme.io") == {setup["project"]: "admin", setup["other"]: "admin"}
    assert tenancy.roles_for("ghost@acme.io") == {}
    members = tenancy.project_members(setup["project"], "contributor")
    assert [(u.id, r) for u, r in members] == [("dev@acme.io", "contributor"), ("lead@acme.io", "maintainer")]


def test_role_order() -> None:
    assert tenancy.role_at_least("admin", "viewer")
    assert not tenancy.role_at_least("viewer", "contributor")
    assert not tenancy.role_at_least(None, "viewer")
