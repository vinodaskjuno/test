"""Agent prompts: every prompt.md follows the shared structure and refers to real orchestrator input keys."""

from __future__ import annotations

import re
from pathlib import Path

import pytest
import yaml

AGENTS_DIR = Path(__file__).resolve().parents[2] / "agents"
PROMPTS = sorted(AGENTS_DIR.glob("S*/*/prompt.md"))

REQUIRED_SECTIONS = [
    "## Role",
    "## Responsibilities",
    "## Inputs you receive",
    "## Method",
    "## Output",
    "## Guardrails",
]
# The orchestrator's AgentCall.inputs keys (CLAUDE.md, "Agent input keys").
INPUT_KEYS = {
    "work_item",
    "sources",
    "requirement",
    "answers",
    "repo_profile",
    "analysis",
    "architecture",
    "openapi",
    "plan",
    "tasks",
    "task",
    "fix_ticket",
    "diff",
    "changed_files",
    "test_report",
    "findings",
    "verdicts",
    "lessons",
    "manifest",
    "gates_config",
    "conventions",
    "pr_comments",
    "ci_logs",
    "run_summary",
    "metrics",
    "eval_results",
    "mode",
    "surfaces",
    "spec_check",
}
FORBIDDEN = re.compile(r"\b(TODO|TBD|FIXME|lorem)\b", re.IGNORECASE)


def _id(path: Path) -> str:
    return path.parent.name


def test_every_agent_has_a_prompt() -> None:
    assert len(PROMPTS) == 65


@pytest.mark.parametrize("path", PROMPTS, ids=_id)
def test_prompt_structure(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    name = yaml.safe_load((path.parent / "agent.yaml").read_text(encoding="utf-8"))["name"]
    assert text.startswith(f"# {name}\n")
    headings = [line.strip() for line in text.splitlines() if line.startswith("## ")]
    assert headings == REQUIRED_SECTIONS
    assert 40 <= len(text.splitlines()) <= 200


@pytest.mark.parametrize("path", PROMPTS, ids=_id)
def test_prompt_names_real_input_keys(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    inputs = text.split("## Inputs you receive", 1)[1].split("\n## ", 1)[0]
    named = set(re.findall(r"`([a-z_]+)`", inputs))
    assert named & INPUT_KEYS, "Inputs section names no orchestrator input key"


@pytest.mark.parametrize("path", PROMPTS, ids=_id)
def test_prompt_demands_json_and_has_no_filler(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    output = text.split("## Output", 1)[1].split("\n## ", 1)[0]
    assert "JSON" in output
    assert not FORBIDDEN.search(text)


def _reads_untrusted(path: Path) -> bool:
    return bool(yaml.safe_load((path.parent / "agent.yaml").read_text(encoding="utf-8"))["reads_untrusted"])


@pytest.mark.parametrize("path", [p for p in PROMPTS if _reads_untrusted(p)], ids=_id)
def test_untrusted_readers_are_told_content_is_data(path: Path) -> None:
    assert "untrusted" in path.read_text(encoding="utf-8").lower()
