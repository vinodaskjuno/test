from __future__ import annotations

from aidlc.orchestrator.workflows.loop_guard import CONTINUE, LoopGuardConfig, decide, failure_signature

CFG = LoopGuardConfig(max_iterations=5, budget_usd=10.0)


def test_signature_is_order_independent_and_ignores_duplicates() -> None:
    a = failure_signature(["t2", "t1", "t1"], ["R1"], ["AC-2", "AC-1"])
    b = failure_signature(["t1", "t2"], ["R1", "R1"], ["AC-1", "AC-2"])
    assert a == b
    assert len(a) == 64


def test_signature_excludes_baseline_failures() -> None:
    assert failure_signature(["t1", "old"], [], [], baseline_failures=["old"]) == failure_signature(["t1"], [], [])


def test_signature_distinguishes_categories() -> None:
    assert failure_signature(["x"], [], []) != failure_signature([], ["x"], [])
    assert failure_signature([], ["x"], []) != failure_signature([], [], ["x"])


def test_continue_when_new_signature_under_caps() -> None:
    assert decide(1, ["s1"], 1.0, CFG) is CONTINUE
    assert decide(2, ["s1", "s2"], 1.0, CFG) is CONTINUE


def test_repeated_signature_escalates() -> None:
    d = decide(2, ["s1", "s1"], 1.0, CFG)
    assert (d.action, d.reason) == ("escalate", "repeated_signature")
    d = decide(3, ["s1", "s2", "s1"], 1.0, CFG)
    assert d.reason == "repeated_signature"


def test_loop_cap_escalates() -> None:
    d = decide(5, ["a", "b", "c", "d", "e"], 1.0, CFG)
    assert (d.action, d.reason) == ("escalate", "loop_cap")


def test_budget_wins_over_other_reasons() -> None:
    d = decide(5, ["a", "a"], 10.01, CFG)
    assert d.reason == "budget"
    assert "10.01" in d.detail


def test_empty_history_continues() -> None:
    assert decide(1, [], 0.0, CFG) is CONTINUE
