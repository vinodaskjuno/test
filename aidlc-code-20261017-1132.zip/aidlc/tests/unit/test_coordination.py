from __future__ import annotations

import subprocess
import threading
from pathlib import Path

import pytest

from aidlc.platform.coordination import id_alloc, manifest
from aidlc.platform.coordination.trial_merge import trial_merge
from aidlc.platform.db import get_engine


def test_allocate_formats_and_increments() -> None:
    assert id_alloc.allocate("p1", "REQ") == "REQ-001"
    assert id_alloc.allocate("p1", "REQ") == "REQ-002"
    assert id_alloc.allocate("p1", "TASK") == "TASK-001"
    assert id_alloc.allocate("p2", "REQ") == "REQ-001"


def test_allocate_is_atomic_under_concurrency() -> None:
    get_engine()  # create the schema once up front; concurrent first calls would race on create_all
    results: list[str] = []
    lock = threading.Lock()
    errors: list[BaseException] = []

    def worker() -> None:
        try:
            for _ in range(10):
                rid = id_alloc.allocate("proj", "REQ")
                with lock:
                    results.append(rid)
        except BaseException as exc:
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    assert len(results) == 200
    assert sorted(int(r.split("-")[1]) for r in results) == list(range(1, 201))


def test_manifest_rank_overlaps_and_finish() -> None:
    assert manifest.register("r1", "p", "REQ-001", "feat/a", ["api"], ["src/a.py", "src/b.py"], ["auth"]) == 1
    assert manifest.register("r2", "p", "REQ-002", "feat/b", ["api"], ["src/b.py"], ["billing"]) == 2
    assert manifest.register("r3", "p", "REQ-003", "feat/c", ["web"], ["ui/x.tsx"], ["auth"]) == 3
    assert manifest.register("other", "q", "REQ-001", "feat/z", ["api"], ["src/b.py"]) == 1
    # Re-registration keeps the rank.
    assert manifest.register("r2", "p", "REQ-002", "feat/b", ["api"], ["src/b.py", "src/c.py"], ["billing"]) == 2

    assert [v.run_id for v in manifest.active("p")] == ["r1", "r2", "r3"]
    assert [v.run_id for v in manifest.higher_ranked("r3")] == ["r1", "r2"]
    assert manifest.higher_ranked("r1") == []

    ov = {o.run_id: o for o in manifest.overlaps("r1")}
    assert ov["r2"].files == ["src/b.py"] and ov["r2"].components == []
    assert ov["r3"].files == [] and ov["r3"].components == ["auth"]
    assert "other" not in ov

    view = manifest.update("r3", files=["ui/y.tsx", "ui/y.tsx"], status="active")
    assert view.files == ["ui/y.tsx"]
    with pytest.raises(ValueError):
        manifest.update("r3", rank=1)

    manifest.finish("r2", "pr-ready")
    assert [v.run_id for v in manifest.active("p")] == ["r1", "r2", "r3"]  # still in flight
    manifest.finish("r1", "done")
    assert [v.run_id for v in manifest.active("p")] == ["r2", "r3"]
    assert [v.run_id for v in manifest.higher_ranked("r3")] == ["r2"]
    # A newcomer ranks after everything in flight (FIFO), never ties.
    assert manifest.register("r4", "p", "REQ-004", "feat/d", ["api"]) == 4


def test_manifest_unknown_run() -> None:
    with pytest.raises(LookupError):
        manifest.update("nope", status="done")
    with pytest.raises(LookupError):
        manifest.overlaps("nope")


def _sh(cwd: Path, *args: str) -> None:
    subprocess.run(
        ["git", "-c", "user.name=T", "-c", "user.email=t@x", *args], cwd=cwd, check=True, capture_output=True
    )


def _commit(repo: Path, name: str, text: str, msg: str) -> None:
    (repo / name).write_text(text)
    _sh(repo, "add", ".")
    _sh(repo, "commit", "-qm", msg)


async def test_trial_merge_clean_and_conflicted(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    repo.mkdir()
    _sh(repo, "init", "-q", "-b", "main")
    _commit(repo, "a.txt", "1\n2\n3\n", "base")
    _sh(repo, "branch", "x")
    _sh(repo, "branch", "y")
    _sh(repo, "checkout", "-q", "x")
    _commit(repo, "a.txt", "1\nX\n3\n", "x edits")
    _commit(repo, "x.txt", "x\n", "x adds")
    _sh(repo, "checkout", "-q", "y")
    _commit(repo, "a.txt", "1\nY\n3\n", "y edits")
    _sh(repo, "checkout", "-q", "main")
    _commit(repo, "m.txt", "m\n", "main adds")

    clean = await trial_merge(repo, "main", "x")
    assert clean.clean and clean.conflicts == [] and clean.tree

    conflicted = await trial_merge(repo, "x", "y")
    assert not conflicted.clean
    assert conflicted.conflicts == ["a.txt"]
    # The working tree and refs are untouched.
    assert (repo / "a.txt").read_text() == "1\n2\n3\n"
