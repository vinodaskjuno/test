from __future__ import annotations

from aidlc.orchestrator.routing import ROUTED, skipped_agents


def test_nothing_is_skipped_when_no_surface_is_declared() -> None:
    assert skipped_agents([]) == frozenset()


def test_a_backend_change_skips_ui_data_and_infra_specialists() -> None:
    skipped = skipped_agents(["backend"])
    assert {"frontend-dev", "visual-ux-validator", "e2e-ui-test", "accessibility-test", "ux-design-analyst"} <= skipped
    assert {"data-modeler", "db-migration-dev", "devops-iac", "integration-dev"} <= skipped
    assert not {"api-contract", "integration-contract-test"} & skipped


def test_a_ui_only_change_skips_the_api_and_data_designers() -> None:
    skipped = skipped_agents(["ui"])
    assert {"api-contract", "data-modeler", "db-migration-dev", "integration-contract-test"} <= skipped
    assert "frontend-dev" not in skipped


def test_an_extension_keeps_its_owner_and_vs_code_tests_but_no_web_validation() -> None:
    skipped = skipped_agents(["vsix"])
    assert not {"frontend-dev", "e2e-ui-test"} & skipped
    assert {"visual-ux-validator", "accessibility-test", "api-contract"} <= skipped


def test_every_surface_together_skips_nothing() -> None:
    assert skipped_agents(["ui", "backend", "data", "infra", "integration", "vsix"]) == frozenset()
    assert "backend-dev" not in ROUTED and "unit-test" not in ROUTED
