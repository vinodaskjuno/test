import pytest
import yaml

from aidlc.adlc_config import ConfigError, dump_config, load_config, parse_config


def test_mapping_repos_become_list_with_primary_and_branch_inheritance():
    cfg = parse_config(
        {
            "project": "shop",
            "name": "Shop",
            "stack": "nextjs-fastapi",
            "repos": {"api": {"url": "https://x/api.git", "primary": True}, "web": {"path": "../web"}},
            "merge_order": ["api", "web"],
            "integration_branch": "staging",
        }
    )
    assert [r.id for r in cfg.repos] == ["api", "web"]
    assert cfg.repos[0].primary and not cfg.repos[1].primary
    assert {r.integration_branch for r in cfg.repos} == {"staging"}


def test_first_repo_becomes_primary_when_none_marked():
    cfg = parse_config({"repos": {"app": {"path": "."}}}, project_id="p1")
    assert cfg.repos[0].primary and cfg.project_id == "p1" and cfg.merge_order == ["app"]


@pytest.mark.parametrize(
    "raw",
    [
        {"repos": {}},
        {"repos": {"a": {}}},
        {"repos": {"a": {"path": "."}}, "merge_order": ["b"]},
        {"repos": {"a": {"path": ".", "primary": True}, "b": {"path": "x", "primary": True}}},
    ],
)
def test_invalid_configs_rejected(raw):
    with pytest.raises(ConfigError):
        parse_config(raw)


def test_round_trip(tmp_path):
    original = parse_config({"project": "p", "repos": {"api": {"url": "u", "primary": True}, "web": {"url": "w"}}})
    path = tmp_path / "config.yml"
    path.write_text(dump_config(original))
    assert load_config(path) == original
    assert yaml.safe_load(path.read_text())["repos"]["api"]["primary"] is True


def test_preset_parses():
    from aidlc.settings import get_settings

    cfg = load_config(get_settings().presets_dir / "nextjs-fastapi.yml", project_id="demo")
    assert cfg.repos[0].id == "app" and cfg.repos[0].primary
