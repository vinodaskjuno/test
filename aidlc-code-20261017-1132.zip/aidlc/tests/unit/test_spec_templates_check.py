from __future__ import annotations

import pytest

from aidlc.platform.spec_templates import TEMPLATE_TYPES, check_spec, example_text, known_presets, template_text
from aidlc.platform.spec_templates.markdown import strip_guidance

PRESETS = known_presets()


def backend(**replace: str) -> str:
    text = example_text("backend")
    for old, new in replace.items():
        assert old in text, old
        text = text.replace(old, new)
    return text


def errors(text: str) -> list[str]:
    return check_spec(text, PRESETS).errors


@pytest.mark.parametrize("type_id", list(TEMPLATE_TYPES))
def test_every_example_passes_cleanly(type_id: str) -> None:
    result = check_spec(example_text(type_id), PRESETS)
    assert result.templated and result.template == type_id
    assert (result.errors, result.warnings, result.gaps) == ([], [], [])
    assert result.kind == ("bug" if type_id == "bug" else "feature")
    assert result.surfaces and result.risk_tier and result.budget_usd


@pytest.mark.parametrize("type_id", list(TEMPLATE_TYPES))
def test_a_blank_template_is_rejected_with_its_unfilled_fields(type_id: str) -> None:
    result = check_spec(template_text(type_id), PRESETS)
    assert result.templated and result.errors
    assert "the title heading (# …) is not filled in" in result.errors
    assert "Spec details: Title is not filled in" in result.errors


def test_a_free_form_spec_is_not_checked() -> None:
    result = check_spec("# Login\n\nUsers log in with email and password.\n", PRESETS)
    assert not result.templated and result.ok and result.surfaces == []


def test_the_example_tells_the_platform_what_the_run_needs() -> None:
    result = check_spec(example_text("integration"), PRESETS)
    assert result.surfaces == ["backend", "integration"]
    assert result.repos == ["storefront"] and result.project_id == "storefront"
    assert (result.risk_tier, result.budget_usd) == ("high", 45.0)
    assert result.title == "Validate shipping addresses with the AddressCheck partner API"


B4_TEXT = "Adding status_changed_at to the order response is additive; no consumer breaks. No version change."
B3_TEXT = "Unchanged: the service is reachable only from the internal network through the existing gateway."
FR4_TEXT = "Two concurrent changes of the same order end with exactly one success | Must"
SECTION_8_SLOT = "{{Affected modules and current behaviour, or N/A — new project}}"


@pytest.mark.parametrize(
    ("replace", "expected"),
    [
        ({"| Jira | SHOP-214 |": "| Jira | {{ABC-123}} |"}, "Spec details: Jira is not filled in"),
        ({"| Jira | SHOP-214 |": "| Jira | shop 214 |"}, "Spec details: Jira 'shop 214' is not an issue key"),
        ({"| Surfaces | backend, data |": "| Surfaces | backend, mobile |"}, "Surfaces must be one or more of"),
        ({"| Project | existing |": "| Project | legacy |"}, "Spec details: Project must be 'new' or 'existing'"),
        ({"| Stack preset | nextjs-fastapi |": "| Stack preset | rails |"}, "Spec details: Stack preset 'rails'"),
        (
            {"| Stack exceptions | none |": "| Stack exceptions | Redis — caching |"},
            "Spec details: stack exception 'Redis — caching' must read 'technology — reason — approver'",
        ),
        ({"| PII categories | name, email |": "| PII categories | name |", "Confidential": "Public"}, "Public data"),
        ({"| Compliance regimes | NYDFS 500 |": "| Compliance regimes | SOC 9 |"}, "compliance regime 'SOC 9'"),
        ({"| Run budget (USD) | 30 |": "| Run budget (USD) | 5000 |"}, "Run budget (USD) must be a number"),
        ({"| Risk tier | medium |": "| Risk tier | high |"}, "needs a Security approver for a high-risk change"),
        ({"| Tech lead | Ana Costa | 12 Oct 2026 |": ""}, "section 17. Approvals needs a named Tech lead"),
        ({"| AS-6 | FR-4 |": "| AS-6 | FR-1 |"}, "FR-4 (Must) has no acceptance scenario"),
        ({"| AS-3 | FR-1 |": "| AS-3 | FR-9 |"}, "AS-3 refers to unknown FR-9"),
        ({"| FR-4 |": "| FR-3 |"}, "FR-3 appears twice"),
        ({FR4_TEXT: "x | Urgent"}, "FR-4 priority must be Must, Should or Could"),
        ({"| p95 at most 100 ms |": "| |"}, "NFR-1 has no measurable target"),
        ({"### 13. Rollout and compatibility": "### Rollout"}, "section 13. Rollout and compatibility is missing"),
        ({"### D3. Rollback": "### Rollback notes"}, "section D3. Rollback is missing"),
        ({"Orders are created as pending and never change, so": "N/A — obvious. So"}, "1. Problem and outcome cannot"),
        ({B4_TEXT: "N/A"}, "section B4. Compatibility and versioning is N/A without a reason"),
        ({B3_TEXT: "N/A"}, "section B3. Authorisation cannot be N/A"),
        ({"The FastAPI service in api/:": SECTION_8_SLOT}, "section 8. Current system still contains"),
    ],
)
def test_a_broken_field_or_section_is_named_in_the_errors(replace: dict[str, str], expected: str) -> None:
    found = errors(backend(**replace))
    assert any(expected in e for e in found), found


def test_the_mode_section_must_be_filled_and_the_other_may_be_na() -> None:
    assert errors(backend(**{"The FastAPI service in api/": "N/A — new project. The FastAPI service in api/"}))
    assert not errors(backend(**{"N/A — existing project.": "Not used."}))


def test_empty_optional_sections_become_gate_a_questions() -> None:
    text = backend(**{"| Manual database edits per week | about 30 | 0 | database change log |": ""})
    result = check_spec(text, PRESETS)
    assert result.ok and result.gaps == ["7. Success metrics"]


def test_filled_sections_of_an_undeclared_surface_are_a_warning() -> None:
    result = check_spec(backend(**{"| Surfaces | backend, data |": "| Surfaces | backend |"}), PRESETS)
    assert result.ok and result.warnings == ["D-sections are filled in but 'data' is not in Surfaces"]


def test_a_declared_surface_needs_its_add_on() -> None:
    found = errors(backend(**{"| Surfaces | backend, data |": "| Surfaces | backend, data, ui |"}))
    assert "section U2. Screens is missing" in found


def test_size_limits_warn_then_reject() -> None:
    def with_frs(n: int) -> str:
        rows = "".join(f"| FR-{i} | The system does thing {i} | Should |\n" for i in range(5, 5 + n))
        return backend(**{"| FR-4 | Two concurrent": rows + "| FR-4 | Two concurrent"})

    warned = check_spec(with_frs(10), PRESETS)
    assert warned.ok and any("above the recommended 12 / 40" in w for w in warned.warnings)
    assert any("exceed the limit of 25 / 80" in e for e in errors(with_frs(30)))


def test_the_specs_own_curly_braces_are_not_template_slots() -> None:
    # the prompt-library example quotes {{customer_name}} template variables as requirement text
    assert "{{customer_name}}" in example_text("ui-only") and not errors(example_text("ui-only"))


def test_a_bug_needs_its_reproduction_and_scenarios() -> None:
    text = example_text("bug").replace("1. Point ORDERS_INVENTORY_URL", "1. {{first step}}\n\nPoint")
    assert any("section 3. Steps to reproduce still contains" in e for e in errors(text))
    no_scenarios = example_text("bug").split("### 8. Acceptance scenarios")[0] + "### 8. Acceptance scenarios\n\n"
    assert "section 8. Acceptance scenarios is empty" in errors(no_scenarios)


def test_an_unknown_template_version_is_rejected() -> None:
    found = errors(backend(**{"aidlc-spec/1 · backend": "aidlc-spec/9 · backend"}))
    assert found == ["Template 'aidlc-spec/9' is not supported; use the current template (aidlc-spec/1)"]


def test_strip_guidance_removes_guidance_and_keeps_the_text_verbatim() -> None:
    text = (
        "# T\n\n<!-- guide: fill this\nin -->\n\n### 1. Problem and outcome\n\n*Guide: from Word*\n\n"
        "Real text with {{customer_name}}.\n\n> **Guide:** quoted\n> more guidance\n\n- item\n"
    )
    assert strip_guidance(text) == "# T\n\n### 1. Problem and outcome\n\nReal text with {{customer_name}}.\n\n- item\n"
