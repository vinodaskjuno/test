from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from aidlc.platform.git import worktrees as wt
from aidlc.platform.git.cli import GitError
from aidlc.platform.git.conflict_bound import resolve_text


def sh(cwd: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-c", "user.name=T", "-c", "user.email=t@x", *args],
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


@pytest.fixture
def origin(tmp_path: Path) -> Path:
    """A bare 'remote' with one commit on main, plus a scratch working clone at tmp/dev."""
    bare = tmp_path / "origin.git"
    sh(tmp_path, "init", "--bare", "-q", "-b", "main", str(bare))
    dev = tmp_path / "dev"
    sh(tmp_path, "clone", "-q", str(bare), str(dev))
    sh(dev, "checkout", "-q", "-b", "main")
    (dev / "app.py").write_text("a = 1\n")
    sh(dev, "add", ".")
    sh(dev, "commit", "-qm", "init")
    sh(dev, "push", "-q", "origin", "main")
    return bare


def dev_commit(tmp_path: Path, branch: str, name: str, text: str) -> None:
    dev = tmp_path / "dev"
    sh(dev, "checkout", "-q", "-B", branch, f"origin/{branch}" if branch == "main" else "HEAD")
    (dev / name).write_text(text)
    sh(dev, "add", ".")
    sh(dev, "commit", "-qm", f"edit {name}")
    sh(dev, "push", "-q", "origin", branch)


async def test_clone_worktree_commit_push_diff(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    assert clone.name.endswith(".git")
    assert await wt.ensure_clone(str(origin), tmp_path / "cache") == clone  # idempotent fetch
    work = await wt.create_worktree(clone, tmp_path / "runs" / "r1", "feat/x", "origin/main")
    assert (work / "app.py").read_text() == "a = 1\n"
    assert await wt.commit_all(work, "nothing", "Bot", "bot@x") is None
    (work / "new.py").write_text("b = 2\n")
    sha = await wt.commit_all(work, "add new", "Bot", "bot@x")
    assert sha and sha == await wt.head_sha(work)
    assert sh(work, "log", "-1", "--format=%an <%ae>") == "Bot <bot@x>"
    assert await wt.changed_files(work, "origin/main") == ["new.py"]
    assert "+b = 2" in await wt.diff(work, "origin/main")
    await wt.push(work, "feat/x")
    assert sh(origin, "rev-parse", "refs/heads/feat/x") == sha
    # Re-creating the same worktree path is a no-op; a new worktree for a pushed branch resumes it.
    assert await wt.create_worktree(clone, work, "feat/x", "origin/main") == work
    sh(clone, "worktree", "remove", "--force", str(work))
    sh(clone, "branch", "-D", "feat/x")
    resumed = await wt.create_worktree(clone, tmp_path / "runs" / "r1b", "feat/x", "origin/main")
    assert await wt.head_sha(resumed) == sha


async def test_build_output_and_install_leftovers_are_never_committed(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "runs" / "r1", "feat/x", "origin/main")
    for rel in ("node_modules/pkg/index.js", "api/orders.egg-info/PKG-INFO", "next-env.d.ts", "dist/app.js"):
        (work / rel).parent.mkdir(parents=True, exist_ok=True)
        (work / rel).write_text("generated\n")
    assert await wt.commit_all(work, "build output only", "Bot", "bot@x") is None
    (work / "package-lock.json").write_text("{}\n")  # an install generated a lockfile the repo does not track
    assert await wt.exclude_untracked(work) == ["package-lock.json"]
    (work / "feature.py").write_text("x = 1\n")
    await wt.commit_all(work, "feature", "Bot", "bot@x")
    assert await wt.changed_files(work, "origin/main") == ["feature.py"]
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    excludes = (clone / "info" / "exclude").read_text()
    assert excludes.count(wt.EXCLUDE_MARKER) == 1 and excludes.count("/package-lock.json") == 1


async def test_a_retried_run_takes_the_branch_over_from_the_old_worktree(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    old = await wt.create_worktree(clone, tmp_path / "runs" / "r1", "aidlc/REQ-001-x", "origin/main")
    (old / "new.py").write_text("b = 2\n")
    sha = await wt.commit_all(old, "work", "Bot", "bot@x")
    new = await wt.create_worktree(clone, tmp_path / "runs" / "r2", "aidlc/REQ-001-x", "origin/main")
    assert await wt.head_sha(new) == sha
    assert sh(new, "branch", "--show-current") == "aidlc/REQ-001-x"
    assert sh(old, "branch", "--show-current") == ""  # detached, files untouched
    assert (old / "new.py").read_text() == "b = 2\n"


async def test_follow_remote_checks_out_the_latest_push(origin: Path, tmp_path: Path) -> None:
    dev_commit(tmp_path, "feature/local", "f.txt", "1\n")
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    first = await wt.create_worktree(clone, tmp_path / "v1", "feature/local", "origin/feature/local")
    assert (first / "f.txt").read_text() == "1\n"
    dev_commit(tmp_path, "feature/local", "f.txt", "2\n")  # the developer pushes again
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    stale = await wt.create_worktree(clone, tmp_path / "v2", "feature/local", "origin/feature/local")
    assert (stale / "f.txt").read_text() == "1\n"  # resuming keeps the local branch (a run's own work)
    fresh = await wt.create_worktree(
        clone, tmp_path / "v3", "feature/local", "origin/feature/local", follow_remote=True
    )
    assert (fresh / "f.txt").read_text() == "2\n"


async def test_push_never_forces(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "w", "feat/y", "origin/main")
    (work / "f.txt").write_text("1\n")
    await wt.commit_all(work, "one", "B", "b@x")
    await wt.push(work, "feat/y")
    sh(work, "reset", "-q", "--hard", "HEAD~1")
    (work / "g.txt").write_text("2\n")
    await wt.commit_all(work, "diverge", "B", "b@x")
    with pytest.raises(GitError):
        await wt.push(work, "feat/y")


async def test_rebase_clean_and_conflict(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "w", "feat/r", "origin/main")
    (work / "mine.py").write_text("m = 1\n")
    await wt.commit_all(work, "mine", "B", "b@x")
    dev_commit(tmp_path, "main", "other.py", "o = 1\n")
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    assert (await wt.rebase(work, "origin/main")).ok
    assert (work / "other.py").exists()

    (work / "app.py").write_text("a = 'mine'\n")
    await wt.commit_all(work, "edit app", "B", "b@x")
    dev_commit(tmp_path, "main", "app.py", "a = 'theirs'\n")
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    before = await wt.head_sha(work)
    result = await wt.rebase(work, "origin/main")
    assert not result.ok
    assert result.conflicted_files == ["app.py"]
    assert await wt.head_sha(work) == before  # aborted, branch untouched


async def test_merge_branch_conflict_gives_diff3_text(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "w", "feat/m", "origin/main")
    (work / "app.py").write_text("a = 1\nours = 1\n")
    await wt.commit_all(work, "ours", "B", "b@x")
    dev_commit(tmp_path, "main", "app.py", "a = 1\ntheirs = 1\n")
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    result = await wt.merge_branch(work, "origin/main")
    assert not result.ok
    assert result.conflicted_files == ["app.py"]
    text = result.text_by_file["app.py"]
    assert "<<<<<<<" in text and "|||||||" in text and ">>>>>>>" in text
    resolved = resolve_text(text)  # both sides appended at the same point: bounded auto-resolution applies
    assert resolved.ok, resolved.reason
    assert resolved.text == "a = 1\nours = 1\ntheirs = 1\n"
    sha = await wt.complete_merge(work, {"app.py": resolved.text})
    assert sha == await wt.head_sha(work)
    assert sh(work, "rev-list", "--parents", "-n1", "HEAD").count(" ") == 2  # a merge commit


async def test_merge_branch_clean_and_abort(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "w", "feat/c", "origin/main")
    (work / "app.py").write_text("a = 2\n")
    await wt.commit_all(work, "ours", "B", "b@x")
    dev_commit(tmp_path, "main", "readme.md", "hi\n")
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    assert (await wt.merge_branch(work, "origin/main")).ok
    assert (work / "readme.md").exists()

    (work / "readme.md").write_text("ours\n")
    await wt.commit_all(work, "ours readme", "B", "b@x")
    dev_commit(tmp_path, "main", "readme.md", "theirs\n")
    await wt.ensure_clone(str(origin), tmp_path / "cache")
    before = await wt.head_sha(work)
    assert not (await wt.merge_branch(work, "origin/main")).ok
    await wt.abort_merge(work)
    assert await wt.head_sha(work) == before


async def test_untracked_files_in_the_way_give_way_to_the_branch(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "runs" / "r1", "feat/x", "origin/main")
    side = await wt.create_worktree(clone, tmp_path / "runs" / "side", "side", "origin/main")
    (side / "web").mkdir()
    (side / "web" / "package-lock.json").write_text('{"committed": true}\n')
    await wt.commit_all(side, "lockfile", "Bot", "bot@x")
    (work / "web").mkdir()
    (work / "web" / "package-lock.json").write_text('{"generated": true}\n')  # an install made it here, untracked
    assert await wt.merge_branch(work, "side") == wt.MergeResult(ok=True)
    assert (work / "web" / "package-lock.json").read_text() == '{"committed": true}\n'


async def test_a_merge_git_refuses_reports_its_reason(origin: Path, tmp_path: Path) -> None:
    clone = await wt.ensure_clone(str(origin), tmp_path / "cache")
    work = await wt.create_worktree(clone, tmp_path / "runs" / "r1", "feat/x", "origin/main")
    side = await wt.create_worktree(clone, tmp_path / "runs" / "side", "side", "origin/main")
    (side / "app.py").write_text("a = 3\n")
    await wt.commit_all(side, "edit", "Bot", "bot@x")
    (work / "app.py").write_text("a = 2\n")  # an uncommitted local change in the way
    with pytest.raises(GitError, match="would be overwritten by merge"):
        await wt.merge_branch(work, "side")
    assert (work / "app.py").read_text() == "a = 2\n"


async def test_detect_integration_branch(origin: Path, tmp_path: Path) -> None:
    cache = tmp_path / "cache"
    assert await wt.detect_integration_branch(await wt.ensure_clone(str(origin), cache)) == "main"

    dev = tmp_path / "dev"
    sh(dev, "checkout", "-q", "-b", "staging")
    sh(dev, "push", "-q", "origin", "staging")
    assert await wt.detect_integration_branch(await wt.ensure_clone(str(origin), cache)) == "staging"

    (dev / ".adlc").mkdir()
    (dev / ".adlc" / "config.yml").write_text("project: p\nintegration_branch: develop\n")
    sh(dev, "checkout", "-q", "main")
    (dev / ".adlc").mkdir(exist_ok=True)
    (dev / ".adlc" / "config.yml").write_text("project: p\nintegration_branch: develop\n")
    sh(dev, "add", ".")
    sh(dev, "commit", "-qm", "config")
    sh(dev, "push", "-q", "origin", "main")
    assert await wt.detect_integration_branch(await wt.ensure_clone(str(origin), cache)) == "develop"
