"""The project guide (docs/guide) is current, complete, accurate against the code, CSP-safe and offline."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from html.parser import HTMLParser

import pytest
import yaml

from aidlc.platform.registry import Registry
from aidlc.settings import ROOT

GUIDE = ROOT / "docs" / "guide"
INDEX = GUIDE / "index.html"
SECTIONS = ["overview", "architecture", "agents", "setup", "run", "testing", "samples", "reference"]
DIAGRAMS = ["feature", "architecture", "multirepo", "bugfix", "local"]
WILDCARD = re.compile(r"^(\*|\$.*|\{.*\}|<.*>)$")


class Page(HTMLParser):
    """Collects what the checks need from index.html in one pass."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: set[str] = set()
        self.attrs: list[tuple[str, str, str]] = []  # (tag, attribute, value)
        self.scripts: list[tuple[dict[str, str | None], str]] = []
        self.style_tags = 0
        self.code_texts: list[str] = []  # text of <pre> and <code> elements
        self.text: list[str] = []
        self._script: dict[str, str | None] | None = None
        self._script_body: list[str] = []
        self._code_depth = 0
        self._code_buf: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        for name, value in attrs:
            if name == "id" and value:
                self.ids.add(value)
            self.attrs.append((tag, name, value or ""))
        if tag == "script":
            self._script, self._script_body = dict(attrs), []
        elif tag == "style":
            self.style_tags += 1
        elif tag in ("pre", "code"):
            if self._code_depth == 0:
                self._code_buf = []
            self._code_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._script is not None:
            self.scripts.append((self._script, "".join(self._script_body)))
            self._script = None
        elif tag in ("pre", "code") and self._code_depth:
            self._code_depth -= 1
            if self._code_depth == 0:
                self.code_texts.append("".join(self._code_buf))

    def handle_data(self, data: str) -> None:
        self.text.append(data)
        if self._script is not None:
            self._script_body.append(data)
        if self._code_depth:
            self._code_buf.append(data)


@pytest.fixture(scope="module")
def html() -> str:
    return INDEX.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def page(html: str) -> Page:
    parsed = Page()
    parsed.feed(html)
    return parsed


@pytest.mark.skipif(shutil.which("node") is None, reason="node is not installed")
def test_build_check_reports_no_drift() -> None:
    proc = subprocess.run(
        ["node", str(GUIDE / "build.mjs"), "--check"], cwd=ROOT, capture_output=True, text=True, timeout=300
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr


def test_all_sections_and_diagrams_are_present(html: str, page: Page) -> None:
    for section in SECTIONS:
        assert re.search(rf'<section class="gsec[^"]*" id="{section}"', html), section
    for diagram in DIAGRAMS:
        match = re.search(rf'<figure class="flow" id="flow-{diagram}".*?</figure>', html, re.S)
        assert match, diagram
        figure = match.group(0)
        assert f'<title id="flow-{diagram}-title">' in figure and f'<desc id="flow-{diagram}-desc">' in figure
        for control in ('data-act="play"', 'data-act="step"', 'data-act="replay"'):
            assert control in figure, (diagram, control)
        assert '<ol class="flow-steps">' in figure  # the text alternative
        nodes = re.findall(r'<g class="fn[^"]*" data-node="[^"]+"[^>]*>', figure)
        assert nodes and all('tabindex="0"' in n and "aria-label=" in n for n in nodes), diagram
    assert 'data-act="fail"' in html and 'data-fail-max="5"' in html


def _subcommands() -> tuple[set[str], set[str]]:
    import argparse
    import importlib.util
    import sys

    if importlib.util.find_spec("aidlc_sdk") is None:  # the CLI imports the SDK; fall back to its in-repo sources
        sys.path.insert(0, str(ROOT / "clients" / "sdk-py" / "src"))
    from aidlc.cli.main import build_parser

    def names(parser: argparse.ArgumentParser) -> dict[str, argparse.ArgumentParser]:
        action = next(a for a in parser._actions if isinstance(a, argparse._SubParsersAction))
        return dict(action.choices)

    top = names(build_parser())
    return set(top), set(names(top["local"]))


# `aidlc <command> [<action>]` at the start of a line (or after `run:` in YAML), or chained after ; && || $(
ARGS = r"aidlc[ \t]+([a-z][\w-]*)(?:[ \t]+([a-z][\w-]*))?"
COMMAND_START = re.compile(r"(?:^|\n)[ \t]*(?:[;&|(]+[ \t]*|run:[ \t]*)?" + ARGS)
COMMAND_CHAINED = re.compile(r"(?:;|&&|\|\||\$\()[ \t]*" + ARGS)


def test_every_aidlc_command_in_the_guide_exists(page: Page) -> None:
    commands, local_actions = _subcommands()
    used: list[tuple[str, str | None]] = []
    for text in page.code_texts:
        for regex in (COMMAND_START, COMMAND_CHAINED):
            used += [(m.group(1), m.group(2)) for m in regex.finditer(text)]
    assert len(used) > 30, "expected many CLI examples"
    unknown = [c for c, _ in used if c not in commands]
    assert not unknown, f"aidlc subcommands not in `aidlc --help`: {sorted(set(unknown))}"
    bad_local = [a for c, a in used if c == "local" and a is not None and a not in local_actions]
    assert not bad_local, f"unknown `aidlc local` actions: {sorted(set(map(str, bad_local)))}"
    assert {c for c, _ in used} >= commands - {"logout"}, "every CLI command should be shown at least once"


def _api_paths(text: str) -> set[str]:
    paths = set(re.findall(r"/api/v1(/[^\s\"'<>`)\],]*)", text))
    paths |= set(re.findall(r"\$API(/[^\s\"'<>`)\],]*)", text))
    cleaned = set()
    for raw in paths:
        path = raw.split("?")[0].rstrip(".:;")
        if path and path != "/":
            cleaned.add("/api/v1" + path)
    return cleaned


def _matches(doc_path: str, spec_path: str) -> bool:
    a, b = doc_path.strip("/").split("/"), spec_path.strip("/").split("/")
    if len(a) != len(b):
        return False
    return all(
        x == y or WILDCARD.match(x) or (y.startswith("{") and y.endswith("}")) for x, y in zip(a, b, strict=True)
    )


def test_every_api_path_in_the_guide_exists(page: Page) -> None:
    spec = json.loads((ROOT / "clients" / "openapi.json").read_text(encoding="utf-8"))
    known = list(spec["paths"])
    mentioned = _api_paths("\n".join(page.text))
    assert len(mentioned) > 25
    unknown = sorted(p for p in mentioned if not any(_matches(p, k) for k in known))
    assert not unknown, f"API paths not in clients/openapi.json: {unknown}"
    documented = {k for k in known if any(_matches(p, k) for p in mentioned)}
    assert documented == {k for k in known if k.startswith("/api/v1/")}, "every endpoint appears in the reference"


def test_all_agents_are_in_the_catalog(page: Page) -> None:
    registry = Registry(ROOT / "agents")
    assert len(registry) == 65
    missing = [a.id for a in registry.all() if f"agent-{a.id}" not in page.ids]
    assert not missing


def test_every_sample_spec_is_linked_and_shipped(page: Page) -> None:
    links = {v for tag, name, v in page.attrs if tag == "a" and name == "href" and v.startswith("samples/")}
    assert links
    for link in links:
        shipped = GUIDE / link
        assert shipped.is_file(), link
        assert shipped.read_bytes() == (ROOT / "evals" / "specs" / link.removeprefix("samples/")).read_bytes()
    for expected in sorted((ROOT / "evals" / "specs").rglob("*.yaml")):
        if not (expected.name == "expected.yaml" or expected.name.endswith(".expected.yaml")):
            continue
        data = yaml.safe_load(expected.read_text(encoding="utf-8"))
        rel = expected.parent.relative_to(ROOT / "evals" / "specs")
        for spec_file in data["spec_files"]:
            assert f"samples/{(rel / spec_file).as_posix()}" in links, f"{rel / spec_file} is not linked"
        assert f"sample-{data['id']}" in page.ids


def test_no_inline_scripts_or_styles(page: Page, html: str) -> None:
    assert page.scripts, "the guide loads its scripts"
    for attrs, body in page.scripts:
        assert attrs.get("src"), "inline <script> without src"
        assert not body.strip(), "inline <script> body"
    assert page.style_tags == 0
    assert not [(tag, name) for tag, name, _ in page.attrs if name == "style"]
    assert not [(tag, name) for tag, name, _ in page.attrs if name.startswith("on")], "inline event handlers"
    assert "javascript:" not in html


def test_no_external_assets(page: Page) -> None:
    external = re.compile(r"^(https?:)?//", re.I)
    asset_attrs = {
        ("script", "src"),
        ("img", "src"),
        ("img", "srcset"),
        ("link", "href"),
        ("source", "src"),
        ("source", "srcset"),
        ("iframe", "src"),
        ("use", "href"),
        ("use", "xlink:href"),
        ("image", "href"),
    }
    bad = [(t, n, v) for t, n, v in page.attrs if (t, n) in asset_attrs and external.match(v)]
    assert not bad, bad
    for css in [GUIDE / "guide.css", *sorted((GUIDE / "assets").rglob("*.css"))]:
        urls = re.findall(r"url\(\s*['\"]?([^'\")]+)", css.read_text(encoding="utf-8"))
        assert not [u for u in urls if external.match(u)], css
    for asset in [v for t, n, v in page.attrs if (t, n) in asset_attrs and not v.startswith("data:")]:
        assert (GUIDE / asset.split("#")[0]).is_file(), asset


def test_guide_documents_exit_codes_and_outcomes(html: str) -> None:
    from aidlc.names import EXIT_CODES

    for outcome, code in EXIT_CODES.items():
        row = rf'<code>{code}</code></td><td>outcome <span class="chip[^"]*">{re.escape(outcome)}</span>'
        assert re.search(row, html), outcome


def test_guide_describes_the_current_runtime_stack(html: str) -> None:
    removed = sorted({m.lower() for m in re.findall(r"langfuse|grafana|clamav|clamd", html, re.I)})
    assert not removed, f"the guide still mentions removed services: {removed}"
    for name in ("Bedrock", "Fiddler", "CrowdStrike"):
        assert name in html, name
