from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any

import httpx
import pytest
import respx

from aidlc.contracts import RunEvent
from aidlc.platform import factory, tenancy
from aidlc.platform.db import Project, Run, User, session_scope
from aidlc.platform.notifications import (
    EmailSender,
    MultiChannelNotifier,
    SlackSender,
    TeamsSender,
    classify,
    dispatch,
)
from aidlc.settings import Settings, get_settings

SLACK = "https://hooks.slack.test/T1"
TEAMS = "https://teams.test/hook"


class FakeSMTP:
    sent: list[Any] = []
    tls: list[bool] = []

    def __init__(self, host: str, port: int, timeout: int) -> None:
        self.host, self.port = host, port

    def __enter__(self) -> FakeSMTP:
        return self

    def __exit__(self, *exc: object) -> None:
        return None

    def starttls(self) -> None:
        FakeSMTP.tls.append(True)

    def send_message(self, msg: Any) -> None:
        FakeSMTP.sent.append(msg)


@pytest.fixture(autouse=True)
def fake_smtp(monkeypatch: pytest.MonkeyPatch) -> type[FakeSMTP]:
    FakeSMTP.sent, FakeSMTP.tls = [], []
    monkeypatch.setattr("aidlc.platform.notifications.smtplib.SMTP", FakeSMTP)
    return FakeSMTP


class RecordingNotifier:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    async def send(self, *, to: Sequence[str], subject: str, body: str, link: str | None = None) -> None:
        self.calls.append({"to": list(to), "subject": subject, "body": body, "link": link})


@pytest.fixture
def project() -> str:
    org = tenancy.create_org("Acme")
    team = tenancy.create_team(org.id, "Payments")
    tenancy.create_project(team.id, "Shop", project_id="shop")
    tenancy.add_member(team.id, "dev@acme.io", "contributor")
    tenancy.add_member(team.id, "viewer@acme.io", "viewer")
    tenancy.add_member(team.id, "muted@acme.io", "maintainer")
    with session_scope() as s:
        s.get(User, "muted@acme.io").preferences = {  # type: ignore[union-attr]
            "notifications": {"events": ["pr_ready", "failed", "escalation", "ci_failing", "audit_finished"]}
        }
        s.add(
            Run(
                id="run-1",
                project_id="shop",
                kind="feature",
                title="CSV export",
                workflow_id="wf",
                created_by="dev@acme.io",
            )
        )
        s.add(Run(id="audit-1", project_id="shop", kind="health_audit", workflow_id="wf2", created_by="dev@acme.io"))
    return "shop"


async def test_email_sender_uses_starttls_on_587(fake_smtp: type[FakeSMTP]) -> None:
    await EmailSender("smtp.test", 587, "aidlc@acme.io").send(["a@acme.io", "b@acme.io"], "Hi", "Body")
    msg = fake_smtp.sent[0]
    assert msg["To"] == "a@acme.io, b@acme.io" and msg["Subject"] == "Hi" and msg["From"] == "aidlc@acme.io"
    assert fake_smtp.tls == [True]


@respx.mock
async def test_slack_and_teams_payloads() -> None:
    slack = respx.post(SLACK).mock(return_value=httpx.Response(200))
    teams = respx.post(TEAMS).mock(return_value=httpx.Response(202))
    await SlackSender(SLACK).send("Subj", "Body", "http://x/runs/1")
    await TeamsSender(TEAMS).send("Subj", "Body", "http://x/runs/1")
    assert json.loads(slack.calls[0].request.content) == {"text": "*Subj*\nBody\n<http://x/runs/1|Open in AIDLC>"}
    card = json.loads(teams.calls[0].request.content)["attachments"][0]["content"]
    assert card["body"][0]["text"] == "Subj"
    assert card["actions"][0]["url"] == "http://x/runs/1"


@respx.mock
async def test_multichannel_isolates_failures(fake_smtp: type[FakeSMTP]) -> None:
    respx.post(SLACK).mock(return_value=httpx.Response(500))
    teams = respx.post(TEAMS).mock(return_value=httpx.Response(200))
    settings = Settings(smtp_host="smtp.test", smtp_port=25, slack_webhook_url=SLACK, teams_webhook_url=TEAMS)
    notifier = MultiChannelNotifier.from_settings(settings)
    await notifier.send(to=["a@acme.io"], subject="S", body="B", link="L")
    assert teams.called
    assert fake_smtp.sent[0].get_content().strip() == "B\n\nL"
    assert fake_smtp.tls == []


def test_from_settings_without_channels() -> None:
    notifier = MultiChannelNotifier.from_settings(Settings())
    assert (notifier.email, notifier.slack, notifier.teams) == (None, None, None)


def test_for_project_overrides() -> None:
    base = MultiChannelNotifier(email=EmailSender("h", 25, "f"), slack=SlackSender(SLACK), teams=TeamsSender(TEAMS))
    scoped = base.for_project(["slack"], slack_url="https://hooks.slack.test/P")
    assert scoped.email is None and scoped.teams is None
    assert scoped.slack is not None and scoped.slack.webhook_url == "https://hooks.slack.test/P"
    fallback = base.for_project(["email", "teams"])
    assert fallback.email is base.email and fallback.teams is base.teams and fallback.slack is None


@pytest.mark.parametrize(
    ("etype", "data", "run_kind", "expected"),
    [
        ("question", {"questions": []}, "feature", "gate_waiting"),
        ("escalation", {"escalation": {"reason": "loop_cap"}}, "feature", "escalation"),
        ("escalation", {"reason": "ci_failing"}, "feature", "ci_failing"),
        ("pr", {"ready": True}, "feature", "pr_ready"),
        ("pr", {"ready": False}, "feature", None),
        ("outcome", {"outcome": "failed"}, "feature", "failed"),
        ("outcome", {"outcome": "blocked"}, "bugfix", "failed"),
        ("outcome", {"outcome": "pr-ready"}, "feature", None),
        ("outcome", {"outcome": "pr-ready"}, "health_audit", "audit_finished"),
        ("log", {}, "feature", None),
    ],
)
def test_classify(etype: str, data: dict[str, Any], run_kind: str, expected: str | None) -> None:
    assert classify(RunEvent(run_id="r", type=etype, data=data), run_kind) == expected  # type: ignore[arg-type]


async def test_dispatch_question_goes_to_contributors_with_inbox_link(
    project: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("AIDLC_PUBLIC_BASE_URL", "https://aidlc.acme.io/")
    get_settings.cache_clear()
    rec = RecordingNotifier()
    factory.set_override("notifier", rec)
    event = RunEvent(
        run_id="run-1",
        type="question",
        data={"questions": [{"id": "Q-1", "text": "Which currency?"}, {"id": "Q-2", "text": "Max rows?"}]},
    )
    sent = await dispatch(event, project)
    assert sent is not None and sent.kind == "gate_waiting"
    assert rec.calls == [
        {
            "to": ["dev@acme.io"],  # viewer excluded (not actionable), muted user opted out
            "subject": "[AIDLC] Gate A questions waiting: CSV export",
            "body": "2 question(s) need an answer:\n- Which currency?\n- Max rows?",
            "link": "https://aidlc.acme.io/inbox?project_id=shop",
        }
    ]


async def test_dispatch_pr_ready_and_audit_link_to_run(project: str) -> None:
    rec = RecordingNotifier()
    factory.set_override("notifier", rec)
    await dispatch(
        RunEvent(
            run_id="run-1",
            type="pr",
            data={"ready": True, "prs": [{"url": "https://gh/pr/1"}], "preview_url": "https://pr-api-1.preview"},
        ),
        project,
    )
    assert rec.calls[0]["link"] == "http://localhost:3000/runs/run-1"
    assert rec.calls[0]["to"] == ["dev@acme.io", "muted@acme.io", "viewer@acme.io"]
    assert rec.calls[0]["body"] == "- https://gh/pr/1\nPreview: https://pr-api-1.preview"
    await dispatch(
        RunEvent(run_id="audit-1", type="outcome", message="12 findings", data={"outcome": "pr-ready"}), project
    )
    assert rec.calls[1]["subject"] == "[AIDLC] Health audit finished: audit-1"


async def test_dispatch_respects_project_event_filter_and_ignores_others(project: str) -> None:
    rec = RecordingNotifier()
    factory.set_override("notifier", rec)
    with session_scope() as s:
        s.get(Project, project).notification_channels = {"events": ["failed"]}  # type: ignore[union-attr]
    assert await dispatch(RunEvent(run_id="run-1", type="question", data={}), project) is None
    assert await dispatch(RunEvent(run_id="run-1", type="log"), project) is None
    assert await dispatch(RunEvent(run_id="missing", type="question"), project) is None
    sent = await dispatch(
        RunEvent(run_id="run-1", type="outcome", message="tests broke", data={"outcome": "failed"}), project
    )
    assert sent is not None and sent.subject == "[AIDLC] Run failed: CSV export"
    assert len(rec.calls) == 1


@respx.mock
async def test_dispatch_uses_project_slack_webhook(project: str, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_SLACK_WEBHOOK_URL", SLACK)
    get_settings.cache_clear()
    project_hook = respx.post("https://hooks.slack.test/PROJECT").mock(return_value=httpx.Response(200))
    global_hook = respx.post(SLACK).mock(return_value=httpx.Response(200))
    with session_scope() as s:
        s.get(Project, project).integrations = {"slack": {"webhook_url": "https://hooks.slack.test/PROJECT"}}  # type: ignore[union-attr]
    await dispatch(
        RunEvent(run_id="run-1", type="escalation", data={"escalation": {"reason": "budget", "detail": "over $50"}}),
        project,
    )
    assert project_hook.called and not global_hook.called
    assert "Escalation (budget): CSV export" in json.loads(project_hook.calls[0].request.content)["text"]


def _prefs(**by_user: dict[str, Any]) -> None:
    with session_scope() as s:
        for user_id, notifications in by_user.items():
            s.get(User, user_id).preferences = {"theme": "dark", "notifications": notifications}  # type: ignore[union-attr]


async def test_user_preferences_choose_channels_events_and_muted_projects(project: str) -> None:
    rec = RecordingNotifier()
    factory.set_override("notifier", rec)
    _prefs(
        **{
            "dev@acme.io": {"channels": ["slack", "in_app"]},  # no email
            "viewer@acme.io": {"channels": ["email"], "events": ["failed"]},  # not pr_ready
            "muted@acme.io": {"muted_projects": ["shop"]},
        }
    )
    pr_ready = RunEvent(run_id="run-1", type="pr", data={"ready": True, "prs": [{"url": "https://gh/pr/1"}]})
    sent = await dispatch(pr_ready, project)
    assert sent is not None and sent.recipients == [] and sent.channels == ["slack"]
    assert rec.calls[0]["to"] == []
    failed = await dispatch(RunEvent(run_id="run-1", type="outcome", data={"outcome": "blocked"}), project)
    assert failed is not None and failed.recipients == ["viewer@acme.io"] and failed.channels == ["email", "slack"]
    _prefs(**{"dev@acme.io": {"channels": []}, "viewer@acme.io": {"channels": []}})
    quiet = await dispatch(RunEvent(run_id="run-1", type="outcome", data={"outcome": "failed"}), project)
    assert quiet is not None and quiet.channels == [] and len(rec.calls) == 2  # nobody wants it: nothing sent


@respx.mock
async def test_project_integrations_route_email_slack_and_teams(
    project: str, monkeypatch: pytest.MonkeyPatch, fake_smtp: type[FakeSMTP]
) -> None:
    monkeypatch.setenv("AIDLC_SMTP_HOST", "smtp.test")
    monkeypatch.setenv("AIDLC_SMTP_PORT", "25")
    monkeypatch.setenv("AIDLC_TEAMS_WEBHOOK_URL", TEAMS)
    get_settings.cache_clear()
    slack = respx.post("https://hooks.slack.test/SHOP").mock(return_value=httpx.Response(200))
    teams_project = respx.post("https://teams.test/SHOP").mock(return_value=httpx.Response(200))
    teams_global = respx.post(TEAMS).mock(return_value=httpx.Response(200))
    with session_scope() as s:
        shop = s.get(Project, project)
        assert shop is not None
        shop.integrations = {
            "slack": {"webhook_url": "https://hooks.slack.test/SHOP"},
            "teams": {"webhook_url": "https://teams.test/SHOP"},
            "email": {"recipients": ["release@acme.io", "dev@acme.io"]},
        }
        shop.notification_channels = {"teams": False}
    event = RunEvent(run_id="run-1", type="escalation", data={"reason": "conflict", "detail": "api:app/main.py"})
    sent = await dispatch(event, project)
    assert sent is not None and sent.kind == "escalation" and sent.channels == ["email", "slack"]
    assert sent.recipients == ["dev@acme.io", "muted@acme.io", "release@acme.io"]
    assert slack.called and not teams_project.called and not teams_global.called
    assert fake_smtp.sent[0]["To"] == "dev@acme.io, muted@acme.io, release@acme.io"
    assert "Escalation (conflict): CSV export" in json.loads(slack.calls[0].request.content)["text"]
