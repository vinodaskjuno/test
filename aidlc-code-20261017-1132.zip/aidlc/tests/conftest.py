"""Shared test setup: every test session gets its own SQLite DB, workspace and artifact dirs."""

from __future__ import annotations

import os
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def _isolated_platform(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    from aidlc.platform import db, factory
    from aidlc.platform.security.malware import DisabledScanner
    from aidlc.settings import get_settings

    monkeypatch.setenv("AIDLC_DATABASE_URL", f"sqlite:///{tmp_path / 'aidlc.db'}")
    monkeypatch.setenv("AIDLC_WORKSPACE_DIR", str(tmp_path / "workspaces"))
    monkeypatch.setenv("AIDLC_ARTIFACT_DIR", str(tmp_path / "artifacts"))
    for key in [
        k
        for k in os.environ
        if k.startswith("AIDLC_") and k not in {"AIDLC_DATABASE_URL", "AIDLC_WORKSPACE_DIR", "AIDLC_ARTIFACT_DIR"}
    ]:
        monkeypatch.delenv(key, raising=False)
    # An empty AWS credential chain (no shared files, env keys or instance metadata): Bedrock credential checks are
    # deterministic and never reach the network. Tests that need credentials set AWS_ACCESS_KEY_ID themselves.
    for key in [k for k in os.environ if k.startswith("AWS_")]:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("AWS_SHARED_CREDENTIALS_FILE", str(tmp_path / "aws" / "credentials"))
    monkeypatch.setenv("AWS_CONFIG_FILE", str(tmp_path / "aws" / "config"))
    monkeypatch.setenv("AWS_EC2_METADATA_DISABLED", "true")
    get_settings.cache_clear()
    db.get_engine.cache_clear()
    factory.clear_overrides()
    # No CrowdStrike tenant in tests: uploads skip the external scan (the EICAR check still runs). Scanner tests
    # install their own stub or clear this override.
    factory.set_override("malware_scanner", DisabledScanner())
    yield
    factory.clear_overrides()
    get_settings.cache_clear()
    db.get_engine.cache_clear()
