"""One REQ over the ``api`` and ``web`` repos: two cross-linked PRs that state the merge order api -> web."""

from __future__ import annotations

import subprocess
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager

import pytest

from aidlc.platform import db
from tests.e2e.conftest import SPECS
from tests.e2e.harness import Stack
from tests.e2e.orders_platform import OrderNotesScript

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]


def ls_tree(remote: str, branch: str) -> list[str]:
    out = subprocess.run(["git", "ls-tree", "-r", "--name-only", branch], cwd=remote, capture_output=True, text=True)
    return out.stdout.split()


async def test_order_notes_spans_api_and_web(stack_for: Callable[..., AbstractAsyncContextManager[Stack]]) -> None:
    async with stack_for(OrderNotesScript()) as stack:
        repos = [
            {"id": "api", "url": stack.remote("multi-api"), "primary": True},
            {"id": "web", "url": stack.remote("multi-web")},
            {"id": "infra", "url": stack.remote("multi-infra")},
        ]
        await stack.create_project("orders-platform", repos, merge_order=["infra", "api", "web"])
        run_id = (await stack.upload("orders-platform", SPECS / "brownfield-multi" / "order-notes.md"))["run"]["id"]

        view = await stack.wait_run(run_id, lambda v: v["state"]["stage"] == "gate_b", "both PRs ready")
        assert view["state"]["outcome"] == "pr-ready"
        prs = {p["repo"]: p for p in view["prs"]}
        assert set(prs) == {"api", "web"}  # infra is untouched: no worktree changes, no PR
        assert all(not p["draft"] for p in prs.values())

        with db.session_scope() as session:
            bodies = {
                repo: session.query(db.LocalPR)
                .filter_by(repo_url=stack.remote(f"multi-{repo}"), number=pr["number"])
                .one()
                for repo, pr in prs.items()
            }
            heads = {repo: row.head for repo, row in bodies.items()}
            bodies = {repo: row.body for repo, row in bodies.items()}
        assert heads["api"] == heads["web"]  # one branch name across the repo set
        for repo, other in (("api", "web"), ("web", "api")):
            assert f"## Related PRs\n- {other}: {prs[other]['url']}" in bodies[repo]
            assert "## Merge order\n1. api\n2. web" in bodies[repo]

        branch = heads["api"]
        api_files, web_files = ls_tree(stack.remote("multi-api"), branch), ls_tree(stack.remote("multi-web"), branch)
        assert "tests/test_notes.py" in api_files and any(f.startswith(".adlc/specs/REQ-001-") for f in api_files)
        assert "tests/notes.test.mjs" in web_files and not any(f.startswith(".adlc/specs/") for f in web_files)
        assert not any(f.startswith("test-results/") for f in api_files + web_files)  # each repo ran its own tests

        rows = {r["ac_id"]: r for r in view["traceability"]}
        assert all(r["passed"] and r["tests"] for r in rows.values()), rows
        assert any("test_ac_3_patch_trims_and_persists" in t for t in rows["AC-3"]["tests"])
        assert any("AC-12 Order type mirrors the contract" in t for t in rows["AC-12"]["tests"])
        assert {t["repo"] for t in view["tests"]} == {"api", "web"}

        [gate_b] = await stack.inbox("orders-platform", "gate_b")
        assert sorted(p["repo"] for p in gate_b["payload"]["prs"]) == ["api", "web"]

        await stack.merge_pr(prs["api"])
        await stack.wait_run(run_id, lambda v: {p["repo"]: p["state"] for p in v["prs"]}["api"] == "merged", "api")
        assert (await stack.run_view(run_id))["state"]["stage"] == "gate_b"  # still waiting for web
        await stack.merge_pr(prs["web"])
        done = await stack.wait_run(run_id, lambda v: v["state"]["stage"] == "done", "run finished")
        assert done["state"]["outcome"] == "pr-ready"
        assert {p["state"] for p in done["prs"]} == {"merged"}
