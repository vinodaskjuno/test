"""The end-to-end stack: a real Temporal dev server, the production worker with every real activity, the real API
over SQLite, LocalForge remotes, the LocalExecutor and a local webhook receiver. Only the agent backend is scripted.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import threading
import time
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import httpx
from temporalio.testing import WorkflowEnvironment

from aidlc.api.main import create_app
from aidlc.api.ratelimit import RateLimiter
from aidlc.api.temporal import RealTemporalGateway
from aidlc.orchestrator.worker import build_worker
from aidlc.orchestrator.workflows import DATA_CONVERTER
from aidlc.platform import db, events, factory
from aidlc.settings import get_settings
from tests.e2e.scripted import ScriptedAgentBackend

API = "/api/v1"
ADMIN = "lead@acme.test"
MAINTAINER = "maint@acme.test"
CONTRIBUTOR = "dev@acme.test"
VIEWER = "viewer@acme.test"
WEBHOOK_SECRET = "e2e-webhook-secret-0123456789"


def bearer(email: str) -> dict[str, str]:
    return {"Authorization": f"Bearer dev:{email}"}


# ---------- recorders ----------


@dataclass
class SentNotification:
    to: list[str]
    subject: str
    body: str
    link: str | None


@dataclass
class RecordingNotifier:
    sent: list[SentNotification] = field(default_factory=list)

    async def send(self, *, to: Any, subject: str, body: str, link: str | None = None) -> None:
        self.sent.append(SentNotification(list(to), subject, body, link))

    def subjects(self) -> list[str]:
        return [n.subject for n in self.sent]


@dataclass
class Delivery:
    headers: dict[str, str]
    body: bytes

    @property
    def json(self) -> dict[str, Any]:
        return json.loads(self.body)


class WebhookReceiver:
    """A real HTTP endpoint on 127.0.0.1 recording every POST (outbound webhook deliveries)."""

    def __init__(self) -> None:
        self.deliveries: list[Delivery] = []
        receiver = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self) -> None:
                length = int(self.headers.get("Content-Length") or 0)
                receiver.deliveries.append(Delivery(dict(self.headers.items()), self.rfile.read(length)))
                self.send_response(204)
                self.end_headers()

            def log_message(self, *args: Any) -> None:
                return

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)

    @property
    def url(self) -> str:
        host, port = self._server.server_address[:2]
        return f"http://{host}:{port}/hooks"

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()

    def events(self) -> list[str]:
        return [d.json["event"] for d in self.deliveries]


# ---------- the stack ----------


@dataclass
class Stack:
    env: WorkflowEnvironment
    api: httpx.AsyncClient
    backend: ScriptedAgentBackend
    notifier: RecordingNotifier
    receiver: WebhookReceiver
    samples: Path
    team_id: str = ""

    # ----- HTTP helpers -----

    async def call(self, method: str, path: str, *, user: str = CONTRIBUTOR, expect: int | None = None, **kw: Any):
        response = await self.api.request(
            method, f"{API}{path}", headers={**bearer(user), **kw.pop("headers", {})}, **kw
        )
        if expect is not None:
            assert response.status_code == expect, f"{method} {path}: {response.status_code} {response.text}"
        return response

    async def get(self, path: str, **kw: Any) -> Any:
        return (await self.call("GET", path, expect=200, **kw)).json()

    async def post(self, path: str, body: Any = None, *, expect: int = 201, **kw: Any) -> Any:
        return (await self.call("POST", path, json=body, expect=expect, **kw)).json()

    # ----- tenancy -----

    async def setup_org(self) -> str:
        """Org (first sign-in makes the lead its admin), one team with a maintainer, contributor and viewer."""
        session = await self.get("/session", user=ADMIN)
        assert session["user"]["is_admin"] is True
        team = await self.post("/teams", {"name": "orders"}, user=ADMIN)
        members = [
            {"user_id": MAINTAINER, "role": "maintainer"},
            {"user_id": CONTRIBUTOR, "role": "contributor"},
            {"user_id": VIEWER, "role": "viewer"},
        ]
        await self.call("PUT", f"/teams/{team['id']}/members", json={"members": members}, user=ADMIN, expect=200)
        self.team_id = team["id"]
        return team["id"]

    async def create_project(
        self, project_id: str, repos: list[dict[str, Any]], *, merge_order: list[str] | None = None
    ) -> dict[str, Any]:
        if not self.team_id:
            await self.setup_org()
        config: dict[str, Any] = {"repos": repos}
        if merge_order:
            config["merge_order"] = merge_order
        project = await self.post(
            "/projects",
            {
                "name": project_id.replace("-", " ").title(),
                "id": project_id,
                "team_id": self.team_id,
                "config": config,
                # The sample repos carry no coverage tooling; every other gate keeps the preset default.
                "gates": {"coverage_min_pct": 0},
                "notification_channels": {"email": True},
            },
            user=MAINTAINER,
        )
        hook = await self.post(
            f"/projects/{project_id}/webhooks",
            {
                "url": self.receiver.url,
                "events": ["run.gate_waiting", "run.pr_ready", "run.failed", "run.completed"],
                "secret": WEBHOOK_SECRET,
            },
            user=MAINTAINER,
        )
        assert hook["secret"] == WEBHOOK_SECRET
        return project

    def remote(self, name: str) -> str:
        """Bare origin of a sample repo (``sample-fastapi-nextjs``, ``multi-api``, ...): its LocalForge URL."""
        return str(self.samples / "remotes" / f"{name}.git")

    # ----- runs -----

    async def upload(self, project_id: str, spec: Path, *, kind: str = "feature") -> dict[str, Any]:
        files = [("files", (spec.name, spec.read_bytes(), "text/markdown"))]
        response = await self.call(
            "POST", f"/projects/{project_id}/specs", files=files, data={"kind": kind}, expect=201
        )
        return response.json()

    async def run_view(self, run_id: str, user: str = VIEWER) -> dict[str, Any]:
        return await self.get(f"/runs/{run_id}", user=user)

    async def wait_for(
        self, what: str, check: Callable[[], Any], *, timeout: float = 180.0, interval: float = 0.25
    ) -> Any:
        """Poll ``check`` (sync or async) until it returns something truthy; the worker runs meanwhile."""
        deadline = time.monotonic() + timeout
        while True:
            value = check()
            if asyncio.iscoroutine(value):
                value = await value
            if value:
                return value
            if time.monotonic() > deadline:
                raise AssertionError(f"timed out waiting for {what}")
            await asyncio.sleep(interval)

    async def wait_run(
        self,
        run_id: str,
        predicate: Callable[[dict[str, Any]], bool],
        what: str,
        *,
        expect_escalation: bool = False,
        **kw: Any,
    ):
        """Poll the RunView until ``predicate``; fail fast on a failed run or an unexpected open escalation."""

        async def check() -> dict[str, Any] | None:
            view = await self.run_view(run_id)
            if predicate(view):
                return view
            state = view["state"]
            if state.get("outcome") == "failed":
                raise AssertionError(f"run {run_id} failed while waiting for {what}: {state.get('summary')}")
            open_escalations = [e for e in state.get("escalations", []) if e.get("decision") is None]
            if open_escalations and not expect_escalation:
                raise AssertionError(f"run {run_id} escalated while waiting for {what}: {open_escalations}")
            return None

        return await self.wait_for(what, check, **kw)

    async def inbox(self, project_id: str, kind: str | None = None, user: str = CONTRIBUTOR) -> list[dict]:
        items = await self.get(f"/inbox?project_id={project_id}", user=user)
        return [i for i in items if kind is None or i["kind"] == kind]

    async def wait_inbox(self, project_id: str, kind: str, run_id: str, *, count: int = 1) -> list[dict]:
        async def check() -> list[dict] | None:
            items = [i for i in await self.inbox(project_id, kind) if i["run_id"] == run_id]
            return items if len(items) >= count else None

        return await self.wait_for(f"{count} open {kind} inbox item(s) for {run_id}", check)

    async def github_hook(self, event: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload).encode()
        signature = "sha256=" + hmac.new(get_settings().webhook_secret.encode(), body, hashlib.sha256).hexdigest()
        response = await self.api.post(
            f"{API}/hooks/github",
            content=body,
            headers={"X-GitHub-Event": event, "X-Hub-Signature-256": signature, "Content-Type": "application/json"},
        )
        assert response.status_code == 200, response.text
        return response.json()

    async def merge_pr(self, pr: dict[str, Any]) -> dict[str, Any]:
        """What GitHub sends when a PR is merged: a signed ``pull_request`` ``closed`` event with ``merged``."""
        result = await self.github_hook(
            "pull_request",
            {
                "action": "closed",
                "pull_request": {"number": pr["number"], "html_url": pr["url"], "merged": True},
                "repository": {"full_name": f"local/{pr['repo']}"},
                "sender": {"login": "reviewer"},
            },
        )
        assert result["accepted"] is True, result
        return result

    async def sse(self, run_id: str, last_event_id: int | None = None) -> list[dict[str, Any]]:
        headers = {**bearer(VIEWER)}
        if last_event_id is not None:
            headers["Last-Event-ID"] = str(last_event_id)
        frames: list[dict[str, Any]] = []
        async with self.api.stream("GET", f"{API}/runs/{run_id}/events", headers=headers) as response:
            assert response.status_code == 200
            frame: dict[str, Any] = {}
            async for line in response.aiter_lines():
                line = line.rstrip("\r")
                if not line:
                    if frame:
                        frames.append(frame)
                        frame = {}
                    continue
                if line.startswith(":"):
                    continue
                name, _, value = line.partition(":")
                frame[name] = value.removeprefix(" ")
        if frame:
            frames.append(frame)
        return frames

    async def webhooks(self, event: str, count: int = 1) -> list[str]:
        """Wait until ``count`` deliveries of ``event`` reached the receiver (they are sent in the background, after
        the run row already shows the outcome), then let every in-flight delivery finish."""
        await self.wait_for(
            f"{count} {event} webhook(s)", lambda: self.receiver.events().count(event) >= count, timeout=30
        )
        await events.drain()
        return self.receiver.events()


# ---------- DB views for assertions ----------


def rows(model: type, **where: Any) -> list[Any]:
    with db.session_scope() as session:
        query = session.query(model)
        for key, value in where.items():
            query = query.filter(getattr(model, key) == value)
        return list(query.all())


@asynccontextmanager
async def running_stack(samples: Path, backend: ScriptedAgentBackend) -> AsyncIterator[Stack]:
    notifier = RecordingNotifier()
    receiver = WebhookReceiver()
    receiver.start()
    factory.set_override("agent_backend", backend)
    factory.set_override("notifier", notifier)
    env = await WorkflowEnvironment.start_local(data_converter=DATA_CONVERTER)
    try:
        worker = build_worker(env.client)
        target = env.client.service_client.config.target_host
        app = create_app(
            RealTemporalGateway(target, "default"), rate_limiter=RateLimiter(rate_per_s=10_000, burst=10_000)
        )
        app.state.sse_poll_s = 0.05
        transport = httpx.ASGITransport(app=app)
        async with worker, httpx.AsyncClient(transport=transport, base_url="http://aidlc.test", timeout=60) as client:
            stack = Stack(env=env, api=client, backend=backend, notifier=notifier, receiver=receiver, samples=samples)
            yield stack
            await events.drain()
    finally:
        await env.shutdown()
        receiver.stop()
