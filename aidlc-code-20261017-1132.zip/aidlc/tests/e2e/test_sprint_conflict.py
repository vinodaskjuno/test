"""A sprint of two REQs appending at the same points of the same files (``brownfield-multi/sprint-conflict``)."""

from __future__ import annotations

import subprocess
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from pathlib import Path
from typing import Any

import pytest

from aidlc.platform import db
from aidlc.platform.git.conflict_bound import resolve_text
from tests.e2e.conftest import SPECS
from tests.e2e.harness import MAINTAINER, Stack, rows
from tests.e2e.orders_platform import (
    CancelScript,
    ReleaseCancelScript,
    ReleaseStatusScript,
    SprintItemScript,
    StatusScript,
)
from tests.e2e.scripted import Script

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]
SPRINT = SPECS / "brownfield-multi" / "sprint-conflict"
SHARED = ["app/models.py", "app/routes/orders.py", "app/store.py", "openapi.yaml"]


def git(cwd: str, *args: str) -> str:
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True).stdout


async def start_sprint(stack: Stack, first: SprintItemScript, second: SprintItemScript) -> dict[str, Any]:
    remote = stack.remote("multi-api")

    async def first_has_delivered() -> None:
        """Hold REQ-002 until REQ-001 has pushed its code and its tests (S8), so the conflict is deterministic."""

        def delivered() -> bool:
            refs = git(remote, "for-each-ref", "--format=%(refname:short)", "refs/heads/aidlc/REQ-001-*").split()
            return bool(refs) and "tests/test_cancel.py" in git(remote, "ls-tree", "-r", "--name-only", refs[0])

        await stack.wait_for("REQ-001 delivered", delivered, timeout=120)

    second.before_final_merge = first_has_delivered
    stack.backend.by_item.update({"REQ-001": first, "REQ-002": second})
    repos = [
        {"id": "api", "url": remote, "primary": True},
        {"id": "web", "url": stack.remote("multi-web")},
        {"id": "infra", "url": stack.remote("multi-infra")},
    ]
    await stack.create_project("orders-platform", repos, merge_order=["infra", "api", "web"])
    items = [
        {
            "title": title,
            "repo_hints": ["api"],
            "sources": [{"kind": "markdown", "name": name, "content": (SPRINT / name).read_text()}],
        }
        for title, name in (("Cancel an order", "req-a.md"), ("Update order status", "req-b.md"))
    ]
    sprint = await stack.post(
        "/sprints", {"project_id": "orders-platform", "title": "Orders sprint 42", "items": items}
    )
    assert sprint["work_item_ids"] == ["REQ-001", "REQ-002"]
    return sprint


async def test_append_only_conflict_is_resolved_by_conflict_bound(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]],
) -> None:
    async with stack_for(Script()) as stack:
        sprint = await start_sprint(stack, CancelScript(), StatusScript())
        a, b = (c["id"] for c in sprint["children"])

        view_a = await stack.wait_run(a, lambda v: v["state"]["stage"] == "gate_b", "REQ-001 ready")
        view_b = await stack.wait_run(b, lambda v: v["state"]["stage"] == "gate_b", "REQ-002 ready")

        # Manifest: both in flight, ranked in sprint order, sharing the appended files.
        manifest = {m["work_item_id"]: m for m in await stack.get("/manifest?project_id=orders-platform")}
        assert (manifest["REQ-001"]["rank"], manifest["REQ-002"]["rank"]) == (1, 2)
        assert set(SHARED) <= set(manifest["REQ-001"]["files"]) & set(manifest["REQ-002"]["files"])
        assert {m["status"] for m in manifest.values()} == {"pr-ready"}

        # The higher-ranked run passes untouched; the lower-ranked one first conflicts, then passes after bounded
        # auto-resolution and a re-run of its tests.
        def finals(view: dict[str, Any]) -> list[tuple[int, bool]]:
            return [(g["attempt"], g["passed"]) for g in view["state"]["gates"] if g["gate"] == "trial_merge_final"]

        for view in (view_a, view_b):  # before S3 neither branch has code: no real conflict yet
            assert [g["passed"] for g in view["state"]["gates"] if g["gate"] == "trial_merge_early"] == [True]
        assert finals(view_a) == [(1, True)] and view_a["state"]["conflicts_resolved"] == []
        assert finals(view_b) == [(1, False), (2, True)]
        failed = next(g for g in view_b["state"]["gates"] if g["gate"] == "trial_merge_final" and not g["passed"])
        assert f"(run {a})" in failed["issues"][0] and all(f in failed["issues"][0] for f in SHARED)
        resolved = view_b["state"]["conflicts_resolved"]
        assert sorted(c["file"] for c in resolved) == SHARED
        assert {(c["kind"], c["resolved_by"]) for c in resolved} == {("append_point", "conflict_bound")}
        assert len(rows(db.RunEventRow, run_id=b, type="conflict_resolved")) == 4
        assert view_b["state"]["iteration"] == 2  # tests re-ran on the merged code
        tests_b = {t["id"]: t["status"] for t in view_b["tests"]}
        assert tests_b["tests/test_cancel.py::test_ac_3_shipped_cannot_be_cancelled"] == "pass"  # REQ-001's code
        assert tests_b["tests/test_contract.py::test_paths_match"] == "pass"

        # Two PRs; REQ-002's PR records the resolutions and contains both endpoints.
        [pr_a], [pr_b] = view_a["prs"], view_b["prs"]
        with db.session_scope() as session:
            body_b = (
                session.query(db.LocalPR)
                .filter_by(repo_url=stack.remote("multi-api"), number=pr_b["number"])
                .one()
                .body
            )
        assert "## Conflicts resolved\n- `api:app/models.py` (append_point, resolved by conflict_bound)" in body_b
        branch_b = git(
            stack.remote("multi-api"), "for-each-ref", "--format=%(refname:short)", "refs/heads/aidlc/REQ-002-*"
        ).split()[0]
        routes = git(stack.remote("multi-api"), "show", f"{branch_b}:app/routes/orders.py")
        assert "def update_order_status" in routes and "def cancel_order" in routes

        sprints = await stack.get("/sprints?project_id=orders-platform")
        assert sorted(c["id"] for c in sprints[0]["children"]) == sorted([a, b])

        await stack.merge_pr(pr_a)
        await stack.merge_pr(pr_b)
        done = await stack.wait_run(sprint["run"]["id"], lambda v: v["state"]["stage"] == "done", "sprint done")
        assert done["state"]["outcome"] == "pr-ready"
        assert sorted(p["repo"] + str(p["number"]) for p in done["prs"]) == ["api1", "api2"]
        assert {m["status"] for m in await stack.get("/manifest?project_id=orders-platform")} == {"done"}


def resolve_on_the_branch(remote: str, branch: str, other: str, workdir: Path) -> None:
    """What the human does for a ``conflict`` escalation: merge the other branch into the run branch on the forge,
    keep the run's own version of the refused file, keep both sides of the pure additions, and push."""
    checkout = workdir / "human"
    subprocess.run(["git", "clone", "-q", "-b", branch, remote, str(checkout)], check=True)
    ident = ["-c", "user.name=Lead", "-c", "user.email=lead@acme.test", "-c", "merge.conflictStyle=diff3"]
    merged = subprocess.run(["git", *ident, "merge", "--no-edit", f"origin/{other}"], cwd=checkout, capture_output=True)
    assert merged.returncode != 0  # it really conflicts
    for name in git(str(checkout), "diff", "--name-only", "--diff-filter=U").split():
        if name == "app/main.py":
            git(str(checkout), "checkout", "--ours", "--", name)  # 1.10.0 supersedes 1.9.0
        else:
            resolved = resolve_text((checkout / name).read_text())
            assert resolved.ok, (name, resolved.reason)
            (checkout / name).write_text(resolved.text)
        git(str(checkout), "add", "--", name)
    git(str(checkout), *ident, "commit", "-q", "--no-edit")
    git(str(checkout), "push", "-q", "origin", branch)


async def test_conflicting_edit_of_the_same_line_escalates_until_a_human_resolves_it(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]], tmp_path: Path
) -> None:
    async with stack_for(Script()) as stack:
        sprint = await start_sprint(stack, ReleaseCancelScript(), ReleaseStatusScript())
        a, b = (c["id"] for c in sprint["children"])

        def open_escalation(view: dict[str, Any]) -> bool:
            return any(e["decision"] is None for e in view["state"]["escalations"])

        waiting = await stack.wait_run(b, open_escalation, "REQ-002 conflict escalation", expect_escalation=True)
        [esc] = waiting["state"]["escalations"]
        assert (esc["reason"], esc["detail"]) == ("conflict", "merge conflicts need a human: api:app/main.py")
        assert esc["options"] == ["retry", "takeover", "cancel"]
        assert esc["diagnosis"] == "# workflow-diagnostics"  # Workflow Diagnostics' report rides on the escalation
        assert stack.backend.called("workflow-diagnostics", b)[0].call.inputs["escalation"]["reason"] == "conflict"
        assert [p["draft"] for p in waiting["prs"]] == [True]  # never marked ready while conflicted
        [event] = rows(db.RunEventRow, run_id=b, type="escalation")
        assert event.data["inbox_ids"] == {"ESC-1": f"{b}:ESC-1"}
        assert any("Escalation (conflict)" in s for s in stack.notifier.subjects())

        # Retry without fixing anything: the platform re-checks and escalates again.
        await stack.post(f"/inbox/{b}:ESC-1/decide", {"decision": "retry"}, expect=200, user=MAINTAINER)
        again = await stack.wait_run(
            b, lambda v: len(v["state"]["escalations"]) == 2, "second escalation", expect_escalation=True
        )
        assert again["state"]["escalations"][1]["detail"] == "merge conflicts need a human: api:app/main.py"

        # A human resolves the conflict on the pushed run branch, then retries: the run picks it up and finishes.
        remote = stack.remote("multi-api")
        branch_a, branch_b = (
            git(remote, "for-each-ref", "--format=%(refname:short)", f"refs/heads/aidlc/{item}-*").split()[0]
            for item in ("REQ-001", "REQ-002")
        )
        resolve_on_the_branch(remote, branch_b, branch_a, tmp_path)
        await stack.post(f"/inbox/{b}:ESC-2/decide", {"decision": "retry"}, expect=200, user=MAINTAINER)
        view_b = await stack.wait_run(b, lambda v: v["state"]["stage"] == "gate_b", "REQ-002 ready")
        assert [e["decision"] for e in view_b["state"]["escalations"]] == ["retry", "retry"]
        assert view_b["state"]["conflicts_resolved"] == []  # the human resolved it, not conflict_bound
        assert [p["draft"] for p in view_b["prs"]] == [False]
        routes = git(remote, "show", f"{branch_b}:app/routes/orders.py")
        assert "def update_order_status" in routes and "def cancel_order" in routes
        assert 'version="1.10.0"' in git(remote, "show", f"{branch_b}:app/main.py")
        tests_b = {t["id"]: t["status"] for t in view_b["tests"]}
        assert tests_b["tests/test_cancel.py::test_ac_3_shipped_cannot_be_cancelled"] == "pass"

        ready_a = await stack.wait_run(a, lambda v: v["state"]["stage"] == "gate_b", "REQ-001 ready")
        await stack.merge_pr(ready_a["prs"][0])
        await stack.merge_pr(view_b["prs"][0])
        done = await stack.wait_run(sprint["run"]["id"], lambda v: v["state"]["stage"] == "done", "sprint done")
        assert done["state"]["outcome"] == "pr-ready"
