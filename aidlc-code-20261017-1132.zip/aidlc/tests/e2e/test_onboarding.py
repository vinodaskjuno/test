"""Create-new-repo onboarding through the API on LocalForge: template repo, protection, .adlc/ scaffold, doctor, PR."""

from __future__ import annotations

import subprocess
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from pathlib import Path
from typing import Any

import pytest

from aidlc.contracts import AgentCall
from aidlc.orchestrator.activities.artifacts import adlc_doctor
from aidlc.orchestrator.models import DoctorInput
from aidlc.platform import db
from aidlc.settings import get_settings
from tests.e2e.harness import MAINTAINER, Stack, rows
from tests.e2e.scripted import Script, write

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]


def git(cwd: Path | str, *args: str) -> str:
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout


class OnboardingScript(Script):
    def repository_discovery(self, call: AgentCall) -> dict[str, Any]:
        return {
            **super().repository_discovery(call),
            "frameworks": ["fastapi", "nextjs"],
            "test_commands": ["cd api && pytest -q", "cd web && npm test"],
            "modules": ["api", "web"],
        }

    def docs(self, call: AgentCall) -> dict[str, Any]:
        root = next(iter(call.worktrees.values()))
        for rel in call.allowed_files:
            write(root, rel, f"# {Path(rel).stem}\n\nWritten from the repository profile ({call.inputs['mode']}).\n")
        return {"summary": "context files", "files_changed": call.allowed_files}


async def test_new_repo_onboarding_creates_protected_repo_and_scaffold(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]], tmp_path: Path
) -> None:
    async with stack_for(OnboardingScript()) as stack:
        await stack.create_project("todo", [])
        run = await stack.post(
            "/projects/todo/onboard",
            {"mode": "new", "repo_name": "todo-app", "preset": "nextjs-fastapi"},
            user=MAINTAINER,
        )
        assert run["kind"] == "onboarding"
        view = await stack.wait_run(run["id"], lambda v: v["state"]["outcome"] is not None, "onboarding finished")
        assert view["state"]["outcome"] == "pr-ready", view["state"]["summary"]

        # The repo exists on the forge, seeded from presets/templates/nextjs-fastapi, with main protected.
        remote = get_settings().workspace_dir / "remotes" / "todo-app.git"
        main_files = git(remote, "ls-tree", "-r", "--name-only", "main").split()
        assert {"README.md", "CODEOWNERS", "api/pyproject.toml", "web/package.json"} <= set(main_files)
        assert git(remote, "config", "receive.denyNonFastForwards").strip() == "true"
        assert git(remote, "config", "aidlc.main.requiredChecks").strip() == "aidlc/gates"

        # The onboarding PR carries the .adlc/ scaffold; the doctor passed in the run and passes on the branch.
        [pr] = view["prs"]
        assert pr["repo"] == "todo-app" and pr["draft"] is False
        [local_pr] = rows(db.LocalPR, repo_url=str(remote))
        assert (local_pr.head, local_pr.base) == ("aidlc/onboarding", "main")
        assert "## Doctor" in local_pr.body and "FAIL" not in local_pr.body
        branch_files = set(git(remote, "ls-tree", "-r", "--name-only", "aidlc/onboarding").split())
        expected = {
            ".adlc/config.yml",
            ".adlc/ETHOS.md",
            ".adlc/context/project-overview.md",
            ".adlc/context/architecture.md",
            ".adlc/context/conventions.md",
            ".adlc/templates/requirement.md",
        }
        assert expected <= branch_files
        overview = git(remote, "show", "aidlc/onboarding:.adlc/context/project-overview.md")
        assert "Written from the repository profile (onboarding)" in overview
        [doctor_event] = [
            e for e in rows(db.RunEventRow, run_id=run["id"], type="log") if e.message.startswith("doctor")
        ]
        assert doctor_event.message == "doctor passed"
        checkout = tmp_path / "todo-app"
        git(tmp_path, "clone", "--quiet", "--branch", "aidlc/onboarding", str(remote), str(checkout))
        report = await adlc_doctor(DoctorInput(worktree=str(checkout)))
        assert report.ok, report.checks
        config = git(remote, "show", "aidlc/onboarding:.adlc/config.yml")
        assert "todo-app:" in config and "primary: true" in config

        # The project now knows its repo, so the next spec upload has somewhere to go.
        project = await stack.get("/projects/todo")
        assert [(r["id"], r["url"], r["primary"]) for r in project["config"]["repos"]] == [
            ("todo-app", str(remote), True)
        ]
        doctor = await stack.post("/projects/todo/doctor", expect=200, user=MAINTAINER)
        assert {c["name"]: c["status"] for c in doctor["checks"]}["repo:todo-app"] == "ok"
