"""Upload-only journey on the storefront sample: upload -> Gate A question -> answer -> real tests -> PR -> merge."""

from __future__ import annotations

import json
import subprocess
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from pathlib import Path

import pytest

from aidlc.platform import db, events
from aidlc.platform.forge.local import LocalForge
from tests.e2e.conftest import SPECS
from tests.e2e.harness import CONTRIBUTOR, MAINTAINER, WEBHOOK_SECRET, Stack, rows
from tests.e2e.storefront import PaginationScript

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]

QUESTION = "Should the orders page default to newest first?"


def git(remote: str, *args: str) -> str:
    return subprocess.run(["git", *args], cwd=remote, check=True, capture_output=True, text=True).stdout


async def test_upload_only_journey(stack_for: Callable[..., AbstractAsyncContextManager[Stack]]) -> None:
    script = PaginationScript(question=QUESTION)
    async with stack_for(script) as stack:
        remote = stack.remote("sample-fastapi-nextjs")
        main_before = git(remote, "rev-parse", "main").strip()
        await stack.create_project("storefront", [{"id": "storefront", "url": remote, "primary": True}])

        uploaded = await stack.upload("storefront", SPECS / "brownfield-single" / "orders-pagination.md")
        run_id = uploaded["run"]["id"]
        assert uploaded["run"]["work_item_id"] == "REQ-001"
        assert uploaded["uploads"][0]["filename"] == "orders-pagination.md"

        # Gate A: the ambiguity agent's question reaches the Inbox (and a notification goes out).
        [question] = await stack.wait_inbox("storefront", "question", run_id)
        assert question["title"] == QUESTION
        assert question["id"] == f"{run_id}:Q-1"
        [asked] = rows(db.RunEventRow, run_id=run_id, type="question")
        assert asked.data["inbox_ids"] == {"Q-1": question["id"]}
        waiting = await stack.run_view(run_id)
        assert waiting["state"]["stage"] == "gate_a"
        assert waiting["state"]["questions"][0]["answer"] is None
        assert any("Gate A questions waiting" in s for s in stack.notifier.subjects())

        answered = await stack.post(
            f"/inbox/{question['id']}/answer", {"answer": "newest first"}, expect=200, user=CONTRIBUTOR
        )
        assert answered["status"] == "resolved"

        # The run continues to a ready PR and waits at Gate B.
        view = await stack.wait_run(
            run_id, lambda v: v["state"]["outcome"] == "pr-ready" and v["state"]["stage"] == "gate_b", "pr-ready"
        )

        # ----- RunView -----
        state = view["state"]
        assert view["run"]["work_item_id"] == "REQ-001"
        assert not view["run"]["title"].endswith(".md")  # intake named the untitled upload
        assert state["questions"][0]["answer"] == "newest first"
        assert [g["gate"] for g in state["gates"] if g["passed"]] == [
            "V1",
            "A",
            "V2",
            "trial_merge_early",
            "quality",
            "trial_merge_final",
        ]
        [pr] = view["prs"]
        assert pr["repo"] == "storefront" and pr["draft"] is False
        rows_by_ac = {r["ac_id"]: r for r in view["traceability"]}
        assert list(rows_by_ac) == [f"AC-{n}" for n in range(1, 12)]
        assert all(r["passed"] for r in view["traceability"]), view["traceability"]
        assert any("test_ac_2_second_page_of_two" in t for t in rows_by_ac["AC-2"]["tests"])
        assert any(t.endswith("AC-9 sortable headers expose aria-sort") for t in rows_by_ac["AC-9"]["tests"])
        tests = {t["id"]: t for t in view["tests"]}
        # baseline tests and the new tests both ran for real (pytest -v and node's JUnit report)
        assert tests["tests/test_orders.py::test_list_returns_orders_in_creation_order"]["status"] == "pass"
        assert tests["tests/test_orders_paging.py::test_ac_4_created_to_includes_the_whole_day"]["status"] == "pass"
        assert sum(t["level"] == "unit" for t in view["tests"]) >= 24
        assert view["cost_by_agent"]["spec-analyst"] == pytest.approx(0.04)  # first draft + Gate A fold-in

        # ----- LocalForge: draft first, then ready, with aidlc/gates success on the branch head -----
        pr_events = [e for e in await stack.sse(run_id) if '"type":"pr"' in e.get("data", "")]
        first_pr = json.loads(pr_events[0]["data"])
        assert first_pr["data"]["draft"] is True and first_pr["stage"] == "spec_pr"
        with db.session_scope() as session:
            local_pr = session.query(db.LocalPR).filter_by(repo_url=remote, number=pr["number"]).one()
            assert local_pr.draft is False
            assert local_pr.title.startswith("REQ-001:")
            assert "## Traceability" in local_pr.body and "| AC-2 |" in local_pr.body
            branch = local_pr.head
        # the upload had no title (the API used the file name), so intake's title names the branch
        assert branch == "aidlc/REQ-001-orders-list-pagination-filters-and-sorti"
        checks = await LocalForge(Path("/unused")).get_checks(remote, branch)
        assert [(c.name, c.conclusion) for c in checks] == [("aidlc/gates", "success")]
        files = git(remote, "ls-tree", "-r", "--name-only", branch).split()
        spec_dir = next(f.split("/")[2] for f in files if f.startswith(".adlc/specs/REQ-001-"))
        for name in ("requirement.md", "architecture.md", "tasks/TASK-001.md", "tasks/TASK-002.md", "run.json"):
            assert f".adlc/specs/{spec_dir}/{name}" in files, name
        assert ".adlc/knowledge/lessons/LESSON-001.md" in files
        assert "api/tests/test_orders_paging.py" in files and "web/tests/orders_page.test.mjs" in files
        requirement_md = git(remote, "show", f"{branch}:.adlc/specs/{spec_dir}/requirement.md")
        assert "newest first" in requirement_md and "AC-11" in requirement_md
        assert git(remote, "rev-parse", "main").strip() == main_before  # nothing lands on main without a merge

        # ----- SSE: full replay, then resume after a Last-Event-ID -----
        frames = await stack.sse(run_id)
        assert frames[-1]["event"] == "end"
        replay = [f for f in frames if "id" in f]
        seqs = [int(f["id"]) for f in replay]
        assert seqs == sorted(seqs) and len(seqs) > 50
        types = [json.loads(f["data"])["type"] for f in replay]
        assert types[0] == "run_started" and "question" in types and "answer" in types
        middle = seqs[len(seqs) // 2]
        resumed = [int(f["id"]) for f in await stack.sse(run_id, last_event_id=middle) if "id" in f]
        assert resumed == [s for s in seqs if s > middle]

        # ----- Run.state snapshots, inbox, cost records, notifications, webhooks -----
        [run_row] = rows(db.Run, id=run_id)
        assert run_row.state["outcome"] == "pr-ready" and run_row.state["prs"][0]["number"] == pr["number"]
        assert run_row.cost_usd == pytest.approx(state["cost_usd"])
        costs = rows(db.CostRecord, run_id=run_id)
        assert {c.squad for c in costs} >= {"S1", "S2", "S3", "S4", "S6", "S7", "S8", "S9"}
        assert {(c.agent_id, c.model) for c in costs} >= {
            ("spec-analyst", "claude-opus-5-5"),
            ("intake", "claude-haiku-5-5"),
        }
        [gate_b] = await stack.inbox("storefront", "gate_b")
        assert gate_b["payload"]["prs"][0]["number"] == pr["number"]
        assert any(s.startswith("[AIDLC] PR(s) ready for review") for s in stack.notifier.subjects())
        pr_ready_mail = next(n for n in stack.notifier.sent if "PR(s) ready" in n.subject)
        assert CONTRIBUTOR in pr_ready_mail.to and MAINTAINER in pr_ready_mail.to

        # ----- Gate B: the PR is merged (signed GitHub webhook) and the run completes -----
        merged = await stack.merge_pr(pr)
        assert merged["run_id"] == run_id
        done = await stack.wait_run(run_id, lambda v: v["state"]["stage"] == "done", "run finished")
        assert done["state"]["outcome"] == "pr-ready"
        assert done["prs"][0]["state"] == "merged"
        assert done["state"]["summary"].startswith("all PRs merged")
        with db.session_scope() as session:
            entry = session.get(db.ManifestEntry, run_id)
            assert entry is not None and entry.status == "done"

        delivered = await stack.webhooks("run.completed")
        assert delivered.count("run.gate_waiting") == 1
        assert "run.pr_ready" in delivered and "run.completed" in delivered
        assert all(
            events.verify(WEBHOOK_SECRET, d.body, d.headers["X-AIDLC-Signature"]) for d in stack.receiver.deliveries
        )
        assert {d.json["run_id"] for d in stack.receiver.deliveries} == {run_id}
        assert {d.status for d in rows(db.WebhookDelivery)} == {"delivered"}
