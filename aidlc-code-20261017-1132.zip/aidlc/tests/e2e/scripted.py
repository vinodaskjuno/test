"""The only fake in the end-to-end tests: an agent backend that answers like the real agents would, deterministically.

``ScriptedAgentBackend`` sits behind the real ``run_agent`` activity (prompt building, untrusted wrapping, schema
validation, cost reporting all run for real). Each agent id maps to a method on a ``Script``: read-only agents return
schema-valid JSON derived from their inputs; mutating dev/test agents really edit files in ``call.worktrees`` so the
real git, test-runner, trial-merge and forge code paths operate on real changes.
"""

from __future__ import annotations

import asyncio
import inspect
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from aidlc.contracts import AgentCall, AgentResult

AC_LINE = re.compile(r"^- \*\*(AC-\d+)\*\*\s+(.*?)(?=^- \*\*AC-|^\s*$|^#|\Z)", re.MULTILINE | re.DOTALL)
COST_PER_CALL = 0.02


def norm(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def parse_acs(content: str) -> list[tuple[str, str]]:
    return [(ac_id, norm(text)) for ac_id, text in AC_LINE.findall(content)]


def write(root: str | Path, rel: str, content: str) -> str:
    path = Path(root) / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return rel


def edit(root: str | Path, rel: str, old: str, new: str) -> str:
    path = Path(root) / rel
    text = path.read_text(encoding="utf-8")
    assert old in text, f"{rel}: {old!r} not found"
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    return rel


def append(root: str | Path, rel: str, content: str) -> str:
    path = Path(root) / rel
    path.write_text(path.read_text(encoding="utf-8") + content, encoding="utf-8")
    return rel


def failing_tests(report: dict[str, Any] | None) -> list[dict[str, Any]]:
    return [r for r in (report or {}).get("results", []) if r.get("status") == "fail"]


@dataclass
class Recorded:
    call: AgentCall
    system_prompt: str
    user_prompt: str


class Script:
    """Default, schema-valid behaviour for every agent. Scenario scripts override the methods they care about."""

    title = "Change"
    repo_hints: list[str] = []
    test_commands: dict[str, list[str]] = {}

    def __init__(self) -> None:
        self.state: dict[str, Any] = {}

    # ----- helpers -----

    @staticmethod
    def sources(call: AgentCall) -> list[dict[str, Any]]:
        return list(call.inputs.get("sources") or [])

    @staticmethod
    def item_id(call: AgentCall) -> str:
        return str((call.inputs.get("work_item") or {}).get("id") or "REQ-000")

    @staticmethod
    def repo_of(call: AgentCall) -> str:
        return next(iter(call.worktrees))

    @staticmethod
    def requirement(call: AgentCall) -> dict[str, Any]:
        return call.inputs.get("requirement") or {}

    def ac_ids(self, call: AgentCall) -> list[str]:
        return [ac["id"] for ac in self.requirement(call).get("acceptance_criteria", [])]

    # ----- S1 -----

    def intake(self, call: AgentCall) -> dict[str, Any]:
        first = self.sources(call)[0] if self.sources(call) else {"content": ""}
        heading = next((ln.lstrip("# ").strip() for ln in first["content"].splitlines() if ln.startswith("# ")), "")
        return {"title": heading or self.title, "kind": "feature", "summary": heading, "repo_hints": self.repo_hints}

    def spec_analyst(self, call: AgentCall) -> dict[str, Any]:
        acs = []
        for src in self.sources(call):
            for ac_id, text in parse_acs(src["content"]):
                quote = text[:70].rsplit(" ", 1)[0]
                acs.append({"id": ac_id, "text": text, "citations": [{"source_name": src["name"], "quote": quote}]})
        answers = call.inputs.get("answers") or []
        return {
            "req_id": self.item_id(call),
            "title": (call.inputs.get("work_item") or {}).get("title") or self.title,
            "summary": f"{self.title} as described in the uploaded spec.",
            "acceptance_criteria": acs,
            "repo_hints": self.repo_hints,
            "assumptions": [f"{a['id']} answered: {a['answer']}" for a in answers if a.get("answer")],
        }

    def ambiguity_conflict_detection(self, call: AgentCall) -> dict[str, Any]:
        return {}

    def compliance_policy(self, call: AgentCall) -> dict[str, Any]:
        return {"summary": "No regulated data beyond what the conventions already cover."}

    def ux_design_analyst(self, call: AgentCall) -> dict[str, Any]:
        return {"summary": "Follows the existing table styles."}

    def spec_validator(self, call: AgentCall) -> dict[str, Any]:
        return {"passed": True}

    def adversary(self, call: AgentCall) -> dict[str, Any]:
        return {"findings": [], "summary": f"nothing blocking ({call.inputs.get('mode')})"}

    # ----- S2 -----

    def repository_discovery(self, call: AgentCall) -> dict[str, Any]:
        repo = self.repo_of(call)
        return {
            "integration_branch": "main",
            "languages": ["python", "typescript"],
            "test_commands": list(self.test_commands.get(repo, [])),
            "conventions_summary": f"{repo}: thin routes, parameterised SQL, tests inject sleep.",
        }

    def _analysis(self, call: AgentCall) -> dict[str, Any]:
        return {"summary": f"{call.agent_id} analysis", "details_md": f"## {call.agent_id}\nNothing unusual."}

    architecture_mapper = feature_tracer = integration_explorer = data_modeler = _analysis

    def solution_architect(self, call: AgentCall) -> dict[str, Any]:
        return {
            "summary": "Extend the existing layers.",
            "details_md": f"# Architecture\n\n{self.title}: extend the "
            "existing route, repository and component layers; no new services.",
        }

    def api_contract(self, call: AgentCall) -> dict[str, Any]:
        return {"openapi_yaml": "openapi: 3.1.0\ninfo: {title: Orders API, version: 1.0.0}\npaths: {}\n"}

    def work_planner(self, call: AgentCall) -> dict[str, Any]:
        raise NotImplementedError("scenario scripts plan their own tasks")

    def overlap_analyst(self, call: AgentCall) -> dict[str, Any]:
        others = call.inputs.get("manifest") or []
        mine = {f for t in (call.inputs.get("plan") or {}).get("tasks", []) for f in t.get("files", [])}
        overlaps = [
            {"run_id": o["run_id"], "files": sorted(mine & set(o.get("files", [])))}
            for o in others
            if mine & set(o.get("files", []))
        ]
        return {"overlaps": overlaps, "summary": f"{len(overlaps)} overlapping run(s)" if overlaps else ""}

    def plan_validator(self, call: AgentCall) -> dict[str, Any]:
        return {"passed": True}

    # ----- S4 / S5 / S6 -----

    def test_strategist(self, call: AgentCall) -> dict[str, Any]:
        return {
            "ac_to_tests": {ac: [f"test_{ac.lower().replace('-', '_')}"] for ac in self.ac_ids(call)},
            "levels": ["unit"],
            "coverage_target_pct": 0,
        }

    def _no_findings(self, call: AgentCall) -> dict[str, Any]:
        return {"findings": [], "summary": "no issues"}

    static_analysis = runtime_hazard = security_scanner = dependency_license = performance_smell = _no_findings
    flaky_test_analyst = _no_findings

    def spec_conformance_validator(self, call: AgentCall) -> dict[str, Any]:
        """An AC passes when none of the tests mapped to it fails (the real agent also reads the diff)."""
        results = (call.inputs.get("test_report") or {}).get("results", [])
        verdicts = []
        for ac in self.ac_ids(call):
            mapped = [r for r in results if ac in r.get("ac_ids", [])]
            verdicts.append(
                {
                    "ac_id": ac,
                    "passed": not any(r["status"] == "fail" for r in mapped),
                    "evidence": [r["name"] for r in mapped] or ["covered by the diff review"],
                }
            )
        return {"verdicts": verdicts}

    def visual_ux_validator(self, call: AgentCall) -> dict[str, Any]:
        return {"verdicts": []}

    def triage(self, call: AgentCall) -> dict[str, Any]:
        failing = failing_tests(call.inputs.get("test_report"))
        tasks = call.inputs.get("tasks") or []
        failed_acs = {ac for r in failing for ac in r.get("ac_ids", [])}
        failed_acs |= {v["ac_id"] for v in call.inputs.get("verdicts") or [] if not v.get("passed")}
        task = next((t for t in tasks if failed_acs & set(t.get("ac_ids", []))), tasks[0] if tasks else None)
        if task is None:
            return {"fix_tickets": [], "diagnosis": "nothing to fix"}
        ticket = {
            "id": f"FIX-{len(self.state.setdefault('tickets', [])) + 1}",
            "owner_agent": task["owner_agent"],
            "repo": task["repo"],
            "root_cause": "failing: " + ", ".join(r["name"] for r in failing) if failing else "AC not satisfied",
            "files": task.get("files", []),
            "evidence": "\n".join(r.get("output", "")[-500:] for r in failing),
        }
        self.state["tickets"].append(ticket)
        return {"fix_tickets": [ticket], "diagnosis": ticket["root_cause"]}

    def debugger(self, call: AgentCall) -> dict[str, Any]:
        ticket = call.inputs.get("fix_ticket")
        return {"fix_tickets": [ticket] if ticket else [], "diagnosis": "root cause confirmed by the failing test"}

    # ----- S7 -----

    reflector = correctness_reviewer = security_reviewer = performance_reviewer = _no_findings
    maintainability_reviewer = architecture_conformance = _no_findings

    def review_judge(self, call: AgentCall) -> dict[str, Any]:
        return {"blocking": [], "non_blocking": [], "dropped": [], "summary": "no blocking findings"}

    # ----- S8 / S9 -----

    def _repos(self, call: AgentCall) -> list[str]:
        return list(call.worktrees)

    def commit(self, call: AgentCall) -> dict[str, Any]:
        item = self.item_id(call)
        return {"messages": {repo: f"feat({repo}): {item} {self.title}" for repo in self._repos(call)}}

    def release_notes(self, call: AgentCall) -> dict[str, Any]:
        return {"changelog_entry": f"- {self.title}"}

    def pr(self, call: AgentCall) -> dict[str, Any]:
        item = self.item_id(call)
        return {
            "title": f"{item}: {self.title}",
            "bodies": {repo: f"## Summary\n{self.title} ({repo})." for repo in self._repos(call)},
        }

    def audit_compliance_reporter(self, call: AgentCall) -> dict[str, Any]:
        summary = call.inputs.get("run_summary") or {}
        flags = summary.get("security_flags") or []
        lines = ["# Audit pack", f"Run `{summary.get('run_id')}`", "", "## Security flags"]
        lines += [f"- {f}" for f in flags] or ["- none"]
        return {"report_md": "\n".join(lines), "score": 1.0}

    def knowledge_capture(self, call: AgentCall) -> dict[str, Any]:
        return {"lessons": [{"title": f"{self.title}: lesson", "body": "Keep the change additive.", "tags": ["e2e"]}]}

    def ci_watcher(self, call: AgentCall) -> dict[str, Any]:
        return {"fix_tickets": [], "diagnosis": "no failing checks"}

    def pr_feedback(self, call: AgentCall) -> dict[str, Any]:
        return {"replies": []}

    # ----- S9 / S10 -----

    def _report(self, call: AgentCall) -> dict[str, Any]:
        return {"report_md": f"# {call.agent_id}"}

    knowledge_curator = agent_evaluation = cost_optimization = workflow_diagnostics = _report
    data_privacy_governance = convention_auditor = test_coverage_auditor = ai_api_cost_scanner = _no_findings

    def backlog_writer(self, call: AgentCall) -> dict[str, Any]:
        return {"drafts": []}

    # ----- dev / test agents (no-op by default) -----

    def _dev(self, call: AgentCall) -> dict[str, Any]:
        return {"summary": "no change needed", "files_changed": []}

    backend_dev = frontend_dev = db_migration_dev = integration_dev = refactoring = devops_iac = docs = _dev
    unit_test = integration_contract_test = e2e_ui_test = performance_resilience = accessibility_test = _dev

    def test_environment_data(self, call: AgentCall) -> dict[str, Any]:
        return {"compose_yaml": ""}

    def branch_merge(self, call: AgentCall) -> dict[str, Any]:
        return {"merged": True}


@dataclass
class ScriptedAgentBackend:
    """``interfaces.AgentBackend`` answering from a ``Script`` (per run id when several runs share a worker)."""

    script: Script
    by_item: dict[str, Script] = field(default_factory=dict)  # work item id -> script (concurrent runs)
    by_run: dict[str, Script] = field(default_factory=dict)
    calls: list[Recorded] = field(default_factory=list)

    def script_for(self, call: AgentCall) -> Script:
        """A run's first agent (intake) carries its work item; later calls are routed by run id."""
        if call.run_id not in self.by_run:
            item = (call.inputs.get("work_item") or {}).get("id")
            if item in self.by_item:
                self.by_run[call.run_id] = self.by_item[item]
        return self.by_run.get(call.run_id, self.script)

    async def invoke(self, call: AgentCall, *, system_prompt: str, user_prompt: str) -> AgentResult:
        self.calls.append(Recorded(call, system_prompt, user_prompt))
        handler = getattr(self.script_for(call), call.agent_id.replace("-", "_"))
        out = handler(call)
        if inspect.isawaitable(out):
            out = await out
        if isinstance(out, AgentResult):
            return out
        await asyncio.sleep(0)
        return AgentResult(
            agent_id=call.agent_id,
            agent_version="scripted",
            ok=True,
            output=out,
            cost_usd=COST_PER_CALL,
            input_tokens=1200,
            output_tokens=300,
            duration_ms=5,
            num_turns=1,
        )

    def called(self, agent_id: str, run_id: str | None = None) -> list[Recorded]:
        return [r for r in self.calls if r.call.agent_id == agent_id and run_id in (None, r.call.run_id)]

    def agents(self, run_id: str | None = None) -> list[str]:
        return list(dict.fromkeys(r.call.agent_id for r in self.calls if run_id in (None, r.call.run_id)))
