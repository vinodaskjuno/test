"""S4 -> S6 fix loop with a real failing test: fixed on iteration 2; and a repeated signature that escalates."""

from __future__ import annotations

from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from typing import Any

import pytest

from aidlc.platform import db
from tests.e2e.conftest import SPECS
from tests.e2e.harness import CONTRIBUTOR, MAINTAINER, Stack, rows
from tests.e2e.storefront import PaginationScript

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]
SPEC = SPECS / "brownfield-single" / "orders-pagination.md"
AC2_TEST = "tests/test_orders_paging.py::test_ac_2_second_page_of_two"


async def start(stack: Stack) -> str:
    await stack.create_project(
        "storefront", [{"id": "storefront", "url": stack.remote("sample-fastapi-nextjs"), "primary": True}]
    )
    return (await stack.upload("storefront", SPEC))["run"]["id"]


def quality(view: dict[str, Any]) -> list[tuple[int, bool]]:
    return [(g["attempt"], g["passed"]) for g in view["state"]["gates"] if g["gate"] == "quality"]


async def test_failing_ac_is_fixed_on_the_second_iteration(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]],
) -> None:
    script = PaginationScript(paging_bug=True)
    async with stack_for(script) as stack:
        run_id = await start(stack)
        view = await stack.wait_run(run_id, lambda v: v["state"]["stage"] == "gate_b", "pr-ready after one fix")

        assert quality(view) == [(1, False), (2, True)]
        assert view["state"]["iteration"] == 2
        failed_gate = next(g for g in view["state"]["gates"] if g["gate"] == "quality" and not g["passed"])
        assert any("acceptance criterion AC-2 is not satisfied" in i for i in failed_gate["issues"])
        assert any(AC2_TEST in i for i in failed_gate["issues"])  # the real pytest failure, not a scripted one

        backend = stack.backend
        [triage] = backend.called("triage", run_id)
        failing = [r for r in triage.call.inputs["test_report"]["results"] if r["status"] == "fail"]
        assert any(r["id"] == AC2_TEST for r in failing)  # failing results keep their id and output
        [debugger] = backend.called("debugger", run_id)
        assert debugger.call.inputs["fix_ticket"]["owner_agent"] == "backend-dev"
        fixes = [r for r in backend.called("backend-dev", run_id) if r.call.inputs.get("fix_ticket")]
        assert len(fixes) == 1
        assert fixes[0].call.allowed_files == fixes[0].call.inputs["fix_ticket"]["files"]
        assert {"stage_started"} <= {e.type for e in rows(db.RunEventRow, run_id=run_id, stage="fix")}

        tests = {t["id"]: t["status"] for t in view["tests"]}
        assert tests[AC2_TEST] == "pass"
        assert all(r["passed"] for r in view["traceability"])
        assert view["state"]["escalations"] == []


async def decide(stack: Stack, run_id: str, reason: str, decision: str, *, count: int) -> dict[str, Any]:
    items = await stack.wait_inbox("storefront", "escalation", run_id)
    [item] = [i for i in items if i["payload"]["reason"] == reason]
    assert item["ref_id"] == f"ESC-{count}"
    assert item["id"] == f"{run_id}:ESC-{count}"  # deterministic, so clients can print `aidlc answer <id>`
    assert item["payload"]["diagnosis"] == "# workflow-diagnostics"  # Workflow Diagnostics explains the escalation
    # Escalation decisions need the maintainer role.
    denied = await stack.call("POST", f"/inbox/{item['id']}/decide", json={"decision": decision}, user=CONTRIBUTOR)
    assert denied.status_code == 403
    return await stack.post(f"/inbox/{item['id']}/decide", {"decision": decision}, expect=200, user=MAINTAINER)


async def test_repeated_signature_escalates_then_retry_and_cancel(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]],
) -> None:
    script = PaginationScript(paging_bug=True, fix_attempts_needed=99)  # every "fix" leaves the same failure
    async with stack_for(script) as stack:
        run_id = await start(stack)

        await decide(stack, run_id, "repeated_signature", "retry", count=1)
        waiting = await stack.wait_run(
            run_id,
            lambda v: len(v["state"]["escalations"]) == 2,
            "the same failure to escalate again",
            expect_escalation=True,
        )
        assert waiting["state"]["escalations"][0]["decision"] == "retry"
        assert quality(waiting) == [(1, False), (2, False), (3, False), (4, False)]
        assert any("Escalation (repeated_signature)" in s for s in stack.notifier.subjects())

        await decide(stack, run_id, "repeated_signature", "cancel", count=2)
        done = await stack.wait_run(
            run_id, lambda v: v["state"]["outcome"] == "cancelled", "cancelled", expect_escalation=True
        )
        assert done["state"]["summary"] == f"ESC-2 (repeated_signature): cancelled by {MAINTAINER}"
        with db.session_scope() as session:
            assert session.get(db.ManifestEntry, run_id).status == "cancelled"
        decisions = [e.data for e in rows(db.RunEventRow, run_id=run_id, type="decision")]
        assert [(d["escalation_id"], d["decision"]) for d in decisions] == [("ESC-1", "retry"), ("ESC-2", "cancel")]
        resolved = await stack.get("/inbox?project_id=storefront&status=resolved", user=CONTRIBUTOR)
        assert sorted(i["resolution"]["decision"] for i in resolved if i["kind"] == "escalation") == ["cancel", "retry"]

        # A cancelled run can be retried from its stored request; the new run is live and can itself be cancelled.
        retried = await stack.post(f"/runs/{run_id}/retry", user=CONTRIBUTOR)
        assert retried["id"] != run_id and retried["work_item_id"] == "REQ-001"
        # It resumes the work item's branch, taking it over from the cancelled run's worktree, and gets to S2+.
        early = ("queued", "S1", "V1", "gate_a", "spec_pr")
        await stack.wait_run(
            retried["id"], lambda v: v["state"]["stage"] not in early, "retry past spec_pr", expect_escalation=True
        )
        await stack.post(f"/runs/{retried['id']}/cancel", expect=200, user=CONTRIBUTOR)
        cancelled = await stack.wait_run(
            retried["id"], lambda v: v["state"]["outcome"] == "cancelled", "cancel", expect_escalation=True
        )
        assert cancelled["state"]["summary"] == f"cancelled by {CONTRIBUTOR}"
        delivered = await stack.webhooks("run.completed", 2)  # a cancelled run's outcome is delivered as completed
        assert delivered.count("run.completed") == 2
