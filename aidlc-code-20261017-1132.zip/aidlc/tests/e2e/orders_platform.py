"""Scripts for the ``orders-platform`` sample repos (``evals/repos/multi/{api,web,infra}``): real code, real tests.

- ``OrderNotesScript``: ``brownfield-multi/order-notes.md`` (contract change in ``api`` + UI in ``web``).
- ``CancelScript`` / ``StatusScript``: ``brownfield-multi/sprint-conflict/req-{a,b}.md``; both append at the same
  points of ``app/routes/orders.py``, ``app/store.py``, ``app/models.py`` and ``openapi.yaml``.
"""

from __future__ import annotations

import sys
from collections.abc import Awaitable, Callable
from typing import Any

from aidlc.contracts import AgentCall
from tests.e2e.scripted import Script, append, edit, write

PYTEST = f"{sys.executable} -m pytest -v -p no:cacheprovider"
NODE_TESTS = (
    "mkdir -p test-results && node --test --test-reporter=junit --test-reporter-destination=test-results/web.xml "
    "'tests/*.test.mjs'"
)
CONTRACT_PATHS_END = '        "404": {description: Not found}\ncomponents:\n'


class OrdersPlatformScript(Script):
    test_commands = {"api": [PYTEST], "infra": [PYTEST]}


# ---------------------------------------------------------------- order notes

NOTES_ROUTE = """

@router.patch("/{order_id}", response_model=Order)
def update_order(order_id: int, body: OrderUpdate, request: Request) -> Order:
    order = _store(request).update_notes(order_id, body.notes)
    if order is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"order {order_id} not found")
    return order
"""

NOTES_STORE = """
    def update_notes(self, order_id: int, notes: str | None) -> Order | None:
        cleaned = (notes or "").strip() or None
        with self._lock:
            order = self._orders.get(order_id)
            if order is None:
                return None
            self._orders[order_id] = order = order.model_copy(update={"notes": cleaned})
            return order
"""

NOTES_CONTRACT_PATCH = """    patch:
      operationId: updateOrder
      parameters:
        - {name: order_id, in: path, required: true, schema: {type: integer}}
      requestBody:
        required: true
        content:
          application/json:
            schema: {$ref: "#/components/schemas/OrderUpdate"}
      responses:
        "200":
          description: The updated order
          content:
            application/json:
              schema: {$ref: "#/components/schemas/Order"}
        "404": {description: Not found}
        "422": {description: Validation error}
"""

NOTES_TESTS = '''"""Order notes (REQ order-notes): API side."""

from __future__ import annotations

from pathlib import Path

import yaml
from fastapi.testclient import TestClient

CONTRACT = yaml.safe_load((Path(__file__).parents[1] / "openapi.yaml").read_text())


def _order(client: TestClient, **extra: object) -> dict:
    return client.post("/orders", json={"customer_name": "Grace", "total_cents": 100, **extra}).json()


def test_ac_1_new_orders_have_null_notes(client: TestClient) -> None:
    order = _order(client)
    assert client.get(f"/orders/{order['id']}").json()["notes"] is None


def test_ac_2_create_with_notes(client: TestClient) -> None:
    response = client.post("/orders", json={"customer_name": "G", "total_cents": 1, "notes": "Call before delivery"})
    assert response.status_code == 201 and response.json()["notes"] == "Call before delivery"


def test_ac_3_patch_trims_and_persists(client: TestClient) -> None:
    order = _order(client)
    patched = client.patch(f"/orders/{order['id']}", json={"notes": "  Leave with neighbour  "})
    assert patched.status_code == 200 and patched.json()["notes"] == "Leave with neighbour"
    assert client.get(f"/orders/{order['id']}").json()["notes"] == "Leave with neighbour"


def test_ac_4_empty_or_null_clears(client: TestClient) -> None:
    order = _order(client, notes="x")
    for value in ("", None):
        assert client.patch(f"/orders/{order['id']}", json={"notes": value}).json()["notes"] is None


def test_ac_5_invalid_patches(client: TestClient) -> None:
    order = _order(client, notes="keep")
    assert client.patch(f"/orders/{order['id']}", json={"notes": "x" * 2001}).status_code == 422
    assert client.patch(f"/orders/{order['id']}", json={"status": "paid"}).status_code == 422
    assert client.get(f"/orders/{order['id']}").json()["notes"] == "keep"
    assert client.patch("/orders/999", json={"notes": "x"}).status_code == 404


def test_ac_6_contract_declares_the_change() -> None:
    schemas = CONTRACT["components"]["schemas"]
    assert CONTRACT["info"]["version"] == "1.9.0"
    assert "notes" in schemas["Order"]["properties"] and "notes" in schemas["OrderCreate"]["properties"]
    assert "OrderUpdate" in schemas and "patch" in CONTRACT["paths"]["/orders/{order_id}"]


def test_ac_7_notes_is_never_required() -> None:
    assert all("notes" not in s.get("required", []) for s in CONTRACT["components"]["schemas"].values())
'''

NOTES_WEB_TESTS = """import { readFileSync } from "node:fs";
import { test } from "node:test";
import assert from "node:assert/strict";

const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), "utf8");
const detail = read("components/OrderDetail.tsx");
const editor = read("components/NotesEditor.tsx");
const table = read("components/OrdersTable.tsx");
const types = read("lib/types.ts");
const api = read("lib/api.ts");

test("AC-8 detail shows notes or No notes", () => {
  assert.match(detail, /<dt>Notes<\\/dt>/);
  assert.match(detail, /No notes/);
  assert.doesNotMatch(detail, /dangerouslySetInnerHTML/);
});

test("AC-9 editing saves through the API and Cancel discards", () => {
  assert.match(api, /method: "PATCH"/);
  assert.match(editor, />Save</);
  assert.match(editor, />Cancel</);
});

test("AC-10 labelled textarea, polite counter, alert on failure", () => {
  assert.match(editor, /<label htmlFor="notes">Notes<\\/label>/);
  assert.match(editor, /aria-live="polite"/);
  assert.match(editor, /role="alert"/);
});

test("AC-11 table shows a Has notes indicator only for non-empty notes", () => {
  assert.match(table, /order\\.notes \\?/);
  assert.match(table, /Has notes/);
});

test("AC-12 Order type mirrors the contract", () => {
  assert.match(types, /notes: string \\| null;/);
});
"""

NOTES_EDITOR = """"use client";

import { useState } from "react";

const LIMIT = 2000;

export function NotesEditor({ initial, save }: { initial: string | null; save: (notes: string) => Promise<void> }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(initial ?? "");
  const [error, setError] = useState<string | null>(null);
  if (!editing) {
    return <button onClick={() => setEditing(true)}>Edit notes</button>;
  }
  return (
    <form
      action={async () => {
        try {
          await save(text);
          setEditing(false);
        } catch {
          setError("Could not save the notes.");
        }
      }}
    >
      <label htmlFor="notes">Notes</label>
      <textarea id="notes" maxLength={LIMIT} value={text} onChange={(e) => setText(e.target.value)} />
      <p aria-live="polite">{LIMIT - text.length} characters left</p>
      {error && <p role="alert">{error}</p>}
      <button type="submit">Save</button>
      <button type="button" onClick={() => { setText(initial ?? ""); setEditing(false); }}>Cancel</button>
    </form>
  );
}
"""


class OrderNotesScript(OrdersPlatformScript):
    title = "Order notes"
    repo_hints = ["api", "web"]

    def work_planner(self, call: AgentCall) -> dict[str, Any]:
        return {
            "architecture_md": "# Architecture\n\nAdditive contract change in `api` (merged first), consumed by `web`.",
            "tasks": [
                {
                    "id": "TASK-001",
                    "title": "Order notes in the API and contract",
                    "repo": "api",
                    "owner_agent": "backend-dev",
                    "description": "notes on Order/OrderCreate, PATCH /orders/{id}, openapi 1.9.0, CORS PATCH.",
                    "files": ["app/models.py", "app/store.py", "app/routes/orders.py", "app/main.py", "openapi.yaml"],
                    "ac_ids": ["AC-1", "AC-2", "AC-3", "AC-4", "AC-5", "AC-6", "AC-7"],
                },
                {
                    "id": "TASK-002",
                    "title": "Notes on the order detail page",
                    "repo": "web",
                    "owner_agent": "frontend-dev",
                    "description": "Show and edit notes; has-notes indicator; types mirror the contract.",
                    "files": [
                        "lib/types.ts",
                        "lib/api.ts",
                        "components/OrderDetail.tsx",
                        "components/NotesEditor.tsx",
                        "components/OrdersTable.tsx",
                    ],
                    "depends_on": ["TASK-001"],
                    "ac_ids": ["AC-8", "AC-9", "AC-10", "AC-11", "AC-12"],
                },
            ],
            "activation_set": ["unit-test", "e2e-ui-test", "static-analysis", "security-scanner"],
            "merge_order": ["api", "web"],
        }

    def backend_dev(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["api"]
        edit(
            root,
            "app/models.py",
            "    total_cents: int = Field(ge=0)\n",
            "    total_cents: int = Field(ge=0)\n    notes: str | None = Field(default=None, max_length=2000)\n",
        )
        edit(
            root,
            "app/models.py",
            "from pydantic import BaseModel, Field\n",
            "from pydantic import BaseModel, ConfigDict, Field\n",
        )
        append(
            root,
            "app/models.py",
            '\n\nclass OrderUpdate(BaseModel):\n    model_config = ConfigDict(extra="forbid")\n'
            "\n    notes: str | None = Field(default=None, max_length=2000)\n",
        )
        append(root, "app/store.py", NOTES_STORE)
        edit(
            root,
            "app/routes/orders.py",
            "from app.models import Order, OrderCreate\n",
            "from app.models import Order, OrderCreate, OrderUpdate\n",
        )
        append(root, "app/routes/orders.py", NOTES_ROUTE)
        edit(root, "app/main.py", 'allow_methods=["GET", "POST"]', 'allow_methods=["GET", "POST", "PATCH"]')
        edit(root, "app/main.py", 'version="1.8.0"', 'version="1.9.0"')
        contract = "openapi.yaml"
        edit(root, contract, "  version: 1.8.0\n", "  version: 1.9.0\n")
        edit(
            root,
            contract,
            CONTRACT_PATHS_END,
            CONTRACT_PATHS_END.replace("components:\n", NOTES_CONTRACT_PATCH + "components:\n"),
        )
        edit(
            root,
            contract,
            "        total_cents: {type: integer, minimum: 0}\n",
            "        total_cents: {type: integer, minimum: 0}\n"
            '        notes: {type: [string, "null"], maxLength: 2000}\n',
        )
        edit(
            root,
            contract,
            "        created_at: {type: string, format: date-time}\n",
            '        created_at: {type: string, format: date-time}\n        notes: {type: [string, "null"]}\n',
        )
        append(
            root,
            contract,
            "    OrderUpdate:\n      type: object\n      additionalProperties: false\n"
            '      properties:\n        notes: {type: [string, "null"], maxLength: 2000}\n',
        )
        return {"summary": "notes + PATCH /orders/{id}", "files_changed": call.allowed_files}

    def frontend_dev(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["web"]
        edit(root, "lib/types.ts", "  created_at: string;\n", "  created_at: string;\n  notes: string | null;\n")
        append(
            root,
            "lib/api.ts",
            "\nexport async function updateOrderNotes(id: number, notes: string | null): "
            'Promise<Order> {\n  const response = await fetch(`${API_URL}/orders/${id}`, {\n    method: "PATCH",\n'
            '    headers: { "Content-Type": "application/json" },\n    body: JSON.stringify({ notes }),\n  });\n'
            "  if (!response.ok) {\n    throw new Error(`orders API returned ${response.status}`);\n  }\n"
            "  return (await response.json()) as Order;\n}\n",
        )
        edit(
            root,
            "components/OrderDetail.tsx",
            "        <dt>Placed</dt>\n",
            '        <dt>Notes</dt>\n        <dd style={{ whiteSpace: "pre-line" }}>{order.notes ?? '
            '<span className="muted">No notes</span>}</dd>\n        <dt>Placed</dt>\n',
        )
        write(root, "components/NotesEditor.tsx", NOTES_EDITOR)
        edit(
            root,
            "components/OrdersTable.tsx",
            "{order.customer_name}",
            '{order.customer_name}{order.notes ? <span className="has-notes" aria-hidden="false">'
            '<span className="visually-hidden">Has notes</span></span> : null}',
        )
        return {"summary": "notes on the detail page", "files_changed": call.allowed_files}

    def unit_test(self, call: AgentCall) -> dict[str, Any]:
        if "api" not in call.worktrees:
            return {"summary": "no API in this repo", "files_changed": []}
        write(call.worktrees["api"], "tests/test_notes.py", NOTES_TESTS)
        return {"summary": "API tests AC-1..AC-7", "files_changed": ["tests/test_notes.py"], "test_commands": [PYTEST]}

    def e2e_ui_test(self, call: AgentCall) -> dict[str, Any]:
        if "web" not in call.worktrees:
            return {"summary": "no UI in this repo", "files_changed": []}
        root = call.worktrees["web"]
        write(root, "tests/notes.test.mjs", NOTES_WEB_TESTS)
        append(root, ".gitignore", "test-results/\n")
        return {
            "summary": "UI checks AC-8..AC-12",
            "files_changed": ["tests/notes.test.mjs"],
            "test_commands": [NODE_TESTS],
        }


# ---------------------------------------------------------------- sprint: cancel + status (same files)

CANCEL_ROUTE = """

@router.post("/{order_id}/cancel", response_model=Order)
def cancel_order(order_id: int, request: Request, body: OrderCancel | None = None) -> Order:
    store = _store(request)
    order = store.get(order_id)
    if order is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"order {order_id} not found")
    if order.status == "shipped":
        raise HTTPException(status.HTTP_409_CONFLICT, f"order {order_id} has shipped and cannot be cancelled")
    return store.cancel(order_id)
"""

STATUS_ROUTE = """

@router.patch("/{order_id}/status", response_model=Order)
def update_order_status(order_id: int, body: OrderStatusUpdate, request: Request) -> Order:
    store = _store(request)
    order = store.get(order_id)
    if order is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"order {order_id} not found")
    allowed = {("pending", "paid"), ("paid", "shipped")}
    if order.status != body.status and (order.status, body.status) not in allowed:
        raise HTTPException(
            status.HTTP_409_CONFLICT, f"cannot change order {order_id} from {order.status} to {body.status}"
        )
    return store.set_status(order_id, body.status)
"""

CANCEL_STORE = """
    def cancel(self, order_id: int) -> Order:
        with self._lock:
            order = self._orders[order_id].model_copy(update={"status": "cancelled"})
            self._orders[order_id] = order
            return order
"""

STATUS_STORE = """
    def set_status(self, order_id: int, status: OrderStatus) -> Order:
        with self._lock:
            order = self._orders[order_id].model_copy(update={"status": status})
            self._orders[order_id] = order
            return order
"""

CANCEL_CONTRACT_PATH = """  /orders/{order_id}/cancel:
    post:
      operationId: cancelOrder
      parameters:
        - {name: order_id, in: path, required: true, schema: {type: integer}}
      requestBody:
        content:
          application/json:
            schema: {$ref: "#/components/schemas/OrderCancel"}
      responses:
        "200": {description: The cancelled order}
        "404": {description: Not found}
        "409": {description: Already shipped}
"""

STATUS_CONTRACT_PATH = """  /orders/{order_id}/status:
    patch:
      operationId: updateOrderStatus
      parameters:
        - {name: order_id, in: path, required: true, schema: {type: integer}}
      requestBody:
        required: true
        content:
          application/json:
            schema: {$ref: "#/components/schemas/OrderStatusUpdate"}
      responses:
        "200": {description: The updated order}
        "404": {description: Not found}
        "409": {description: Transition not allowed}
"""

CANCEL_TESTS = '''"""Cancel an order (sprint REQ A)."""

from __future__ import annotations

from fastapi.testclient import TestClient


def _order(client: TestClient, status: str = "pending") -> dict:
    order = client.post("/orders", json={"customer_name": "Ada", "total_cents": 100}).json()
    if status != "pending":
        store = client.app.state.store
        store._orders[order["id"]] = store._orders[order["id"]].model_copy(update={"status": status})
    return order


def test_ac_1_ac_2_cancel_pending_and_paid(client: TestClient) -> None:
    for status in ("pending", "paid"):
        order = _order(client, status)
        assert client.post(f"/orders/{order['id']}/cancel").json()["status"] == "cancelled"
        assert client.get(f"/orders/{order['id']}").json()["status"] == "cancelled"


def test_ac_3_shipped_cannot_be_cancelled(client: TestClient) -> None:
    order = _order(client, "shipped")
    response = client.post(f"/orders/{order['id']}/cancel")
    assert response.status_code == 409
    assert response.json()["detail"] == f"order {order['id']} has shipped and cannot be cancelled"


def test_ac_4_cancel_is_idempotent(client: TestClient) -> None:
    order = _order(client, "cancelled")
    assert client.post(f"/orders/{order['id']}/cancel").json()["status"] == "cancelled"


def test_ac_5_unknown_order_is_404(client: TestClient) -> None:
    assert client.post("/orders/404/cancel").json()["detail"] == "order 404 not found"


def test_ac_6_long_reason_is_422(client: TestClient) -> None:
    order = _order(client)
    assert client.post(f"/orders/{order['id']}/cancel", json={"reason": "x" * 501}).status_code == 422
'''

STATUS_TESTS = '''"""Update order status (sprint REQ B)."""

from __future__ import annotations

from fastapi.testclient import TestClient


def _order(client: TestClient) -> dict:
    return client.post("/orders", json={"customer_name": "Ada", "total_cents": 100}).json()


def test_ac_1_ac_2_forward_transitions(client: TestClient) -> None:
    order = _order(client)
    assert client.patch(f"/orders/{order['id']}/status", json={"status": "paid"}).json()["status"] == "paid"
    assert client.patch(f"/orders/{order['id']}/status", json={"status": "shipped"}).json()["status"] == "shipped"


def test_ac_3_skipping_a_step_is_409(client: TestClient) -> None:
    order = _order(client)
    response = client.patch(f"/orders/{order['id']}/status", json={"status": "shipped"})
    assert response.status_code == 409
    assert response.json()["detail"] == f"cannot change order {order['id']} from pending to shipped"


def test_ac_4_cancelled_is_not_a_status_update(client: TestClient) -> None:
    order = _order(client)
    assert client.patch(f"/orders/{order['id']}/status", json={"status": "cancelled"}).status_code == 422


def test_ac_5_same_status_is_a_noop(client: TestClient) -> None:
    order = _order(client)
    client.patch(f"/orders/{order['id']}/status", json={"status": "paid"})
    assert client.patch(f"/orders/{order['id']}/status", json={"status": "paid"}).json()["status"] == "paid"


def test_ac_6_unknown_order_is_404(client: TestClient) -> None:
    assert client.patch("/orders/404/status", json={"status": "paid"}).status_code == 404
'''


class SprintItemScript(OrdersPlatformScript):
    """One sprint item appending a route, a store method, a model and a contract path at the shared points."""

    repo_hints = ["api"]
    route = store = model = contract_path = contract_schema = tests = test_file = ""
    model_name = ""
    extra_files: list[str] = []

    def __init__(self, *, before_final_merge: Callable[[], Awaitable[None]] | None = None) -> None:
        super().__init__()
        self.before_final_merge = before_final_merge

    async def knowledge_capture(self, call: AgentCall) -> dict[str, Any]:
        """S9 runs right before the final trial merge: a test can hold the run here until another run has pushed."""
        if self.before_final_merge is not None:
            await self.before_final_merge()
        return super().knowledge_capture(call)

    def work_planner(self, call: AgentCall) -> dict[str, Any]:
        return {
            "architecture_md": f"# Architecture\n\n{self.title}: append to the orders route, store and contract.",
            "tasks": [
                {
                    "id": "TASK-001",
                    "title": self.title,
                    "repo": "api",
                    "owner_agent": "backend-dev",
                    "description": "Route at the end of app/routes/orders.py, store method, model and contract.",
                    "files": [
                        "app/routes/orders.py",
                        "app/store.py",
                        "app/models.py",
                        "openapi.yaml",
                        *self.extra_files,
                    ],
                    "ac_ids": self.ac_ids(call),
                }
            ],
            "activation_set": ["unit-test", "static-analysis"],
        }

    def backend_dev(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["api"]
        # A new import line (not an edit of the shared one) keeps the two sprint items pure additions.
        edit(
            root,
            "app/routes/orders.py",
            "from app.models import Order, OrderCreate\n",
            f"from app.models import Order, OrderCreate\nfrom app.models import {self.model_name}\n",
        )
        append(root, "app/routes/orders.py", self.route)
        append(root, "app/store.py", self.store)
        append(root, "app/models.py", self.model)
        edit(
            root,
            "openapi.yaml",
            CONTRACT_PATHS_END,
            CONTRACT_PATHS_END.replace("components:\n", self.contract_path + "components:\n"),
        )
        append(root, "openapi.yaml", self.contract_schema)
        self.extra_edits(root)
        return {"summary": self.title, "files_changed": call.allowed_files}

    def extra_edits(self, root: str) -> None:
        return None

    def unit_test(self, call: AgentCall) -> dict[str, Any]:
        write(call.worktrees["api"], self.test_file, self.tests)
        return {"summary": "API tests", "files_changed": [self.test_file], "test_commands": [PYTEST]}


class CancelScript(SprintItemScript):
    title = "Cancel an order"
    route, store, tests, test_file = CANCEL_ROUTE, CANCEL_STORE, CANCEL_TESTS, "tests/test_cancel.py"
    model = "\n\nclass OrderCancel(BaseModel):\n    reason: str | None = Field(default=None, max_length=500)\n"
    model_name = "OrderCancel"
    contract_path = CANCEL_CONTRACT_PATH
    contract_schema = (
        "    OrderCancel:\n      type: object\n      properties:\n        reason: {type: string, maxLength: 500}\n"
    )


class StatusScript(SprintItemScript):
    title = "Update order status"
    route, store, tests, test_file = STATUS_ROUTE, STATUS_STORE, STATUS_TESTS, "tests/test_status.py"
    model = '\n\nclass OrderStatusUpdate(BaseModel):\n    status: Literal["paid", "shipped"]\n'
    model_name = "OrderStatusUpdate"
    contract_path = STATUS_CONTRACT_PATH
    contract_schema = (
        "    OrderStatusUpdate:\n      type: object\n      required: [status]\n      properties:\n"
        "        status: {type: string, enum: [paid, shipped]}\n"
    )
    extra_files = ["app/main.py"]

    def extra_edits(self, root: str) -> None:
        edit(
            root,
            "app/store.py",
            "from app.models import Order, OrderCreate\n",
            "from app.models import Order, OrderCreate\nfrom app.models import OrderStatus\n",
        )
        edit(root, "app/main.py", 'allow_methods=["GET", "POST"]', 'allow_methods=["GET", "POST", "PATCH"]')


class ReleaseCancelScript(CancelScript):
    """Like ``CancelScript`` but also bumps the API version: an edit of an existing line."""

    extra_files = ["app/main.py"]

    def extra_edits(self, root: str) -> None:
        edit(root, "app/main.py", 'version="1.8.0"', 'version="1.9.0"')


class ReleaseStatusScript(StatusScript):
    """Like ``StatusScript`` but bumps the same version line differently: conflict_bound must refuse this."""

    def extra_edits(self, root: str) -> None:
        super().extra_edits(root)
        edit(root, "app/main.py", 'version="1.8.0"', 'version="1.10.0"')
