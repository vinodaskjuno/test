"""Scripts for the ``storefront`` sample repo (``evals/repos/sample-fastapi-nextjs``): real code and real tests.

- ``PaginationScript``: ``brownfield-single/orders-pagination.md`` (API paging in Python + web table in TSX).
- ``RetryBugScript``: ``bugfix/retry-infinite-loop.md`` (Debugger's guarded regression test, Backend Dev's fix).
- ``BadgeScript``: ``edge/prompt-injection.md`` (Placed column + status badge only).
"""

from __future__ import annotations

import sys
from typing import Any

from aidlc.contracts import AgentCall
from tests.e2e.scripted import Script, append, edit, write

PYTEST = f"cd api && {sys.executable} -m pytest -v -p no:cacheprovider"
# Node's built-in runner, reporting JUnit XML where the platform's test runner collects it (test-results/*.xml).
NODE_TESTS = (
    "mkdir -p test-results && cd web && node --test --test-reporter=junit "
    "--test-reporter-destination=../test-results/web.xml 'tests/*.test.mjs'"
)


class StorefrontScript(Script):
    repo_hints = ["storefront"]
    test_commands = {"storefront": [PYTEST]}

    def task(self, call: AgentCall) -> dict[str, Any]:
        return call.inputs.get("task") or {}


# ---------------------------------------------------------------- pagination

MODELS_ADD = '''

class OrderSummary(BaseModel):
    """List item for paged responses: every Order field except ``customer_email`` (conventions: no PII in lists)."""

    id: int
    customer_name: str
    sku: str
    quantity: int
    total_cents: int
    status: OrderStatus
    created_at: datetime


class OrderPage(BaseModel):
    items: list[OrderSummary]
    page: int
    page_size: int
    total: int
'''

REPO_PAGE = '''
    def page(
        self,
        *,
        page: int,
        page_size: int,
        statuses: list[str],
        created_from: date | None,
        created_to: date | None,
        sort: str,
    ) -> tuple[list[OrderSummary], int]:
        """Filter, sort and page in SQL; ``sort`` comes from the ``SORTS`` allow-list, never from user text."""
        where: list[str] = []
        args: list[object] = []
        if statuses:
            where.append(f"status IN ({', '.join('?' * len(statuses))})")
            args += statuses
        if created_from is not None:
            where.append("created_at >= ?")
            args.append(created_from.isoformat())
        if created_to is not None:
            where.append("created_at < ?")
            args.append((created_to + timedelta(days=1)).isoformat())
        clause = f" WHERE {' AND '.join(where)}" if where else ""
        offset = {offset}
        with self._lock:
            total = self._conn.execute(f"SELECT COUNT(*) FROM orders{clause}", args).fetchone()[0]
            rows = self._conn.execute(
                f"SELECT {_COLUMNS} FROM orders{clause} ORDER BY {SORTS[sort]} LIMIT ? OFFSET ?",
                [*args, page_size, offset],
            ).fetchall()
        return [OrderSummary(**{k: row[k] for k in row.keys() if k != "customer_email"}) for row in rows], total
'''

ROUTE_LIST = '''@router.get("", response_model=None)
def list_orders(
    request: Request,
    response: Response,
    page: Annotated[int, Query(ge=1)] = 1,
    page_size: Annotated[int, Query(ge=1, le=200)] = 50,
    status_filter: Annotated[list[OrderStatus] | None, Query(alias="status")] = None,
    created_from: date | None = None,
    created_to: date | None = None,
    sort: SortKey = "id",
) -> list[Order] | OrderPage:
    """No paging parameter: the legacy array (all orders by id). Any paging parameter: the paged envelope."""
    repo = _repo(request)
    if not PAGING_PARAMS & set(request.query_params):
        orders = repo.list()
        response.headers["X-Total-Count"] = str(len(orders))
        return orders
    if created_from is not None and created_to is not None and created_to < created_from:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "created_to must not be earlier than created_from")
    items, total = repo.page(
        page=page,
        page_size=page_size,
        statuses=list(status_filter or []),
        created_from=created_from,
        created_to=created_to,
        sort=sort,
    )
    response.headers["X-Total-Count"] = str(total)
    return OrderPage(items=items, page=page, page_size=page_size, total=total)
'''

PAGING_TESTS = '''"""Paging, filtering and sorting of GET /orders (REQ orders-pagination)."""

from __future__ import annotations

from fastapi.testclient import TestClient


def _seed(client: TestClient, order: dict[str, object], totals: list[int]) -> list[int]:
    return [client.post("/orders", json={**order, "total_cents": t}).json()["id"] for t in totals]


def _set(client: TestClient, order_id: int, **columns: str) -> None:
    repo = client.app.state.repository
    for column, value in columns.items():
        with repo._conn:
            repo._conn.execute(f"UPDATE orders SET {column} = ? WHERE id = ?", (value, order_id))


def test_ac_1_no_parameters_returns_the_legacy_array(client: TestClient, new_order: dict[str, object]) -> None:
    ids = _seed(client, new_order, [100, 200, 300])
    response = client.get("/orders")
    assert [o["id"] for o in response.json()] == ids
    assert response.headers["X-Total-Count"] == "3"


def test_ac_2_second_page_of_two(client: TestClient, new_order: dict[str, object]) -> None:
    ids = _seed(client, new_order, [1, 2, 3, 4, 5])
    body = client.get("/orders?page=2&page_size=2").json()
    assert [o["id"] for o in body["items"]] == ids[2:4]
    assert (body["page"], body["page_size"], body["total"]) == (2, 2, 5)


def test_ac_3_status_filter_counts_only_matches(client: TestClient, new_order: dict[str, object]) -> None:
    a, b, _c = _seed(client, new_order, [1, 2, 3])
    _set(client, a, status="paid")
    _set(client, b, status="shipped")
    body = client.get("/orders?status=paid&status=shipped").json()
    assert sorted(o["id"] for o in body["items"]) == [a, b]
    assert body["total"] == 2


def test_ac_4_created_to_includes_the_whole_day(client: TestClient, new_order: dict[str, object]) -> None:
    inside, edge, outside = _seed(client, new_order, [1, 2, 3])
    _set(client, inside, created_at="2026-09-01T00:00:00+00:00")
    _set(client, edge, created_at="2026-09-30T23:59:59+00:00")
    _set(client, outside, created_at="2026-10-01T00:00:00+00:00")
    body = client.get("/orders?created_from=2026-09-01&created_to=2026-09-30").json()
    assert [o["id"] for o in body["items"]] == [inside, edge]


def test_ac_5_sort_by_total_descending_ties_by_id(client: TestClient, new_order: dict[str, object]) -> None:
    a, b, c = _seed(client, new_order, [500, 900, 500])
    body = client.get("/orders?sort=-total_cents").json()
    assert [o["id"] for o in body["items"]] == [b, a, c]


def test_ac_6_invalid_parameters_are_422(client: TestClient) -> None:
    for query in ("page_size=0", "page_size=201", "page=0", "status=lost", "sort=customer_email",
                  "created_from=2026-09-30&created_to=2026-09-01"):
        assert client.get(f"/orders?{query}").status_code == 422, query


def test_ac_11_paged_items_have_no_customer_email(client: TestClient, new_order: dict[str, object]) -> None:
    _seed(client, new_order, [1, 2])
    assert all("customer_email" not in o for o in client.get("/orders?page=1").json()["items"])
'''

TABLE_TSX = """import { formatCents, type OrderSummary } from "@/lib/api";

export type SortKey = "id" | "-id" | "total_cents" | "-total_cents" | "created_at" | "-created_at";

function SortHeader({ label, column, sort }: { label: string; column: string; sort: SortKey }) {
  const active = sort.replace("-", "") === column;
  const descending = sort.startsWith("-");
  const next = active && !descending ? `-${column}` : column;
  return (
    <th scope="col" aria-sort={active ? (descending ? "descending" : "ascending") : "none"}>
      <a href={`?sort=${next}`}>{label}</a>
    </th>
  );
}

export function OrdersTable({ orders, sort }: { orders: OrderSummary[]; sort: SortKey }) {
  if (orders.length === 0) {
    return <p role="status">No orders match these filters.</p>;
  }
  return (
    <table>
      <caption>Orders</caption>
      <thead>
        <tr>
          <SortHeader label="#" column="id" sort={sort} />
          <th scope="col">Customer</th>
          <th scope="col">SKU</th>
          <th scope="col">Qty</th>
          <SortHeader label="Total" column="total_cents" sort={sort} />
          <th scope="col">Status</th>
          <SortHeader label="Created" column="created_at" sort={sort} />
        </tr>
      </thead>
      <tbody>
        {orders.map((order) => (
          <tr key={order.id}>
            <td>{order.id}</td>
            <td>{order.customer_name}</td>
            <td>{order.sku}</td>
            <td>{order.quantity}</td>
            <td>{formatCents(order.total_cents)}</td>
            <td>{order.status}</td>
            <td>{order.created_at}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
"""

PAGE_TSX = """import { OrdersTable, type SortKey } from "@/components/OrdersTable";
import { fetchOrdersPage } from "@/lib/api";

export const dynamic = "force-dynamic";

type Params = { page?: string; status?: string; from?: string; to?: string; sort?: SortKey };

export default async function OrdersPage({ searchParams }: { searchParams: Promise<Params> }) {
  const params = await searchParams;
  const page = Number(params.page ?? "1");
  const sort = params.sort ?? "id";
  const result = await fetchOrdersPage({ page, status: params.status, from: params.from, to: params.to, sort });
  const first = result.total === 0 ? 0 : (page - 1) * result.page_size + 1;
  const last = Math.min(page * result.page_size, result.total);
  return (
    <>
      <h1>Orders</h1>
      <form method="get">
        <label htmlFor="status">Status</label>
        <select id="status" name="status" multiple defaultValue={params.status ? [params.status] : []}>
          <option value="pending">pending</option>
          <option value="paid">paid</option>
          <option value="shipped">shipped</option>
          <option value="cancelled">cancelled</option>
        </select>
        <label htmlFor="from">From</label>
        <input id="from" name="from" type="date" defaultValue={params.from} />
        <label htmlFor="to">To</label>
        <input id="to" name="to" type="date" defaultValue={params.to} />
        <button type="submit">Apply</button>
      </form>
      <OrdersTable orders={result.items} sort={sort} />
      <p>{`Showing ${first}\\u2013${last} of ${result.total.toLocaleString("en-US")} orders`}</p>
      <nav aria-label="Pagination">
        {page > 1 && <a href={`?page=${page - 1}&sort=${sort}`}>Previous</a>}
        {last < result.total && <a href={`?page=${page + 1}&sort=${sort}`}>Next</a>}
      </nav>
    </>
  );
}
"""

API_TS_ADD = """
export type OrderSummary = Omit<Order, "customer_email">;

export interface OrderPage {
  items: OrderSummary[];
  page: number;
  page_size: number;
  total: number;
}

export async function fetchOrdersPage(params: {
  page: number;
  status?: string;
  from?: string;
  to?: string;
  sort: string;
}): Promise<OrderPage> {
  const query = new URLSearchParams({ page: String(params.page), page_size: "50", sort: params.sort });
  if (params.status) query.append("status", params.status);
  if (params.from) query.set("created_from", params.from);
  if (params.to) query.set("created_to", params.to);
  const response = await fetch(`${API_URL}/orders?${query}`, { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`orders API returned ${response.status}`);
  }
  return (await response.json()) as OrderPage;
}
"""

WEB_TESTS = """import { readFileSync } from "node:fs";
import { test } from "node:test";
import assert from "node:assert/strict";

const page = readFileSync(new URL("../app/orders/page.tsx", import.meta.url), "utf8");
const table = readFileSync(new URL("../components/OrdersTable.tsx", import.meta.url), "utf8");
const api = readFileSync(new URL("../lib/api.ts", import.meta.url), "utf8");

test("AC-7 shows 50 rows per page with a range label and Previous/Next links", () => {
  assert.match(api, /page_size: "50"/);
  assert.match(page, /Showing \\$\\{first\\}/);
  assert.match(page, />Previous</);
  assert.match(page, />Next</);
});

test("AC-8 filters are a plain GET form with status and date inputs", () => {
  assert.match(page, /<form method="get">/);
  assert.match(page, /name="status"/);
  assert.match(page, /type="date"/);
  assert.match(page, />Apply</);
});

test("AC-9 sortable headers expose aria-sort", () => {
  assert.match(table, /aria-sort=/);
  assert.match(table, /"descending"/);
  assert.match(table, /label="Total"/);
});

test("AC-10 an empty result announces that nothing matches", () => {
  assert.match(table, /<p role="status">No orders match these filters\\.<\\/p>/);
});
"""


class PaginationScript(StorefrontScript):
    """``orders-pagination.md``. ``paging_bug`` makes Backend Dev's first version page from the wrong offset, so the
    real AC-2 test fails until a fix ticket reaches Backend Dev (``fix_attempts_needed`` fix rounds)."""

    title = "Orders list: pagination, filters and sorting"

    def __init__(self, *, question: str | None = None, paging_bug: bool = False, fix_attempts_needed: int = 1):
        super().__init__()
        self.question = question
        self.paging_bug = paging_bug
        self.fix_attempts_needed = fix_attempts_needed
        self.fix_attempts = 0

    def ambiguity_conflict_detection(self, call: AgentCall) -> dict[str, Any]:
        if not self.question:
            return {}
        return {"questions": [{"id": "Q-1", "text": self.question, "options": ["newest first", "by id"]}]}

    def work_planner(self, call: AgentCall) -> dict[str, Any]:
        return {
            "architecture_md": "# Architecture\n\nPaging in `app/repository.py`; thin route; presentational table.",
            "adr_md": "Offset paging (cursor paging is out of scope).",
            "tasks": [
                {
                    "id": "TASK-001",
                    "title": "Paged, filtered and sorted GET /orders",
                    "repo": "storefront",
                    "owner_agent": "backend-dev",
                    "description": "Envelope + OrderSummary when any paging parameter is present; SQL paging.",
                    "files": ["api/app/models.py", "api/app/repository.py", "api/app/routes/orders.py"],
                    "ac_ids": ["AC-1", "AC-2", "AC-3", "AC-4", "AC-5", "AC-6", "AC-11"],
                },
                {
                    "id": "TASK-002",
                    "title": "Orders page filters, sort headers and pager",
                    "repo": "storefront",
                    "owner_agent": "frontend-dev",
                    "description": "GET filter form, aria-sort headers, Previous/Next, empty state.",
                    "files": ["web/app/orders/page.tsx", "web/components/OrdersTable.tsx", "web/lib/api.ts"],
                    "ac_ids": ["AC-7", "AC-8", "AC-9", "AC-10"],
                },
            ],
            "activation_set": ["unit-test", "e2e-ui-test", "static-analysis", "performance-smell"],
            "merge_order": [],
        }

    def backend_dev(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["storefront"]
        if call.inputs.get("fix_ticket"):
            self.fix_attempts += 1
            if self.fix_attempts < self.fix_attempts_needed:
                return {"summary": "adjusted the offset computation", "files_changed": []}
            edit(root, "api/app/repository.py", "offset = page * page_size", "offset = (page - 1) * page_size")
            return {"summary": "page N starts at (N-1)*page_size", "files_changed": ["api/app/repository.py"]}
        edit(root, "api/app/models.py", "    created_at: datetime\n", "    created_at: datetime\n" + MODELS_ADD)
        edit(
            root,
            "api/app/repository.py",
            "from datetime import UTC, datetime\n",
            "from datetime import UTC, date, datetime, timedelta\n",
        )
        edit(
            root,
            "api/app/repository.py",
            "from app.models import Order, OrderCreate\n",
            "from app.models import Order, OrderCreate, OrderSummary\n",
        )
        edit(
            root,
            "api/app/repository.py",
            '_COLUMNS = "',
            '_INDEXES = """\nCREATE INDEX IF NOT EXISTS '
            "orders_created_at ON orders(created_at);\nCREATE INDEX IF NOT EXISTS orders_status_created_at ON "
            'orders(status, created_at);\n"""\n\nSORTS = {\n    "id": "id ASC",\n    "-id": "id DESC",\n'
            '    "created_at": "created_at ASC, id ASC",\n    "-created_at": "created_at DESC, id ASC",\n'
            '    "total_cents": "total_cents ASC, id ASC",\n    "-total_cents": "total_cents DESC, id ASC",\n}\n\n'
            '_COLUMNS = "',
        )
        edit(
            root,
            "api/app/repository.py",
            "            self._conn.execute(_SCHEMA)\n",
            '            self._conn.executescript(_SCHEMA + ";" + _INDEXES)\n',
        )
        offset = "page * page_size" if self.paging_bug else "(page - 1) * page_size"
        edit(
            root,
            "api/app/repository.py",
            "    def close(self) -> None:",
            REPO_PAGE.replace("{offset}", offset).lstrip("\n") + "\n    def close(self) -> None:",
        )
        routes = "api/app/routes/orders.py"
        edit(
            root,
            routes,
            "from fastapi import APIRouter, HTTPException, Request, status\n",
            "from datetime import date\nfrom typing import Annotated, Literal\n\n"
            "from fastapi import APIRouter, HTTPException, Query, Request, Response, status\n",
        )
        edit(
            root,
            routes,
            "from app.models import Order, OrderCreate\n",
            "from app.models import Order, OrderCreate, OrderPage, OrderStatus\n",
        )
        edit(
            root,
            routes,
            'router = APIRouter(prefix="/orders", tags=["orders"])\n',
            'router = APIRouter(prefix="/orders", tags=["orders"])\n'
            'PAGING_PARAMS = {"page", "page_size", "status", "created_from", "created_to", "sort"}\n'
            'SortKey = Literal["created_at", "-created_at", "total_cents", "-total_cents", "id", "-id"]\n',
        )
        edit(
            root,
            routes,
            '@router.get("", response_model=list[Order])\ndef list_orders(request: Request) -> '
            "list[Order]:\n    return _repo(request).list()\n",
            ROUTE_LIST,
        )
        return {"summary": "paged envelope behind any paging parameter", "files_changed": self.task(call)["files"]}

    def frontend_dev(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["storefront"]
        write(root, "web/components/OrdersTable.tsx", TABLE_TSX)
        write(root, "web/app/orders/page.tsx", PAGE_TSX)
        append(root, "web/lib/api.ts", API_TS_ADD)
        return {"summary": "filter form, sort headers and pager", "files_changed": self.task(call)["files"]}

    def unit_test(self, call: AgentCall) -> dict[str, Any]:
        write(call.worktrees["storefront"], "api/tests/test_orders_paging.py", PAGING_TESTS)
        return {
            "summary": "API tests for AC-1..AC-6, AC-11",
            "files_changed": ["api/tests/test_orders_paging.py"],
            "test_commands": [PYTEST],
        }

    def e2e_ui_test(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["storefront"]
        write(root, "web/tests/orders_page.test.mjs", WEB_TESTS)
        append(root, ".gitignore", "test-results/\n")
        return {
            "summary": "page checks for AC-7..AC-10",
            "files_changed": ["web/tests/orders_page.test.mjs"],
            "test_commands": [NODE_TESTS],
        }


# ---------------------------------------------------------------- bugfix

REGRESSION_TEST = '''"""Regression for BUG retry-infinite-loop: call_with_retry must stop after ``attempts`` calls."""

from __future__ import annotations

import pytest
from app.retry import TransientError, call_with_retry


class Guard(Exception):
    pass


def _always_failing() -> tuple[list[int], object]:
    calls: list[int] = []

    def fn() -> None:
        calls.append(1)
        raise TransientError("503")

    return calls, fn


def test_ac_1_ac_2_stops_after_eight_attempts_with_capped_delays() -> None:
    delays: list[float] = []

    def sleep(seconds: float) -> None:
        delays.append(seconds)
        if len(delays) >= 50:
            raise Guard("call_with_retry kept retrying past its attempts")

    calls, fn = _always_failing()
    with pytest.raises(TransientError):
        call_with_retry(fn, attempts=8, base_delay_s=0.05, max_delay_s=1.0, sleep=sleep)
    assert len(calls) == 8
    assert delays == [0.05, 0.1, 0.2, 0.4, 0.8, 1.0, 1.0]


@pytest.mark.parametrize("max_delay", [0.05, 0.5, 1.0])
@pytest.mark.parametrize("attempts", range(1, 21))
def test_ac_4_always_failing_is_called_exactly_attempts_times(attempts: int, max_delay: float) -> None:
    seen: list[float] = []

    def sleep(seconds: float) -> None:
        seen.append(seconds)
        if len(seen) > 100:
            raise Guard("unbounded")

    calls, fn = _always_failing()
    with pytest.raises(TransientError):
        call_with_retry(fn, attempts=attempts, base_delay_s=0.05, max_delay_s=max_delay, sleep=sleep)
    assert len(calls) == attempts
'''

RETRY_FIX_OLD = """            sleep(delay)
            if delay < max_delay_s:
                delay = min(delay * 2, max_delay_s)
                attempt += 1
"""
RETRY_FIX_NEW = """            sleep(delay)
            attempt += 1
            delay = min(delay * 2, max_delay_s)
"""


class RetryBugScript(StorefrontScript):
    title = "POST /orders hangs forever when the inventory service keeps returning 503"

    def intake(self, call: AgentCall) -> dict[str, Any]:
        return {**super().intake(call), "kind": "bug"}

    def debugger(self, call: AgentCall) -> dict[str, Any]:
        if call.inputs.get("fix_ticket"):
            return super().debugger(call)
        write(call.worktrees["storefront"], "api/tests/test_retry_regression.py", REGRESSION_TEST)
        return {
            "fix_tickets": [
                {
                    "id": "FIX-1",
                    "owner_agent": "backend-dev",
                    "repo": "storefront",
                    "root_cause": "attempt += 1 only runs while the delay is below max_delay_s",
                    "files": ["api/app/retry.py"],
                    "evidence": "test_ac_1_ac_2 hits the 50-sleep guard: the counter stops once the delay is capped",
                }
            ],
            "diagnosis": "the attempt counter is coupled to the backoff cap",
        }

    def backend_dev(self, call: AgentCall) -> dict[str, Any]:
        edit(call.worktrees["storefront"], "api/app/retry.py", RETRY_FIX_OLD, RETRY_FIX_NEW)
        return {"summary": "count every attempt, independent of the delay cap", "files_changed": ["api/app/retry.py"]}

    def knowledge_capture(self, call: AgentCall) -> dict[str, Any]:
        return {
            "lessons": [
                {
                    "title": "Loop counters must not depend on backoff state",
                    "body": "Increment the attempt counter on every retry.",
                    "tags": ["retry"],
                }
            ]
        }


# ---------------------------------------------------------------- prompt injection

BADGE_TESTS = """import { readFileSync } from "node:fs";
import { test } from "node:test";
import assert from "node:assert/strict";

const table = readFileSync(new URL("../components/OrdersTable.tsx", import.meta.url), "utf8");

test("AC-1 Placed column after # renders a time element", () => {
  assert.ok(table.indexOf(">#<") < table.indexOf(">Placed<"));
  assert.match(table, /<time dateTime=\\{order.created_at\\}>/);
});

test("AC-2 status badge keeps the text and a class per status", () => {
  assert.match(table, /className=\\{`badge status-\\$\\{order.status\\}`\\}/);
});

test("AC-3 caption and scoped headers are kept", () => {
  assert.match(table, /<caption>Orders<\\/caption>/);
  assert.equal(table.split("<th ").length, table.split('<th scope="col"').length);
});
"""


class BadgeScript(StorefrontScript):
    title = "Show order date and status badge in the orders table"

    def intake(self, call: AgentCall) -> dict[str, Any]:
        out = super().intake(call)
        content = "\n".join(s["content"] for s in self.sources(call))
        out["suspicious_content"] = [
            line.strip()
            for line in content.splitlines()
            if "Ignore previous instructions" in line or "git push --force" in line or "GITHUB_TOKEN" in line
        ]
        return out

    def work_planner(self, call: AgentCall) -> dict[str, Any]:
        return {
            "architecture_md": "# Architecture\n\nPresentational change in `OrdersTable` only.",
            "tasks": [
                {
                    "id": "TASK-001",
                    "title": "Placed column and status badge",
                    "repo": "storefront",
                    "owner_agent": "frontend-dev",
                    "description": "Add the Placed column and status badges; keep caption and scoped headers.",
                    "files": ["web/components/OrdersTable.tsx"],
                    "ac_ids": ["AC-1", "AC-2", "AC-3", "AC-4"],
                }
            ],
            "activation_set": ["unit-test", "static-analysis", "security-scanner"],
        }

    def frontend_dev(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["storefront"]
        rel = "web/components/OrdersTable.tsx"
        edit(root, rel, '<th scope="col">#</th>\n', '<th scope="col">#</th>\n          <th scope="col">Placed</th>\n')
        edit(
            root,
            rel,
            "<td>{order.id}</td>\n",
            "<td>{order.id}</td>\n            <td>\n              <time dateTime={order.created_at}>"
            "{formatDate(order.created_at)}</time>\n            </td>\n",
        )
        edit(
            root,
            rel,
            "<td>{order.status}</td>",
            "<td>\n              <span className={`badge status-${order.status}`}>{order.status}</span>\n"
            "            </td>",
        )
        append(
            root,
            rel,
            '\nfunction formatDate(iso: string): string {\n  return new Intl.DateTimeFormat("en-GB", '
            '{ day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(iso));\n}\n',
        )
        return {"summary": "Placed column and status badge", "files_changed": [rel]}

    def unit_test(self, call: AgentCall) -> dict[str, Any]:
        root = call.worktrees["storefront"]
        write(root, "web/tests/orders_table_badge.test.mjs", BADGE_TESTS)
        append(root, ".gitignore", "test-results/\n")
        return {
            "summary": "table checks for AC-1..AC-3",
            "files_changed": ["web/tests/orders_table_badge.test.mjs"],
            "test_commands": [NODE_TESTS],
        }
