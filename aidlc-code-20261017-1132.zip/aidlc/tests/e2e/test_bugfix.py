"""Bugfix on the seeded infinite retry loop: the bug really hangs, the Debugger's test really fails, the fix passes."""

from __future__ import annotations

import subprocess
import sys
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from pathlib import Path

import pytest

from aidlc.platform import db
from aidlc.platform.sandbox.local import LocalExecutor
from tests.e2e.conftest import SPECS
from tests.e2e.harness import Stack, rows
from tests.e2e.storefront import RetryBugScript

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]

# What production does with ORDERS_RETRY_ATTEMPTS=8 and an inventory service stuck on 503 (no guard, no-op sleep).
UNGUARDED = (
    "from app.retry import TransientError, call_with_retry\n"
    "calls = []\n"
    "def fn():\n    calls.append(1)\n    raise TransientError('503')\n"
    "try:\n    call_with_retry(fn, attempts=8, base_delay_s=0.05, max_delay_s=1.0, sleep=lambda s: None)\n"
    "except TransientError:\n    print('calls', len(calls))\n"
)


def git(cwd: Path | str, *args: str) -> str:
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout


async def test_seeded_retry_bug_is_reproduced_fixed_and_delivered(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]], tmp_path: Path
) -> None:
    async with stack_for(RetryBugScript()) as stack:
        remote = stack.remote("sample-fastapi-nextjs")
        executor = LocalExecutor()
        api_main = stack.samples / "sample-fastapi-nextjs" / "api"
        hung = await executor.run([sys.executable, "-c", UNGUARDED], api_main, timeout_s=3)
        assert hung.timed_out and "killed after 3s timeout" in hung.stderr  # the seeded bug never returns

        await stack.create_project("storefront", [{"id": "storefront", "url": remote, "primary": True}])
        uploaded = await stack.upload("storefront", SPECS / "bugfix" / "retry-infinite-loop.md", kind="bug")
        run_id = uploaded["run"]["id"]
        assert uploaded["run"]["kind"] == "bugfix" and uploaded["run"]["work_item_id"] == "BUG-001"

        view = await stack.wait_run(run_id, lambda v: v["state"]["stage"] == "gate_b", "bugfix PR ready")
        assert view["state"]["outcome"] == "pr-ready"

        # Reproduction: the Debugger's guarded regression test ran for real and failed against the seeded bug.
        [reproduced] = [e for e in rows(db.RunEventRow, run_id=run_id, type="log") if e.message == "bug reproduced"]
        assert reproduced.stage == "reproduce"
        assert (
            "tests/test_retry_regression.py::test_ac_1_ac_2_stops_after_eight_attempts_with_capped_delays"
            in (reproduced.data["failing"])
        )
        assert any("[8-1.0]" in t or "[8-0.05]" in t for t in reproduced.data["failing"])
        fixes = [r for r in stack.backend.called("backend-dev", run_id)]
        assert len(fixes) == 1 and fixes[0].call.inputs["fix_ticket"]["files"] == ["api/app/retry.py"]

        # After the fix the same tests pass on the first quality iteration; nothing else needed fixing.
        assert [(g["gate"], g["passed"]) for g in view["state"]["gates"]] == [
            ("A", True),
            ("quality", True),
            ("trial_merge_final", True),
        ]
        tests = {t["id"]: t["status"] for t in view["tests"]}
        assert (
            tests["tests/test_retry_regression.py::test_ac_1_ac_2_stops_after_eight_attempts_with_capped_delays"]
            == "pass"
        )
        assert tests["tests/test_retry.py::test_retries_then_succeeds_with_doubling_delays"] == "pass"  # AC-6
        assert sum(t.startswith("tests/test_retry_regression.py::test_ac_4") for t in tests) == 60
        assert all(r["passed"] for r in view["traceability"] if r["tests"])
        assert set(stack.backend.agents(run_id)) >= {
            "intake",
            "spec-analyst",
            "debugger",
            "backend-dev",
            "runtime-hazard",
            "correctness-reviewer",
            "review-judge",
            "pr",
        }
        assert "spec-validator" not in stack.backend.agents(run_id)  # the bug flow has no V1

        [pr] = view["prs"]
        branch = next(r.head for r in rows(db.LocalPR, repo_url=remote) if r.number == pr["number"])
        log = git(remote, "log", "--format=%s", f"main..{branch}").splitlines()
        assert log.index("fix: FIX-1") < log.index("test: reproduce bug")  # newest first: test before the fix
        files = git(remote, "ls-tree", "-r", "--name-only", branch).split()
        assert any(f.startswith(".adlc/bugs/BUG-001-") and f.endswith(".md") for f in files)
        assert "api/tests/test_retry_regression.py" in files
        assert git(remote, "diff", "--name-only", f"main...{branch}", "--", "api/app").split() == ["api/app/retry.py"]

        # The delivered branch no longer hangs.
        checkout = tmp_path / "fixed"
        git(tmp_path, "clone", "--quiet", "--branch", branch, remote, str(checkout))
        fixed = await executor.run([sys.executable, "-c", UNGUARDED], checkout / "api", timeout_s=30)
        assert not fixed.timed_out and fixed.exit_code == 0 and fixed.stdout.strip() == "calls 8"

        await stack.merge_pr(pr)
        done = await stack.wait_run(run_id, lambda v: v["state"]["stage"] == "done", "bugfix merged")
        assert done["state"]["outcome"] == "pr-ready"
        lessons = await stack.get("/knowledge?project_id=storefront&kind=lesson")
        assert [k["title"] for k in lessons] == ["Loop counters must not depend on backoff state"]
