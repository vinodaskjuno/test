"""Health audit -> ranked findings and backlog drafts; VerifyBranch (``aidlc local submit``) -> aidlc/gates status."""

from __future__ import annotations

import subprocess
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from pathlib import Path
from typing import Any

import pytest

from aidlc.contracts import AgentCall
from aidlc.platform import db
from aidlc.platform.forge.local import LocalForge
from tests.e2e.harness import CONTRIBUTOR, VIEWER, Stack, rows
from tests.e2e.storefront import StorefrontScript

pytestmark = [pytest.mark.e2e, pytest.mark.temporal]


def git(cwd: Path | str, *args: str) -> str:
    cmd = ["git", "-c", "user.name=Dev", "-c", "user.email=dev@acme.test", *args]
    return subprocess.run(cmd, cwd=cwd, check=True, capture_output=True, text=True).stdout


def finding(fid: str, agent: str, severity: str, rule: str, message: str, file: str, line: int) -> dict[str, Any]:
    return {
        "id": fid,
        "source_agent": agent,
        "severity": severity,
        "rule": rule,
        "message": message,
        "file": file,
        "line": line,
        "repo": "storefront",
        "evidence": "seeded",
    }


class HealthScript(StorefrontScript):
    """Whole-repo scanners that find the seeded retry loop, auditors with lower-severity findings, a backlog."""

    def runtime_hazard(self, call: AgentCall) -> dict[str, Any]:
        if call.inputs.get("mode") != "repo":
            return super().runtime_hazard(call)
        return {
            "findings": [
                finding(
                    "RH-1",
                    "runtime-hazard",
                    "high",
                    "unbounded-loop",
                    "call_with_retry never stops once the delay is capped",
                    "api/app/retry.py",
                    32,
                )
            ]
        }

    def convention_auditor(self, call: AgentCall) -> dict[str, Any]:
        return {
            "findings": [
                finding(
                    "CA-1",
                    "convention-auditor",
                    "low",
                    "naming",
                    "routes module mixes HTTP and inventory concerns",
                    "api/app/routes/orders.py",
                    1,
                )
            ]
        }

    def test_coverage_auditor(self, call: AgentCall) -> dict[str, Any]:
        return {
            "findings": [
                finding(
                    "TC-1",
                    "test-coverage-auditor",
                    "medium",
                    "untested-branch",
                    "the 503 path of POST /orders has no capped-delay test",
                    "api/app/inventory.py",
                    40,
                )
            ]
        }

    def backlog_writer(self, call: AgentCall) -> dict[str, Any]:
        ranked = call.inputs["findings"]
        assert [f["id"] for f in ranked] == ["RH-1", "TC-1", "CA-1"]  # blocking/severity order reached the writer
        return {
            "drafts": [
                {
                    "kind": "BUG",
                    "title": "Retry loop never terminates",
                    "source_findings": ["RH-1"],
                    "markdown": "# BUG: retry loop never terminates\n\n## Acceptance criteria\n"
                    "- **AC-1** stops after N.",
                },
                {
                    "kind": "REQ",
                    "title": "Cover the inventory 503 path",
                    "source_findings": ["TC-1"],
                    "markdown": "# Cover the inventory 503 path\n\n## Acceptance criteria\n- **AC-1** a capped test.",
                },
            ]
        }


async def test_health_audit_ranks_findings_and_drafts_backlog(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]],
) -> None:
    async with stack_for(HealthScript()) as stack:
        remote = stack.remote("sample-fastapi-nextjs")
        await stack.create_project("storefront", [{"id": "storefront", "url": remote, "primary": True}])
        audit = await stack.post("/audits", {"project_id": "storefront"})
        view = await stack.wait_run(audit["id"], lambda v: v["state"]["outcome"] is not None, "audit finished")
        assert view["state"]["outcome"] == "pr-ready", view["state"]["summary"]
        assert view["state"]["summary"].startswith("3 findings, 2 draft specs")

        [listed] = await stack.get("/audits?project_id=storefront", user=VIEWER)
        assert [f["id"] for f in listed["findings"]] == ["RH-1", "TC-1", "CA-1"]
        backlog = await stack.get("/backlog?project_id=storefront", user=VIEWER)
        assert [(b["kind"], b["title"], b["source_findings"]) for b in backlog] == [
            ("BUG", "Retry loop never terminates", ["RH-1"]),
            ("REQ", "Cover the inventory 503 path", ["TC-1"]),
        ]
        artifacts = {a["name"] for a in await stack.get(f"/runs/{audit['id']}/artifacts", user=VIEWER)}
        assert {
            "health-findings.md",
            ".adlc/bugs/BUG-001-retry-loop-never-terminates.md",
            ".adlc/specs/REQ-001-cover-the-inventory-503-path/requirement.md",
        } <= artifacts
        [pr] = view["prs"]
        [local_pr] = rows(db.LocalPR, repo_url=remote)
        assert local_pr.draft is False and "| 1 | high | runtime-hazard | unbounded-loop |" in local_pr.body
        files = git(remote, "ls-tree", "-r", "--name-only", local_pr.head).split()
        assert ".adlc/bugs/BUG-001-retry-loop-never-terminates.md" in files
        assert any("Health audit finished" in s for s in stack.notifier.subjects())

        # A draft is promoted into a run of the right kind (then stopped: this test is about the audit).
        promoted = await stack.post(f"/backlog/{backlog[0]['id']}/promote", user=CONTRIBUTOR)
        assert promoted["kind"] == "bugfix" and promoted["work_item_id"] == "BUG-002"
        again = await stack.post(f"/backlog/{backlog[0]['id']}/promote", user=CONTRIBUTOR)
        assert again["id"] == promoted["id"]  # idempotent
        await stack.post(f"/runs/{promoted['id']}/cancel", expect=200, user=CONTRIBUTOR)
        await stack.wait_run(
            promoted["id"],
            lambda v: v["state"]["outcome"] == "cancelled",
            "promoted run cancelled",
            expect_escalation=True,
        )
        assert pr["repo"] == "storefront"


FAILING_TEST = """from app.retry import TransientError, call_with_retry


def test_retry_counts_every_attempt() -> None:
    calls = []

    def fn() -> None:
        calls.append(1)
        raise TransientError("503")

    sleeps = []

    def sleep(seconds: float) -> None:
        sleeps.append(seconds)
        if len(sleeps) > 20:
            raise RuntimeError("guard")

    try:
        call_with_retry(fn, attempts=8, base_delay_s=0.05, max_delay_s=1.0, sleep=sleep)
    except TransientError:
        pass
    assert len(calls) == 8
"""


async def test_verify_branch_sets_the_gates_status_on_each_push(
    stack_for: Callable[..., AbstractAsyncContextManager[Stack]], tmp_path: Path
) -> None:
    async with stack_for(StorefrontScript()) as stack:
        remote = stack.remote("sample-fastapi-nextjs")
        await stack.create_project("storefront", [{"id": "storefront", "url": remote, "primary": True}])
        forge = LocalForge(tmp_path)

        # A developer works locally (``aidlc local``): a regression test that fails against the seeded bug...
        dev = tmp_path / "dev"
        git(tmp_path, "clone", "--quiet", remote, str(dev))
        git(dev, "checkout", "--quiet", "-b", "feature/retry-guard")
        (dev / "api" / "tests" / "test_retry_guard.py").write_text(FAILING_TEST)
        git(dev, "add", "-A")
        git(dev, "commit", "--quiet", "-m", "test: retry guard")
        git(dev, "push", "--quiet", "origin", "feature/retry-guard")
        first_sha = git(dev, "rev-parse", "HEAD").strip()

        async def submit() -> dict[str, Any]:
            run = await stack.post(
                "/verify-branch", {"project_id": "storefront", "repo": "storefront", "branch": "feature/retry-guard"}
            )
            return await stack.wait_run(run["id"], lambda v: v["state"]["outcome"] is not None, "verify finished")

        failed = await submit()
        assert failed["state"]["outcome"] == "blocked"
        assert "test_retry_counts_every_attempt" in failed["state"]["summary"]
        checks = await forge.get_checks(remote, first_sha)
        assert [(c.name, c.conclusion) for c in checks] == [("aidlc/gates", "failure")]

        # ...then fixes the bug and submits again: the new head is verified, not the old one.
        retry_py = dev / "api" / "app" / "retry.py"
        retry_py.write_text(
            retry_py.read_text().replace(
                "            if delay < max_delay_s:\n                delay = min(delay * 2, max_delay_s)\n"
                "                attempt += 1\n",
                "            attempt += 1\n            delay = min(delay * 2, max_delay_s)\n",
            )
        )
        git(dev, "commit", "--quiet", "-am", "fix: count every retry attempt")
        git(dev, "push", "--quiet", "origin", "feature/retry-guard")
        second_sha = git(dev, "rev-parse", "HEAD").strip()

        passed = await submit()
        assert passed["state"]["outcome"] == "pr-ready", passed["state"]["summary"]
        assert passed["state"]["summary"] == "feature/retry-guard verified: aidlc/gates success"
        assert {t["id"]: t["status"] for t in passed["tests"]}[
            "tests/test_retry_guard.py::test_retry_counts_every_attempt"
        ] == "pass"
        checks = await forge.get_checks(remote, "feature/retry-guard")
        assert [(c.name, c.conclusion) for c in checks] == [("aidlc/gates", "success")]
        assert git(remote, "rev-parse", "feature/retry-guard").strip() == second_sha  # verify never pushes
