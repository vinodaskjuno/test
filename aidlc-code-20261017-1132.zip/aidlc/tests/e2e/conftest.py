"""End-to-end fixtures: sample git repos with LocalForge remotes and the full stack (see ``harness.py``)."""

from __future__ import annotations

import importlib.util
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from pathlib import Path
from types import ModuleType

import pytest

from aidlc.settings import ROOT
from tests.e2e.harness import Stack, running_stack
from tests.e2e.scripted import Script, ScriptedAgentBackend

SPECS = ROOT / "evals" / "specs"


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "e2e: full-stack end-to-end test (real Temporal, worker, API and git)")


def _make_git_repos() -> ModuleType:
    path = ROOT / "evals" / "repos" / "make_git_repos.py"
    spec = importlib.util.spec_from_file_location("aidlc_eval_make_git_repos", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def samples(tmp_path: Path) -> Path:
    """``sample-fastapi-nextjs`` and ``multi/{api,web,infra}`` as git repos, bare remotes under ``remotes/``."""
    target = tmp_path / "samples"
    _make_git_repos().make_repos(target)
    return target


@pytest.fixture
def stack_for(samples: Path) -> Callable[[Script], AbstractAsyncContextManager[Stack]]:
    def start(script: Script) -> AbstractAsyncContextManager[Stack]:
        return running_stack(samples, ScriptedAgentBackend(script))

    return start
