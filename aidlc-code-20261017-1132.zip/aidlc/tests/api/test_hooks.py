from __future__ import annotations

import hashlib
import hmac
import json

import httpx
import pytest
import respx
from fastapi.testclient import TestClient
from sqlalchemy import select

from aidlc.contracts import PRRef, RunState
from aidlc.names import SIG_PR_EVENT
from aidlc.platform import db
from aidlc.platform.spec_templates import template_text
from aidlc.settings import get_settings
from tests.api.conftest import ADMIN, FakeTemporalGateway, World, bearer
from tests.api.test_runs import create_run

SECRET = "hook-secret-for-tests"
JIRA = {
    "jira": {
        "base_url": "https://acme.atlassian.net",
        "user": "bot@acme.test",
        "api_token": "jira-token",
        "project_key": "SHOP",
    }
}


@pytest.fixture(autouse=True)
def _secret(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_WEBHOOK_SECRET", SECRET)
    get_settings.cache_clear()


def signed(payload: dict, secret: str = SECRET) -> tuple[bytes, str]:
    body = json.dumps(payload).encode()
    return body, "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def github(client: TestClient, event: str, payload: dict, secret: str = SECRET):
    body, signature = signed(payload, secret)
    return client.post(
        "/api/v1/hooks/github",
        content=body,
        headers={"X-GitHub-Event": event, "X-Hub-Signature-256": signature, "Content-Type": "application/json"},
    )


def test_github_signature_is_required(client: TestClient, world: World) -> None:
    assert github(client, "ping", {"zen": "hi"}).json() == {
        "accepted": True,
        "detail": "pong",
        "run_id": None,
        "run_ids": [],
    }
    assert github(client, "ping", {"zen": "hi"}, secret="wrong").status_code == 401
    unsigned = client.post("/api/v1/hooks/github", content=b"{}", headers={"X-GitHub-Event": "ping"})
    assert unsigned.status_code == 401


def test_default_secret_refused_outside_dev(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AIDLC_WEBHOOK_SECRET")
    monkeypatch.setenv("AIDLC_AUTH_MODE", "oidc")
    get_settings.cache_clear()
    assert github(client, "ping", {}, secret="change-me").status_code == 503


def test_merged_pr_signals_owning_run(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    run = create_run(client)
    pr = PRRef(repo="api", number=12, url="https://github.com/acme/api/pull/12")
    with db.session_scope() as s:
        row = s.get(db.Run, run["id"])
        row.state = RunState(run_id=run["id"], kind="feature", prs=[pr]).model_dump(mode="json")
    payload = {
        "action": "closed",
        "pull_request": {"number": 12, "html_url": pr.url, "merged": True},
        "repository": {"full_name": "acme/api"},
        "sender": {"login": "octocat"},
    }
    r = github(client, "pull_request", payload)
    assert r.json() == {"accepted": True, "detail": "pr_event merged", "run_id": run["id"], "run_ids": [run["id"]]}
    assert gateway.signals[-1] == (
        run["workflow_id"],
        SIG_PR_EVENT,
        {"repo": "api", "number": 12, "url": pr.url, "user": "github:octocat", "action": "merged"},
    )


def test_review_comment_found_via_pr_event(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    run = create_run(client)
    url = "https://github.com/acme/api/pull/3"
    with db.session_scope() as s:
        s.add(db.RunEventRow(run_id=run["id"], type="pr", data={"repo": "api", "number": 3, "url": url}))
    payload = {
        "action": "created",
        "comment": {"id": 99, "body": "please rename"},
        "pull_request": {"number": 3, "html_url": url},
        "repository": {"full_name": "acme/api"},
        "sender": {"login": "rev"},
    }
    assert github(client, "pull_request_review_comment", payload).json()["run_id"] == run["id"]
    assert gateway.signals[-1][2]["action"] == "comment" and gateway.signals[-1][2]["comment_id"] == "99"


def test_unknown_pr_is_ignored(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    payload = {"action": "synchronize", "pull_request": {"number": 1, "html_url": "x"}, "repository": {}}
    assert github(client, "pull_request", payload).json()["accepted"] is False
    assert gateway.signals == []


def issue_payload(**comment) -> dict:
    return {
        "action": "created",
        "issue": {
            "number": 5,
            "title": "Export CSV",
            "body": "Users export orders.",
            "html_url": "https://github.com/acme/api/issues/5",
            "labels": [{"name": "bug"}],
        },
        "comment": {"id": 1, "body": "/aidlc run", "author_association": "MEMBER", **comment},
        "repository": {"full_name": "acme/api"},
        "sender": {"login": "octocat"},
    }


def test_issue_comment_command_starts_run(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    r = github(client, "issue_comment", issue_payload())
    assert r.json()["accepted"] is True, r.json()
    kind, request, _ = gateway.starts[-1]
    assert kind == "bugfix" and request.work_item.id == "BUG-001"
    source = request.work_item.sources[0]
    assert source.kind == "github_issue" and "Users export orders." in source.content
    assert request.work_item.repo_hints == ["api"]
    # Redelivery of the same comment does not start a second run.
    assert github(client, "issue_comment", issue_payload()).json()["run_id"] == r.json()["run_id"]
    assert len(gateway.starts) == 1


def test_issue_comment_from_outsider_is_ignored(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    assert github(client, "issue_comment", issue_payload(author_association="NONE")).json()["accepted"] is False
    assert gateway.starts == []


def test_jira_labelled_issue_starts_run(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    assert client.put("/api/v1/integrations?project_id=shop", json=JIRA, headers=bearer(ADMIN)).status_code == 200
    payload = {
        "webhookEvent": "jira:issue_created",
        "user": {"accountId": "acc-1"},
        "issue": {
            "key": "SHOP-42",
            "self": "https://acme.atlassian.net/rest/api/3/issue/1",
            "fields": {
                "summary": "Gift cards",
                "labels": ["aidlc"],
                "issuetype": {"name": "Story"},
                "project": {"key": "SHOP"},
                "description": {
                    "type": "doc",
                    "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Sell gift cards"}]}],
                },
            },
        },
    }
    raw, signature = signed(payload)
    headers = {"X-Hub-Signature": signature, "Content-Type": "application/json"}
    assert client.post("/api/v1/hooks/jira", content=raw, headers={"X-Hub-Signature": "sha256=0"}).status_code == 401
    r = client.post("/api/v1/hooks/jira", content=raw, headers=headers)
    assert r.json()["accepted"] is True, r.json()
    kind, request, _ = gateway.starts[-1]
    assert kind == "feature" and request.work_item.title == "Gift cards"
    assert request.work_item.sources[0].kind == "jira" and "Sell gift cards" in request.work_item.sources[0].content
    assert client.post("/api/v1/hooks/jira", content=raw, headers=headers).json()["run_id"] == r.json()["run_id"]
    assert len(gateway.starts) == 1

    unlabelled, sig = signed({**payload, "issue": {**payload["issue"], "fields": {"labels": []}}})
    ignored = client.post("/api/v1/hooks/jira", content=unlabelled, headers={"X-Hub-Signature": sig})
    assert ignored.json()["accepted"] is False


def _jira_issue(labels: list[str]) -> dict:
    return {
        "key": "SHOP-7",
        "self": "https://acme.atlassian.net/rest/api/3/issue/7",
        "fields": {
            "summary": "Loyalty points",
            "labels": labels,
            "issuetype": {"name": "Bug"},
            "project": {"key": "SHOP"},
            "description": "Points are lost on refund",
        },
    }


def _jira_post(client: TestClient, payload: dict) -> dict:
    raw, signature = signed(payload)
    return client.post("/api/v1/hooks/jira", content=raw, headers={"X-Hub-Signature": signature}).json()


def test_jira_update_that_adds_the_label_starts_a_run(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    client.put("/api/v1/integrations?project_id=shop", json=JIRA, headers=bearer(ADMIN))
    edit = {
        "webhookEvent": "jira:issue_updated",
        "issue": _jira_issue(["aidlc", "backend"]),
        "changelog": {"id": "100", "items": [{"field": "summary", "fromString": "a", "toString": "b"}]},
    }
    assert _jira_post(client, edit) == {
        "accepted": False,
        "detail": "update does not add the aidlc label",
        "run_id": None,
        "run_ids": [],
    }
    label = {
        **edit,
        "changelog": {
            "id": "101",
            "items": [{"field": "labels", "fromString": "backend", "toString": "aidlc backend"}],
        },
    }
    first = _jira_post(client, label)
    assert first["accepted"] is True
    kind, request, _ = gateway.starts[-1]
    assert kind == "bugfix" and request.options["event"] == "jira:issue_updated"
    assert request.work_item.sources[0].content == "# Loyalty points\n\nPoints are lost on refund"
    assert _jira_post(client, label)["run_id"] == first["run_id"]  # redelivery of the same change
    relabel = {**label, "changelog": {**label["changelog"], "id": "205"}}
    assert _jira_post(client, relabel)["run_id"] != first["run_id"]  # removed and added again: a new request
    assert len(gateway.starts) == 2


GITHUB_API = "https://api.github.com"
SHA = "a" * 40


def _push(added: list[str], modified: list[str] = (), *, ref: str = "refs/heads/main", **extra) -> dict:
    return {
        "ref": ref,
        "after": SHA,
        "repository": {"full_name": "acme/api", "default_branch": "main"},
        "installation": {"id": 99},
        "pusher": {"name": "dev"},
        "commits": [{"id": SHA, "added": added, "modified": list(modified), "removed": []}],
        **extra,
    }


@pytest.fixture
def github_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_GITHUB_TOKEN", "ghs_test")
    get_settings.cache_clear()


@respx.mock
def test_spec_push_to_default_branch_starts_runs(
    client: TestClient, world: World, gateway: FakeTemporalGateway, github_token: None
) -> None:
    spec = "---\nid: REQ-900\ntitle: Gift wrap\nstatus: draft\n---\n# Gift wrap\n\nShoppers can add gift wrap."
    bug = "# Totals round wrong\n\nCart totals round half-down."
    route = respx.get(f"{GITHUB_API}/repos/acme/api/contents/.adlc/specs/REQ-900-gift-wrap/requirement.md").mock(
        return_value=httpx.Response(200, content=spec.encode())
    )
    respx.get(f"{GITHUB_API}/repos/acme/api/contents/.adlc/bugs/rounding.md").mock(
        return_value=httpx.Response(200, content=bug.encode())
    )
    payload = _push(
        [".adlc/specs/REQ-900-gift-wrap/requirement.md", "README.md"],
        [".adlc/bugs/rounding.md", ".adlc/specs/x/architecture.md"],
    )
    r = github(client, "push", payload).json()
    assert r["accepted"] is True and len(r["run_ids"]) == 2, r
    assert route.calls.last.request.url.params["ref"] == SHA
    assert route.calls.last.request.headers["Authorization"] == "Bearer ghs_test"
    (k1, feature, _), (k2, bugfix, _) = gateway.starts
    assert (k1, k2) == ("feature", "bugfix")
    assert feature.work_item.title == "Gift wrap" and feature.work_item.repo_hints == ["api"]
    assert feature.work_item.sources[0].content == spec
    assert feature.work_item.sources[0].uri.endswith(f"/blob/{SHA}/.adlc/specs/REQ-900-gift-wrap/requirement.md")
    assert feature.options == {
        "trigger": "github_push",
        "repo": "acme/api",
        "commit": SHA,
        "spec_path": ".adlc/specs/REQ-900-gift-wrap/requirement.md",
    }
    assert bugfix.work_item.kind == "bug" and bugfix.work_item.title == "Totals round wrong"
    # Redelivery of the same push is idempotent per commit and path.
    assert github(client, "push", payload).json()["run_ids"] == r["run_ids"]
    assert len(gateway.starts) == 2


@respx.mock
def test_spec_push_skips_specs_a_run_already_owns(
    client: TestClient, world: World, gateway: FakeTemporalGateway, github_token: None
) -> None:
    run = create_run(client)  # allocates REQ-001 for the shop project
    path = f".adlc/specs/{run['work_item_id']}-orders/requirement.md"
    respx.get(f"{GITHUB_API}/repos/acme/api/contents/{path}").mock(
        return_value=httpx.Response(200, content=b"# Orders\n\nWritten by the platform's own run.")
    )
    starts = len(gateway.starts)
    r = github(client, "push", _push([path])).json()
    assert r["accepted"] is False and "already tracked" in r["detail"]
    assert len(gateway.starts) == starts


@pytest.mark.parametrize(
    ("payload", "detail"),
    [
        (_push([".adlc/specs/a/requirement.md"], ref="refs/heads/feature"), "no .adlc specs"),
        (_push([".adlc/specs/a/requirement.md"], deleted=True), "no .adlc specs"),
        (_push(["docs/spec.md"]), "no .adlc specs"),
        ({**_push([".adlc/bugs/b.md"]), "installation": None}, "not from a GitHub App installation"),
        (
            {**_push([".adlc/bugs/b.md"]), "repository": {"full_name": "other/repo", "default_branch": "main"}},
            "no project includes other/repo",
        ),
    ],
)
def test_spec_push_ignored(
    client: TestClient, world: World, gateway: FakeTemporalGateway, payload: dict, detail: str
) -> None:
    r = github(client, "push", payload).json()
    assert r["accepted"] is False and detail in r["detail"]
    assert gateway.starts == []


@respx.mock
def test_spec_push_reports_github_errors(client: TestClient, world: World, github_token: None) -> None:
    respx.get(f"{GITHUB_API}/repos/acme/api/contents/.adlc/bugs/b.md").mock(return_value=httpx.Response(404))
    assert github(client, "push", _push([".adlc/bugs/b.md"])).status_code == 502


@respx.mock
def test_spec_push_that_fails_the_template_check_starts_no_run_and_is_audited(
    client: TestClient, world: World, gateway: FakeTemporalGateway, github_token: None
) -> None:
    path = ".adlc/specs/new-quote/requirement.md"
    respx.get(f"{GITHUB_API}/repos/acme/api/contents/{path}").mock(
        return_value=httpx.Response(200, content=template_text("backend").encode())
    )
    r = github(client, "push", _push([path])).json()
    assert r["accepted"] is False and f"rejected: {path}" in r["detail"]
    assert not gateway.starts
    with db.session_scope() as s:
        row = s.scalars(select(db.AuditLog).where(db.AuditLog.action == "spec.rejected")).one()
        assert row.target == path and row.detail["errors"]
