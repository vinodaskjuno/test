from __future__ import annotations

from urllib.parse import quote

from fastapi.testclient import TestClient

from aidlc.names import SIG_ANSWER, SIG_ESCALATION
from aidlc.platform import db
from tests.api.conftest import CONTRIBUTOR, MAINTAINER, VIEWER, FakeTemporalGateway, World, bearer
from tests.api.test_runs import create_run


def add_item(run_id: str, item_id: str, kind: str, ref_id: str, payload: dict | None = None) -> None:
    with db.session_scope() as s:
        s.add(
            db.InboxItem(
                id=item_id,
                run_id=run_id,
                project_id="shop",
                kind=kind,
                ref_id=ref_id,
                title=ref_id,
                payload=payload or {},
            )
        )


def test_answer_signals_the_workflow(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    run = create_run(client)
    add_item(run["id"], "i1", "question", "Q-1", {"text": "Which currency?"})
    inbox = client.get("/api/v1/inbox?project_id=shop", headers=bearer(VIEWER)).json()
    assert [i["id"] for i in inbox] == ["i1"]
    assert client.post("/api/v1/inbox/i1/answer", json={"answer": "EUR"}, headers=bearer(VIEWER)).status_code == 403
    r = client.post("/api/v1/inbox/i1/answer", json={"answer": "EUR"}, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 200 and r.json()["status"] == "resolved"
    assert gateway.signals == [
        (run["workflow_id"], SIG_ANSWER, {"question_id": "Q-1", "answer": "EUR", "user": CONTRIBUTOR, "source": "api"})
    ]
    assert (
        client.post("/api/v1/inbox/i1/answer", json={"answer": "USD"}, headers=bearer(CONTRIBUTOR)).status_code == 409
    )
    assert client.get("/api/v1/inbox", headers=bearer(VIEWER)).json() == []
    assert len(client.get("/api/v1/inbox?status=resolved", headers=bearer(VIEWER)).json()) == 1


def test_decide_escalation(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    run = create_run(client)
    add_item(run["id"], "e1", "escalation", "ESC-1", {"options": ["retry", "cancel"]})
    assert (
        client.post("/api/v1/inbox/e1/decide", json={"decision": "retry"}, headers=bearer(CONTRIBUTOR)).status_code
        == 403
    )
    bad = client.post("/api/v1/inbox/e1/decide", json={"decision": "takeover"}, headers=bearer(MAINTAINER))
    assert bad.status_code == 422
    r = client.post("/api/v1/inbox/e1/decide", json={"decision": "retry", "note": "flaky"}, headers=bearer(MAINTAINER))
    assert r.status_code == 200 and r.json()["resolution"]["note"] == "flaky"
    assert gateway.signals[-1] == (
        run["workflow_id"],
        SIG_ESCALATION,
        {"escalation_id": "ESC-1", "decision": "retry", "user": MAINTAINER, "content": None, "source": "api"},
    )


def test_wrong_item_kind_conflicts(client: TestClient, world: World) -> None:
    run = create_run(client)
    add_item(run["id"], "q1", "question", "Q-1")
    assert (
        client.post("/api/v1/inbox/q1/decide", json={"decision": "retry"}, headers=bearer(MAINTAINER)).status_code
        == 409
    )
    assert client.post("/api/v1/inbox/zz/answer", json={"answer": "x"}, headers=bearer(MAINTAINER)).status_code == 404


def test_edit_spec_decision_forwards_replacement_spec(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    run = create_run(client)
    add_item(run["id"], "e2", "escalation", "ESC-2", {"options": ["retry", "edit_spec", "cancel"]})
    spec = "# New spec\nAC-1: totals include tax"
    r = client.post("/api/v1/inbox/e2/decide", json={"decision": "edit_spec", "note": spec}, headers=bearer(MAINTAINER))
    assert r.status_code == 200
    assert gateway.signals[-1] == (
        run["workflow_id"],
        SIG_ESCALATION,
        {"escalation_id": "ESC-2", "decision": "edit_spec", "user": MAINTAINER, "content": spec, "source": "api"},
    )


def test_get_inbox_item_by_deterministic_id(client: TestClient, world: World) -> None:
    run = create_run(client)
    item_id = f"{run['id']}:Q-1"
    add_item(run["id"], item_id, "question", "Q-1", {"text": "Which currency?"})
    r = client.get(f"/api/v1/inbox/{quote(item_id, safe='')}", headers=bearer(VIEWER))
    assert r.status_code == 200 and r.json()["ref_id"] == "Q-1" and r.json()["payload"]["text"] == "Which currency?"
    assert client.get(f"/api/v1/inbox/{item_id}", headers=bearer(VIEWER)).json()["id"] == item_id  # ':' unencoded
    assert client.get(f"/api/v1/inbox/{quote(item_id)}", headers=bearer("x@other.test")).status_code == 404
    assert client.get("/api/v1/inbox/nope:Q-9", headers=bearer(VIEWER)).status_code == 404
    answered = client.post(
        f"/api/v1/inbox/{quote(item_id, safe='')}/answer", json={"answer": "EUR"}, headers=bearer(CONTRIBUTOR)
    )
    assert answered.json()["status"] == "resolved"
