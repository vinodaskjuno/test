"""Scheduled health audits: API over the fake gateway, and the real gateway against a local Temporal server."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from aidlc.api.routers.schedules import action_workflow_id
from aidlc.api.temporal import RealTemporalGateway
from aidlc.contracts import ProjectConfig, RunRequest
from tests.api.conftest import ADMIN, CONTRIBUTOR, MAINTAINER, VIEWER, FakeTemporalGateway, World, bearer

URL = "/api/v1/audits/schedules"


def test_schedule_create_list_delete(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    body = {"project_id": "shop", "cron": "0  3 * * 1", "timezone": "Europe/London", "repos": ["api"]}
    assert client.post(URL, json=body, headers=bearer(CONTRIBUTOR)).status_code == 403
    r = client.post(URL, json=body, headers=bearer(MAINTAINER))
    assert r.status_code == 201, r.text
    created = r.json()
    assert created["id"] == "audit-shop-1" and created["cron"] == "0 3 * * 1"
    assert (created["timezone"], created["repos"], created["open_pr"]) == ("Europe/London", ["api"], True)
    assert created["created_by"] == MAINTAINER

    schedule = gateway.schedules["audit-shop-1"]
    assert schedule.kind == "health_audit" and schedule.workflow_id == action_workflow_id("audit-shop-1")
    assert len(schedule.workflow_id) + len("-2026-10-12T03:00:00Z") <= 64
    request = schedule.request
    assert request.run_id == schedule.workflow_id and request.project.project_id == "shop"
    assert request.options == {
        "repos": ["api"],
        "open_pr": True,
        "create_run_row": True,
        "schedule_id": "audit-shop-1",
        "requested_by": MAINTAINER,
        "title": "Scheduled health audit",
    }

    second = client.post(URL, json={**body, "repos": [], "open_pr": False}, headers=bearer(MAINTAINER)).json()
    assert second["id"] == "audit-shop-2"
    listed = client.get(URL, headers=bearer(VIEWER)).json()
    assert [s["id"] for s in listed] == ["audit-shop-1", "audit-shop-2"]
    assert listed[0]["recent_run_ids"] == [f"{schedule.workflow_id}-2026-10-12T03:00:00Z"]
    assert client.get(f"{URL}?project_id=other", headers=bearer(VIEWER)).json() == []

    assert client.delete(f"{URL}/audit-shop-1", headers=bearer(CONTRIBUTOR)).status_code == 403
    assert client.delete(f"{URL}/audit-shop-1", headers=bearer(MAINTAINER)).status_code == 204
    assert list(gateway.schedules) == ["audit-shop-2"]
    assert client.delete(f"{URL}/audit-shop-1", headers=bearer(MAINTAINER)).status_code == 404


def test_schedules_are_invisible_outside_the_project(client: TestClient, world: World) -> None:
    client.post(URL, json={"project_id": "shop", "cron": "0 3 * * *"}, headers=bearer(MAINTAINER))
    stranger = bearer("someone@other.test")
    assert client.get(URL, headers=stranger).json() == []
    assert client.delete(f"{URL}/audit-shop-1", headers=stranger).status_code == 404


@pytest.mark.parametrize(
    "patch",
    [
        {"cron": "every monday"},
        {"cron": "0 3 * *"},
        {"timezone": "Mars/Olympus"},
        {"repos": ["web"]},
    ],
)
def test_schedule_validation(client: TestClient, world: World, gateway: FakeTemporalGateway, patch: dict) -> None:
    body = {"project_id": "shop", "cron": "0 3 * * 1", **patch}
    assert client.post(URL, json=body, headers=bearer(ADMIN)).status_code == 422
    assert gateway.schedules == {}


def test_temporal_failure_is_503(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    gateway.fail_start = True
    r = client.post(URL, json={"project_id": "shop", "cron": "0 3 * * 1"}, headers=bearer(MAINTAINER))
    assert r.status_code == 503
    gateway.fail_start = False
    # The failed attempt used up its number; ids are never reused.
    assert (
        client.post(URL, json={"project_id": "shop", "cron": "0 3 * * 1"}, headers=bearer(MAINTAINER)).json()["id"]
        == "audit-shop-2"
    )


@pytest.mark.temporal
async def test_real_gateway_manages_temporal_schedules() -> None:
    from temporalio.testing import WorkflowEnvironment

    from aidlc.orchestrator.workflows import DATA_CONVERTER

    async with await WorkflowEnvironment.start_local(data_converter=DATA_CONVERTER) as env:
        gateway = RealTemporalGateway("unused", "default")
        gateway._client = env.client
        request = RunRequest(
            run_id="sched-0123456789ab",
            kind="health_audit",
            project=ProjectConfig(project_id="shop", name="Shop", repos=[]),
            options={"create_run_row": True},
        )
        memo = {"project_id": "shop", "cron": "0 3 * * 1", "timezone": "UTC", "repos": ["api"], "open_pr": True}
        await gateway.create_schedule(
            "audit-shop-1",
            cron="0 3 * * 1",
            timezone="UTC",
            kind="health_audit",
            request=request,
            workflow_id="sched-0123456789ab",
            memo=memo,
        )
        await gateway.create_schedule(
            "other-1",
            cron="0 4 * * *",
            timezone="UTC",
            kind="health_audit",
            request=request,
            workflow_id="sched-ffffffffffff",
            memo={},
        )
        listed = await gateway.list_schedules("audit-")
        assert [s.id for s in listed] == ["audit-shop-1"]
        assert listed[0].memo == memo and listed[0].paused is False
        assert listed[0].next_run_at is not None and listed[0].next_run_at.weekday() == 0
        description = await env.client.get_schedule_handle("audit-shop-1").describe()
        action = description.schedule.action
        assert action.workflow == "HealthAuditWorkflow" and action.id == "sched-0123456789ab"
        await gateway.delete_schedule("audit-shop-1")
        await gateway.delete_schedule("other-1")
        assert await gateway.list_schedules("") == []
