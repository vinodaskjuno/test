from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from aidlc.platform import db, knowledge
from aidlc.platform.registry import get_registry
from aidlc.settings import get_settings
from tests.api.conftest import (
    ADMIN,
    CONTRIBUTOR,
    MAINTAINER,
    VIEWER,
    FakeTemporalGateway,
    MemoryArtifactStore,
    World,
    bearer,
)
from tests.api.test_runs import add_events, create_run

AGENT_YAML = """id: {id}
number: {number}
name: {name}
squad: S1
version: 1.0.0
model: claude-haiku-5-5
description: Test agent.
tools: [Read]
reads_untrusted: true
workflows: [feature]
"""


@pytest.fixture
def agents_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    root = tmp_path / "agents"
    for number, agent_id in ((1, "intake"), (2, "spec-analyst")):
        folder = root / "S1" / agent_id
        folder.mkdir(parents=True)
        (folder / "agent.yaml").write_text(AGENT_YAML.format(id=agent_id, number=number, name=agent_id.title()))
        (folder / "prompt.md").write_text("You are a test agent.")
        (folder / "schema.py").write_text(
            "from aidlc.agent_outputs import IntakeOutput\n\n\nclass Output(IntakeOutput):\n    pass\n"
        )
    monkeypatch.setenv("AIDLC_AGENTS_DIR", str(root))
    get_settings.cache_clear()
    get_registry.cache_clear()
    yield root
    get_registry.cache_clear()


def test_agents_list_and_detail_come_from_registry(client: TestClient, world: World, agents_dir: Path) -> None:
    agents = client.get("/api/v1/agents", headers=bearer(VIEWER)).json()
    assert [(a["id"], a["squad_name"]) for a in agents] == [
        ("intake", "Discovery & Requirements"),
        ("spec-analyst", "Discovery & Requirements"),
    ]
    detail = client.get("/api/v1/agents/intake", headers=bearer(VIEWER)).json()
    assert detail["prompt"] == "You are a test agent." and "title" in detail["output_schema"]["properties"]
    assert client.get("/api/v1/agents/nope", headers=bearer(VIEWER)).status_code == 404


def test_agent_promotion_requires_score_and_role(client: TestClient, world: World, agents_dir: Path) -> None:
    with db.session_scope() as s:
        s.add(db.AgentVersion(agent_id="intake", version="1.0.0", status="promoted", eval_score=0.9))
        s.add(db.AgentVersion(agent_id="intake", version="1.1.0", eval_score=0.95))
        s.add(db.AgentVersion(agent_id="intake", version="1.2.0", eval_score=0.4))
    promote = "/api/v1/agents/intake/promote"
    assert client.post(promote, json={"version": "1.1.0"}, headers=bearer(CONTRIBUTOR)).status_code == 403
    assert client.post(promote, json={"version": "1.2.0"}, headers=bearer(MAINTAINER)).status_code == 409
    assert client.post(promote, json={"version": "9.9.9"}, headers=bearer(MAINTAINER)).status_code == 409
    r = client.post(promote, json={"version": "1.1.0"}, headers=bearer(MAINTAINER))
    assert r.status_code == 200 and r.json()["promoted_version"] == "1.1.0"
    statuses = {v["version"]: v["status"] for v in r.json()["versions"]}
    assert statuses == {"1.0.0": "retired", "1.1.0": "promoted", "1.2.0": "candidate"}
    rolled = client.post("/api/v1/agents/intake/rollback", headers=bearer(MAINTAINER)).json()
    assert rolled["promoted_version"] == "1.0.0"
    assert client.post("/api/v1/agents/intake/rollback", headers=bearer(MAINTAINER)).status_code == 409


def test_eval_scores_gate_promotion_end_to_end(client: TestClient, world: World, agents_dir: Path) -> None:
    evals = "/api/v1/agents/intake/evals"
    report = {"cases": [{"case_id": "intake-bug-report", "score": 0.9}]}
    assert client.post(evals, json={"version": "1.0.0", "score": 0.9}, headers=bearer(CONTRIBUTOR)).status_code == 403
    assert client.post(evals, json={"version": "1.0.0", "score": 1.5}, headers=bearer(MAINTAINER)).status_code == 422
    assert client.post(evals, json={"version": "v1", "score": 0.5}, headers=bearer(MAINTAINER)).status_code == 422
    missing = client.post("/api/v1/agents/nope/evals", json={"version": "1.0.0", "score": 0.9}, headers=bearer(ADMIN))
    assert missing.status_code == 404

    first = client.post(evals, json={"version": "1.0.0", "score": 0.9, "report": report}, headers=bearer(MAINTAINER))
    assert first.status_code == 201, first.text
    version = first.json()["versions"][0]
    assert version["status"] == "candidate" and version["eval_score"] == 0.9
    assert version["eval_report"]["cases"] == report["cases"] and version["eval_report"]["submitted_by"] == MAINTAINER
    assert first.json()["promotion_min_score"] == 0.8

    listed = {a["id"]: a for a in client.get("/api/v1/agents", headers=bearer(VIEWER)).json()}
    assert listed["intake"]["latest_eval_version"] == "1.0.0" and listed["intake"]["promotable"] is True
    assert listed["spec-analyst"]["latest_eval_score"] is None and listed["spec-analyst"]["promotable"] is False

    promote = "/api/v1/agents/intake/promote"
    assert client.post(promote, json={"version": "1.0.0"}, headers=bearer(MAINTAINER)).status_code == 200
    client.post(evals, json={"version": "1.1.0", "score": 0.7}, headers=bearer(MAINTAINER))
    below = client.post(promote, json={"version": "1.1.0"}, headers=bearer(MAINTAINER))
    assert below.status_code == 409 and "below the promotion threshold" in below.json()["detail"]
    summary = {a["id"]: a for a in client.get("/api/v1/agents", headers=bearer(VIEWER)).json()}["intake"]
    assert (summary["promoted_version"], summary["promoted_score"]) == ("1.0.0", 0.9)
    assert (summary["latest_eval_version"], summary["promotable"]) == ("1.1.0", False)

    # A re-run of the suite on 1.1.0 passes; promotion and rollback walk the promotion history.
    client.post(evals, json={"version": "1.1.0", "score": 0.85}, headers=bearer(MAINTAINER))
    assert (
        client.post(promote, json={"version": "1.1.0"}, headers=bearer(MAINTAINER)).json()["promoted_version"]
        == "1.1.0"
    )
    rolled = client.post("/api/v1/agents/intake/rollback", headers=bearer(MAINTAINER)).json()
    assert rolled["promoted_version"] == "1.0.0"
    assert {v["version"]: v["status"] for v in rolled["versions"]} == {"1.0.0": "promoted", "1.1.0": "candidate"}


def test_cost_aggregation(client: TestClient, world: World) -> None:
    run_a, run_b = create_run(client), create_run(client)
    with db.session_scope() as s:
        for run_id, agent, squad, cost in (
            (run_a["id"], "spec-analyst", "S1", 1.0),
            (run_a["id"], "backend-dev", "S3", 2.0),
            (run_b["id"], "backend-dev", "S3", 3.0),
        ):
            s.add(
                db.CostRecord(
                    run_id=run_id,
                    project_id="shop",
                    agent_id=agent,
                    squad=squad,
                    model="m",
                    cost_usd=cost,
                    input_tokens=10,
                )
            )
    by_agent = client.get("/api/v1/cost?group_by=agent", headers=bearer(VIEWER)).json()
    assert by_agent["total_usd"] == 6.0
    assert [(g["key"], g["cost_usd"], g["runs"]) for g in by_agent["groups"]] == [
        ("backend-dev", 5.0, 2),
        ("spec-analyst", 1.0, 1),
    ]
    by_squad = client.get("/api/v1/cost?group_by=squad&project_id=shop", headers=bearer(VIEWER)).json()
    assert {g["key"]: g["cost_usd"] for g in by_squad["groups"]} == {"S3": 5.0, "S1": 1.0}
    by_team = client.get("/api/v1/cost?group_by=team", headers=bearer(VIEWER)).json()
    assert by_team["groups"][0]["key"] == world.team_id and by_team["groups"][0]["input_tokens"] == 30
    assert client.get("/api/v1/cost", headers=bearer("eve@other.test")).json()["total_usd"] == 0


def test_verify_branch_starts_workflow(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    body = {"project_id": "shop", "repo": "api", "branch": "feature/cart"}
    r = client.post("/api/v1/verify-branch", json=body, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 201
    kind, request, _ = gateway.starts[-1]
    assert kind == "verify_branch" and request.options == {"repo": "api", "branch": "feature/cart"}
    unknown = client.post("/api/v1/verify-branch", json={**body, "repo": "x"}, headers=bearer(CONTRIBUTOR))
    assert unknown.status_code == 422
    bad = client.post("/api/v1/verify-branch", json={**body, "branch": "a..b"}, headers=bearer(CONTRIBUTOR))
    assert bad.status_code == 422


def test_sprint_starts_with_multiple_work_items(
    client: TestClient, world: World, gateway: FakeTemporalGateway, store: MemoryArtifactStore
) -> None:
    body = {"project_id": "shop", "title": "Sprint 1", "items": [{"title": "Cart"}, {"title": "Crash", "kind": "bug"}]}
    r = client.post("/api/v1/sprints", json=body, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 201 and r.json()["work_item_ids"] == ["REQ-001", "BUG-001"]
    sprint_id = r.json()["run"]["id"]
    kind, request, _ = gateway.starts[-1]
    assert kind == "sprint" and request.run_id == sprint_id
    children = request.options["children"]
    assert [c["work_item"]["id"] for c in children] == ["REQ-001", "BUG-001"]
    # Child runs exist before the sprint starts them: their events, inbox items and PRs need a run row.
    assert [(c["id"], c["kind"]) for c in r.json()["children"]] == [
        (c["run_id"], k) for c, k in zip(children, ["feature", "bugfix"], strict=True)
    ]
    with db.session_scope() as s:
        rows = [s.get(db.Run, c["run_id"]) for c in children]
        assert all(row.parent_run_id == sprint_id and row.workflow_id == row.id for row in rows)
        assert [row.work_item_id for row in rows] == ["REQ-001", "BUG-001"]
    assert f"runs/{children[1]['run_id']}/request.json" in store.objects  # children can be retried on their own
    listed = client.get("/api/v1/sprints?project_id=shop", headers=bearer(VIEWER)).json()
    assert listed[0]["work_item_ids"] == ["REQ-001", "BUG-001"]
    assert sorted(c["id"] for c in listed[0]["children"]) == sorted(c["run_id"] for c in children)


def test_sprint_start_failure_fails_the_children(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    gateway.fail_start = True
    body = {"project_id": "shop", "title": "Sprint 1", "items": [{"title": "Cart"}]}
    assert client.post("/api/v1/sprints", json=body, headers=bearer(CONTRIBUTOR)).status_code == 503
    with db.session_scope() as s:
        outcomes = {r.kind: (r.stage, r.outcome) for r in s.query(db.Run).all()}
    assert outcomes == {"sprint": ("start_failed", "failed"), "feature": ("start_failed", "failed")}


def test_audit_backlog_and_promotion(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    audit = client.post("/api/v1/audits", json={"project_id": "shop"}, headers=bearer(CONTRIBUTOR)).json()
    assert gateway.starts[-1][0] == "health_audit"
    finding = {"id": "F1", "source_agent": "convention-auditor", "severity": "low", "rule": "r", "message": "m"}
    draft = {"kind": "BUG", "title": "Fix naming", "markdown": "# Fix naming", "source_findings": ["F1"]}
    add_events(
        audit["id"],
        {"type": "agent_completed", "agent_id": "convention-auditor", "data": {"findings": [finding]}},
        {"type": "agent_completed", "agent_id": "backlog-writer", "data": {"drafts": [draft]}},
        outcome="pr-ready",
    )
    audits = client.get("/api/v1/audits?project_id=shop", headers=bearer(VIEWER)).json()
    assert audits[0]["findings"][0]["id"] == "F1"
    backlog = client.get("/api/v1/backlog", headers=bearer(VIEWER)).json()
    assert [(b["id"], b["kind"], b["promoted_run_id"]) for b in backlog] == [(f"{audit['id']}-1", "BUG", None)]
    item_id = backlog[0]["id"]
    assert client.post(f"/api/v1/backlog/{item_id}/promote", headers=bearer(VIEWER)).status_code == 403
    promoted = client.post(f"/api/v1/backlog/{item_id}/promote", headers=bearer(CONTRIBUTOR)).json()
    assert promoted["kind"] == "bugfix" and promoted["work_item_id"] == "BUG-001"
    again = client.post(f"/api/v1/backlog/{item_id}/promote", headers=bearer(MAINTAINER)).json()
    assert again["id"] == promoted["id"]
    assert client.get("/api/v1/backlog", headers=bearer(VIEWER)).json()[0]["promoted_run_id"] == promoted["id"]
    assert client.post("/api/v1/backlog/nope-1/promote", headers=bearer(CONTRIBUTOR)).status_code == 404


def test_gates_manifest_knowledge_previews(client: TestClient, world: World) -> None:
    run = create_run(client)
    add_events(
        run["id"],
        {"type": "gate", "stage": "V1", "data": {"gate": "V1", "passed": False, "attempt": 1, "issues": ["vague"]}},
        {"type": "gate", "stage": "V1", "data": {"gate": "V1", "passed": True, "attempt": 2}},
        {"type": "gate", "data": {"gate": "quality", "passed": True}},
    )
    gates = client.get("/api/v1/gates?project_id=shop", headers=bearer(VIEWER)).json()
    stats = {g["gate"]: g for g in gates["summary"]}
    assert stats["V1"]["total"] == 2 and stats["V1"]["pass_rate"] == 0.5 and stats["V1"]["mean_attempts"] == 1.5
    assert gates["config"]["coverage_min_pct"] == 80 and len(gates["recent"]) == 3

    with db.session_scope() as s:
        s.add(db.ManifestEntry(run_id=run["id"], project_id="shop", work_item_id="REQ-001", branch="aidlc/req-001"))
        s.add(db.PreviewEnv(id="pr-api-7", run_id=run["id"], repo="api", pr_number=7, url="https://pr-7.preview"))
    lesson = knowledge.record("shop", "lesson", "Retry payments", "Use idempotency keys", ["payments"])
    doc = knowledge.record("shop", "doc", "Readme", "Setup", [])
    manifest = client.get("/api/v1/manifest?project_id=shop", headers=bearer(VIEWER)).json()
    assert manifest[0]["branch"] == "aidlc/req-001"
    hits = client.get("/api/v1/knowledge?project_id=shop&q=idempotency", headers=bearer(VIEWER)).json()
    assert [(h["id"], h["tags"]) for h in hits] == [(lesson, ["payments"])] and hits[0]["updated_at"]
    docs = client.get("/api/v1/knowledge?project_id=shop&kind=doc", headers=bearer(VIEWER)).json()
    assert [h["id"] for h in docs] == [doc]
    previews = client.get(f"/api/v1/previews?run_id={run['id']}", headers=bearer(VIEWER)).json()
    assert previews[0]["url"] == "https://pr-7.preview"
    assert client.get("/api/v1/previews", headers=bearer("eve@other.test")).json() == []
    assert client.get("/api/v1/gates?project_id=shop", headers=bearer(ADMIN)).status_code == 200
