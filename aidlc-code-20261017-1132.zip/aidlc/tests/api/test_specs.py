from __future__ import annotations

import io

import docx
import pytest
from fastapi.testclient import TestClient

from aidlc.api import convert
from aidlc.interfaces import ScannerUnavailable, ScanVerdict
from aidlc.platform import db, factory
from tests.api.conftest import CONTRIBUTOR, VIEWER, FakeTemporalGateway, MemoryArtifactStore, World, bearer

EICAR = (r"X5O!P%@AP[4\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*").encode()


def make_pdf(text: str) -> bytes:
    """A minimal one-page PDF with a Helvetica text run and a correct xref table."""
    content = f"BT /F1 12 Tf 20 100 Td ({text}) Tj ET".encode()
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] /Resources << /Font << /F1 4 0 R >> >> "
        b"/Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length %d >>\nstream\n" % len(content) + content + b"\nendstream",
    ]
    out = b"%PDF-1.4\n"
    offsets = []
    for number, body in enumerate(objects, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % number + body + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1)
    out += b"".join(b"%010d 00000 n \n" % offset for offset in offsets)
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objects) + 1, xref)
    return out


def make_docx() -> bytes:
    document = docx.Document()
    document.add_heading("Checkout", level=1)
    document.add_paragraph("Shoppers pay with a saved card.")
    document.add_paragraph("Card is charged once", style="List Bullet")
    document.add_paragraph("Receipt is emailed", style="List Bullet")
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text, table.cell(0, 1).text = "AC", "Text"
    table.cell(1, 0).text, table.cell(1, 1).text = "AC-1", "pay | confirm"
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def test_markdown_upload_creates_work_item_and_starts_feature_run(
    client: TestClient, world: World, gateway: FakeTemporalGateway, store: MemoryArtifactStore
) -> None:
    openapi = b"openapi: 3.1.0\ninfo: {title: shop, version: '1'}\npaths: {}\n"
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[
            ("files", ("todo.md", b"# Todo\n\nUsers add items.", "text/markdown")),
            ("files", ("api.yaml", openapi, "application/yaml")),
            ("files", ("mock.png", b"\x89PNG\r\n\x1a\nxx", "image/png")),
        ],
        data={"kind": "feature", "title": "Todo app", "repos": ["api"], "figma_url": "https://www.figma.com/f/abc"},
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 201, r.text
    body = r.json()
    assert [u["kind"] for u in body["uploads"]] == ["markdown", "openapi", "image"]
    assert body["run"]["work_item_id"] == "REQ-001" and body["run"]["kind"] == "feature"
    kind, request, _ = gateway.starts[-1]
    assert kind == "feature"
    item = request.work_item
    assert item.title == "Todo app" and item.repo_hints == ["api"] and item.requested_by == CONTRIBUTOR
    assert [s.kind for s in item.sources] == ["markdown", "openapi", "image", "figma"]
    assert item.sources[0].content.startswith("# Todo") and item.sources[0].uri in store.objects
    assert store.objects[body["uploads"][2]["artifact_key"]][0].startswith(b"\x89PNG")
    with db.session_scope() as s:
        assert s.get(db.Upload, body["uploads"][0]["id"]).markdown.startswith("# Todo")

    second = client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", ("bug.txt", b"crash on save", "text/plain"))],
        data={"kind": "bug"},
        headers=bearer(CONTRIBUTOR),
    )
    assert second.json()["run"]["work_item_id"] == "BUG-001" and second.json()["run"]["kind"] == "bugfix"


def test_pdf_and_docx_are_converted(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[
            ("files", ("spec.pdf", make_pdf("Users can export CSV"), "application/pdf")),
            ("files", ("spec.docx", make_docx(), "application/octet-stream")),
        ],
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 201, r.text
    pdf, word = gateway.starts[-1][1].work_item.sources
    assert "Users can export CSV" in pdf.content
    assert word.content == (
        "# Checkout\n\nShoppers pay with a saved card.\n\n- Card is charged once\n- Receipt is emailed\n\n"
        "| AC | Text |\n| --- | --- |\n| AC-1 | pay \\| confirm |"
    )


def test_economy_upload_starts_the_run_with_economy_gates(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    files = [("files", ("todo.md", b"# Todo\n\nUsers add items.", "text/markdown"))]
    plain = client.post("/api/v1/projects/shop/specs", files=files, headers=bearer(CONTRIBUTOR))
    assert plain.status_code == 201 and "gates" not in gateway.starts[-1][1].options
    r = client.post("/api/v1/projects/shop/specs", files=files, data={"economy": "true"}, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 201, r.text
    assert gateway.starts[-1][1].options["gates"] == {"economy": {"enabled": True}}


def test_oversize_upload_is_413(client: TestClient, world: World, monkeypatch: pytest.MonkeyPatch) -> None:
    from aidlc.settings import get_settings

    monkeypatch.setenv("AIDLC_UPLOAD_MAX_BYTES", "16")
    get_settings.cache_clear()
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", ("a.md", b"x" * 17, "text/markdown"))],
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 413


def test_bad_type_is_415(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", ("run.exe", b"MZ...", "application/octet-stream"))],
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 415
    assert gateway.starts == []


def test_eicar_is_rejected_422(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", ("spec.md", b"# spec\n" + EICAR, "text/markdown"))],
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 422 and "malware" in r.json()["detail"]
    assert gateway.starts == []


def test_viewer_cannot_upload(client: TestClient, world: World) -> None:
    r = client.post(
        "/api/v1/projects/shop/specs", files=[("files", ("a.md", b"# a", "text/markdown"))], headers=bearer(VIEWER)
    )
    assert r.status_code == 403


class StubScanner:
    """Answers like the CrowdStrike scanner: a verdict, or ScannerUnavailable."""

    def __init__(self, verdict: ScanVerdict | None = None, unavailable: str | None = None) -> None:
        self.verdict = verdict
        self.unavailable = unavailable
        self.scanned: list[str] = []

    async def scan(self, filename: str, data: bytes) -> ScanVerdict:
        self.scanned.append(filename)
        if self.unavailable:
            raise ScannerUnavailable(self.unavailable)
        assert self.verdict is not None
        return self.verdict


@pytest.mark.parametrize(
    ("scanner", "status", "detail"),
    [
        (StubScanner(ScanVerdict(False, "CrowdStrike verdict: malware")), 422, "malware detected"),
        (StubScanner(ScanVerdict(False, "CrowdStrike verdict: suspicious")), 422, "suspicious"),
        (StubScanner(unavailable="CrowdStrike scan timed out after 120s"), 503, "timed out"),
        (StubScanner(unavailable="CrowdStrike unreachable: ConnectionError"), 503, "unreachable"),
    ],
)
def test_scanner_verdicts_map_to_status_codes(
    client: TestClient, world: World, gateway: FakeTemporalGateway, scanner: StubScanner, status: int, detail: str
) -> None:
    factory.set_override("malware_scanner", scanner)
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", ("spec.md", b"# spec", "text/markdown"))],
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == status and detail in r.json()["detail"]
    assert scanner.scanned == ["spec.md"] and gateway.starts == []


def test_clean_verdict_accepts_the_upload(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    scanner = StubScanner(ScanVerdict(True, "CrowdStrike verdict: no specific threat"))
    factory.set_override("malware_scanner", scanner)
    r = client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", ("spec.md", b"# spec", "text/markdown"))],
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 201 and scanner.scanned == ["spec.md"]


async def test_eicar_is_rejected_before_the_external_scanner() -> None:
    scanner = StubScanner(ScanVerdict(True, "clean"))
    factory.set_override("malware_scanner", scanner)
    with pytest.raises(convert.UploadRejected) as rejected:
        await convert.scan("x.md", b"text " + EICAR)
    assert rejected.value.status_code == 422 and "EICAR" in rejected.value.detail
    assert scanner.scanned == []


def test_filenames_are_sanitised() -> None:
    assert convert.safe_filename("../../etc/pass wd.md") == "pass_wd.md"
    assert convert.safe_filename("C:\\Users\\a\\spec.md") == "spec.md"
