from __future__ import annotations

import json

from fastapi.testclient import TestClient

from aidlc.contracts import (
    AcceptanceCriterion,
    ACVerdict,
    Finding,
    PRRef,
    Requirement,
    RunState,
    TestReport,
    TestResult,
)
from aidlc.platform import db
from tests.api.conftest import CONTRIBUTOR, VIEWER, FakeTemporalGateway, MemoryArtifactStore, World, bearer

RUN = {"project_id": "shop", "kind": "feature", "title": "Add cart", "sources": []}


def create_run(client: TestClient, **headers: str) -> dict:
    r = client.post("/api/v1/runs", json=RUN, headers={**bearer(CONTRIBUTOR), **headers})
    assert r.status_code in (200, 201), r.text
    return r.json()


def add_events(run_id: str, *events: dict, outcome: str | None = None) -> list[int]:
    with db.session_scope() as s:
        rows = [db.RunEventRow(run_id=run_id, **e) for e in events]
        s.add_all(rows)
        if outcome:
            run = s.get(db.Run, run_id)
            run.outcome, run.stage = outcome, "done"
        s.flush()
        return [r.seq for r in rows]


def test_idempotency_key_replays_the_same_run(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    first = client.post("/api/v1/runs", json=RUN, headers={**bearer(CONTRIBUTOR), "Idempotency-Key": "k-1"})
    again = client.post("/api/v1/runs", json=RUN, headers={**bearer(CONTRIBUTOR), "Idempotency-Key": "k-1"})
    assert (first.status_code, again.status_code) == (201, 200)
    assert first.json()["id"] == again.json()["id"] and first.json()["work_item_id"] == "REQ-001"
    assert len(gateway.starts) == 1
    other = create_run(client, **{"Idempotency-Key": "k-2"})
    assert other["id"] != first.json()["id"] and other["work_item_id"] == "REQ-002"


def test_start_failure_marks_run_failed(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    gateway.fail_start = True
    r = client.post("/api/v1/runs", json=RUN, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 503
    runs = client.get("/api/v1/runs?outcome=failed", headers=bearer(VIEWER)).json()
    assert [x["stage"] for x in runs] == ["start_failed"]


def test_list_filters(client: TestClient, world: World) -> None:
    run = create_run(client)
    assert [r["id"] for r in client.get("/api/v1/runs?q=cart", headers=bearer(VIEWER)).json()] == [run["id"]]
    assert client.get("/api/v1/runs?q=nothing", headers=bearer(VIEWER)).json() == []
    assert len(client.get("/api/v1/runs?outcome=active&kind=feature", headers=bearer(VIEWER)).json()) == 1
    assert client.get("/api/v1/runs", headers=bearer("eve@other.test")).json() == []


def test_run_view_assembles_traceability_findings_tests_and_cost(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    run = create_run(client)
    requirement = Requirement(
        req_id="REQ-001",
        title="Cart",
        summary="s",
        acceptance_criteria=[
            AcceptanceCriterion(id="AC-1", text="add item"),
            AcceptanceCriterion(id="AC-2", text="remove item"),
            AcceptanceCriterion(id="AC-3", text="checkout"),
        ],
    )
    report = TestReport(
        results=[
            TestResult(id="T1", name="add", level="unit", status="pass", ac_ids=["AC-1"]),
            TestResult(id="T2", name="remove", level="unit", status="fail", ac_ids=["AC-2"]),
        ]
    )
    finding = Finding(id="F1", source_agent="security-scanner", severity="high", rule="r", message="m")
    add_events(
        run["id"],
        {"type": "stage_completed", "stage": "S1", "data": {"requirement": requirement.model_dump(mode="json")}},
        {"type": "agent_completed", "agent_id": "unit-test", "data": {"test_report": report.model_dump(mode="json")}},
        {"type": "agent_completed", "data": {"findings": [finding.model_dump(mode="json")]}},
        {"type": "agent_completed", "data": {"verdicts": [ACVerdict(ac_id="AC-1", passed=True).model_dump()]}},
    )
    with db.session_scope() as s:
        for agent, cost in (("spec-analyst", 0.5), ("spec-analyst", 0.25), ("unit-test", 1.0)):
            s.add(
                db.CostRecord(run_id=run["id"], project_id="shop", agent_id=agent, squad="S1", model="m", cost_usd=cost)
            )
    pr = PRRef(repo="api", number=7, url="https://github.com/acme/api/pull/7")
    gateway.states[run["workflow_id"]] = RunState(
        run_id=run["id"], kind="feature", stage="S4", prs=[pr], preview_url="https://pr-7.preview.localhost"
    )

    view = client.get(f"/api/v1/runs/{run['id']}", headers=bearer(VIEWER)).json()
    assert set(view) == {"run", "state", "prs", "preview_url", "traceability", "findings", "tests", "cost_by_agent"}
    assert view["state"]["stage"] == "S4" and view["prs"][0]["number"] == 7
    assert view["preview_url"] == "https://pr-7.preview.localhost"
    assert view["traceability"] == [
        {"ac_id": "AC-1", "text": "add item", "tests": ["T1"], "passed": True},
        {"ac_id": "AC-2", "text": "remove item", "tests": ["T2"], "passed": False},
        {"ac_id": "AC-3", "text": "checkout", "tests": [], "passed": None},
    ]
    assert [f["id"] for f in view["findings"]] == ["F1"]
    assert [t["id"] for t in view["tests"]] == ["T1", "T2"]
    assert view["cost_by_agent"] == {"spec-analyst": 0.75, "unit-test": 1.0}


def test_run_view_falls_back_to_snapshot(client: TestClient, world: World) -> None:
    run = create_run(client)
    view = client.get(f"/api/v1/runs/{run['id']}", headers=bearer(VIEWER)).json()
    assert view["state"]["stage"] == "queued" and view["traceability"] == []
    assert client.get("/api/v1/runs/nope", headers=bearer(VIEWER)).status_code == 404
    assert client.get(f"/api/v1/runs/{run['id']}", headers=bearer("eve@other.test")).status_code == 404


def test_cancel_and_retry(
    client: TestClient, world: World, gateway: FakeTemporalGateway, store: MemoryArtifactStore
) -> None:
    run = create_run(client)
    assert client.post(f"/api/v1/runs/{run['id']}/cancel", headers=bearer(VIEWER)).status_code == 403
    assert client.post(f"/api/v1/runs/{run['id']}/retry", headers=bearer(CONTRIBUTOR)).status_code == 409
    assert client.post(f"/api/v1/runs/{run['id']}/cancel", headers=bearer(CONTRIBUTOR)).status_code == 200
    assert gateway.cancels == [(run["workflow_id"], CONTRIBUTOR)]
    add_events(run["id"], {"type": "outcome", "message": "cancelled"}, outcome="cancelled")
    assert client.post(f"/api/v1/runs/{run['id']}/cancel", headers=bearer(CONTRIBUTOR)).status_code == 409
    retried = client.post(f"/api/v1/runs/{run['id']}/retry", headers=bearer(CONTRIBUTOR))
    assert retried.status_code == 201
    assert retried.json()["work_item_id"] == run["work_item_id"] and retried.json()["id"] != run["id"]
    assert gateway.starts[-1][1].options["retry_of"] == run["id"]


def test_sse_resumes_after_last_event_id_and_ends_with_outcome(client: TestClient, world: World) -> None:
    run = create_run(client)
    seqs = add_events(
        run["id"],
        {"type": "run_started", "message": "one"},
        {"type": "stage_started", "stage": "S1", "message": "two"},
        {"type": "stage_completed", "stage": "S1", "message": "three"},
        outcome="pr-ready",
    )
    headers = {**bearer(VIEWER), "Last-Event-ID": str(seqs[0])}
    with client.stream("GET", f"/api/v1/runs/{run['id']}/events", headers=headers) as r:
        assert r.status_code == 200 and r.headers["content-type"].startswith("text/event-stream")
        text = "".join(r.iter_text())
    ids = [int(line[3:].strip()) for line in text.splitlines() if line.startswith("id:")]
    data = [json.loads(line[5:]) for line in text.splitlines() if line.startswith("data:")]
    assert ids == seqs[1:]
    assert [d.get("message") for d in data[:2]] == ["two", "three"]
    assert "event: end" in text and data[-1]["outcome"] == "pr-ready"


def test_artifacts_list_and_download(client: TestClient, world: World, store: MemoryArtifactStore) -> None:
    run = create_run(client)
    store.objects[f"runs/{run['id']}/reports/audit.html"] = (b"<script>x</script>", "text/html")
    listed = client.get(f"/api/v1/runs/{run['id']}/artifacts", headers=bearer(VIEWER)).json()
    assert [a["name"] for a in listed] == ["reports/audit.html", "request.json"]
    r = client.get(f"/api/v1/runs/{run['id']}/artifacts/reports/audit.html", headers=bearer(VIEWER))
    assert r.status_code == 200 and r.content == b"<script>x</script>"
    assert r.headers["content-disposition"].startswith("attachment")
    assert "sandbox" in r.headers["content-security-policy"]
    request = client.get(f"/api/v1/runs/{run['id']}/artifacts/request.json", headers=bearer(VIEWER)).json()
    assert request["work_item"]["id"] == "REQ-001"
    assert client.get(f"/api/v1/runs/{run['id']}/artifacts/missing", headers=bearer(VIEWER)).status_code == 404
    assert client.get(f"/api/v1/runs/{run['id']}/artifacts/a/../b", headers=bearer(VIEWER)).status_code in (400, 404)


def test_sqlite_timestamps_are_served_as_utc(client: TestClient, world: World) -> None:
    run = create_run(client)
    add_events(run["id"], {"type": "run_started", "message": "one"}, outcome="pr-ready")
    view = client.get(f"/api/v1/runs/{run['id']}", headers=bearer(VIEWER))
    assert view.status_code == 200, view.text
    assert view.json()["run"]["created_at"].endswith(("Z", "+00:00"))
    with client.stream("GET", f"/api/v1/runs/{run['id']}/events", headers=bearer(VIEWER)) as r:
        text = "".join(r.iter_text())
    events = [json.loads(line[5:]) for line in text.splitlines() if line.startswith("data:")][:-1]
    assert events and all(e["at"].endswith(("Z", "+00:00")) for e in events)
