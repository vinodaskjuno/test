"""Confluence pages as spec sources: URL parsing, storage XHTML -> Markdown, and the upload/run endpoints."""

from __future__ import annotations

import base64

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from aidlc.api.confluence import page_id, storage_to_markdown
from aidlc.api.convert import UploadRejected
from aidlc.platform import db
from tests.api.conftest import ADMIN, CONTRIBUTOR, FakeTemporalGateway, MemoryArtifactStore, World, bearer

SITE = "https://acme.atlassian.net"
PAGE_URL = f"{SITE}/wiki/spaces/ENG/pages/12345/Order+export"
API = f"{SITE}/wiki/api/v2/pages/12345"
STORAGE = (
    "<h1>Order export</h1>"
    "<p>Managers <strong>export</strong> orders as <a href='https://acme.test/csv'>CSV</a>.</p>"
    "<ul><li>Filter by date<ul><li>Inclusive range</li></ul></li><li>Max 10k rows</li></ul>"
    "<table><tbody><tr><th>Column</th><th>Type</th></tr><tr><td><p>total</p></td><td>decimal | cents</td></tr>"
    "</tbody></table>"
    '<ac:structured-macro ac:name="code"><ac:parameter ac:name="language">sql</ac:parameter>'
    "<ac:plain-text-body><![CDATA[SELECT * FROM orders WHERE total > 0;]]></ac:plain-text-body>"
    "</ac:structured-macro>"
)
PAGE = {
    "id": "12345",
    "title": "Order export",
    "body": {"storage": {"value": STORAGE, "representation": "storage"}},
    "_links": {"base": f"{SITE}/wiki", "webui": "/spaces/ENG/pages/12345/Order+export"},
}
INTEGRATION = {"confluence": {"base_url": f"{SITE}/wiki", "user": "bot@acme.test", "api_token": "conf-token"}}


def test_storage_format_becomes_markdown() -> None:
    assert storage_to_markdown(STORAGE) == (
        "# Order export\n\n"
        "Managers **export** orders as [CSV](https://acme.test/csv).\n\n"
        "- Filter by date\n  - Inclusive range\n- Max 10k rows\n\n"
        "| Column | Type |\n| --- | --- |\n| total | decimal \\| cents |\n\n"
        "```sql\nSELECT * FROM orders WHERE total > 0;\n```"
    )


def test_macros_lists_and_links() -> None:
    storage = (
        "<ol><li>First</li><li>Second</li></ol>"
        '<ac:structured-macro ac:name="warning"><ac:parameter ac:name="title">PII</ac:parameter>'
        "<ac:rich-text-body><p>Mask emails.</p></ac:rich-text-body></ac:structured-macro>"
        '<p>See <ac:link><ri:page ri:content-title="Data policy"/></ac:link><br/>then <code>make test</code>.</p>'
        "<pre>raw ``` fence</pre>"
        "<ac:task-list><ac:task><ac:task-status>incomplete</ac:task-status>"
        "<ac:task-body>Sign off</ac:task-body></ac:task></ac:task-list>"
    )
    assert storage_to_markdown(storage) == (
        "1. First\n2. Second\n\n"
        "> **Warning: PII**\n>\n> Mask emails.\n\n"
        "See Data policy\nthen `make test`.\n\n"
        "````\nraw ``` fence\n````\n\n"
        "- [ ] Sign off"
    )


@pytest.mark.parametrize(
    ("url", "expected"),
    [
        (PAGE_URL, "12345"),
        (f"{SITE}/wiki/pages/viewpage.action?pageId=777", "777"),
        (f"{SITE}/wiki/spaces/ENG/pages/edit-v2/42", "42"),
    ],
)
def test_page_id_from_url(url: str, expected: str) -> None:
    assert page_id(url, SITE) == expected


@pytest.mark.parametrize(
    "url",
    [
        "https://evil.test/wiki/spaces/ENG/pages/12345/x",  # credentials only go to the configured site
        "http://acme.atlassian.net/wiki/spaces/ENG/pages/12345/x",
        f"{SITE}/wiki/x/AbCd",  # short link: no page id
    ],
)
def test_page_id_rejects(url: str) -> None:
    with pytest.raises(UploadRejected):
        page_id(url, SITE)


def _configure(client: TestClient) -> None:
    r = client.put("/api/v1/integrations?project_id=shop", json=INTEGRATION, headers=bearer(ADMIN))
    assert r.status_code == 200, r.text


@respx.mock
def test_upload_with_confluence_page_starts_run(
    client: TestClient, world: World, gateway: FakeTemporalGateway, store: MemoryArtifactStore
) -> None:
    _configure(client)
    route = respx.get(API).mock(return_value=httpx.Response(200, json=PAGE))
    r = client.post(
        "/api/v1/projects/shop/specs",
        data={"kind": "feature", "confluence_urls": [PAGE_URL]},
        headers=bearer(CONTRIBUTOR),
    )
    assert r.status_code == 201, r.text
    request = route.calls.last.request
    assert request.url.params["body-format"] == "storage"
    assert request.headers["Authorization"] == "Basic " + base64.b64encode(b"bot@acme.test:conf-token").decode()
    upload = r.json()["uploads"][0]
    assert (upload["kind"], upload["filename"]) == ("confluence", "confluence-12345.md")
    _, run_request, _ = gateway.starts[-1]
    source = run_request.work_item.sources[0]
    assert source.kind == "confluence" and source.uri == PAGE_URL
    assert source.content == storage_to_markdown(STORAGE)  # the page's own H1 is its title
    assert run_request.work_item.title == "Order export"
    with db.session_scope() as s:
        row = s.get(db.Upload, upload["id"])
        assert row.markdown == source.content
    assert store.objects[upload["artifact_key"]][0] == source.content.encode()


@respx.mock
def test_run_create_accepts_confluence_urls(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    _configure(client)
    respx.get(API).mock(return_value=httpx.Response(200, json=PAGE))
    body = {"project_id": "shop", "kind": "bugfix", "confluence_urls": [PAGE_URL]}
    r = client.post("/api/v1/runs", json=body, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 201, r.text
    work_item = gateway.starts[-1][1].work_item
    assert work_item.kind == "bug" and [s.kind for s in work_item.sources] == ["confluence"]


@respx.mock
@pytest.mark.parametrize(
    ("response", "code"),
    [
        (httpx.Response(404), 422),
        (httpx.Response(401), 422),
        (httpx.Response(500), 502),
        (httpx.Response(200, json={"id": "12345"}), 502),
    ],
)
def test_confluence_errors(client: TestClient, world: World, response: httpx.Response, code: int) -> None:
    _configure(client)
    respx.get(API).mock(return_value=response)
    r = client.post("/api/v1/projects/shop/specs", data={"confluence_urls": [PAGE_URL]}, headers=bearer(CONTRIBUTOR))
    assert r.status_code == code, r.text


def test_confluence_needs_the_integration(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    r = client.post("/api/v1/projects/shop/specs", data={"confluence_urls": [PAGE_URL]}, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 422 and "no Confluence integration" in r.json()["detail"]
    assert client.post("/api/v1/projects/shop/specs", data={}, headers=bearer(CONTRIBUTOR)).status_code == 422
    assert gateway.starts == []
