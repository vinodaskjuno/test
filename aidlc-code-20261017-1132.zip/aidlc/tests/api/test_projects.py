from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from aidlc.interfaces import CheckStatus
from aidlc.platform import db, factory
from tests.api.conftest import ADMIN, CONTRIBUTOR, MAINTAINER, VIEWER, FakeTemporalGateway, World, bearer


def test_project_crud_and_roles(client: TestClient, world: World) -> None:
    listed = client.get("/api/v1/projects", headers=bearer(VIEWER)).json()
    assert [(p["id"], p["role"]) for p in listed] == [("shop", "viewer")]
    project = client.get("/api/v1/projects/shop", headers=bearer(CONTRIBUTOR)).json()
    assert project["config"]["project_id"] == "shop"
    assert project["config"]["repos"][0]["url"] == "https://github.com/acme/api"

    patch = {
        "config": {"repos": [{"id": "web", "path": "/tmp/web"}], "merge_order": ["web"]},
        "gates": {"coverage_min_pct": 90},
    }
    r = client.patch("/api/v1/projects/shop", json=patch, headers=bearer(MAINTAINER))
    assert r.status_code == 200, r.text
    assert r.json()["config"]["merge_order"] == ["web"] and r.json()["gates"] == {"coverage_min_pct": 90}

    session = client.get("/api/v1/session", headers=bearer(MAINTAINER)).json()
    assert session["roles"] == {"shop": "maintainer"}
    with db.session_scope() as s:
        actions = [a.action for a in s.scalars(select(db.AuditLog))]
    assert "project.create" in actions and "project.update" in actions


def test_rbac_denials(client: TestClient, world: World) -> None:
    assert client.patch("/api/v1/projects/shop", json={"name": "x"}, headers=bearer(CONTRIBUTOR)).status_code == 403
    run = {"project_id": "shop", "kind": "feature", "title": "Add cart"}
    assert client.post("/api/v1/runs", json=run, headers=bearer(VIEWER)).status_code == 403
    assert client.post("/api/v1/teams", json={"name": "t"}, headers=bearer(MAINTAINER)).status_code == 403
    # Users outside the project's org do not learn it exists.
    assert client.get("/api/v1/projects/shop", headers=bearer("eve@other.test")).status_code == 404
    assert client.get("/api/v1/projects", headers=bearer("eve@other.test")).json() == []


def test_invalid_config_and_gates_are_rejected(client: TestClient, world: World) -> None:
    r = client.patch("/api/v1/projects/shop", json={"config": {"repos": "nope"}}, headers=bearer(MAINTAINER))
    assert r.status_code == 422
    r = client.patch("/api/v1/projects/shop", json={"gates": {"coverage_min_pct": 101}}, headers=bearer(MAINTAINER))
    assert r.status_code == 422
    r = client.patch("/api/v1/projects/shop", json={"gates": {"unknown_gate": 1}}, headers=bearer(MAINTAINER))
    assert r.status_code == 422


def test_adlc_config_yml_shape_is_accepted(client: TestClient, world: World) -> None:
    config = {
        "repos": {"api": {"url": "https://github.com/acme/api"}, "web": {"path": "/srv/web", "primary": True}},
        "integration_branch": "develop",
        "merge_order": ["api", "web"],
    }
    r = client.patch("/api/v1/projects/shop", json={"config": config}, headers=bearer(MAINTAINER))
    assert r.status_code == 200, r.text
    repos = {repo["id"]: repo for repo in r.json()["config"]["repos"]}
    assert repos["web"]["primary"] is True and repos["api"]["integration_branch"] == "develop"
    assert r.json()["config"]["name"] == "Shop"
    bad = {"repos": {"api": {}}}
    assert client.patch("/api/v1/projects/shop", json={"config": bad}, headers=bearer(MAINTAINER)).status_code == 422


def test_duplicate_project_id_conflicts(client: TestClient, world: World) -> None:
    body = {"name": "Shop", "id": "shop", "team_id": world.team_id}
    assert client.post("/api/v1/projects", json=body, headers=bearer(ADMIN)).status_code == 409


def test_onboard_starts_onboarding_workflow(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    body = {"mode": "new", "repo_name": "todo-app", "preset": "nextjs-fastapi"}
    r = client.post("/api/v1/projects/shop/onboard", json=body, headers=bearer(MAINTAINER))
    assert r.status_code == 201, r.text
    kind, request, workflow_id = gateway.starts[-1]
    assert kind == "onboarding" and workflow_id == f"run-{r.json()['id']}"
    assert request.options["repo_name"] == "todo-app"
    bad = client.post("/api/v1/projects/shop/onboard", json={"mode": "existing"}, headers=bearer(MAINTAINER))
    assert bad.status_code == 422


def test_existing_repo_onboarding_adds_the_repo_and_passes_options(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    body = {
        "mode": "existing",
        "repo_url": "https://github.com/acme/storefront.git",
        "integration_branch": "develop",
        "preset": "python",
    }
    r = client.post("/api/v1/projects/shop/onboard", json=body, headers=bearer(MAINTAINER))
    assert r.status_code == 201, r.text
    _, request, _ = gateway.starts[-1]
    assert request.options["repo_url"] == body["repo_url"]
    assert request.options["repo_id"] == "storefront" and request.options["integration_branch"] == "develop"
    repos = {repo.id: repo for repo in request.project.repos}
    assert repos["storefront"].url == body["repo_url"] and repos["storefront"].primary is False
    project = client.get("/api/v1/projects/shop", headers=bearer(VIEWER)).json()
    assert [repo["id"] for repo in project["config"]["repos"]] == ["api", "storefront"]

    # An already-configured repo is reused (matched by URL), keeping its id.
    again = {"mode": "existing", "repo_url": "https://github.com/acme/api/"}
    client.post("/api/v1/projects/shop/onboard", json=again, headers=bearer(MAINTAINER))
    assert gateway.starts[-1][1].options["repo_id"] == "api"
    clash = {"mode": "existing", "repo_url": "https://github.com/acme/other", "repo_id": "api"}
    assert client.post("/api/v1/projects/shop/onboard", json=clash, headers=bearer(MAINTAINER)).status_code == 409


class _Forge:
    async def get_checks(self, repo_url: str, ref: str) -> list[CheckStatus]:
        return [CheckStatus(name="aidlc/gates", status="completed", conclusion="success")]


def test_doctor_reports_checks(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    assert client.get("/api/v1/projects/shop/doctor", headers=bearer(VIEWER)).json() == {
        "checks": [],
        "checked_at": None,
    }
    factory.set_override("forge", _Forge())
    gateway.healthy = False
    report = client.post("/api/v1/projects/shop/doctor", headers=bearer(MAINTAINER)).json()
    status = {c["name"]: c["status"] for c in report["checks"]}
    assert status == {
        "repo:api": "ok",
        "required-check:api": "ok",
        "model-access": "unknown",
        "temporal": "fail",
    }
    model = next(c["detail"] for c in report["checks"] if c["name"] == "model-access")
    assert "Amazon Bedrock in us-east-1" in model and "claude-opus-5-5 → anthropic.claude-opus-5-5" in model
    assert client.get("/api/v1/projects/shop/doctor", headers=bearer(VIEWER)).json() == report


def test_webhook_subscriptions(client: TestClient, world: World) -> None:
    body = {"url": "https://hooks.example.test/aidlc", "events": ["run.pr_ready", "run.failed"]}
    created = client.post("/api/v1/projects/shop/webhooks", json=body, headers=bearer(MAINTAINER))
    assert created.status_code == 201
    assert len(created.json()["secret"]) == 64
    listed = client.get("/api/v1/projects/shop/webhooks", headers=bearer(MAINTAINER)).json()
    assert listed[0]["url"] == body["url"] and "secret" not in listed[0]
    assert client.get("/api/v1/projects/shop/webhooks", headers=bearer(CONTRIBUTOR)).status_code == 403
    wid = created.json()["id"]
    assert client.delete(f"/api/v1/projects/shop/webhooks/{wid}", headers=bearer(MAINTAINER)).status_code == 204
    assert client.get("/api/v1/projects/shop/webhooks", headers=bearer(MAINTAINER)).json() == []


FULL_INTEGRATIONS = {
    "github": {},
    "jira": {
        "base_url": "https://acme.atlassian.net",
        "user": "bot@acme.test",
        "api_token": "jira-secret",
        "project_key": "SHOP",
    },
    "confluence": {"base_url": "https://acme.atlassian.net/wiki", "user": "bot@acme.test", "api_token": "conf-secret"},
    "figma": {"mcp_url": "https://mcp.figma.test/mcp", "token": "figma-secret"},
    "jenkins": {
        "base_url": "https://ci.acme.test",
        "user": "aidlc",
        "api_token": "jenkins-secret",
        "job_path": "job/{repo}/job/{branch}",
    },
    "slack": {"webhook_url": "https://hooks.slack.test/T0/B0/x"},
    "teams": {"webhook_url": "https://acme.webhook.office.test/x"},
    "email": {"recipients": ["leads@acme.test", "qa@acme.test"]},
}
SECRETS = {("jira", "api_token"), ("confluence", "api_token"), ("figma", "token"), ("jenkins", "api_token")}


def test_integrations_mask_secrets_and_keep_them_on_round_trip(client: TestClient, world: World) -> None:
    url = "/api/v1/integrations?project_id=shop"
    assert client.put(url, json=FULL_INTEGRATIONS, headers=bearer(MAINTAINER)).status_code == 403
    r = client.put(url, json=FULL_INTEGRATIONS, headers=bearer(ADMIN))
    assert r.status_code == 200, r.text
    shown = r.json()["integrations"]
    for provider, fields in FULL_INTEGRATIONS.items():
        for key, value in fields.items():
            assert shown[provider][key] == ("********" if (provider, key) in SECRETS else value)
    assert client.get(url, headers=bearer(MAINTAINER)).json()["integrations"] == shown

    # Sending the masked form back keeps every secret; an emptied field clears that provider's value.
    echoed = {**shown, "figma": {"mcp_url": "https://mcp.figma.test/mcp", "token": None}}
    assert client.put(url, json=echoed, headers=bearer(ADMIN)).status_code == 200
    with db.session_scope() as s:
        stored = s.get(db.Project, "shop").integrations
    assert stored["jira"]["api_token"] == "jira-secret" and stored["jenkins"]["api_token"] == "jenkins-secret"
    assert stored["figma"] == {"mcp_url": "https://mcp.figma.test/mcp"}
    assert stored["github"] == {}  # unconfigured providers are stored empty, never as nulls
    # Integrations live in their own column, never in the ProjectConfig.
    assert "integrations" not in client.get("/api/v1/projects/shop", headers=bearer(VIEWER)).json()["config"]


@pytest.mark.parametrize(
    "body",
    [
        {"jira": {"project_key": "SHOP", "api_token": "s3cret"}},  # incomplete
        {"slack": {"channel": "#dev"}},  # unknown field
        {"slack": {"webhook_url": "http://hooks.slack.test/x"}},  # webhooks must be https
        {"jenkins": {**FULL_INTEGRATIONS["jenkins"], "job_path": "job/{repo}/{sha}"}},
        {"jenkins": {**FULL_INTEGRATIONS["jenkins"], "job_path": "/job/../{repo}"}},
        {"email": {"recipients": ["not-an-email"]}},
        {"jira": {**FULL_INTEGRATIONS["jira"], "project_key": "shop"}},
        {"figma": {"token": "only-a-token"}},
        {"github": {"token": "x"}},
    ],
)
def test_integrations_validate_shapes(client: TestClient, world: World, body: dict) -> None:
    r = client.put("/api/v1/integrations?project_id=shop", json=body, headers=bearer(ADMIN))
    assert r.status_code == 422, r.text


def test_masked_secret_without_stored_value_is_rejected(client: TestClient, world: World) -> None:
    body = {"confluence": {**FULL_INTEGRATIONS["confluence"], "api_token": "********"}}
    assert client.put("/api/v1/integrations?project_id=shop", json=body, headers=bearer(ADMIN)).status_code == 422


def test_legacy_integration_settings_read_as_typed(client: TestClient, world: World) -> None:
    with db.session_scope() as s:
        s.get(db.Project, "shop").integrations = {
            "slack": {"webhook_url": "https://hooks.slack.test/x", "channel": "#dev"},
            "jira": {"project_key": "SHOP"},
        }
    shown = client.get("/api/v1/integrations?project_id=shop", headers=bearer(MAINTAINER)).json()["integrations"]
    assert shown["slack"] == {"webhook_url": "https://hooks.slack.test/x"}
    assert shown["jira"] == {"base_url": None, "user": None, "api_token": None, "project_key": None}


def test_teams_listing_and_membership(client: TestClient, world: World) -> None:
    teams = client.get("/api/v1/teams", headers=bearer(VIEWER)).json()
    assert [t["id"] for t in teams] == [world.team_id]
    roles = {m["user_id"]: m["role"] for m in teams[0]["members"]}
    assert roles[CONTRIBUTOR] == "contributor"
    r = client.put(
        f"/api/v1/teams/{world.team_id}/members",
        json={"members": [{"user_id": MAINTAINER, "role": "admin"}]},
        headers=bearer(ADMIN),
    )
    assert [m["user_id"] for m in r.json()["members"]] == [MAINTAINER]
    assert client.get("/api/v1/projects", headers=bearer(VIEWER)).json() == []
