from __future__ import annotations

import importlib.util
import json
import re
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from aidlc.api.convert import ALLOWED
from aidlc.api.main import create_app
from aidlc.settings import ROOT, get_settings
from tests.api.conftest import VIEWER, bearer

# Every endpoint of "Control-plane REST API v1" in CLAUDE.md, as (method, path).
CONTRACT = {
    ("get", "/api/v1/session"),
    ("put", "/api/v1/me/preferences"),
    ("get", "/api/v1/projects"),
    ("post", "/api/v1/projects"),
    ("get", "/api/v1/projects/{project_id}"),
    ("patch", "/api/v1/projects/{project_id}"),
    ("post", "/api/v1/projects/{project_id}/onboard"),
    ("get", "/api/v1/projects/{project_id}/doctor"),
    ("post", "/api/v1/projects/{project_id}/specs"),
    ("get", "/api/v1/runs"),
    ("post", "/api/v1/runs"),
    ("get", "/api/v1/runs/{run_id}"),
    ("post", "/api/v1/runs/{run_id}/cancel"),
    ("post", "/api/v1/runs/{run_id}/retry"),
    ("get", "/api/v1/runs/{run_id}/events"),
    ("get", "/api/v1/runs/{run_id}/artifacts"),
    ("get", "/api/v1/runs/{run_id}/artifacts/{name}"),
    ("get", "/api/v1/inbox"),
    ("post", "/api/v1/inbox/{item_id}/answer"),
    ("post", "/api/v1/inbox/{item_id}/decide"),
    ("get", "/api/v1/sprints"),
    ("post", "/api/v1/sprints"),
    ("get", "/api/v1/manifest"),
    ("get", "/api/v1/gates"),
    ("get", "/api/v1/audits"),
    ("post", "/api/v1/audits"),
    ("get", "/api/v1/backlog"),
    ("post", "/api/v1/backlog/{item_id}/promote"),
    ("get", "/api/v1/knowledge"),
    ("get", "/api/v1/agents"),
    ("get", "/api/v1/agents/{agent_id}"),
    ("post", "/api/v1/agents/{agent_id}/promote"),
    ("post", "/api/v1/agents/{agent_id}/rollback"),
    ("get", "/api/v1/cost"),
    ("get", "/api/v1/integrations"),
    ("put", "/api/v1/integrations"),
    ("get", "/api/v1/teams"),
    ("post", "/api/v1/teams"),
    ("put", "/api/v1/teams/{team_id}/members"),
    ("get", "/api/v1/projects/{project_id}/webhooks"),
    ("post", "/api/v1/projects/{project_id}/webhooks"),
    ("get", "/api/v1/previews"),
    ("post", "/api/v1/verify-branch"),
    ("post", "/api/v1/hooks/github"),
    ("post", "/api/v1/hooks/jira"),
    ("get", "/metrics"),
    ("get", "/api/v1/config"),
    ("get", "/api/v1/inbox/{item_id}"),
    ("post", "/api/v1/agents/{agent_id}/evals"),
    ("get", "/api/v1/audits/schedules"),
    ("post", "/api/v1/audits/schedules"),
    ("delete", "/api/v1/audits/schedules/{schedule_id}"),
}
GUIDE_CSP_DIRECTIVES = {
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self'",
    "img-src 'self' data:",
    "font-src 'self'",
    "connect-src 'self'",
    "frame-ancestors 'none'",
}


def test_healthz_and_security_headers(client: TestClient) -> None:
    r = client.get("/healthz")
    assert r.json() == {"status": "ok"}
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["content-security-policy"].startswith("default-src 'none'")
    assert r.headers["x-frame-options"] == "DENY"


def test_cors_allows_the_web_ui_origin(client: TestClient) -> None:
    r = client.options(
        "/api/v1/session",
        headers={"Origin": "http://localhost:3000", "Access-Control-Request-Method": "GET"},
    )
    assert r.headers["access-control-allow-origin"] == "http://localhost:3000"
    evil = client.options(
        "/api/v1/session", headers={"Origin": "https://evil.test", "Access-Control-Request-Method": "GET"}
    )
    assert "access-control-allow-origin" not in evil.headers


def test_metrics_count_requests_by_route(client: TestClient) -> None:
    client.get("/api/v1/session", headers=bearer(VIEWER))
    body = client.get("/metrics").text
    assert 'aidlc_api_requests_total{method="GET",route="/api/v1/session",status="200"}' in body


def test_openapi_export_covers_the_contract(tmp_path: Path) -> None:
    spec_path = ROOT / "scripts" / "export_openapi.py"
    spec = importlib.util.spec_from_file_location("export_openapi", spec_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    out = tmp_path / "clients" / "openapi.json"
    module.export(out)
    document = json.loads(out.read_text())
    operations = {(method, path) for path, ops in document["paths"].items() for method in ops}
    assert operations >= CONTRACT, sorted(CONTRACT - operations)
    for path, ops in document["paths"].items():
        for method, op in ops.items():
            assert "200" in op["responses"] or "201" in op["responses"] or "204" in op["responses"], (method, path)
    assert "HTTPBearer" in document["components"]["securitySchemes"]
    assert "RunView" in document["components"]["schemas"]


def test_every_operation_has_an_explicit_stable_id() -> None:
    document = create_app().openapi()
    ids = [op["operationId"] for ops in document["paths"].values() for op in ops.values()]
    assert len(ids) == len(set(ids))
    generated = [i for i in ids if not re.fullmatch(r"[a-z][A-Za-z]+", i)]
    assert generated == [], "set operation_id= on these routes"
    named = {(m, p): op["operationId"] for p, ops in document["paths"].items() for m, op in ops.items()}
    assert named[("get", "/api/v1/runs")] == "listRuns"
    assert named[("get", "/api/v1/runs/{run_id}/events")] == "streamRunEvents"
    assert named[("post", "/api/v1/projects/{project_id}/specs")] == "uploadSpecs"
    assert named[("post", "/api/v1/inbox/{item_id}/answer")] == "answerInboxItem"


def test_run_events_stream_references_a_named_schema() -> None:
    document = create_app().openapi()
    response = document["paths"]["/api/v1/runs/{run_id}/events"]["get"]["responses"]["200"]
    assert response["content"] == {"text/event-stream": {"schema": {"$ref": "#/components/schemas/RunEventView"}}}
    assert set(document["components"]["schemas"]["RunEventView"]["required"]) >= {"seq", "run_id", "type", "data"}


def test_public_config_needs_no_auth(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_UPLOAD_MAX_BYTES", "1234")
    get_settings.cache_clear()
    config = client.get("/api/v1/config").json()
    assert config["upload_max_bytes"] == 1234 and config["auth_mode"] == "dev" and config["oidc"] is None
    assert ".md" in config["allowed_extensions"] and ".gif" not in config["allowed_extensions"]
    assert config["allowed_extensions"] == sorted(ALLOWED) and config["version"]

    monkeypatch.setenv("AIDLC_AUTH_MODE", "oidc")
    monkeypatch.setenv("AIDLC_OIDC_ISSUER", "https://login.example.test/tenant/v2.0")
    monkeypatch.setenv("AIDLC_OIDC_AUDIENCE", "client-123")
    get_settings.cache_clear()
    assert client.get("/api/v1/config").json()["oidc"] == {
        "issuer": "https://login.example.test/tenant/v2.0",
        "client_id": "client-123",
    }


def test_guide_is_served_under_a_strict_csp(client: TestClient) -> None:
    r = client.get("/guide/")
    if r.status_code == 404:
        pytest.skip("docs/guide has not been built")
    directives = {d.strip() for d in r.headers["content-security-policy"].split(";")}
    assert directives >= GUIDE_CSP_DIRECTIVES
    assert not any("unsafe" in d for d in directives)
