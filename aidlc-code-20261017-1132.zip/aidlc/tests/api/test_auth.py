from __future__ import annotations

import time

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient

from aidlc.api import auth
from aidlc.api.main import create_app
from aidlc.api.ratelimit import RateLimiter
from aidlc.platform import db
from aidlc.settings import get_settings
from tests.api.conftest import ADMIN, VIEWER, bearer

ISSUER = "https://login.example.test/tenant/v2.0"
AUDIENCE = "api://aidlc"


def test_dev_token_provisions_user_and_first_user_is_admin(client: TestClient) -> None:
    first = client.get("/api/v1/session", headers=bearer(ADMIN)).json()
    second = client.get("/api/v1/session", headers=bearer(VIEWER)).json()
    assert first["user"] == {"id": ADMIN, "name": "admin", "email": ADMIN, "is_admin": True}
    assert second["user"]["is_admin"] is False
    assert second["preferences"]["theme"] == "system"


def test_missing_and_malformed_tokens_are_rejected(client: TestClient) -> None:
    assert client.get("/api/v1/session").status_code == 401
    assert client.get("/api/v1/session", headers={"Authorization": "Bearer dev:not-an-email"}).status_code == 401
    assert client.get("/api/v1/session", headers={"Authorization": "Bearer aidlc_unknown"}).status_code == 401


def test_dev_tokens_disabled_outside_dev_mode(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_AUTH_MODE", "oidc")
    get_settings.cache_clear()
    r = client.get("/api/v1/session", headers=bearer(ADMIN))
    assert r.status_code == 401
    assert "disabled" in r.json()["detail"]


@pytest.fixture
def oidc(monkeypatch: pytest.MonkeyPatch):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    monkeypatch.setenv("AIDLC_AUTH_MODE", "oidc")
    monkeypatch.setenv("AIDLC_OIDC_ISSUER", ISSUER)
    monkeypatch.setenv("AIDLC_OIDC_AUDIENCE", AUDIENCE)
    monkeypatch.setenv("AIDLC_OIDC_JWKS_URL", "https://login.example.test/keys")
    get_settings.cache_clear()

    class FakeJwks:
        def get_signing_key_from_jwt(self, token: str):
            assert jwt.get_unverified_header(token)["kid"] == "k1"
            return jwt.PyJWK.from_dict(
                {**jwt.algorithms.RSAAlgorithm.to_jwk(key.public_key(), as_dict=True), "kid": "k1", "alg": "RS256"}
            )

    monkeypatch.setattr(auth, "jwks_client", lambda url: FakeJwks())

    def issue(**overrides) -> str:
        claims = {
            "iss": ISSUER,
            "aud": AUDIENCE,
            "sub": "subject-1",
            "email": "Ada@Acme.test",
            "name": "Ada",
            "exp": int(time.time()) + 300,
            **overrides,
        }
        return jwt.encode(claims, key, algorithm="RS256", headers={"kid": "k1"})

    return issue


def test_oidc_token_is_validated_against_jwks(client: TestClient, oidc) -> None:
    r = client.get("/api/v1/session", headers={"Authorization": f"Bearer {oidc()}"})
    assert r.status_code == 200, r.text
    assert r.json()["user"]["id"] == "ada@acme.test"
    assert r.json()["user"]["name"] == "Ada"


@pytest.mark.parametrize(
    "overrides", [{"aud": "someone-else"}, {"iss": "https://evil.test"}, {"exp": int(time.time()) - 10}]
)
def test_oidc_rejects_wrong_audience_issuer_or_expired(client: TestClient, oidc, overrides) -> None:
    r = client.get("/api/v1/session", headers={"Authorization": f"Bearer {oidc(**overrides)}"})
    assert r.status_code == 401


def test_api_token_lifecycle(client: TestClient) -> None:
    created = client.post("/api/v1/me/tokens", json={"name": "ci"}, headers=bearer(ADMIN))
    assert created.status_code == 201
    token = created.json()["token"]
    assert token.startswith("aidlc_")
    with db.session_scope() as s:
        stored = s.get(db.ApiToken, created.json()["id"])
        assert stored.token_hash == auth.hash_token(token) and token not in stored.token_hash
    via_token = client.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"})
    assert via_token.json()["user"]["id"] == ADMIN
    listed = client.get("/api/v1/me/tokens", headers=bearer(ADMIN)).json()
    assert [t["name"] for t in listed] == ["ci"] and "token" not in listed[0]
    assert client.delete(f"/api/v1/me/tokens/{created.json()['id']}", headers=bearer(ADMIN)).status_code == 204
    assert client.get("/api/v1/session", headers={"Authorization": f"Bearer {token}"}).status_code == 401


def test_other_users_cannot_revoke_my_token(client: TestClient) -> None:
    created = client.post("/api/v1/me/tokens", json={"name": "ci"}, headers=bearer(ADMIN)).json()
    assert client.delete(f"/api/v1/me/tokens/{created['id']}", headers=bearer(VIEWER)).status_code == 404


def test_preferences_round_trip(client: TestClient) -> None:
    default = client.get("/api/v1/session", headers=bearer(ADMIN)).json()["preferences"]
    assert default["notifications"]["events"] == [
        "gate_waiting",
        "pr_ready",
        "failed",
        "escalation",
        "ci_failing",
        "audit_finished",
    ]
    prefs = {
        "theme": "dark",
        "notifications": {"channels": ["slack"], "events": ["pr_ready", "ci_failing"], "muted_projects": ["shop"]},
    }
    assert client.put("/api/v1/me/preferences", json=prefs, headers=bearer(ADMIN)).status_code == 200
    assert client.get("/api/v1/session", headers=bearer(ADMIN)).json()["preferences"] == prefs


@pytest.mark.parametrize(
    "notifications",
    [
        {"channels": ["pager"]},
        {"events": ["completed"]},
        {"events": ["pr_ready"], "extra": True},
    ],
)
def test_preferences_validate_the_shape(client: TestClient, notifications: dict) -> None:
    body = {"theme": "light", "notifications": notifications}
    assert client.put("/api/v1/me/preferences", json=body, headers=bearer(ADMIN)).status_code == 422


def test_rate_limit_per_token(gateway, store) -> None:
    app = create_app(gateway, rate_limiter=RateLimiter(rate_per_s=0.001, burst=2))
    with TestClient(app) as c:
        codes = [c.get("/api/v1/session", headers=bearer(ADMIN)).status_code for _ in range(3)]
        other = c.get("/api/v1/session", headers=bearer(VIEWER)).status_code
        limited = c.get("/api/v1/session", headers=bearer(ADMIN))
    assert codes == [200, 200, 429]
    assert other == 200
    assert int(limited.headers["Retry-After"]) >= 1
