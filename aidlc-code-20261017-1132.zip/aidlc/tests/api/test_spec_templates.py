"""Spec templates over the API: download in each format, check a filled spec, and the check at upload time."""

from __future__ import annotations

import io

import docx
from fastapi.testclient import TestClient
from sqlalchemy import select

from aidlc.platform import db
from aidlc.platform.spec_templates import example_text, template_text
from aidlc.platform.spec_templates.render import to_docx
from tests.api.conftest import CONTRIBUTOR, FakeTemporalGateway, World, bearer


def shop_spec(type_id: str = "backend") -> str:
    """An example re-addressed to the test project, with one guidance comment the agents must not see."""
    text = example_text(type_id).replace("| Project id | storefront |", "| Project id | shop |")
    return text.replace("## Spec details", "<!-- guide: written by the requester -->\n\n## Spec details", 1)


def upload(client: TestClient, text: str, *, kind: str = "feature", name: str = "spec.md", data: bytes | None = None):
    return client.post(
        "/api/v1/projects/shop/specs",
        files=[("files", (name, data if data is not None else text.encode(), "application/octet-stream"))],
        data={"kind": kind},
        headers=bearer(CONTRIBUTOR),
    )


def test_templates_are_listed_and_downloadable_in_every_format(client: TestClient, world: World) -> None:
    listed = client.get("/api/v1/spec-templates", headers=bearer(CONTRIBUTOR)).json()
    assert [t["id"] for t in listed][:4] == ["ui-only", "ui-backend", "backend", "vsix"]
    assert next(t for t in listed if t["id"] == "integration")["surfaces"] == ["backend", "integration"]

    md = client.get("/api/v1/spec-templates/vsix", headers=bearer(CONTRIBUTOR))
    assert md.status_code == 200 and md.text == template_text("vsix")
    assert md.headers["content-disposition"] == 'attachment; filename="aidlc-spec-vsix.md"'
    word = client.get("/api/v1/spec-templates/bug?format=docx&example=true", headers=bearer(CONTRIBUTOR))
    assert word.headers["content-type"].startswith("application/vnd.openxmlformats")
    assert docx.Document(io.BytesIO(word.content)).paragraphs[0].text == example_text("bug").splitlines()[0][2:]
    page = client.get("/api/v1/spec-templates/ui-only?format=confluence", headers=bearer(CONTRIBUTOR))
    assert page.text.startswith("<h1>")
    assert client.get("/api/v1/spec-templates/mobile", headers=bearer(CONTRIBUTOR)).status_code == 404
    assert client.get("/api/v1/spec-templates").status_code == 401


def test_check_reports_without_starting_a_run(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    ok = client.post("/api/v1/spec-templates/check", json={"markdown": shop_spec()}, headers=bearer(CONTRIBUTOR))
    assert ok.status_code == 200 and ok.json()["errors"] == [] and ok.json()["surfaces"] == ["backend", "data"]
    blank = client.post(
        "/api/v1/spec-templates/check", json={"markdown": template_text("backend")}, headers=bearer(CONTRIBUTOR)
    ).json()
    assert blank["templated"] and "Spec details: Title is not filled in" in blank["errors"]
    assert not gateway.starts


def test_a_valid_templated_upload_carries_surfaces_tier_budget_and_clean_text(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    r = upload(client, shop_spec())
    assert r.status_code == 201, r.text
    _, request, _ = gateway.starts[-1]
    item = request.work_item
    assert item.surfaces == ["backend", "data"]
    assert item.title == "Storefront order status updates (API)" and item.repo_hints == ["storefront"]
    assert "guide:" not in item.sources[0].content and "| Surfaces | backend, data |" in item.sources[0].content
    assert request.options["spec_check"] == {"template": "backend", "gaps": [], "warnings": []}
    assert (request.options["risk_tier"], request.options["budget_usd"]) == ("medium", 30.0)
    with db.session_scope() as s:  # the stored upload keeps what the requester sent
        assert "guide:" in s.scalars(select(db.Upload)).one().markdown


def test_a_word_upload_is_checked_like_markdown(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    r = upload(client, "", name="spec.docx", data=to_docx(shop_spec("ui-backend").replace("feedback-hub", "shop")))
    assert r.status_code == 201, r.text
    assert gateway.starts[-1][1].work_item.surfaces == ["ui", "backend"]


def test_an_incomplete_templated_spec_is_rejected_with_every_error_and_nothing_stored(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    r = upload(client, template_text("backend"))
    assert r.status_code == 422
    detail = r.json()["detail"]
    assert detail["message"] == "the spec does not pass the template check"
    assert "spec.md: Spec details: Title is not filled in" in detail["errors"] and len(detail["errors"]) > 20
    assert not gateway.starts
    with db.session_scope() as s:
        assert s.scalars(select(db.Upload)).first() is None


def test_a_bug_template_must_be_sent_as_a_bug_and_to_its_own_project(client: TestClient, world: World) -> None:
    as_feature = upload(client, shop_spec("bug")).json()["detail"]["errors"]
    assert as_feature == ["spec.md is a bug template; submit it as a bug (--type bug)"]
    assert upload(client, shop_spec("bug"), kind="bug").status_code == 201
    elsewhere = upload(client, example_text("vsix")).json()["detail"]["errors"]
    assert elsewhere == ["the spec names project 'prompt-snippets' but was submitted to project 'shop'"]


def test_post_runs_checks_templated_sources_too(client: TestClient, world: World, gateway: FakeTemporalGateway) -> None:
    body = {"project_id": "shop", "kind": "feature", "sources": [{"kind": "markdown", "name": "s.md"}]}
    body["sources"][0]["content"] = shop_spec()
    r = client.post("/api/v1/runs", json=body, headers=bearer(CONTRIBUTOR))
    assert r.status_code == 201, r.text
    assert gateway.starts[-1][1].work_item.surfaces == ["backend", "data"]
    body["sources"][0]["content"] = template_text("ui-only")
    assert client.post("/api/v1/runs", json=body, headers=bearer(CONTRIBUTOR)).status_code == 422
