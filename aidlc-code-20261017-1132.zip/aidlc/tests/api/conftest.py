"""API test fixtures: a recording fake Temporal gateway, an in-memory artifact store and a seeded org."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pytest
from fastapi.testclient import TestClient

from aidlc.api.main import create_app
from aidlc.api.ratelimit import RateLimiter
from aidlc.api.temporal import ScheduleInfo
from aidlc.contracts import RunKind, RunRequest, RunState
from aidlc.platform import factory


@dataclass
class FakeSchedule:
    cron: str
    timezone: str
    kind: RunKind
    request: RunRequest
    workflow_id: str
    memo: dict[str, Any]


@dataclass
class FakeTemporalGateway:
    starts: list[tuple[str, RunRequest, str]] = field(default_factory=list)
    signals: list[tuple[str, str, dict[str, Any]]] = field(default_factory=list)
    cancels: list[tuple[str, str]] = field(default_factory=list)
    states: dict[str, RunState] = field(default_factory=dict)
    schedules: dict[str, FakeSchedule] = field(default_factory=dict)
    healthy: bool = True
    fail_start: bool = False
    statuses: dict[str, str | None] = field(default_factory=dict)  # workflow id -> status; started ones run

    async def start(self, kind: RunKind, request: RunRequest, workflow_id: str) -> None:
        if self.fail_start:
            raise ConnectionError("temporal down")
        self.starts.append((kind, request, workflow_id))

    async def signal(self, workflow_id: str, name: str, payload: dict[str, Any]) -> None:
        self.signals.append((workflow_id, name, payload))

    async def query_state(self, workflow_id: str) -> RunState | None:
        return self.states.get(workflow_id)

    async def cancel(self, workflow_id: str, user: str) -> None:
        self.cancels.append((workflow_id, user))

    async def ping(self) -> bool:
        return self.healthy

    async def workflow_status(self, workflow_id: str) -> str | None:
        if workflow_id in self.statuses:
            return self.statuses[workflow_id]
        return "running" if any(w == workflow_id for _, _, w in self.starts) else None

    async def create_schedule(
        self,
        schedule_id: str,
        *,
        cron: str,
        timezone: str,
        kind: RunKind,
        request: RunRequest,
        workflow_id: str,
        memo: dict[str, Any],
    ) -> None:
        if self.fail_start:
            raise ConnectionError("temporal down")
        if schedule_id in self.schedules:
            raise ValueError(f"schedule {schedule_id} already exists")
        self.schedules[schedule_id] = FakeSchedule(cron, timezone, kind, request, workflow_id, memo)

    async def list_schedules(self, prefix: str) -> list[ScheduleInfo]:
        return [
            ScheduleInfo(id=sid, memo=dict(s.memo), recent_workflow_ids=[f"{s.workflow_id}-2026-10-12T03:00:00Z"])
            for sid, s in self.schedules.items()
            if sid.startswith(prefix)
        ]

    async def delete_schedule(self, schedule_id: str) -> None:
        del self.schedules[schedule_id]


class MemoryArtifactStore:
    def __init__(self) -> None:
        self.objects: dict[str, tuple[bytes, str]] = {}

    async def put(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        self.objects[key] = (data, content_type)
        return key

    async def get(self, key: str) -> bytes:
        if key not in self.objects:
            raise KeyError(key)
        return self.objects[key][0]

    async def keys(self, prefix: str = "") -> list[str]:
        return [k for k in self.objects if k.startswith(prefix)]


def bearer(email: str) -> dict[str, str]:
    return {"Authorization": f"Bearer dev:{email}"}


ADMIN = "admin@acme.test"
MAINTAINER = "maint@acme.test"
CONTRIBUTOR = "contrib@acme.test"
VIEWER = "viewer@acme.test"


@pytest.fixture
def gateway() -> FakeTemporalGateway:
    return FakeTemporalGateway()


@pytest.fixture
def store() -> MemoryArtifactStore:
    s = MemoryArtifactStore()
    factory.set_override("artifacts", s)
    return s


@pytest.fixture
def app(gateway: FakeTemporalGateway, store: MemoryArtifactStore):
    application = create_app(gateway, rate_limiter=RateLimiter(rate_per_s=1000, burst=1000))
    application.state.sse_poll_s = 0.01
    return application


@pytest.fixture
def client(app) -> TestClient:
    with TestClient(app) as c:
        yield c


@dataclass
class World:
    team_id: str
    project_id: str


@pytest.fixture
def world(client: TestClient) -> World:
    """acme.test org: admin (first user), one team with a maintainer, contributor and viewer, one project."""
    assert client.get("/api/v1/session", headers=bearer(ADMIN)).json()["user"]["is_admin"] is True
    team = client.post("/api/v1/teams", json={"name": "core"}, headers=bearer(ADMIN)).json()
    members = [
        {"user_id": MAINTAINER, "role": "maintainer"},
        {"user_id": CONTRIBUTOR, "role": "contributor"},
        {"user_id": VIEWER, "role": "viewer"},
    ]
    r = client.put(f"/api/v1/teams/{team['id']}/members", json={"members": members}, headers=bearer(ADMIN))
    assert r.status_code == 200, r.text
    r = client.post(
        "/api/v1/projects",
        json={
            "name": "Shop",
            "id": "shop",
            "team_id": team["id"],
            "config": {"repos": [{"id": "api", "url": "https://github.com/acme/api", "primary": True}]},
        },
        headers=bearer(MAINTAINER),
    )
    assert r.status_code == 201, r.text
    return World(team_id=team["id"], project_id="shop")
