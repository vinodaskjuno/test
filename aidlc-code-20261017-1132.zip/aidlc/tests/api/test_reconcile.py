"""Runs whose workflow ended outside the platform are closed with their Inbox items, and audited."""

from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import select

from aidlc.api.reconcile import reconcile_runs
from aidlc.platform import db
from tests.api.conftest import FakeTemporalGateway, World
from tests.api.test_runs import create_run


def _escalation(run_id: str) -> str:
    with db.session_scope() as s:
        item = db.InboxItem(
            id=f"{run_id}:ESC-1", run_id=run_id, project_id="shop", kind="escalation", ref_id="ESC-1", title="stuck"
        )
        s.add(item)
        return item.id


async def test_runs_whose_workflow_ended_or_vanished_are_closed(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    alive, terminated, vanished = (create_run(client)["id"] for _ in range(3))
    with db.session_scope() as s:
        workflows = {r.id: r.workflow_id for r in s.scalars(select(db.Run))}
    gateway.statuses[workflows[terminated]] = "terminated"
    gateway.statuses[workflows[vanished]] = None
    item = _escalation(terminated)

    assert sorted(await reconcile_runs(gateway)) == sorted([terminated, vanished])
    with db.session_scope() as s:
        assert s.get(db.Run, alive).outcome is None
        assert (s.get(db.Run, terminated).outcome, s.get(db.Run, terminated).stage) == ("cancelled", "done")
        assert s.get(db.Run, vanished).outcome == "cancelled"
        closed = s.get(db.InboxItem, item)
        assert closed.status == "resolved" and closed.resolution["reason"] == "run ended: workflow terminated"
        audited = {a.target for a in s.scalars(select(db.AuditLog).where(db.AuditLog.action == "run.reconciled"))}
        assert audited == {terminated, vanished}
    assert await reconcile_runs(gateway) == []  # nothing left to close


async def test_a_failed_workflow_closes_its_run_as_failed(
    client: TestClient, world: World, gateway: FakeTemporalGateway
) -> None:
    run_id = create_run(client)["id"]
    with db.session_scope() as s:
        gateway.statuses[s.get(db.Run, run_id).workflow_id] = "failed"
    await reconcile_runs(gateway)
    with db.session_scope() as s:
        assert s.get(db.Run, run_id).outcome == "failed"
