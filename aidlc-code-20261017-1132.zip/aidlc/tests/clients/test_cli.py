"""The ``aidlc`` CLI: login/config, run --watch exit codes, --json output, doctor fixes and error mapping."""

from __future__ import annotations

import json
import stat
import time
from pathlib import Path

import httpx
import pytest
import respx

from aidlc.cli.config import config_path
from aidlc.cli.main import main
from aidlc.names import EXIT_CODES
from tests.clients.payloads import (
    API,
    event,
    inbox_item,
    project_view,
    public_config,
    run_summary,
    run_view,
    session_view,
    sse,
)

V1 = f"{API}/api/v1"


@pytest.fixture
def token(monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("AIDLC_TOKEN", "aidlc_test")
    return "aidlc_test"


def _json_out(capsys: pytest.CaptureFixture[str]) -> object:
    return json.loads(capsys.readouterr().out)


# ---------- login and config ----------


@respx.mock
def test_login_with_token_stores_private_config(capsys: pytest.CaptureFixture[str]) -> None:
    route = respx.get(f"{V1}/session").respond(json=session_view())
    assert main(["login", "--token", "aidlc_abc"]) == 0
    assert route.calls.last.request.headers["Authorization"] == "Bearer aidlc_abc"
    path = config_path()
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert stat.S_IMODE(path.parent.stat().st_mode) == 0o700
    stored = json.loads(path.read_text())
    assert stored["token"] == "aidlc_abc" and stored["api_url"] == API and stored["auth_method"] == "token"
    assert "Signed in" in capsys.readouterr().out


@respx.mock
def test_login_rejected_token_is_not_stored(capsys: pytest.CaptureFixture[str]) -> None:
    respx.get(f"{V1}/session").respond(401, json={"detail": "invalid API token"})
    assert main(["login", "--token", "aidlc_bad"]) == 1
    assert not config_path().exists()
    err = capsys.readouterr().err
    assert "invalid API token" in err and "aidlc login" in err


@respx.mock
def test_login_dev_and_logout() -> None:
    route = respx.get(f"{V1}/session").respond(json=session_view("me@example.com"))
    assert main(["login", "--dev", "me@example.com"]) == 0
    assert route.calls.last.request.headers["Authorization"] == "Bearer dev:me@example.com"
    assert main(["logout"]) == 0
    assert "token" not in json.loads(config_path().read_text())


@respx.mock
def test_login_device_code_flow(capsys: pytest.CaptureFixture[str]) -> None:
    issuer = "https://login.test/tenant/v2.0"
    # The issuer and client id come from the server's public config: no SSO settings needed on the machine.
    respx.get(f"{V1}/config").respond(json=public_config({"issuer": issuer, "client_id": "cli-app"}))
    session = respx.get(f"{V1}/session").respond(json=session_view())
    respx.get(f"{issuer}/.well-known/openid-configuration").respond(
        json={
            "device_authorization_endpoint": "https://login.test/device",
            "token_endpoint": "https://login.test/token",
        }
    )
    device = respx.post("https://login.test/device").respond(
        json={
            "device_code": "dc",
            "user_code": "ABCD-EFGH",
            "verification_uri": "https://login.test/link",
            "interval": 0,
        }
    )
    token_route = respx.post("https://login.test/token")
    token_route.side_effect = [
        httpx.Response(400, json={"error": "authorization_pending"}),
        httpx.Response(200, json={"access_token": "jwt-1", "refresh_token": "r-1", "expires_in": 3600}),
    ]
    assert main(["login"]) == 0
    assert "ABCD-EFGH" in capsys.readouterr().err
    stored = json.loads(config_path().read_text())
    assert stored["token"] == "jwt-1" and stored["refresh_token"] == "r-1" and stored["auth_method"] == "oidc"
    assert session.calls.last.request.headers["Authorization"] == "Bearer jwt-1"
    assert "client_id=cli-app" in device.calls.last.request.content.decode()


def test_login_without_sso_settings_explains_options(capsys: pytest.CaptureFixture[str]) -> None:
    with respx.mock:
        respx.get(f"{V1}/config").respond(json=public_config())
        assert main(["login"]) == 1
    assert "aidlc login --token" in capsys.readouterr().err


@respx.mock
def test_expired_oidc_token_is_refreshed(_cli_env: Path) -> None:
    _cli_env.parent.mkdir(parents=True)
    _cli_env.write_text(
        json.dumps(
            {
                "api_url": API,
                "token": "old",
                "refresh_token": "r-1",
                "token_expires_at": time.time() - 10,
                "token_endpoint": "https://login.test/token",
                "oidc_client_id": "cli-app",
            }
        )
    )
    respx.post("https://login.test/token").respond(json={"access_token": "new", "expires_in": 3600})
    route = respx.get(f"{V1}/session").respond(json=session_view())
    assert main(["whoami"]) == 0
    assert route.calls.last.request.headers["Authorization"] == "Bearer new"
    stored = json.loads(_cli_env.read_text())
    assert stored["token"] == "new" and stored["refresh_token"] == "r-1"


# ---------- run / watch / status ----------


def _mock_run(outcome: str) -> respx.Route:
    upload = respx.post(f"{V1}/projects/shop/specs").respond(201, json={"uploads": [], "run": run_summary()})
    events = [
        event(1, "stage_started", stage="S1"),
        event(2, "agent_started", stage="S1", agent_id="intake"),
        event(3, "agent_completed", stage="S1", agent_id="intake", cost_usd=0.12),
        event(4, "question", stage="S1", questions=[{"id": "Q-1", "text": "Which DB?"}]),
        event(5, "outcome", outcome=outcome),
    ]
    respx.get(f"{V1}/runs/run-1/events").respond(text=sse(*events, outcome=outcome))
    return upload


@pytest.mark.parametrize("outcome", ["pr-ready", "completed", "blocked", "failed", "cancelled"])
@respx.mock
def test_run_watch_exits_with_outcome_code(
    outcome: str, token: str, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    spec = tmp_path / "todo.md"
    spec.write_text("# Todo app\n")
    upload = _mock_run(outcome)
    code = main(["run", str(spec), "--project", "shop", "--repo", "web", "--type", "feature", "--watch"])
    assert code == EXIT_CODES[outcome]
    body = upload.calls.last.request.content.decode()
    assert 'filename="todo.md"' in body and 'name="repos"\r\n\r\nweb' in body
    out = capsys.readouterr().out
    assert "run-1" in out and f"outcome: {outcome}" in out and "question" in out


@respx.mock
def test_run_watch_json_is_ndjson(token: str, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    spec = tmp_path / "todo.md"
    spec.write_text("# Todo\n")
    _mock_run("blocked")
    assert main(["--json", "run", str(spec), "-p", "shop", "--watch"]) == 2
    lines = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert lines[0]["run"]["id"] == "run-1"
    assert [line["seq"] for line in lines[1:-1]] == [1, 2, 3, 4, 5]
    assert lines[-1] == {"outcome": "blocked", "last_event_id": 5}


def test_run_with_missing_spec_fails(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["run", "nope.md", "--project", "shop"]) == 1
    assert "spec file not found" in capsys.readouterr().err
    assert main(["run", "--project", "shop"]) == 1
    assert "at least one spec file or --confluence" in capsys.readouterr().err


@respx.mock
def test_run_from_confluence_pages(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    page = "https://acme.atlassian.net/wiki/spaces/ENG/pages/1/Spec"
    upload = respx.post(f"{V1}/projects/shop/specs").respond(201, json={"uploads": [], "run": run_summary()})
    assert main(["run", "--project", "shop", "--confluence", page, "--type", "bug"]) == 0
    form = dict(httpx.QueryParams(upload.calls.last.request.content.decode()))
    assert form == {"kind": "bug", "confluence_urls": page}
    assert "Started run" in capsys.readouterr().out


@respx.mock
def test_run_economy_flag_is_sent_with_the_upload(token: str, tmp_path: Path) -> None:
    spec = tmp_path / "spec.md"
    spec.write_text("# Spec\n")
    upload = respx.post(f"{V1}/projects/shop/specs").respond(201, json={"uploads": [], "run": run_summary()})
    assert main(["run", str(spec), "--project", "shop", "--economy"]) == 0
    assert b'name="economy"\r\n\r\ntrue' in upload.calls.last.request.content


def test_watch_prints_the_exact_answer_command(capsys: pytest.CaptureFixture[str], monkeypatch) -> None:
    from aidlc_sdk.models import RunEventView

    from aidlc.cli.output import Out
    from aidlc.cli.stepper import LiveView, Stepper

    monkeypatch.setenv("NO_COLOR", "1")
    view = LiveView(Out(), Stepper("run-1"))
    question = event(
        1,
        "question",
        stage="A",
        questions=[{"id": "Q-1", "text": "Which currency?"}, {"id": "Q-2", "text": "Rounding?"}],
        inbox_ids={"Q-1": "run-1:Q-1", "Q-2": "run-1:Q-2"},
    )
    escalation = event(
        2,
        "escalation",
        stage="S6",
        escalation={"id": "ESC-1", "reason": "loop_cap", "options": ["retry", "cancel"]},
        inbox_ids={"ESC-1": "run-1:ESC-1"},
    )
    for e in (question, escalation):
        view.update(RunEventView.model_validate(e))
    out = capsys.readouterr().out
    assert "aidlc answer run-1:Q-1 '<answer>'" in out and "aidlc answer run-1:Q-2 '<answer>'" in out
    assert "aidlc escalation run-1:ESC-1 retry|cancel" in out


def test_watch_renders_stepper_on_a_terminal(token: str, monkeypatch: pytest.MonkeyPatch) -> None:
    from aidlc_sdk.models import RunEventView

    from aidlc.cli.output import Out
    from aidlc.cli.stepper import LiveView, Stepper

    class Tty:
        def __init__(self) -> None:
            self.text = ""

        def isatty(self) -> bool:
            return True

        def write(self, s: str) -> None:
            self.text += s

        def flush(self) -> None:
            pass

    monkeypatch.setenv("NO_COLOR", "1")
    stream = Tty()
    view = LiveView(Out(stream=stream), Stepper("run-1", "REQ-001 Todo"))  # type: ignore[arg-type]
    for e in [
        event(1, "stage_started", stage="S1"),
        event(2, "agent_started", stage="S1", agent_id="intake"),
        event(3, "stage_completed", stage="S1"),
        event(4, "stage_started", stage="S2"),
        event(5, "escalation", stage="S2", id="ESC-1", reason="loop_cap", options=["retry", "cancel"]),
    ]:
        view.update(RunEventView.model_validate(e))
    view.close("failed")
    frame = stream.text.split("\x1b[J")[-1]
    assert "✓ S1" in frame and "✗ S2" in frame and "ESC-1" in frame and "outcome: failed" in frame
    assert "\x1b[" in stream.text  # redrawn in place


@pytest.mark.parametrize(
    ("outcome", "code"), [(None, 0), ("pr-ready", 0), ("completed", 0), ("blocked", 2), ("failed", 3), ("cancelled", 4)]
)
@respx.mock
def test_status_exit_code_and_json(outcome: str | None, code: int, token: str, capsys) -> None:
    respx.get(f"{V1}/runs/run-1").respond(json=run_view(outcome=outcome))
    assert main(["status", "run-1", "--json"]) == code
    data = _json_out(capsys)
    assert data["run"]["id"] == "run-1" and data["run"]["outcome"] == outcome


@respx.mock
def test_status_lists_runs(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    route = respx.get(f"{V1}/runs").respond(json=[run_summary(), run_summary("run-2", outcome="pr-ready")])
    assert main(["status", "--project", "shop"]) == 0
    assert route.calls.last.request.url.params["project_id"] == "shop"
    out = capsys.readouterr().out
    assert "run-2" in out and "pr-ready" in out and "active" in out


@respx.mock
def test_watch_command_streams_until_end(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    respx.get(f"{V1}/runs/run-1").respond(json=run_view())
    respx.get(f"{V1}/runs/run-1/events").respond(
        text=sse(event(1, "outcome", outcome="cancelled"), outcome="cancelled")
    )
    assert main(["watch", "run-1"]) == 4


# ---------- inbox / answers / escalations ----------


@respx.mock
def test_inbox_json_parses(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    route = respx.get(f"{V1}/inbox").respond(json=[inbox_item()])
    assert main(["inbox", "--project", "shop", "--json"]) == 0
    assert route.calls.last.request.url.params["project_id"] == "shop"
    assert _json_out(capsys)[0]["id"] == "item-1"


@respx.mock
def test_interactive_answer_reads_the_item_by_id(
    token: str, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    item_id = "run-1:Q-1"
    get = respx.get(f"{V1}/inbox/run-1%3AQ-1").respond(json=inbox_item(item_id))
    answer = respx.post(f"{V1}/inbox/run-1%3AQ-1/answer").respond(json=inbox_item(item_id, status="resolved"))
    monkeypatch.setattr("sys.stdin.isatty", lambda: True)
    monkeypatch.setattr("builtins.input", lambda prompt: "sqlite")
    assert main(["answer", item_id]) == 0
    assert get.called and json.loads(answer.calls.last.request.content) == {"answer": "sqlite"}
    out = capsys.readouterr().out
    assert "Q-1: Which database?" in out and "options: postgres, sqlite" in out

    respx.get(f"{V1}/inbox/run-1%3AQ-1").respond(json=inbox_item(item_id, status="resolved"))
    assert main(["answer", item_id]) == 1
    assert "already resolved" in capsys.readouterr().err


@respx.mock
def test_answer_and_escalation(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    answer = respx.post(f"{V1}/inbox/item-1/answer").respond(json=inbox_item(status="resolved"))
    decide = respx.post(f"{V1}/inbox/item-2/decide").respond(json=inbox_item("item-2", "escalation"))
    assert main(["answer", "item-1", "postgres"]) == 0
    assert json.loads(answer.calls.last.request.content) == {"answer": "postgres"}
    assert main(["escalation", "item-2", "retry", "--note", "flaky CI"]) == 0
    assert json.loads(decide.calls.last.request.content) == {"decision": "retry", "note": "flaky CI"}


@respx.mock
def test_edit_spec_sends_the_replacement_spec(token: str, tmp_path: Path) -> None:
    decide = respx.post(f"{V1}/inbox/item-2/decide").respond(json=inbox_item("item-2", "escalation"))
    assert main(["escalation", "item-2", "edit_spec"]) == 1
    spec = tmp_path / "v2.md"
    spec.write_text("# Todo v2\n")
    assert main(["escalation", "item-2", "edit_spec", "--spec", str(spec)]) == 0
    assert json.loads(decide.calls.last.request.content) == {"decision": "edit_spec", "note": "# Todo v2\n"}


@respx.mock
def test_rbac_refusal_is_an_error(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    respx.post(f"{V1}/inbox/item-2/decide").respond(403, json={"detail": "requires the maintainer role"})
    assert main(["--json", "escalation", "item-2", "cancel"]) == 1
    captured = capsys.readouterr()
    assert json.loads(captured.out)["error"] == {
        "type": "PermissionDenied",
        "message": "requires the maintainer role",
        "status": 403,
        "hint": "ask a project maintainer for a role that allows this",
    }
    assert "requires the maintainer role" in captured.err


# ---------- previews / artifacts / projects ----------


@respx.mock
def test_preview_prints_url(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    view = run_view()
    view["preview_url"] = "https://pr-7.preview.test"
    respx.get(f"{V1}/runs/run-1").respond(json=view)
    respx.get(f"{V1}/previews").respond(json=[])
    assert main(["preview", "run-1"]) == 0
    assert capsys.readouterr().out.strip() == "https://pr-7.preview.test"


@respx.mock
def test_preview_missing_is_an_error(token: str) -> None:
    respx.get(f"{V1}/runs/run-1").respond(json=run_view())
    respx.get(f"{V1}/previews").respond(json=[])
    assert main(["preview", "run-1"]) == 1


@respx.mock
def test_artifacts_list_and_download(token: str, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    respx.get(f"{V1}/runs/run-1/artifacts").respond(json=[{"name": "reports/tests.json", "key": "runs/run-1/x"}])
    respx.get(f"{V1}/runs/run-1/artifacts/reports/tests.json").respond(content=b'{"ok": true}')
    assert main(["artifacts", "run-1", "--json"]) == 0
    assert _json_out(capsys)[0]["name"] == "reports/tests.json"
    target = tmp_path / "out.json"
    assert main(["artifacts", "run-1", "--get", "reports/tests.json", "-o", str(target)]) == 0
    assert target.read_bytes() == b'{"ok": true}'


@respx.mock
def test_projects_json(token: str, capsys: pytest.CaptureFixture[str]) -> None:
    respx.get(f"{V1}/projects").respond(json=[project_view()])
    assert main(["projects", "--json"]) == 0
    assert _json_out(capsys)[0]["id"] == "shop"


# ---------- doctor ----------


@respx.mock
def test_doctor_failures_print_fixes(capsys: pytest.CaptureFixture[str]) -> None:
    respx.get(f"{API}/healthz").mock(side_effect=httpx.ConnectError("refused"))
    assert main(["doctor"]) == 1
    out = capsys.readouterr().out
    assert "✗ config" in out and "fix: aidlc login" in out
    assert "✗ api" in out and "fix: export AIDLC_API_URL=" in out


@respx.mock
def test_doctor_project_checks_and_json(token: str, capsys: pytest.CaptureFixture[str], monkeypatch) -> None:
    monkeypatch.setattr("aidlc.cli.doctor.shutil.which", lambda tool: f"/usr/bin/{tool}")
    respx.get(f"{API}/healthz").respond(json={"status": "ok"})
    respx.get(f"{V1}/session").respond(json=session_view())
    respx.get(f"{V1}/projects/shop/doctor").respond(
        json={
            "checks": [
                {"name": "repo:web", "status": "ok", "detail": "reachable"},
                {"name": "temporal", "status": "fail", "detail": "unreachable: ConnectError"},
                {"name": "model-access", "status": "unknown", "detail": "Amazon Bedrock in us-east-1"},
            ],
            "checked_at": "2026-10-12T10:00:00Z",
        }
    )
    assert main(["doctor", "--project", "shop", "--json"]) == 1
    report = _json_out(capsys)
    by_name = {c["name"]: c for c in report["checks"]}
    assert report["ok"] is False
    assert by_name["auth"]["status"] == "ok"
    assert by_name["server:temporal"]["status"] == "fail" and "docker compose" in by_name["server:temporal"]["fix"]
    assert by_name["server:model-access"]["status"] == "warn"
    assert "eks.amazonaws.com/role-arn" in by_name["server:model-access"]["fix"]
    assert "bedrock:InvokeModel" in by_name["server:model-access"]["fix"]
    assert by_name["local:model-access"]["status"] == "warn"
    assert "no AWS credentials for Bedrock in us-east-1" in by_name["local:model-access"]["detail"]
    assert "aws sso login" in by_name["local:model-access"]["fix"]


@respx.mock
def test_doctor_local_requires_tools(token: str, capsys: pytest.CaptureFixture[str], monkeypatch) -> None:
    monkeypatch.setattr("aidlc.cli.doctor.shutil.which", lambda tool: None)
    respx.get(f"{API}/healthz").respond(json={"status": "ok"})
    respx.get(f"{V1}/session").respond(json=session_view())
    assert main(["doctor", "--local"]) == 1
    out = capsys.readouterr().out
    assert "✗ local:gh" in out and "gh auth login" in out and "✗ local:model-access" in out and "AWS_PROFILE" in out


@respx.mock
def test_doctor_local_model_access_with_aws_credentials(token: str, capsys, monkeypatch) -> None:
    monkeypatch.setattr("aidlc.cli.doctor.shutil.which", lambda tool: f"/usr/bin/{tool}")
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
    monkeypatch.setenv("AIDLC_AWS_REGION", "eu-central-1")
    respx.get(f"{API}/healthz").respond(json={"status": "ok"})
    respx.get(f"{V1}/session").respond(json=session_view())
    assert main(["doctor", "--local", "--json"]) == 0
    check = {c["name"]: c for c in _json_out(capsys)["checks"]}["local:model-access"]
    assert check["status"] == "ok" and "Amazon Bedrock in eu-central-1" in check["detail"]


def test_doctor_flags_world_readable_config(_cli_env: Path, capsys, monkeypatch) -> None:
    _cli_env.parent.mkdir(parents=True)
    _cli_env.write_text(json.dumps({"token": "aidlc_x"}))
    _cli_env.chmod(0o644)
    with respx.mock:
        respx.get(f"{API}/healthz").respond(json={"status": "ok"})
        respx.get(f"{V1}/session").respond(json=session_view())
        assert main(["doctor"]) == 1
    assert f"chmod 600 {_cli_env}" in capsys.readouterr().out


# ---------- spec templates ----------


@respx.mock
def test_spec_template_downloads_the_chosen_format(token: str, tmp_path: Path, capsys) -> None:
    route = respx.get(f"{V1}/spec-templates/vsix").respond(content=b"PK\x03\x04word")
    target = tmp_path / "vsix.docx"
    assert main(["spec", "template", "vsix", "--format", "docx", "-o", str(target)]) == 0
    assert route.calls.last.request.url.params["format"] == "docx" and target.read_bytes() == b"PK\x03\x04word"
    assert f"aidlc spec check {target}" in capsys.readouterr().out


def test_spec_check_offline_passes_an_example_and_fails_a_blank_template(tmp_path: Path, capsys) -> None:
    from aidlc.platform.spec_templates import example_text, template_text

    good, blank = tmp_path / "good.md", tmp_path / "blank.md"
    good.write_text(example_text("integration"))
    blank.write_text(template_text("integration"))
    assert main(["spec", "check", str(good), "--offline"]) == 0
    assert "passes (integration, surfaces: backend, integration)" in capsys.readouterr().out
    assert main(["spec", "check", str(blank), "--offline"]) == 1
    out = capsys.readouterr().out
    assert "error: Spec details: Title is not filled in" in out and "fix them before you submit" in out


@respx.mock
def test_spec_check_asks_the_server_by_default(token: str, tmp_path: Path, capsys) -> None:
    spec = tmp_path / "s.md"
    spec.write_text("# Free-form spec\n")
    result = {"templated": False, "errors": [], "warnings": [], "gaps": [], "surfaces": [], "repos": [], "title": ""}
    route = respx.post(f"{V1}/spec-templates/check").respond(json=result)
    assert main(["spec", "check", str(spec)]) == 0
    assert route.calls.last.request.read() and "free-form spec" in capsys.readouterr().out
