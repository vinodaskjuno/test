"""Agent eval runner: rubric grading through the Agent Evaluation grader, recorded grades, and submitting scores to
the registry with the Python SDK (``run_evals.py --submit``)."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

import pytest
import respx

from aidlc.contracts import AgentResult
from aidlc.settings import ROOT
from tests.clients.payloads import API, agent_detail

V1 = f"{API}/api/v1"


def _load() -> ModuleType:
    spec = importlib.util.spec_from_file_location(
        "run_evals_under_test", ROOT / "evals" / "agent-evals" / "run_evals.py"
    )
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module  # dataclasses resolve annotations through the module registry
    spec.loader.exec_module(module)
    return module


run_evals = _load()
RUBRIC = "Each AC is testable."
SUITE = {
    "version": 3,
    "min_score": 0.8,
    "cases": [
        {
            "id": "sa-1",
            "agent": "spec-analyst",
            "description": "testable ACs",
            "checks": [
                {"type": "min_count", "path": "acceptance_criteria", "min": 1},
                {"type": "rubric", "criteria": RUBRIC, "min": 0.75, "weight": 3},
            ],
        },
        {"id": "in-1", "agent": "intake", "checks": [{"type": "equals", "path": "kind", "value": "feature"}]},
    ],
}


def _result(agent: str, output: dict[str, Any], version: str = "1.2.0") -> AgentResult:
    return AgentResult(agent_id=agent, agent_version=version, ok=True, output=output)


RESULTS = {
    "sa-1": _result("spec-analyst", {"acceptance_criteria": [{"id": "AC-1"}]}),
    "in-1": _result("intake", {"kind": "feature"}, version="2.0.0"),
}
LABEL = run_evals.parse_suite(SUITE).cases[0].checks[1].label


def test_rubric_checks_score_from_grades_and_are_skipped_without_them() -> None:
    suite = run_evals.parse_suite(SUITE)
    case = suite.cases[0]
    graded = run_evals.score_case(case, RESULTS["sa-1"], {LABEL: 0.9})
    assert graded.score == 1.0 and "grade=0.90" in graded.checks[1].detail
    failing = run_evals.score_case(case, RESULTS["sa-1"], {LABEL: 0.5})
    assert failing.score == 0.25  # weights 1 + 3; the rubric (weight 3) fails
    ungraded = run_evals.score_case(case, RESULTS["sa-1"])
    assert ungraded.score == 1.0 and ungraded.checks[1].skipped  # only the property check counts
    rubric_only = run_evals.parse_suite(
        {"cases": [{"id": "r", "agent": "spec-analyst", "checks": [{"type": "rubric", "criteria": RUBRIC}]}]}
    ).cases[0]
    assert run_evals.score_case(rubric_only, RESULTS["sa-1"]).error == "no graded checks"
    with pytest.raises(run_evals.SuiteError, match="needs criteria"):
        run_evals.parse_suite({"cases": [{"id": "r", "agent": "x", "checks": [{"type": "rubric"}]}]})


async def test_live_grading_uses_the_orchestrator_grader(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[dict[str, Any], str, dict[str, Any]]] = []

    async def grade(case: dict[str, Any], agent_id: str, output: dict[str, Any]) -> float:
        calls.append((case, agent_id, output))
        return 1.4  # clamped to 1.0

    fake = ModuleType("aidlc.orchestrator.evaluation")
    fake.grade = grade  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "aidlc.orchestrator.evaluation", fake)
    suite = run_evals.parse_suite(SUITE)
    grades = await run_evals.grade_rubrics(suite.cases, RESULTS)
    assert grades == {"sa-1": {LABEL: 1.0}}
    case, agent_id, output = calls[0]
    assert (case["id"], case["rubric"], agent_id) == ("sa-1", RUBRIC, "spec-analyst")
    assert output == {"acceptance_criteria": [{"id": "AC-1"}]}


async def test_without_the_grader_rubrics_stay_ungraded(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "aidlc.orchestrator.evaluation", None)  # import raises ImportError
    assert await run_evals.grade_rubrics(run_evals.parse_suite(SUITE).cases, RESULTS) == {}


def test_recorded_grades_round_trip(tmp_path: Path) -> None:
    path = tmp_path / "results.jsonl"
    run_evals.write_results(path, RESULTS, {"sa-1": {LABEL: 0.8}})
    results, grades = run_evals.load_results(path)
    assert results["in-1"].agent_version == "2.0.0" and grades == {"sa-1": {LABEL: 0.8}, "in-1": {}}


@respx.mock
def test_submit_records_each_agents_score_for_its_version(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    suite_path, results_path = tmp_path / "suite.yaml", tmp_path / "results.jsonl"
    suite_path.write_text(json.dumps(SUITE))  # JSON is valid YAML
    run_evals.write_results(results_path, RESULTS, {"sa-1": {LABEL: 0.6}})
    sa = respx.post(f"{V1}/agents/spec-analyst/evals").respond(201, json=agent_detail("spec-analyst"))
    intake = respx.post(f"{V1}/agents/intake/evals").respond(201, json=agent_detail("intake"))
    argv = ["--suite", str(suite_path), "--results", str(results_path), "--submit", "--api", API, "--token", "t0k"]

    assert run_evals.main(argv) == 1  # spec-analyst scores 0.25 < 0.8; both scores are still recorded
    body = json.loads(sa.calls.last.request.content)
    assert (body["version"], body["score"]) == ("1.2.0", 0.25)
    assert body["report"]["suite_version"] == 3 and body["report"]["passed"] is False
    assert [c["case_id"] for c in body["report"]["cases"]] == ["sa-1"]
    assert sa.calls.last.request.headers["Authorization"] == "Bearer t0k"
    assert json.loads(intake.calls.last.request.content)["version"] == "2.0.0"
    assert "SKIP" not in capsys.readouterr().out

    intake.respond(403, json={"detail": "requires the maintainer role"})
    assert run_evals.main(argv) == 2
    err = capsys.readouterr().err
    assert "submit: intake@2.0.0: 403" in err and "requires the maintainer role" in err


def test_submit_needs_api_and_token(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AIDLC_API_URL", raising=False)
    results_path = tmp_path / "results.jsonl"
    run_evals.write_results(results_path, RESULTS, {})
    assert run_evals.main(["--results", str(results_path), "--submit"]) == 2


def test_mixed_versions_are_not_submitted() -> None:
    suite = run_evals.parse_suite(
        {
            "cases": [
                {"id": "a", "agent": "intake", "checks": [{"type": "nonempty", "path": "kind"}]},
                {"id": "b", "agent": "intake", "checks": [{"type": "nonempty", "path": "kind"}]},
            ]
        }
    )
    results = {"a": _result("intake", {"kind": "x"}, "1.0.0"), "b": _result("intake", {"kind": "x"}, "1.1.0")}
    scores = run_evals.score_results(suite, results)
    agents = run_evals.score_agents(scores, suite.min_score, results)
    assert agents[0].version is None
    assert run_evals.submit(object(), suite, agents, scores) == [  # type: ignore[arg-type]
        "intake: no single agent version in the results; not submitted"
    ]
