"""Client test setup: an isolated CLI config file and API URL for every test."""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.clients.payloads import API


@pytest.fixture(autouse=True)
def _cli_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    config = tmp_path / "config" / "aidlc" / "config.json"
    monkeypatch.setenv("AIDLC_CONFIG", str(config))
    monkeypatch.setenv("AIDLC_API_URL", API)
    for name in ("AIDLC_TOKEN", "AIDLC_OIDC_ISSUER", "AIDLC_OIDC_CLIENT_ID", "ANTHROPIC_API_KEY", "NO_COLOR"):
        monkeypatch.delenv(name, raising=False)
    return config
