"""Local dev mode: export to .claude/, the local runner (with a fake agent backend) and submit."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

import pytest
import respx
import yaml

from aidlc.cli.main import main
from aidlc.local.export import MARKER, export
from aidlc.local.pipeline import BANNER, SKILL_NAME
from aidlc.local.runner import AgentOutcome, LocalRunError, run
from aidlc.platform.registry import AgentSpec, get_registry
from aidlc.settings import get_settings
from tests.clients.payloads import API, run_summary

V1 = f"{API}/api/v1"


def _front_matter(text: str) -> dict[str, Any]:
    assert text.startswith("---\n")
    raw, _, _ = text[4:].partition("\n---\n")
    return yaml.safe_load(raw)


def test_export_writes_valid_subagents_and_is_idempotent(tmp_path: Path) -> None:
    registry = get_registry()
    dest = tmp_path / ".claude"
    first = export(dest, registry)
    agents = sorted((dest / "agents").glob("*.md"))
    assert len(agents) == len(registry) == 65
    assert len(first.written) == 66  # 65 agents + the skill
    for path in agents:
        text = path.read_text(encoding="utf-8")
        meta = _front_matter(text)
        spec = registry.get(path.stem)
        assert meta["name"] == spec.id
        assert meta["model"] in {"opus", "sonnet", "haiku"}
        assert meta["tools"].split(", ") == spec.tools
        assert meta["description"]
        assert MARKER in text and spec.prompt in text and "## Output" in text and "```json" in text
    skill = (dest / "skills" / SKILL_NAME / "SKILL.md").read_text(encoding="utf-8")
    assert _front_matter(skill)["name"] == SKILL_NAME and BANNER in skill

    second = export(dest, registry)
    assert second.written == [] and len(second.unchanged) == 66 and second.removed == []


def test_export_removes_only_stale_generated_files(tmp_path: Path) -> None:
    dest = tmp_path / ".claude"
    export(dest)
    stale = dest / "agents" / "retired-agent.md"
    stale.write_text(f"---\nname: retired-agent\n---\n<!-- {MARKER} -->\n")
    mine = dest / "agents" / "my-own-agent.md"
    mine.write_text("---\nname: my-own-agent\n---\nhand written\n")
    result = export(dest)
    assert result.removed == [stale] and not stale.exists() and mine.exists()


def test_cli_local_export(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["local", "export", "--dest", str(tmp_path / ".claude"), "--json"]) == 0
    assert len(json.loads(capsys.readouterr().out)["written"]) == 66


# ---------- local run ----------


def _git(repo: Path, *args: str) -> str:
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=True).stdout.strip()


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    repo = tmp_path / "repo"
    repo.mkdir()
    _git(repo, "init", "-q", "-b", "main")
    _git(repo, "config", "user.email", "dev@example.com")
    _git(repo, "config", "user.name", "Dev")
    spec = repo / ".adlc" / "specs" / "REQ-001-todo"
    spec.mkdir(parents=True)
    (spec / "requirement.md").write_text("# REQ-001: Todo\n\n### AC-1: Add a todo\n")
    (repo / "app.py").write_text("")
    _git(repo, "add", "-A")
    _git(repo, "commit", "-q", "-m", "init")
    return repo


def test_local_run_refuses_without_aws_credentials(repo: Path, capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(LocalRunError, match="no AWS credentials for Bedrock"):
        run("REQ-001", repo)
    assert main(["local", "run", "REQ-001", "--repo-dir", str(repo)]) == 1
    assert "aws sso login" in capsys.readouterr().err
    assert _git(repo, "rev-parse", "--abbrev-ref", "HEAD") == "main"  # nothing touched


def test_local_run_without_bedrock_needs_an_anthropic_key(repo: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIDLC_BEDROCK_ENABLED", "false")
    get_settings.cache_clear()
    with pytest.raises(LocalRunError, match="ANTHROPIC_API_KEY is not set"):
        run("REQ-001", repo)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    assert run("REQ-001", repo, agent_runner=FakeAgents(), log=lambda _: None)["status"] == "ready-to-submit"


def aws_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")


class FakeAgents:
    """Deterministic stand-in for the Claude Agent SDK: canned outputs per agent; dev agents write a file."""

    def __init__(self, validator_passes: bool = True, finding_severity: str | None = None) -> None:
        self.validator_passes = validator_passes
        self.finding_severity = finding_severity
        self.calls: list[tuple[str, dict[str, Any]]] = []

    async def __call__(self, spec: AgentSpec, ethos: str, inputs: dict[str, Any], cwd: Path) -> AgentOutcome:
        self.calls.append((spec.id, inputs))
        outputs: dict[str, dict[str, Any]] = {
            "spec-validator": {
                "passed": self.validator_passes,
                "issues": [] if self.validator_passes else ["AC-1 vague"],
            },
            "work-planner": {
                "architecture_md": "# Architecture\nOne module.",
                "tasks": [
                    {
                        "id": "TASK-001",
                        "title": "Todo model",
                        "repo": "app",
                        "owner_agent": "backend-dev",
                        "description": "Add the model.",
                        "ac_ids": ["AC-1"],
                    }
                ],
                "activation_set": ["backend-dev"],
            },
            "backend-dev": {"summary": "added model", "files_changed": ["todo.py"]},
            "unit-test": {"summary": "added tests", "files_changed": ["test_todo.py"]},
            "reflector": {"findings": [], "summary": "fine"},
            "correctness-reviewer": {"findings": [], "summary": "fine"},
        }
        if spec.id == "backend-dev":
            (cwd / "todo.py").write_text("class Todo: ...\n")
        if spec.id == "unit-test":
            (cwd / "test_todo.py").write_text("def test_todo(): ...\n")
        output = outputs[spec.id]
        if spec.id == "correctness-reviewer" and self.finding_severity:
            output = {
                "findings": [
                    {
                        "id": "F-1",
                        "source_agent": spec.id,
                        "severity": self.finding_severity,
                        "rule": "r",
                        "message": "m",
                    }
                ]
            }
        return AgentOutcome(
            ok=True, output=spec.output_model.model_validate(output).model_dump(mode="json"), cost_usd=0.5
        )


def test_local_run_pipeline_writes_state_and_branch(repo: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    aws_credentials(monkeypatch)
    agents = FakeAgents()
    lines: list[str] = []
    state = run("req-001", repo, agent_runner=agents, log=lines.append)
    assert lines[0] == BANNER
    assert [a for a, _ in agents.calls] == [
        "spec-validator",
        "work-planner",
        "backend-dev",
        "unit-test",
        "reflector",
        "correctness-reviewer",
    ]
    assert "<untrusted_source" in agents.calls[0][1]["requirement"]
    assert agents.calls[-1][1]["changed_files"]  # reviewers see the diff
    assert state["status"] == "ready-to-submit" and state["verified"] is False and state["cost_usd"] == 3.0
    saved = json.loads((repo / ".adlc/specs/REQ-001-todo/run.json").read_text())
    assert saved["status"] == "ready-to-submit" and [s["status"] for s in saved["stages"]] == ["done"] * 5
    assert _git(repo, "rev-parse", "--abbrev-ref", "HEAD") == "aidlc/req-001-local"
    assert (repo / ".adlc/specs/REQ-001-todo/tasks/TASK-001.md").is_file()
    assert _git(repo, "status", "--porcelain") == ""
    assert "todo.py" in _git(repo, "diff", "--name-only", "main..HEAD")


@pytest.mark.parametrize(
    ("agents", "status"),
    [(FakeAgents(validator_passes=False), "blocked"), (FakeAgents(finding_severity="high"), "blocked")],
)
def test_local_run_blocks(repo: Path, monkeypatch: pytest.MonkeyPatch, agents: FakeAgents, status: str) -> None:
    aws_credentials(monkeypatch)
    assert run("REQ-001", repo, agent_runner=agents, log=lambda _: None)["status"] == status


def test_local_run_refuses_a_dirty_tree(repo: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    aws_credentials(monkeypatch)
    (repo / "app.py").write_text("changed")
    with pytest.raises(LocalRunError, match="commit or stash"):
        run("REQ-001", repo, agent_runner=FakeAgents())


def test_local_run_needs_the_requirement(repo: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    aws_credentials(monkeypatch)
    with pytest.raises(LocalRunError, match="REQ-404"):
        run("REQ-404", repo, agent_runner=FakeAgents())


# ---------- submit ----------


@respx.mock
def test_submit_calls_verify_branch(repo: Path, monkeypatch: pytest.MonkeyPatch, capsys) -> None:
    monkeypatch.setenv("AIDLC_TOKEN", "aidlc_t")
    _git(repo, "checkout", "-q", "-b", "aidlc/req-001-local")
    route = respx.post(f"{V1}/verify-branch").respond(201, json=run_summary("run-9", kind="verify_branch"))
    assert main(["local", "submit", "--project", "shop", "--repo", "web", "--repo-dir", str(repo)]) == 0
    assert json.loads(route.calls.last.request.content) == {
        "project_id": "shop",
        "repo": "web",
        "branch": "aidlc/req-001-local",
    }
    assert route.calls.last.request.headers["Authorization"] == "Bearer aidlc_t"
    out = capsys.readouterr().out
    assert "run-9" in out and "aidlc/gates" in out


async def test_claude_agent_runs_on_bedrock_with_the_model_map(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import claude_agent_sdk
    from claude_agent_sdk import ResultMessage

    from aidlc.local.runner import claude_agent

    seen: dict[str, Any] = {}

    async def fake_query(*, prompt: str, options: Any):
        seen["options"] = options
        yield ResultMessage(
            subtype="success",
            duration_ms=1,
            duration_api_ms=1,
            is_error=False,
            num_turns=1,
            session_id="s",
            total_cost_usd=0.1,
            structured_output={"passed": True, "issues": []},
        )

    monkeypatch.setattr(claude_agent_sdk, "query", fake_query)
    monkeypatch.setenv("AIDLC_BEDROCK_MODEL_MAP", '{"claude-sonnet-5-5": "us.anthropic.claude-sonnet-5-5-v1:0"}')
    get_settings.cache_clear()
    spec = get_registry().get("spec-validator")
    outcome = await claude_agent(spec, "ethos", {"requirement": "r"}, tmp_path)
    assert outcome.ok and outcome.cost_usd == 0.1
    assert seen["options"].model == "us.anthropic.claude-sonnet-5-5-v1:0"
    assert seen["options"].env == {
        "CLAUDE_CODE_USE_BEDROCK": "1",
        "AWS_REGION": "us-east-1",
        "ANTHROPIC_DEFAULT_SONNET_MODEL": "us.anthropic.claude-sonnet-5-5-v1:0",
    }
