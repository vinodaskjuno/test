"""API payload builders for client tests (shapes follow clients/openapi.json)."""

from __future__ import annotations

import json
from typing import Any

API = "http://api.test"
NOW = "2026-10-12T10:00:00Z"


def run_summary(run_id: str = "run-1", **overrides: Any) -> dict[str, Any]:
    return {
        "id": run_id,
        "project_id": "shop",
        "kind": "feature",
        "work_item_id": "REQ-001",
        "title": "Todo app",
        "stage": "queued",
        "outcome": None,
        "iteration": 0,
        "cost_usd": 0.0,
        "created_by": "dev@example.com",
        "parent_run_id": None,
        "workflow_id": f"FeatureWorkflow-{run_id}",
        "created_at": NOW,
        "updated_at": NOW,
        **overrides,
    }


def run_view(run_id: str = "run-1", *, outcome: str | None = None, **state: Any) -> dict[str, Any]:
    summary = run_summary(run_id, outcome=outcome, stage="S3" if outcome is None else "done")
    return {
        "run": summary,
        "state": {"run_id": run_id, "kind": "feature", "stage": summary["stage"], "outcome": outcome, **state},
        "prs": [{"repo": "web", "number": 7, "url": "https://github.test/acme/web/pull/7", "draft": True}],
        "preview_url": None,
        "traceability": [{"ac_id": "AC-1", "text": "Add a todo", "tests": ["t1"], "passed": True}],
        "findings": [],
        "tests": [],
        "cost_by_agent": {},
    }


def inbox_item(item_id: str = "item-1", kind: str = "question", **overrides: Any) -> dict[str, Any]:
    return {
        "id": item_id,
        "run_id": "run-1",
        "project_id": "shop",
        "kind": kind,
        "ref_id": "Q-1" if kind == "question" else "ESC-1",
        "title": "Which database?",
        "payload": {"options": ["postgres", "sqlite"]},
        "status": "open",
        "resolution": {},
        "created_at": NOW,
        "resolved_at": None,
        **overrides,
    }


def public_config(oidc: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "upload_max_bytes": 10 * 1024 * 1024,
        "allowed_extensions": [".md", ".pdf"],
        "auth_mode": "oidc" if oidc else "dev",
        "oidc": oidc,
        "version": "0.1.0",
    }


def agent_detail(agent_id: str = "intake", versions: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    return {
        "id": agent_id,
        "number": 1,
        "name": "Intake",
        "squad": "S1",
        "squad_name": "Discovery & Requirements",
        "version": "1.0.0",
        "model": "claude-haiku-5-5",
        "effort": "low",
        "description": "Normalizes triggers.",
        "tools": ["Read"],
        "mcp_servers": [],
        "reads_untrusted": True,
        "workflows": ["feature"],
        "promoted_version": None,
        "promoted_score": None,
        "latest_eval_version": None,
        "latest_eval_score": None,
        "promotable": False,
        "prompt": "You are Intake.",
        "max_turns": 30,
        "budget_usd": 1.0,
        "timeout_s": 600,
        "output_schema": {},
        "versions": versions or [],
        "promotion_min_score": 0.8,
    }


def session_view(email: str = "dev@example.com") -> dict[str, Any]:
    return {
        "user": {"id": email, "name": "Dev", "email": email, "is_admin": False},
        "roles": {"shop": "contributor"},
        "preferences": {"theme": "system", "notifications": {}},
    }


def project_view(project_id: str = "shop", role: str = "contributor") -> dict[str, Any]:
    return {
        "id": project_id,
        "name": "Shop",
        "team_id": "team-1",
        "config": {"project_id": project_id, "name": "Shop", "repos": [{"id": "web", "url": "https://github.test/w"}]},
        "gates": {},
        "notification_channels": {},
        "created_at": NOW,
        "role": role,
    }


def event(seq: int, type_: str, *, stage: str | None = None, agent_id: str | None = None, **data: Any) -> dict:
    return {
        "seq": seq,
        "run_id": "run-1",
        "type": type_,
        "stage": stage,
        "agent_id": agent_id,
        "message": data.pop("message", type_),
        "data": data,
        "at": NOW,
    }


def sse(*events: dict[str, Any], outcome: str | None = None, ping: bool = True) -> str:
    """An SSE body as sse-starlette writes it: ``id``/``data`` per event, comments as pings, a final ``end``."""
    parts = [": ping\r\n\r\n"] if ping else []
    for e in events:
        parts.append(f"id: {e['seq']}\r\ndata: {json.dumps(e)}\r\n\r\n")
    if outcome is not None:
        last = events[-1]["seq"] if events else 0
        parts.append(f"event: end\r\ndata: {json.dumps({'outcome': outcome, 'last_event_id': last})}\r\n\r\n")
    return "".join(parts)
