"""SDK contract: every operation the Python client calls exists in clients/openapi.json, and the generated
models match the spec."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest
from aidlc_sdk import OPERATIONS

from aidlc.settings import ROOT

SPEC = json.loads((ROOT / "clients" / "openapi.json").read_text(encoding="utf-8"))
SDK = ROOT / "clients" / "sdk-py"


BY_ID = {op["operationId"]: (method.upper(), path) for path, ops in SPEC["paths"].items() for method, op in ops.items()}


@pytest.mark.parametrize(("operation_id", "method", "path"), [(n, m, p) for n, (m, p) in OPERATIONS.items()])
def test_operation_matches_openapi(operation_id: str, method: str, path: str) -> None:
    assert BY_ID.get(operation_id) == (method, path), f"{operation_id} is not {method} {path} in clients/openapi.json"


def test_typescript_sdk_uses_the_same_operations() -> None:
    source = (ROOT / "clients" / "sdk-ts" / "src" / "client.ts").read_text(encoding="utf-8")
    table = dict(re.findall(r'^\s+(\w+): \["(?:GET|POST|PUT|PATCH|DELETE)", "([^"]+)"\],$', source, re.MULTILINE))
    assert table, "sdk-ts has no OPERATIONS table"
    for operation_id, path in table.items():
        assert BY_ID.get(operation_id, (None, None))[1] == path, f"sdk-ts {operation_id} is not {path}"
    assert set(OPERATIONS) == set(table), "the Python and TypeScript SDKs call different operations"


def test_generated_models_are_current(tmp_path: Path) -> None:
    codegen = shutil.which("datamodel-codegen") or str(ROOT / ".venv" / "bin" / "datamodel-codegen")
    if not Path(codegen).exists():
        pytest.skip("datamodel-code-generator is not installed")
    committed = (SDK / "src" / "aidlc_sdk" / "models.py").read_text(encoding="utf-8")
    copy = tmp_path / "sdk"
    shutil.copytree(SDK / "scripts", copy / "scripts")
    (copy / "src" / "aidlc_sdk").mkdir(parents=True)
    subprocess.run(
        ["bash", str(copy / "scripts" / "generate.sh"), str(ROOT / "clients" / "openapi.json")],
        check=True,
        capture_output=True,
        env={"PATH": f"{ROOT / '.venv' / 'bin'}:/usr/bin:/bin"},
    )
    assert (copy / "src" / "aidlc_sdk" / "models.py").read_text(encoding="utf-8") == committed
