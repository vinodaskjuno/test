"""Python SDK: auth header, idempotency, multipart upload, error mapping and SSE resume."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
from aidlc_sdk import (
    USER_AGENT,
    ApiError,
    AsyncClient,
    AuthError,
    Client,
    Conflict,
    NotFound,
    PermissionDenied,
    RateLimited,
    StreamEnd,
    Unreachable,
)
from aidlc_sdk.models import RunEventView

from tests.clients.payloads import (
    API,
    NOW,
    agent_detail,
    event,
    inbox_item,
    public_config,
    run_summary,
    run_view,
    sse,
)

EVENTS = f"{API}/api/v1/runs/run-1/events"


@pytest.fixture
def client():
    with Client(API, "aidlc_secret") as c:
        yield c


@respx.mock
def test_bearer_token_and_user_agent_are_sent(client: Client) -> None:
    route = respx.get(f"{API}/api/v1/runs/run-1").respond(json=run_view())
    view = client.get_run("run-1")
    assert view.run.id == "run-1"
    request = route.calls.last.request
    assert request.headers["Authorization"] == "Bearer aidlc_secret"
    assert request.headers["User-Agent"] == USER_AGENT


@pytest.mark.parametrize("base", [API, f"{API}/", f"{API}/api/v1", f"{API}/api/v1/"])
@respx.mock
def test_base_url_accepts_root_or_api_prefix(base: str) -> None:
    respx.get(f"{API}/api/v1/projects").respond(json=[])
    with Client(base) as c:
        assert c.list_projects() == []


@respx.mock
def test_create_run_sends_an_idempotency_key(client: Client) -> None:
    route = respx.post(f"{API}/api/v1/runs").respond(201, json=run_summary())
    client.create_run({"project_id": "shop", "kind": "feature", "title": "Todo"}, idempotency_key="key-1")
    client.create_run({"project_id": "shop", "kind": "feature", "title": "Todo"})
    first, second = (c.request for c in route.calls)
    assert first.headers["Idempotency-Key"] == "key-1"
    assert len(second.headers["Idempotency-Key"]) == 32
    assert json.loads(first.content) == {"project_id": "shop", "kind": "feature", "title": "Todo"}


@respx.mock
def test_upload_specs_is_multipart_with_files_field(client: Client, tmp_path) -> None:
    spec = tmp_path / "todo.md"
    spec.write_text("# Todo\n")
    route = respx.post(f"{API}/api/v1/projects/shop/specs").respond(201, json={"uploads": [], "run": run_summary()})
    result = client.upload_specs("shop", [spec, ("notes.txt", b"more")], kind="bug", title="T", repos=["web", "api"])
    assert result.run.id == "run-1"
    body = route.calls.last.request.content.decode()
    assert route.calls.last.request.headers["Content-Type"].startswith("multipart/form-data")
    assert body.count('name="files"') == 2
    assert 'filename="todo.md"' in body and 'filename="notes.txt"' in body
    assert body.count('name="repos"') == 2
    assert 'name="kind"\r\n\r\nbug' in body


@respx.mock
def test_artifact_names_keep_their_path(client: Client) -> None:
    respx.get(f"{API}/api/v1/runs/run-1/artifacts/reports/test%20report.json").respond(content=b"{}")
    assert client.get_artifact("run-1", "reports/test report.json") == b"{}"


@pytest.mark.parametrize(
    ("status", "error"),
    [(401, AuthError), (403, PermissionDenied), (404, NotFound), (409, Conflict), (500, ApiError)],
)
@respx.mock
def test_errors_are_typed(client: Client, status: int, error: type[ApiError]) -> None:
    respx.post(f"{API}/api/v1/runs/run-1/cancel").respond(status, json={"detail": "nope"})
    with pytest.raises(error) as info:
        client.cancel_run("run-1")
    assert info.value.status == status
    assert info.value.message == "nope"


@respx.mock
def test_rate_limit_carries_retry_after(client: Client) -> None:
    respx.get(f"{API}/api/v1/inbox").respond(429, json={"detail": "rate limit exceeded"}, headers={"Retry-After": "7"})
    with pytest.raises(RateLimited) as info:
        client.list_inbox()
    assert info.value.retry_after == 7


@respx.mock
def test_validation_errors_are_readable(client: Client) -> None:
    detail = [{"loc": ["body", "answer"], "msg": "String should have at least 1 character", "type": "x"}]
    respx.post(f"{API}/api/v1/inbox/i/answer").respond(422, json={"detail": detail})
    with pytest.raises(ApiError, match=r"body\.answer: String should have at least 1 character"):
        client.answer("i", "x")


@respx.mock
def test_connection_failures_raise_unreachable(client: Client) -> None:
    respx.get(f"{API}/healthz").mock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(Unreachable):
        client.health()


@respx.mock
def test_events_resume_with_last_event_id_after_a_dropped_connection(client: Client) -> None:
    seen: list[str | None] = []

    def respond(request: httpx.Request) -> httpx.Response:
        seen.append(request.headers.get("Last-Event-ID"))
        if len(seen) == 1:  # the connection drops after two events, before the run ends
            body = sse(event(1, "stage_started", stage="S1"), event(2, "agent_started", stage="S1", agent_id="intake"))
        elif len(seen) == 2:
            raise httpx.ReadError("connection reset")
        else:
            body = sse(event(3, "stage_completed", stage="S1"), outcome="pr-ready")
        return httpx.Response(200, text=body, headers={"Content-Type": "text/event-stream"})

    respx.get(EVENTS).mock(side_effect=respond)
    items = list(client.events("run-1", backoff_s=0))
    assert seen == [None, "2", "2"]
    assert [i.seq for i in items if isinstance(i, RunEventView)] == [1, 2, 3]
    assert items[-1] == StreamEnd(outcome="pr-ready", last_event_id=3)


@respx.mock
def test_events_start_from_a_given_event_id(client: Client) -> None:
    route = respx.get(EVENTS).respond(text=sse(event(6, "log"), outcome="failed"))
    items = list(client.events("run-1", last_event_id=5))
    assert route.calls.last.request.headers["Last-Event-ID"] == "5"
    assert isinstance(items[-1], StreamEnd) and items[-1].outcome == "failed"


@respx.mock
def test_events_do_not_retry_permission_errors(client: Client) -> None:
    route = respx.get(EVENTS).respond(403, json={"detail": "requires the viewer role"})
    with pytest.raises(PermissionDenied):
        list(client.events("run-1", backoff_s=0))
    assert route.call_count == 1


@respx.mock
def test_events_give_up_after_max_failures(client: Client) -> None:
    route = respx.get(EVENTS).mock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(Unreachable):
        list(client.events("run-1", backoff_s=0, max_failures=2))
    assert route.call_count == 3


@respx.mock
def test_events_retry_server_errors_and_rate_limits(client: Client) -> None:
    route = respx.get(EVENTS)
    route.side_effect = [
        httpx.Response(503, json={"detail": "busy"}),
        httpx.Response(429, json={"detail": "slow down"}, headers={"Retry-After": "0"}),
        httpx.Response(200, text=sse(event(1, "log"), outcome="cancelled")),
    ]
    items = list(client.events("run-1", backoff_s=0))
    assert items[-1] == StreamEnd(outcome="cancelled", last_event_id=1)
    assert route.call_count == 3


@respx.mock
async def test_async_client_calls_and_resumes() -> None:
    respx.get(f"{API}/api/v1/session").respond(
        json={
            "user": {"id": "a@b.co", "name": "A", "email": "a@b.co", "is_admin": True},
            "roles": {},
            "preferences": {},
        }
    )
    calls: list[str | None] = []

    def respond(request: httpx.Request) -> httpx.Response:
        calls.append(request.headers.get("Last-Event-ID"))
        if len(calls) == 1:
            return httpx.Response(200, text=sse(event(1, "log")))
        return httpx.Response(200, text=sse(event(2, "outcome", outcome="blocked"), outcome="blocked"))

    respx.get(EVENTS).mock(side_effect=respond)
    async with AsyncClient(API, "dev:a@b.co") as client:
        session = await client.session()
        items = [item async for item in client.events("run-1", backoff_s=0)]
    assert session.user.is_admin
    assert calls == [None, "1"]
    assert items[-1] == StreamEnd(outcome="blocked", last_event_id=2)


@respx.mock
async def test_async_errors_are_typed() -> None:
    respx.post(f"{API}/api/v1/inbox/x/decide").respond(403, json={"detail": "requires the maintainer role"})
    async with AsyncClient(API, "t") as client:
        with pytest.raises(PermissionDenied, match="maintainer"):
            await client.decide("x", "retry")


@respx.mock
def test_config_inbox_item_and_confluence_upload(client: Client) -> None:
    respx.get(f"{API}/api/v1/config").respond(json=public_config())
    assert client.config().upload_max_bytes == 10 * 1024 * 1024
    item = respx.get(f"{API}/api/v1/inbox/run-1%3AQ-1").respond(json=inbox_item("run-1:Q-1"))
    assert client.get_inbox_item("run-1:Q-1").id == "run-1:Q-1" and item.called
    upload = respx.post(f"{API}/api/v1/projects/shop/specs").respond(201, json={"uploads": [], "run": run_summary()})
    page = "https://acme.atlassian.net/wiki/spaces/ENG/pages/1/Spec"
    client.upload_specs("shop", [], confluence_urls=[page])
    assert dict(httpx.QueryParams(upload.calls.last.request.content.decode())) == {
        "kind": "feature",
        "confluence_urls": page,
    }
    with pytest.raises(ValueError, match="at least one file or Confluence page link"):
        client.upload_specs("shop", [])


@respx.mock
async def test_agent_eval_promote_and_rollback() -> None:
    version = {"version": "1.2.0", "status": "candidate", "eval_score": 0.91, "eval_report": {}, "updated_at": NOW}
    evals = respx.post(f"{API}/api/v1/agents/intake/evals").respond(201, json=agent_detail(versions=[version]))
    promote = respx.post(f"{API}/api/v1/agents/intake/promote").respond(json=agent_detail())
    rollback = respx.post(f"{API}/api/v1/agents/intake/rollback").respond(json=agent_detail())
    async with AsyncClient(API, "aidlc_secret") as api:
        detail = await api.record_agent_eval("intake", "1.2.0", 0.91, {"cases": 3})
        await api.promote_agent("intake", "1.2.0")
        await api.rollback_agent("intake")
    assert detail.versions[0].eval_score == 0.91
    assert json.loads(evals.calls.last.request.content) == {"version": "1.2.0", "score": 0.91, "report": {"cases": 3}}
    assert json.loads(promote.calls.last.request.content) == {"version": "1.2.0"}
    assert rollback.called
