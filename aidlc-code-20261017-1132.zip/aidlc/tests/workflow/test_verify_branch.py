from temporalio.testing import WorkflowEnvironment

from aidlc.names import VERIFY_BRANCH
from aidlc.orchestrator.models import Act, ToolsOutput
from tests.workflow.fakes import FakePlatform, failing_report, feature_request, running, start


def verify_request():  # type: ignore[no-untyped-def]
    options = {"repo": "api", "branch": "feature/local-login"}
    return feature_request(kind="verify_branch", options=options).model_copy(update={"work_item": None})


async def test_verify_branch_pass_sets_success_status(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        state = await (await start(env, tq, VERIFY_BRANCH, verify_request())).result()
    assert state.outcome == "pr-ready"
    workspace = fake.calls[Act.PREPARE_WORKSPACE][0]
    assert workspace.branch == "feature/local-login" and workspace.create_branch is False
    status = fake.calls[Act.FORGE_SET_GATE_STATUS][-1]
    assert status.state == "success" and status.items[0].repo == "api"
    called = {c.agent_id for c in fake.agent_calls}
    assert "review-judge" in called and "reflector" not in called and "spec-conformance-validator" not in called
    assert fake.called("data-privacy-governance")[0].inputs["mode"] == "diff"  # PII review of the branch
    assert not fake.calls[Act.BASELINE_TESTS]


async def test_verify_branch_failure_sets_failure_status(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report()))
    async with running(env, fake) as tq:
        state = await (await start(env, tq, VERIFY_BRANCH, verify_request())).result()
    assert state.outcome == "blocked"
    assert fake.calls[Act.FORGE_SET_GATE_STATUS][-1].state == "failure"
    assert not fake.called("triage")  # verification reports; it never edits the branch
