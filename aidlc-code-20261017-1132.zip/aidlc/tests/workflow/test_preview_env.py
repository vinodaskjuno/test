from datetime import timedelta

from temporalio.testing import WorkflowEnvironment

from aidlc.names import PREVIEW_ENV, SIG_PR_EVENT
from aidlc.orchestrator.models import Act, PREventSignal
from tests.workflow.fakes import FakePlatform, feature_request, running, start, wait_state


def preview_request(**extra: object):  # type: ignore[no-untyped-def]
    options = {"repo": "api", "pr_number": 7, "compose_yaml": "services: {}", "ttl_hours": 2, **extra}
    return feature_request(kind="preview", options=options).model_copy(update={"work_item": None})


async def test_preview_up_refresh_then_down_on_close(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        handle = await start(env, tq, PREVIEW_ENV, preview_request())
        up = await wait_state(handle, lambda s: s.preview_url is not None)
        assert up.preview_url == "https://pr-api-7.preview.localhost"
        await handle.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=7, action="synchronize"))
        await handle.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=7, action="closed"))
        state = await handle.result()

    assert state.stage == "down" and state.preview_url is None and state.summary == "PR closed"
    assert len(fake.calls[Act.PREVIEW_UP]) == 2 and fake.calls[Act.PREVIEW_UP][0].ttl_hours == 2
    assert fake.calls[Act.PREVIEW_DOWN][0].pr_number == 7
    assert "pr-api-7" in fake.calls[Act.FORGE_POST_COMMENTS][0].bodies[0]
    assert {e.type for e in fake.events} == {"preview"}
    assert all(e.stage is None for e in fake.events)


async def test_preview_ttl_expires(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        handle = await start(env, tq, PREVIEW_ENV, preview_request(url="https://existing"))
        await env.sleep(timedelta(hours=3))
        state = await handle.result()
    assert state.summary == "TTL of 2h expired"
    assert not fake.calls[Act.PREVIEW_UP]  # the parent run had already brought it up
    assert fake.calls[Act.PREVIEW_DOWN]
