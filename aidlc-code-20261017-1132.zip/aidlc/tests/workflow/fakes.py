"""Scripted fake activities for workflow tests, registered under the production activity names.

Agent outputs are queues per agent id: each call pops the next item; the last item repeats. An item may be a dict
(the agent's output), an ``AgentResult`` or a callable ``(AgentCall) -> dict | AgentResult``. Other activities
have sensible defaults and can be scripted the same way through ``queue(name, *results)``.
"""

import asyncio
import uuid
from collections import defaultdict
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from typing import Any

from temporalio import activity
from temporalio.client import WorkflowHandle
from temporalio.service import RPCError, RPCStatusCode
from temporalio.testing import WorkflowEnvironment

from aidlc.contracts import (
    AgentResult,
    GateResult,
    ProjectConfig,
    PRRef,
    RepoRef,
    RunEvent,
    RunRequest,
    RunState,
    SourceDoc,
    Surface,
    TestReport,
    TestResult,
    WorkItem,
)
from aidlc.orchestrator.models import (
    Act,
    AgentCost,
    AllocateIdInput,
    ArtifactsInput,
    CIInput,
    CIStatus,
    CitationsInput,
    CommentsInput,
    CommentsResult,
    CommitInput,
    CommitResult,
    CreatedRepo,
    CreateRepoInput,
    DiffInput,
    DiffResult,
    DoctorInput,
    DoctorReport,
    ExcludeInput,
    GateStatusInput,
    InstallInput,
    InstallOutput,
    IntegrateInput,
    IntegrateResult,
    Issues,
    KnowledgeHits,
    KnowledgeQuery,
    KnowledgeRecordInput,
    LoadGatesInput,
    ManifestFinishInput,
    ManifestRegisterInput,
    ManifestUpdateInput,
    ManifestView,
    NotifyInput,
    OnboardingScaffoldInput,
    OpenPRsInput,
    PostCommentsInput,
    PreviewDownInput,
    PreviewUpInput,
    PRList,
    ProjectRef,
    ProtectInput,
    PushBranchesInput,
    QualityInput,
    ReadyPRsInput,
    RegisterRepoInput,
    RepoWorkspace,
    RunAgentInput,
    RunCosts,
    RunRef,
    RunRowInput,
    ScanInput,
    StoreArtifactInput,
    SyncInput,
    SyncResult,
    TaskWorktree,
    TaskWorktrees,
    TaskWorktreesInput,
    ToolsInput,
    ToolsOutput,
    TrialMergeInput,
    TrialMergeReport,
    Workspace,
    WorkspaceInput,
    WrittenFiles,
)
from aidlc.orchestrator.worker import build_worker

DEV = {"summary": "done", "files_changed": ["app/login.py"], "test_commands": []}
NO_FINDINGS: dict[str, Any] = {"findings": []}
TICKET = {
    "id": "FIX-1",
    "owner_agent": "backend-dev",
    "repo": "api",
    "root_cause": "bad check",
    "files": ["app/login.py"],
}
REQUIREMENT = {
    "req_id": "REQ-001",
    "title": "Add login",
    "summary": "Users log in with email and password.",
    "acceptance_criteria": [
        {"id": "AC-1", "text": "A user can log in", "citations": [{"source_name": "spec.md", "quote": "log in"}]}
    ],
}
PLAN = {
    "architecture_md": "# Architecture",
    "tasks": [
        {
            "id": "TASK-001",
            "title": "Login API",
            "repo": "api",
            "owner_agent": "backend-dev",
            "description": "Add POST /login",
            "files": ["app/login.py"],
            "ac_ids": ["AC-1"],
        }
    ],
    "activation_set": ["unit-test", "static-analysis", "security-scanner"],
}
ANALYSIS = {"summary": "analysis", "details_md": "details"}

DEFAULT_OUTPUTS: dict[str, Any] = {
    "intake": {"title": "Add login", "kind": "feature", "summary": "login"},
    "spec-analyst": REQUIREMENT,
    "ambiguity-conflict-detection": {},
    "ux-design-analyst": ANALYSIS,
    "compliance-policy": {"summary": "no policy impact", "nfrs": ["Passwords are hashed"]},
    "spec-validator": {"passed": True},
    "adversary": NO_FINDINGS,
    "repository-discovery": {"integration_branch": "main", "test_commands": ["pytest -q"]},
    "architecture-mapper": ANALYSIS,
    "feature-tracer": ANALYSIS,
    "integration-explorer": ANALYSIS,
    "solution-architect": ANALYSIS,
    "api-contract": {"openapi_yaml": "openapi: 3.1.0"},
    "data-modeler": ANALYSIS,
    "work-planner": PLAN,
    "overlap-analyst": {},
    "plan-validator": {"passed": True},
    **{a: DEV for a in ("backend-dev", "frontend-dev", "db-migration-dev", "integration-dev", "refactoring")},
    **{a: DEV for a in ("devops-iac", "docs", "unit-test", "integration-contract-test", "e2e-ui-test")},
    **{a: DEV for a in ("performance-resilience", "accessibility-test")},
    "test-strategist": {"ac_to_tests": {"AC-1": ["test_login"]}, "levels": ["unit"]},
    "test-environment-data": {"compose_yaml": ""},
    "flaky-test-analyst": NO_FINDINGS,
    **{a: NO_FINDINGS for a in ("static-analysis", "runtime-hazard", "security-scanner", "dependency-license")},
    "performance-smell": NO_FINDINGS,
    "spec-conformance-validator": {"verdicts": [{"ac_id": "AC-1", "passed": True}]},
    "visual-ux-validator": {"verdicts": []},
    "triage": {"fix_tickets": [TICKET], "diagnosis": "login check inverted"},
    "debugger": {"fix_tickets": [TICKET], "diagnosis": "confirmed"},
    "reflector": NO_FINDINGS,
    **{a: NO_FINDINGS for a in ("correctness-reviewer", "security-reviewer", "performance-reviewer")},
    **{a: NO_FINDINGS for a in ("maintainability-reviewer", "architecture-conformance")},
    "review-judge": {"summary": "no blocking findings"},
    "commit": {"messages": {"api": "feat(login): add login"}},
    "pr": {"title": "REQ-001: Add login", "bodies": {"api": "Adds login."}},
    "release-notes": {"changelog_entry": "- Login"},
    "ci-watcher": {"fix_tickets": [TICKET], "diagnosis": "CI lint failure"},
    "pr-feedback": {"replies": []},
    "knowledge-capture": {"lessons": [{"title": "Hash passwords", "body": "Use argon2", "tags": ["security"]}]},
    "audit-compliance-reporter": {"report_md": "# Audit pack"},
    **{a: NO_FINDINGS for a in ("convention-auditor", "test-coverage-auditor", "ai-api-cost-scanner")},
    "backlog-writer": {"drafts": [{"kind": "BUG", "title": "Unbounded retry", "markdown": "# Unbounded retry"}]},
    "knowledge-curator": {"report_md": "## Lessons that apply\n- LESSON-001: hash passwords (backend-dev)"},
    "data-privacy-governance": NO_FINDINGS,
    "branch-merge": {"merged": True, "notes": "OK api head abc123: build n/a, tests 1/1"},
    "workflow-diagnostics": {"report_md": "## Diagnosis\nThe same test fails every iteration.", "score": 0.8},
    "cost-optimization": {"report_md": "## Spend overview\nWithin budget.", "recommendations": []},
}


def passing_report() -> TestReport:
    return TestReport(
        results=[TestResult(id="t1", name="test_login_ac1", level="unit", status="pass", ac_ids=["AC-1"])]
    )


def failing_report(test_id: str = "t1") -> TestReport:
    return TestReport(
        results=[TestResult(id=test_id, name="test_login_ac1", level="unit", status="fail", ac_ids=["AC-1"])]
    )


def project(*repos: str) -> ProjectConfig:
    ids = repos or ("api",)
    return ProjectConfig(
        project_id="p1",
        name="Demo",
        repos=[RepoRef(id=r, url=f"https://git.example/{r}", primary=i == 0) for i, r in enumerate(ids)],
    )


def feature_request(
    run_id: str | None = None,
    *,
    kind: str = "feature",
    item_id: str = "",
    options: dict[str, Any] | None = None,
    surfaces: list[Surface] | None = None,
    extra_sources: list[SourceDoc] | None = None,
) -> RunRequest:
    return RunRequest(
        run_id=run_id or f"run-{uuid.uuid4().hex[:8]}",
        kind=kind,  # type: ignore[arg-type]
        project=project(),
        work_item=WorkItem(
            id=item_id,
            kind="bug" if kind == "bugfix" else "feature",
            title="Add login",
            project_id="p1",
            sources=[SourceDoc(kind="markdown", name="spec.md", content="Users must log in."), *(extra_sources or [])],
            requested_by="dev@example.com",
            surfaces=surfaces or [],
        ),
        options=options or {},
    )


class FakePlatform:
    def __init__(self) -> None:
        self.outputs: dict[str, list[Any]] = {k: [v] for k, v in DEFAULT_OUTPUTS.items()}
        self.queues: dict[str, list[Any]] = {}
        self.agent_calls: list[RunAgentInput] = []
        self.calls: dict[str, list[Any]] = defaultdict(list)
        self.events: list[RunEvent] = []
        self.snapshots: list[RunState] = []
        self.agent_cost = 0.01
        self.counters: dict[str, int] = defaultdict(int)
        self.pr_numbers: dict[str, int] = defaultdict(int)

    # ---------- scripting ----------

    def script(self, agent_id: str, *outputs: Any) -> None:
        self.outputs[agent_id] = list(outputs)

    def queue(self, name: str, *results: Any) -> None:
        self.queues[name] = list(results)

    def called(self, agent_id: str) -> list[RunAgentInput]:
        return [c for c in self.agent_calls if c.agent_id == agent_id]

    def event_types(self) -> list[str]:
        return [e.type for e in self.events]

    @staticmethod
    def _next(items: list[Any]) -> Any:
        return items.pop(0) if len(items) > 1 else items[0]

    def _result(self, name: str, arg: Any, default: Callable[[Any], Any]) -> Any:
        self.calls[name].append(arg)
        if name in self.queues:
            item = self._next(self.queues[name])
            return item(arg) if callable(item) else item
        return default(arg)

    # ---------- activities ----------

    def activities(self) -> list[Callable[..., Any]]:
        fake = self

        @activity.defn(name=Act.RUN_AGENT)
        async def run_agent(call: RunAgentInput) -> AgentResult:
            fake.agent_calls.append(call)
            item = fake._next(fake.outputs[call.agent_id])
            if callable(item):
                item = item(call)
            if isinstance(item, AgentResult):
                return item
            return AgentResult(
                agent_id=call.agent_id, agent_version="1.0.0", ok=True, output=item, cost_usd=fake.agent_cost
            )

        @activity.defn(name=Act.EMIT_EVENT)
        async def emit_event(event: RunEvent) -> None:
            fake.events.append(event)

        @activity.defn(name=Act.PERSIST_STATE)
        async def persist_state(state: RunState) -> None:
            fake.snapshots.append(state)

        @activity.defn(name=Act.NOTIFY)
        async def notify(arg: NotifyInput) -> None:
            fake.calls[Act.NOTIFY].append(arg)

        @activity.defn(name=Act.ALLOCATE_ID)
        async def allocate_id(arg: AllocateIdInput) -> str:
            def default(a: AllocateIdInput) -> str:
                fake.counters[a.prefix] += 1
                return f"{a.prefix}-{fake.counters[a.prefix]:03d}"

            return fake._result(Act.ALLOCATE_ID, arg, default)

        @activity.defn(name=Act.LOAD_GATES)
        async def load_gates(arg: LoadGatesInput) -> dict[str, Any]:
            return fake._result(Act.LOAD_GATES, arg, lambda a: {})

        @activity.defn(name=Act.PREPARE_WORKSPACE)
        async def prepare_workspace(arg: WorkspaceInput) -> Workspace:
            def default(a: WorkspaceInput) -> Workspace:
                repos = {
                    r: RepoWorkspace(
                        repo=r, path=f"/ws/{a.run_id}/{r}", url=f"https://git.example/{r}", base_branch="main"
                    )
                    for r in a.repo_ids
                }
                return Workspace(branch=a.branch, repos=repos)

            return fake._result(Act.PREPARE_WORKSPACE, arg, default)

        @activity.defn(name=Act.PREPARE_TASK_WORKTREES)
        async def prepare_task_worktrees(arg: TaskWorktreesInput) -> TaskWorktrees:
            return fake._result(
                Act.PREPARE_TASK_WORKTREES,
                arg,
                lambda a: TaskWorktrees(
                    items=[
                        TaskWorktree(
                            task_id=i.task_id,
                            repo=i.repo,
                            path=f"{i.repo_path}--{i.task_id}",
                            branch=f"{a.branch}--{i.task_id.lower()}",
                        )
                        for i in a.items
                    ]
                ),
            )

        @activity.defn(name=Act.RUN_TOOLS)
        async def run_tools(arg: ToolsInput) -> ToolsOutput:
            return fake._result(Act.RUN_TOOLS, arg, lambda a: ToolsOutput(report=passing_report()))

        @activity.defn(name=Act.BASELINE_TESTS)
        async def baseline_tests(arg: ToolsInput) -> ToolsOutput:
            return fake._result(Act.BASELINE_TESTS, arg, lambda a: ToolsOutput(report=TestReport()))

        @activity.defn(name=Act.INSTALL_DEPS)
        async def install_deps(arg: InstallInput) -> InstallOutput:
            return fake._result(Act.INSTALL_DEPS, arg, lambda a: InstallOutput())

        @activity.defn(name=Act.EXCLUDE_UNTRACKED)
        async def exclude_untracked(arg: ExcludeInput) -> list[str]:
            return fake._result(Act.EXCLUDE_UNTRACKED, arg, lambda a: [])

        @activity.defn(name=Act.WRITE_ADLC_ARTIFACTS)
        async def write_adlc_artifacts(arg: ArtifactsInput) -> WrittenFiles:
            return fake._result(Act.WRITE_ADLC_ARTIFACTS, arg, lambda a: WrittenFiles(paths=list(a.files)))

        @activity.defn(name=Act.WRITE_ONBOARDING_SCAFFOLD)
        async def write_onboarding_scaffold(arg: OnboardingScaffoldInput) -> WrittenFiles:
            return fake._result(Act.WRITE_ONBOARDING_SCAFFOLD, arg, lambda a: WrittenFiles(paths=[".adlc/config.yml"]))

        @activity.defn(name=Act.ADLC_DOCTOR)
        async def adlc_doctor(arg: DoctorInput) -> DoctorReport:
            return fake._result(Act.ADLC_DOCTOR, arg, lambda a: DoctorReport(ok=True))

        @activity.defn(name=Act.STORE_ARTIFACT)
        async def store_artifact(arg: StoreArtifactInput) -> str:
            return fake._result(Act.STORE_ARTIFACT, arg, lambda a: f"runs/{a.run_id}/{a.name}")

        @activity.defn(name=Act.GIT_COMMIT_PUSH)
        async def git_commit_push(arg: CommitInput) -> CommitResult:
            return fake._result(Act.GIT_COMMIT_PUSH, arg, lambda a: CommitResult(sha="abc123", committed=True))

        @activity.defn(name=Act.GIT_DIFF)
        async def git_diff(arg: DiffInput) -> DiffResult:
            return fake._result(
                Act.GIT_DIFF,
                arg,
                lambda a: DiffResult(repo=a.repo, diff="diff --git a/app/login.py", changed_files=["app/login.py"]),
            )

        @activity.defn(name=Act.GIT_PUSH_BRANCHES)
        async def git_push_branches(arg: PushBranchesInput) -> None:
            fake.calls[Act.GIT_PUSH_BRANCHES].append(arg)

        @activity.defn(name=Act.GIT_SYNC_BRANCH)
        async def git_sync_branch(arg: SyncInput) -> SyncResult:
            return fake._result(Act.GIT_SYNC_BRANCH, arg, lambda a: SyncResult(updated=False, sha="abc123"))

        @activity.defn(name=Act.ENSURE_RUN_ROW)
        async def ensure_run_row(arg: RunRowInput) -> None:
            fake.calls[Act.ENSURE_RUN_ROW].append(arg)

        @activity.defn(name=Act.RUN_COSTS)
        async def run_costs(arg: RunRef) -> RunCosts:
            def default(a: RunRef) -> RunCosts:
                calls: dict[str, int] = defaultdict(int)
                for c in fake.agent_calls:
                    calls[c.agent_id] += 1
                agents = [
                    AgentCost(agent_id=a, calls=n, cost_usd=round(n * fake.agent_cost, 6)) for a, n in calls.items()
                ]
                return RunCosts(agents=agents, total_usd=sum(x.cost_usd for x in agents), calls=sum(calls.values()))

            return fake._result(Act.RUN_COSTS, arg, default)

        @activity.defn(name=Act.INTEGRATE_BRANCHES)
        async def integrate_branches(arg: IntegrateInput) -> IntegrateResult:
            return fake._result(Act.INTEGRATE_BRANCHES, arg, lambda a: IntegrateResult(repo=a.repo, merged=a.branches))

        @activity.defn(name=Act.TRIAL_MERGE_GATE)
        async def trial_merge_gate(arg: TrialMergeInput) -> TrialMergeReport:
            return fake._result(Act.TRIAL_MERGE_GATE, arg, lambda a: TrialMergeReport(passed=True))

        @activity.defn(name=Act.FORGE_OPEN_DRAFT_PRS)
        async def forge_open_draft_prs(arg: OpenPRsInput) -> PRList:
            def default(a: OpenPRsInput) -> PRList:
                prs = []
                for item in a.items:
                    fake.pr_numbers[item.repo] += 1
                    n = fake.pr_numbers[item.repo]
                    prs.append(PRRef(repo=item.repo, number=n, url=f"{item.repo_url}/pull/{n}", draft=a.draft))
                return PRList(prs=prs)

            return fake._result(Act.FORGE_OPEN_DRAFT_PRS, arg, default)

        @activity.defn(name=Act.FORGE_UPDATE_AND_READY_PRS)
        async def forge_update_and_ready_prs(arg: ReadyPRsInput) -> PRList:
            return fake._result(
                Act.FORGE_UPDATE_AND_READY_PRS,
                arg,
                lambda a: PRList(prs=[p.model_copy(update={"draft": False}) for p in a.prs]),
            )

        @activity.defn(name=Act.FORGE_CI_STATUS)
        async def forge_ci_status(arg: CIInput) -> CIStatus:
            return fake._result(Act.FORGE_CI_STATUS, arg, lambda a: CIStatus(state="success"))

        @activity.defn(name=Act.FORGE_NEW_COMMENTS)
        async def forge_new_comments(arg: CommentsInput) -> CommentsResult:
            return fake._result(Act.FORGE_NEW_COMMENTS, arg, lambda a: CommentsResult())

        @activity.defn(name=Act.FORGE_POST_COMMENTS)
        async def forge_post_comments(arg: PostCommentsInput) -> None:
            fake.calls[Act.FORGE_POST_COMMENTS].append(arg)

        @activity.defn(name=Act.FORGE_SET_GATE_STATUS)
        async def forge_set_gate_status(arg: GateStatusInput) -> None:
            fake.calls[Act.FORGE_SET_GATE_STATUS].append(arg)

        @activity.defn(name=Act.FORGE_CREATE_REPO)
        async def forge_create_repo(arg: CreateRepoInput) -> CreatedRepo:
            return fake._result(
                Act.FORGE_CREATE_REPO,
                arg,
                lambda a: CreatedRepo(
                    name=a.name, url=f"https://git.example/{a.name}", clone_url=f"https://git.example/{a.name}.git"
                ),
            )

        @activity.defn(name=Act.FORGE_PROTECT_BRANCH)
        async def forge_protect_branch(arg: ProtectInput) -> None:
            fake.calls[Act.FORGE_PROTECT_BRANCH].append(arg)

        @activity.defn(name=Act.REGISTER_REPO)
        async def register_repo(arg: RegisterRepoInput) -> None:
            fake.calls[Act.REGISTER_REPO].append(arg)

        @activity.defn(name=Act.MANIFEST_ACTIVE)
        async def manifest_active(arg: ProjectRef) -> ManifestView:
            return fake._result(Act.MANIFEST_ACTIVE, arg, lambda a: ManifestView())

        @activity.defn(name=Act.MANIFEST_REGISTER)
        async def manifest_register(arg: ManifestRegisterInput) -> int:
            return fake._result(Act.MANIFEST_REGISTER, arg, lambda a: 1)

        @activity.defn(name=Act.MANIFEST_UPDATE)
        async def manifest_update(arg: ManifestUpdateInput) -> None:
            fake.calls[Act.MANIFEST_UPDATE].append(arg)

        @activity.defn(name=Act.MANIFEST_FINISH)
        async def manifest_finish(arg: ManifestFinishInput) -> None:
            fake.calls[Act.MANIFEST_FINISH].append(arg)

        @activity.defn(name=Act.KNOWLEDGE_SEARCH)
        async def knowledge_search(arg: KnowledgeQuery) -> KnowledgeHits:
            return fake._result(Act.KNOWLEDGE_SEARCH, arg, lambda a: KnowledgeHits())

        @activity.defn(name=Act.KNOWLEDGE_RECORD)
        async def knowledge_record(arg: KnowledgeRecordInput) -> str:
            return fake._result(Act.KNOWLEDGE_RECORD, arg, lambda a: f"p1:{a.title}")

        @activity.defn(name=Act.EVALUATE_QUALITY_GATE)
        async def evaluate_quality_gate(arg: QualityInput) -> GateResult:
            def default(a: QualityInput) -> GateResult:
                failing = [r.id for r in a.test_report.results if r.status == "fail"]
                return GateResult(gate="quality", passed=not failing, issues=[f"failing: {t}" for t in failing])

            return fake._result(Act.EVALUATE_QUALITY_GATE, arg, default)

        @activity.defn(name=Act.VALIDATE_CITATIONS)
        async def validate_citations(arg: CitationsInput) -> Issues:
            return fake._result(Act.VALIDATE_CITATIONS, arg, lambda a: Issues())

        @activity.defn(name=Act.SCAN_INJECTION)
        async def scan_injection(arg: ScanInput) -> Issues:
            return fake._result(Act.SCAN_INJECTION, arg, lambda a: Issues())

        @activity.defn(name=Act.PREVIEW_UP)
        async def preview_up(arg: PreviewUpInput) -> str:
            return fake._result(Act.PREVIEW_UP, arg, lambda a: f"https://pr-{a.repo}-{a.pr_number}.preview.localhost")

        @activity.defn(name=Act.PREVIEW_DOWN)
        async def preview_down(arg: PreviewDownInput) -> None:
            fake.calls[Act.PREVIEW_DOWN].append(arg)

        return [v for v in locals().values() if callable(v) and hasattr(v, "__temporal_activity_definition")]


@asynccontextmanager
async def running(env: WorkflowEnvironment, fake: FakePlatform) -> AsyncIterator[str]:
    task_queue = f"tq-{uuid.uuid4().hex[:8]}"
    async with build_worker(env.client, activities=fake.activities(), task_queue=task_queue):
        yield task_queue


async def start(env: WorkflowEnvironment, task_queue: str, workflow: str, req: RunRequest) -> WorkflowHandle:
    return await env.client.start_workflow(workflow, req, id=req.run_id, task_queue=task_queue, result_type=RunState)


async def wait_state(
    handle: WorkflowHandle, predicate: Callable[[RunState], bool], timeout_s: float = 30.0
) -> RunState:
    """Poll the ``state`` query until ``predicate`` holds."""
    deadline = asyncio.get_running_loop().time() + timeout_s
    while True:
        try:
            state: RunState | None = await handle.query("state", result_type=RunState)
        except RPCError as err:  # a child workflow that has not started yet
            if err.status != RPCStatusCode.NOT_FOUND:
                raise
            state = None
        if state is not None and predicate(state):
            return state
        if asyncio.get_running_loop().time() > deadline:
            raise AssertionError(f"state never matched; last: {state}")
        await asyncio.sleep(0.05)
