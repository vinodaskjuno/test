from pathlib import Path

from temporalio.client import WorkflowHandle
from temporalio.exceptions import ApplicationError
from temporalio.testing import WorkflowEnvironment

from aidlc.agent_outputs import Overlap
from aidlc.contracts import AgentResult, ConflictResolution, RunState, SourceDoc, TestReport, TestResult
from aidlc.names import FEATURE, SIG_ANSWER, SIG_CANCEL, SIG_ESCALATION, SIG_PR_EVENT
from aidlc.orchestrator.models import (
    Q_OPEN_QUESTIONS,
    SIG_ANSWERS,
    Act,
    AnswerSignal,
    AnswersSignal,
    CancelSignal,
    CheckInfo,
    CIStatus,
    CommentInfo,
    CommentsResult,
    DecisionSignal,
    IntegrateInput,
    IntegrateResult,
    Issues,
    MergeConflict,
    OpenQuestionsView,
    PREventSignal,
    SyncResult,
    ToolsOutput,
    TrialMergeReport,
)
from tests.workflow.fakes import (
    DEV,
    PLAN,
    REQUIREMENT,
    FakePlatform,
    failing_report,
    feature_request,
    passing_report,
    running,
    start,
    wait_state,
)


async def wait_ready(handle: WorkflowHandle) -> RunState:
    return await wait_state(handle, lambda s: s.outcome == "pr-ready" and s.stage == "gate_b")


async def merge_all(handle: WorkflowHandle, state: RunState) -> RunState:
    for pr in state.prs:
        await handle.signal(SIG_PR_EVENT, PREventSignal(repo=pr.repo, number=pr.number, action="merged"))
    return await handle.result()


async def decide(handle: WorkflowHandle, reason: str, decision: str) -> RunState:
    state = await wait_state(handle, lambda s: any(e.reason == reason and e.decision is None for e in s.escalations))
    esc = next(e for e in state.escalations if e.reason == reason and e.decision is None)
    await handle.signal(SIG_ESCALATION, DecisionSignal(escalation_id=esc.id, decision=decision, user="lead"))
    return state


async def test_happy_path_reaches_pr_ready_then_merges(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        ready = await wait_ready(handle)
        assert [p.draft for p in ready.prs] == [False]
        final = await merge_all(handle, ready)

    assert final.outcome == "pr-ready"
    assert final.prs[0].state == "merged"
    assert final.iteration == 1
    assert [g.gate for g in final.gates if g.passed] == [
        "V1",
        "A",
        "V2",
        "trial_merge_early",
        "quality",
        "trial_merge_final",
    ]
    stages = [e.stage for e in fake.events if e.type == "stage_started"]
    for stage in ("S1", "V1", "spec_pr", "S2", "V2", "S3", "S4", "S5", "S6", "S7", "S9", "S8", "ci", "gate_b"):
        assert stage in stages
    # the allocated id drives the branch and the spec folder
    assert fake.calls[Act.ALLOCATE_ID][0].prefix == "REQ"
    assert fake.calls[Act.PREPARE_WORKSPACE][0].branch == "aidlc/REQ-001-add-login"
    # untrusted sources travel separately from the work item
    intake = fake.called("intake")[0]
    assert "sources" not in intake.inputs["work_item"] and intake.inputs["sources"][0]["name"] == "spec.md"
    # task scope is enforced through allowed_files on the owning dev agent
    dev = fake.called("backend-dev")[0]
    assert dev.allowed_files == ["app/login.py"] and dev.inputs["task"]["id"] == "TASK-001"
    # PR body carries the factual sections rendered from run state
    body = fake.calls[Act.FORGE_UPDATE_AND_READY_PRS][0].bodies["api"]
    assert "## Traceability" in body and "AC-1" in body and "Audit pack" in body
    assert fake.calls[Act.FORGE_SET_GATE_STATUS][-1].state == "success"
    assert fake.calls[Act.MANIFEST_FINISH][-1].status == "done"
    # API contract: requirement on spec stages, ready PR events, snapshots persisted
    spec_done = [e for e in fake.events if e.type == "stage_completed" and e.stage == "S1"]
    assert spec_done[0].data["requirement"]["req_id"] == REQUIREMENT["req_id"]
    assert any(e.type == "pr" and e.data.get("ready") is True and e.data["number"] == 1 for e in fake.events)
    assert fake.snapshots[-1].outcome == "pr-ready"
    assert fake.event_types().count("outcome") == 1
    assert all(e.data["gate"] for e in fake.events if e.type == "gate")


async def test_each_task_gets_only_its_own_acs_and_the_contract_only_when_it_builds_an_api(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    second_ac = {
        "id": "AC-2",
        "text": "Deploys run in CI",
        "citations": [{"source_name": "spec.md", "quote": "log in"}],
    }
    fake.script(
        "spec-analyst", {**REQUIREMENT, "acceptance_criteria": [*REQUIREMENT["acceptance_criteria"], second_ac]}
    )
    infra_task = {
        **PLAN["tasks"][0],
        "id": "TASK-002",
        "owner_agent": "devops-iac",
        "files": ["ci.yml"],
        "ac_ids": ["AC-2"],
    }
    fake.script("work-planner", {**PLAN, "tasks": [*PLAN["tasks"], infra_task]})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))

    api = fake.called("backend-dev")[0].inputs
    infra = fake.called("devops-iac")[0].inputs
    assert [ac["id"] for ac in api["requirement"]["acceptance_criteria"]] == ["AC-1"]
    assert [ac["id"] for ac in infra["requirement"]["acceptance_criteria"]] == ["AC-2"]
    assert api["openapi"] == "openapi: 3.1.0" and "openapi" not in infra
    # siblings come as a who-owns-what index; only the task itself carries its description
    assert [t["id"] for t in infra["tasks"]] == ["TASK-001", "TASK-002"]
    assert all("description" not in t for t in infra["tasks"]) and infra["task"]["description"] == "Add POST /login"
    # S4 and S7 get the plan without the architecture they already receive on its own
    assert fake.called("test-strategist")[0].inputs["plan"]["architecture_md"] == ""
    assert fake.called("review-judge")[0].inputs["architecture"] == "details"
    # the platform installs each task worktree and excludes discovery's install output; agents never install
    installs = [Path(c.worktree).name for c in fake.calls[Act.INSTALL_DEPS]]
    assert {"api--TASK-001", "api--TASK-002"} <= set(installs)
    assert fake.calls[Act.EXCLUDE_UNTRACKED][0].worktree == fake.called("repository-discovery")[0].worktrees["api"]
    # S4 writers work in private worktrees whose branches git merges back without a Branch & Merge agent call
    assert fake.called("unit-test")[0].worktrees["api"].endswith("--S4-unit-test-api")
    merged = [b for c in fake.calls[Act.INTEGRATE_BRANCHES] for b in c.branches]
    assert any(b.endswith("--s4-unit-test-api") for b in merged) and len(fake.called("branch-merge")) == 1
    # after each integration the run worktree gets the merged dependencies before tests run there
    run_tree = fake.called("repository-discovery")[0].worktrees["api"]
    assert run_tree in [c.worktree for c in fake.calls[Act.INSTALL_DEPS]]


async def test_failing_citations_go_straight_to_the_fix_without_paying_the_validators(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    fake.queue(Act.VALIDATE_CITATIONS, Issues(issues=["AC-1: quote not found in 'spec.md'"]), Issues())
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))

    assert [(g.attempt, g.passed) for g in state.gates if g.gate == "V1"] == [(1, False), (2, True)]
    assert len(fake.called("spec-validator")) == 1  # only the attempt whose citations held
    fix = fake.called("spec-analyst")[1].inputs["findings"]
    assert "citation: AC-1: quote not found" in fix[0]["message"]
    # the adversary reviews the spec and the plan at "high"; code review keeps its agent.yaml effort
    efforts = [c.effort_cap for c in fake.called("adversary")]
    assert efforts[:2] == ["high", "high"] and efforts[-1] is None


async def test_an_economy_run_caps_every_agent_call(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    economy = {"gates": {"economy": {"enabled": True, "effort_cap": "low", "max_turns_cap": 20}}}
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options=economy))
        await merge_all(handle, await wait_ready(handle))
    authors, writers = {"spec-analyst", "work-planner"}, {"backend-dev", "unit-test"}
    assert fake.agent_calls
    # the spec and plan authors keep their effort; code and test writers keep their turns; everyone else is capped
    assert all(c.effort_cap == "low" for c in fake.agent_calls if c.agent_id not in authors)
    assert all(c.effort_cap is None for c in fake.agent_calls if c.agent_id in authors)
    assert all(c.max_turns_cap == 20 for c in fake.agent_calls if c.agent_id not in writers)
    assert all(c.max_turns_cap is None for c in fake.agent_calls if c.agent_id in writers)


async def test_a_human_retry_lifts_the_turn_cap_but_keeps_the_effort_cap(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    economy = {"gates": {"economy": {"enabled": True, "effort_cap": "low", "max_turns_cap": 20}}}
    out_of_turns = AgentResult(agent_id="intake", agent_version="1.0.0", ok=False, error="error_max_turns")
    fake.script("intake", out_of_turns, {"title": "Add login", "kind": "feature", "summary": "login"})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options=economy))
        await decide(handle, "agent_error", "retry")
        await merge_all(handle, await wait_ready(handle))
    first, retried = fake.called("intake")[:2]
    assert (first.max_turns_cap, retried.max_turns_cap) == (20, None)
    assert first.effort_cap == retried.effort_cap == "low"


async def test_v1_fails_then_passes(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.script("spec-validator", {"passed": False, "issues": ["AC-1 is not testable"]}, {"passed": True})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    v1 = [(g.attempt, g.passed) for g in state.gates if g.gate == "V1"]
    assert v1 == [(1, False), (2, True)]
    fix_call = fake.called("spec-analyst")[1]
    assert fix_call.inputs["findings"][0]["message"] == "AC-1 is not testable"


async def test_v1_exhausted_escalates_then_human_retry(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    failing = {"passed": False, "issues": ["missing ACs"]}
    fake.script("spec-validator", failing, failing, failing, {"passed": True})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await decide(handle, "v1_exhausted", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert state.escalations[0].reason == "v1_exhausted" and state.escalations[0].decision == "retry"
    assert [g.passed for g in state.gates if g.gate == "V1"] == [False, False, False, True]
    assert "decision" in fake.event_types()


async def test_edit_spec_replaces_the_spec_and_drafts_the_requirement_again(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    failing = {"passed": False, "issues": ["missing ACs"]}
    fake.script("spec-validator", failing, failing, failing, {"passed": True})
    figma = SourceDoc(kind="figma", name="figma", uri="https://www.figma.com/f/abc")
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(extra_sources=[figma]))
        state = await wait_state(handle, lambda s: any(e.reason == "v1_exhausted" for e in s.escalations))
        esc = next(e for e in state.escalations if e.reason == "v1_exhausted")
        replacement = DecisionSignal(
            escalation_id=esc.id, decision="edit_spec", user="lead", content="# Login\n\nUsers log in with SSO."
        )
        await handle.signal(SIG_ESCALATION, replacement)
        await merge_all(handle, await wait_ready(handle))

    redraft = fake.called("spec-analyst")[3]  # first draft, two V1 fixes, then the draft from the replacement
    assert redraft.inputs.get("requirement") is None and "findings" not in redraft.inputs
    names = [s["name"] for s in fake.called("ambiguity-conflict-detection")[-1].inputs["sources"]]
    assert names == ["figma", "spec-edit-1"]  # the old spec text is gone; the design stays attached
    assert len(fake.called("ambiguity-conflict-detection")) == 2


async def test_gate_a_question_answered_by_signal(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.script("ambiguity-conflict-detection", {"questions": [{"id": "Q-9", "text": "SSO or password?"}]})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        waiting = await wait_state(handle, lambda s: s.stage == "gate_a" and bool(s.questions))
        assert waiting.questions[0].id == "Q-1"
        await handle.signal(SIG_ANSWER, AnswerSignal(question_id="Q-1", answer="password", user="pm@example.com"))
        state = await merge_all(handle, await wait_ready(handle))
    assert state.questions[0].answer == "password"
    fold = fake.called("spec-analyst")[-1]
    assert fold.inputs["answers"][0]["answer"] == "password"
    question_event = next(e for e in fake.events if e.type == "question")
    assert question_event.data["questions"][0]["text"] == "SSO or password?"


async def test_all_questions_answered_in_one_signal_from_the_temporal_ui(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    asked = [{"id": "Q-8", "text": "SSO or password?"}, {"id": "Q-9", "text": "Lockout after how many tries?"}]
    fake.script("ambiguity-conflict-detection", {"questions": asked})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await wait_state(handle, lambda s: s.stage == "gate_a" and len(s.questions) == 2)
        view = await handle.query(Q_OPEN_QUESTIONS, result_type=OpenQuestionsView)
        assert [q.id for q in view.questions] == ["Q-1", "Q-2"] and view.signal == SIG_ANSWERS
        assert view.template == {"answers": {"Q-1": "", "Q-2": ""}, "user": ""}
        # unknown ids and empty answers are ignored: only Q-1 is taken, so the run keeps waiting for Q-2
        partial = {"Q-1": "password", "Q-2": " ", "Q-7": "nonsense"}
        await handle.signal(SIG_ANSWERS, AnswersSignal(answers=partial, user="pm@example.com"))
        view = await handle.query(Q_OPEN_QUESTIONS, result_type=OpenQuestionsView)
        assert [q.id for q in view.questions] == ["Q-2"]
        both = {"Q-1": "SSO", "Q-2": "five"}  # an already-taken answer is not overwritten
        await handle.signal(SIG_ANSWERS, AnswersSignal(answers=both, user="pm@example.com"))
        state = await merge_all(handle, await wait_ready(handle))
    assert [(q.answer, q.answered_by) for q in state.questions] == [
        ("password", "pm@example.com"),
        ("five", "pm@example.com"),
    ]
    answers = [e.data for e in fake.events if e.type == "answer"]
    assert [(a["answer"], a["source"]) for a in answers] == [("password", "temporal"), ("five", "temporal")]


async def test_reviewing_agents_get_test_output_only_for_failures(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    noisy = TestReport(
        results=[
            TestResult(id="t1", name="test_login_ac1", level="unit", status="pass", ac_ids=["AC-1"], output="x" * 5000),
            TestResult(id="t2", name="test_logout", level="unit", status="fail", output="AssertionError: 401 != 200"),
        ]
    )
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=noisy), ToolsOutput(report=passing_report()))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))
    seen = fake.called("spec-conformance-validator")[0].inputs
    report = seen["test_report"]
    assert report["counts"] == {"pass": 1, "fail": 1}
    assert report["results"][0] == {"name": "test_login_ac1", "status": "pass", "ac_ids": ["AC-1"]}
    assert report["results"][1]["output"] == "AssertionError: 401 != 200"
    # the validators locate code through the task index, not the whole plan
    assert "plan" not in seen and seen["tasks"][0] == {
        "id": "TASK-001",
        "title": "Login API",
        "repo": "api",
        "owner_agent": "backend-dev",
        "files": ["app/login.py"],
        "depends_on": [],
        "ac_ids": ["AC-1"],
    }
    assert set(seen.get("analysis", {})) <= {"ux-design-analyst", "test-strategist"}


async def test_fix_loop_passes_on_second_iteration(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report()), ToolsOutput(report=passing_report()))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert state.iteration == 2
    assert [g.passed for g in state.gates if g.gate == "quality"] == [False, True]
    assert len(fake.called("triage")) == 1 and len(fake.called("debugger")) == 1
    fix = fake.called("backend-dev")[1]
    assert fix.inputs["fix_ticket"]["id"] == "FIX-1" and fix.allowed_files == ["app/login.py"]


async def test_repeated_failure_signature_escalates(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report()))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await decide(handle, "repeated_signature", "cancel")
        state = await handle.result()
    assert state.outcome == "cancelled"
    assert state.iteration == 2
    assert fake.calls[Act.MANIFEST_FINISH][-1].status == "cancelled"


async def test_baseline_failures_do_not_fail_the_gate(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.queue(Act.BASELINE_TESTS, ToolsOutput(report=failing_report("legacy")))
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report("legacy")))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert state.iteration == 1 and not fake.called("triage")


async def test_budget_exceeded_escalates(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.agent_cost = 0.4
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options={"budget_usd": 1.0}))
        await decide(handle, "budget", "takeover")
        state = await handle.result()
    assert state.outcome == "blocked"
    assert state.cost_usd > 1.0
    assert state.escalations[0].reason == "budget"
    assert not fake.called("work-planner")


async def test_parallel_agents_over_budget_share_one_escalation(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    second = {**PLAN["tasks"][0], "id": "TASK-002", "files": ["app/logout.py"]}
    fake.script("work-planner", {**PLAN, "tasks": [*PLAN["tasks"], second]})
    costly = AgentResult(agent_id="backend-dev", agent_version="1.0.0", ok=True, output=DEV, cost_usd=20.0)
    fake.script("backend-dev", costly, costly)  # both tasks finish over the budget together
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options={"budget_usd": 15.0}))
        await decide(handle, "budget", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready"
    assert [e.reason for e in state.escalations] == ["budget"]  # one decision, one extra tranche


async def test_early_trial_merge_conflict_with_higher_ranked_run_blocks(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    conflict = MergeConflict(repo="api", against="aidlc/REQ-000-other", run_id="run-other", files=["app/login.py"])
    fake.queue(Act.TRIAL_MERGE_GATE, TrialMergeReport(passed=False, conflicts=[conflict]))
    fake.script("overlap-analyst", {"overlaps": [Overlap(run_id="run-other", files=["app/login.py"]).model_dump()]})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await handle.result()
    assert state.outcome == "blocked"
    assert "run-other" in state.summary
    assert not fake.called("backend-dev")
    assert state.gates[-1].gate == "trial_merge_early" and not state.gates[-1].passed


async def test_early_conflict_with_integration_branch_only_does_not_block(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    conflict = MergeConflict(repo="api", against="main", files=["README.md"])
    fake.queue(
        Act.TRIAL_MERGE_GATE, TrialMergeReport(passed=False, conflicts=[conflict]), TrialMergeReport(passed=True)
    )
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready"


def absorb(blocked: bool):
    """INTEGRATE_BRANCHES fake: task branches merge cleanly; branches brought in at the final gate conflict."""

    def result(arg: IntegrateInput) -> IntegrateResult:
        if not arg.branches[0].startswith("origin/"):
            return IntegrateResult(repo=arg.repo, merged=arg.branches)
        if blocked:
            return IntegrateResult(repo=arg.repo, blocked_files=["app/login.py"])
        resolved = ConflictResolution(repo=arg.repo, file="app/login.py", resolved_by="conflict_bound")
        return IntegrateResult(repo=arg.repo, merged=arg.branches, resolutions=[resolved])

    return result


async def test_final_trial_merge_conflict_is_merged_in_when_conflict_bound_accepts_it(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    conflict = MergeConflict(repo="api", against="aidlc/REQ-000-other", run_id="run-other", files=["app/login.py"])
    fake.queue(
        Act.TRIAL_MERGE_GATE,
        TrialMergeReport(passed=True),
        TrialMergeReport(passed=False, conflicts=[conflict]),
        TrialMergeReport(passed=True),
    )
    fake.queue(Act.INTEGRATE_BRANCHES, absorb(blocked=False))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))

    assert state.outcome == "pr-ready"
    finals = [(g.attempt, g.passed) for g in state.gates if g.gate == "trial_merge_final"]
    assert finals == [(1, False), (2, True)]
    assert fake.calls[Act.INTEGRATE_BRANCHES][-1].branches == ["origin/aidlc/REQ-000-other"]
    assert [(c.file, c.resolved_by) for c in state.conflicts_resolved] == [("app/login.py", "conflict_bound")]
    assert state.iteration == 2  # the quality loop re-ran on the merged code
    pushes = [c.message for c in fake.calls[Act.GIT_COMMIT_PUSH] if c.push]
    assert "chore(aidlc): merge aidlc/REQ-000-other" in pushes
    body = fake.calls[Act.FORGE_UPDATE_AND_READY_PRS][-1].bodies["api"]
    assert "## Conflicts resolved\n- `api:app/login.py` (append_point, resolved by conflict_bound)" in body


async def test_unbounded_conflict_escalates_and_cancel_blocks(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    conflict = MergeConflict(repo="api", against="main", files=["app/login.py"])
    fake.queue(
        Act.TRIAL_MERGE_GATE, TrialMergeReport(passed=True), TrialMergeReport(passed=False, conflicts=[conflict])
    )
    fake.queue(Act.INTEGRATE_BRANCHES, absorb(blocked=True))
    blocked_notes = {"merged": False, "notes": "BLOCKED api:app/login.py: ours renames; theirs edits"}
    fake.script("branch-merge", {"merged": True}, blocked_notes)
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        waiting = await decide(handle, "conflict", "cancel")
        state = await handle.result()

    [esc] = waiting.escalations
    assert esc.detail.startswith("merge conflicts need a human: api:app/login.py")
    assert "BLOCKED api:app/login.py" in esc.detail  # Branch & Merge's explanation for the human
    assert esc.diagnosis.startswith("## Diagnosis")  # Workflow Diagnostics ran for the escalation
    assert state.outcome == "blocked"
    assert state.summary.startswith("merge conflicts need a human: api:app/login.py (ESC-1 (conflict): cancelled")
    assert not fake.calls[Act.FORGE_UPDATE_AND_READY_PRS]
    pushed = [c for c in fake.calls[Act.GIT_COMMIT_PUSH] if c.push and c.message == "chore(aidlc): sync"]
    assert pushed, "the run branch is pushed so a human can resolve the conflict on it"


async def test_a_merge_git_refuses_escalates_instead_of_failing_the_run(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    attempts = {"n": 0}

    def refuse_once(arg: IntegrateInput) -> IntegrateResult:
        attempts["n"] += 1
        if attempts["n"] == 1:
            raise ApplicationError("untracked working tree files would be overwritten by merge", non_retryable=True)
        return IntegrateResult(repo=arg.repo, merged=arg.branches)

    fake.queue(Act.INTEGRATE_BRANCHES, refuse_once)
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await decide(handle, "conflict", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready"
    assert state.escalations[0].detail.startswith("merging the task branches failed: ")


async def test_agents_failing_together_get_one_escalation_each(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    second = {**PLAN["tasks"][0], "id": "TASK-002", "files": ["app/logout.py"]}
    fake.script("work-planner", {**PLAN, "tasks": [*PLAN["tasks"], second]})
    broken = AgentResult(agent_id="backend-dev", agent_version="1.0.0", ok=False, error="connection reset by peer")
    fake.script("backend-dev", broken, broken, DEV, DEV)  # both tier-1 tasks fail at the same time
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        waiting = await wait_state(handle, lambda s: sum(e.decision is None for e in s.escalations) == 2)
        assert sorted(e.id for e in waiting.escalations) == ["ESC-1", "ESC-2"]
        await decide(handle, "agent_error", "retry")
        await decide(handle, "agent_error", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready" and [e.decision for e in state.escalations] == ["retry", "retry"]


async def test_conflict_retry_rechecks_after_a_human_resolved_it(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    conflict = MergeConflict(repo="api", against="main", files=["app/login.py"])
    fake.queue(
        Act.TRIAL_MERGE_GATE,
        TrialMergeReport(passed=True),
        TrialMergeReport(passed=False, conflicts=[conflict]),
        TrialMergeReport(passed=True),
    )
    resolved_by_human = absorb(blocked=False)
    fake.queue(
        Act.INTEGRATE_BRANCHES,
        absorb(blocked=False),  # S3 task branches
        lambda a: absorb(blocked=False)(a).model_copy(update={"resolutions": []}),  # S4 writer branches, clean
        absorb(blocked=True),  # origin/main refused by conflict_bound
        absorb(blocked=True),  # retry before anyone fixed it
        lambda a: resolved_by_human(a).model_copy(update={"resolutions": []}),  # already merged on the branch
    )
    fake.queue(Act.GIT_SYNC_BRANCH, SyncResult(updated=False, sha="abc123"), SyncResult(updated=True, sha="def456"))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await decide(handle, "conflict", "retry")
        await wait_state(handle, lambda s: len(s.escalations) == 2)
        await decide(handle, "conflict", "retry")
        state = await merge_all(handle, await wait_ready(handle))

    assert state.outcome == "pr-ready"
    assert [e.decision for e in state.escalations] == ["retry", "retry"]
    assert len(fake.calls[Act.GIT_SYNC_BRANCH]) == 2
    finals = [(g.attempt, g.passed) for g in state.gates if g.gate == "trial_merge_final"]
    assert finals == [(1, False), (2, True)]
    assert len(fake.called("branch-merge")) == 4  # S3 tier, then every integration attempt at the final gate
    assert fake.called("branch-merge")[1].inputs["integration"][0]["blocked_files"] == ["app/login.py"]


async def test_final_gate_escalates_when_branches_keep_moving(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    conflict = MergeConflict(repo="api", against="aidlc/REQ-000-other", run_id="run-other", files=["app/login.py"])
    moving = TrialMergeReport(passed=False, conflicts=[conflict])
    fake.queue(
        Act.TRIAL_MERGE_GATE, TrialMergeReport(passed=True), moving, moving, moving, TrialMergeReport(passed=True)
    )
    fake.queue(Act.INTEGRATE_BRANCHES, absorb(blocked=False))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        waiting = await decide(handle, "conflict", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert waiting.escalations[0].detail.startswith("trial_merge_final failed: api: conflicts with aidlc/REQ-000-other")
    finals = [(g.attempt, g.passed) for g in state.gates if g.gate == "trial_merge_final"]
    assert finals == [(1, False), (2, False), (3, False), (1, True)]
    assert state.outcome == "pr-ready"


async def test_activation_set_skips_agents(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))
    called = {c.agent_id for c in fake.agent_calls}
    assert {"unit-test", "static-analysis", "security-scanner"} <= called
    skipped = {"e2e-ui-test", "accessibility-test", "runtime-hazard", "performance-smell", "test-environment-data"}
    assert not skipped & called
    assert "visual-ux-validator" not in called and "ux-design-analyst" not in called


async def test_ci_red_routes_to_ci_watcher_then_green(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    red = CIStatus(
        state="failure", checks=[CheckInfo(repo="api", name="lint", status="completed", conclusion="failure")]
    )
    fake.queue(Act.FORGE_CI_STATUS, red, CIStatus(state="success"))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready"
    watcher = fake.called("ci-watcher")
    assert len(watcher) == 1 and watcher[0].inputs["ci_logs"][0]["name"] == "lint"
    assert fake.called("backend-dev")[-1].inputs["fix_ticket"]["id"] == "FIX-1"
    pushes = [c for c in fake.calls[Act.GIT_COMMIT_PUSH] if c.push and c.message.startswith("fix(aidlc)")]
    assert pushes


async def test_pr_feedback_then_merge_tears_down_preview(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    activation = [*fake.outputs["work-planner"][0]["activation_set"], "test-environment-data"]
    fake.script("work-planner", {**fake.outputs["work-planner"][0], "activation_set": activation})
    fake.script("test-environment-data", {"compose_yaml": "services: {}"})
    comment = CommentInfo(repo="api", number=1, id="c1", author="rev", body="rename this", author_is_member=True)
    fake.queue(Act.FORGE_NEW_COMMENTS, CommentsResult(comments=[comment]))
    fake.script("pr-feedback", {"replies": [{"comment_id": "c1", "body": "Done."}]})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        ready = await wait_ready(handle)
        assert ready.preview_url == "https://pr-api-1.preview.localhost"
        await handle.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=1, action="comment"))
        state = await merge_all(handle, ready)
        preview = env.client.get_workflow_handle(f"preview-{state.run_id}-api-1", result_type=RunState)
        assert (await preview.result()).stage == "down"
    assert state.outcome == "pr-ready" and state.prs[0].state == "merged"
    assert fake.called("pr-feedback")[0].inputs["pr_comments"][0]["body"] == "rename this"
    replies = fake.calls[Act.FORGE_POST_COMMENTS]
    assert any("Done." in b for r in replies for b in r.bodies)
    assert fake.calls[Act.PREVIEW_DOWN]


async def test_closed_pr_cancels_run(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await wait_ready(handle)
        await handle.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=1, action="closed"))
        state = await handle.result()
    assert state.outcome == "cancelled"
    assert fake.event_types().count("outcome") == 2  # pr-ready at ready time, cancelled when closed


async def test_cancel_signal_cancels_run(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.script("ambiguity-conflict-detection", {"questions": [{"id": "Q-1", "text": "Which IdP?"}]})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await wait_state(handle, lambda s: s.stage == "gate_a")
        await handle.signal(SIG_CANCEL, CancelSignal(user="pm@example.com"))
        state = await handle.result()
    assert state.outcome == "cancelled"
    assert "pm@example.com" in state.summary
    assert not fake.called("work-planner")


async def test_agent_failure_escalates_and_retry_recovers(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    from aidlc.contracts import AgentResult

    broken = AgentResult(agent_id="intake", agent_version="1.0.0", ok=False, error="invalid output twice")
    fake.script("intake", broken, fake.outputs["intake"][0])
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await decide(handle, "agent_error", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready"
    assert [c.attempt for c in fake.called("intake")] == [1, 2]


async def test_governance_agents_are_wired_into_the_run(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    from aidlc.orchestrator.models import KnowledgeHit, KnowledgeHits

    hit = KnowledgeHit(id="p1:LESSON-001", kind="lesson", title="Hash passwords", body="Use argon2", tags=["security"])
    fake.queue(Act.KNOWLEDGE_SEARCH, KnowledgeHits(hits=[hit]))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))

    # Knowledge Curator briefs on the raw hits; its digest is what every later agent gets as `lessons`
    [curator] = fake.called("knowledge-curator")
    assert curator.inputs["lessons"][0]["id"] == "p1:LESSON-001" and curator.inputs["requirement"]["req_id"]
    digest = fake.outputs["knowledge-curator"][0]["report_md"]
    for agent in ("solution-architect", "work-planner", "backend-dev", "reflector", "correctness-reviewer"):
        assert fake.called(agent)[0].inputs["lessons"] == digest, agent
    order = [c.agent_id for c in fake.agent_calls]
    assert order.index("knowledge-curator") < order.index("architecture-mapper")
    # Data Privacy classifies the requirement in S1; with no personal data it does not scan the diff in S5
    [privacy] = fake.called("data-privacy-governance")
    assert privacy.inputs["mode"] == "requirement" and "sources" not in privacy.inputs
    # Branch & Merge verifies every integration
    merge = fake.called("branch-merge")[0]
    assert merge.inputs["integration"][0]["merged"] == ["aidlc/REQ-001-add-login--task-001"]
    assert "api" in merge.worktrees
    # Cost Optimization reports at the end; Workflow Diagnostics only runs on escalations
    [cost] = fake.called("cost-optimization")
    assert cost.inputs["metrics"]["calls"] > 20 and cost.inputs["run_summary"]["outcome"] == "pr-ready"
    report = next(c for c in fake.calls[Act.STORE_ARTIFACT] if c.name == "cost-report.md")
    assert report.content.startswith("## Spend overview") and "| spec-analyst |" in report.content
    assert any(e.type == "log" and e.data.get("report") == "cost-report.md" for e in fake.events)
    assert not fake.called("workflow-diagnostics")
    # CI status is asked per project (Jenkins integration), gates are read with the primary repo's gates.yaml
    assert fake.calls[Act.FORGE_CI_STATUS][0].project_id == "p1"
    gates = fake.calls[Act.LOAD_GATES][0]
    assert (gates.repo_url, gates.branch) == ("https://git.example/api", None)


async def test_personal_data_becomes_nfrs_and_a_privacy_scan(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    pii = {
        "id": "F-1",
        "source_agent": "data-privacy-governance",
        "severity": "medium",
        "rule": "pii:email",
        "message": "Email addresses are masked in logs",
    }
    fake.script("data-privacy-governance", {"findings": [pii], "summary": "emails"}, {"findings": []})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))
    s1, s5 = fake.called("data-privacy-governance")
    assert (s1.inputs["mode"], s5.inputs["mode"]) == ("requirement", "diff")
    assert (
        "Privacy (pii:email): Email addresses are masked in logs"
        in fake.called("work-planner")[0].inputs["requirement"]["nfrs"]
    )


async def test_filename_title_is_replaced_by_intakes_title(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    req = feature_request(item_id="REQ-007")
    assert req.work_item is not None
    req = req.model_copy(update={"work_item": req.work_item.model_copy(update={"title": "spec.md"})})
    fake.script("intake", {"title": "Sign in with email", "kind": "feature", "summary": "login"})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, req)
        await merge_all(handle, await wait_ready(handle))
    assert fake.calls[Act.PREPARE_WORKSPACE][0].branch == "aidlc/REQ-007-sign-in-with-email"
    assert fake.calls[Act.FORGE_OPEN_DRAFT_PRS][0].title == "REQ-007: Sign in with email"
    assert fake.calls[Act.WRITE_ADLC_ARTIFACTS][0].spec_dir == "REQ-007-sign-in-with-email"
    assert fake.called("spec-analyst")[0].inputs["work_item"]["title"] == "Sign in with email"


async def test_coverage_commands_run_with_the_tests(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.script(
        "repository-discovery",
        {"test_commands": ["pytest -q"], "coverage_commands": ["pytest -q --cov=app --cov-report=json"]},
    )
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))
    run = fake.calls[Act.RUN_TOOLS][0]
    assert run.commands == ["pytest -q"] and run.coverage_commands == ["pytest -q --cov=app --cov-report=json"]
    assert all(not c.coverage_commands for c in fake.calls[Act.BASELINE_TESTS])


async def test_failed_diagnostics_never_blocks_an_escalation(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    from aidlc.contracts import AgentResult

    broken = AgentResult(agent_id="workflow-diagnostics", agent_version="1.0.0", ok=False, error="budget")
    fake.script("workflow-diagnostics", broken)
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report()))
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        waiting = await decide(handle, "repeated_signature", "cancel")
        state = await handle.result()
    assert waiting.escalations[0].diagnosis == ""
    assert state.outcome == "cancelled"
    # the cost report still runs when the run ends cancelled
    assert any(c.name == "cost-report.md" for c in fake.calls[Act.STORE_ARTIFACT])


async def test_pushed_spec_keeps_its_own_folder(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    from aidlc.orchestrator.workflows.squads.discovery import pushed_spec_dir

    assert pushed_spec_dir(".adlc/bugs/BUG-004-crash.md") == "BUG-004-crash"
    assert pushed_spec_dir("docs/spec.md") is None and pushed_spec_dir(None) is None
    options = {"trigger": "github_push", "commit": "abc", "spec_path": ".adlc/specs/REQ-001-login/requirement.md"}
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options=options))
        await merge_all(handle, await wait_ready(handle))
    assert {c.spec_dir for c in fake.calls[Act.WRITE_ADLC_ARTIFACTS] if c.spec_dir} == {"REQ-001-login"}
    assert fake.calls[Act.WRITE_ADLC_ARTIFACTS][0].item_id == "REQ-001"
    assert fake.calls[Act.PREPARE_WORKSPACE][0].branch == "aidlc/REQ-001-add-login"


async def test_declared_surfaces_skip_the_agents_a_ui_only_change_does_not_need(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    screenshot = SourceDoc(kind="image", name="library.png", uri="projects/p1/uploads/x/library.png")
    request = feature_request(surfaces=["ui"], extra_sources=[screenshot])
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, request)
        await merge_all(handle, await wait_ready(handle))

    called = {c.agent_id for c in fake.agent_calls}
    # no API and no data in a UI-only change; screenshots are enough design input for the UX analyst
    assert not {"api-contract", "data-modeler"} & called
    assert "ux-design-analyst" in called
    surfaces = fake.called("work-planner")[0].inputs["surfaces"]
    assert surfaces["declared"] == ["ui"]
    assert "frontend-dev" in surfaces["allowed_owner_agents"]
    assert "db-migration-dev" not in surfaces["allowed_owner_agents"]
    assert {"api-contract", "data-modeler", "devops-iac"} <= set(surfaces["skipped_agents"])
    assert fake.called("solution-architect")[0].inputs["surfaces"] == surfaces


async def test_a_plan_task_outside_the_declared_surfaces_fails_v2(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    ui_task = {**PLAN["tasks"][0], "owner_agent": "frontend-dev", "files": ["web/login.tsx"]}
    fake.script("work-planner", {**PLAN, "tasks": [ui_task]}, PLAN)
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(surfaces=["backend"]))
        state = await merge_all(handle, await wait_ready(handle))

    v2 = [g for g in state.gates if g.gate == "V2"]
    assert not v2[0].passed and "'frontend-dev' is not one of the development agents" in v2[0].issues[0]
    assert v2[-1].passed
    assert "frontend-dev" not in {c.agent_id for c in fake.agent_calls}
    assert "api-contract" in {c.agent_id for c in fake.agent_calls}


async def test_a_templated_specs_check_reaches_the_spec_analyst_and_its_risk_tier_the_gates(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    spec_check = {"template": "backend", "gaps": ["6. Business rules and data"], "warnings": []}
    options = {"spec_check": spec_check, "risk_tier": "high"}
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options=options, surfaces=["backend"]))
        await merge_all(handle, await wait_ready(handle))

    assert fake.called("spec-analyst")[0].inputs["spec_check"] == spec_check
    assert fake.called("spec-analyst")[0].inputs["work_item"]["surfaces"] == ["backend"]
    assert fake.calls[Act.LOAD_GATES][0].risk_tier == "high"


async def test_an_undeclared_change_still_runs_every_design_agent(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        await merge_all(handle, await wait_ready(handle))

    called = {c.agent_id for c in fake.agent_calls}
    assert {"api-contract", "data-modeler"} <= called
    assert "surfaces" not in fake.called("work-planner")[0].inputs
    assert "spec_check" not in fake.called("spec-analyst")[0].inputs


QUOTA = "API Error: Request rejected (429) · Too many tokens per day, please wait before trying again."


FAST_QUOTA = {"gates": {"quota_wait_s": 1}}


async def test_a_spent_token_quota_waits_and_retries_without_asking_a_human(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    quota = AgentResult(agent_id="intake", agent_version="1.0.0", ok=False, error=QUOTA)
    fake.script("intake", quota, quota, {"title": "Add login", "kind": "feature", "summary": "login"})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options=FAST_QUOTA))
        state = await merge_all(handle, await wait_ready(handle))
    assert state.outcome == "pr-ready" and state.escalations == []
    assert len(fake.called("intake")) == 3
    assert sum("token quota reached" in e.message for e in fake.events) == 2  # two waits of quota_wait_s


async def test_agents_stopped_by_the_quota_share_one_escalation(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    second = {**PLAN["tasks"][0], "id": "TASK-002", "files": ["app/logout.py"]}
    fake.script("work-planner", {**PLAN, "tasks": [*PLAN["tasks"], second]})
    quota = AgentResult(agent_id="backend-dev", agent_version="1.0.0", ok=False, error=QUOTA)
    fake.script("backend-dev", *[quota] * 14, DEV, DEV)  # both tasks exhaust their waits, then succeed
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request(options=FAST_QUOTA))
        await decide(handle, "agent_error", "retry")
        state = await merge_all(handle, await wait_ready(handle))
    assert [e.reason for e in state.escalations] == ["agent_error"]
    assert "token quota" in state.escalations[0].detail


async def test_failed_integration_verification_is_fixed_by_the_owner_before_asking_a_human(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    failed = {"merged": False, "notes": "FAILED api: npm run typecheck exit 2: app/login.py(3,1): unused variable"}
    fake.script("branch-merge", failed, {"merged": True, "notes": "OK api: tests 1/1"})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert state.escalations == []
    fix = next(c for c in fake.called("backend-dev") if c.inputs.get("fix_ticket"))
    assert fix.inputs["fix_ticket"]["id"] == "INT-1" and "unused variable" in fix.inputs["fix_ticket"]["evidence"]
    assert "app/login.py" in fix.allowed_files and "package.json" in fix.allowed_files
    assert "eslint.config.*" in fix.allowed_files  # a lint fix may need the tool's own configuration
    # once the nested fix stage ends, the run is back in S3: the re-verification is reported under S3
    fix_done = next(i for i, e in enumerate(fake.events) if e.type == "stage_completed" and e.stage == "fix")
    reverify = next(e for e in fake.events[fix_done:] if e.type == "agent_started" and e.agent_id == "branch-merge")
    assert reverify.stage == "S3"


async def test_v1_rechecks_its_own_findings_and_minor_ones_do_not_block(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    fake.script(
        "spec-validator",
        {"passed": False, "issues": ["AC-1 is not testable"]},
        {"passed": False, "issues": ["(minor) AC-1 could name the field"]},
    )
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert [g.passed for g in state.gates if g.gate == "V1"] == [False, True]
    first, recheck = fake.called("spec-validator")[:2]
    assert "mode" not in first.inputs
    assert recheck.inputs["mode"] == "recheck" and recheck.inputs["findings"][0]["message"] == "AC-1 is not testable"


async def test_v2_rechecks_the_adversarys_own_blocking_findings(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    gap = {
        "id": "F-1",
        "source_agent": "adversary",
        "severity": "high",
        "rule": "adversary/plan/missing-dependency",
        "message": "TASK-001 misses a dependency",
        "blocking": True,
    }
    fake.script("adversary", {"findings": []}, {"findings": [gap]}, {"findings": []})  # V1, V2 attempt 1, recheck
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert [g.passed for g in state.gates if g.gate == "V2"] == [False, True]
    plan_recheck = [c for c in fake.called("adversary") if c.inputs.get("mode") == "plan"][1]
    assert plan_recheck.inputs["findings"][0]["message"] == "TASK-001 misses a dependency"


async def test_personal_data_the_privacy_agent_only_infers_becomes_a_gate_a_question(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    inferred = {
        "id": "F-1",
        "source_agent": "data-privacy-governance",
        "severity": "info",
        "rule": "pii:health",
        "message": "The incident notes field might hold health details.",
    }
    fake.script("data-privacy-governance", {"findings": [inferred]})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        waiting = await wait_state(handle, lambda s: s.stage == "gate_a" and bool(s.questions))
        question = next(q for q in waiting.questions if "incident notes" in q.text)
        assert len({q.id for q in waiting.questions}) == len(waiting.questions)
        assert all(q.id.startswith("Q-") and q.id[2:].isdigit() for q in waiting.questions)
        assert question.options[1] == "No: it is not personal data"
        await handle.signal(SIG_ANSWER, AnswerSignal(question_id=question.id, answer="No", user="pm@example.com"))
        await merge_all(handle, await wait_ready(handle))
    planned_nfrs = [n for c in fake.called("work-planner") for n in c.inputs["requirement"]["nfrs"]]
    assert not any("Privacy (pii:health)" in n for n in planned_nfrs)


async def test_integration_verification_gets_two_automatic_fixes_before_a_human(
    env: WorkflowEnvironment, fake: FakePlatform
) -> None:
    failed = {"merged": False, "notes": "FAILED api: npm run lint: app/login.py line 2: no-undef"}
    fake.script("branch-merge", failed, failed, {"merged": True, "notes": "OK api: tests 1/1"})
    async with running(env, fake) as tq:
        handle = await start(env, tq, FEATURE, feature_request())
        state = await merge_all(handle, await wait_ready(handle))
    assert state.escalations == []
    fixes = [c.inputs["fix_ticket"]["id"] for c in fake.called("backend-dev") if c.inputs.get("fix_ticket")]
    assert fixes == ["INT-1", "INT-2"]  # one ticket per round
