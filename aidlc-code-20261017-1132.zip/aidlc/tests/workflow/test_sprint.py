import asyncio

from temporalio.testing import WorkflowEnvironment

from aidlc.contracts import RunState
from aidlc.names import SIG_PR_EVENT, SPRINT
from aidlc.orchestrator.models import Act, PREventSignal, ToolsOutput
from tests.workflow.fakes import (
    FakePlatform,
    failing_report,
    feature_request,
    passing_report,
    project,
    running,
    start,
    wait_state,
)


async def test_sprint_runs_children_and_aggregates(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    children = [feature_request(f"child-{i}") for i in (1, 2)]
    sprint = feature_request("sprint-1", kind="sprint").model_copy(
        update={
            "work_item": None,
            "project": project(),
            "options": {"children": [{"run_id": c.run_id, "work_item": c.work_item} for c in children]},
        }
    )
    async with running(env, fake) as tq:
        handle = await start(env, tq, SPRINT, sprint)
        child_handles = [env.client.get_workflow_handle(c.run_id, result_type=RunState) for c in children]
        ready = await asyncio.gather(
            *(wait_state(h, lambda s: s.outcome == "pr-ready" and s.stage == "gate_b") for h in child_handles)
        )
        for h, st in zip(child_handles, ready, strict=True):
            await h.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=st.prs[0].number, action="merged"))
        state = await handle.result()

    assert state.outcome == "pr-ready"
    assert len(state.prs) == 2
    assert "child-1: pr-ready" in state.summary and "child-2: pr-ready" in state.summary
    assert state.cost_usd > 0
    assert {c.run_id for c in fake.agent_calls} == {"child-1", "child-2"}


async def test_sprint_without_children_fails(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    sprint = feature_request(kind="sprint").model_copy(update={"work_item": None})
    async with running(env, fake) as tq:
        state = await (await start(env, tq, SPRINT, sprint)).result()
    assert state.outcome == "failed"


async def test_sprint_runs_bug_items_as_bugfix_children(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report()), ToolsOutput(report=passing_report()))
    bug = feature_request("child-bug", kind="bugfix")
    sprint = feature_request("sprint-2", kind="sprint").model_copy(
        update={"work_item": None, "options": {"children": [{"run_id": bug.run_id, "work_item": bug.work_item}]}}
    )
    async with running(env, fake) as tq:
        handle = await start(env, tq, SPRINT, sprint)
        child = env.client.get_workflow_handle(bug.run_id, result_type=RunState)
        ready = await wait_state(child, lambda s: s.outcome == "pr-ready" and s.stage == "gate_b")
        assert ready.kind == "bugfix"
        await child.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=ready.prs[0].number, action="merged"))
        state = await handle.result()

    assert state.outcome == "pr-ready"
    assert fake.called("spec-analyst")[0].inputs["mode"] == "bug"
    assert fake.called("debugger") and not fake.called("work-planner")
