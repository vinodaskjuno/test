from collections.abc import AsyncIterator

import pytest
from temporalio.testing import WorkflowEnvironment

from aidlc.orchestrator.workflows import DATA_CONVERTER
from tests.workflow.fakes import FakePlatform


@pytest.fixture
async def env() -> AsyncIterator[WorkflowEnvironment]:
    async with await WorkflowEnvironment.start_time_skipping(data_converter=DATA_CONVERTER) as environment:
        yield environment


@pytest.fixture
def fake() -> FakePlatform:
    return FakePlatform()
