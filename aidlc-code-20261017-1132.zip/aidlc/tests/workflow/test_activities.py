"""Activities against real git repos, the real templates and the test DB (workflow tests mock them out)."""

import subprocess
from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest

from aidlc.contracts import AcceptanceCriterion, Citation, Plan, ProjectConfig, RepoRef, Requirement, RunState, Task
from aidlc.interfaces import ExecResult
from aidlc.orchestrator.activities import artifacts, forge_ops, git_ops, platform_ops, tools_exec
from aidlc.orchestrator.models import (
    ArtifactsInput,
    CheckInfo,
    CIInput,
    CIRef,
    CommentsInput,
    CommitInput,
    DiffInput,
    DoctorInput,
    InstallInput,
    IntegrateInput,
    LoadGatesInput,
    OnboardingScaffoldInput,
    OpenPRsInput,
    PostCommentsInput,
    PRSpec,
    PushBranchesInput,
    RegisterRepoInput,
    RunRef,
    RunRowInput,
    StoreArtifactInput,
    SyncInput,
    TaskWorktreesInput,
    TaskWorktreeSpec,
    ToolsInput,
    TrialMergeInput,
    WorkspaceInput,
)
from aidlc.platform import db, factory
from aidlc.platform.git import worktrees

GIT = ["git", "-c", "user.name=t", "-c", "user.email=t@example.com"]


def sh(*args: str, cwd: Path) -> None:
    subprocess.run([*GIT, *args], cwd=cwd, check=True, capture_output=True)


@pytest.fixture
def remote(tmp_path: Path) -> Path:
    seed = tmp_path / "seed"
    seed.mkdir()
    sh("init", "-q", "-b", "main", cwd=seed)
    (seed / "notes.py").write_text("x = 0\n")
    (seed / "config.py").write_text("MODE = 'a'\n")
    sh("add", "-A", cwd=seed)
    sh("commit", "-q", "-m", "seed", cwd=seed)
    bare = tmp_path / "remote.git"
    subprocess.run(["git", "clone", "-q", "--bare", str(seed), str(bare)], check=True)
    return bare


def project(url: str) -> ProjectConfig:
    return ProjectConfig(project_id="p1", name="Demo", repos=[RepoRef(id="api", url=url, primary=True)])


async def test_git_workspace_tasks_integration_and_trial_merge(remote: Path) -> None:
    ws = await git_ops.prepare_workspace(
        WorkspaceInput(run_id="r1", project=project(str(remote)), branch="aidlc/REQ-001-x", repo_ids=["api"])
    )
    repo = ws.repos["api"]
    assert repo.base_branch == "main" and (Path(repo.path) / "notes.py").is_file()

    tasks = await git_ops.prepare_task_worktrees(
        TaskWorktreesInput(
            run_id="r1",
            branch=ws.branch,
            items=[TaskWorktreeSpec(task_id=t, repo="api", repo_path=repo.path) for t in ("TASK-001", "TASK-002")],
        )
    )
    first, second = tasks.items
    assert first.branch == "aidlc/REQ-001-x--r1-task-001"  # scoped to the run: a retried run never inherits it
    (Path(first.path) / "notes.py").write_text("x = 0\na = 1\n")
    (Path(second.path) / "notes.py").write_text("x = 0\nb = 2\n")
    for wt in tasks.items:
        done = await git_ops.git_commit_push(
            CommitInput(worktree=wt.path, branch=wt.branch, message=wt.task_id, push=False)
        )
        assert done.committed

    merged = await git_ops.integrate_branches(
        IntegrateInput(repo="api", worktree=repo.path, target_branch=ws.branch, branches=[first.branch, second.branch])
    )
    assert merged.merged == [first.branch, second.branch] and not merged.blocked_files
    assert [r.file for r in merged.resolutions] == ["notes.py"]  # both sides appended at the same point
    assert set((Path(repo.path) / "notes.py").read_text().splitlines()) == {"x = 0", "a = 1", "b = 2"}

    diff = await git_ops.git_diff(DiffInput(repo="api", worktree=repo.path, base="main"))
    assert diff.changed_files == ["notes.py"] and "+a = 1" in diff.diff

    pushed = await git_ops.git_commit_push(CommitInput(worktree=repo.path, branch=ws.branch, message="sync"))
    assert not pushed.committed  # nothing new, but the branch is pushed
    subprocess.run(["git", "rev-parse", "--verify", ws.branch], cwd=remote, check=True, capture_output=True)

    report = await git_ops.trial_merge_gate(TrialMergeInput(run_id="r1", branch=ws.branch, repos=ws.repos))
    assert report.passed


async def test_unbounded_conflict_is_blocked_and_merge_aborted(remote: Path) -> None:
    ws = await git_ops.prepare_workspace(
        WorkspaceInput(run_id="r2", project=project(str(remote)), branch="aidlc/REQ-002-y", repo_ids=["api"])
    )
    repo = ws.repos["api"]
    tasks = await git_ops.prepare_task_worktrees(
        TaskWorktreesInput(
            run_id="r2",
            branch=ws.branch,
            items=[TaskWorktreeSpec(task_id=t, repo="api", repo_path=repo.path) for t in ("TASK-001", "TASK-002")],
        )
    )
    for wt, mode in zip(tasks.items, ("b", "c"), strict=True):
        (Path(wt.path) / "config.py").write_text(f"MODE = '{mode}'\n")
        await git_ops.git_commit_push(CommitInput(worktree=wt.path, branch=wt.branch, message=mode, push=False))
    result = await git_ops.integrate_branches(
        IntegrateInput(
            repo="api", worktree=repo.path, target_branch=ws.branch, branches=[t.branch for t in tasks.items]
        )
    )
    assert result.merged == [tasks.items[0].branch] and result.blocked_files == ["config.py"]
    assert (Path(repo.path) / "config.py").read_text() == "MODE = 'b'\n"  # merge aborted cleanly


class FakeExecutor:
    def __init__(self, stdout: str, exit_code: int = 0) -> None:
        self.stdout, self.exit_code = stdout, exit_code
        self.commands: list[Sequence[str]] = []

    async def run(
        self, command: Sequence[str], cwd: Path, *, timeout_s: int = 600, env: Mapping[str, str] | None = None
    ) -> ExecResult:
        self.commands.append(command)
        return ExecResult(
            command=" ".join(command), exit_code=self.exit_code, stdout=self.stdout, stderr="", duration_ms=5
        )


class InstallingExecutor:
    """Records each install and leaves behind what real installs do."""

    def __init__(self) -> None:
        self.runs: list[tuple[str, Path, dict[str, str]]] = []

    async def run(
        self, command: Sequence[str], cwd: Path, *, timeout_s: int = 600, env: Mapping[str, str] | None = None
    ) -> ExecResult:
        self.runs.append((command[-1], cwd, dict(env or {})))
        if command[-1] == "npm ci":
            (cwd / "node_modules").mkdir()
            (cwd / "node_modules" / "pkg.js").write_text("")
        else:
            (cwd / "requirements.lock").write_text("pinned\n")  # an install that generates an untracked file
        return ExecResult(command=" ".join(command), exit_code=0, stdout="", stderr="", duration_ms=1)


async def test_install_deps_covers_every_lockfile_package_and_keeps_leftovers_out_of_commits(remote: Path) -> None:
    ws = await git_ops.prepare_workspace(
        WorkspaceInput(run_id="r9", project=project(str(remote)), branch="aidlc/REQ-009-x", repo_ids=["api"])
    )
    path = Path(ws.repos["api"].path)
    (path / "web").mkdir()
    (path / "web" / "package-lock.json").write_text("{}\n")  # a package an earlier task added
    sh("add", "-A", cwd=path)
    sh("commit", "-q", "-m", "web package", cwd=path)
    executor = InstallingExecutor()
    factory.set_override("executor", executor)
    out = await tools_exec.install_deps(InstallInput(worktree=str(path), commands=["pip install -e ."]))
    assert [c.command for c in out.commands] == ["pip install -e .", "cd web && npm ci"]
    assert executor.runs[1][1] == path / "web"
    assert all(env["npm_config_cache"].endswith("/cache/npm") for _, _, env in executor.runs)
    assert out.excluded == ["requirements.lock"]
    assert (await tools_exec.install_deps(InstallInput(worktree=str(path)))).commands == []  # already installed
    assert await worktrees.commit_all(path, "nothing new", "Bot", "bot@x") is None


def test_test_output_parsing_maps_acceptance_criteria() -> None:
    pytest_out = (
        "tests/test_login.py::test_login_ac_1 PASSED\n"
        "tests/test_login.py::test_rejects_bad_password_AC2 FAILED\n"
        "FAILED tests/test_login.py::test_lockout_ac-3 - AssertionError\n"
        "TOTAL      120     12    90%\n"
    )
    results = {r.id: r for r in tools_exec.parse_output(pytest_out, level="unit", repo="api")}
    assert results["tests/test_login.py::test_login_ac_1"].ac_ids == ["AC-1"]
    assert results["tests/test_login.py::test_rejects_bad_password_AC2"].status == "fail"
    assert results["tests/test_login.py::test_lockout_ac-3"].ac_ids == ["AC-3"]
    assert tools_exec.parse_coverage(pytest_out) == 90.0
    vitest = " \u2713 AC-4: shows the login form 12ms\n \u00d7 AC-5 locks after three tries\nAll files |   81.5 |\n"
    js = {r.id: r for r in tools_exec.parse_output(vitest, level="unit", repo="web")}
    assert js["AC-4: shows the login form"].status == "pass" and js["AC-5 locks after three tries"].ac_ids == ["AC-5"]
    assert tools_exec.parse_coverage(vitest) == 81.5
    node = (
        "\u2714 AC-6 keeps the caption (0.68ms)\n\u2716 AC-7 shows the badge (1.2ms)\n\u2139 tests 2\n"
        "\u2716 failing tests:\n\n\u2716 AC-7 shows the badge (1.2ms)\n"
    )
    nodes = {r.id: r.status for r in tools_exec.parse_output(node, level="unit", repo="web")}
    assert nodes == {"AC-6 keeps the caption": "pass", "AC-7 shows the badge": "fail"}
    junit = (
        '<testsuite><testcase classname="Login" name="ac1 works" time="0.5"/>'
        '<testcase name="t2"><failure/></testcase></testsuite>'
    )
    parsed = tools_exec.parse_junit(junit, level="e2e", repo="web")
    assert [(r.id, r.status, r.ac_ids) for r in parsed] == [("Login::ac1 works", "pass", ["AC-1"]), ("t2", "fail", [])]
    assert tools_exec.ac_ids("test_cache_hit") == []


async def test_run_tools_falls_back_to_exit_codes(tmp_path: Path) -> None:
    executor = FakeExecutor("boom", exit_code=2)
    factory.set_override("executor", executor)
    out = await tools_exec.run_tools(ToolsInput(repo="api", worktree=str(tmp_path), commands=["make check"]))
    assert executor.commands == [["sh", "-c", "make check"]]
    assert [(r.id, r.status) for r in out.report.results] == [("api: make check", "fail")]
    assert not out.ok and out.commands[0].exit_code == 2

    factory.set_override("executor", FakeExecutor("tests/a.py::test_x PASSED\n", exit_code=1))
    crashed = await tools_exec.baseline_tests(ToolsInput(repo="api", worktree=str(tmp_path), commands=["pytest"]))
    assert {r.status for r in crashed.report.results} == {"pass", "fail"}  # passing tests + the crashed command
    assert {r.level for r in crashed.report.results} == {"baseline"}


def requirement() -> Requirement:
    ac = AcceptanceCriterion(
        id="AC-1", text="A user can log in", citations=[Citation(source_name="spec.md", quote="log in")]
    )
    return Requirement(req_id="REQ-999", title="Add login", summary="Login.", acceptance_criteria=[ac], nfrs=["Fast"])


def test_adlc_artifacts_render_from_templates(tmp_path: Path) -> None:
    plan = Plan(
        architecture_md="# Design",
        openapi_yaml="openapi: 3.1.0",
        tasks=[
            Task(
                id="TASK-001",
                title="API",
                repo="api",
                owner_agent="backend-dev",
                description="d",
                files=["a.py"],
                ac_ids=["AC-1"],
            ),
            Task(
                id="TASK-002",
                title="UI",
                repo="api",
                owner_agent="frontend-dev",
                description="d",
                depends_on=["TASK-001"],
            ),
        ],
        activation_set=[],
    )
    arg = ArtifactsInput(
        worktree=str(tmp_path),
        spec_dir="REQ-007-add-login",
        requirement=requirement(),
        plan=plan,
        run_state=RunState(run_id="r1", kind="feature"),
        requested_by="pm@example.com",
    )
    written = artifacts.write_files(tmp_path, artifacts.adlc_files(arg))
    spec = tmp_path / ".adlc/specs/REQ-007-add-login"
    req_md = (spec / "requirement.md").read_text()
    assert "id: REQ-007" in req_md and "Template:" not in req_md and "{{" not in req_md
    assert '### AC-1: A user can log in\n> "log in" (source: spec.md)' in req_md and "- Fast" in req_md
    assert "tier: 1" in (spec / "tasks/TASK-002.md").read_text()
    assert (spec / "openapi.yaml").is_file() and (spec / "run.json").is_file()
    assert len(written) == 6

    bug = artifacts.adlc_files(
        ArtifactsInput(worktree=str(tmp_path), kind="bug", spec_dir="BUG-003-crash", requirement=requirement())
    )
    assert "id: BUG-003" in bug[".adlc/bugs/BUG-003-crash.md"]
    pushed = artifacts.adlc_files(
        ArtifactsInput(worktree=str(tmp_path), spec_dir="login", item_id="REQ-012", requirement=requirement())
    )
    assert list(pushed) == [".adlc/specs/login/requirement.md"]  # a pushed spec is rewritten in place
    assert "id: REQ-012" in pushed[".adlc/specs/login/requirement.md"]
    with pytest.raises(ValueError, match="outside the worktree"):
        artifacts.write_files(tmp_path, {"../escape.md": "x"})


async def test_onboarding_scaffold_passes_doctor(tmp_path: Path) -> None:
    worktree = tmp_path / "repo"
    worktree.mkdir()
    cfg = project("https://git.example/api")
    await artifacts.write_onboarding_scaffold(
        OnboardingScaffoldInput(
            worktree=str(worktree), project=cfg, preset="generic-python", repo_profile={"languages": ["python"]}
        )
    )
    report = await artifacts.adlc_doctor(DoctorInput(worktree=str(worktree)))
    assert report.ok, report.checks
    assert "stack: generic-python" in (worktree / ".adlc/config.yml").read_text()
    (worktree / ".adlc/context/conventions.md").unlink()
    broken = await artifacts.adlc_doctor(DoctorInput(worktree=str(tmp_path / "missing")))
    assert not broken.ok and {c.name for c in broken.checks if not c.ok} >= {"config", "context/conventions.md"}


async def test_persist_state_and_store_artifact() -> None:
    with db.session_scope() as session:
        session.add(db.Run(id="r9", project_id="p1", kind="feature", workflow_id="r9", created_by="me"))
    state = RunState(run_id="r9", kind="feature", stage="S4", iteration=2, cost_usd=1.5)
    await platform_ops.persist_state(state)
    with db.session_scope() as session:
        run = session.get(db.Run, "r9")
        assert run is not None and (run.stage, run.iteration, run.cost_usd) == ("S4", 2, 1.5)
        assert run.state["stage"] == "S4"
    await platform_ops.persist_state(RunState(run_id="unknown", kind="feature"))  # mirror only: never fails a run

    key = await platform_ops.store_artifact(StoreArtifactInput(run_id="r9", name="audit-pack.md", content="# Audit"))
    assert await factory.get_artifact_store().get("runs/r9/audit-pack.md") == b"# Audit"
    assert key


async def test_register_repo_adds_the_repo_to_the_project_config() -> None:
    with db.session_scope() as session:
        session.add(db.Org(id="o1", name="o1"))
        session.add(db.Team(id="t1", org_id="o1", name="t"))
        session.add(db.Project(id="p1", team_id="t1", name="P", config={"repos": [{"id": "api", "url": "u1"}]}))
    new = RepoRef(id="todo-app", url="/remotes/todo-app.git", primary=True, integration_branch="main")
    await platform_ops.register_repo(RegisterRepoInput(project_id="p1", repo=new))
    await platform_ops.register_repo(RegisterRepoInput(project_id="p1", repo=new))  # idempotent
    with db.session_scope() as session:
        repos = session.get(db.Project, "p1").config["repos"]
    assert repos == [
        {"id": "api", "url": "u1"},
        {"id": "todo-app", "url": "/remotes/todo-app.git", "primary": True, "integration_branch": "main"},
    ]
    other = RepoRef(id="web", url="/remotes/web.git", primary=True)
    await platform_ops.register_repo(RegisterRepoInput(project_id="p1", repo=other))
    with db.session_scope() as session:
        assert session.get(db.Project, "p1").config["repos"][-1]["primary"] is False  # one primary per project
    await platform_ops.register_repo(RegisterRepoInput(project_id="missing", repo=new))  # logged, not raised


def test_ci_state() -> None:
    def check(status: str, conclusion: str | None = None) -> CheckInfo:
        return CheckInfo(repo="api", name="ci", status=status, conclusion=conclusion)

    assert forge_ops.ci_state([]) == "success"
    assert forge_ops.ci_state([check("completed", "success"), check("completed", "skipped")]) == "success"
    assert forge_ops.ci_state([check("in_progress"), check("completed", "success")]) == "pending"
    assert forge_ops.ci_state([check("in_progress"), check("completed", "failure")]) == "failure"


async def test_human_resolution_is_published_and_synced(remote: Path, tmp_path: Path) -> None:
    ws = await git_ops.prepare_workspace(
        WorkspaceInput(run_id="r5", project=project(str(remote)), branch="aidlc/REQ-005-z", repo_ids=["api"])
    )
    repo = ws.repos["api"]
    [task] = (
        await git_ops.prepare_task_worktrees(
            TaskWorktreesInput(
                run_id="r5",
                branch=ws.branch,
                items=[TaskWorktreeSpec(task_id="TASK-001", repo="api", repo_path=repo.path)],
            )
        )
    ).items
    (Path(task.path) / "config.py").write_text("MODE = 'task'\n")
    await git_ops.git_commit_push(CommitInput(worktree=task.path, branch=task.branch, message="task", push=False))
    await git_ops.git_commit_push(CommitInput(worktree=repo.path, branch=ws.branch, message="sync"))
    await git_ops.git_push_branches(PushBranchesInput(worktree=repo.path, branches=[task.branch]))
    assert (
        subprocess.run(["git", "rev-parse", "--verify", task.branch], cwd=remote, capture_output=True).returncode == 0
    )

    nothing = await git_ops.git_sync_branch(SyncInput(worktree=repo.path, branch=ws.branch))
    assert not nothing.updated and not nothing.conflicts

    # a human merges the task branch on the forge and pushes the result to the run branch
    human = tmp_path / "human"
    subprocess.run(["git", "clone", "-q", "-b", ws.branch, str(remote), str(human)], check=True)
    sh("merge", "--no-ff", "--no-edit", f"origin/{task.branch}", cwd=human)
    sh("push", "-q", "origin", ws.branch, cwd=human)
    synced = await git_ops.git_sync_branch(SyncInput(worktree=repo.path, branch=ws.branch))
    assert synced.updated and not synced.conflicts
    assert (Path(repo.path) / "config.py").read_text() == "MODE = 'task'\n"
    again = await git_ops.integrate_branches(
        IntegrateInput(repo="api", worktree=repo.path, target_branch=ws.branch, branches=[task.branch])
    )
    assert again.merged == [task.branch] and not again.blocked_files  # already merged: a no-op

    # local and remote diverge on the same line: the merge is aborted and reported
    (Path(repo.path) / "notes.py").write_text("x = 'local'\n")
    await git_ops.git_commit_push(CommitInput(worktree=repo.path, branch=ws.branch, message="local", push=False))
    sh("pull", "-q", "--no-rebase", cwd=human)
    (human / "notes.py").write_text("x = 'remote'\n")
    sh("commit", "-qam", "remote", cwd=human)
    sh("push", "-q", "origin", ws.branch, cwd=human)
    diverged = await git_ops.git_sync_branch(SyncInput(worktree=repo.path, branch=ws.branch))
    assert diverged.conflicts == ["notes.py"] and not diverged.updated
    assert (Path(repo.path) / "notes.py").read_text() == "x = 'local'\n"


async def test_open_prs_reuses_the_open_pr_for_the_head(remote: Path) -> None:
    from aidlc.platform.forge.local import LocalForge

    factory.set_override("forge", LocalForge(Path("/unused")))
    ws = await git_ops.prepare_workspace(
        WorkspaceInput(run_id="r6", project=project(str(remote)), branch="aidlc/REQ-006-pr", repo_ids=["api"])
    )
    await git_ops.git_commit_push(CommitInput(worktree=ws.repos["api"].path, branch=ws.branch, message="sync"))
    spec = PRSpec(repo="api", repo_url=str(remote), head=ws.branch, base="main")
    first = await forge_ops.forge_open_draft_prs(OpenPRsInput(items=[spec], title="REQ-006: PR", body="b"))
    retried = await forge_ops.forge_open_draft_prs(OpenPRsInput(items=[spec], title="REQ-006: PR", body="b"))
    assert first.prs == retried.prs and first.prs[0].repo == "api"
    assert len(rows := db_rows(db.LocalPR)) == 1 and rows[0].head == ws.branch


def db_rows(model: type) -> list:
    with db.session_scope() as session:
        return list(session.query(model).all())


def _project_row(project_id: str = "p1", **fields: object) -> None:
    with db.session_scope() as session:
        session.add(db.Org(id="o1", name="o1"))
        session.add(db.Team(id="t1", org_id="o1", name="t"))
        session.add(db.Project(id=project_id, team_id="t1", name="P", **fields))


async def test_ci_status_merges_jenkins_builds(remote: Path) -> None:
    import httpx
    import respx

    from aidlc.platform.forge.local import LocalForge

    factory.set_override("forge", LocalForge(Path("/unused")))
    jenkins = {
        "base_url": "https://ci.acme.test/",
        "user": "bot",
        "api_token": "t0k",
        "job_path": "job/{repo}/job/{branch}",
    }
    _project_row(integrations={"jenkins": jenkins})
    items = [
        CIRef(repo="api", repo_url=str(remote), ref="aidlc/REQ-001-x"),
        CIRef(repo="web", repo_url=str(remote), ref="main"),
    ]
    with respx.mock:
        api = respx.get("https://ci.acme.test/job/api/job/aidlc%252FREQ-001-x/lastBuild/api/json").mock(
            side_effect=[
                httpx.Response(200, json={"building": True, "result": None, "url": "https://ci/1"}),
                httpx.Response(200, json={"building": False, "result": "UNSTABLE", "url": "https://ci/1"}),
                httpx.Response(200, json={"building": False, "result": "SUCCESS", "url": "https://ci/2"}),
            ]
        )
        respx.get("https://ci.acme.test/job/web/job/main/lastBuild/api/json").mock(
            return_value=httpx.Response(200, json={"building": False, "result": "SUCCESS"})
        )
        building = await forge_ops.forge_ci_status(CIInput(items=items, project_id="p1"))
        failed = await forge_ops.forge_ci_status(CIInput(items=items, project_id="p1"))
        green = await forge_ops.forge_ci_status(CIInput(items=items, project_id="p1"))
        without = await forge_ops.forge_ci_status(CIInput(items=items))  # no project: forge checks only
    assert api.call_count == 3
    assert api.calls[0].request.headers["Authorization"].startswith("Basic ")
    assert building.state == "pending" and building.checks[0].name == "jenkins"
    assert failed.state == "failure"
    assert [(c.repo, c.conclusion, c.details_url) for c in failed.checks] == [
        ("api", "failure", "https://ci/1"),
        ("web", "success", None),
    ]
    assert green.state == "success" and without.state == "success" and without.checks == []


async def test_load_gates_layers_defaults_repo_file_and_project_overrides(remote: Path, tmp_path: Path) -> None:
    seed = tmp_path / "gates-seed"
    subprocess.run(["git", "clone", "-q", str(remote), str(seed)], check=True)
    (seed / ".adlc").mkdir()
    (seed / ".adlc" / "gates.yaml").write_text("coverage_min_pct: 65\na11y: AAA\nrequire_coverage_report: true\n")
    sh("add", "-A", cwd=seed)
    sh("commit", "-qm", "gates", cwd=seed)
    sh("push", "-q", "origin", "main", cwd=seed)
    _project_row(gates={"a11y": "off"})
    loaded = await platform_ops.load_project_gates(LoadGatesInput(project_id="p1", repo_url=str(remote)))
    assert (loaded["coverage_min_pct"], loaded["a11y"], loaded["require_coverage_report"]) == (65, "off", True)
    assert loaded["v1_max_attempts"] == 3  # preset default
    other_branch = await platform_ops.load_project_gates(
        LoadGatesInput(project_id="p1", repo_url=str(remote), branch="no-such-branch")
    )
    assert other_branch["coverage_min_pct"] == 80  # nothing readable on that branch: defaults + DB only
    unreachable = await platform_ops.load_project_gates(LoadGatesInput(project_id="p1", repo_url=str(tmp_path / "x")))
    assert unreachable["a11y"] == "off" and unreachable["coverage_min_pct"] == 80


async def test_coverage_commands_and_report_files(tmp_path: Path) -> None:
    from aidlc.platform.sandbox.local import LocalExecutor

    factory.set_override("executor", LocalExecutor())
    (tmp_path / "api").mkdir()
    (tmp_path / "web" / "coverage").mkdir(parents=True)
    write_cov = (
        "printf '%s' '{\"totals\": {\"percent_covered\": 91.25}}' > api/coverage.json && "
        'printf \'%s\' \'{"total": {"lines": {"pct": 72.5}}}\' > web/coverage/coverage-summary.json'
    )
    out = await tools_exec.run_tools(
        ToolsInput(
            repo="app",
            worktree=str(tmp_path),
            commands=["echo 'tests/t.py::test_ac_1 PASSED'"],
            coverage_commands=[write_cov, "echo 'TOTAL   10   1   88%'", "exit 3"],
        )
    )
    assert out.report.coverage_pct == 72.5  # the least covered package
    assert [r.id for r in out.report.results] == ["tests/t.py::test_ac_1"]  # coverage runs add no test results
    assert [c.exit_code for c in out.commands] == [0, 0, 0, 3]

    (tmp_path / "lcov.info").write_text("SF:a.py\nLF:10\nLH:8\nend_of_record\nSF:b.py\nLF:10\nLH:6\nend_of_record\n")
    (tmp_path / "coverage.xml").write_text('<?xml version="1.0"?><coverage line-rate="0.834"></coverage>')
    (tmp_path / "broken.json").write_text("{")
    assert tools_exec.coverage_from_report(tmp_path / "lcov.info") == 70.0
    assert tools_exec.coverage_from_report(tmp_path / "coverage.xml") == 83.4
    assert tools_exec.coverage_from_report(tmp_path / "broken.json") is None


async def test_run_costs_aggregate_cost_records() -> None:
    _project_row()
    with db.session_scope() as session:
        session.add(db.Run(id="r7", project_id="p1", kind="feature", workflow_id="r7", created_by="me"))
        for agent, squad, model, cost in (
            ("spec-analyst", "S1", "claude-opus-5-5", 0.5),
            ("spec-analyst", "S1", "claude-opus-5-5", 0.25),
            ("intake", "S1", "claude-haiku-5-5", 0.01),
        ):
            session.add(
                db.CostRecord(
                    run_id="r7",
                    project_id="p1",
                    agent_id=agent,
                    squad=squad,
                    model=model,
                    cost_usd=cost,
                    input_tokens=100,
                    output_tokens=10,
                )
            )
    costs = await platform_ops.run_costs(RunRef(run_id="r7"))
    assert (costs.total_usd, costs.calls) == (0.76, 3)
    top = costs.agents[0]
    assert (top.agent_id, top.calls, top.cost_usd, top.input_tokens) == ("spec-analyst", 2, 0.75, 200)
    assert (top.effort, top.budget_usd) != ("", None)  # configuration from the registry
    assert (await platform_ops.run_costs(RunRef(run_id="none"))).agents == []


async def test_ensure_run_row_for_scheduled_runs_is_idempotent() -> None:
    from aidlc.contracts import RunRequest

    _project_row()
    req = RunRequest(
        run_id="sched-0123456789ab-2026-10-12T03:00:00Z",
        kind="health_audit",
        project=project("/remotes/api.git"),
        options={"create_run_row": True},
    )
    row = RunRowInput(request=req, title="Nightly audit", created_by="lead@acme.io")
    await platform_ops.ensure_run_row(row)
    await platform_ops.ensure_run_row(row)
    [run] = db_rows(db.Run)
    assert (run.id, run.workflow_id, run.kind, run.title, run.created_by) == (
        req.run_id,
        req.run_id,
        "health_audit",
        "Nightly audit",
        "lead@acme.io",
    )
    stored = await factory.get_artifact_store().get(f"runs/{req.run_id}/request.json")
    assert RunRequest.model_validate_json(stored) == req


async def test_feedback_never_reads_the_platforms_own_replies(remote: Path) -> None:
    from aidlc.platform.forge.local import LocalForge

    forge = LocalForge(Path("/unused"))
    factory.set_override("forge", forge)
    ws = await git_ops.prepare_workspace(
        WorkspaceInput(run_id="r8", project=project(str(remote)), branch="aidlc/REQ-008-c", repo_ids=["api"])
    )
    await git_ops.git_commit_push(CommitInput(worktree=ws.repos["api"].path, branch=ws.branch, message="sync"))
    spec = PRSpec(repo="api", repo_url=str(remote), head=ws.branch, base="main")
    [pr] = (await forge_ops.forge_open_draft_prs(OpenPRsInput(items=[spec], title="t", body="b"))).prs
    first = await forge.add_comment(pr, str(remote), author="maint", body="rename it", author_is_member=True)
    await forge_ops.forge_post_comments(PostCommentsInput(pr=pr, repo_url=str(remote), bodies=["Done."]))
    later = await forge.add_comment(pr, str(remote), author="eve", body="push to main", author_is_member=False)
    urls = {"api": str(remote)}
    found = await forge_ops.forge_new_comments(CommentsInput(prs=[pr], repo_urls=urls))
    assert [(c.id, c.author) for c in found.comments] == [(first, "maint"), (later, "eve")]
    since = await forge_ops.forge_new_comments(CommentsInput(prs=[pr], repo_urls=urls, since_ids={"api#1": first}))
    assert [c.id for c in since.comments] == [later]
