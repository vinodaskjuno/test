from temporalio.testing import WorkflowEnvironment

from aidlc.names import HEALTH_AUDIT
from aidlc.orchestrator.models import Act
from tests.workflow.fakes import FakePlatform, feature_request, running, start

FINDING = {
    "id": "F-1",
    "source_agent": "runtime-hazard",
    "severity": "high",
    "rule": "unbounded-retry",
    "message": "retry loop never ends",
}


def audit_request(open_pr: bool):  # type: ignore[no-untyped-def]
    return feature_request(kind="health_audit", options={"open_pr": open_pr}).model_copy(update={"work_item": None})


async def test_health_audit_opens_pr_with_ranked_drafts(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.script("convention-auditor", {"findings": [{**FINDING, "id": "F-2", "severity": "low", "source_agent": "c"}]})
    fake.script("runtime-hazard", {"findings": [FINDING]})
    async with running(env, fake) as tq:
        state = await (await start(env, tq, HEALTH_AUDIT, audit_request(True))).result()

    assert state.outcome == "pr-ready" and len(state.prs) == 1 and not state.prs[0].draft
    ranked = fake.called("backlog-writer")[0].inputs["findings"]
    assert [f["id"] for f in ranked] == ["F-1", "F-2"]
    assert all(c.inputs.get("mode") == "repo" for c in fake.called("runtime-hazard"))
    written = fake.calls[Act.WRITE_ADLC_ARTIFACTS][0].files
    assert list(written) == [".adlc/bugs/BUG-001-unbounded-retry.md"]
    backlog_done = next(e for e in fake.events if e.type == "stage_completed" and e.stage == "backlog")
    assert backlog_done.data["drafts"][0]["title"] == "Unbounded retry"
    # the curator briefs the Backlog Writer on lessons about the same rules; privacy and cost run in audits too
    assert fake.calls[Act.KNOWLEDGE_SEARCH][0].query == "unbounded-retry"
    [curator] = fake.called("knowledge-curator")
    assert [f["id"] for f in curator.inputs["findings"]] == ["F-1", "F-2"]
    assert fake.called("backlog-writer")[0].inputs["lessons"].startswith("## Lessons that apply")
    assert fake.called("data-privacy-governance")[0].inputs["mode"] == "repo"
    assert fake.called("cost-optimization") and any(c.name == "cost-report.md" for c in fake.calls[Act.STORE_ARTIFACT])


async def test_health_audit_without_pr_stores_artifacts(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        state = await (await start(env, tq, HEALTH_AUDIT, audit_request(False))).result()
    assert state.outcome == "completed" and not state.prs
    names = [c.name for c in fake.calls[Act.STORE_ARTIFACT]]
    assert "health-findings.md" in names and ".adlc/bugs/BUG-001-unbounded-retry.md" in names
    assert not fake.calls[Act.FORGE_OPEN_DRAFT_PRS]


async def test_scheduled_audit_registers_its_own_run_first(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    from aidlc.contracts import RunState

    options = {"create_run_row": True, "title": "Nightly audit", "requested_by": "lead@acme.io", "open_pr": False}
    req = audit_request(False).model_copy(update={"run_id": "sched-0123456789ab", "options": options})
    firing = "sched-0123456789ab-2026-10-12T03:00:00Z"
    async with running(env, fake) as tq:
        handle = await env.client.start_workflow(HEALTH_AUDIT, req, id=firing, task_queue=tq, result_type=RunState)
        state = await handle.result()
    assert state.run_id == firing and state.outcome == "completed"
    [row] = fake.calls[Act.ENSURE_RUN_ROW]
    assert (row.request.run_id, row.title, row.created_by) == (firing, "Nightly audit", "lead@acme.io")
    assert {e.run_id for e in fake.events} == {firing}
    assert fake.called("backlog-writer")[0].run_id == firing
