import pytest
from temporalio.testing import WorkflowEnvironment

from aidlc.orchestrator.activities import ALL_ACTIVITIES
from aidlc.orchestrator.models import Act
from aidlc.orchestrator.worker import ALL_WORKFLOWS, build_worker
from aidlc.orchestrator.workflows.runtime import DEV_AGENTS, OPTIONAL_AGENTS, S5_AGENTS, TEST_WRITERS
from aidlc.orchestrator.workflows.squads.health import AUDITORS
from aidlc.orchestrator.workflows.squads.review import REVIEWERS
from aidlc.platform.registry import Registry
from aidlc.settings import ROOT
from tests.workflow.fakes import DEFAULT_OUTPUTS


async def test_production_worker_registers_every_workflow_and_activity(env: WorkflowEnvironment) -> None:
    # Run (not just build) the worker so it validates against the server and shuts down before the server does;
    # a worker left unstarted keeps a core client polling a server that is already gone.
    async with build_worker(env.client) as worker:  # validates every workflow in the sandbox
        assert worker.task_queue == "aidlc-main"
    names = {a.__temporal_activity_definition.name for a in ALL_ACTIVITIES}  # type: ignore[attr-defined]
    assert names == {v for k, v in vars(Act).items() if k.isupper()}
    assert len(ALL_WORKFLOWS) == 7


@pytest.fixture(scope="module")
def registry() -> Registry:
    return Registry(ROOT / "agents")


def test_every_orchestrated_agent_exists(registry: Registry) -> None:
    referenced = {*DEV_AGENTS, *OPTIONAL_AGENTS, *S5_AGENTS, *TEST_WRITERS, *REVIEWERS, *AUDITORS}
    referenced |= set(DEFAULT_OUTPUTS)
    assert sorted(a for a in referenced if a not in registry) == []


@pytest.mark.parametrize("agent_id", sorted(DEFAULT_OUTPUTS))
def test_scripted_outputs_match_real_agent_schemas(registry: Registry, agent_id: str) -> None:
    """The workflow tests' fakes must be outputs the real agents could legally return."""
    registry.get(agent_id).output_model.model_validate(DEFAULT_OUTPUTS[agent_id])
