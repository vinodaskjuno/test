from temporalio.testing import WorkflowEnvironment

from aidlc.names import BUGFIX, SIG_PR_EVENT
from aidlc.orchestrator.models import Act, PREventSignal, ToolsOutput
from tests.workflow.fakes import (
    FakePlatform,
    failing_report,
    feature_request,
    passing_report,
    running,
    start,
    wait_state,
)


async def test_bugfix_reproduces_fixes_and_opens_pr(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    # reproduction run fails (bug reproduced), every later run passes
    fake.queue(Act.RUN_TOOLS, ToolsOutput(report=failing_report()), ToolsOutput(report=passing_report()))
    async with running(env, fake) as tq:
        handle = await start(env, tq, BUGFIX, feature_request(kind="bugfix"))
        ready = await wait_state(handle, lambda s: s.outcome == "pr-ready" and s.stage == "gate_b")
        await handle.signal(SIG_PR_EVENT, PREventSignal(repo="api", number=1, action="merged"))
        state = await handle.result()

    assert state.outcome == "pr-ready" and ready.prs[0].repo == "api"
    assert fake.calls[Act.ALLOCATE_ID][0].prefix == "BUG"
    assert fake.called("spec-analyst")[0].inputs["mode"] == "bug"
    assert fake.called("debugger")[0].inputs["requirement"]["req_id"] == "REQ-001"
    assert fake.called("backend-dev")[0].inputs["fix_ticket"]["id"] == "FIX-1"
    artifacts = fake.calls[Act.WRITE_ADLC_ARTIFACTS][0]
    assert artifacts.kind == "bug" and artifacts.spec_dir == "BUG-001-add-login"
    called = {c.agent_id for c in fake.agent_calls}
    assert {"correctness-reviewer", "security-reviewer", "reflector", "review-judge"} <= called
    assert not {"work-planner", "performance-reviewer", "adversary", "test-strategist", "e2e-ui-test"} & called
    assert fake.called("knowledge-curator") and fake.called("cost-optimization")
    assert fake.called("backend-dev")[0].inputs["lessons"].startswith("## Lessons that apply")
    # bugfix runs never register in the manifest, so they never update or finish an entry there
    assert not fake.calls[Act.MANIFEST_REGISTER]
    assert not fake.calls[Act.MANIFEST_UPDATE] and not fake.calls[Act.MANIFEST_FINISH]


async def test_bugfix_unreproduced_escalates(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    from aidlc.names import SIG_ESCALATION
    from aidlc.orchestrator.models import DecisionSignal

    async with running(env, fake) as tq:
        handle = await start(env, tq, BUGFIX, feature_request(kind="bugfix"))
        state = await wait_state(handle, lambda s: bool(s.escalations))
        assert state.escalations[0].reason == "agent_error"
        await handle.signal(SIG_ESCALATION, DecisionSignal(escalation_id="ESC-1", decision="cancel"))
        final = await handle.result()
    assert final.outcome == "cancelled"
    assert fake.called("unit-test")  # the test writer tried to reproduce after the debugger
