from temporalio.testing import WorkflowEnvironment

from aidlc.names import REPO_ONBOARDING
from aidlc.orchestrator.models import Act, DoctorCheck, DoctorReport
from tests.workflow.fakes import FakePlatform, feature_request, running, start


def onboarding(**options: object):  # type: ignore[no-untyped-def]
    return feature_request(kind="onboarding", options=options).model_copy(update={"work_item": None})


async def test_onboarding_existing_repo(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        state = await (await start(env, tq, REPO_ONBOARDING, onboarding(mode="existing"))).result()
    assert state.outcome == "pr-ready" and state.prs[0].repo == "api"
    docs = fake.called("docs")[0]
    assert docs.allowed_files[0] == ".adlc/context/project-overview.md"
    assert fake.calls[Act.WRITE_ONBOARDING_SCAFFOLD][0].preset == "nextjs-fastapi"
    assert not fake.calls[Act.FORGE_CREATE_REPO] and not fake.calls[Act.REGISTER_REPO]
    assert "## Doctor" in fake.calls[Act.FORGE_OPEN_DRAFT_PRS][0].body


async def test_onboarding_new_repo_is_created_and_protected(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    async with running(env, fake) as tq:
        req = onboarding(mode="new", repo_name="todo-app", preset="generic-python")
        state = await (await start(env, tq, REPO_ONBOARDING, req)).result()
    assert state.outcome == "pr-ready" and state.prs[0].repo == "todo-app"
    assert fake.calls[Act.FORGE_CREATE_REPO][0].preset == "generic-python"
    protect = fake.calls[Act.FORGE_PROTECT_BRANCH][0]
    assert protect.required_checks == ["aidlc/gates"] and protect.branch == "main"
    assert fake.calls[Act.PREPARE_WORKSPACE][0].project.repos[0].url == "https://git.example/todo-app.git"
    [registered] = fake.calls[Act.REGISTER_REPO]
    assert registered.project_id == "p1"
    assert (registered.repo.id, registered.repo.url, registered.repo.primary) == (
        "todo-app",
        "https://git.example/todo-app.git",
        True,
    )


async def test_onboarding_fails_when_doctor_fails(env: WorkflowEnvironment, fake: FakePlatform) -> None:
    fake.queue(Act.ADLC_DOCTOR, DoctorReport(ok=False, checks=[DoctorCheck(name="config", ok=False, detail="bad")]))
    async with running(env, fake) as tq:
        state = await (await start(env, tq, REPO_ONBOARDING, onboarding())).result()
    assert state.outcome == "failed" and "config: bad" in state.summary
    assert not fake.calls[Act.FORGE_OPEN_DRAFT_PRS]
