#!/usr/bin/env bash
# Regenerate aidlc_sdk/models.py from the control-plane OpenAPI document (clients/openapi.json).
# Usage: scripts/generate.sh [path/to/openapi.json]   (needs datamodel-code-generator and ruff on PATH or in ../../.venv)
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
spec="${1:-$here/../openapi.json}"
venv_bin="$here/../../.venv/bin"
codegen="datamodel-codegen"
if [[ -x "$venv_bin/datamodel-codegen" ]]; then
  codegen="$venv_bin/datamodel-codegen"
  export PATH="$venv_bin:$PATH"
fi

"$codegen" \
  --input "$spec" \
  --input-file-type openapi \
  --openapi-scopes schemas \
  --output "$here/src/aidlc_sdk/models.py" \
  --output-model-type pydantic_v2.BaseModel \
  --target-python-version 3.12 \
  --use-standard-collections \
  --use-union-operator \
  --use-annotated \
  --field-constraints \
  --enum-field-as-literal all \
  --extra-fields ignore \
  --use-double-quotes \
  --keep-model-order \
  --disable-timestamp \
  --formatters builtin \
  --custom-file-header '"""Models generated from clients/openapi.json by scripts/generate.sh. Do not edit by hand."""'
# Format with explicit settings so the output does not depend on which ruff config is in scope.
ruff_opts=(--quiet --line-length 120 --target-version py312)
ruff check --fix --select I,UP,F "${ruff_opts[@]}" "$here/src/aidlc_sdk/models.py"
ruff format "${ruff_opts[@]}" "$here/src/aidlc_sdk/models.py"
echo "wrote $here/src/aidlc_sdk/models.py"
