"""Server-sent events: a line decoder (WHATWG rules) and the resume/backoff policy used by both clients."""

from __future__ import annotations

import json
import random
from dataclasses import dataclass, field

from pydantic import BaseModel

from aidlc_sdk.models import RunEventView


@dataclass(frozen=True)
class SseMessage:
    event: str
    data: str
    id: str | None


class StreamEnd(BaseModel):
    """The final item of a run's event stream: the run finished with ``outcome``."""

    outcome: str
    last_event_id: int | None = None


RunStreamItem = RunEventView | StreamEnd


@dataclass
class SseDecoder:
    """Feeds lines (without terminators) and returns a message at each blank line. Comments (pings) are skipped."""

    retry_ms: int | None = None
    _event: str = ""
    _data: list[str] = field(default_factory=list)
    _id: str | None = None

    def feed(self, line: str) -> SseMessage | None:
        if not line:
            if not self._data and not self._event:
                return None
            message = SseMessage(event=self._event or "message", data="\n".join(self._data), id=self._id)
            self._event, self._data, self._id = "", [], None
            return message
        if line.startswith(":"):
            return None
        name, _, value = line.partition(":")
        value = value.removeprefix(" ")
        if name == "data":
            self._data.append(value)
        elif name == "event":
            self._event = value
        elif name == "id" and "\0" not in value:
            self._id = value
        elif name == "retry" and value.isdigit():
            self.retry_ms = int(value)
        return None


@dataclass
class Resume:
    """Tracks the last delivered event id and how long to wait before the next reconnect."""

    last_event_id: int | None = None
    max_failures: int = 8
    initial_backoff_s: float = 0.5
    max_backoff_s: float = 30.0
    failures: int = 0

    def headers(self) -> dict[str, str]:
        headers = {"Accept": "text/event-stream", "Cache-Control": "no-cache"}
        if self.last_event_id is not None:
            headers["Last-Event-ID"] = str(self.last_event_id)
        return headers

    def item(self, message: SseMessage) -> RunStreamItem | None:
        """The typed item for ``message``; advances the resume point and resets the failure count."""
        if message.event == "end":
            end = StreamEnd.model_validate(json.loads(message.data or "{}"))
            return end.model_copy(update={"last_event_id": end.last_event_id or self.last_event_id})
        if message.event != "message" or not message.data:
            return None
        event = RunEventView.model_validate_json(message.data)
        self.last_event_id = event.seq
        self.failures = 0
        return event

    def next_delay(self, retry_ms: int | None = None) -> float | None:
        """Seconds to wait before reconnecting, or ``None`` once ``max_failures`` consecutive attempts failed."""
        self.failures += 1
        if self.failures > self.max_failures:
            return None
        base = retry_ms / 1000 if retry_ms is not None else self.initial_backoff_s
        delay = min(self.max_backoff_s, base * 2 ** (self.failures - 1))
        return delay + random.uniform(0, delay / 10) if delay else 0.0
