"""Thin synchronous and asynchronous clients over the control-plane REST API v1.

Both clients execute the same request builders (``aidlc_sdk._ops``) and return the generated models.
"""

from __future__ import annotations

import time
from collections.abc import AsyncIterator, Iterator, Mapping, Sequence
from typing import Any, Literal, Self

import anyio
import httpx

from aidlc_sdk import _ops as ops
from aidlc_sdk import models as m
from aidlc_sdk._ops import Call, EscalationDecision, InboxStatus, SpecFile
from aidlc_sdk.errors import AidlcError, RateLimited, Unreachable, error_for
from aidlc_sdk.sse import Resume, RunStreamItem, SseDecoder, StreamEnd

__version__ = "0.1.0"
USER_AGENT = f"aidlc-sdk-python/{__version__}"
# The server pings every 15 s; a minute without a byte means the connection is dead and should be resumed.
STREAM_READ_TIMEOUT_S = 60.0


def normalize_base_url(base_url: str) -> str:
    """Accept the server root or the ``/api/v1`` base; the operation paths carry the prefix themselves."""
    url = base_url.strip().rstrip("/")
    return url.removesuffix(ops.API_PREFIX)


def _headers(token: str | None, extra: Mapping[str, str] | None) -> dict[str, str]:
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    headers.update(extra or {})
    return headers


def _stream_timeout(timeout: float) -> httpx.Timeout:
    return httpx.Timeout(timeout, read=STREAM_READ_TIMEOUT_S)


class _Base:
    base_url: str

    def url(self, op: str, **path_params: str) -> str:
        """Absolute URL of an operation, e.g. for links printed to users."""
        return self.base_url + Call(op, ops._nothing, path_params).path


class Client(_Base):
    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        *,
        timeout: float = 30.0,
        headers: Mapping[str, str] | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = normalize_base_url(base_url)
        self.timeout = timeout
        self._http = httpx.Client(
            base_url=self.base_url, headers=_headers(token, headers), timeout=timeout, transport=transport
        )

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    def call[T](self, call: Call[T]) -> T:
        try:
            response = self._http.request(call.method, call.path, **call.request_kwargs())
        except httpx.TransportError as exc:
            raise Unreachable(f"{call.method} {self.base_url}{call.path}: {exc}") from exc
        if response.is_error:
            raise error_for(response)
        return call.parse(response)

    # ---------- server, session and tokens ----------
    def health(self) -> m.Health:
        return self.call(ops.health())

    def config(self) -> m.PublicConfig:
        """Public server settings (upload limits, sign-in method); needs no token."""
        return self.call(ops.get_config())

    def session(self) -> m.SessionView:
        return self.call(ops.get_session())

    def list_tokens(self) -> list[m.TokenView]:
        return self.call(ops.list_tokens())

    def create_token(self, name: str) -> m.TokenCreated:
        return self.call(ops.create_token(name))

    def revoke_token(self, token_id: str) -> None:
        return self.call(ops.revoke_token(token_id))

    # ---------- projects ----------
    def list_projects(self) -> list[m.ProjectView]:
        return self.call(ops.list_projects())

    def get_project(self, project_id: str) -> m.ProjectView:
        return self.call(ops.get_project(project_id))

    def get_doctor(self, project_id: str) -> m.DoctorReport:
        return self.call(ops.get_doctor(project_id))

    def run_doctor(self, project_id: str) -> m.DoctorReport:
        return self.call(ops.run_doctor(project_id))

    def upload_specs(
        self,
        project_id: str,
        files: Sequence[SpecFile],
        *,
        kind: Literal["feature", "bug"] = "feature",
        title: str | None = None,
        repos: Sequence[str] = (),
        figma_url: str | None = None,
        confluence_urls: Sequence[str] = (),
        economy: bool = False,
    ) -> m.SpecUploadResult:
        call = ops.upload_specs(
            project_id,
            files,
            kind=kind,
            title=title,
            repos=repos,
            figma_url=figma_url,
            confluence_urls=confluence_urls,
            economy=economy,
        )
        return self.call(call)

    # ---------- runs ----------
    def list_runs(self, **filters: Any) -> list[m.RunSummary]:
        return self.call(ops.list_runs(**filters))

    def create_run(self, body: m.RunCreate | Mapping[str, Any], idempotency_key: str | None = None) -> m.RunSummary:
        return self.call(ops.create_run(body, idempotency_key))

    def get_run(self, run_id: str) -> m.RunView:
        return self.call(ops.get_run(run_id))

    def cancel_run(self, run_id: str) -> m.RunSummary:
        return self.call(ops.cancel_run(run_id))

    def retry_run(self, run_id: str) -> m.RunSummary:
        return self.call(ops.retry_run(run_id))

    def list_artifacts(self, run_id: str) -> list[m.ArtifactView]:
        return self.call(ops.list_artifacts(run_id))

    def list_spec_templates(self) -> list[m.SpecTemplateView]:
        return self.call(ops.list_spec_templates())

    def get_spec_template(
        self, type_id: str, format: Literal["md", "docx", "confluence"] = "md", example: bool = False
    ) -> bytes:
        return self.call(ops.get_spec_template(type_id, format, example))

    def check_spec(self, markdown: str) -> m.SpecCheck:
        return self.call(ops.check_spec(markdown))

    def get_artifact(self, run_id: str, name: str) -> bytes:
        return self.call(ops.get_artifact(run_id, name))

    def events(
        self,
        run_id: str,
        *,
        last_event_id: int | None = None,
        max_failures: int = 8,
        backoff_s: float = 0.5,
    ) -> Iterator[RunStreamItem]:
        """Yield the run's events, then a ``StreamEnd``. Dropped connections resume from the last event id."""
        resume = Resume(last_event_id=last_event_id, max_failures=max_failures, initial_backoff_s=backoff_s)
        retry_ms: int | None = None
        path = ops.stream_events(run_id).path
        while True:
            decoder = SseDecoder(retry_ms=retry_ms)
            error: AidlcError
            try:
                with self._http.stream(
                    "GET", path, headers=resume.headers(), timeout=_stream_timeout(self.timeout)
                ) as response:
                    if response.is_error:
                        response.read()
                        error = error_for(response)
                        if isinstance(error, RateLimited):
                            time.sleep(error.retry_after)
                            continue
                        if response.status_code < 500:
                            raise error
                    else:
                        for line in response.iter_lines():
                            message = decoder.feed(line)
                            item = resume.item(message) if message else None
                            if item is not None:
                                yield item
                                if isinstance(item, StreamEnd):
                                    return
                        error = Unreachable(f"event stream for run {run_id} closed before the run finished")
            except httpx.TransportError as exc:
                error = Unreachable(f"event stream for run {run_id}: {exc}")
            retry_ms = decoder.retry_ms
            delay = resume.next_delay(retry_ms)
            if delay is None:
                raise error
            time.sleep(delay)

    # ---------- inbox, previews, knowledge, agents ----------
    def list_inbox(self, project_id: str | None = None, status: InboxStatus = "open") -> list[m.InboxItemView]:
        return self.call(ops.list_inbox(project_id, status))

    def get_inbox_item(self, item_id: str) -> m.InboxItemView:
        return self.call(ops.get_inbox_item(item_id))

    def answer(self, item_id: str, answer: str) -> m.InboxItemView:
        return self.call(ops.answer(item_id, answer))

    def decide(self, item_id: str, decision: EscalationDecision, note: str = "") -> m.InboxItemView:
        return self.call(ops.decide(item_id, decision, note))

    def list_previews(self, run_id: str | None = None, project_id: str | None = None) -> list[m.PreviewView]:
        return self.call(ops.list_previews(run_id, project_id))

    def search_knowledge(
        self, project_id: str, q: str = "", kind: str | None = None, limit: int | None = None
    ) -> list[m.KnowledgeView]:
        return self.call(ops.search_knowledge(project_id, q, kind, limit))

    def list_agents(self) -> list[m.AgentSummary]:
        return self.call(ops.list_agents())

    def get_agent(self, agent_id: str) -> m.AgentDetail:
        return self.call(ops.get_agent(agent_id))

    def record_agent_eval(
        self, agent_id: str, version: str, score: float, report: Mapping[str, Any] | None = None
    ) -> m.AgentDetail:
        return self.call(ops.record_agent_eval(agent_id, version, score, report))

    def promote_agent(self, agent_id: str, version: str) -> m.AgentDetail:
        return self.call(ops.promote_agent(agent_id, version))

    def rollback_agent(self, agent_id: str) -> m.AgentDetail:
        return self.call(ops.rollback_agent(agent_id))

    def verify_branch(self, project_id: str, repo: str, branch: str) -> m.RunSummary:
        return self.call(ops.verify_branch(project_id, repo, branch))


class AsyncClient(_Base):
    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        *,
        timeout: float = 30.0,
        headers: Mapping[str, str] | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = normalize_base_url(base_url)
        self.timeout = timeout
        self._http = httpx.AsyncClient(
            base_url=self.base_url, headers=_headers(token, headers), timeout=timeout, transport=transport
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._http.aclose()

    async def call[T](self, call: Call[T]) -> T:
        try:
            response = await self._http.request(call.method, call.path, **call.request_kwargs())
        except httpx.TransportError as exc:
            raise Unreachable(f"{call.method} {self.base_url}{call.path}: {exc}") from exc
        if response.is_error:
            raise error_for(response)
        return call.parse(response)

    # ---------- server, session and tokens ----------
    async def health(self) -> m.Health:
        return await self.call(ops.health())

    async def config(self) -> m.PublicConfig:
        """Public server settings (upload limits, sign-in method); needs no token."""
        return await self.call(ops.get_config())

    async def session(self) -> m.SessionView:
        return await self.call(ops.get_session())

    async def list_tokens(self) -> list[m.TokenView]:
        return await self.call(ops.list_tokens())

    async def create_token(self, name: str) -> m.TokenCreated:
        return await self.call(ops.create_token(name))

    async def revoke_token(self, token_id: str) -> None:
        return await self.call(ops.revoke_token(token_id))

    # ---------- projects ----------
    async def list_projects(self) -> list[m.ProjectView]:
        return await self.call(ops.list_projects())

    async def get_project(self, project_id: str) -> m.ProjectView:
        return await self.call(ops.get_project(project_id))

    async def get_doctor(self, project_id: str) -> m.DoctorReport:
        return await self.call(ops.get_doctor(project_id))

    async def run_doctor(self, project_id: str) -> m.DoctorReport:
        return await self.call(ops.run_doctor(project_id))

    async def upload_specs(
        self,
        project_id: str,
        files: Sequence[SpecFile],
        *,
        kind: Literal["feature", "bug"] = "feature",
        title: str | None = None,
        repos: Sequence[str] = (),
        figma_url: str | None = None,
        confluence_urls: Sequence[str] = (),
        economy: bool = False,
    ) -> m.SpecUploadResult:
        call = ops.upload_specs(
            project_id,
            files,
            kind=kind,
            title=title,
            repos=repos,
            figma_url=figma_url,
            confluence_urls=confluence_urls,
            economy=economy,
        )
        return await self.call(call)

    # ---------- runs ----------
    async def list_runs(self, **filters: Any) -> list[m.RunSummary]:
        return await self.call(ops.list_runs(**filters))

    async def create_run(
        self, body: m.RunCreate | Mapping[str, Any], idempotency_key: str | None = None
    ) -> m.RunSummary:
        return await self.call(ops.create_run(body, idempotency_key))

    async def get_run(self, run_id: str) -> m.RunView:
        return await self.call(ops.get_run(run_id))

    async def cancel_run(self, run_id: str) -> m.RunSummary:
        return await self.call(ops.cancel_run(run_id))

    async def retry_run(self, run_id: str) -> m.RunSummary:
        return await self.call(ops.retry_run(run_id))

    async def list_artifacts(self, run_id: str) -> list[m.ArtifactView]:
        return await self.call(ops.list_artifacts(run_id))

    async def list_spec_templates(self) -> list[m.SpecTemplateView]:
        return await self.call(ops.list_spec_templates())

    async def get_spec_template(
        self, type_id: str, format: Literal["md", "docx", "confluence"] = "md", example: bool = False
    ) -> bytes:
        return await self.call(ops.get_spec_template(type_id, format, example))

    async def check_spec(self, markdown: str) -> m.SpecCheck:
        return await self.call(ops.check_spec(markdown))

    async def get_artifact(self, run_id: str, name: str) -> bytes:
        return await self.call(ops.get_artifact(run_id, name))

    async def events(
        self,
        run_id: str,
        *,
        last_event_id: int | None = None,
        max_failures: int = 8,
        backoff_s: float = 0.5,
    ) -> AsyncIterator[RunStreamItem]:
        """Yield the run's events, then a ``StreamEnd``. Dropped connections resume from the last event id."""
        resume = Resume(last_event_id=last_event_id, max_failures=max_failures, initial_backoff_s=backoff_s)
        retry_ms: int | None = None
        path = ops.stream_events(run_id).path
        while True:
            decoder = SseDecoder(retry_ms=retry_ms)
            error: AidlcError
            try:
                async with self._http.stream(
                    "GET", path, headers=resume.headers(), timeout=_stream_timeout(self.timeout)
                ) as response:
                    if response.is_error:
                        await response.aread()
                        error = error_for(response)
                        if isinstance(error, RateLimited):
                            await anyio.sleep(error.retry_after)
                            continue
                        if response.status_code < 500:
                            raise error
                    else:
                        async for line in response.aiter_lines():
                            message = decoder.feed(line)
                            item = resume.item(message) if message else None
                            if item is not None:
                                yield item
                                if isinstance(item, StreamEnd):
                                    return
                        error = Unreachable(f"event stream for run {run_id} closed before the run finished")
            except httpx.TransportError as exc:
                error = Unreachable(f"event stream for run {run_id}: {exc}")
            retry_ms = decoder.retry_ms
            delay = resume.next_delay(retry_ms)
            if delay is None:
                raise error
            await anyio.sleep(delay)

    # ---------- inbox, previews, knowledge, agents ----------
    async def list_inbox(self, project_id: str | None = None, status: InboxStatus = "open") -> list[m.InboxItemView]:
        return await self.call(ops.list_inbox(project_id, status))

    async def get_inbox_item(self, item_id: str) -> m.InboxItemView:
        return await self.call(ops.get_inbox_item(item_id))

    async def answer(self, item_id: str, answer: str) -> m.InboxItemView:
        return await self.call(ops.answer(item_id, answer))

    async def decide(self, item_id: str, decision: EscalationDecision, note: str = "") -> m.InboxItemView:
        return await self.call(ops.decide(item_id, decision, note))

    async def list_previews(self, run_id: str | None = None, project_id: str | None = None) -> list[m.PreviewView]:
        return await self.call(ops.list_previews(run_id, project_id))

    async def search_knowledge(
        self, project_id: str, q: str = "", kind: str | None = None, limit: int | None = None
    ) -> list[m.KnowledgeView]:
        return await self.call(ops.search_knowledge(project_id, q, kind, limit))

    async def list_agents(self) -> list[m.AgentSummary]:
        return await self.call(ops.list_agents())

    async def get_agent(self, agent_id: str) -> m.AgentDetail:
        return await self.call(ops.get_agent(agent_id))

    async def record_agent_eval(
        self, agent_id: str, version: str, score: float, report: Mapping[str, Any] | None = None
    ) -> m.AgentDetail:
        return await self.call(ops.record_agent_eval(agent_id, version, score, report))

    async def promote_agent(self, agent_id: str, version: str) -> m.AgentDetail:
        return await self.call(ops.promote_agent(agent_id, version))

    async def rollback_agent(self, agent_id: str) -> m.AgentDetail:
        return await self.call(ops.rollback_agent(agent_id))

    async def verify_branch(self, project_id: str, repo: str, branch: str) -> m.RunSummary:
        return await self.call(ops.verify_branch(project_id, repo, branch))
