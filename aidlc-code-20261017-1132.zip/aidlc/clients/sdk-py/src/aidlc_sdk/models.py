"""Models generated from clients/openapi.json by scripts/generate.sh. Do not edit by hand."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, RootModel


class AgentDetail(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    number: Annotated[int, Field(title="Number")]
    name: Annotated[str, Field(title="Name")]
    squad: Annotated[str, Field(title="Squad")]
    squad_name: Annotated[str, Field(title="Squad Name")]
    version: Annotated[str, Field(title="Version")]
    model: Annotated[
        Literal["claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"],
        Field(title="Model"),
    ]
    effort: Annotated[str, Field(title="Effort")]
    description: Annotated[str, Field(title="Description")]
    tools: Annotated[list[str], Field(title="Tools")]
    mcp_servers: Annotated[list[str], Field(title="Mcp Servers")]
    reads_untrusted: Annotated[bool, Field(title="Reads Untrusted")]
    workflows: Annotated[list[str], Field(title="Workflows")]
    promoted_version: Annotated[str | None, Field(title="Promoted Version")]
    promoted_score: Annotated[
        float | None,
        Field(description="Eval score of the promoted version", title="Promoted Score"),
    ]
    latest_eval_version: Annotated[
        str | None,
        Field(description="Most recently evaluated version", title="Latest Eval Version"),
    ]
    latest_eval_score: Annotated[float | None, Field(title="Latest Eval Score")]
    promotable: Annotated[
        bool,
        Field(
            description="The latest evaluated version meets the promotion threshold",
            title="Promotable",
        ),
    ]
    prompt: Annotated[str, Field(title="Prompt")]
    max_turns: Annotated[int, Field(title="Max Turns")]
    budget_usd: Annotated[float, Field(title="Budget Usd")]
    timeout_s: Annotated[int, Field(title="Timeout S")]
    output_schema: Annotated[dict[str, Any], Field(title="Output Schema")]
    versions: Annotated[list[AgentVersionView], Field(title="Versions")]
    promotion_min_score: Annotated[float, Field(title="Promotion Min Score")]


class AgentEvalCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    version: Annotated[str, Field(pattern="^\\d+\\.\\d+\\.\\d+$", title="Version")]
    score: Annotated[float, Field(ge=0.0, le=1.0, title="Score")]
    report: Annotated[
        dict[str, Any] | None,
        Field(description="Per-case scores and check details", title="Report"),
    ] = None


class AgentSummary(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    number: Annotated[int, Field(title="Number")]
    name: Annotated[str, Field(title="Name")]
    squad: Annotated[str, Field(title="Squad")]
    squad_name: Annotated[str, Field(title="Squad Name")]
    version: Annotated[str, Field(title="Version")]
    model: Annotated[
        Literal["claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"],
        Field(title="Model"),
    ]
    effort: Annotated[str, Field(title="Effort")]
    description: Annotated[str, Field(title="Description")]
    tools: Annotated[list[str], Field(title="Tools")]
    mcp_servers: Annotated[list[str], Field(title="Mcp Servers")]
    reads_untrusted: Annotated[bool, Field(title="Reads Untrusted")]
    workflows: Annotated[list[str], Field(title="Workflows")]
    promoted_version: Annotated[str | None, Field(title="Promoted Version")]
    promoted_score: Annotated[
        float | None,
        Field(description="Eval score of the promoted version", title="Promoted Score"),
    ]
    latest_eval_version: Annotated[
        str | None,
        Field(description="Most recently evaluated version", title="Latest Eval Version"),
    ]
    latest_eval_score: Annotated[float | None, Field(title="Latest Eval Score")]
    promotable: Annotated[
        bool,
        Field(
            description="The latest evaluated version meets the promotion threshold",
            title="Promotable",
        ),
    ]


class AgentVersionView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    version: Annotated[str, Field(title="Version")]
    status: Annotated[Literal["candidate", "promoted", "retired"], Field(title="Status")]
    eval_score: Annotated[float | None, Field(title="Eval Score")]
    eval_report: Annotated[dict[str, Any], Field(title="Eval Report")]
    updated_at: Annotated[AwareDatetime, Field(title="Updated At")]


class AnswerRequest(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    answer: Annotated[str, Field(max_length=20000, min_length=1, title="Answer")]


class ApiToken(RootModel[str]):
    root: Annotated[
        str,
        Field(description="Secret; returned masked", max_length=500, title="Api Token"),
    ]


class ArtifactView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    name: Annotated[str, Field(title="Name")]
    key: Annotated[str, Field(title="Key")]


class AuditCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    repos: Annotated[list[str] | None, Field(title="Repos")] = None
    open_pr: Annotated[bool | None, Field(title="Open Pr")] = True


class AuditScheduleCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    cron: Annotated[
        str,
        Field(
            description="Five-field cron expression, e.g. '0 3 * * 1'",
            max_length=120,
            min_length=9,
            title="Cron",
        ),
    ]
    timezone: Annotated[
        str | None,
        Field(
            description="IANA time zone the cron is evaluated in",
            max_length=64,
            title="Timezone",
        ),
    ] = "UTC"
    repos: Annotated[list[str] | None, Field(title="Repos")] = None
    open_pr: Annotated[bool | None, Field(title="Open Pr")] = True


class AuditScheduleView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    cron: Annotated[str, Field(title="Cron")]
    timezone: Annotated[str, Field(title="Timezone")]
    repos: Annotated[list[str], Field(title="Repos")]
    open_pr: Annotated[bool, Field(title="Open Pr")]
    created_by: Annotated[str, Field(title="Created By")]
    paused: Annotated[bool, Field(title="Paused")]
    next_run_at: Annotated[AwareDatetime | None, Field(title="Next Run At")]
    recent_run_ids: Annotated[list[str], Field(title="Recent Run Ids")]


class AuditView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run: RunSummary
    findings: Annotated[list[Finding], Field(title="Findings")]


class BacklogItem(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    run_id: Annotated[str, Field(title="Run Id")]
    kind: Annotated[Literal["REQ", "BUG"], Field(title="Kind")]
    title: Annotated[str, Field(title="Title")]
    markdown: Annotated[str, Field(title="Markdown")]
    source_findings: Annotated[list[str], Field(title="Source Findings")]
    promoted_run_id: Annotated[str | None, Field(title="Promoted Run Id")]


class BaseUrl(RootModel[str]):
    root: Annotated[
        str,
        Field(max_length=300, pattern="^https?://[^\\s/]+(/\\S*)?$", title="Base Url"),
    ]


class BodyUploadSpecs(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    files: Annotated[
        list[str] | None,
        Field(description="Spec documents and attachments", title="Files"),
    ] = None
    kind: Annotated[Literal["feature", "bug"] | None, Field(title="Kind")] = "feature"
    title: Annotated[Title | None, Field(title="Title")] = None
    repos: Annotated[list[str] | None, Field(title="Repos")] = None
    figma_url: Annotated[FigmaUrl | None, Field(title="Figma Url")] = None
    confluence_urls: Annotated[
        list[str] | None,
        Field(
            description="Confluence page links, fetched with the project's Confluence integration",
            title="Confluence Urls",
        ),
    ] = None
    economy: Annotated[
        bool | None,
        Field(
            description="Economy mode for this run: cap every agent's thinking effort and turns",
            title="Economy",
        ),
    ] = False


class Budgets(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run_usd: Annotated[float | None, Field(title="Run Usd")] = 50.0
    agent_usd_default: Annotated[float | None, Field(title="Agent Usd Default")] = 3.0


class ConflictResolution(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    repo: Annotated[str, Field(title="Repo")]
    file: Annotated[str, Field(title="File")]
    kind: Annotated[Literal["append_point"], Field(title="Kind")] = "append_point"
    resolved_by: Annotated[str, Field(title="Resolved By")]
    at: Annotated[AwareDatetime | None, Field(title="At")] = None


class ConfluenceIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    base_url: Annotated[BaseUrl | None, Field(title="Base Url")] = None
    user: Annotated[User | None, Field(title="User")] = None
    api_token: Annotated[ApiToken | None, Field(description="Secret; returned masked", title="Api Token")] = None


class ConfluenceUrl(RootModel[str]):
    root: Annotated[str, Field(max_length=1000, pattern="^https://\\S+$")]


class CostGroup(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    key: Annotated[str, Field(title="Key")]
    cost_usd: Annotated[float, Field(title="Cost Usd")]
    input_tokens: Annotated[int, Field(title="Input Tokens")]
    output_tokens: Annotated[int, Field(title="Output Tokens")]
    runs: Annotated[int, Field(title="Runs")]


class CostView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    group_by: Annotated[Literal["agent", "squad", "project", "team"], Field(title="Group By")]
    total_usd: Annotated[float, Field(title="Total Usd")]
    groups: Annotated[list[CostGroup], Field(title="Groups")]


class DecideRequest(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    decision: Annotated[Literal["retry", "edit_spec", "takeover", "cancel"], Field(title="Decision")]
    note: Annotated[str | None, Field(max_length=200000, title="Note")] = ""


class DoctorCheck(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    name: Annotated[str, Field(title="Name")]
    status: Annotated[Literal["ok", "warn", "fail", "unknown"], Field(title="Status")]
    detail: Annotated[str | None, Field(title="Detail")] = ""


class DoctorReport(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    checks: Annotated[list[DoctorCheck] | None, Field(title="Checks")] = None
    checked_at: Annotated[AwareDatetime | None, Field(title="Checked At")] = None


class EmailIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    recipients: Annotated[list[Recipient] | None, Field(max_length=100, title="Recipients")] = None


class Escalation(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    reason: Annotated[
        Literal[
            "loop_cap",
            "repeated_signature",
            "budget",
            "v1_exhausted",
            "v2_exhausted",
            "conflict",
            "ci_failing",
            "feedback_cap",
            "agent_error",
        ],
        Field(title="Reason"),
    ]
    detail: Annotated[str, Field(title="Detail")]
    options: Annotated[
        list[Literal["retry", "edit_spec", "takeover", "cancel"]] | None,
        Field(title="Options"),
    ] = None
    decision: Annotated[str | None, Field(title="Decision")] = None
    diagnosis: Annotated[str | None, Field(title="Diagnosis")] = ""


class FigmaIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    mcp_url: Annotated[McpUrl | None, Field(title="Mcp Url")] = None
    token: Annotated[Token | None, Field(description="Secret; returned masked", title="Token")] = None


class FigmaUrl(RootModel[str]):
    root: Annotated[
        str,
        Field(pattern="^https://([a-z0-9-]+\\.)*figma\\.com/\\S+$", title="Figma Url"),
    ]


class Finding(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    source_agent: Annotated[str, Field(title="Source Agent")]
    severity: Annotated[Literal["critical", "high", "medium", "low", "info"], Field(title="Severity")]
    rule: Annotated[str, Field(title="Rule")]
    message: Annotated[str, Field(title="Message")]
    file: Annotated[str | None, Field(title="File")] = None
    line: Annotated[int | None, Field(title="Line")] = None
    repo: Annotated[str | None, Field(title="Repo")] = None
    evidence: Annotated[str | None, Field(title="Evidence")] = ""
    blocking: Annotated[bool | None, Field(title="Blocking")] = False


class GateEventView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run_id: Annotated[str, Field(title="Run Id")]
    gate: Annotated[
        Literal["V1", "V2", "A", "B", "quality", "trial_merge_early", "trial_merge_final"] | str,
        Field(title="Gate"),
    ]
    passed: Annotated[bool, Field(title="Passed")]
    attempt: Annotated[int, Field(title="Attempt")]
    issues: Annotated[list[str], Field(title="Issues")]
    at: Annotated[AwareDatetime, Field(title="At")]


class GateResult(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    gate: Annotated[
        Literal["V1", "V2", "A", "B", "quality", "trial_merge_early", "trial_merge_final"],
        Field(title="Gate"),
    ]
    passed: Annotated[bool, Field(title="Passed")]
    attempt: Annotated[int | None, Field(title="Attempt")] = 1
    issues: Annotated[list[str] | None, Field(title="Issues")] = None


class GateStat(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    gate: Annotated[str, Field(title="Gate")]
    total: Annotated[int, Field(title="Total")]
    passed: Annotated[int, Field(title="Passed")]
    failed: Annotated[int, Field(title="Failed")]
    pass_rate: Annotated[float, Field(title="Pass Rate")]
    mean_attempts: Annotated[float, Field(title="Mean Attempts")]


class GatesView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    config: Annotated[dict[str, Any], Field(title="Config")]
    summary: Annotated[list[GateStat], Field(title="Summary")]
    recent: Annotated[list[GateEventView], Field(title="Recent")]


class GithubIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )


class HTTPValidationError(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    detail: Annotated[list[ValidationError] | None, Field(title="Detail")] = None


class Health(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    status: Annotated[Literal["ok"], Field(title="Status")] = "ok"


class HookResult(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    accepted: Annotated[bool, Field(title="Accepted")]
    detail: Annotated[str | None, Field(title="Detail")] = ""
    run_id: Annotated[str | None, Field(title="Run Id")] = None
    run_ids: Annotated[
        list[str] | None,
        Field(
            description="Every run started (a push may add several specs)",
            title="Run Ids",
        ),
    ] = None


class Id(RootModel[str]):
    root: Annotated[str, Field(pattern="^[a-z0-9][a-z0-9-]{1,62}$", title="Id")]


class InboxItemView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    run_id: Annotated[str, Field(title="Run Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    kind: Annotated[Literal["question", "gate_b", "escalation"], Field(title="Kind")]
    ref_id: Annotated[str, Field(title="Ref Id")]
    title: Annotated[str, Field(title="Title")]
    payload: Annotated[dict[str, Any], Field(title="Payload")]
    status: Annotated[Literal["open", "resolved"], Field(title="Status")]
    resolution: Annotated[dict[str, Any], Field(title="Resolution")]
    created_at: Annotated[AwareDatetime, Field(title="Created At")]
    resolved_at: Annotated[AwareDatetime | None, Field(title="Resolved At")]


class IntegrationBranch(RootModel[str]):
    root: Annotated[str, Field(pattern="^[A-Za-z0-9._/-]{1,200}$", title="Integration Branch")]


class Integrations(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    github: GithubIntegration | None = None
    jira: JiraIntegration | None = None
    confluence: ConfluenceIntegration | None = None
    figma: FigmaIntegration | None = None
    jenkins: JenkinsIntegration | None = None
    slack: SlackIntegration | None = None
    teams: TeamsIntegration | None = None
    email: EmailIntegration | None = None


class IntegrationsView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    integrations: Integrations


class JenkinsIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    base_url: Annotated[BaseUrl | None, Field(title="Base Url")] = None
    user: Annotated[User | None, Field(title="User")] = None
    api_token: Annotated[ApiToken | None, Field(description="Secret; returned masked", title="Api Token")] = None
    job_path: Annotated[
        JobPath | None,
        Field(
            description="Job path template with {repo} and {branch}, e.g. job/{repo}/job/{branch}",
            title="Job Path",
        ),
    ] = None


class JiraIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    base_url: Annotated[BaseUrl | None, Field(title="Base Url")] = None
    user: Annotated[User | None, Field(title="User")] = None
    api_token: Annotated[ApiToken | None, Field(description="Secret; returned masked", title="Api Token")] = None
    project_key: Annotated[ProjectKey | None, Field(title="Project Key")] = None


class JobPath(RootModel[str]):
    root: Annotated[
        str,
        Field(
            description="Job path template with {repo} and {branch}, e.g. job/{repo}/job/{branch}",
            max_length=300,
            title="Job Path",
        ),
    ]


class KnowledgeView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    kind: Annotated[str, Field(title="Kind")]
    title: Annotated[str, Field(title="Title")]
    body: Annotated[str, Field(title="Body")]
    tags: Annotated[list[str], Field(title="Tags")]
    path: Annotated[str | None, Field(title="Path")]
    updated_at: Annotated[AwareDatetime | None, Field(title="Updated At")]


class ManifestView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run_id: Annotated[str, Field(title="Run Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    work_item_id: Annotated[str, Field(title="Work Item Id")]
    branch: Annotated[str, Field(title="Branch")]
    repos: Annotated[list[str], Field(title="Repos")]
    files: Annotated[list[str], Field(title="Files")]
    components: Annotated[list[str], Field(title="Components")]
    rank: Annotated[int, Field(title="Rank")]
    status: Annotated[str, Field(title="Status")]
    started_at: Annotated[AwareDatetime, Field(title="Started At")]


class McpUrl(RootModel[str]):
    root: Annotated[
        str,
        Field(max_length=300, pattern="^https?://[^\\s/]+(/\\S*)?$", title="Mcp Url"),
    ]


class MembersUpdate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    members: Annotated[list[TeamMemberView], Field(title="Members")]


class Name(RootModel[str]):
    root: Annotated[str, Field(max_length=200, min_length=1, title="Name")]


class NotificationPrefs(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    channels: Annotated[
        list[Literal["email", "slack", "teams", "in_app"]] | None,
        Field(title="Channels"),
    ] = None
    events: Annotated[
        list[Literal["gate_waiting", "pr_ready", "failed", "escalation", "ci_failing", "audit_finished"]] | None,
        Field(title="Events"),
    ] = None
    muted_projects: Annotated[list[str] | None, Field(max_length=500, title="Muted Projects")] = None


class OidcInfo(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    issuer: Annotated[str, Field(title="Issuer")]
    client_id: Annotated[
        str | None,
        Field(
            description="Public client id the API accepts tokens for (its audience)",
            title="Client Id",
        ),
    ]


class OnboardRequest(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    mode: Annotated[Literal["existing", "new"], Field(title="Mode")]
    repo_url: Annotated[RepoUrl | None, Field(title="Repo Url")] = None
    repo_id: Annotated[RepoId | None, Field(title="Repo Id")] = None
    integration_branch: Annotated[IntegrationBranch | None, Field(title="Integration Branch")] = None
    repo_name: Annotated[RepoName | None, Field(title="Repo Name")] = None
    preset: Annotated[str | None, Field(title="Preset")] = "nextjs-fastapi"


class PRRef(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    repo: Annotated[str, Field(title="Repo")]
    number: Annotated[int, Field(title="Number")]
    url: Annotated[str, Field(title="Url")]
    draft: Annotated[bool | None, Field(title="Draft")] = True
    state: Annotated[Literal["open", "merged", "closed"] | None, Field(title="State")] = "open"


class Preferences(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    theme: Annotated[Literal["system", "light", "dark"] | None, Field(title="Theme")] = "system"
    notifications: NotificationPrefs | None = None


class PreviewView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    run_id: Annotated[str | None, Field(title="Run Id")]
    repo: Annotated[str, Field(title="Repo")]
    pr_number: Annotated[int, Field(title="Pr Number")]
    url: Annotated[str, Field(title="Url")]
    status: Annotated[Literal["up", "down"], Field(title="Status")]
    expires_at: Annotated[AwareDatetime | None, Field(title="Expires At")]


class ProjectConfig(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    name: Annotated[str, Field(title="Name")]
    stack_preset: Annotated[str | None, Field(title="Stack Preset")] = "nextjs-fastapi"
    repos: Annotated[list[RepoRef], Field(title="Repos")]
    merge_order: Annotated[list[str] | None, Field(title="Merge Order")] = None
    budgets: Budgets | None = None
    agent_pins: Annotated[dict[str, str] | None, Field(title="Agent Pins")] = None
    preview_ttl_hours: Annotated[int | None, Field(title="Preview Ttl Hours")] = 72


class ProjectCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    name: Annotated[str, Field(max_length=200, min_length=1, title="Name")]
    team_id: Annotated[str, Field(title="Team Id")]
    id: Annotated[Id | None, Field(title="Id")] = None
    config: Annotated[
        dict[str, Any] | None,
        Field(description="ProjectConfig fields except project_id/name", title="Config"),
    ] = None
    gates: Annotated[dict[str, Any] | None, Field(title="Gates")] = None
    notification_channels: Annotated[dict[str, Any] | None, Field(title="Notification Channels")] = None


class ProjectKey(RootModel[str]):
    root: Annotated[str, Field(pattern="^[A-Z][A-Z0-9_]{0,19}$", title="Project Key")]


class ProjectPatch(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    name: Annotated[Name | None, Field(title="Name")] = None
    config: Annotated[dict[str, Any] | None, Field(title="Config")] = None
    gates: Annotated[dict[str, Any] | None, Field(title="Gates")] = None
    notification_channels: Annotated[dict[str, Any] | None, Field(title="Notification Channels")] = None


class ProjectView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    name: Annotated[str, Field(title="Name")]
    team_id: Annotated[str, Field(title="Team Id")]
    config: ProjectConfig
    gates: Annotated[dict[str, Any], Field(title="Gates")]
    notification_channels: Annotated[dict[str, Any], Field(title="Notification Channels")]
    created_at: Annotated[AwareDatetime, Field(title="Created At")]
    role: Annotated[
        Literal["admin", "maintainer", "contributor", "viewer"] | None,
        Field(title="Role"),
    ]


class PromoteRequest(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    version: Annotated[str, Field(pattern="^\\d+\\.\\d+\\.\\d+$", title="Version")]


class PublicConfig(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    upload_max_bytes: Annotated[int, Field(title="Upload Max Bytes")]
    allowed_extensions: Annotated[list[str], Field(title="Allowed Extensions")]
    auth_mode: Annotated[Literal["dev", "oidc"], Field(title="Auth Mode")]
    oidc: OidcInfo | None
    version: Annotated[str, Field(title="Version")]


class Question(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    text: Annotated[str, Field(title="Text")]
    options: Annotated[list[str] | None, Field(title="Options")] = None
    answer: Annotated[str | None, Field(title="Answer")] = None
    answered_by: Annotated[str | None, Field(title="Answered By")] = None


class Recipient(RootModel[str]):
    root: Annotated[str, Field(max_length=254, pattern="^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")]


class RepoId(RootModel[str]):
    root: Annotated[str, Field(pattern="^[a-z0-9][a-z0-9-]{0,62}$", title="Repo Id")]


class RepoName(RootModel[str]):
    root: Annotated[str, Field(pattern="^[A-Za-z0-9._-]{1,100}$", title="Repo Name")]


class RepoRef(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    url: Annotated[str | None, Field(title="Url")] = None
    path: Annotated[str | None, Field(title="Path")] = None
    primary: Annotated[bool | None, Field(title="Primary")] = False
    integration_branch: Annotated[str | None, Field(title="Integration Branch")] = None


class RepoUrl(RootModel[str]):
    root: Annotated[
        str,
        Field(max_length=500, pattern="^(https://|git@|file://|/)\\S+$", title="Repo Url"),
    ]


class RunCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    kind: Annotated[
        Literal["feature", "bugfix", "sprint", "health_audit", "onboarding", "preview", "verify_branch"],
        Field(title="Kind"),
    ]
    title: Annotated[str | None, Field(max_length=300, title="Title")] = ""
    sources: Annotated[list[SourceDoc] | None, Field(title="Sources")] = None
    confluence_urls: Annotated[
        list[ConfluenceUrl] | None,
        Field(
            description="Confluence pages fetched with the project's Confluence integration and added as sources",
            max_length=20,
            title="Confluence Urls",
        ),
    ] = None
    repo_hints: Annotated[list[str] | None, Field(title="Repo Hints")] = None
    options: Annotated[dict[str, Any] | None, Field(title="Options")] = None


class RunEventView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    seq: Annotated[int, Field(title="Seq")]
    run_id: Annotated[str, Field(title="Run Id")]
    type: Annotated[
        Literal[
            "run_started",
            "stage_started",
            "stage_completed",
            "agent_started",
            "agent_completed",
            "gate",
            "question",
            "answer",
            "escalation",
            "decision",
            "pr",
            "preview",
            "conflict_resolved",
            "lesson",
            "log",
            "outcome",
        ],
        Field(title="Type"),
    ]
    stage: Annotated[str | None, Field(title="Stage")]
    agent_id: Annotated[str | None, Field(title="Agent Id")]
    message: Annotated[str, Field(title="Message")]
    data: Annotated[dict[str, Any], Field(title="Data")]
    at: Annotated[AwareDatetime, Field(title="At")]


class RunState(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run_id: Annotated[str, Field(title="Run Id")]
    kind: Annotated[
        Literal["feature", "bugfix", "sprint", "health_audit", "onboarding", "preview", "verify_branch"],
        Field(title="Kind"),
    ]
    stage: Annotated[str | None, Field(title="Stage")] = "queued"
    outcome: Annotated[
        Literal["pr-ready", "completed", "blocked", "failed", "cancelled"] | None,
        Field(title="Outcome"),
    ] = None
    iteration: Annotated[int | None, Field(title="Iteration")] = 0
    gates: Annotated[list[GateResult] | None, Field(title="Gates")] = None
    prs: Annotated[list[PRRef] | None, Field(title="Prs")] = None
    conflicts_resolved: Annotated[list[ConflictResolution] | None, Field(title="Conflicts Resolved")] = None
    questions: Annotated[list[Question] | None, Field(title="Questions")] = None
    escalations: Annotated[list[Escalation] | None, Field(title="Escalations")] = None
    cost_usd: Annotated[float | None, Field(title="Cost Usd")] = 0.0
    preview_url: Annotated[str | None, Field(title="Preview Url")] = None
    summary: Annotated[str | None, Field(title="Summary")] = ""


class RunSummary(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    kind: Annotated[
        Literal["feature", "bugfix", "sprint", "health_audit", "onboarding", "preview", "verify_branch"],
        Field(title="Kind"),
    ]
    work_item_id: Annotated[str | None, Field(title="Work Item Id")]
    title: Annotated[str, Field(title="Title")]
    stage: Annotated[str, Field(title="Stage")]
    outcome: Annotated[
        Literal["pr-ready", "completed", "blocked", "failed", "cancelled"] | None,
        Field(title="Outcome"),
    ]
    iteration: Annotated[int, Field(title="Iteration")]
    cost_usd: Annotated[float, Field(title="Cost Usd")]
    created_by: Annotated[str, Field(title="Created By")]
    parent_run_id: Annotated[str | None, Field(title="Parent Run Id")]
    workflow_id: Annotated[str, Field(title="Workflow Id")]
    created_at: Annotated[AwareDatetime, Field(title="Created At")]
    updated_at: Annotated[AwareDatetime, Field(title="Updated At")]


class RunView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run: RunSummary
    state: RunState
    prs: Annotated[list[PRRef], Field(title="Prs")]
    preview_url: Annotated[str | None, Field(title="Preview Url")]
    traceability: Annotated[list[TraceRow], Field(title="Traceability")]
    findings: Annotated[list[Finding], Field(title="Findings")]
    tests: Annotated[list[TestResult], Field(title="Tests")]
    cost_by_agent: Annotated[dict[str, float], Field(title="Cost By Agent")]


class Secret(RootModel[str]):
    root: Annotated[str, Field(max_length=128, min_length=16, title="Secret")]


class SessionView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    user: UserView
    roles: Annotated[
        dict[str, Literal["admin", "maintainer", "contributor", "viewer"]],
        Field(title="Roles"),
    ]
    preferences: Preferences


class SlackIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    webhook_url: Annotated[WebhookUrl | None, Field(title="Webhook Url")] = None


class SourceDoc(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    kind: Annotated[
        Literal["markdown", "pdf", "docx", "text", "jira", "confluence", "github_issue", "figma", "openapi", "image"],
        Field(title="Kind"),
    ]
    name: Annotated[str, Field(title="Name")]
    content: Annotated[str | None, Field(title="Content")] = ""
    uri: Annotated[str | None, Field(title="Uri")] = None
    sha256: Annotated[str | None, Field(title="Sha256")] = None


class SpecCheck(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    templated: Annotated[bool | None, Field(title="Templated")] = False
    template: Annotated[str | None, Field(title="Template")] = None
    kind: Annotated[Literal["feature", "bug"] | None, Field(title="Kind")] = None
    title: Annotated[str | None, Field(title="Title")] = ""
    project_id: Annotated[str | None, Field(title="Project Id")] = None
    repos: Annotated[list[str] | None, Field(title="Repos")] = None
    surfaces: Annotated[
        list[Literal["ui", "backend", "data", "infra", "integration", "vsix"]] | None,
        Field(title="Surfaces"),
    ] = None
    risk_tier: Annotated[Literal["low", "medium", "high"] | None, Field(title="Risk Tier")] = None
    budget_usd: Annotated[float | None, Field(title="Budget Usd")] = None
    errors: Annotated[list[str] | None, Field(title="Errors")] = None
    warnings: Annotated[list[str] | None, Field(title="Warnings")] = None
    gaps: Annotated[list[str] | None, Field(title="Gaps")] = None


class SpecCheckRequest(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    markdown: Annotated[
        str,
        Field(
            description="The filled spec (Markdown)",
            max_length=2000000,
            title="Markdown",
        ),
    ]


class SpecTemplateView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    name: Annotated[str, Field(title="Name")]
    description: Annotated[str, Field(title="Description")]
    surfaces: Annotated[
        list[Literal["ui", "backend", "data", "infra", "integration", "vsix"]],
        Field(
            description="Surfaces the template declares; empty for the bug template",
            title="Surfaces",
        ),
    ]
    formats: Annotated[list[Literal["md", "docx", "confluence"]] | None, Field(title="Formats")] = None


class SpecUploadResult(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    uploads: Annotated[list[UploadView], Field(title="Uploads")]
    run: RunSummary


class SprintCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    title: Annotated[str, Field(max_length=300, min_length=1, title="Title")]
    items: Annotated[list[SprintItem], Field(max_length=50, min_length=1, title="Items")]


class SprintItem(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    kind: Annotated[Literal["feature", "bug"] | None, Field(title="Kind")] = "feature"
    title: Annotated[str, Field(max_length=300, min_length=1, title="Title")]
    sources: Annotated[list[SourceDoc] | None, Field(title="Sources")] = None
    repo_hints: Annotated[list[str] | None, Field(title="Repo Hints")] = None


class SprintView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    run: RunSummary
    work_item_ids: Annotated[list[str], Field(title="Work Item Ids")]
    children: Annotated[list[RunSummary], Field(title="Children")]


class TeamCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    name: Annotated[str, Field(max_length=200, min_length=1, title="Name")]
    monthly_budget_usd: Annotated[float | None, Field(ge=0.0, title="Monthly Budget Usd")] = 1000.0


class TeamMemberView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    user_id: Annotated[str, Field(max_length=200, min_length=3, title="User Id")]
    role: Annotated[Literal["admin", "maintainer", "contributor", "viewer"], Field(title="Role")]


class TeamView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    org_id: Annotated[str, Field(title="Org Id")]
    name: Annotated[str, Field(title="Name")]
    monthly_budget_usd: Annotated[float, Field(title="Monthly Budget Usd")]
    members: Annotated[list[TeamMemberView], Field(title="Members")]


class TeamsIntegration(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    webhook_url: Annotated[WebhookUrl | None, Field(title="Webhook Url")] = None


class TestResult(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    name: Annotated[str, Field(title="Name")]
    level: Annotated[
        Literal["unit", "integration", "contract", "e2e", "performance", "accessibility", "baseline"],
        Field(title="Level"),
    ]
    status: Annotated[Literal["pass", "fail", "skip", "flaky"], Field(title="Status")]
    ac_ids: Annotated[list[str] | None, Field(title="Ac Ids")] = None
    repo: Annotated[str | None, Field(title="Repo")] = None
    duration_ms: Annotated[int | None, Field(title="Duration Ms")] = 0
    output: Annotated[str | None, Field(title="Output")] = ""


class Title(RootModel[str]):
    root: Annotated[str, Field(max_length=300, title="Title")]


class Token(RootModel[str]):
    root: Annotated[str, Field(description="Secret; returned masked", max_length=500, title="Token")]


class TokenCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    name: Annotated[str, Field(max_length=200, min_length=1, title="Name")]


class TokenCreated(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    name: Annotated[str, Field(title="Name")]
    created_at: Annotated[AwareDatetime, Field(title="Created At")]
    token: Annotated[str, Field(description="Shown once; only a hash is stored.", title="Token")]


class TokenView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    name: Annotated[str, Field(title="Name")]
    created_at: Annotated[AwareDatetime, Field(title="Created At")]


class TraceRow(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    ac_id: Annotated[str, Field(title="Ac Id")]
    text: Annotated[str, Field(title="Text")]
    tests: Annotated[list[str], Field(title="Tests")]
    passed: Annotated[bool | None, Field(title="Passed")]


class UploadView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    filename: Annotated[str, Field(title="Filename")]
    content_type: Annotated[str, Field(title="Content Type")]
    size: Annotated[int, Field(title="Size")]
    sha256: Annotated[str, Field(title="Sha256")]
    kind: Annotated[
        Literal["markdown", "pdf", "docx", "text", "jira", "confluence", "github_issue", "figma", "openapi", "image"],
        Field(title="Kind"),
    ]
    artifact_key: Annotated[str, Field(title="Artifact Key")]


class User(RootModel[str]):
    root: Annotated[str, Field(max_length=200, title="User")]


class UserView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    name: Annotated[str, Field(title="Name")]
    email: Annotated[str | None, Field(title="Email")]
    is_admin: Annotated[bool, Field(title="Is Admin")]


class ValidationError(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    loc: Annotated[list[str | int], Field(title="Location")]
    msg: Annotated[str, Field(title="Message")]
    type: Annotated[str, Field(title="Error Type")]
    input: Annotated[Any | None, Field(title="Input")] = None
    ctx: Annotated[dict[str, Any] | None, Field(title="Context")] = None


class VerifyBranchRequest(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    project_id: Annotated[str, Field(title="Project Id")]
    repo: Annotated[str, Field(max_length=200, min_length=1, title="Repo")]
    branch: Annotated[str, Field(pattern="^[A-Za-z0-9._/][A-Za-z0-9._/-]{0,199}$", title="Branch")]


class WebhookCreate(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    url: Annotated[str, Field(max_length=500, pattern="^https?://[^\\s]+$", title="Url")]
    events: Annotated[
        list[Literal["run.gate_waiting", "run.pr_ready", "run.failed", "run.completed"]],
        Field(min_length=1, title="Events"),
    ]
    secret: Annotated[Secret | None, Field(title="Secret")] = None


class WebhookCreated(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    url: Annotated[str, Field(title="Url")]
    events: Annotated[
        list[Literal["run.gate_waiting", "run.pr_ready", "run.failed", "run.completed"]],
        Field(title="Events"),
    ]
    active: Annotated[bool, Field(title="Active")]
    secret: Annotated[str, Field(description="HMAC signing secret; shown once.", title="Secret")]


class WebhookUrl(RootModel[str]):
    root: Annotated[str, Field(max_length=500, pattern="^https://\\S+$", title="Webhook Url")]


class WebhookView(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
    )
    id: Annotated[str, Field(title="Id")]
    project_id: Annotated[str, Field(title="Project Id")]
    url: Annotated[str, Field(title="Url")]
    events: Annotated[
        list[Literal["run.gate_waiting", "run.pr_ready", "run.failed", "run.completed"]],
        Field(title="Events"),
    ]
    active: Annotated[bool, Field(title="Active")]
