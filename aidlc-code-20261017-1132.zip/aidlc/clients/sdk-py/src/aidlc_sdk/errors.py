"""Typed errors raised by the AIDLC clients. Every error carries the HTTP status and the API's ``detail``."""

from __future__ import annotations

from typing import Any

import httpx


class AidlcError(Exception):
    """Base class of every SDK error."""


class Unreachable(AidlcError):
    """The API could not be reached (DNS, connection refused, TLS, timeout)."""


class ApiError(AidlcError):
    def __init__(self, status: int, detail: Any, *, method: str = "", url: str = "") -> None:
        self.status = status
        self.detail = detail
        self.method = method
        self.url = url
        super().__init__(f"{status} {method} {url}: {self.message}".strip())

    @property
    def message(self) -> str:
        if isinstance(self.detail, list):  # FastAPI validation errors
            return "; ".join(
                f"{'.'.join(str(p) for p in e.get('loc', []))}: {e.get('msg', '')}" if isinstance(e, dict) else str(e)
                for e in self.detail
            )
        if isinstance(self.detail, dict) and isinstance(self.detail.get("errors"), list):  # e.g. the spec check
            return "\n".join([str(self.detail.get("message", "")), *(f"  - {e}" for e in self.detail["errors"])])
        return str(self.detail)


class AuthError(ApiError):
    """401: missing, expired or invalid credentials."""


class PermissionDenied(ApiError):
    """403: the caller's role on the project is too low for this action."""


class NotFound(ApiError):
    """404: the resource does not exist or is not visible to the caller."""


class Conflict(ApiError):
    """409: the resource is in a state that does not allow the action (e.g. a finished run)."""


class RateLimited(ApiError):
    """429: per-token rate limit exceeded; retry after ``retry_after`` seconds."""

    def __init__(self, status: int, detail: Any, *, retry_after: float, method: str = "", url: str = "") -> None:
        self.retry_after = retry_after
        super().__init__(status, detail, method=method, url=url)


_BY_STATUS: dict[int, type[ApiError]] = {401: AuthError, 403: PermissionDenied, 404: NotFound, 409: Conflict}


def _detail(response: httpx.Response) -> Any:
    try:
        body = response.json()
    except ValueError:
        return response.text or response.reason_phrase
    return body.get("detail", body) if isinstance(body, dict) else body


def _retry_after(response: httpx.Response) -> float:
    try:
        return max(0.0, float(response.headers.get("Retry-After", "1")))
    except ValueError:
        return 1.0


def error_for(response: httpx.Response) -> ApiError:
    """The typed error for a non-2xx response. The body must already be read."""
    kwargs = {"method": response.request.method, "url": str(response.request.url)}
    detail = _detail(response)
    if response.status_code == 429:
        return RateLimited(429, detail, retry_after=_retry_after(response), **kwargs)
    cls = _BY_STATUS.get(response.status_code, ApiError)
    return cls(response.status_code, detail, **kwargs)
