"""Operation table and request builders shared by the sync and async clients.

``OPERATIONS`` maps the OpenAPI ``operationId`` of every operation the SDK calls to its (method, path); the
contract test checks each one against ``clients/openapi.json`` so the SDK cannot drift from the API.
"""

from __future__ import annotations

import mimetypes
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal
from urllib.parse import quote

import httpx
from pydantic import BaseModel, TypeAdapter

from aidlc_sdk import models as m

API_PREFIX = "/api/v1"

OPERATIONS: dict[str, tuple[str, str]] = {
    "healthz": ("GET", "/healthz"),
    "getConfig": ("GET", "/api/v1/config"),
    "getSession": ("GET", "/api/v1/session"),
    "listTokens": ("GET", "/api/v1/me/tokens"),
    "createToken": ("POST", "/api/v1/me/tokens"),
    "revokeToken": ("DELETE", "/api/v1/me/tokens/{token_id}"),
    "listProjects": ("GET", "/api/v1/projects"),
    "getProject": ("GET", "/api/v1/projects/{project_id}"),
    "getDoctor": ("GET", "/api/v1/projects/{project_id}/doctor"),
    "runDoctor": ("POST", "/api/v1/projects/{project_id}/doctor"),
    "uploadSpecs": ("POST", "/api/v1/projects/{project_id}/specs"),
    "listSpecTemplates": ("GET", "/api/v1/spec-templates"),
    "getSpecTemplate": ("GET", "/api/v1/spec-templates/{type_id}"),
    "checkSpec": ("POST", "/api/v1/spec-templates/check"),
    "listRuns": ("GET", "/api/v1/runs"),
    "createRun": ("POST", "/api/v1/runs"),
    "getRun": ("GET", "/api/v1/runs/{run_id}"),
    "cancelRun": ("POST", "/api/v1/runs/{run_id}/cancel"),
    "retryRun": ("POST", "/api/v1/runs/{run_id}/retry"),
    "streamRunEvents": ("GET", "/api/v1/runs/{run_id}/events"),
    "listArtifacts": ("GET", "/api/v1/runs/{run_id}/artifacts"),
    "getArtifact": ("GET", "/api/v1/runs/{run_id}/artifacts/{name}"),
    "listInbox": ("GET", "/api/v1/inbox"),
    "getInboxItem": ("GET", "/api/v1/inbox/{item_id}"),
    "answerInboxItem": ("POST", "/api/v1/inbox/{item_id}/answer"),
    "decideInboxItem": ("POST", "/api/v1/inbox/{item_id}/decide"),
    "listPreviews": ("GET", "/api/v1/previews"),
    "searchKnowledge": ("GET", "/api/v1/knowledge"),
    "listAgents": ("GET", "/api/v1/agents"),
    "getAgent": ("GET", "/api/v1/agents/{agent_id}"),
    "recordAgentEval": ("POST", "/api/v1/agents/{agent_id}/evals"),
    "promoteAgent": ("POST", "/api/v1/agents/{agent_id}/promote"),
    "rollbackAgent": ("POST", "/api/v1/agents/{agent_id}/rollback"),
    "verifyBranch": ("POST", "/api/v1/verify-branch"),
}

SpecFile = Path | tuple[str, bytes] | tuple[str, bytes, str]
InboxStatus = Literal["open", "resolved", "all"]
EscalationDecision = Literal["retry", "edit_spec", "takeover", "cancel"]


def _parser[T](adapter: TypeAdapter[T]) -> Callable[[httpx.Response], T]:
    return lambda response: adapter.validate_json(response.content)


def _model[M: BaseModel](model: type[M]) -> Callable[[httpx.Response], M]:
    return lambda response: model.model_validate_json(response.content)


def _models[M: BaseModel](model: type[M]) -> Callable[[httpx.Response], list[M]]:
    return _parser(TypeAdapter(list[model]))  # type: ignore[valid-type]


def _nothing(response: httpx.Response) -> None:
    return None


def _bytes(response: httpx.Response) -> bytes:
    return response.content


def _query(**params: Any) -> dict[str, Any]:
    return {k: v for k, v in params.items() if v is not None}


@dataclass(frozen=True)
class Call[T]:
    """One API request: which operation, how to fill its path, and how to parse a 2xx response."""

    op: str
    parse: Callable[[httpx.Response], T]
    path_params: Mapping[str, str] = field(default_factory=dict)
    params: Mapping[str, Any] | None = None
    json: Any = None
    data: Mapping[str, Any] | None = None
    files: Sequence[tuple[str, tuple[str, bytes, str]]] | None = None
    headers: Mapping[str, str] = field(default_factory=dict)

    @property
    def method(self) -> str:
        return OPERATIONS[self.op][0]

    @property
    def path(self) -> str:
        template = OPERATIONS[self.op][1]
        # Artifact names are nested paths; every other parameter is a single segment.
        return template.format(**{k: quote(v, safe="/" if k == "name" else "") for k, v in self.path_params.items()})

    def request_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = {"params": self.params, "headers": dict(self.headers)}
        if self.json is not None:
            kwargs["json"] = self.json
        if self.files is not None:
            kwargs["files"] = list(self.files)
            kwargs["data"] = dict(self.data or {})
        return kwargs


def _spec_file(spec: SpecFile) -> tuple[str, tuple[str, bytes, str]]:
    if isinstance(spec, Path):
        name, content, ctype = spec.name, spec.read_bytes(), ""
    elif len(spec) == 3:
        name, content, ctype = spec  # type: ignore[misc]
    else:
        name, content = spec  # type: ignore[misc]
        ctype = ""
    ctype = ctype or mimetypes.guess_type(name)[0] or ("text/markdown" if name.endswith(".md") else "text/plain")
    return ("files", (name, content, ctype))


def _body(model: BaseModel) -> dict[str, Any]:
    return model.model_dump(mode="json", exclude_none=True)


# ---------- builders (one per operation; the clients only execute them) ----------


def get_config() -> Call[m.PublicConfig]:
    return Call("getConfig", _model(m.PublicConfig))


def health() -> Call[m.Health]:
    return Call("healthz", _model(m.Health))


def get_session() -> Call[m.SessionView]:
    return Call("getSession", _model(m.SessionView))


def list_tokens() -> Call[list[m.TokenView]]:
    return Call("listTokens", _models(m.TokenView))


def create_token(name: str) -> Call[m.TokenCreated]:
    return Call("createToken", _model(m.TokenCreated), json=_body(m.TokenCreate(name=name)))


def revoke_token(token_id: str) -> Call[None]:
    return Call("revokeToken", _nothing, {"token_id": token_id})


def list_projects() -> Call[list[m.ProjectView]]:
    return Call("listProjects", _models(m.ProjectView))


def get_project(project_id: str) -> Call[m.ProjectView]:
    return Call("getProject", _model(m.ProjectView), {"project_id": project_id})


def get_doctor(project_id: str) -> Call[m.DoctorReport]:
    return Call("getDoctor", _model(m.DoctorReport), {"project_id": project_id})


def run_doctor(project_id: str) -> Call[m.DoctorReport]:
    return Call("runDoctor", _model(m.DoctorReport), {"project_id": project_id})


def upload_specs(
    project_id: str,
    files: Sequence[SpecFile],
    *,
    kind: Literal["feature", "bug"] = "feature",
    title: str | None = None,
    repos: Sequence[str] = (),
    figma_url: str | None = None,
    confluence_urls: Sequence[str] = (),
    economy: bool = False,
) -> Call[m.SpecUploadResult]:
    if not files and not confluence_urls:
        raise ValueError("upload_specs needs at least one file or Confluence page link")
    data: dict[str, Any] = {"kind": kind}
    if title:
        data["title"] = title
    if repos:
        data["repos"] = list(repos)
    if figma_url:
        data["figma_url"] = figma_url
    if confluence_urls:
        data["confluence_urls"] = list(confluence_urls)
    if economy:
        data["economy"] = "true"
    return Call(
        "uploadSpecs",
        _model(m.SpecUploadResult),
        {"project_id": project_id},
        data=data,
        files=[_spec_file(f) for f in files],
    )


def list_runs(
    *,
    project_id: str | None = None,
    kind: str | None = None,
    outcome: str | None = None,
    q: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> Call[list[m.RunSummary]]:
    params = _query(project_id=project_id, kind=kind, outcome=outcome, q=q, limit=limit, offset=offset)
    return Call("listRuns", _models(m.RunSummary), params=params)


def list_spec_templates() -> Call[list[m.SpecTemplateView]]:
    return Call("listSpecTemplates", _models(m.SpecTemplateView))


def get_spec_template(
    type_id: str, format: Literal["md", "docx", "confluence"] = "md", example: bool = False
) -> Call[bytes]:
    params = _query(format=format, example="true" if example else None)
    return Call("getSpecTemplate", _bytes, {"type_id": type_id}, params=params)


def check_spec(markdown: str) -> Call[m.SpecCheck]:
    return Call("checkSpec", _model(m.SpecCheck), json=_body(m.SpecCheckRequest(markdown=markdown)))


def create_run(body: m.RunCreate | Mapping[str, Any], idempotency_key: str | None = None) -> Call[m.RunSummary]:
    """``idempotency_key`` defaults to a fresh UUID, so a retried request (same ``Call``) never starts two runs."""
    payload = _body(body if isinstance(body, m.RunCreate) else m.RunCreate.model_validate(body))
    key = idempotency_key or uuid.uuid4().hex
    return Call("createRun", _model(m.RunSummary), json=payload, headers={"Idempotency-Key": key})


def get_run(run_id: str) -> Call[m.RunView]:
    return Call("getRun", _model(m.RunView), {"run_id": run_id})


def cancel_run(run_id: str) -> Call[m.RunSummary]:
    return Call("cancelRun", _model(m.RunSummary), {"run_id": run_id})


def retry_run(run_id: str) -> Call[m.RunSummary]:
    return Call("retryRun", _model(m.RunSummary), {"run_id": run_id})


def list_artifacts(run_id: str) -> Call[list[m.ArtifactView]]:
    return Call("listArtifacts", _models(m.ArtifactView), {"run_id": run_id})


def get_artifact(run_id: str, name: str) -> Call[bytes]:
    return Call("getArtifact", _bytes, {"run_id": run_id, "name": name.lstrip("/")})


def list_inbox(project_id: str | None = None, status: InboxStatus = "open") -> Call[list[m.InboxItemView]]:
    return Call("listInbox", _models(m.InboxItemView), params=_query(project_id=project_id, status=status))


def get_inbox_item(item_id: str) -> Call[m.InboxItemView]:
    return Call("getInboxItem", _model(m.InboxItemView), {"item_id": item_id})


def answer(item_id: str, answer: str) -> Call[m.InboxItemView]:
    body = _body(m.AnswerRequest(answer=answer))
    return Call("answerInboxItem", _model(m.InboxItemView), {"item_id": item_id}, json=body)


def decide(item_id: str, decision: EscalationDecision, note: str = "") -> Call[m.InboxItemView]:
    body = _body(m.DecideRequest(decision=decision, note=note))
    return Call("decideInboxItem", _model(m.InboxItemView), {"item_id": item_id}, json=body)


def list_previews(run_id: str | None = None, project_id: str | None = None) -> Call[list[m.PreviewView]]:
    return Call("listPreviews", _models(m.PreviewView), params=_query(run_id=run_id, project_id=project_id))


def search_knowledge(
    project_id: str, q: str = "", kind: str | None = None, limit: int | None = None
) -> Call[list[m.KnowledgeView]]:
    params = _query(project_id=project_id, q=q, kind=kind, limit=limit)
    return Call("searchKnowledge", _models(m.KnowledgeView), params=params)


def list_agents() -> Call[list[m.AgentSummary]]:
    return Call("listAgents", _models(m.AgentSummary))


def get_agent(agent_id: str) -> Call[m.AgentDetail]:
    return Call("getAgent", _model(m.AgentDetail), {"agent_id": agent_id})


def record_agent_eval(
    agent_id: str, version: str, score: float, report: Mapping[str, Any] | None = None
) -> Call[m.AgentDetail]:
    body = _body(m.AgentEvalCreate(version=version, score=score, report=dict(report or {})))
    return Call("recordAgentEval", _model(m.AgentDetail), {"agent_id": agent_id}, json=body)


def promote_agent(agent_id: str, version: str) -> Call[m.AgentDetail]:
    body = _body(m.PromoteRequest(version=version))
    return Call("promoteAgent", _model(m.AgentDetail), {"agent_id": agent_id}, json=body)


def rollback_agent(agent_id: str) -> Call[m.AgentDetail]:
    return Call("rollbackAgent", _model(m.AgentDetail), {"agent_id": agent_id})


def verify_branch(project_id: str, repo: str, branch: str) -> Call[m.RunSummary]:
    body = _body(m.VerifyBranchRequest(project_id=project_id, repo=repo, branch=branch))
    return Call("verifyBranch", _model(m.RunSummary), json=body)


def stream_events(run_id: str) -> Call[None]:
    """Path holder for the SSE endpoint; the clients stream it themselves (see ``Client.events``)."""
    return Call("streamRunEvents", _nothing, {"run_id": run_id})
