import { describe, expect, it, vi } from "vitest";

import {
  AidlcClient,
  AuthError,
  Conflict,
  NotFound,
  PermissionDenied,
  RateLimited,
  SseDecoder,
  Unreachable,
  isStreamEnd,
  type RunStreamItem,
} from "../src/index.js";

const API = "http://api.test";
const NOW = "2026-10-12T10:00:00Z";

function json(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", ...headers } });
}

function event(seq: number, type = "log") {
  return { seq, run_id: "run-1", type, stage: "S1", agent_id: null, message: type, data: {}, at: NOW };
}

function sse(events: ReturnType<typeof event>[], outcome?: string): string {
  let body = ": ping\r\n\r\n";
  for (const e of events) body += `id: ${e.seq}\r\ndata: ${JSON.stringify(e)}\r\n\r\n`;
  if (outcome) {
    const last = events.at(-1)?.seq ?? 0;
    body += `event: end\r\ndata: ${JSON.stringify({ outcome, last_event_id: last })}\r\n\r\n`;
  }
  return body;
}

/** A stream that delivers `text` and then fails, like a dropped connection. */
function dropping(text: string): Response {
  let sent = false;
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) {
      // Erroring a stream discards queued chunks, so deliver the text first and fail on the next read.
      if (sent) return controller.error(new TypeError("terminated"));
      sent = true;
      controller.enqueue(new TextEncoder().encode(text));
    },
  });
  return new Response(stream, { status: 200, headers: { "Content-Type": "text/event-stream" } });
}

function client(fetchImpl: typeof fetch, token = "aidlc_secret") {
  return new AidlcClient({ baseUrl: `${API}/api/v1/`, token, fetch: fetchImpl });
}

function requestOf(mock: ReturnType<typeof vi.fn>, index = 0): { url: string; init: RequestInit; headers: Headers } {
  const [url, init] = mock.mock.calls[index] as [string, RequestInit];
  return { url, init, headers: new Headers(init.headers) };
}

describe("AidlcClient", () => {
  it("sends the bearer token and normalises the base URL", async () => {
    const fetchMock = vi.fn(async () => json([]));
    await client(fetchMock as unknown as typeof fetch).listProjects();
    const { url, headers } = requestOf(fetchMock);
    expect(url).toBe(`${API}/api/v1/projects`);
    expect(headers.get("Authorization")).toBe("Bearer aidlc_secret");
  });

  it("sends an Idempotency-Key when creating runs", async () => {
    const fetchMock = vi.fn(async () => json({ id: "run-1" }, 201));
    const api = client(fetchMock as unknown as typeof fetch);
    await api.createRun({ project_id: "shop", kind: "feature", title: "Todo" }, "key-1");
    await api.createRun({ project_id: "shop", kind: "feature", title: "Todo" });
    expect(requestOf(fetchMock, 0).headers.get("Idempotency-Key")).toBe("key-1");
    expect(requestOf(fetchMock, 1).headers.get("Idempotency-Key")).toMatch(/^[0-9a-f-]{36}$/);
    expect(JSON.parse(requestOf(fetchMock, 0).init.body as string)).toEqual({
      project_id: "shop",
      kind: "feature",
      title: "Todo",
    });
  });

  it("uploads specs as multipart with the files field", async () => {
    const fetchMock = vi.fn(async () => json({ uploads: [], run: { id: "run-1" } }, 201));
    await client(fetchMock as unknown as typeof fetch).uploadSpecs(
      "shop",
      [{ name: "todo.md", data: "# Todo" }, { name: "b.md", data: new Uint8Array([35]) }],
      { kind: "bug", repos: ["web", "api"] },
    );
    const { url, init } = requestOf(fetchMock);
    expect(url).toBe(`${API}/api/v1/projects/shop/specs`);
    const form = init.body as FormData;
    expect(form.getAll("files")).toHaveLength(2);
    expect((form.get("files") as File).name).toBe("todo.md");
    expect(form.getAll("repos")).toEqual(["web", "api"]);
    expect(form.get("kind")).toBe("bug");
  });

  it("sends Confluence page links with or without files", async () => {
    const fetchMock = vi.fn(async () => json({ uploads: [], run: { id: "run-1" } }, 201));
    const api = client(fetchMock as unknown as typeof fetch);
    const page = "https://acme.atlassian.net/wiki/spaces/ENG/pages/1/Spec";
    await api.uploadSpecs("shop", [], { confluenceUrls: [page] });
    const form = requestOf(fetchMock).init.body as FormData;
    expect(form.getAll("confluence_urls")).toEqual([page]);
    expect(form.getAll("files")).toEqual([]);
    expect(() => api.uploadSpecs("shop", [])).toThrow(/at least one file or Confluence page link/);
  });

  it("encodes deterministic inbox ids and reads the public config", async () => {
    const fetchMock = vi.fn(async () => json({}));
    const api = client(fetchMock as unknown as typeof fetch);
    await api.getInboxItem("run-1:Q-1");
    expect(requestOf(fetchMock, 0).url).toBe(`${API}/api/v1/inbox/run-1%3AQ-1`);
    await api.answer("run-1:Q-1", "EUR");
    expect(requestOf(fetchMock, 1).url).toBe(`${API}/api/v1/inbox/run-1%3AQ-1/answer`);
    await api.config();
    expect(requestOf(fetchMock, 2).url).toBe(`${API}/api/v1/config`);
    expect(api.url("streamRunEvents", { run_id: "r 1" })).toBe(`${API}/api/v1/runs/r%201/events`);
  });

  it("records agent evals and promotes or rolls back versions", async () => {
    const fetchMock = vi.fn(async () => json({ id: "intake" }));
    const api = client(fetchMock as unknown as typeof fetch);
    await api.recordAgentEval("intake", "1.2.0", 0.91, { cases: 3 });
    await api.promoteAgent("intake", "1.2.0");
    await api.rollbackAgent("intake");
    const calls = fetchMock.mock.calls.map((_, i) => requestOf(fetchMock, i));
    expect(calls.map((c) => [c.init.method, c.url])).toEqual([
      ["POST", `${API}/api/v1/agents/intake/evals`],
      ["POST", `${API}/api/v1/agents/intake/promote`],
      ["POST", `${API}/api/v1/agents/intake/rollback`],
    ]);
    expect(JSON.parse(calls[0].init.body as string)).toEqual({ version: "1.2.0", score: 0.91, report: { cases: 3 } });
    expect(JSON.parse(calls[1].init.body as string)).toEqual({ version: "1.2.0" });
  });

  it("keeps nested artifact names as path segments", async () => {
    const fetchMock = vi.fn(async () => new Response(new Uint8Array([1, 2])));
    const bytes = await client(fetchMock as unknown as typeof fetch).getArtifact("run-1", "reports/test report.json");
    expect(requestOf(fetchMock).url).toBe(`${API}/api/v1/runs/run-1/artifacts/reports/test%20report.json`);
    expect(Array.from(bytes)).toEqual([1, 2]);
  });

  it.each([
    [401, AuthError],
    [403, PermissionDenied],
    [404, NotFound],
    [409, Conflict],
  ])("maps HTTP %i to a typed error", async (status, ErrorClass) => {
    const fetchMock = vi.fn(async () => json({ detail: "nope" }, status));
    const error = await client(fetchMock as unknown as typeof fetch)
      .cancelRun("run-1")
      .catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ErrorClass);
    expect((error as PermissionDenied).status).toBe(status);
    expect((error as PermissionDenied).detailMessage).toBe("nope");
  });

  it("reports Retry-After on rate limits and network failures as Unreachable", async () => {
    const limited = vi.fn(async () => json({ detail: "slow down" }, 429, { "Retry-After": "7" }));
    const error = await client(limited as unknown as typeof fetch)
      .listInbox()
      .catch((e: unknown) => e);
    expect(error).toBeInstanceOf(RateLimited);
    expect((error as RateLimited).retryAfter).toBe(7);

    const down = vi.fn(async () => {
      throw new TypeError("fetch failed");
    });
    await expect(client(down as unknown as typeof fetch).health()).rejects.toBeInstanceOf(Unreachable);
  });
});

describe("events", () => {
  it("resumes with Last-Event-ID after a dropped connection", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(dropping(sse([event(1), event(2)])))
      .mockRejectedValueOnce(new TypeError("fetch failed"))
      .mockResolvedValueOnce(new Response(sse([event(3)], "pr-ready")));
    const items: RunStreamItem[] = [];
    for await (const item of client(fetchMock as unknown as typeof fetch).events("run-1", { backoffMs: 0 })) {
      items.push(item);
    }
    const ids = fetchMock.mock.calls.map((_, i) => requestOf(fetchMock, i).headers.get("Last-Event-ID"));
    expect(ids).toEqual([null, "2", "2"]);
    expect(items.filter((i) => !isStreamEnd(i)).map((i) => (i as { seq: number }).seq)).toEqual([1, 2, 3]);
    expect(items.at(-1)).toEqual({ type: "end", outcome: "pr-ready", last_event_id: 3 });
  });

  it("starts after a given event id and does not retry permission errors", async () => {
    const ok = vi.fn(async () => new Response(sse([event(6)], "failed")));
    const items: RunStreamItem[] = [];
    for await (const item of client(ok as unknown as typeof fetch).events("run-1", { lastEventId: 5 })) items.push(item);
    expect(requestOf(ok).headers.get("Last-Event-ID")).toBe("5");
    expect(items.at(-1)).toMatchObject({ type: "end", outcome: "failed" });

    const denied = vi.fn(async () => json({ detail: "requires the viewer role" }, 403));
    const stream = client(denied as unknown as typeof fetch).events("run-1", { backoffMs: 0 });
    await expect(stream.next()).rejects.toBeInstanceOf(PermissionDenied);
    expect(denied).toHaveBeenCalledTimes(1);
  });

  it("gives up after maxFailures consecutive failures", async () => {
    const down = vi.fn(async () => {
      throw new TypeError("fetch failed");
    });
    const stream = client(down as unknown as typeof fetch).events("run-1", { backoffMs: 0, maxFailures: 2 });
    await expect(stream.next()).rejects.toBeInstanceOf(Unreachable);
    expect(down).toHaveBeenCalledTimes(3);
  });
});

describe("SseDecoder", () => {
  it("joins multi-line data, skips comments and reads retry", () => {
    const decoder = new SseDecoder();
    for (const line of [": ping", "retry: 2500", "id: 4", "data: a", "data: b"]) expect(decoder.feed(line)).toBeNull();
    expect(decoder.feed("")).toEqual({ event: "message", data: "a\nb", id: "4" });
    expect(decoder.retryMs).toBe(2500);
  });
});
