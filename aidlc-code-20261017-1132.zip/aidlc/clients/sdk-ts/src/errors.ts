/** Typed errors raised by the AIDLC client. Every API error carries the HTTP status and the API's `detail`. */

export class AidlcError extends Error {
  override name = "AidlcError";
}

/** The API could not be reached (DNS, connection refused, TLS, aborted stream). */
export class Unreachable extends AidlcError {
  override name = "Unreachable";
}

function describe(detail: unknown): string {
  if (Array.isArray(detail)) {
    return detail
      .map((e) => {
        if (e && typeof e === "object" && "msg" in e) {
          const loc = Array.isArray((e as { loc?: unknown[] }).loc) ? (e as { loc: unknown[] }).loc.join(".") : "";
          return `${loc}: ${String((e as { msg: unknown }).msg)}`;
        }
        return String(e);
      })
      .join("; ");
  }
  return typeof detail === "string" ? detail : JSON.stringify(detail);
}

export class ApiError extends AidlcError {
  override name = "ApiError";
  readonly status: number;
  readonly detail: unknown;
  readonly detailMessage: string;

  constructor(status: number, detail: unknown, method = "", url = "") {
    const text = describe(detail);
    super(`${status} ${method} ${url}: ${text}`.trim());
    this.status = status;
    this.detail = detail;
    this.detailMessage = text;
  }
}

/** 401: missing, expired or invalid credentials. */
export class AuthError extends ApiError {
  override name = "AuthError";
}

/** 403: the caller's role on the project is too low for this action. */
export class PermissionDenied extends ApiError {
  override name = "PermissionDenied";
}

/** 404: the resource does not exist or is not visible to the caller. */
export class NotFound extends ApiError {
  override name = "NotFound";
}

/** 409: the resource's state does not allow the action. */
export class Conflict extends ApiError {
  override name = "Conflict";
}

/** 429: per-token rate limit exceeded; retry after `retryAfter` seconds. */
export class RateLimited extends ApiError {
  override name = "RateLimited";
  readonly retryAfter: number;

  constructor(detail: unknown, retryAfter: number, method = "", url = "") {
    super(429, detail, method, url);
    this.retryAfter = retryAfter;
  }
}

/** The typed error for a non-2xx response. */
export async function errorFor(response: Response, method: string): Promise<ApiError> {
  const text = await response.text();
  let detail: unknown = text || response.statusText;
  try {
    const body: unknown = JSON.parse(text);
    detail = body && typeof body === "object" && "detail" in body ? (body as { detail: unknown }).detail : body;
  } catch {
    // not JSON: keep the text
  }
  const url = response.url;
  if (response.status === 429) {
    const retryAfter = Number(response.headers.get("Retry-After") ?? "1");
    return new RateLimited(detail, Number.isFinite(retryAfter) ? Math.max(0, retryAfter) : 1, method, url);
  }
  const byStatus: Record<number, typeof ApiError> = { 401: AuthError, 403: PermissionDenied, 404: NotFound, 409: Conflict };
  const Cls = byStatus[response.status] ?? ApiError;
  return new Cls(response.status, detail, method, url);
}
