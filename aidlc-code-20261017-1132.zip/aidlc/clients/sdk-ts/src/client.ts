/** A small fetch-based client for the AIDLC control-plane REST API v1, mirroring the Python SDK (`aidlc_sdk`). */

import { AidlcError, ApiError, RateLimited, Unreachable, errorFor } from "./errors.js";
import type { components } from "./schema.js";
import { SseDecoder, backoffMs, readLines } from "./sse.js";

export type Schemas = components["schemas"];
export type SessionView = Schemas["SessionView"];
export type TokenView = Schemas["TokenView"];
export type TokenCreated = Schemas["TokenCreated"];
export type ProjectView = Schemas["ProjectView"];
export type DoctorReport = Schemas["DoctorReport"];
export type RunCreate = Schemas["RunCreate"];
export type RunSummary = Schemas["RunSummary"];
export type RunView = Schemas["RunView"];
export type SpecUploadResult = Schemas["SpecUploadResult"];
export type SpecTemplateView = Schemas["SpecTemplateView"];
export type SpecTemplateFormat = NonNullable<SpecTemplateView["formats"]>[number];
export type SpecCheck = Schemas["SpecCheck"];
export type ArtifactView = Schemas["ArtifactView"];
export type InboxItemView = Schemas["InboxItemView"];
export type PreviewView = Schemas["PreviewView"];
export type KnowledgeView = Schemas["KnowledgeView"];
export type AgentSummary = Schemas["AgentSummary"];
export type AgentDetail = Schemas["AgentDetail"];
export type Health = Schemas["Health"];
export type PublicConfig = Schemas["PublicConfig"];
export type AgentEvalCreate = Schemas["AgentEvalCreate"];
export type RunEventView = Schemas["RunEventView"];
export type EscalationDecision = Schemas["DecideRequest"]["decision"];

/** OpenAPI `operationId` → [method, path] for every operation this client calls (checked against the spec). */
export const OPERATIONS = {
  healthz: ["GET", "/healthz"],
  getConfig: ["GET", "/api/v1/config"],
  getSession: ["GET", "/api/v1/session"],
  listTokens: ["GET", "/api/v1/me/tokens"],
  createToken: ["POST", "/api/v1/me/tokens"],
  revokeToken: ["DELETE", "/api/v1/me/tokens/{token_id}"],
  listProjects: ["GET", "/api/v1/projects"],
  getProject: ["GET", "/api/v1/projects/{project_id}"],
  getDoctor: ["GET", "/api/v1/projects/{project_id}/doctor"],
  runDoctor: ["POST", "/api/v1/projects/{project_id}/doctor"],
  uploadSpecs: ["POST", "/api/v1/projects/{project_id}/specs"],
  listSpecTemplates: ["GET", "/api/v1/spec-templates"],
  getSpecTemplate: ["GET", "/api/v1/spec-templates/{type_id}"],
  checkSpec: ["POST", "/api/v1/spec-templates/check"],
  listRuns: ["GET", "/api/v1/runs"],
  createRun: ["POST", "/api/v1/runs"],
  getRun: ["GET", "/api/v1/runs/{run_id}"],
  cancelRun: ["POST", "/api/v1/runs/{run_id}/cancel"],
  retryRun: ["POST", "/api/v1/runs/{run_id}/retry"],
  streamRunEvents: ["GET", "/api/v1/runs/{run_id}/events"],
  listArtifacts: ["GET", "/api/v1/runs/{run_id}/artifacts"],
  getArtifact: ["GET", "/api/v1/runs/{run_id}/artifacts/{name}"],
  listInbox: ["GET", "/api/v1/inbox"],
  getInboxItem: ["GET", "/api/v1/inbox/{item_id}"],
  answerInboxItem: ["POST", "/api/v1/inbox/{item_id}/answer"],
  decideInboxItem: ["POST", "/api/v1/inbox/{item_id}/decide"],
  listPreviews: ["GET", "/api/v1/previews"],
  searchKnowledge: ["GET", "/api/v1/knowledge"],
  listAgents: ["GET", "/api/v1/agents"],
  getAgent: ["GET", "/api/v1/agents/{agent_id}"],
  recordAgentEval: ["POST", "/api/v1/agents/{agent_id}/evals"],
  promoteAgent: ["POST", "/api/v1/agents/{agent_id}/promote"],
  rollbackAgent: ["POST", "/api/v1/agents/{agent_id}/rollback"],
  verifyBranch: ["POST", "/api/v1/verify-branch"],
} as const satisfies Record<string, readonly [string, string]>;

export type OperationId = keyof typeof OPERATIONS;

/** The final item of a run's event stream: the run finished with `outcome`. */
export interface StreamEnd {
  type: "end";
  outcome: string;
  last_event_id: number | null;
}

export type RunStreamItem = RunEventView | StreamEnd;

export function isStreamEnd(item: RunStreamItem): item is StreamEnd {
  return item.type === "end";
}

export interface SpecFile {
  name: string;
  data: Blob | Uint8Array | string;
  type?: string;
}

export interface ClientOptions {
  /** Server root (`https://aidlc.example.com`) or the `/api/v1` base. */
  baseUrl: string;
  /** OIDC access token, API token (`aidlc_…`) or, on dev servers, `dev:<email>`. */
  token?: string;
  fetch?: typeof fetch;
  headers?: Record<string, string>;
}

export interface EventsOptions {
  lastEventId?: number;
  maxFailures?: number;
  backoffMs?: number;
  maxBackoffMs?: number;
  signal?: AbortSignal;
}

type Query = Record<string, string | number | boolean | null | undefined>;

interface RequestOptions {
  pathParams?: Record<string, string>;
  query?: Query;
  json?: unknown;
  form?: FormData;
  headers?: Record<string, string>;
}

export const USER_AGENT = "aidlc-sdk-ts/0.1.0";
const API_PREFIX = "/api/v1";

export function normalizeBaseUrl(baseUrl: string): string {
  let url = baseUrl.trim().replace(/\/+$/, "");
  if (url.endsWith(API_PREFIX)) url = url.slice(0, -API_PREFIX.length);
  return url;
}

function fill(template: string, params: Record<string, string> = {}): string {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => {
    const value = params[key];
    if (value === undefined) throw new AidlcError(`missing path parameter ${key}`);
    // Artifact names are nested paths; every other parameter is a single segment.
    return key === "name" ? value.split("/").map(encodeURIComponent).join("/") : encodeURIComponent(value);
  });
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason);
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      clearTimeout(timer);
      reject(signal.reason);
    });
  });
}

export class AidlcClient {
  readonly baseUrl: string;
  private readonly token: string | undefined;
  private readonly fetchImpl: typeof fetch;
  private readonly extraHeaders: Record<string, string>;

  constructor(options: ClientOptions) {
    this.baseUrl = normalizeBaseUrl(options.baseUrl);
    this.token = options.token;
    this.fetchImpl = options.fetch ?? globalThis.fetch.bind(globalThis);
    this.extraHeaders = options.headers ?? {};
  }

  /** Absolute URL of an operation, e.g. for links. */
  url(operation: OperationId, pathParams?: Record<string, string>, query?: Query): string {
    const url = new URL(this.baseUrl + fill(OPERATIONS[operation][1], pathParams));
    for (const [key, value] of Object.entries(query ?? {})) {
      if (value !== undefined && value !== null) url.searchParams.set(key, String(value));
    }
    return url.toString();
  }

  private headers(extra?: Record<string, string>): Headers {
    const headers = new Headers({ Accept: "application/json", "User-Agent": USER_AGENT, ...this.extraHeaders });
    if (this.token) headers.set("Authorization", `Bearer ${this.token}`);
    for (const [key, value] of Object.entries(extra ?? {})) headers.set(key, value);
    return headers;
  }

  private async send(operation: OperationId, options: RequestOptions = {}, signal?: AbortSignal) {
    const method = OPERATIONS[operation][0];
    const headers = this.headers(options.headers);
    let body: BodyInit | undefined;
    if (options.json !== undefined) {
      headers.set("Content-Type", "application/json");
      body = JSON.stringify(options.json);
    } else if (options.form) {
      body = options.form;
    }
    const url = this.url(operation, options.pathParams, options.query);
    let response: Response;
    try {
      response = await this.fetchImpl(url, { method, headers, body, signal });
    } catch (error) {
      if (signal?.aborted) throw error;
      throw new Unreachable(`${method} ${url}: ${String(error)}`);
    }
    if (!response.ok) throw await errorFor(response, method);
    return response;
  }

  private async json<T>(operation: OperationId, options?: RequestOptions): Promise<T> {
    const response = await this.send(operation, options);
    return (await response.json()) as T;
  }

  // ---------- session and tokens ----------
  health(): Promise<Health> {
    return this.json("healthz");
  }

  /** Public server settings (upload limits, sign-in method); needs no token. */
  config(): Promise<PublicConfig> {
    return this.json("getConfig");
  }

  session(): Promise<SessionView> {
    return this.json("getSession");
  }

  listTokens(): Promise<TokenView[]> {
    return this.json("listTokens");
  }

  createToken(name: string): Promise<TokenCreated> {
    return this.json("createToken", { json: { name } });
  }

  async revokeToken(tokenId: string): Promise<void> {
    await this.send("revokeToken", { pathParams: { token_id: tokenId } });
  }

  // ---------- projects ----------
  listProjects(): Promise<ProjectView[]> {
    return this.json("listProjects");
  }

  getProject(projectId: string): Promise<ProjectView> {
    return this.json("getProject", { pathParams: { project_id: projectId } });
  }

  getDoctor(projectId: string): Promise<DoctorReport> {
    return this.json("getDoctor", { pathParams: { project_id: projectId } });
  }

  runDoctor(projectId: string): Promise<DoctorReport> {
    return this.json("runDoctor", { pathParams: { project_id: projectId } });
  }

  /**
   * Upload spec documents (multipart field `files`) and/or Confluence page links (fetched by the server with the
   * project's Confluence integration) and start a feature or bug run.
   */
  uploadSpecs(
    projectId: string,
    files: SpecFile[],
    options: {
      kind?: "feature" | "bug";
      title?: string;
      repos?: string[];
      figmaUrl?: string;
      confluenceUrls?: string[];
      /** Economy mode for this run: caps every agent's thinking effort and turns. */
      economy?: boolean;
    } = {},
  ): Promise<SpecUploadResult> {
    const confluenceUrls = options.confluenceUrls ?? [];
    if (files.length === 0 && confluenceUrls.length === 0) {
      throw new AidlcError("uploadSpecs needs at least one file or Confluence page link");
    }
    const form = new FormData();
    for (const file of files) {
      const blob =
        file.data instanceof Blob ? file.data : new Blob([file.data as BlobPart], { type: file.type ?? "text/markdown" });
      form.append("files", blob, file.name);
    }
    form.append("kind", options.kind ?? "feature");
    if (options.title) form.append("title", options.title);
    for (const repo of options.repos ?? []) form.append("repos", repo);
    if (options.figmaUrl) form.append("figma_url", options.figmaUrl);
    for (const url of confluenceUrls) form.append("confluence_urls", url);
    if (options.economy) form.append("economy", "true");
    return this.json("uploadSpecs", { pathParams: { project_id: projectId }, form });
  }

  // ---------- runs ----------
  listRuns(
    filters: { projectId?: string; kind?: string; outcome?: string; q?: string; limit?: number; offset?: number } = {},
  ): Promise<RunSummary[]> {
    const { projectId, ...rest } = filters;
    return this.json("listRuns", { query: { project_id: projectId, ...rest } });
  }

  /** `idempotencyKey` defaults to a fresh UUID; reuse a key when retrying so only one run starts. */
  listSpecTemplates(): Promise<SpecTemplateView[]> {
    return this.json("listSpecTemplates", {});
  }

  /** A blank template (or, with `example`, a filled-in one) as Markdown, Word (docx) or Confluence storage XHTML. */
  async getSpecTemplate(typeId: string, format: SpecTemplateFormat = "md", example = false): Promise<Uint8Array> {
    const response = await this.send("getSpecTemplate", {
      pathParams: { type_id: typeId },
      query: { format, example: example || undefined },
    });
    return new Uint8Array(await response.arrayBuffer());
  }

  /** The check a spec upload runs, without starting a run. */
  checkSpec(markdown: string): Promise<SpecCheck> {
    return this.json("checkSpec", { json: { markdown } });
  }

  createRun(body: RunCreate, idempotencyKey: string = crypto.randomUUID()): Promise<RunSummary> {
    return this.json("createRun", { json: body, headers: { "Idempotency-Key": idempotencyKey } });
  }

  getRun(runId: string): Promise<RunView> {
    return this.json("getRun", { pathParams: { run_id: runId } });
  }

  cancelRun(runId: string): Promise<RunSummary> {
    return this.json("cancelRun", { pathParams: { run_id: runId } });
  }

  retryRun(runId: string): Promise<RunSummary> {
    return this.json("retryRun", { pathParams: { run_id: runId } });
  }

  listArtifacts(runId: string): Promise<ArtifactView[]> {
    return this.json("listArtifacts", { pathParams: { run_id: runId } });
  }

  async getArtifact(runId: string, name: string): Promise<Uint8Array> {
    const response = await this.send("getArtifact", {
      pathParams: { run_id: runId, name: name.replace(/^\/+/, "") },
    });
    return new Uint8Array(await response.arrayBuffer());
  }

  /**
   * Yield the run's events, then a `StreamEnd`. Dropped connections reconnect with backoff and resume from the
   * last delivered event id (`Last-Event-ID`); 4xx errors other than 429 are raised at once.
   */
  async *events(runId: string, options: EventsOptions = {}): AsyncGenerator<RunStreamItem> {
    const maxFailures = options.maxFailures ?? 8;
    const initial = options.backoffMs ?? 500;
    const maxBackoff = options.maxBackoffMs ?? 30_000;
    let lastEventId: number | null = options.lastEventId ?? null;
    let failures = 0;
    let retryMs: number | null = null;
    for (;;) {
      const decoder: SseDecoder = new SseDecoder(retryMs);
      let error: AidlcError;
      const headers: Record<string, string> = { Accept: "text/event-stream", "Cache-Control": "no-cache" };
      if (lastEventId !== null) headers["Last-Event-ID"] = String(lastEventId);
      try {
        const response = await this.send("streamRunEvents",
          { pathParams: { run_id: runId }, headers },
          options.signal,
        );
        if (!response.body) throw new Unreachable("event stream has no body");
        for await (const line of readLines(response.body)) {
          const message = decoder.feed(line);
          if (!message) continue;
          if (message.event === "end") {
            const end = JSON.parse(message.data || "{}") as { outcome?: string; last_event_id?: number | null };
            yield { type: "end", outcome: end.outcome ?? "", last_event_id: end.last_event_id ?? lastEventId };
            return;
          }
          if (message.event !== "message" || !message.data) continue;
          const event = JSON.parse(message.data) as RunEventView;
          lastEventId = event.seq;
          failures = 0;
          yield event;
        }
        error = new Unreachable(`event stream for run ${runId} closed before the run finished`);
      } catch (caught) {
        if (options.signal?.aborted) throw caught;
        if (caught instanceof RateLimited) {
          await sleep(caught.retryAfter * 1000, options.signal);
          continue;
        }
        if (caught instanceof ApiError && caught.status < 500) throw caught;
        error = caught instanceof AidlcError ? caught : new Unreachable(`event stream for run ${runId}: ${String(caught)}`);
      }
      retryMs = decoder.retryMs;
      failures += 1;
      if (failures > maxFailures) throw error;
      await sleep(initial === 0 ? 0 : backoffMs(failures, initial, maxBackoff, retryMs), options.signal);
    }
  }

  // ---------- inbox, previews, knowledge, agents ----------
  listInbox(projectId?: string, status: "open" | "resolved" | "all" = "open"): Promise<InboxItemView[]> {
    return this.json("listInbox", { query: { project_id: projectId, status } });
  }

  /** One inbox item; ids look like `<run_id>:<ref_id>` and are URL-encoded here. */
  getInboxItem(itemId: string): Promise<InboxItemView> {
    return this.json("getInboxItem", { pathParams: { item_id: itemId } });
  }

  answer(itemId: string, answer: string): Promise<InboxItemView> {
    return this.json("answerInboxItem", { pathParams: { item_id: itemId }, json: { answer } });
  }

  decide(itemId: string, decision: EscalationDecision, note = ""): Promise<InboxItemView> {
    return this.json("decideInboxItem", {
      pathParams: { item_id: itemId },
      json: { decision, note },
    });
  }

  listPreviews(filters: { runId?: string; projectId?: string } = {}): Promise<PreviewView[]> {
    return this.json("listPreviews", { query: { run_id: filters.runId, project_id: filters.projectId } });
  }

  searchKnowledge(projectId: string, q = "", options: { kind?: string; limit?: number } = {}): Promise<KnowledgeView[]> {
    return this.json("searchKnowledge", { query: { project_id: projectId, q, ...options } });
  }

  listAgents(): Promise<AgentSummary[]> {
    return this.json("listAgents");
  }

  getAgent(agentId: string): Promise<AgentDetail> {
    return this.json("getAgent", { pathParams: { agent_id: agentId } });
  }

  /** Record an eval-suite score (0..1) for an agent version; maintainers only. */
  recordAgentEval(
    agentId: string,
    version: string,
    score: number,
    report: AgentEvalCreate["report"] = {},
  ): Promise<AgentDetail> {
    const body: AgentEvalCreate = { version, score, report };
    return this.json("recordAgentEval", { pathParams: { agent_id: agentId }, json: body });
  }

  /** Promote an evaluated version; the API refuses scores below its promotion threshold. */
  promoteAgent(agentId: string, version: string): Promise<AgentDetail> {
    return this.json("promoteAgent", { pathParams: { agent_id: agentId }, json: { version } });
  }

  rollbackAgent(agentId: string): Promise<AgentDetail> {
    return this.json("rollbackAgent", { pathParams: { agent_id: agentId } });
  }

  verifyBranch(projectId: string, repo: string, branch: string): Promise<RunSummary> {
    return this.json("verifyBranch", { json: { project_id: projectId, repo, branch } });
  }
}
