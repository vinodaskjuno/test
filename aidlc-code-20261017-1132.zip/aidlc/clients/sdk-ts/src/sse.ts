/** Server-sent events: a line decoder (WHATWG rules) and the resume/backoff policy used by `AidlcClient.events`. */

export interface SseMessage {
  event: string;
  data: string;
  id: string | null;
}

export class SseDecoder {
  retryMs: number | null;
  private event = "";
  private data: string[] = [];
  private id: string | null = null;

  constructor(retryMs: number | null = null) {
    this.retryMs = retryMs;
  }

  /** Feed one line (without its terminator); returns a message at each blank line. Comments (pings) are skipped. */
  feed(line: string): SseMessage | null {
    if (line === "") {
      if (this.data.length === 0 && this.event === "") return null;
      const message = { event: this.event || "message", data: this.data.join("\n"), id: this.id };
      this.event = "";
      this.data = [];
      this.id = null;
      return message;
    }
    if (line.startsWith(":")) return null;
    const colon = line.indexOf(":");
    const name = colon === -1 ? line : line.slice(0, colon);
    let value = colon === -1 ? "" : line.slice(colon + 1);
    if (value.startsWith(" ")) value = value.slice(1);
    if (name === "data") this.data.push(value);
    else if (name === "event") this.event = value;
    else if (name === "id" && !value.includes("\0")) this.id = value;
    else if (name === "retry" && /^\d+$/.test(value)) this.retryMs = Number(value);
    return null;
  }
}

/** Splits a byte stream into lines on CRLF, LF or CR, across chunk boundaries. */
export async function* readLines(body: ReadableStream<Uint8Array>): AsyncGenerator<string> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      for (;;) {
        const match = /\r\n|\n|\r/.exec(buffer);
        // A trailing CR may be the first half of CRLF: wait for the next chunk.
        if (!match || (match[0] === "\r" && match.index === buffer.length - 1)) break;
        yield buffer.slice(0, match.index);
        buffer = buffer.slice(match.index + match[0].length);
      }
    }
    buffer += decoder.decode();
    if (buffer) yield* buffer.split(/\r\n|\n|\r/);
  } finally {
    reader.releaseLock();
  }
}

export function backoffMs(failures: number, initialMs: number, maxMs: number, retryMs: number | null): number {
  const base = retryMs ?? initialMs;
  const delay = Math.min(maxMs, base * 2 ** (failures - 1));
  return delay + Math.random() * (delay / 10);
}
