#!/usr/bin/env node
// Bundles docs/guide into ONE self-contained HTML file for sharing (no folder, no server, works offline):
// stylesheets (with @import and url() fonts/images) and scripts are inlined, images and downloadable sample
// files become data: URIs. Usage: node scripts/bundle_guide.mjs [out.html]   (default: var/aidlc-guide.html)
import { mkdirSync, readFileSync, writeFileSync, existsSync, statSync } from 'node:fs';
import { dirname, extname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const GUIDE = join(ROOT, 'docs', 'guide');
const OUT = resolve(process.argv[2] ?? join(ROOT, 'var', 'aidlc-guide.html'));

const MIME = {
  '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf',
  '.md': 'text/markdown;charset=utf-8', '.yaml': 'text/yaml;charset=utf-8', '.yml': 'text/yaml;charset=utf-8',
  '.json': 'application/json', '.txt': 'text/plain;charset=utf-8', '.diff': 'text/x-diff;charset=utf-8',
  '.py': 'text/x-python;charset=utf-8', '.ts': 'text/plain;charset=utf-8', '.tsx': 'text/plain;charset=utf-8',
};

const isLocal = (ref) => ref && !/^(?:[a-z][a-z0-9+.-]*:|#|\/\/)/i.test(ref);
const resolveIn = (baseDir, ref) => {
  const path = resolve(baseDir, decodeURIComponent(ref.split(/[?#]/)[0]));
  if (!path.startsWith(GUIDE) || !existsSync(path) || !statSync(path).isFile()) {
    throw new Error(`unresolved local reference ${ref} (from ${relative(ROOT, baseDir) || '.'})`);
  }
  return path;
};
const dataUri = (path) =>
  `data:${MIME[extname(path).toLowerCase()] ?? 'application/octet-stream'};base64,${readFileSync(path).toString('base64')}`;

function inlineCss(path, seen = new Set()) {
  if (seen.has(path)) return '';
  seen.add(path);
  const dir = dirname(path);
  return readFileSync(path, 'utf8')
    .replace(/@import\s+(?:url\(\s*)?["']?([^"')\s]+)["']?\s*\)?\s*;/g, (m, ref) =>
      isLocal(ref) ? inlineCss(resolveIn(dir, ref), seen) : m)
    .replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/g, (m, q, ref) => (isLocal(ref) ? `url("${dataUri(resolveIn(dir, ref))}")` : m));
}

let html = readFileSync(join(GUIDE, 'index.html'), 'utf8');
const counts = { css: 0, js: 0, assets: 0 };
const deferred = [];

html = html.replace(/<link\b[^>]*\brel="stylesheet"[^>]*>/g, (tag) => {
  const ref = tag.match(/\bhref="([^"]+)"/)?.[1];
  if (!isLocal(ref)) return tag;
  counts.css++;
  return `<style>\n${inlineCss(resolveIn(GUIDE, ref)).replace(/<\/style/gi, '<\\/style')}\n</style>`;
});

html = html.replace(/<script\b([^>]*)\bsrc="([^"]+)"([^>]*)><\/script>/g, (tag, before, ref, after) => {
  if (!isLocal(ref)) return tag;
  counts.js++;
  // Inline scripts run in document order, so a deferred script moves to the end of <body> to keep its timing.
  const code = readFileSync(resolveIn(GUIDE, ref), 'utf8').replace(/<\/script/gi, '<\\/script');
  const attrs = `${before}${after}`.replace(/\s*\bdefer\b/, '').replace(/\s+/g, ' ').trimEnd();
  const inline = `<script${attrs}>\n${code}\n</script>`;
  if (/\bdefer\b/.test(before + after)) {
    deferred.push(inline);
    return '';
  }
  return inline;
});

html = html.replace(/\b(src|href)="([^"]+)"/g, (m, attr, ref) => {
  if (!isLocal(ref)) return m;
  counts.assets++;
  return `${attr}="${dataUri(resolveIn(GUIDE, ref))}"`;
});
html = html.replace('</body>', `${deferred.join('\n')}\n</body>`);

mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, html);
const mb = (statSync(OUT).size / 1024 / 1024).toFixed(1);
console.log(`wrote ${relative(process.cwd(), OUT)} (${mb} MB): ${counts.css} stylesheet(s), ${counts.js} script(s), ${counts.assets} embedded asset(s)`);
