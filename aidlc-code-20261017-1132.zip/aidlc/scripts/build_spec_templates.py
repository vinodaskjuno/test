"""Assemble the ready-to-fill spec templates (``templates/specs/<type>.md``) from ``templates/specs/parts/``."""

from __future__ import annotations

import argparse
from pathlib import Path

from aidlc.platform.spec_templates import TEMPLATE_TYPES, assemble, specs_dir


def build(out_dir: Path | None = None) -> list[Path]:
    target = out_dir or specs_dir()
    written = []
    for type_id in TEMPLATE_TYPES:
        path = target / f"{type_id}.md"
        path.write_text(assemble(type_id), encoding="utf-8")
        written.append(path)
    return written


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=None, help="directory to write to (default templates/specs)")
    args = parser.parse_args()
    for path in build(args.out):
        print(f"wrote {path}")


if __name__ == "__main__":
    main()
