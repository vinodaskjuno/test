"""Write the control-plane OpenAPI document to ``clients/openapi.json`` (input for the SDK and web UI generators)."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from aidlc.api.main import create_app
from aidlc.settings import ROOT

DEFAULT_OUT = ROOT / "clients" / "openapi.json"


def export(out: Path = DEFAULT_OUT) -> dict[str, Any]:
    spec = create_app().openapi()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
    return spec


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    spec = export(args.out)
    print(f"wrote {args.out} ({len(spec['paths'])} paths)")


if __name__ == "__main__":
    main()
