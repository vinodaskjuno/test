# AWS Setup for AIDLC Platform

## Quick Start

```bash
cd /Users/vinoth/github/aidlc
source .env.aws
./test-platform.sh
```

## What Was Updated

1. **test-platform.sh** - Now includes AWS credentials setup
2. **.env.aws** - Contains your AWS credentials (NOT committed to git)
3. **TESTING.md** - Updated documentation with AWS setup instructions

## Security Recommendations

### ⚠️ CRITICAL: Rotate Your Credentials

If you've shared AWS credentials in plain text anywhere (conversation, screenshot, etc.):

1. **Rotate credentials IMMEDIATELY:**
   ```bash
   # In AWS Console:
   # IAM → Users → <YOUR_USER> → Security credentials
   # → Access keys → Deactivate → Delete → Create new access key
   ```

2. **Update .env.aws with new credentials:**
   ```bash
   # Edit .env.aws with new keys
   nano .env.aws
   ```

### Best Practices Going Forward

1. **Never share credentials in conversations** - Use environment files
2. **Rotate credentials regularly** - Every 90 days minimum
3. **Use IAM roles when possible** - Instead of access keys (recommended for production)
4. **Consider AWS SSO** - More secure than access keys
5. **Enable MFA** - On your IAM user account
6. **Use AWS Secrets Manager** - For production deployments
7. **Store .env files securely** - Use git-crypt, sealed secrets, or similar

## Alternative Setup Methods

### Method 1: Environment Variables (Current)
```bash
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=us-east-1
./test-platform.sh
```

### Method 2: AWS CLI Profile
```bash
aws configure --profile aidlc
export AWS_PROFILE=aidlc
./test-platform.sh
```

### Method 3: AWS SSO (Most Secure)
```bash
aws configure sso
aws sso login --profile aidlc
export AWS_PROFILE=aidlc
./test-platform.sh
```

### Method 4: Fallback to Anthropic API
```bash
export ANTHROPIC_API_KEY=your_key_here
export AIDLC_BEDROCK_ENABLED=false
./test-platform.sh
```

## Verification

Test your AWS credentials:
```bash
aws sts get-caller-identity
```

Expected output:
```json
{
    "UserId": "...",
    "Account": "...",
    "Arn": "arn:aws:iam::...:user/..."
}
```

## Required AWS Permissions

For Bedrock access, ensure your IAM user has:
- `bedrock:InvokeModel`
- `bedrock:InvokeModelWithResponseStream`

Attach the `AmazonBedrockFullAccess` policy or create a custom policy:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": "arn:aws:bedrock:us-east-1::foundation-model/*"
    }
  ]
}
```

## Troubleshooting

### Credentials Not Working
```bash
# Check if credentials are set
echo $AWS_ACCESS_KEY_ID
echo $AWS_SECRET_ACCESS_KEY

# Test credentials
aws sts get-caller-identity

# Check Bedrock access
aws bedrock list-foundation-models --region us-east-1
```

### Worker Fails to Start
```bash
# Check worker logs
tail -f var/local/worker.log

# Verify Bedrock is enabled
echo $AIDLC_BEDROCK_ENABLED  # Should be "true"
```

### Access Denied Errors
- Verify IAM permissions for Bedrock
- Check that models are available in your region
- Ensure credentials haven't expired

## Next Steps

1. ✅ Rotate your AWS credentials (if shared)
2. ✅ Test the platform: `source .env.aws && ./test-platform.sh`
3. ✅ Run the full test suite: `./test-platform-ci.sh`
4. Consider setting up AWS SSO for better security
5. Enable CloudTrail for API call auditing
