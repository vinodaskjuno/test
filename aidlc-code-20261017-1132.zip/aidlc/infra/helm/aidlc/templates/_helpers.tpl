{{- define "aidlc.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "aidlc.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "aidlc.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "aidlc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/* Selector labels for one component: include "aidlc.selectorLabels" (dict "root" . "component" "api") */}}
{{- define "aidlc.selectorLabels" -}}
app.kubernetes.io/name: {{ include "aidlc.name" .root }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{- define "aidlc.platformImage" -}}
{{- printf "%s:%s" .Values.image.platform.repository (default .Chart.AppVersion .Values.image.platform.tag) -}}
{{- end -}}

{{- define "aidlc.webImage" -}}
{{- printf "%s:%s" .Values.image.web.repository (default .Chart.AppVersion .Values.image.web.tag) -}}
{{- end -}}

{{- define "aidlc.secretName" -}}
{{- if .Values.secrets.externalSecret.enabled -}}
{{- printf "%s-secrets" (include "aidlc.fullname" .) -}}
{{- else -}}
{{- required "secrets.existingSecret is required unless secrets.externalSecret.enabled" .Values.secrets.existingSecret -}}
{{- end -}}
{{- end -}}

{{- define "aidlc.serviceAccountName" -}}
{{- printf "%s-%s" (include "aidlc.fullname" .root) .component -}}
{{- end -}}

{{/* Env shared by api, worker and mcp: ConfigMap (plain) + Secret (sensitive). */}}
{{- define "aidlc.platformEnv" -}}
envFrom:
  - configMapRef:
      name: {{ include "aidlc.fullname" . }}-config
  - secretRef:
      name: {{ include "aidlc.secretName" . }}
{{- end -}}

{{/* Writable scratch dirs: the root filesystem is read-only. */}}
{{- define "aidlc.scratchVolumeMounts" -}}
- name: tmp
  mountPath: /tmp
- name: home
  mountPath: /home/aidlc
- name: data
  mountPath: /var/lib/aidlc
{{- end -}}
