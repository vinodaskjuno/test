import { beforeEach, describe, expect, it, vi } from "vitest";
import * as vscode from "vscode";

import { activate, HELLO_COMMAND } from "../src/extension";

function activateWithFakeContext(): { subscriptions: { dispose(): unknown }[] } {
  const context = { subscriptions: [] as { dispose(): unknown }[] };
  activate(context as unknown as vscode.ExtensionContext);
  return context;
}

describe("activate", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("registers the hello command and ties it to the extension's lifetime", () => {
    const context = activateWithFakeContext();
    expect(vscode.commands.registerCommand).toHaveBeenCalledWith(HELLO_COMMAND, expect.any(Function));
    expect(context.subscriptions).toHaveLength(1);
  });

  it("shows a greeting when the command runs", async () => {
    activateWithFakeContext();
    const [, callback] = vi.mocked(vscode.commands.registerCommand).mock.calls[0];
    await callback();
    expect(vscode.window.showInformationMessage).toHaveBeenCalledWith("Hello from App");
  });
});
