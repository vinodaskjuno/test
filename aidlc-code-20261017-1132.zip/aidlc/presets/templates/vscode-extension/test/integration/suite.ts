// Runs inside the VS Code extension host; a thrown error fails the test run.
import * as vscode from "vscode";

import { HELLO_COMMAND } from "../../src/extension";

export async function run(): Promise<void> {
  const extension = vscode.extensions.getExtension("app.app");
  if (!extension) {
    throw new Error("extension app.app is not loaded in the test instance");
  }
  await extension.activate();
  const commands = await vscode.commands.getCommands(true);
  if (!commands.includes(HELLO_COMMAND)) {
    throw new Error(`${HELLO_COMMAND} is not registered`);
  }
}
