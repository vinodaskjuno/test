// Downloads VS Code (cached in .vscode-test/), loads this extension into it and runs out/integration/suite.js.
import * as path from "node:path";

import { runTests } from "@vscode/test-electron";

async function main(): Promise<void> {
  await runTests({
    extensionDevelopmentPath: path.resolve(__dirname, "../.."),
    extensionTestsPath: path.resolve(__dirname, "suite.js"),
    launchArgs: ["--disable-extensions"],
  });
}

main().catch((error: unknown) => {
  console.error(error);
  process.exit(1);
});
