// The subset of the `vscode` API the unit tests exercise; vitest.config.ts aliases `vscode` to this module.
import { vi } from "vitest";

export const commands = {
  registerCommand: vi.fn((_command: string, _callback: (...args: unknown[]) => unknown) => ({ dispose: vi.fn() })),
};

export const window = {
  showInformationMessage: vi.fn(async (_message: string) => undefined),
};
