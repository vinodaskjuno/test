// Bundles the extension to dist/extension.js (CommonJS, `vscode` provided by the extension host).
// Flags: --production (minify, no source maps), --watch (rebuild on change), --integration (also bundle the
// @vscode/test-electron runner and suite to out/integration/).
import * as esbuild from "esbuild";

const production = process.argv.includes("--production");
const watch = process.argv.includes("--watch");
const integration = process.argv.includes("--integration");

const common = {
  bundle: true,
  format: "cjs",
  platform: "node",
  target: "node20",
  external: ["vscode"],
  sourcemap: !production,
  minify: production,
  logLevel: "info",
};

const builds = [{ ...common, entryPoints: ["src/extension.ts"], outfile: "dist/extension.js" }];
if (integration) {
  builds.push({
    ...common,
    entryPoints: ["test/integration/runTest.ts", "test/integration/suite.ts"],
    outdir: "out/integration",
    packages: "external",
  });
}

if (watch) {
  for (const options of builds) {
    await (await esbuild.context(options)).watch();
  }
} else {
  await Promise.all(builds.map((options) => esbuild.build(options)));
}
