# Conventions

## TypeScript
- Strict TypeScript; `npm run typecheck` clean.
- `src/extension.ts` only wires `activate()`; commands, views and providers live in their own modules under `src/`.
- Every disposable is pushed onto `context.subscriptions`.
- Every command is declared in `package.json` `contributes.commands` with the `App` category and an `app.` id.

## Tests
- Unit tests under `test/` run in vitest; `vscode` resolves to `test/__mocks__/vscode.ts`, extended as needed.
- Integration tests under `test/integration/` run in a downloaded VS Code through `@vscode/test-electron`.

## Releases
- User-visible changes add an entry to `CHANGELOG.md` and bump `version` in `package.json`.
- `npm run package` builds `dist/app.vsix`; it is distributed privately, never published to the Marketplace.

## Git
- Conventional commits; branch from and merge into `main`; CI (`.github/workflows/ci.yml`) must pass.
