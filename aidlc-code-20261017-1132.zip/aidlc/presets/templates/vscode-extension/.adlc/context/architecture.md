# Architecture

```
VS Code extension host --require--> dist/extension.js (esbuild bundle of src/) --> vscode API
```

- `src/extension.ts` — `activate(context)` registers commands and pushes every disposable onto
  `context.subscriptions`; `deactivate()` is called on shutdown.
- `package.json` `contributes` declares every command, setting and view; VS Code activates the extension when one
  of its commands runs.
- `esbuild.mjs` bundles `src/` (with `vscode` external) to CommonJS; `--production` minifies for packaging.
- Webviews, language features and settings are added by the first feature that needs them and recorded as an ADR in
  `.adlc/specs/`.
