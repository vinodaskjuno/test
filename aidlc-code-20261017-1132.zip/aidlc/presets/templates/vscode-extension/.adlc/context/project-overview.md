# Project overview

A new VS Code extension created from the AIDLC `vscode-extension` preset. Replace this paragraph with what the
extension does, who uses it and why; the platform's agents read this file before every change.

- **src/** — extension source; `src/extension.ts` is the entry point bundled to `dist/extension.js`.
- **test/** — vitest unit tests against a mocked `vscode` API; `test/integration/` runs inside a real VS Code.
- Distributed privately as `dist/app.vsix` (`npm run package`), not through the Marketplace.
