import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: { alias: { vscode: fileURLToPath(new URL("test/__mocks__/vscode.ts", import.meta.url)) } },
  test: {
    include: ["test/**/*.test.ts"],
    environment: "node",
    coverage: { provider: "v8", include: ["src/**"], reporter: ["text", "json-summary", "lcov"] },
  },
});
