# App

Created from the AIDLC `vscode-extension` preset: a Visual Studio Code extension in TypeScript, bundled with esbuild
into `dist/extension.js` and packaged as a `.vsix` for private distribution.

| Task | Command |
|---|---|
| Install | `npm install` |
| Build (and rebuild on change) | `npm run build` (`npm run watch`) |
| Typecheck | `npm run typecheck` |
| Unit tests (vitest, mocked `vscode` API) | `npm test` |
| Integration tests (real VS Code via `@vscode/test-electron`) | `npm run test:integration` |
| Package | `npm run package` → `dist/app.vsix` |

Install the packaged extension with `code --install-extension dist/app.vsix`. Press F5 in VS Code with this folder
open to run it in an Extension Development Host. On headless Linux, run the integration tests under `xvfb-run -a`.

## Commands

| Command | Id |
|---|---|
| App: Hello World | `app.helloWorld` |

CI runs typecheck, both test suites and packaging on every pull request and keeps the `.vsix` as a build artifact.
Specs, plans and lessons for this repo live under `.adlc/`; see `.adlc/context/` for the overview, architecture and
conventions the AIDLC agents follow.
