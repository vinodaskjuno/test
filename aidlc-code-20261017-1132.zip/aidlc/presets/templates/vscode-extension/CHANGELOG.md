# Changelog

## 0.1.0

- Initial release: the `App: Hello World` command.
