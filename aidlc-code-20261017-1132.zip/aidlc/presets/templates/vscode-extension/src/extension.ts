import * as vscode from "vscode";

export const HELLO_COMMAND = "app.helloWorld";

export function activate(context: vscode.ExtensionContext): void {
  context.subscriptions.push(
    vscode.commands.registerCommand(HELLO_COMMAND, () => vscode.window.showInformationMessage("Hello from App")),
  );
}

// VS Code disposes everything on context.subscriptions itself; there is no other state to release.
export function deactivate(): void {}
