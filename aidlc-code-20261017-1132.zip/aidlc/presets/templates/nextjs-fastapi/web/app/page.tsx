export default function Home() {
  return (
    <>
      <h1>It works</h1>
      <p>Edit <code>web/app/page.tsx</code> to get started. The API health check is at <code>/health</code>.</p>
    </>
  );
}
