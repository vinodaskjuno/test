import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import Home from "@/app/page";

describe("Home", () => {
  it("renders a single top-level heading", () => {
    const html = renderToStaticMarkup(<Home />);
    expect(html.match(/<h1>/g)).toHaveLength(1);
    expect(html).toContain("It works");
  });
});
