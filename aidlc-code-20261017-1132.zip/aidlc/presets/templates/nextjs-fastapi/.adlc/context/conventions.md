# Conventions

## Python (api/)
- Python 3.12, type hints everywhere, `from __future__ import annotations`.
- `ruff check` and `ruff format` clean (config in `api/pyproject.toml`).
- Thin routes in `app/routes/<resource>.py`; business logic in `app/services/`; persistence in `app/repositories/`.
- pytest with FastAPI `TestClient`; tests never call real external services.

## TypeScript (web/)
- Strict TypeScript, `npm run typecheck` clean.
- Server components fetch data; components under `components/` receive props.
- vitest tests under `web/tests/`.
- WCAG 2.2 AA: labelled form fields, `alt` on images, visible focus.

## Git
- Conventional commits; branch from and merge into `main`; CI (`.github/workflows/ci.yml`) must pass.
