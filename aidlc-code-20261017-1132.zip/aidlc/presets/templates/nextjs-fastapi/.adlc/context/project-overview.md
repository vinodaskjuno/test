# Project overview

A new product created from the AIDLC `nextjs-fastapi` preset. Replace this paragraph with what the product does,
who uses it and why; the platform's agents read this file before every change.

- **api/** — FastAPI backend (`uvicorn --factory app.main:create_app`).
- **web/** — Next.js (App Router, TypeScript) frontend.
