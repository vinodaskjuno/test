# Architecture

```
browser --> web (Next.js, server components) --HTTP--> api (FastAPI)
```

- `api/app/main.py` — `create_app(settings)` factory; routers are added under `api/app/routes/`.
- `api/app/settings.py` — `Settings` from `APP_*` environment variables.
- `web/app/` — App Router pages; shared UI goes in `web/components/`, API helpers in `web/lib/`.
- Persistence is chosen by the first feature that needs it and recorded as an ADR in `.adlc/specs/`.
