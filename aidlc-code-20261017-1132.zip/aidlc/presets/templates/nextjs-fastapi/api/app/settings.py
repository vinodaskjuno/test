"""Configuration from ``APP_*`` environment variables."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="APP_")

    environment: str = "dev"
    cors_origins: list[str] = ["http://localhost:3000"]
