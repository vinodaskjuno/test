# App

Created from the AIDLC `nextjs-fastapi` preset.

| Part | Run | Test |
|---|---|---|
| `api/` (FastAPI) | `pip install -e "api[dev]" && cd api && uvicorn --factory app.main:create_app --reload` | `cd api && pytest -q` |
| `web/` (Next.js) | `cd web && npm install && npm run dev` | `cd web && npm test` |

CI runs both on every pull request. Specs, plans and lessons for this repo live under `.adlc/`; see
`.adlc/context/` for the overview, architecture and conventions the AIDLC agents follow.
