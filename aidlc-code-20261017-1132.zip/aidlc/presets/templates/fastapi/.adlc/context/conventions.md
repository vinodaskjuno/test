# Conventions

## Python
- Python 3.12, type hints everywhere, `from __future__ import annotations`.
- `ruff check` and `ruff format` clean (config in `pyproject.toml`).
- Thin routes in `app/routes/<resource>.py`; business logic in `app/services/`; persistence in `app/repositories/`.
- Request and response bodies are Pydantic models.

## Tests
- pytest with FastAPI `TestClient` against `create_app()`; tests mirror the module path under `tests/`.
- Tests never call real external services.

## Git
- Conventional commits; branch from and merge into `main`; CI (`.github/workflows/ci.yml`) must pass.
