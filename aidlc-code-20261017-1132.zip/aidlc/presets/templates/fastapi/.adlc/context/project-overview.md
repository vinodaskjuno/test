# Project overview

A new service created from the AIDLC `fastapi` preset. Replace this paragraph with what the service does,
who calls it and why; the platform's agents read this file before every change.

- **app/** — FastAPI application (`uvicorn --factory app.main:create_app`).
- **tests/** — pytest suite using FastAPI's `TestClient`.
