# Architecture

```
client --HTTP--> uvicorn --> app (FastAPI, create_app factory)
```

- `app/main.py` — `create_app()` factory; routers are added under `app/routes/`.
- Business logic goes in `app/services/`, persistence in `app/repositories/`.
- Configuration, persistence and authentication are chosen by the first feature that needs them and recorded as an
  ADR in `.adlc/specs/`.
