# App

Created from the AIDLC `fastapi` preset: a Python 3.12 FastAPI service managed with [uv](https://docs.astral.sh/uv/).

| Task | Command |
|---|---|
| Install | `uv sync --extra dev` |
| Run | `uv run uvicorn --factory app.main:create_app --reload` |
| Test | `uv run pytest -q` |
| Lint | `uv run ruff check . && uv run ruff format --check .` |

Without uv: `python3 -m venv .venv && .venv/bin/pip install -e ".[dev]"`, then `.venv/bin/pytest -q`.

CI runs lint and tests on every pull request. Specs, plans and lessons for this repo live under `.adlc/`; see
`.adlc/context/` for the overview, architecture and conventions the AIDLC agents follow.
