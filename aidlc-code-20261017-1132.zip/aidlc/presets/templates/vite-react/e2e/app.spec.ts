import { expect, test } from "@playwright/test";

test("home page renders the heading and counts clicks", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("It works");
  await page.getByRole("button", { name: "Clicked 0 times" }).click();
  await expect(page.getByRole("button", { name: "Clicked 1 time" })).toBeVisible();
});
