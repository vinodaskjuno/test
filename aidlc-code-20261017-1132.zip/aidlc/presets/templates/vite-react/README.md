# App

Created from the AIDLC `vite-react` preset: a React 18 single-page app in strict TypeScript, built with Vite 5.

| Task | Command |
|---|---|
| Install | `npm install` |
| Develop | `npm run dev` |
| Lint and typecheck | `npm run lint && npm run typecheck` |
| Unit tests (vitest + Testing Library) | `npm test` |
| End-to-end tests (Playwright) | `npx playwright install chromium && npx playwright test` |
| Production build | `npm run build && npm run preview` |

CI runs lint, typecheck, tests and the build on every pull request. Specs, plans and lessons for this repo live under
`.adlc/`; see `.adlc/context/` for the overview, architecture and conventions the AIDLC agents follow.
