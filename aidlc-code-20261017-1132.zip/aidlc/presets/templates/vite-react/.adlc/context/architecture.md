# Architecture

```
browser --> index.html --> src/main.tsx --> <App /> (React, client-side rendering)
```

- `src/main.tsx` — mounts `<App />` into `#root` under `StrictMode`.
- `src/App.tsx` — top-level component; shared UI goes in `src/components/`, server calls in `src/api/`.
- `vite.config.ts` — build and vitest configuration (jsdom, Testing Library setup in `src/test-setup.ts`).
- Routing, state management and the backend contract are chosen by the first feature that needs them and recorded
  as an ADR in `.adlc/specs/`.
