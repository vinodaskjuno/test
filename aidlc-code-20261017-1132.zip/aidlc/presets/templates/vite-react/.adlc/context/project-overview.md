# Project overview

A new product created from the AIDLC `vite-react` preset. Replace this paragraph with what the product does,
who uses it and why; the platform's agents read this file before every change.

- **src/** — React 18 single-page app (TypeScript, Vite 5); entry point `src/main.tsx`.
- **e2e/** — Playwright specs run against the production build.
