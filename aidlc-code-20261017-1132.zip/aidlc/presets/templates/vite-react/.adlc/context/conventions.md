# Conventions

## TypeScript and React
- Strict TypeScript; `npm run typecheck` and `npm run lint` clean.
- Function components with named exports; one component per file.
- Server calls go through `src/api/`; components receive data through props or hooks.
- WCAG 2.2 AA: labelled form fields, `alt` on images, visible focus, keyboard-operable controls.

## Tests
- vitest + Testing Library tests next to the code as `*.test.tsx`; query by role or label, not by class or test id.
- Playwright specs under `e2e/` run against `vite preview` of the production build.
- Tests never call real external services.

## Git
- Conventional commits; branch from and merge into `main`; CI (`.github/workflows/ci.yml`) must pass.
