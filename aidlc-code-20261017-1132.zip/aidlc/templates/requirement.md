---
# Template: .adlc/specs/{{req_id}}-{{slug}}/requirement.md (written by the Spec Analyst, gated by V1).
# Placeholders:
#   {{req_id}}               requirement id allocated by the platform, e.g. REQ-007
#   {{slug}}                 kebab-case short title used in the folder name
#   {{title}}                one-line title
#   {{status}}               draft | validated | in-progress | pr-ready | blocked
#   {{repos}}                YAML list of repo ids from .adlc/config.yml, e.g. [api, web]
#   {{tags}}                 YAML list of tags from .adlc/templates/taxonomy.md
#   {{created}}              ISO-8601 date
#   {{requested_by}}         requester identity (email or handle)
#   {{sources}}              YAML list of source document names (as cited below)
#   {{summary}}              two to five sentences: problem, who benefits, outcome
#   {{acceptance_criteria}}  one "### AC-n" block per criterion, each with its verbatim source quote(s)
#   {{nfrs}}, {{out_of_scope}}, {{assumptions}}, {{open_questions}}  Markdown bullet lists ("- None." when empty)
id: {{req_id}}
title: {{title}}
kind: feature
status: {{status}}
repos: {{repos}}
tags: {{tags}}
created: {{created}}
requested_by: {{requested_by}}
sources: {{sources}}
---

# {{req_id}}: {{title}}

## Summary
{{summary}}

## Acceptance criteria
<!-- Each criterion is observable and atomic, and cites the exact source text it comes from:
### AC-1: <criterion text>
> "<verbatim quote>" (source: <source name>)
-->
{{acceptance_criteria}}

## Non-functional requirements
{{nfrs}}

## Out of scope
{{out_of_scope}}

## Assumptions
{{assumptions}}

## Open questions
{{open_questions}}
