---
# Template: .adlc/knowledge/assumptions/{{assume_id}}.md (written by Knowledge Capture from assumptions made during
# spec, planning or development that a human has not yet confirmed).
# Placeholders:
#   {{assume_id}}   id allocated by the platform, e.g. ASSUME-004
#   {{title}}       the assumption as one declarative sentence
#   {{status}}      open | confirmed | rejected
#   {{tags}}        YAML list of tags from taxonomy.md
#   {{origin}}      run or requirement id where the assumption was made
#   {{created}}     ISO-8601 date
#   {{statement}}   the assumption in full, including its scope
#   {{rationale}}   why it was reasonable given the available sources
#   {{impact}}      what changes (code, ACs, tests) if it turns out to be wrong
#   {{confirm_with}} who or what can confirm it (role, document, system)
id: {{assume_id}}
title: {{title}}
status: {{status}}
tags: {{tags}}
origin: {{origin}}
created: {{created}}
---

# {{assume_id}}: {{title}}

## Statement
{{statement}}

## Rationale
{{rationale}}

## Impact if wrong
{{impact}}

## How to confirm
{{confirm_with}}
