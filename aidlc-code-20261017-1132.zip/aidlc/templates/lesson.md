---
# Template: .adlc/knowledge/lessons/{{lesson_id}}.md (written by Knowledge Capture; retrieved by the Knowledge
# Curator and the Reflector in later runs).
# Placeholders:
#   {{lesson_id}}     id allocated by the platform, e.g. LESSON-021
#   {{title}}         the lesson as one imperative sentence
#   {{tags}}          YAML list of tags from taxonomy.md (at least one domain tag and one kind tag)
#   {{origin}}        run or requirement id the lesson came from, e.g. REQ-007
#   {{created}}       ISO-8601 date
#   {{context}}       where this applies (component, layer, technology)
#   {{what_happened}} the surprise, failure or costly retry that taught the lesson
#   {{lesson}}        the durable rule, stated so it can be followed without the original context
#   {{how_to_apply}}  concrete check or pattern to use next time (code reference if useful)
id: {{lesson_id}}
title: {{title}}
tags: {{tags}}
origin: {{origin}}
created: {{created}}
---

# {{lesson_id}}: {{title}}

## Context
{{context}}

## What happened
{{what_happened}}

## Lesson
{{lesson}}

## How to apply
{{how_to_apply}}
