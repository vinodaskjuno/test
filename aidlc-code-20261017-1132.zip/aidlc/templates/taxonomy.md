<!--
Template: .adlc/templates/taxonomy.md — the controlled tag vocabulary for requirements, bugs, lessons and
assumptions. Knowledge Capture may only use tags listed here; the Knowledge Curator retrieves by them.
Placeholders:
  {{project_name}}   project display name
  {{domain_tags}}    Markdown bullet list of project-specific domain tags ("- `domain:<name>` — <meaning>")
Projects extend the "Domain" section; the other sections are shared across projects and should change rarely.
Tags are lowercase kebab-case, written as `<facet>:<value>`.
-->
# Tag taxonomy — {{project_name}}

## Kind (exactly one per lesson or assumption)
- `kind:pitfall` — a mistake that was made and fixed
- `kind:pattern` — an approach that worked and should be reused
- `kind:constraint` — a hard limit of the system, platform or organisation
- `kind:decision` — a design decision and its reason
- `kind:process` — how work flows (reviews, releases, ownership)

## Layer
- `layer:api` — HTTP/RPC interface and request handling
- `layer:service` — business logic
- `layer:data` — persistence, schema, migrations, queries
- `layer:ui` — pages, components, client state
- `layer:integration` — third-party systems and cross-repo contracts
- `layer:infra` — CI/CD, containers, infrastructure-as-code
- `layer:test` — test code, fixtures, environments

## Concern
- `concern:security` — authn, authz, secrets, injection, data exposure
- `concern:privacy` — personal data handling, retention, redaction
- `concern:performance` — latency, throughput, resource use
- `concern:reliability` — error handling, retries, idempotency, timeouts
- `concern:concurrency` — locking, races, ordering
- `concern:accessibility` — WCAG conformance
- `concern:compatibility` — backward compatibility, API versioning, migrations
- `concern:observability` — logging, metrics, tracing
- `concern:cost` — paid API and LLM usage, infrastructure spend

## Stage (where in the pipeline it surfaced)
- `stage:spec` · `stage:plan` · `stage:dev` · `stage:test` · `stage:review` · `stage:ci` · `stage:feedback`

## Domain (project-specific)
{{domain_tags}}
