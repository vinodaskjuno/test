---
# Template: .adlc/bugs/{{bug_id}}-{{slug}}.md (written by Intake/Debugger for the bugfix workflow, or by the
# Backlog Writer from health-audit findings).
# Placeholders:
#   {{bug_id}}          bug id allocated by the platform, e.g. BUG-012
#   {{slug}}            kebab-case short title
#   {{title}}           one-line title
#   {{severity}}        critical | high | medium | low
#   {{status}}          open | reproduced | fixed | wont-fix
#   {{repos}}           YAML list of affected repo ids
#   {{tags}}            YAML list of tags from taxonomy.md
#   {{created}}         ISO-8601 date
#   {{reported_by}}     reporter identity or "health-audit"
#   {{observed}}        what happens
#   {{expected}}        what should happen
#   {{steps}}           numbered reproduction steps
#   {{environment}}     versions, configuration, data conditions
#   {{reproduction_test}}  path and name of the failing test that reproduces the bug
#   {{root_cause}}      root-cause analysis (filled after diagnosis)
#   {{acceptance_criteria}}  "### AC-n" blocks defining the fixed behaviour
#   {{source_findings}} Markdown bullet list of finding ids this bug was drafted from (audits only)
id: {{bug_id}}
title: {{title}}
kind: bug
severity: {{severity}}
status: {{status}}
repos: {{repos}}
tags: {{tags}}
created: {{created}}
reported_by: {{reported_by}}
---

# {{bug_id}}: {{title}}

## Observed behaviour
{{observed}}

## Expected behaviour
{{expected}}

## Steps to reproduce
{{steps}}

## Environment
{{environment}}

## Reproduction test
{{reproduction_test}}

## Root cause
{{root_cause}}

## Acceptance criteria
{{acceptance_criteria}}

## Source findings
{{source_findings}}
