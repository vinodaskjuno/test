<!--
Template: .adlc/context/project-overview.md (generated during repo onboarding by the Docs agent from the repository
profile; maintained by humans afterwards). Agents read it to learn the product's vocabulary and boundaries.
Placeholders:
  {{project_name}}   project display name
  {{purpose}}        what the product does and for whom (one paragraph)
  {{users}}          Markdown bullet list of user roles and what each needs
  {{capabilities}}   Markdown bullet list of the main capabilities or features
  {{repos}}          Markdown table rows "| <repo id> | <role> | <primary language> |"
  {{glossary}}       Markdown bullet list "- **Term** — meaning"
  {{boundaries}}     Markdown bullet list of what the product deliberately does not do
  {{contacts}}       Markdown bullet list of owning teams or code owners
-->
# {{project_name}} — project overview

## Purpose
{{purpose}}

## Users
{{users}}

## Main capabilities
{{capabilities}}

## Repositories
| Repo id | Role | Primary language |
|---|---|---|
{{repos}}

## Glossary
{{glossary}}

## Boundaries
{{boundaries}}

## Owners
{{contacts}}
