<!--
Template: architecture document. Used twice:
  - .adlc/context/architecture.md — the system as it is (generated at onboarding, kept current by humans).
  - .adlc/specs/{{req_id}}-{{slug}}/architecture.md — the design for one requirement (Solution Architect, V2-gated).
Placeholders:
  {{title}}            "System architecture" or "<REQ id>: <title>"
  {{context}}          problem statement and constraints this design answers
  {{components}}       Markdown table rows "| <component> | <repo> | <responsibility> |"
  {{diagram}}          a Mermaid or ASCII diagram of components and data flow
  {{data_flow}}        numbered walk-through of the main request or event flow
  {{contracts}}        APIs, events and schemas between components and repos (link openapi.yaml when present)
  {{data_model}}       entities, ownership and migration notes
  {{cross_cutting}}    security, privacy, performance, observability and failure handling
  {{adr}}              architecture decision record: Context / Decision / Alternatives / Consequences
  {{risks}}            Markdown bullet list of risks with mitigations
-->
# {{title}}

## Context
{{context}}

## Components
| Component | Repo | Responsibility |
|---|---|---|
{{components}}

## Diagram
{{diagram}}

## Data flow
{{data_flow}}

## Contracts
{{contracts}}

## Data model
{{data_model}}

## Cross-cutting concerns
{{cross_cutting}}

## Decision record
{{adr}}

## Risks
{{risks}}
