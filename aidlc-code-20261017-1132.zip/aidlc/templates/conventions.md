<!--
Template: .adlc/context/conventions.md — the coding conventions agents must follow and the Maintainability Reviewer
and Convention Auditor enforce. Seeded at onboarding from the stack preset's `conventions` and the observed code;
humans own it afterwards. Write rules that can be checked: "X must/never Y", with an example where useful.
Placeholders:
  {{project_name}}   project display name
  {{layout}}         Markdown bullet list: where code, tests, configuration and docs live
  {{naming}}         Markdown bullet list: file, module, type, function and test naming rules
  {{style}}          Markdown bullet list: formatter/linter settings and language-specific rules
  {{errors}}         Markdown bullet list: error handling, logging and retry rules
  {{testing}}        Markdown bullet list: test levels, fixtures, mocking policy, AC-id test naming
  {{security}}       Markdown bullet list: secrets, input validation, authz checks, PII handling
  {{git}}            Markdown bullet list: branch names, commit message format, PR expectations
  {{exceptions}}     Markdown bullet list of accepted deviations, each with its reason
-->
# Conventions — {{project_name}}

## Layout
{{layout}}

## Naming
{{naming}}

## Style and tooling
{{style}}

## Errors, logging and retries
{{errors}}

## Testing
- Every acceptance criterion is proven by at least one test whose name carries the AC id
  (`test_ac_3_...` in Python, `"AC-3: ..."` in JavaScript/TypeScript test titles).
{{testing}}

## Security and privacy
{{security}}

## Git and pull requests
- Commits follow Conventional Commits (`type(scope): subject`) and reference the requirement (`Refs: REQ-xxx`).
{{git}}

## Accepted exceptions
{{exceptions}}
