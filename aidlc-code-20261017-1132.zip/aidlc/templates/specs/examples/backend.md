# Storefront: change an order's status

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · backend |
| Title | Storefront order status updates (API) |
| Project | existing |
| Project id | storefront |
| Repositories | storefront |
| Surfaces | backend, data |
| Stack preset | nextjs-fastapi |
| Stack exceptions | none |
| Jira | SHOP-214 |
| Priority | P2 |
| Target release | 2026.11 |
| Business sponsor | Grace Lin |
| Product owner | Tom Hale |
| Tech lead | Ana Costa |
| Data classification | Confidential |
| PII categories | name, email |
| Compliance regimes | NYDFS 500 |
| Risk tier | medium |
| Run budget (USD) | 30 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Orders are created as pending and never change, so the fulfilment team edits the database by hand to mark orders
paid, shipped or cancelled. A status-update endpoint with the allowed transitions removes the manual edits and the
mistakes they cause, such as shipping a cancelled order.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Fulfilment system | The warehouse integration and support tools | Change an order's status through the API |

### 3. Scope

**In scope**

- PATCH /orders/{order_id}/status with the allowed transitions, and a status_changed_at field on orders.

**Out of scope**

- The web orders table (a separate spec), audit trail of who changed a status, customer notifications, refunds.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | PATCH /orders/{order_id}/status with {"status": "<new>"} changes the status and returns 200 with the order | Must |
| FR-2 | Only these changes are allowed: pending to paid or cancelled; paid to shipped or cancelled. shipped and cancelled are final | Must |
| FR-3 | Orders have status_changed_at: null until the first change, then the UTC time of the latest change | Must |
| FR-4 | Two concurrent changes of the same order end with exactly one success | Must |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1, FR-3 | order 1 is pending | a client sends {"status": "paid"} | 200, status paid and status_changed_at set |
| AS-2 | FR-2 | order 1 is paid | a client sends {"status": "pending"} | 409 with "cannot change order 1 from paid to pending" and the order is unchanged |
| AS-3 | FR-1 | no order 999 | a client changes order 999 | 404 with "order 999 not found" |
| AS-4 | FR-1 | order 1 exists | a client sends {"status": "lost"} | 422 |
| AS-5 | FR-3 | a database created before this change | the API starts | it starts and existing orders return status_changed_at null |
| AS-6 | FR-4 | order 1 is pending | two clients send paid and cancelled at the same time | one gets 200, the other 409 naming the status it lost to |

### 6. Business rules and data

N/A — the transitions in FR-2 are the only rules.

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Manual database edits per week | about 30 | 0 | database change log |

## Part B — Technical (owner: Tech lead)

### 8. Current system

The FastAPI service in api/: api/app/routes/orders.py (list, get, create), api/app/repository.py (SQLite through
sqlite3 with a lock), api/app/models.py (OrderStatus is pending, paid, shipped or cancelled). Existing endpoints and
their tests must keep passing unchanged.

### 9. New project setup

N/A — existing project.

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| PATCH | /orders/{order_id}/status | internal services | {"status": "pending, paid, shipped or cancelled"} | 200 and the order including status_changed_at |
| GET | /orders and /orders/{order_id} | internal services | unchanged | the order now includes status_changed_at |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| unknown order | 404 | order <id> not found |
| change not allowed | 409 | cannot change order <id> from <current> to <new> |
| unknown status | 422 | FastAPI validation error list |

### B3. Authorisation

Unchanged: the service is reachable only from the internal network through the existing gateway.

### B4. Compatibility and versioning

Adding status_changed_at to the order response is additive; no consumer breaks. No version change.

### B5. Limits and performance

N/A — same limits as the existing endpoints.

### B6. Events and messages

N/A — no events.

## Data add-on (owner: Tech lead with the data owner)

### D1. Entities and schema changes

| Table or entity | Change | Columns (type, null, default) | Indexes and constraints |
|---|---|---|---|
| orders | add | status_changed_at TEXT NULL (ISO 8601 UTC) | none |

### D2. Migration and backfill

On startup the repository adds the column when it is missing (ALTER TABLE orders ADD COLUMN), before serving
requests. No backfill: existing orders keep null.

### D3. Rollback

The previous build ignores the extra column, so rolling back the code needs no down migration; the column stays.

### D4. Retention and volumes

| Item | Value |
|---|---|
| Rows today and growth | about 80,000, +5,000 a month |
| Retention | unchanged |
| Deletion or archival | unchanged |
| Personal data columns | customer_name, customer_email (existing) |

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | Status change response time | p95 at most 100 ms |
| NFR-2 | Security | Personal data in logs | no customer name or e-mail in any log line |

### 11. Data and privacy

The endpoint returns the whole order, which includes the customer's name and e-mail, as the existing endpoints do.
No new personal data is stored; logs record only the order id and the statuses.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NYDFS 500 | 500.06 audit trail of changes to nonpublic information | each change is logged with order id, old and new status and time |

### 13. Rollout and compatibility

No flag: the endpoint is new and unused until the fulfilment system adopts it. Deploy the API first; rollback is the
previous image.

### 14. Test expectations

API tests for every allowed change, one rejected change from each final status, the 404, the 422, the concurrent
change of AS-6 and the column upgrade of AS-5 on a database created without the column.

### 15. Increments

N/A — one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | The fulfilment system calls the new endpoint from release 2026.12 | Tom Hale |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Tom Hale | 12 Oct 2026 |
| Tech lead | Ana Costa | 12 Oct 2026 |
