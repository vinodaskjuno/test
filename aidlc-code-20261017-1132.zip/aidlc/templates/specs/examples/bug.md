# Placing an order hangs when the inventory service is down

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · bug |
| Title | Placing an order hangs forever when the inventory service is down |
| Project id | storefront |
| Repositories | storefront |
| Surfaces | backend |
| Jira | SHOP-260 |
| Severity | high |
| Priority | P1 |
| Found in version | orders-api 0.4.0 |
| Reported by | On-call SRE |
| Data classification | Confidential |
| PII categories | name, email |
| Risk tier | medium |
| Run budget (USD) | 15 |

## Bug report

### 1. Observed behaviour

With the production retry settings, POST /orders never returns while the inventory service is unavailable. The load
balancer gives up after 60 seconds, the API keeps retrying in the background about every half second, and with
enough such requests the API runs out of worker threads and stops answering every endpoint, including /health.

### 2. Expected behaviour

After ORDERS_RETRY_ATTEMPTS failed attempts in total, the request returns 503 with
{"detail": "inventory service unavailable"}. The waits double from the base delay and never exceed the maximum
delay. No order is stored.

### 3. Steps to reproduce

1. Point ORDERS_INVENTORY_URL at a closed port, for example http://localhost:9999.
2. Start the API with ORDERS_RETRY_ATTEMPTS=10, ORDERS_RETRY_BASE_DELAY_S=0.05 and ORDERS_RETRY_MAX_DELAY_S=0.5.
3. POST /orders with {"customer_name": "Ada", "customer_email": "ada@shop.example", "sku": "BOOK-001", "quantity": 1, "total_cents": 2299}.

### 4. Environment

| Item | Value |
|---|---|
| Version or commit | orders-api 0.4.0 |
| Configuration | ORDERS_RETRY_ATTEMPTS=10, ORDERS_RETRY_BASE_DELAY_S=0.05, ORDERS_RETRY_MAX_DELAY_S=0.5 |
| Platform | Linux container, Python 3.12 |

### 5. Impact

| Item | Value |
|---|---|
| Who is affected | every customer placing an order during an inventory outage |
| How often | every order request while inventory is down |
| Business impact | the storefront stops taking orders and the API stops answering health checks |

### 6. Workaround

Set ORDERS_RETRY_MAX_DELAY_S above the largest delay the attempts reach (for example 10), which avoids the hang.

### 7. Evidence

The inventory stub's access log shows a POST /reservations every 0.5 seconds with no end. Also reproducible with
ORDERS_RETRY_BASE_DELAY_S=1.0 and ORDERS_RETRY_MAX_DELAY_S=1.0 and the default 3 attempts.

### 8. Acceptance scenarios

| ID | Related | Given | When | Then |
|---|---|---|---|---|
| AS-1 | — | the settings from the steps and inventory down | an order is placed | exactly 10 attempts, then 503 {"detail": "inventory service unavailable"} |
| AS-2 | — | a base delay equal to or greater than the maximum delay | an order is placed with inventory down | the attempts never exceed ORDERS_RETRY_ATTEMPTS |
| AS-3 | — | the default settings and inventory down | an order is placed | 3 attempts, then the same 503, as today |
| AS-4 | — | inventory answers 409 out of stock | an order is placed | 409 immediately, with no retry |
