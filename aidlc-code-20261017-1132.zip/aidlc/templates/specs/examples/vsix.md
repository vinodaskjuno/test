# AIG Prompt Snippets for VS Code

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · vsix |
| Title | AIG Prompt Snippets VS Code extension |
| Project | new |
| Project id | prompt-snippets |
| Repositories | app |
| Surfaces | vsix |
| Stack preset | vscode-extension |
| Stack exceptions | none |
| Jira | AIGDX-41 |
| Priority | P3 |
| Target release | 2026.12 |
| Business sponsor | Marcus Bell |
| Product owner | Priya Raman |
| Tech lead | Dana Whitfield |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | none |
| Risk tier | low |
| Run budget (USD) | 35 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Engineers retype the same AI prompts ("explain this code", "write unit tests") many times a day. An extension with
its own sidebar keeps reusable prompt snippets one click away and inserts them at the cursor, saving time and
spreading good prompts across teams.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Engineer | Anyone using VS Code at AIG | Add, insert, copy and delete their own snippets |

### 3. Scope

**In scope**

- An Activity Bar icon with a sidebar tree of snippets, add, insert, copy and delete commands, and a status bar count.

**Out of scope**

- Syncing snippets between machines, webviews, telemetry, the public Marketplace.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | An "AIG Snippets" Activity Bar container shows a tree of snippets sorted by title, ignoring case | Must |
| FR-2 | On first activation the extension stores three starter snippets | Must |
| FR-3 | "Add snippet" asks for a title (1–80 characters) and a body (1–10,000 characters); Escape cancels without saving | Must |
| FR-4 | "Insert at cursor" replaces the selection in the active editor with the snippet body | Must |
| FR-5 | "Copy" copies the body; "Delete" asks for confirmation | Must |
| FR-6 | The status bar shows "<n> snippets" ("1 snippet" for one) and opens the sidebar | Should |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1, FR-2 | a fresh install | the user opens the AIG Snippets view | three starter snippets are listed A–Z and the status bar shows "3 snippets" |
| AS-2 | FR-3 | the view is open | the user adds "Review SQL" with a body | it appears in sorted position and the message Added "Review SQL" shows |
| AS-3 | FR-3 | the Add snippet title box is open | the user presses Escape | nothing is added |
| AS-4 | FR-4 | a file is open with text selected | the user inserts "Write unit tests" | the selection is replaced by the snippet body |
| AS-5 | FR-4 | no editor is open | the user inserts a snippet | the error "Open a file to insert a snippet." shows |
| AS-6 | FR-5 | a snippet exists | the user deletes it and confirms | it disappears and the count drops by one |
| AS-7 | FR-6 | one snippet remains | the status bar updates | it reads "1 snippet" |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Starter snippets | Explain this code; Write unit tests; Summarise for a ticket |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Installs in the first month | 0 | 300 | private gallery download count |

## Part B — Technical (owner: Tech lead)

### 8. Current system

N/A — new project.

### 9. New project setup

The vscode-extension preset layout: src/extension.ts (activation and wiring), src/store.ts (snippet storage),
src/tree.ts (tree provider), src/commands.ts and src/format.ts (pure helpers). Scripts: build, watch, typecheck,
test, test:integration and package.

## VS Code extension add-on (owner: Tech lead)

### V1. Compatibility

| Item | Value |
|---|---|
| VS Code engine | ^1.90.0 |
| Where it runs | desktop, Remote SSH, WSL and Dev Containers |
| Workspace trust | works in untrusted workspaces: it reads and writes only its own global state |
| Extension kind | ui |

### V2. Contributions

| Contribution | Id | Title or label | Details |
|---|---|---|---|
| Activity Bar container | aig-snippets | AIG Snippets | icon media/aig-snippets.svg (below) |
| View | aigSnippets.list | Prompt snippets | tree; welcome text "No snippets yet." with an Add snippet link |
| Command | aigSnippets.add | Add snippet | view title icon $(add) and Command Palette |
| Command | aigSnippets.insert | Insert at cursor | inline on each item; hidden from the Command Palette |
| Command | aigSnippets.copy, aigSnippets.delete | Copy, Delete | item context menu |
| Setting | aigSnippets.insertTrailingNewline | Add a new line after an inserted snippet | boolean, default false |

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v11H8l-4 4z"/><path d="M8 9h8"/><path d="M8 12h5"/></svg>
```

### V3. Activation and performance

Activates on onView:aigSnippets.list and its commands only; activation under 100 ms; no work at startup beyond
reading global state.

### V4. Webviews

N/A — no webviews.

### V5. Telemetry and data

No telemetry and no network calls. Snippets are stored in context.globalState under aigSnippets.items.

### V6. Packaging and distribution

| Item | Value |
|---|---|
| Extension id | aig.aig-prompt-snippets |
| Version | 0.1.0 |
| Distribution | AIG private extension gallery; not the public Marketplace |
| Signing | signed with the enterprise code-signing certificate in the release pipeline |
| Package command | npm run package writes dist/aig-prompt-snippets.vsix |

### V7. Extension tests

Unit tests with a vscode mock for format.ts, store.ts and every command handler. Integration tests with
@vscode/test-electron, headless in CI, check activation, that every contributed command is registered, and AS-1,
AS-4 and AS-5 in a real VS Code.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | Activation time | under 100 ms on a developer laptop |
| NFR-2 | Usability | Keyboard use | every command reachable from the Command Palette or the view with the keyboard |

### 11. Data and privacy

Snippets are typed by the user and stay on the machine in VS Code's global state; nothing leaves it.

### 12. Compliance

N/A — no regime applies: no data leaves the machine.

### 13. Rollout and compatibility

Published to the private gallery as 0.1.0 for the developer-experience pilot group first, then everyone. Rollback is
unpublishing the version; users' snippets stay in their global state.

### 14. Test expectations

The unit and integration tests in V7; npm run package must produce an installable .vsix in CI.

### 15. Increments

N/A — one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | Access to the private gallery's publish token in CI | Dana Whitfield |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Priya Raman | 14 Oct 2026 |
| Tech lead | Dana Whitfield | 14 Oct 2026 |
