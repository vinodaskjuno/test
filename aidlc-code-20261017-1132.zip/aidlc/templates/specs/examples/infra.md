# Storefront: container image and CI pipeline

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · infra |
| Title | Storefront API container image and CI pipeline |
| Project | existing |
| Project id | storefront |
| Repositories | storefront |
| Surfaces | infra |
| Stack preset | nextjs-fastapi |
| Stack exceptions | none |
| Jira | SHOP-240 |
| Priority | P2 |
| Target release | 2026.12 |
| Business sponsor | Grace Lin |
| Product owner | Tom Hale |
| Tech lead | Ana Costa |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | NYDFS 500 |
| Risk tier | medium |
| Run budget (USD) | 25 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

The orders API is deployed by copying files to a VM, and nothing tests a change before it reaches production. A
container image built and tested by CI on every pull request makes deployments repeatable and stops broken changes
from being merged.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Developer | Storefront engineers | Open pull requests that CI checks |
| Release manager | Platform team member | Deploy a tagged image |

### 3. Scope

**In scope**

- A Dockerfile for api/, and a GitHub Actions workflow that lints, tests and builds the image on every pull request.

**Out of scope**

- Kubernetes manifests and the web app's image (separate specs).

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | api/Dockerfile builds an image that runs the API as a non-root user on port 8000 and answers GET /health | Must |
| FR-2 | A workflow runs ruff, pytest and the image build on every pull request to main and fails the check on any error | Must |
| FR-3 | On a version tag (v*), the workflow pushes the image to the internal registry tagged with the version | Should |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the image is built | it starts with ORDERS_DATABASE_PATH=/data/orders.db | GET /health returns {"status": "ok"} within 10 seconds and the process runs as uid 10001 |
| AS-2 | FR-2 | a pull request with a failing test | CI runs | the check fails and names the failing test |
| AS-3 | FR-2 | a pull request that passes | CI runs | the check passes in under 10 minutes |
| AS-4 | FR-3 | tag v0.5.0 is pushed | CI runs | registry.internal.example/storefront/orders-api:0.5.0 exists |

### 6. Business rules and data

N/A — infrastructure only.

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Failed production deployments per quarter | 4 | 0 | incident records |

## Part B — Technical (owner: Tech lead)

### 8. Current system

The API runs from api/ with uvicorn on a VM; dependencies are in api/pyproject.toml; tests run with pytest from
api/. There is no Dockerfile and no CI workflow.

### 9. New project setup

N/A — existing project.

## Infrastructure add-on (owner: Tech lead with platform / SRE)

### I1. Resources and environments

| Resource | Type | Environments | Change |
|---|---|---|---|
| orders-api image | container image (python:3.12-slim base) | all | new |
| ci.yml | GitHub Actions workflow | pull requests and tags | new |

### I2. Tooling and pipeline

GitHub Actions with the organisation's self-hosted runners. Registry credentials come from the REGISTRY_TOKEN
repository secret, never from files in the repository or the image.

### I3. Cost

| Item | Monthly estimate | Basis |
|---|---|---|
| CI minutes | $0 | self-hosted runners |
| Registry storage | $5 | about 20 images of 150 MB |

### I4. Resilience

N/A — build tooling only; runtime resilience is unchanged.

### I5. Change window and rollback

Merged at any time: it changes no running system. Rollback is reverting the pull request.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Security | Image vulnerabilities | 0 critical or high CVEs in the image scan |
| NFR-2 | Performance | CI duration | under 10 minutes per pull request |
| NFR-3 | Security | Image size | under 200 MB |

### 11. Data and privacy

No data is handled; the image contains no database file and no secrets.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NYDFS 500 | 500.08 application security procedures | every change is tested and scanned before merge |

### 13. Rollout and compatibility

The workflow becomes a required check on main after it has passed on three pull requests.

### 14. Test expectations

A test that builds the image and runs the AS-1 health check; the workflow itself is checked with actionlint.

### 15. Increments

N/A — one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | REGISTRY_TOKEN secret created by the platform team | Ana Costa |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Tom Hale | 15 Oct 2026 |
| Tech lead | Ana Costa | 15 Oct 2026 |
