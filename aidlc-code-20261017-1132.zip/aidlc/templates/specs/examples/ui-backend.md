# AIG Feedback Hub

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · ui-backend |
| Title | AIG Feedback Hub |
| Project | new |
| Project id | feedback-hub |
| Repositories | app |
| Surfaces | ui, backend |
| Stack preset | nextjs-fastapi |
| Stack exceptions | none |
| Jira | AIGFH-3 |
| Priority | P2 |
| Target release | 2026.12 |
| Business sponsor | Marcus Bell |
| Product owner | Lena Ortiz |
| Tech lead | Sam Okafor |
| Data classification | Confidential |
| PII categories | email |
| Compliance regimes | NAIC AI bulletin |
| Risk tier | medium |
| Run budget (USD) | 60 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Teams piloting AI assistants collect feedback on answers in spreadsheets, so nobody can see which model performs
worst or spot recurring complaints. The Feedback Hub stores a rating and comment for each AI answer, lets reviewers
filter it and shows per-model averages, so the AI governance group can compare models with evidence.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Pilot user | Staff using an AI assistant in a pilot | Submit feedback |
| Reviewer | AI governance group member | Browse, filter and delete feedback; view statistics |

### 3. Scope

**In scope**

- An API storing feedback in SQLite, and a web app to submit, browse, filter, delete and chart it.

**Out of scope**

- Sign-in (pilot users and reviewers use the app on the internal network), editing feedback, exports.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | Users can submit feedback with a model (gpt-4o, claude-sonnet, gemini-pro or llama-3), a rating of 1–5, a comment of up to 2,000 characters, up to 5 tags and their e-mail address | Must |
| FR-2 | Reviewers can list feedback newest first, 20 per page, filtered by model, minimum rating and one tag | Must |
| FR-3 | Reviewers can delete a feedback item after confirming | Must |
| FR-4 | A statistics page shows the total count, the average rating per model to 2 decimals as a bar chart, and the rating distribution | Must |
| FR-5 | When the API cannot be reached, each page shows "Couldn't reach the Feedback API." with a Retry button | Should |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the new feedback form | the user submits a valid form | the API returns 201, the app shows "Thanks, your feedback was saved." and the item is first in the list |
| AS-2 | FR-1 | the new feedback form | the user submits without a rating | "Choose a rating" shows under Rating and no request is sent |
| AS-3 | FR-1 | the API | a client posts a rating of 6 | the API returns 422 |
| AS-4 | FR-2 | 25 stored items | a reviewer opens the list | 20 items newest first and a "Load more" button that loads the other 5 |
| AS-5 | FR-2 | stored items for several models | a reviewer filters llama-3 with minimum rating 4 | only llama-3 items rated 4 or 5 are shown |
| AS-6 | FR-3 | a feedback card | the reviewer presses Delete, then confirms | the card disappears and GET /api/feedback/{id} returns 404 |
| AS-7 | FR-4 | 12 items, 3 per model | a reviewer opens Statistics | total 12, four bars with averages to 2 decimals, and the 1–5 distribution |
| AS-8 | FR-5 | the API is stopped | a reviewer opens Statistics | "Couldn't reach the Feedback API." with Retry |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Tags | 1–24 characters of a-z, 0-9 and -; duplicates removed, order kept |
| Averages | rounded half up to 2 decimals; a model without feedback shows "No data" |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Feedback items per pilot week | about 40 in spreadsheets | 200 | count in the database |

## Part B — Technical (owner: Tech lead)

### 8. Current system

N/A — new project.

### 9. New project setup

The nextjs-fastapi preset layout: the FastAPI service in backend/ and the Next.js app in frontend/. Each part
provides install, build, test and lint commands; backend/scripts/seed.py inserts 12 sample items. The README
explains how to run both locally.

## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

| Item | Value |
|---|---|
| Design system | AIG Design System 3.2 |
| Figma | screenshots attached |
| Screenshots | feedback-list.png, statistics.png |
| New tokens or components | none |

### U2. Screens

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| Feedback list | / | Browse and filter feedback | filter, load more, delete |
| New feedback | /new | Submit feedback | fill in, submit |
| Statistics | /stats | Compare models | read the chart and table |

### U3. States

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| Feedback list | "Loading…" | No feedback matches these filters. | Couldn't reach the Feedback API. with Retry | not applicable: no sign-in |
| New feedback | button shows "Saving…" | not applicable | the API's first validation message above the form | not applicable |
| Statistics | "Loading…" | "No data" per model without feedback | Couldn't reach the Feedback API. with Retry | not applicable |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | desktop 1024 px and up; one column below |
| Accessibility level | WCAG 2.2 AA |
| Keyboard and screen reader | ratings use radio buttons; stars have aria-label "<n> out of 5" |
| Browsers | latest Chrome and Edge |

### U5. Content and localisation

| Item | Value |
|---|---|
| Languages | English (US) |
| Formats | dates as 15 Oct 2026, 10:00 |

### U6. Analytics

N/A — no analytics in the pilot.

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| POST | /api/feedback | anyone on the network | model, rating, comment, tags, author_email | 201 and the stored item with id and created_at |
| GET | /api/feedback | anyone on the network | model, min_rating, tag, limit (1–100, default 20), cursor | 200 {items, next_cursor} |
| GET | /api/feedback/{id} | anyone on the network | none | 200 the item |
| DELETE | /api/feedback/{id} | anyone on the network | none | 204 |
| GET | /api/feedback/stats | anyone on the network | none | 200 {total, by_model, distribution} |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| invalid field | 422 | FastAPI validation error list |
| unknown id | 404 | feedback <id> not found |

### B3. Authorisation

None in the pilot: the service is reachable only on the internal network, and CORS allows only the web app's origin
(FEEDBACK_CORS_ORIGINS).

### B4. Compatibility and versioning

N/A — new API with no consumers yet.

### B5. Limits and performance

| Item | Value |
|---|---|
| Pagination | cursor on id, 20 per page, maximum 100 |
| Payload size | 16 KB per request |

### B6. Events and messages

N/A — no events.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | List and statistics response time | p95 at most 300 ms with 10,000 stored items |
| NFR-2 | Accessibility | All three screens | WCAG 2.2 AA, 0 axe violations |
| NFR-3 | Observability | Request logging | one log line per request without the e-mail address |

### 11. Data and privacy

Feedback stores the author's e-mail address so reviewers can follow up. It is never written to logs, is shown only
in the list, and items are deleted after 12 months by a nightly job. Comments may contain personal data typed by
users; the form says not to include customer details.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NAIC AI bulletin | Insurers document how AI system performance is monitored | per-model ratings and averages give the governance group a monitoring record |

### 13. Rollout and compatibility

Deployed to the pilot environment only; no flag. Rollback is redeploying the previous build; the SQLite file is
backed up nightly.

### 14. Test expectations

API tests for every endpoint, each validation rule, cursor paging and the statistics arithmetic, each on a fresh
temporary database. Web tests for form validation, filters, Load more, delete confirmation and the unreachable-API
state. Test e-mail addresses use feedback.example.

### 15. Increments

N/A — one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | Pilot environment with a persistent volume for the database | Sam Okafor |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Lena Ortiz | 13 Oct 2026 |
| Tech lead | Sam Okafor | 13 Oct 2026 |
