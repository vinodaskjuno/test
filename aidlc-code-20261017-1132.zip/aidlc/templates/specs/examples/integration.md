# Storefront: validate shipping addresses with AddressCheck

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · integration |
| Title | Validate shipping addresses with the AddressCheck partner API |
| Project | existing |
| Project id | storefront |
| Repositories | storefront |
| Surfaces | backend, integration |
| Stack preset | nextjs-fastapi |
| Stack exceptions | none |
| Jira | SHOP-252 |
| Priority | P2 |
| Target release | 2027.01 |
| Business sponsor | Grace Lin |
| Product owner | Tom Hale |
| Tech lead | Ana Costa |
| Data classification | Confidential |
| PII categories | name, postal address |
| Compliance regimes | NYDFS 500, NAIC IDSL |
| Risk tier | high |
| Run budget (USD) | 45 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

About 2% of orders ship to addresses that do not exist, and each return costs about $18. Checking the address with
AddressCheck when the order is placed, and offering its corrected address, cuts failed deliveries without blocking
customers when the partner is down.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Storefront web app | The checkout that calls the API | Validate an address before placing the order |

### 3. Scope

**In scope**

- POST /addresses/validate calling AddressCheck, with timeouts, retries, caching and a fallback when it is down.

**Out of scope**

- Changing the checkout screens (a separate spec) and validating non-US addresses.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | POST /addresses/validate returns valid, corrected (with the corrected address) or invalid for a US address | Must |
| FR-2 | When AddressCheck fails or times out after the retries, the endpoint returns unverified so checkout can continue | Must |
| FR-3 | A result is cached for 24 hours per normalised address, so the same address is sent to AddressCheck at most once a day | Should |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | AddressCheck confirms the address | the API validates "1 Main St, Albany NY 12207" | 200 {"result": "valid"} |
| AS-2 | FR-1 | AddressCheck suggests "1 Main Street" | the API validates "1 Main Stret, Albany NY 12207" | 200 {"result": "corrected", "address": {…"line1": "1 Main Street"…}} |
| AS-3 | FR-1 | the request has no postal code | the API validates it | 422 and AddressCheck is not called |
| AS-4 | FR-2 | AddressCheck times out on every attempt | the API validates an address | 200 {"result": "unverified"} within 5 seconds and a warning is logged without the address |
| AS-5 | FR-3 | the same address was validated an hour ago | it is validated again | the cached result is returned and AddressCheck is not called |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Normalisation | upper-case, collapse spaces, strip punctuation before caching |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Orders returned as undeliverable | 2.0% | under 0.5% | carrier return reports |

## Part B — Technical (owner: Tech lead)

### 8. Current system

The FastAPI service in api/; outbound calls already go through httpx with app/retry.py (call_with_retry). Orders are
created in api/app/routes/orders.py; this change adds a new route module and does not change order creation.

### 9. New project setup

N/A — existing project.

## External integration add-on (owner: Tech lead)

### X1. Counterparty and contract

| Item | Value |
|---|---|
| Counterparty | AddressCheck Inc. |
| Direction | we call them |
| Protocol and format | HTTPS REST, JSON (POST /v2/verify) |
| Contract or documentation | addresscheck-v2.yaml attached |
| Versioning | v2; 12 months' notice of breaking changes in the contract |

### X2. Authentication

OAuth2 client credentials; the client id and secret are read from the secrets manager at startup
(ADDRESSCHECK_CLIENT_ID, ADDRESSCHECK_CLIENT_SECRET) and rotated every 90 days. Tokens are cached until 60 seconds
before they expire.

### X3. Timeouts, retries and SLAs

| Item | Value |
|---|---|
| Their SLA | 99.5% monthly, p95 400 ms |
| Our timeout | 1.5 seconds per call |
| Retries | 2 retries, backoff 200 ms then 400 ms, only on timeouts and 5xx |
| Rate limits | 50 calls per second; over the limit counts as a failure |
| Idempotency | verification is read-only, so retries are safe |

### X4. Failure handling

| Failure | What users see | What the system does |
|---|---|---|
| AddressCheck down or timing out | checkout continues; the address is marked unverified | returns unverified, logs a warning, counts addresscheck_failures_total |
| AddressCheck returns 401 | checkout continues | returns unverified, refreshes the token once, alerts on-call when it happens again within 5 minutes |

### X5. Test environment

AddressCheck sandbox at https://sandbox.addresscheck.example with test credentials in the CI secrets; unit tests use
recorded responses with respx and never call the sandbox or production.

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| POST | /addresses/validate | storefront web app | line1, line2 (optional), city, state (2 letters), postal_code (5 digits) | 200 {result: valid, corrected, invalid or unverified, address (when corrected)} |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| missing or malformed field | 422 | FastAPI validation error list |
| non-US state code | 422 | only US addresses can be validated |

### B3. Authorisation

Callable only by the storefront web app through the internal gateway with its service token.

### B4. Compatibility and versioning

Additive: a new endpoint; nothing existing changes.

### B5. Limits and performance

| Item | Value |
|---|---|
| Rate limit | 20 requests per second per client |

### B6. Events and messages

N/A — no events.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | Validation response time | p95 at most 600 ms, maximum 5 seconds including retries |
| NFR-2 | Security | Personal data in logs and metrics | no name or address in any log line or metric label |
| NFR-3 | Availability | Checkout during a partner outage | 100% of validations return within 5 seconds |

### 11. Data and privacy

The customer's name and address are sent to AddressCheck under the data processing agreement and are not stored by
the storefront beyond the 24-hour cache, which holds only the normalised address and the result, encrypted at rest.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NYDFS 500 | 500.11 third-party service provider security | AddressCheck is covered by the vendor assessment and DPA on file |
| NYDFS 500 | 500.15 encryption of nonpublic information | TLS 1.2+ to AddressCheck; cache encrypted at rest |
| NAIC IDSL | oversight of third-party service providers | contract and assessment reviewed yearly by vendor management |

### 13. Rollout and compatibility

Behind the flag address_validation_enabled (default off); turned on for 10% of checkouts, then 100% after a week
without errors. Rollback: turn the flag off.

### 14. Test expectations

Unit tests with recorded AddressCheck responses for AS-1 to AS-5, including timeouts, 5xx, 401 and the cache;
a contract test against addresscheck-v2.yaml. Test addresses are synthetic.

### 15. Increments

N/A — one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | AddressCheck production credentials issued by vendor management | Tom Hale |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Tom Hale | 15 Oct 2026 |
| Tech lead | Ana Costa | 15 Oct 2026 |
| Security | Ivan Petrov | 15 Oct 2026 |
