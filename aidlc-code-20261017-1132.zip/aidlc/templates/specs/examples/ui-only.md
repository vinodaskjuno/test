# AIG Prompt Library

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · ui-only |
| Title | AIG Prompt Library |
| Project | new |
| Project id | prompt-library |
| Repositories | app |
| Surfaces | ui |
| Stack preset | vite-react |
| Stack exceptions | framer-motion — page and card animations the AIG motion guidelines require — Dana Whitfield |
| Jira | AIGPL-12 |
| Priority | P3 |
| Target release | 2026.12 |
| Business sponsor | Marcus Bell |
| Product owner | Priya Raman |
| Tech lead | Dana Whitfield |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | none |
| Risk tier | low |
| Run budget (USD) | 35 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Claims, underwriting and service staff keep their best AI prompts in personal notes, so good prompts are not shared
and new staff start from scratch. This prototype gives them one browsable library of approved prompt templates that
they can search, fill in and copy. It runs on built-in sample data so the design can be reviewed before a backend is
funded.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Staff member | Any AIG employee using AI assistants | Browse, search, fill in and copy prompts; mark favourites |

### 3. Scope

**In scope**

- A library page, a prompt detail page with a live preview, and a favourites page.
- Twelve built-in prompts in four categories; favourites kept in the browser.

**Out of scope**

- A backend, sign-in, and creating or editing prompts.
- Languages other than English.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | The library shows every prompt as a card (title, category, one-line description, variables) sorted by title A–Z | Must |
| FR-2 | A search field filters the cards to prompts whose title or description contains the text, ignoring case, and keeps the text in the URL as ?q= | Must |
| FR-3 | The sidebar filters by category (Claims, Underwriting, Customer service, Engineering) and shows each category's count | Must |
| FR-4 | The prompt page has one field per variable and a preview that replaces each {{variable}} with the field's value as it is typed | Must |
| FR-5 | "Copy prompt" copies the preview text to the clipboard | Must |
| FR-6 | A star marks a prompt as a favourite; favourites survive a reload and are listed on /favourites | Should |
| FR-7 | A theme toggle switches between light and dark and remembers the choice | Could |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the library is open | the page has loaded | 12 cards are shown, sorted A–Z |
| AS-2 | FR-2 | the library is open | the user types "claim" in the search field | only "Claim summary" and "Claim denial letter" remain and the URL ends with ?q=claim |
| AS-3 | FR-2 | the library is open | the user types "zzz" | the text No prompts match "zzz" and a "Clear search" button are shown |
| AS-4 | FR-3 | the library is open | the user selects Claims | 3 cards are shown and the Claims count reads 3 |
| AS-5 | FR-4 | the "Complaint reply" prompt is open | the user types "Ada" in Customer name | the preview shows "Ada" in place of {{customer_name}} and {{complaint}} stays highlighted |
| AS-6 | FR-5 | a prompt is open | the user presses "Copy prompt" | the preview text is on the clipboard and the toast "Copied to clipboard" shows for 3 seconds |
| AS-7 | FR-5 | the browser refuses clipboard access | the user presses "Copy prompt" | the toast "Couldn't copy. Select the text and copy it manually." shows |
| AS-8 | FR-6 | "Code review" is starred | the user reloads and opens /favourites | "Code review" is listed and the Favourites count reads 1 |
| AS-9 | FR-1 | the user opens /prompts/p99 | the page loads | "Prompt not found" and a "Back to the library" button are shown |
| AS-10 | FR-7 | the light theme is on | the user toggles the theme and reloads | the dark theme is shown after the reload |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Sample prompts | 12 prompts, 3 per category, with ids p01–p12; every template uses each of its variables at least once |
| Field labels | A variable name with underscores as spaces and the first letter upper case: customer_name → "Customer name" |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Design review sign-off | none | approved by 3 business units | review meeting notes |

## Part B — Technical (owner: Tech lead)

### 8. Current system

N/A — new project.

### 9. New project setup

One Vite React app at the repository root, created from the vite-react preset: src/ for the code, src/mocks/ for the
sample data, which resolves after 300 ms to show loading states. Scripts: dev, build, preview, test, typecheck and
lint. The README explains how to install, run and test.

## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

| Item | Value |
|---|---|
| Design system | AIG Design System 3.2 (light and dark tokens) |
| Figma | screenshots attached |
| Screenshots | library.png, prompt-detail.png |
| New tokens or components | none |

### U2. Screens

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| Library | / and /category/:slug | Browse and search prompts | search, filter by category, open, star |
| Prompt detail | /prompts/:id | Fill in and copy one prompt | fill variables, copy, reset, star |
| Favourites | /favourites | The starred prompts | open, unstar |

### U3. States

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| Library | card-sized skeletons with a shimmer | No prompts match "<text>" with Clear search | not applicable: sample data cannot fail | not applicable: no sign-in |
| Prompt detail | skeleton form | not applicable | "Prompt not found" with Back to the library | not applicable: no sign-in |
| Favourites | skeleton cards | No favourites yet. Star a prompt to keep it here. | not applicable | not applicable |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | 3 card columns from 1024 px, 2 from 640 px, 1 below; the sidebar becomes a row of pills below 768 px |
| Accessibility level | WCAG 2.2 AA in both themes |
| Keyboard and screen reader | every control reachable by keyboard with a visible focus ring; stars use aria-pressed |
| Browsers | latest Chrome, Edge, Safari and Firefox |

### U5. Content and localisation

| Item | Value |
|---|---|
| Languages | English (US) |
| Formats | none: no dates or numbers are shown |

### U6. Analytics

N/A — the prototype records no analytics.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Accessibility | Contrast and keyboard use | WCAG 2.2 AA, 0 axe violations on each screen |
| NFR-2 | Usability | Reduced motion | with prefers-reduced-motion set, no animation runs |
| NFR-3 | Performance | First load of the library | under 2 seconds on a 4G connection |

### 11. Data and privacy

The app holds only the built-in sample prompts. Favourites and the theme are stored in the browser's localStorage
under aig.favourites and aig.theme; nothing is sent anywhere.

### 12. Compliance

N/A — no regime applies: sample data only, nothing stored on a server.

### 13. Rollout and compatibility

Shared with reviewers as a static build; no feature flag, no existing users, nothing to roll back.

### 14. Test expectations

Unit tests for the filters and the template preview; component tests for each acceptance scenario; an axe
accessibility check on each screen. No end-to-end browser tests for the prototype.

### 15. Increments

N/A — small enough to ship in one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Assumption | The approved prompt texts will replace the sample texts before any pilot | Priya Raman |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Priya Raman | 14 Oct 2026 |
| Tech lead | Dana Whitfield | 14 Oct 2026 |
| Architecture | Dana Whitfield | 14 Oct 2026 |
