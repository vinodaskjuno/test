# Storefront: order status history

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · data-migration |
| Title | Storefront order status history table and backfill |
| Project | existing |
| Project id | storefront |
| Repositories | storefront |
| Surfaces | data, backend |
| Stack preset | nextjs-fastapi |
| Stack exceptions | none |
| Jira | SHOP-231 |
| Priority | P2 |
| Target release | 2027.01 |
| Business sponsor | Grace Lin |
| Product owner | Tom Hale |
| Tech lead | Ana Costa |
| Data classification | Confidential |
| PII categories | none |
| Compliance regimes | NYDFS 500 |
| Risk tier | medium |
| Run budget (USD) | 30 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Support cannot answer "when was my order shipped?" because only the current status is stored. A history table that
records every status change, back-filled from the current orders, gives support the full timeline and gives audit
the record NYDFS expects.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Support tools | Internal services used by the support team | Read an order's status history |

### 3. Scope

**In scope**

- An order_status_history table, written on every status change, a backfill, and GET /orders/{id}/history.

**Out of scope**

- Showing the history in the web app; who made each change.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | Every status change inserts a history row (order id, from status, to status, changed_at UTC) in the same transaction as the change | Must |
| FR-2 | The backfill inserts one row per existing order: from null to its current status, at its status_changed_at or else created_at | Must |
| FR-3 | GET /orders/{order_id}/history returns the rows oldest first | Must |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | order 1 is pending | it is changed to paid | one history row pending → paid exists with the change time |
| AS-2 | FR-1 | a status change fails with 409 | the request ends | no history row is written |
| AS-3 | FR-2 | 3 existing orders and an empty history table | the backfill runs twice | exactly 3 rows exist, one per order |
| AS-4 | FR-3 | order 1 went pending → paid → shipped | a client reads its history | 3 rows oldest first: null → pending, pending → paid, paid → shipped |
| AS-5 | FR-3 | no order 999 | a client reads its history | 404 with "order 999 not found" |

### 6. Business rules and data

N/A — no rules beyond FR-1 to FR-3.

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Support tickets escalated for order timelines | about 20 a week | 0 | support ticket tags |

## Part B — Technical (owner: Tech lead)

### 8. Current system

api/app/repository.py stores orders in SQLite (sqlite3, one lock); status changes go through
OrderRepository.update_status, added by SHOP-214. Schema changes run at startup in OrderRepository.__init__.

### 9. New project setup

N/A — existing project.

## Data add-on (owner: Tech lead with the data owner)

### D1. Entities and schema changes

| Table or entity | Change | Columns (type, null, default) | Indexes and constraints |
|---|---|---|---|
| order_status_history | add | id INTEGER PK, order_id INTEGER NOT NULL, from_status TEXT NULL, to_status TEXT NOT NULL, changed_at TEXT NOT NULL | index on (order_id, changed_at); order_id references orders(id) |

### D2. Migration and backfill

The table is created at startup when missing. The backfill is a script, api/scripts/backfill_status_history.py,
run once after the deploy; it skips orders that already have a row, so a re-run is safe. 80,000 orders take under a
minute in batches of 1,000; it holds the write lock for one batch at a time.

### D3. Rollback

The previous build ignores the new table. To remove it, drop order_status_history; no existing data changes.

### D4. Retention and volumes

| Item | Value |
|---|---|
| Rows today and growth | 80,000 after the backfill, +12,000 a month |
| Retention | as long as the order |
| Deletion or archival | deleted with its order |
| Personal data columns | none |

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| GET | /orders/{order_id}/history | internal services | none | 200 a list of {from_status, to_status, changed_at} |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| unknown order | 404 | order <id> not found |

### B3. Authorisation

Unchanged: internal network through the existing gateway.

### B4. Compatibility and versioning

Additive: a new endpoint and table; no existing response changes.

### B5. Limits and performance

N/A — histories hold a handful of rows.

### B6. Events and messages

N/A — no events.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | History read time | p95 at most 50 ms |
| NFR-2 | Availability | Backfill impact | API p95 stays under 200 ms while the backfill runs |

### 11. Data and privacy

The history holds only order ids, statuses and times; no personal data.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NYDFS 500 | 500.06 audit trail | every status change is kept with its time for the life of the order |

### 13. Rollout and compatibility

Deploy the API, then run the backfill once in each environment. Rollback: redeploy the previous image.

### 14. Test expectations

Tests for AS-1 to AS-5, including a failed change leaving no row and a second backfill run adding nothing.

### 15. Increments

N/A — one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | SHOP-214 (status updates) is released first | Ana Costa |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Tom Hale | 15 Oct 2026 |
| Tech lead | Ana Costa | 15 Oct 2026 |
