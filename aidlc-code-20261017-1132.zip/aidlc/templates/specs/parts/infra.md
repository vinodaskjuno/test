## Infrastructure add-on (owner: Tech lead with platform / SRE)

### I1. Resources and environments

| Resource | Type | Environments | Change |
|---|---|---|---|
| {{e.g. orders-api}} | {{e.g. Kubernetes Deployment}} | {{e.g. dev, test, prod}} | {{what changes}} |

### I2. Tooling and pipeline

<!-- guide: IaC tool and module (Terraform, Helm, CloudFormation), where state is kept, CI/CD changes, and how secrets
are supplied (never in code or images). -->

{{Tool, state, pipeline and secrets}}

### I3. Cost

| Item | Monthly estimate | Basis |
|---|---|---|
| {{e.g. compute}} | {{e.g. $120}} | {{e.g. 2 pods, 0.5 vCPU each}} |

### I4. Resilience

| Item | Value |
|---|---|
| Availability target | {{e.g. 99.9%}} |
| RPO and RTO | {{e.g. RPO 15 minutes, RTO 1 hour}} |
| Backups | {{what, how often, where}} |
| Scaling | {{e.g. 2 to 6 replicas at 70% CPU}} |

### I5. Change window and rollback

<!-- guide: When the change may be applied, change-board approval, how it is verified after applying, and how it is
rolled back. -->

{{Window, approval, verification and rollback}}
