## VS Code extension add-on (owner: Tech lead)

### V1. Compatibility

| Item | Value |
|---|---|
| VS Code engine | {{e.g. ^1.90.0}} |
| Where it runs | {{desktop, Remote SSH, WSL, Dev Containers, Codespaces, vscode.dev}} |
| Workspace trust | {{works in untrusted workspaces, or needs trust and why}} |
| Extension kind | {{workspace or ui}} |

### V2. Contributions

<!-- guide: Everything the extension adds to VS Code. An Activity Bar container needs an icon: give its SVG
(24 × 24, one colour, stroke or fill "currentColor") in a code block here or attach it. -->

| Contribution | Id | Title or label | Details |
|---|---|---|---|
| Activity Bar container | {{e.g. aig-tools}} | {{e.g. AIG Tools}} | {{icon file, e.g. media/aig-tools.svg}} |
| View | {{e.g. aigTools.list}} | {{e.g. Tools}} | {{tree or webview; welcome text when empty}} |
| Command | {{e.g. aigTools.refresh}} | {{e.g. Refresh}} | {{where it appears: palette, view title, context menu}} |
| Setting | {{e.g. aigTools.endpoint}} | {{description}} | {{type and default}} |

### V3. Activation and performance

<!-- guide: Activation events (avoid "*"), the startup budget (e.g. activation under 200 ms) and work that must stay
off the extension host's main thread. -->

{{Activation events and startup budget}}

### V4. Webviews

<!-- guide: Webviews with their content security policy, message protocol and saved state. "N/A — no webviews" when
there are none. An extension with webviews also adds `ui` to Surfaces and fills in the UI add-on. -->

{{Webviews, CSP and messages, or N/A — no webviews}}

### V5. Telemetry and data

<!-- guide: Telemetry must follow vscode.env.isTelemetryEnabled; never send source code or personal data. Secrets go
in SecretStorage only. List every network endpoint the extension calls. -->

{{Telemetry, secrets and network calls}}

### V6. Packaging and distribution

| Item | Value |
|---|---|
| Extension id | {{publisher.name, e.g. aig.aig-tools}} |
| Version | {{e.g. 0.1.0}} |
| Distribution | {{e.g. private gallery or artifact repository; not the public Marketplace}} |
| Signing | {{e.g. signed .vsix with the enterprise code-signing certificate}} |
| Package command | {{e.g. npm run package writes dist/aig-tools.vsix}} |

### V7. Extension tests

<!-- guide: Unit tests with a vscode mock for logic, and integration tests in a real VS Code with
@vscode/test-electron (headless in CI) for activation, commands and contributions. -->

{{Unit and integration test expectations}}
