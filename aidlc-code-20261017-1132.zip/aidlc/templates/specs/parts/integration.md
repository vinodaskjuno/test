## External integration add-on (owner: Tech lead)

### X1. Counterparty and contract

| Item | Value |
|---|---|
| Counterparty | {{e.g. AddressCheck Inc.}} |
| Direction | {{we call them, they call us, or both}} |
| Protocol and format | {{e.g. HTTPS REST, JSON}} |
| Contract or documentation | {{link or attached file}} |
| Versioning | {{e.g. v2, 12 months' notice of breaking changes}} |

### X2. Authentication

<!-- guide: How each side proves who it is (OAuth2 client credentials, mutual TLS, API key, signed webhooks), where
credentials are kept (secrets manager) and how they are rotated. -->

{{Authentication, credential storage and rotation}}

### X3. Timeouts, retries and SLAs

| Item | Value |
|---|---|
| Their SLA | {{e.g. 99.5%, p95 400 ms}} |
| Our timeout | {{e.g. 2 seconds per call}} |
| Retries | {{e.g. 3 attempts, exponential backoff from 200 ms, only on 5xx and timeouts}} |
| Rate limits | {{e.g. 50 calls per second}} |
| Idempotency | {{e.g. Idempotency-Key header on POST}} |

### X4. Failure handling

| Failure | What users see | What the system does |
|---|---|---|
| {{e.g. counterparty down}} | {{exact message}} | {{e.g. queue and retry for 24 hours, alert on-call}} |

### X5. Test environment

<!-- guide: Sandbox URL and access, test accounts, recorded fixtures. Tests never call the production service. -->

{{Sandbox, test accounts and fixtures}}
