## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

<!-- guide: Every endpoint added or changed; for a changed endpoint, say what changes. Describe requests and
responses as field lists with types and rules. An existing OpenAPI file can be uploaded with the spec. -->

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| {{e.g. POST}} | {{e.g. /api/v1/quotes}} | {{role}} | {{fields, types and rules}} | {{status and body fields}} |

### B2. Validation and errors

<!-- guide: Each rejected input or failure, with the status code and the exact message. -->

| Case | Status | Message |
|---|---|---|
| {{e.g. unknown quote id}} | {{e.g. 404}} | {{e.g. quote <id> not found}} |

### B3. Authorisation

<!-- guide: Who may call what, how identity is checked (OIDC scopes, roles) and any row-level rules (e.g. agents
see only their own clients). -->

{{Roles, scopes and row-level rules}}

### B4. Compatibility and versioning

<!-- guide: Breaking changes (removed or renamed fields, changed meaning, new required fields), the API version,
the deprecation period and the consumers affected. "N/A — new API" for a new service. -->

{{Breaking changes, version and consumers}}

### B5. Limits and performance

<!-- guide: Optional. -->

| Item | Value |
|---|---|
| Rate limit | {{e.g. 100 requests per minute per client}} |
| Pagination | {{e.g. cursor, 20 per page, maximum 100}} |
| Payload size | {{e.g. 1 MB}} |

### B6. Events and messages

<!-- guide: Optional. Events or queue messages published or consumed. -->

| Event or topic | Producer | Payload | Delivery |
|---|---|---|---|
| {{e.g. quote.issued}} | {{service}} | {{fields}} | {{e.g. at least once}} |
