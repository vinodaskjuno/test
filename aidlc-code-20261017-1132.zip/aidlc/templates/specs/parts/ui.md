## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

<!-- guide: The design system and version the screens must use. Colour and type tokens live in the design system,
so do not copy them here unless the change adds new ones. Pass the Figma link with the upload (`--figma <url>`) or
attach screenshots as extra files, and name them here. -->

| Item | Value |
|---|---|
| Design system | {{e.g. AIG Design System 3.2}} |
| Figma | {{https://www.figma.com/… or "screenshots attached"}} |
| Screenshots | {{file names of attached images, or none}} |
| New tokens or components | {{none, or list them}} |

### U2. Screens

<!-- guide: Every screen, page, dialog or panel added or changed. -->

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| {{e.g. Policy list}} | {{e.g. /policies}} | {{what it is for}} | {{e.g. search, filter, open}} |

### U3. States

<!-- guide: For each screen, what users see while loading, with no data, after an error and without permission.
Give the exact text. -->

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| {{e.g. Policy list}} | {{e.g. skeleton rows}} | {{exact text}} | {{exact text and retry}} | {{exact text}} |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | {{e.g. desktop 1280 px and up, tablet 768–1279 px, phone below 768 px}} |
| Accessibility level | {{e.g. WCAG 2.2 AA}} |
| Keyboard and screen reader | {{focus order, shortcuts, labels that need care}} |
| Browsers | {{e.g. latest Chrome, Edge, Safari and Firefox}} |

### U5. Content and localisation

<!-- guide: Optional. Languages, and the date, number and currency formats. -->

| Item | Value |
|---|---|
| Languages | {{e.g. English (US)}} |
| Formats | {{e.g. 15 Oct 2026, $1,234.50}} |

### U6. Analytics

<!-- guide: Optional. Events to record; never include personal data in event properties. -->

| Event | When | Properties |
|---|---|---|
| {{e.g. quote_viewed}} | {{when it fires}} | {{properties, no personal data}} |
