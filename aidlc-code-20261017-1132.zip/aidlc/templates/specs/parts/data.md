## Data add-on (owner: Tech lead with the data owner)

### D1. Entities and schema changes

| Table or entity | Change | Columns (type, null, default) | Indexes and constraints |
|---|---|---|---|
| {{e.g. policies}} | {{add, change or remove}} | {{e.g. renewal_date DATE NULL}} | {{e.g. index on renewal_date}} |

### D2. Migration and backfill

<!-- guide: Migration tool (e.g. Alembic), whether it runs before or after the code deploy, the backfill logic and
batch size, expected duration, and any locking. -->

{{Tool, order, backfill and duration}}

### D3. Rollback

<!-- guide: How the migration and the backfill are undone, and data that cannot be restored and how it is
protected (backup, soft delete). -->

{{Down migration and data protection}}

### D4. Retention and volumes

| Item | Value |
|---|---|
| Rows today and growth | {{e.g. 2.4 million, +60,000 a month}} |
| Retention | {{e.g. 7 years after policy end}} |
| Deletion or archival | {{how and when}} |
| Personal data columns | {{none, or list}} |
