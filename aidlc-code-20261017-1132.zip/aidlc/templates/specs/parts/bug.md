# {{Short description of the bug}}

<!-- guide: AIDLC bug template ([[template]]). Replace every {{…}} slot and keep the headings and the Spec details
field names exactly as they are. Upload it as a bug (`aidlc run <file> --type bug`). The platform first writes a test
that fails because of the bug, then fixes the code. Before you submit, run `aidlc spec check <file>`. -->

## Spec details

<!-- guide: Every row is required. Surfaces names where the fix is expected to land (ui, backend, data, infra,
integration, vsix); it decides which specialist agents run. -->

| Field | Value |
|---|---|
| Template | [[template]] |
| Title | {{Short description, at most 300 characters}} |
| Project id | {{AIDLC project id, e.g. storefront}} |
| Repositories | {{repo ids, comma-separated}} |
| Surfaces | {{ui, backend, data, infra, integration or vsix}} |
| Jira | {{ABC-123}} |
| Severity | {{critical, high, medium or low}} |
| Priority | {{P1, P2, P3 or P4}} |
| Found in version | {{e.g. orders-api 0.4.0 or a commit id}} |
| Reported by | {{name or team}} |
| Data classification | {{Public, Internal, Confidential or Restricted}} |
| PII categories | {{none, or e.g. name, email}} |
| Risk tier | {{low, medium or high}} |
| Run budget (USD) | {{e.g. 15}} |

## Bug report

### 1. Observed behaviour

<!-- guide: What happens, exactly as a user or system sees it: messages, status codes, wrong values, timing. -->

{{What happens}}

### 2. Expected behaviour

{{What should happen instead, with exact values}}

### 3. Steps to reproduce

<!-- guide: Numbered steps from a clean start, with the exact input, settings and data. -->

1. {{first step}}
2. {{next step}}

### 4. Environment

| Item | Value |
|---|---|
| Version or commit | {{e.g. orders-api 0.4.0}} |
| Configuration | {{settings, flags and environment variables that matter}} |
| Platform | {{e.g. Linux container, Chrome 130}} |

### 5. Impact

| Item | Value |
|---|---|
| Who is affected | {{users, teams or systems}} |
| How often | {{e.g. every request with these settings}} |
| Business impact | {{e.g. orders cannot be placed during inventory outages}} |

### 6. Workaround

<!-- guide: Optional. -->

{{Workaround, if any}}

### 7. Evidence

<!-- guide: Optional. Log lines (remove personal data and secrets first) and the names of attached screenshots. -->

{{Logs and screenshots}}

### 8. Acceptance scenarios

<!-- guide: Include the scenario that fails today; it becomes the regression test. The Related column may name a
requirement or stay "—". -->

| ID | Related | Given | When | Then |
|---|---|---|---|---|
| AS-1 | — | {{the state from the steps}} | {{the action}} | {{the corrected behaviour, with exact values}} |
