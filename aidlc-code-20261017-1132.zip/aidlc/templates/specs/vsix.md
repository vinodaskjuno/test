# {{Title of the change}}

<!-- guide: AIDLC spec template (aidlc-spec/1 · vsix, VS Code extension). Part A is written by Product / the business analyst,
Part B by the tech lead. Replace every {{…}} slot, keep the headings and the Spec details field names exactly as
they are, and write "N/A — <reason>" in a section that does not apply. Guidance like this note is ignored by the
platform: delete it or leave it. Before you submit, run `aidlc spec check <file>`: a missing required section stops
the upload with a list of what to fix; an empty optional section becomes a question for you at Gate A. -->

## Spec details

<!-- guide: Every row is required.
Surfaces lists every area the change touches (ui, backend, data, infra, integration, vsix) and decides which
specialist agents run. Add `data` when tables, columns or stored data change; add `integration` when the change
calls or is called by a partner system. For each surface you add, paste its sections from
templates/specs/parts/<surface>.md.
Stack preset is one of the approved stacks; any other language, framework or service goes in Stack exceptions as
"technology — reason — approver" (separate several with ";") and is confirmed at Gate A.
Risk tier high tightens the quality gates and needs a Security approver in section 17.
Run budget is the most this run may spend on AI agents; the run pauses for approval when it is reached. -->

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · vsix |
| Title | {{Short name of the change, at most 300 characters}} |
| Project | {{new or existing}} |
| Project id | {{AIDLC project id, e.g. storefront}} |
| Repositories | {{repo ids in the project, comma-separated, e.g. storefront}} |
| Surfaces | vsix |
| Stack preset | {{nextjs-fastapi, vite-react, fastapi, vscode-extension, generic-node or generic-python}} |
| Stack exceptions | {{none, or: technology — reason — approver}} |
| Jira | {{ABC-123}} |
| Priority | {{P1, P2, P3 or P4}} |
| Target release | {{e.g. 2026.12 or 15 Dec 2026}} |
| Business sponsor | {{name}} |
| Product owner | {{name}} |
| Tech lead | {{name}} |
| Data classification | {{Public, Internal, Confidential or Restricted}} |
| PII categories | {{none, or e.g. name, email, policy number}} |
| Compliance regimes | {{none, or any of: NYDFS 500, NAIC IDSL, NAIC AI bulletin, EU AI Act, Other: <name>}} |
| Risk tier | {{low, medium or high}} |
| Run budget (USD) | {{e.g. 40}} |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

<!-- guide: Who has the problem today, what it costs them, and what is different once this ships. Two to five
sentences, in business terms. Leave solution design to Part B. -->

{{The problem today and the outcome wanted}}

### 2. Users and roles

<!-- guide: Every kind of user or system that takes part, and what each may do in this change. These roles become
the permission rules the code and tests enforce. -->

| Role | Who they are | What they can do in this change |
|---|---|---|
| {{e.g. Underwriter}} | {{who they are}} | {{what they can do}} |

### 3. Scope

<!-- guide: Two lists. "Out of scope" stops the agents from building things nobody asked for. -->

**In scope**

- {{what this change delivers}}

**Out of scope**

- {{what it deliberately does not do}}

### 4. Functional requirements

<!-- guide: One row per behaviour users or systems will see, written as one testable statement ("Users can…",
"The system rejects…"). Give exact values: limits, formats, rounding, messages, sort orders. Avoid words that cannot
be tested, such as fast, intuitive, robust or "etc.". Must = the release is blocked without it. -->

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | {{Users can …}} | {{Must, Should or Could}} |
| FR-2 | {{The system …}} | {{Must, Should or Could}} |

### 5. Acceptance scenarios

<!-- guide: At least one scenario for every Must requirement, and the unhappy paths: invalid input, not found, no
permission, a dependency down, no data yet. Write the exact message, value or state the user sees. These become the
acceptance criteria the tests must prove. -->

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | {{a starting state}} | {{the action}} | {{the observable result, with exact values}} |
| AS-2 | FR-1 | {{an unhappy-path state}} | {{the action}} | {{the exact error or fallback}} |

### 6. Business rules and data

<!-- guide: Calculations, policies and reference data the requirements depend on. Optional. -->

| Rule | Detail |
|---|---|
| {{e.g. Premium rounding}} | {{e.g. round half up to 2 decimals}} |

### 7. Success metrics

<!-- guide: How the business will know it worked. Optional. -->

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| {{e.g. Time to issue a quote}} | {{value}} | {{value}} | {{source}} |

## Part B — Technical (owner: Tech lead)

### 8. Current system

<!-- guide: Existing projects: the modules, files, endpoints and screens this change touches, the behaviour that
must not change, and known constraints. New projects: "N/A — new project". -->

{{Affected modules and current behaviour, or N/A — new project}}

### 9. New project setup

<!-- guide: New projects: repository layout (e.g. api/ and web/), the scripts each part must provide (install,
build, test, lint, typecheck), how to run it locally, and anything the README must explain. Existing projects:
"N/A — existing project". -->

{{Layout, scripts and local run, or N/A — existing project}}

## VS Code extension add-on (owner: Tech lead)

### V1. Compatibility

| Item | Value |
|---|---|
| VS Code engine | {{e.g. ^1.90.0}} |
| Where it runs | {{desktop, Remote SSH, WSL, Dev Containers, Codespaces, vscode.dev}} |
| Workspace trust | {{works in untrusted workspaces, or needs trust and why}} |
| Extension kind | {{workspace or ui}} |

### V2. Contributions

<!-- guide: Everything the extension adds to VS Code. An Activity Bar container needs an icon: give its SVG
(24 × 24, one colour, stroke or fill "currentColor") in a code block here or attach it. -->

| Contribution | Id | Title or label | Details |
|---|---|---|---|
| Activity Bar container | {{e.g. aig-tools}} | {{e.g. AIG Tools}} | {{icon file, e.g. media/aig-tools.svg}} |
| View | {{e.g. aigTools.list}} | {{e.g. Tools}} | {{tree or webview; welcome text when empty}} |
| Command | {{e.g. aigTools.refresh}} | {{e.g. Refresh}} | {{where it appears: palette, view title, context menu}} |
| Setting | {{e.g. aigTools.endpoint}} | {{description}} | {{type and default}} |

### V3. Activation and performance

<!-- guide: Activation events (avoid "*"), the startup budget (e.g. activation under 200 ms) and work that must stay
off the extension host's main thread. -->

{{Activation events and startup budget}}

### V4. Webviews

<!-- guide: Webviews with their content security policy, message protocol and saved state. "N/A — no webviews" when
there are none. An extension with webviews also adds `ui` to Surfaces and fills in the UI add-on. -->

{{Webviews, CSP and messages, or N/A — no webviews}}

### V5. Telemetry and data

<!-- guide: Telemetry must follow vscode.env.isTelemetryEnabled; never send source code or personal data. Secrets go
in SecretStorage only. List every network endpoint the extension calls. -->

{{Telemetry, secrets and network calls}}

### V6. Packaging and distribution

| Item | Value |
|---|---|
| Extension id | {{publisher.name, e.g. aig.aig-tools}} |
| Version | {{e.g. 0.1.0}} |
| Distribution | {{e.g. private gallery or artifact repository; not the public Marketplace}} |
| Signing | {{e.g. signed .vsix with the enterprise code-signing certificate}} |
| Package command | {{e.g. npm run package writes dist/aig-tools.vsix}} |

### V7. Extension tests

<!-- guide: Unit tests with a vscode mock for logic, and integration tests in a real VS Code with
@vscode/test-electron (headless in CI) for activation, commands and contributions. -->

{{Unit and integration test expectations}}

### 10. Non-functional requirements

<!-- guide: Every row needs a measurable target. Categories: Performance, Availability, Security, Accessibility,
Observability, Scalability, Usability. -->

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | {{e.g. Performance}} | {{e.g. Search response time}} | {{e.g. p95 at most 300 ms with 50 requests per second}} |

### 11. Data and privacy

<!-- guide: Data the change reads, stores or sends, and where personal data appears: fields, logs, analytics,
prompts sent to AI models. How it is masked, retained and deleted. Must agree with Data classification and PII
categories in Spec details. -->

{{Data handled and how personal data is protected}}

### 12. Compliance

<!-- guide: For each regime named in Spec details, the obligation that applies and how this change meets it, for
example NYDFS 500.15 encryption of non-public information, or an EU AI Act transparency notice for AI-generated
text. "N/A — <reason>" when no regime applies. -->

| Regime | Obligation | How this change meets it |
|---|---|---|
| {{e.g. NYDFS 500}} | {{e.g. 500.15 encryption of non-public information}} | {{e.g. stored fields are encrypted at rest}} |

### 13. Rollout and compatibility

<!-- guide: Feature flag (name and default), compatibility with existing clients and data, deployment order,
rollback plan, and who must be told. -->

{{Flag, compatibility, deployment order and rollback}}

### 14. Test expectations

<!-- guide: Test levels expected in addition to the platform's unit tests (integration/contract, end-to-end,
accessibility, performance), test data rules (synthetic data only, e-mail addresses at example.com or another
reserved domain) and environments. -->

{{Test levels, test data and environments}}

### 15. Increments

<!-- guide: Large changes only (more than 12 requirements): the slices, in order, that can each ship on their own and
be submitted as their own spec. Optional. -->

| Increment | FRs | Ships when |
|---|---|---|
| {{1}} | {{e.g. FR-1, FR-2}} | {{e.g. sprint 24}} |

### 16. Dependencies, assumptions and open questions

<!-- guide: Anything outside this change that it depends on, assumptions made while writing it, and questions you
already know are open. Optional. -->

| Type | Item | Owner |
|---|---|---|
| {{Dependency, Assumption or Question}} | {{description}} | {{name or team}} |

### 17. Approvals

<!-- guide: Product owner and Tech lead are required. Add a Security row for risk tier high and an Architecture row
when the spec has stack exceptions. Delete rows that do not apply. -->

| Role | Name | Date |
|---|---|---|
| Product owner | {{name}} | {{date}} |
| Tech lead | {{name}} | {{date}} |
| Security | {{name, required for risk tier high}} | {{date}} |
