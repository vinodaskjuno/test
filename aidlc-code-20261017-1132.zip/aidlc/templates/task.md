---
# Template: .adlc/specs/{{req_id}}-{{slug}}/tasks/{{task_id}}.md (written by the Work Planner, gated by V2).
# Placeholders:
#   {{task_id}}       task id, e.g. TASK-003
#   {{req_id}}        parent requirement id
#   {{slug}}          requirement slug (folder name)
#   {{title}}         one-line task title
#   {{repo}}          repo id from .adlc/config.yml the task is confined to
#   {{owner_agent}}   agent id that implements the task, e.g. backend-dev
#   {{tier}}          dependency tier (0 = no dependencies); tasks in one tier run in parallel
#   {{depends_on}}    YAML list of task ids, e.g. [TASK-001]
#   {{ac_ids}}        YAML list of acceptance-criterion ids the task satisfies, e.g. [AC-1, AC-2]
#   {{files}}         Markdown bullet list of files the task exclusively owns (create or edit)
#   {{description}}   what to build and how it fits the architecture
#   {{done_when}}     Markdown checklist of completion conditions
id: {{task_id}}
requirement: {{req_id}}
title: {{title}}
repo: {{repo}}
owner_agent: {{owner_agent}}
tier: {{tier}}
depends_on: {{depends_on}}
ac_ids: {{ac_ids}}
---

# {{task_id}}: {{title}}

## Description
{{description}}

## Files owned
<!-- Only these files may be created or edited by the owner agent. Anything else is a plan change. -->
{{files}}

## Done when
{{done_when}}
