/**
 * AIG: Test model routing command — FR-CHAT-4 (REQ-007)
 *
 * Implements the `aig.testModelRouting` VS Code command and exports the pure
 * formatting / picker-helper functions used by `test/routing.test.ts` (TASK-011).
 *
 * ACs covered: AC-36, AC-37, AC-38, AC-39, AC-40, AC-41, AC-42, AC-43, AC-44,
 *              AC-46, AC-49
 *
 * Pre-existing dependency stubs are declared at the bottom of this file.
 * Replace each `declare` with a real import once the corresponding extension
 * unit is available (architecture R-1 BLOCKING; ASSUME-REQ007-A1).
 */

import * as vscode from 'vscode';
import type { RoutingTestResult } from './types.js';

// ---------------------------------------------------------------------------
// AC-39, AC-40 — Routing result formatter (pure, exported for TASK-011)
// ---------------------------------------------------------------------------

/**
 * Formats a routing test result into the VS Code notification display string.
 *
 * AC-39: `Routing: <model> · <tier> · <cost mode> · <profile> — <ms> ms (<provider>)`
 * AC-40: When `usageState !== 'normal'`, appends ` · usage <state>: <description>`.
 *
 * @example
 * formatRoutingResult({
 *   model: 'gpt-4o', tier: 'premium', costMode: 'standard',
 *   jobProfile: 'coding', latencyMs: 142, provider: 'openai',
 *   usageState: 'normal', ...
 * })
 * // → 'Routing: gpt-4o · premium · standard · coding — 142 ms (openai)'
 */
export function formatRoutingResult(r: RoutingTestResult): string {
  let text =
    `Routing: ${r.model} · ${r.tier} · ${r.costMode} · ${r.jobProfile}` +
    ` — ${r.latencyMs} ms (${r.provider})`;
  if (r.usageState !== 'normal') {
    // AC-40: append usage suffix when state is not normal
    text += ` · usage ${r.usageState}: ${r.usageDescription ?? ''}`;
  }
  return text;
}

// ---------------------------------------------------------------------------
// AC-43 — Output channel log formatter (pure, exported for TASK-011)
// ---------------------------------------------------------------------------

/**
 * Serialises all routing result fields into a single `key=value …` string for
 * the AIG output channel log (AC-43).
 *
 * The `[routing] ` prefix is prepended by the caller in `runRoutingCommand`.
 * Null / undefined values are rendered as `—` so every field is always present.
 */
export function formatRoutingFields(r: RoutingTestResult): string {
  const str = (v: unknown): string =>
    v === null || v === undefined ? '—' : String(v);
  return [
    `result=${str(r.result)}`,
    `model=${str(r.model)}`,
    `provider=${str(r.provider)}`,
    `tier=${str(r.tier)}`,
    `costMode=${str(r.costMode)}`,
    `jobProfile=${str(r.jobProfile)}`,
    `usageState=${str(r.usageState)}`,
    `latencyMs=${str(r.latencyMs)}`,
    `tokens=${str(r.tokens)}`,
    `cache=${str(r.cache)}`,
    `answer=${str(r.answer)}`,
    `error=${str(r.error)}`,
    `traceId=${str(r.traceId)}`,
  ].join(' ');
}

// ---------------------------------------------------------------------------
// AC-42 — Details QuickPick row builder (pure, exported for TASK-011)
// ---------------------------------------------------------------------------

/**
 * Builds the fixed 13-row item list for the Details QuickPick (AC-42).
 *
 * ASSUME-REQ007-A6: All 13 rows are always present regardless of null or absent
 * field values; missing values are displayed as '—'.
 *
 * Selecting a row in the QuickPick copies `item.description` to the clipboard
 * (the copy logic lives in `showDetailsQuickPick`).
 */
export function buildDetailsItems(
  r: RoutingTestResult,
): Array<{ label: string; description: string }> {
  const val = (v: unknown): string =>
    v === null || v === undefined || v === '' ? '—' : String(v);
  return [
    { label: 'Result',      description: val(r.result) },
    { label: 'Model',       description: val(r.model) },
    { label: 'Provider',    description: val(r.provider) },
    { label: 'Tier',        description: val(r.tier) },
    { label: 'Cost mode',   description: val(r.costMode) },
    { label: 'Job profile', description: val(r.jobProfile) },
    { label: 'Usage state', description: val(r.usageState) },
    { label: 'Latency',     description: r.latencyMs !== undefined ? `${r.latencyMs} ms` : '—' },
    { label: 'Tokens',      description: val(r.tokens) },
    { label: 'Cache',       description: val(r.cache) },
    { label: 'Answer',      description: val(r.answer) },
    { label: 'Error',       description: val(r.error) },
    { label: 'Trace id',    description: val(r.traceId) },
  ];
}

// ---------------------------------------------------------------------------
// AC-37, AC-44 — Profile picker helpers (pure, exported for TASK-011)
// ---------------------------------------------------------------------------

/**
 * Builds the ordered QuickPick item list for profile selection.
 *
 * AC-37: The configured profile appears first when it is in the allowed set,
 * followed by every other allowed profile. When the configured profile is NOT
 * in the allowed set, all allowed profiles are returned in their original order.
 *
 * @param allowed     All profiles the signed-in user may select.
 * @param configured  The profile currently active in extension settings.
 */
export function buildProfilePickerItems(allowed: string[], configured: string): string[] {
  if (allowed.includes(configured)) {
    return [configured, ...allowed.filter(p => p !== configured)];
  }
  return [...allowed];
}

/**
 * Returns the single allowed profile directly when there is exactly one choice
 * (AC-44: skip the QuickPick picker), or `null` when the picker must be shown.
 *
 * The `_configured` parameter is retained for API symmetry with
 * `buildProfilePickerItems`; callers may pass any value.
 *
 * @param allowed      All profiles the user may select.
 * @param _configured  Reserved for symmetry; not used in the single-profile path.
 */
export function pickProfileOrSkip(allowed: string[], _configured: string): string | null {
  return allowed.length === 1 ? allowed[0] : null;
}

// ---------------------------------------------------------------------------
// Internal helper — AC-42 Details QuickPick interaction
// ---------------------------------------------------------------------------

/**
 * Shows the Details QuickPick with 13 rows and copies the selected row's value
 * to the clipboard (AC-42).
 */
async function showDetailsQuickPick(result: RoutingTestResult): Promise<void> {
  const items = buildDetailsItems(result);
  const selected = await vscode.window.showQuickPick(items, {
    placeHolder: 'Select a row to copy its value',
  });
  if (selected !== undefined) {
    // AC-42: selecting any row copies that row's value to the clipboard
    await vscode.env.clipboard.writeText(selected.description);
  }
}

// ---------------------------------------------------------------------------
// AC-36..49 — Main command handler
// ---------------------------------------------------------------------------

/**
 * Entry point for the `aig.testModelRouting` VS Code command (FR-CHAT-4).
 *
 * Registered by `extension.ts` (TASK-009) as:
 * ```ts
 * vscode.commands.registerCommand('aig.testModelRouting', runRoutingCommand)
 * ```
 *
 * AC coverage:
 * - AC-36  sign-in guard (not signed in → message + Sign In button → return)
 * - AC-37  configured profile first in picker items
 * - AC-38  POST /api/v1/routing/test { job_profile }
 * - AC-39  result notification text: `Routing: <model> · …`
 * - AC-40  usage-state suffix when usageState !== 'normal'
 * - AC-41  'Copy trace id' button → clipboard
 * - AC-42  'Details' button → 13-row QuickPick; select-to-copy
 * - AC-43  `[routing] key=value …` line to AIG output channel
 * - AC-44  single allowed profile → skip picker
 * - AC-46  picker dismissed (undefined) → silent abort
 * - AC-49  backend error → describeBackendError → showErrorMessage
 */
export async function runRoutingCommand(): Promise<void> {
  // AC-36: Sign-in guard — check before any user-facing interaction
  if (!isSignedIn()) {
    const action = await vscode.window.showInformationMessage(
      'You are not signed in to the AIG platform.',
      'AIG: Sign In',
    );
    if (action === 'AIG: Sign In') {
      void vscode.commands.executeCommand('aig.signIn');
    }
    return;
  }

  // AC-37, AC-44, AC-46: Profile selection
  const allowed = getAllowedProfiles();
  let profile: string;

  const directProfile = pickProfileOrSkip(allowed, getConfiguredProfile());
  if (directProfile !== null) {
    // AC-44: exactly one allowed profile → use it directly, skip the picker
    profile = directProfile;
  } else {
    // AC-37: multiple profiles → show picker with configured profile first
    const items = buildProfilePickerItems(allowed, getConfiguredProfile());
    const picked = await vscode.window.showQuickPick(items, {
      placeHolder: 'Select a job profile for the routing test',
    });
    if (picked === undefined) {
      // AC-46: user dismissed the picker → silent abort, no message
      return;
    }
    profile = picked;
  }

  // AC-38: Backend call — POST /api/v1/routing/test { job_profile }
  let result: RoutingTestResult;
  try {
    result = await backendClient.post<RoutingTestResult>('/api/v1/routing/test', {
      job_profile: profile,
    });
  } catch (error: unknown) {
    // AC-49: route every backend error through describeBackendError and show as
    // a VS Code error notification
    vscode.window.showErrorMessage(describeBackendError(error));
    return;
  }

  // AC-43: Log all result fields to the AIG output channel as `[routing] key=value …`
  outputChannel.appendLine('[routing] ' + formatRoutingFields(result));

  // AC-39, AC-40: Format the notification display text
  const text = formatRoutingResult(result);

  // AC-41, AC-42: Notification with action buttons
  const btn = await vscode.window.showInformationMessage(text, 'Copy trace id', 'Details');

  if (btn === 'Copy trace id') {
    // AC-41: copy trace id to the system clipboard
    await vscode.env.clipboard.writeText(result.traceId);
  } else if (btn === 'Details') {
    // AC-42: show the 13-row Details QuickPick; each selected row copies its value
    await showDetailsQuickPick(result);
  }
}

// ---------------------------------------------------------------------------
// Pre-existing dependency stubs (ASSUME-REQ007-A1)
// ---------------------------------------------------------------------------
//
// These `declare` statements allow `tsc --noEmit` to pass while the actual
// implementations are absent from this worktree (architecture R-1 BLOCKING).
//
// IMPORTANT: Replace each declaration with the real import once the
// corresponding pre-existing extension unit is available:
//
//   isSignedIn()         → import from the sign-in unit
//   getAllowedProfiles()  → import from the sign-in / settings unit
//   getConfiguredProfile() → import from the settings unit
//   backendClient.post   → import from the backend-client unit
//   describeBackendError → import from the error-utility module
//   outputChannel        → import from the AIG output-channel module
//
// Security note (NFR pii:authentication-token): none of these stubs or the
// real implementations may write the bearer token to any log or output channel.

declare function isSignedIn(): boolean;
declare function getAllowedProfiles(): string[];
declare function getConfiguredProfile(): string;
declare function describeBackendError(error: unknown): string;
declare const outputChannel: {
  appendLine(line: string): void;
};
declare const backendClient: {
  post<T>(path: string, body: unknown): Promise<T>;
};
