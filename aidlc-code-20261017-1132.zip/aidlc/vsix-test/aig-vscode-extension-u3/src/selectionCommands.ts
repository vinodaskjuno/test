/**
 * Selection editor commands — src/selectionCommands.ts  (FR-CHAT-2, REQ-007)
 *
 * Implements the `aig.explainSelection` and `aig.fixSelection` editor
 * context-menu commands.  Exports a single
 * `runSelectionCommand(type: 'explain' | 'fix'): Promise<void>` that is
 * registered by `extension.ts` (TASK-009).
 *
 * ACs implemented: AC-28, AC-29
 */

import * as vscode from 'vscode';
import { buildSelectionPrefill } from './chatPrompt.js';

// ============================================================
// AMBIENT DECLARATIONS FOR PRE-EXISTING EXTENSION DEPENDENCIES
//
// `sidebarPrefillAPI` is provided by the pre-existing sidebar unit
// (ASSUME-REQ007-A1).  As of VS Code 1.90, the public API for
// prefilling the chat composer is:
//   vscode.commands.executeCommand(
//     'workbench.action.chat.open',
//     { query: string, isPartialQuery: true }
//   )
// which keeps the message in the composer without sending it (AC-29).
//
// Replace this declaration with a real import once the owning sidebar
// unit is available, e.g.:
//   import { sidebarPrefillAPI } from './sidebar'
// ============================================================

/**
 * Opens the VS Code sidebar Chat composer prefilled with `query`.
 * `doNotSend: true` means the composer is populated but the user must
 * press Enter to submit (AC-29).
 *
 * STUB — Replace with real import from the pre-existing sidebar unit.
 *
 * The current implementation falls back to the standard VS Code
 * `workbench.action.chat.open` command with `isPartialQuery: true`,
 * which is the publicly documented equivalent on VS Code ^1.90.0 (R-2).
 */
async function sidebarPrefillAPI(
  query: string,
  _opts: { doNotSend: boolean },
): Promise<void> {
  await vscode.commands.executeCommand('workbench.action.chat.open', {
    query,
    isPartialQuery: true,
  });
}

// ============================================================
// Public API
// ============================================================

/**
 * Runs the 'AIG: Explain Selection' or 'AIG: Fix Selection' command.
 *
 * Steps:
 * 1. Guard: no active editor or no usable text (AC-28).
 * 2. Build the sidebar Chat composer prefill string (AC-29).
 * 3. Open the composer prefilled but NOT auto-sent — user presses Enter (AC-29).
 *
 * @param type  `'explain'` for AIG: Explain Selection;
 *              `'fix'`     for AIG: Fix Selection.
 */
export async function runSelectionCommand(
  type: 'explain' | 'fix',
): Promise<void> {
  // AC-28: require an active text editor.
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showInformationMessage(
      'AIG: open a file and select some code first.',
    );
    return;
  }

  // Prefer the current selection; fall back to the whole file.
  const selText = editor.document.getText(editor.selection);
  const text = selText.length > 0 ? selText : editor.document.getText();

  // AC-28: guard against empty/whitespace-only content.
  if (!text.trim()) {
    vscode.window.showInformationMessage(
      'AIG: open a file and select some code first.',
    );
    return;
  }

  // AC-29: determine the ask text (mirrors AC-20 DEFAULT_ASKS).
  const ask =
    type === 'explain' ? 'Explain this code.' : 'Fix the problems in this code.';

  // AC-29: build the prefill string (30,000-char code-context cap enforced
  //        inside buildSelectionPrefill via SELECTION_COMMAND_LIMIT).
  const prefill = buildSelectionPrefill(ask, text, editor.document.languageId);

  // AC-29: open the sidebar Chat composer prefilled — do NOT auto-send.
  await sidebarPrefillAPI('@aig ' + prefill, { doNotSend: true });
}
