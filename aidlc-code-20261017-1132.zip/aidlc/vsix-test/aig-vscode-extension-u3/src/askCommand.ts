/**
 * AIG: Ask command — src/askCommand.ts  (FR-CHAT-3, REQ-007)
 *
 * Implements the `aig.ask` VS Code command.  Exports a single
 * `runAskCommand(arg?: string): Promise<void>` that is registered by
 * `extension.ts` (TASK-009).
 *
 * ACs implemented: AC-30, AC-31, AC-32, AC-33, AC-34, AC-35, AC-45, AC-47
 *
 * Security invariant (NFR pii:authentication-token):
 *   The bearer token MUST NOT appear in any `outputChannel.appendLine` or
 *   `outputChannel.append` call.  Only the fields enumerated in AC-32 are
 *   written to the output channel.
 */

import * as vscode from 'vscode';

// ============================================================
// AMBIENT DECLARATIONS FOR PRE-EXISTING EXTENSION DEPENDENCIES
//
// These symbols are provided by pre-existing extension units that are not
// present in this worktree (ASSUME-REQ007-A1).  Each `declare` statement
// must be replaced with a real import once the owning module is available:
//
//   isSignedIn           → import { isSignedIn } from './auth'
//                          (or wherever the sign-in unit is published)
//   getConfiguredProfile → import { getConfiguredProfile } from './settings'
//   getBackendEnv        → import { getBackendEnv } from './settings'
//   describeBackendError → import { describeBackendError } from './backendClient'
//   outputChannel        → import { outputChannel } from './outputChannel'
//   backendClient        → import { backendClient } from './backendClient'
// ============================================================

/**
 * Returns true when the user is currently signed in to the AIG platform.
 * Used for the sign-in guard (AC-47).
 *
 * STUB — Replace with real import from the pre-existing sign-in unit.
 */
declare function isSignedIn(): boolean;

/**
 * Returns the active AIG job-profile string from extension settings.
 * Used as the `x-aig-job-profile` header value (AC-31) and in the
 * `[ask] env=… profile=… trace=…` log line (AC-32).
 *
 * STUB — Replace with real import from the pre-existing settings unit.
 */
declare function getConfiguredProfile(): string;

/**
 * Returns the backend environment label (e.g. `'dev'` or `'prod'`) derived
 * from the configured backend URL (AC-32, ASSUME-REQ007-A7).
 *
 * STUB — Replace with real import from the pre-existing settings unit.
 */
declare function getBackendEnv(): string;

/**
 * Maps a raw backend error value to a human-readable string for display
 * (AC-35, AC-48, AC-49).
 *
 * STUB — Replace with real import from the pre-existing backend-client unit.
 */
declare function describeBackendError(error: unknown): string;

/**
 * The shared AIG VS Code output channel that receives log lines (AC-32, AC-43).
 *
 * STUB — Replace with real import from the pre-existing output-channel unit.
 */
declare const outputChannel: vscode.OutputChannel;

// ---------------------------------------------------------------------------
// StreamSSE parameter shape
// ---------------------------------------------------------------------------

/** Parameters for a single SSE streaming request to the AIG backend (AC-31). */
interface StreamSSEParams {
  /** The user-supplied prompt text sent to the AIG model gateway. */
  prompt: string;
  /**
   * HTTP headers attached to the SSE request.
   * Must include `x-aig-job-profile` and `x-aig-trace-id` (AC-31).
   * Must NOT include the bearer token directly (bearer token is managed
   * by the pre-existing backend client — NFR no-keys architecture).
   */
  headers: Record<string, string>;
  /** VS Code cancellation token wired to abort the stream on user cancel (AC-34). */
  token: vscode.CancellationToken;
}

/**
 * Pre-existing backend client that opens an HTTP SSE connection to the AIG
 * gateway and yields response deltas (AC-31..34, ASSUME-REQ007-A1).
 *
 * `streamSSE` yields text deltas until the `[DONE]` sentinel or stream close.
 * Callers detect `[DONE]` to confirm a complete response (AC-33).
 *
 * STUB — Replace with real import from the pre-existing backend-client unit.
 */
declare const backendClient: {
  streamSSE(params: StreamSSEParams): AsyncIterable<string>;
};

// ============================================================
// Internal helpers
// ============================================================

/**
 * Generates a UUID v4-shaped trace ID for each request (AC-31).
 *
 * Uses `Math.random()` for simplicity — acceptable because trace IDs are
 * used for observability correlation only, not for cryptographic purposes.
 */
function generateTraceId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// ============================================================
// Exported command handler — runAskCommand (FR-CHAT-3)
// ============================================================

/**
 * Implements the `aig.ask` VS Code command (FR-CHAT-3).
 *
 * Execution steps (in order):
 *  1. AC-47  — Sign-in guard: abort with message + Sign In button when not signed in.
 *  2. AC-30  — Collect prompt from InputBox, or use the supplied `arg`.
 *  3. AC-45  — Silent cancel when InputBox is dismissed (Escape → `undefined`).
 *  4. AC-31  — Generate trace ID; resolve job profile and backend env.
 *  5. AC-32  — Log `> <prompt>` then `[ask] env=… profile=… trace=…`.
 *  6. AC-34  — Open a cancellable progress notification.
 *  7. AC-31  — Stream over HTTP SSE with `x-aig-job-profile` and `x-aig-trace-id`.
 *  8. AC-32  — Append each response delta to the output channel.
 *  9. AC-33  — Warn "response may be incomplete" when `[DONE]` is never received.
 * 10. AC-32  — Log `[ask] done trace=…` after the stream ends.
 * 11. AC-35  — Route all backend errors through `describeBackendError`.
 *
 * @param arg - Optional pre-supplied prompt string (AC-30).  When omitted,
 *              an InputBox is shown to collect the prompt from the user.
 */
export async function runAskCommand(arg?: string): Promise<void> {
  // ----------------------------------------------------------------
  // AC-47 — Sign-in guard (must be the very first check, before any UI).
  // ----------------------------------------------------------------
  if (!isSignedIn()) {
    const action = await vscode.window.showInformationMessage(
      'You are not signed in to the AIG platform.',
      'AIG: Sign In'
    );
    if (action === 'AIG: Sign In') {
      // Fire-and-forget: executeCommand returns a Thenable but we do not
      // need to await it here — the sign-in flow runs independently.
      void vscode.commands.executeCommand('aig.signIn');
    }
    return;
  }

  // ----------------------------------------------------------------
  // AC-30 — Collect the prompt via InputBox or use the supplied argument.
  // AC-45 — When InputBox is dismissed (Escape), `showInputBox` resolves
  //          to `undefined`; silently cancel with no notification.
  // ----------------------------------------------------------------
  const prompt =
    arg ??
    (await vscode.window.showInputBox({
      placeHolder: 'Ask the AIG gateway...',
    }));

  if (prompt === undefined) {
    // AC-45 — User dismissed the InputBox (Escape): silent cancel, no message.
    return;
  }

  // ----------------------------------------------------------------
  // AC-31 — Generate a fresh, unique trace ID for this request.
  //         Resolve the job profile and backend environment before logging.
  // ----------------------------------------------------------------
  const traceId = generateTraceId();
  const profile = getConfiguredProfile();
  const env = getBackendEnv();

  // ----------------------------------------------------------------
  // AC-32 — Log sequence step 1: prompt line.
  // Security invariant: the bearer token MUST NOT appear here.
  // ----------------------------------------------------------------
  outputChannel.appendLine('> ' + prompt);

  // ----------------------------------------------------------------
  // AC-32 — Log sequence step 2: request metadata line.
  // ----------------------------------------------------------------
  outputChannel.appendLine(
    '[ask] env=' + env + ' profile=' + profile + ' trace=' + traceId
  );

  // ----------------------------------------------------------------
  // AC-34 — Wrap the streaming request in a cancellable VS Code progress
  //         notification.  The `token` from `withProgress` is wired to the
  //         backend SSE stream so the user can cancel mid-flight.
  // AC-35 — Catch all errors and route through `describeBackendError`.
  // ----------------------------------------------------------------
  try {
    await vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: 'AIG: Ask',
        cancellable: true, // AC-34
      },
      async (_, token) => {
        let done = false;

        // AC-31 — Stream over HTTP SSE; attach x-aig-job-profile and
        //         x-aig-trace-id headers.  The VS Code CancellationToken is
        //         passed to the backend client so the in-flight request is
        //         aborted when the user cancels (AC-34).
        for await (const delta of backendClient.streamSSE({
          prompt,
          headers: {
            'x-aig-job-profile': profile, // AC-31
            'x-aig-trace-id': traceId,    // AC-31
          },
          token,
        })) {
          // AC-33 — Track the [DONE] sentinel that marks a complete response.
          if (delta === '[DONE]') {
            done = true;
            break;
          }
          // AC-32 — Log sequence step 3: write each response delta.
          outputChannel.append(delta);
        }

        // AC-33 — If the stream closed without sending [DONE], the response
        //         may be incomplete; warn the user.
        if (!done) {
          void vscode.window.showWarningMessage('response may be incomplete');
        }

        // AC-32 — Log sequence step 4: completion line.
        outputChannel.appendLine('\n[ask] done trace=' + traceId);
      }
    );
  } catch (error) {
    // AC-35 — All backend errors are routed through the shared
    //         `describeBackendError` utility before being shown to the user.
    void vscode.window.showErrorMessage(describeBackendError(error));
  }
}
