/**
 * @aig chat participant request handler — FR-CHAT-1 (REQ-007)
 *
 * Implements the VS Code `@aig` chat participant handler and follow-up
 * provider. Exports `handleChatRequest` and `chatFollowupProvider` for
 * import by `extension.ts` (TASK-009).
 *
 * Thin orchestrator pattern (storefront:api/app/routes/orders.py:1-46):
 * all prompt-assembly logic is delegated to `chatPrompt.ts` (TASK-004).
 *
 * ACs implemented: AC-3, AC-9, AC-10, AC-21, AC-22, AC-23, AC-24,
 *                  AC-25, AC-26, AC-27, AC-48
 *
 * Security invariant (NFR pii:authentication-token):
 *   The bearer token MUST NOT appear in any stream.markdown() call or in
 *   any log line written by this file. All outbound calls that carry the
 *   bearer token flow exclusively through the pre-existing backend client.
 */

import * as vscode from 'vscode';
import {
  parseCommand,
  resolveContextFromReferences,
  matchesContextHints,
  truncateCode,
  buildHistory,
  buildTaskPrompt,
  assembleRequest,
  SYSTEM_PROMPT,
  CODE_CONTEXT_LIMIT,
} from './chatPrompt.js';

// ============================================================================
// AMBIENT DECLARATIONS FOR PRE-EXISTING EXTENSION DEPENDENCIES
//
// These symbols are provided by pre-existing extension units that are absent
// from this worktree (ASSUME-REQ007-A1, architecture R-1 BLOCKING).
//
// Replace each `declare` with a real import once the owning module is available:
//
//   isSignedIn           → import { isSignedIn } from './auth'
//                          (or wherever the sign-in unit is published)
//   getConfiguredProfile → import { getConfiguredProfile } from './settings'
//   describeBackendError → import { describeBackendError } from './backendClient'
//   backendClient        → import { backendClient } from './backendClient'
//
// Security note (NFR no-keys architecture): the bearer token is owned by the
// pre-existing backend client; none of these stubs receive or log it.
// ============================================================================

/**
 * Returns `true` when the user is signed in to the AIG platform (AC-3).
 * STUB — Replace with real import from the pre-existing sign-in unit.
 */
declare function isSignedIn(): boolean;

/**
 * Returns the active AIG job-profile label from extension settings (AC-21).
 * STUB — Replace with real import from the pre-existing settings unit.
 */
declare function getConfiguredProfile(): string;

/**
 * Maps a raw backend error value to a human-readable message (AC-25, AC-48).
 * STUB — Replace with real import from the pre-existing backend-client unit.
 */
declare function describeBackendError(error: unknown): string;

/**
 * Pre-existing backend client that streams chat responses from the AIG gateway.
 *
 * `streamChat` yields string deltas until the stream is exhausted or
 * the cancellation `token` fires (AC-22, AC-23, ASSUME-REQ007-A1).
 *
 * STUB — Replace with real import from the pre-existing backend-client unit.
 */
declare const backendClient: {
  streamChat(assembled: string, token: vscode.CancellationToken): AsyncIterable<string>;
};

// ============================================================================
// Internal helpers
// ============================================================================

/**
 * Generates a UUID v4-shaped trace ID per request for inclusion in result
 * metadata (AC-24).  Uses Math.random() — acceptable because trace IDs are
 * used for observability correlation only, not cryptographic purposes.
 */
function generateTraceId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Reads the text content and language ID of a resolved resource (AC-7, AC-8).
 *
 * Accepts a `vscode.Uri` (whole file) or a `vscode.Location` (range within a
 * file). Returns `null` when the document cannot be opened or the resource
 * type is not recognised.
 */
async function readResourceContent(
  resource: unknown,
): Promise<{ text: string; languageId: string } | null> {
  try {
    let uri: vscode.Uri;
    let range: vscode.Range | undefined;

    if (resource instanceof vscode.Uri) {
      uri = resource;
    } else if (resource instanceof vscode.Location) {
      uri = resource.uri;
      range = resource.range;
    } else {
      return null;
    }

    const doc = await vscode.workspace.openTextDocument(uri);
    const text = range !== undefined ? doc.getText(range) : doc.getText();
    return { text, languageId: doc.languageId };
  } catch {
    // If the document cannot be opened (e.g. binary or inaccessible), treat
    // this reference as unresolvable and fall through to the active-editor
    // fallback (AC-8).
    return null;
  }
}

/** Guidance text shown when both prompt and code context are absent (AC-9). */
const GUIDANCE_MESSAGE =
  'To use the AIG coding assistant, select some code and try /explain, /fix or /tests, or type your question directly.';

// ============================================================================
// AC-3..27, AC-48 — Chat participant request handler (FR-CHAT-1)
// ============================================================================

/**
 * Main request handler for the `@aig` VS Code chat participant.
 *
 * Registered in `extension.ts` (TASK-009) via:
 *   `vscode.chat.createChatParticipant('aig', handleChatRequest)`
 *
 * Execution order (matches architecture FR-CHAT-1 flow):
 *  1. AC-3  — Sign-in guard
 *  2. AC-4..6 — Parse slash command
 *  3. AC-7  — Resolve explicit references
 *  4. AC-8  — Fall back to active editor when warranted
 *  5. AC-9  — Empty guard
 *  6. AC-10 — Cite the resolved resource
 *  7. AC-12 — Truncate code context to 24,000 chars
 *  8. AC-11 — Build @aig-only history (last 10 turns, user-first, within budget)
 *  9. AC-17..20 — Build task-specific prompt
 * 10. AC-16, AC-13 — Assemble full request (truncated at 40,000 chars)
 * 11. AC-21 — Show progress with job-profile label
 * 12. AC-22, AC-23 — Stream deltas; wire cancellation token to backend
 * 13. AC-24 — Populate result metadata
 * 14. AC-25, AC-48 — Error handling
 */
export async function handleChatRequest(
  request: vscode.ChatRequest,
  context: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken,
): Promise<vscode.ChatResult> {
  // -------------------------------------------------------------------------
  // AC-3 — Sign-in guard: check before any other work; return a signed-out
  //         reply without touching the backend.
  // -------------------------------------------------------------------------
  if (!isSignedIn()) {
    stream.markdown('You are not signed in to the AIG platform.');
    stream.button({ command: 'aig.signIn', title: 'AIG: Sign In' });
    return {};
  }

  // -------------------------------------------------------------------------
  // AC-4, AC-5, AC-6 — Extract slash command and effective prompt text.
  //
  // parseCommand() priority:
  //   1. request.command field (AC-4)
  //   2. /token prefix in the prompt (AC-5)
  //   3. Unknown tokens → null command, prompt unchanged (AC-6)
  // -------------------------------------------------------------------------
  const { command, promptText } = parseCommand(request);

  // -------------------------------------------------------------------------
  // AC-7 — Resolve explicit chat references (#file, #selection, Uri, Location).
  //         The first readable, non-untitled reference wins.
  //
  // ChatPromptReference.value can be string | Uri | Location | unknown.
  // Adapt to the { uri?, location? } shape expected by resolveContextFromReferences.
  // -------------------------------------------------------------------------
  const adaptedRefs = Array.from(request.references).map((ref) => {
    const v = ref.value;
    if (v instanceof vscode.Uri) {
      return { uri: v as unknown };
    }
    if (v instanceof vscode.Location) {
      return { location: v as unknown };
    }
    // Non-URI / non-Location references (e.g. plain string) are ignored.
    return {} as { uri?: unknown; location?: unknown };
  });

  let codeContext: string | null = null;
  let resource: vscode.Uri | vscode.Location | null = null;
  let languageId: string | undefined;

  const resolvedRef = resolveContextFromReferences(adaptedRefs);
  if (resolvedRef !== null) {
    const content = await readResourceContent(resolvedRef.resource);
    if (content !== null && content.text.length > 0) {
      codeContext = content.text;
      languageId = content.languageId;
      // Narrow the unknown resource back to its concrete VS Code type.
      if (resolvedRef.resource instanceof vscode.Uri) {
        resource = resolvedRef.resource;
      } else if (resolvedRef.resource instanceof vscode.Location) {
        resource = resolvedRef.resource;
      }
    }
  }

  // -------------------------------------------------------------------------
  // AC-8 — When no explicit reference was resolved, fall back to the active
  //         editor's selection (or whole file) whenever the request implies
  //         code context is expected (slash command present OR prompt matches
  //         a context-hint phrase).
  // -------------------------------------------------------------------------
  if (codeContext === null && (command !== null || matchesContextHints(promptText))) {
    const editor = vscode.window.activeTextEditor;
    if (editor !== undefined) {
      languageId = editor.document.languageId;
      const selText = editor.document.getText(editor.selection);
      codeContext = selText.length > 0 ? selText : editor.document.getText();
      resource = editor.document.uri;
    }
  }

  // -------------------------------------------------------------------------
  // AC-9 — No prompt and no code context: show guidance and return early.
  // -------------------------------------------------------------------------
  if (!promptText && codeContext === null) {
    stream.markdown(GUIDANCE_MESSAGE);
    return {};
  }

  // -------------------------------------------------------------------------
  // AC-10 — Cite the resolved resource so VS Code renders an inline reference.
  // -------------------------------------------------------------------------
  if (codeContext !== null && resource !== null) {
    stream.reference(resource);
  }

  // -------------------------------------------------------------------------
  // AC-12 — Hard-cap code context at 24,000 characters; append truncation
  //         marker when over the limit.
  // -------------------------------------------------------------------------
  const truncatedContext = truncateCode(codeContext ?? '', CODE_CONTEXT_LIMIT);

  // -------------------------------------------------------------------------
  // AC-11 — Build @aig-only history: last 10 turns, user-first, within budget.
  // -------------------------------------------------------------------------
  const history = buildHistory(context.history, 10);

  // -------------------------------------------------------------------------
  // AC-17..20 — Build task-specific prompt text.
  //   explain → summary, how it works, edge cases, risks (AC-17)
  //   fix     → list problems + corrected code in one block (AC-18)
  //   tests   → pytest/vitest/jest in one block (AC-19)
  //   null    → freeform; AC-20 default asks apply when userPrompt is empty
  // -------------------------------------------------------------------------
  const taskPrompt = buildTaskPrompt(command, promptText, languageId);

  // -------------------------------------------------------------------------
  // AC-16, AC-13 — Assemble the full request (system prompt + history +
  //                context + task prompt); truncated at 40,000 chars.
  // -------------------------------------------------------------------------
  const assembled = assembleRequest({
    systemPrompt: SYSTEM_PROMPT,
    history,
    codeContext: truncatedContext,
    taskPrompt,
  });

  // -------------------------------------------------------------------------
  // AC-21 — Show a progress notification while the backend call is in flight.
  //         The token supplied to handleChatRequest is the VS Code chat
  //         cancellation signal (AC-23); withProgress's own cancellable is
  //         not needed here.
  // -------------------------------------------------------------------------
  const jobProfile = getConfiguredProfile();
  const traceId = generateTraceId();

  await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: `Asking the AIG gateway (${jobProfile})…`,
      cancellable: false,
    },
    async () => {
      try {
        // AC-22, AC-23 — Forward each delta as markdown; `token` wires the
        // VS Code chat cancellation signal to the backend stream so the
        // user can cancel mid-flight.
        for await (const delta of backendClient.streamChat(assembled, token)) {
          stream.markdown(delta);
        }
      } catch (error: unknown) {
        // AC-25 — Exact message for the portkey_key_not_configured error code.
        if (
          typeof error === 'object' &&
          error !== null &&
          (error as { code?: unknown }).code === 'portkey_key_not_configured'
        ) {
          stream.markdown(
            'The Portkey gateway key is not configured on the AIG backend.',
          );
        } else {
          // AC-48 — All other backend errors routed through describeBackendError.
          stream.markdown(describeBackendError(error));
        }
      }
    },
  );

  // -------------------------------------------------------------------------
  // AC-24 — Return result metadata: command, traceId, tokens, model, route.
  //         `tokens`, `model`, and `route` are null here because the pre-existing
  //         backend client stub does not yet surface those fields; the real
  //         client implementation will populate them from the backend response.
  // -------------------------------------------------------------------------
  return {
    metadata: {
      command,
      traceId,
      tokens: null,
      model: null,
      route: null,
    },
  };
}

// ============================================================================
// AC-26, AC-27 — Follow-up suggestion provider
// ============================================================================

/**
 * Follow-up suggestion provider for the `@aig` chat participant.
 *
 * Registered in `extension.ts` via:
 *   `participant.followupProvider = chatFollowupProvider`
 *
 * - After `explain`: suggests 'Write tests for it' (triggers `/tests`) — AC-26.
 * - After `fix`:     suggests 'Write tests for the fix' (triggers `/tests`) — AC-27.
 * - After `tests` or freeform: no follow-up (ASSUME-REQ007-A8).
 */
export const chatFollowupProvider: vscode.ChatFollowupProvider = {
  provideFollowups(
    result: vscode.ChatResult,
    _context: vscode.ChatContext,
    _token: vscode.CancellationToken,
  ): vscode.ChatFollowup[] {
    // AC-26 — After /explain: offer 'Write tests for it' → /tests
    if (result.metadata?.['command'] === 'explain') {
      return [{ prompt: 'Write tests for it', command: 'tests' }];
    }
    // AC-27 — After /fix: offer 'Write tests for the fix' → /tests
    if (result.metadata?.['command'] === 'fix') {
      return [{ prompt: 'Write tests for the fix', command: 'tests' }];
    }
    return [];
  },
};
