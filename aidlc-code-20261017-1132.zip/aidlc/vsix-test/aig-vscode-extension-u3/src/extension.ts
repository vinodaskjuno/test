/**
 * Extension activation entry point — src/extension.ts  (REQ-007)
 *
 * Implements the VS Code extension `activate()` and `deactivate()` functions.
 * Wires all command handlers and, when available, the `@aig` chat participant
 * into VS Code's registration APIs.
 *
 * ACs implemented: AC-1, AC-2
 *
 * Imports:
 *   handleChatRequest, chatFollowupProvider  ← ./chatParticipant  (TASK-007)
 *   runSelectionCommand                       ← ./selectionCommands (TASK-008)
 *   runAskCommand                             ← ./askCommand        (TASK-005)
 *   runRoutingCommand                         ← ./routingCommand    (TASK-006)
 */

import * as vscode from 'vscode';
import { handleChatRequest, chatFollowupProvider } from './chatParticipant.js';
import { runSelectionCommand } from './selectionCommands.js';
import { runAskCommand } from './askCommand.js';
import { runRoutingCommand } from './routingCommand.js';

/**
 * Called by VS Code when the extension is first activated.
 *
 * @param context - The extension context supplied by the VS Code host.
 */
export function activate(context: vscode.ExtensionContext): void {
  // --------------------------------------------------------------------------
  // AC-1 — Conditional chat participant registration.
  //
  // The VS Code Chat participant API was stabilised in VS Code 1.90.  On older
  // hosts (or in environments that do not expose the API) the property may be
  // absent.  The `typeof` guard ensures activation completes silently without
  // throwing a TypeError (AC-1: "silent no-op").
  //
  // AC-2 — Icon path: vscode.Uri.joinPath resolves to `<extensionUri>/media/aig-icon.png`,
  //          which is the committed asset from TASK-002.
  // --------------------------------------------------------------------------
  if (typeof vscode.chat?.createChatParticipant === 'function') {
    const participant = vscode.chat.createChatParticipant('aig', handleChatRequest);

    // AC-2: point VS Code at the committed icon asset.
    participant.iconPath = vscode.Uri.joinPath(
      context.extensionUri,
      'media',
      'aig-icon.png',
    );

    // AC-26, AC-27: attach the follow-up suggestion provider.
    participant.followupProvider = chatFollowupProvider;

    context.subscriptions.push(participant);
  }
  // When vscode.chat.createChatParticipant is absent: silent no-op (AC-1).

  // --------------------------------------------------------------------------
  // FR-CHAT-2 — Editor context-menu selection commands (AC-28, AC-29).
  //
  // `runSelectionCommand` is a single export from selectionCommands.ts that
  // accepts the command type as its first argument.  Each registration passes
  // a lambda so the VS Code command dispatch signature (no required args) is
  // satisfied while forwarding the correct type string.
  // --------------------------------------------------------------------------
  context.subscriptions.push(
    vscode.commands.registerCommand('aig.explainSelection', () =>
      runSelectionCommand('explain'),
    ),
    vscode.commands.registerCommand('aig.fixSelection', () =>
      runSelectionCommand('fix'),
    ),

    // FR-CHAT-3 — AIG: Ask (AC-30..35, AC-45, AC-47).
    //
    // `runAskCommand` accepts an optional string argument (AC-30) that is
    // forwarded directly when the command is invoked programmatically with a
    // pre-supplied prompt.  VS Code passes `undefined` when the command is
    // triggered from the command palette.
    vscode.commands.registerCommand('aig.ask', (arg?: string) =>
      runAskCommand(arg),
    ),

    // FR-CHAT-4 — AIG: Test model routing (AC-36..44, AC-46, AC-49).
    vscode.commands.registerCommand('aig.testModelRouting', runRoutingCommand),
  );
}

/**
 * Called by VS Code when the extension is deactivated.
 *
 * No explicit cleanup is required: all disposables pushed to
 * `context.subscriptions` in `activate()` are disposed automatically by the
 * VS Code host.
 */
export function deactivate(): void {
  // intentional no-op
}
