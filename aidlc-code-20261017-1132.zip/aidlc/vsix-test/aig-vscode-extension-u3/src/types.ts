/**
 * Shared TypeScript interfaces and type aliases for the AIG VS Code extension
 * coding-assistant unit (FR-CHAT-1..4, REQ-007).
 *
 * Design constraints:
 * - Zero VS Code API imports (no `import * as vscode from 'vscode'`).
 * - Zero runtime side-effects — interfaces and type aliases only.
 * - Pattern: storefront:web/lib/api.ts:1-12
 */

// ---------------------------------------------------------------------------
// AC-38..43 — Routing test response shape from POST /api/v1/routing/test
// ---------------------------------------------------------------------------

/** Response payload returned by POST /api/v1/routing/test (AC-38). */
export interface RoutingTestResult {
  result: string;
  model: string;
  provider: string;
  tier: string;
  costMode: string;
  jobProfile: string;
  /** 'normal' or any non-normal value that triggers the usage-state suffix (AC-40). */
  usageState: string;
  /** Human-readable usage description; present when usageState !== 'normal' (AC-40). */
  usageDescription?: string;
  latencyMs: number;
  /** Integer token count reported by the backend, or null when omitted (AC-42, AC-43). */
  tokens: number | null;
  cache: string | null;
  answer: string | null;
  error: string | null;
  traceId: string;
}

// ---------------------------------------------------------------------------
// AC-25, AC-48, AC-49 — Discriminated error from the AIG backend
// ---------------------------------------------------------------------------

/** Error payload returned (or constructed) from an AIG backend failure. */
export interface BackendError {
  /** Machine-readable error code, e.g. 'portkey_key_not_configured' (AC-25). */
  code?: string;
  /** Human-readable error description produced by describeBackendError(). */
  message: string;
}

// ---------------------------------------------------------------------------
// AC-4..6 — Recognised slash commands for the @aig chat participant
// ---------------------------------------------------------------------------

/**
 * The set of recognised slash-command values that the @aig participant acts on
 * (AC-4, AC-5). `null` means no recognised command was detected (AC-6 — unknown
 * tokens are left as literal text in the prompt).
 */
export type ChatCommand = 'explain' | 'fix' | 'tests' | null;

// ---------------------------------------------------------------------------
// AC-7, AC-10 — Resolved code context with its VS Code resource reference
// ---------------------------------------------------------------------------

/**
 * Code context resolved from an explicit chat reference or the active editor.
 *
 * `resource` is typed `unknown` here to keep this file free of VS Code API
 * imports (which would make it environment-dependent).  Command handlers
 * narrow it to `vscode.Uri | vscode.Location` at their call sites (AC-7,
 * AC-10).
 */
export interface ResolvedContext {
  /** The resolved source-code text (may be truncated later by truncateCode). */
  text: string;
  /** vscode.Uri | vscode.Location — typed as unknown, narrowed at call site. */
  resource: unknown;
}

// ---------------------------------------------------------------------------
// AC-11 — Single turn in the @aig chat history
// ---------------------------------------------------------------------------

/**
 * One turn from the @aig participant's conversation history (AC-11).
 * buildHistory() filters to @aig turns only, takes the last 10, trims to
 * budget, and ensures the sequence starts with a user turn.
 */
export interface HistoryTurn {
  role: 'user' | 'assistant';
  content: string;
}
