/**
 * Pure-functions module for all prompt-assembly logic.
 *
 * Design constraints (ADR-2):
 * - Zero VS Code API imports.
 * - All functions are pure: inputs → outputs, no side-effects.
 * - Enables Vitest `environment: node` testing without a VS Code extension host.
 *
 * AC coverage: AC-4, AC-5, AC-6, AC-7, AC-8, AC-11, AC-12, AC-13,
 *              AC-14, AC-15, AC-16, AC-17, AC-18, AC-19, AC-20, AC-29
 */

import type { ChatCommand, ResolvedContext, HistoryTurn } from './types.js';

// ============================================================================
// Constants
// ============================================================================

/**
 * AC-16: Exact verbatim system prompt for the AIG coding assistant.
 *
 * This is a compile-time constant — not a template literal and not
 * user-configurable — to prevent prompt-injection overrides (NFR LLM01).
 * Tests MUST assert exact string equality: `expect(SYSTEM_PROMPT).toBe(...)`.
 */
export const SYSTEM_PROMPT: string =
  'You are the AIG coding assistant inside VS Code, served through the AIG model gateway.' +
  ' Be concise and precise.' +
  ' Use Markdown; put code in fenced blocks with a language.' +
  ' Never ask for or reveal API keys or credentials.' +
  ' If code context is provided, base the answer on it and say when something cannot be determined from it.';

/**
 * AC-8: Context-hint phrases used by matchesContextHints().
 * Matched via case-insensitive substring search (ASSUME-REQ007-A3).
 */
export const CONTEXT_HINTS: readonly string[] = [
  'this function',
  'the selected code',
  '#selection',
  'explain it',
];

/** AC-12: Hard cap (characters) for code context in the @aig chat participant. */
export const CODE_CONTEXT_LIMIT = 24_000;

/** AC-13: Hard cap (characters) for the total assembled @aig request. */
export const REQUEST_LIMIT = 40_000;

/** AC-29: Hard cap (characters) for code context in the FR-CHAT-2 sidebar prefill. */
export const SELECTION_COMMAND_LIMIT = 30_000;

/**
 * AC-20: Default ask texts used when the user prompt is empty for a
 * recognised slash command.
 */
export const DEFAULT_ASKS: Record<'explain' | 'fix' | 'tests', string> = {
  explain: 'Explain this code.',
  fix: 'Fix the problems in this code.',
  tests: 'Write unit tests for this code.',
};

// Internal: recognised slash-command names.
const KNOWN_COMMANDS = new Set<string>(['explain', 'fix', 'tests']);

// Internal: participant ID for the @aig chat participant.
const AIG_PARTICIPANT_ID = 'aig';

// ============================================================================
// AC-4, AC-5, AC-6 — parseCommand
// ============================================================================

/**
 * Extracts the slash command and effective prompt text from a chat request.
 *
 * Priority order (AC-4 → AC-5 → AC-6):
 * 1. If `request.command` is a recognised command ('explain', 'fix', 'tests'),
 *    use it and keep `request.prompt` unchanged (AC-4).
 * 2. If `request.command` is absent, try parsing a `/token` prefix from the
 *    prompt. When the token is recognised, strip it and return the remainder
 *    as promptText (AC-5).
 * 3. In all other cases — including unrecognised `request.command` values and
 *    unrecognised `/xxx` prefixes — return `command: null` and leave the
 *    prompt text unchanged (AC-6: unknown tokens stay as literal text).
 */
export function parseCommand(
  request: { command?: string; prompt: string },
): { command: ChatCommand; promptText: string } {
  // AC-4: explicit request.command takes priority.
  if (request.command !== undefined && request.command !== '') {
    const cmd = request.command.toLowerCase();
    if (KNOWN_COMMANDS.has(cmd)) {
      return { command: cmd as ChatCommand, promptText: request.prompt };
    }
    // Unrecognised request.command — AC-6: no command, prompt unchanged.
    return { command: null, promptText: request.prompt };
  }

  // AC-5: try to parse a /token prefix from the prompt text.
  const match = /^\/(\S+)([\s\S]*)$/.exec(request.prompt);
  if (match !== null) {
    const token = match[1].toLowerCase();
    const rest = match[2].trimStart();
    if (KNOWN_COMMANDS.has(token)) {
      return { command: token as ChatCommand, promptText: rest };
    }
    // AC-6: unrecognised /xxx token — leave prompt as-is, no command.
    return { command: null, promptText: request.prompt };
  }

  return { command: null, promptText: request.prompt };
}

// ============================================================================
// AC-7 — resolveContextFromReferences
// ============================================================================

/**
 * Returns the first explicit chat reference that is not an `untitled` file.
 *
 * - Skips references whose URI scheme is 'untitled' (AC-7).
 * - Returns `null` when no readable non-untitled reference is found.
 *
 * The `text` field in the returned `ResolvedContext` is set to an empty string
 * here; the caller (chatParticipant.ts) reads the actual file content from the
 * VS Code workspace API using the returned `resource`.
 */
export function resolveContextFromReferences(
  references: Array<{ uri?: unknown; location?: unknown }>,
): ResolvedContext | null {
  for (const ref of references) {
    // Determine the primary resource (URI or Location).
    const resource = ref.uri ?? ref.location;
    if (resource === undefined || resource === null) continue;

    // Extract the URI for scheme inspection (Location objects carry a nested .uri).
    const uri: unknown = ref.uri !== undefined
      ? ref.uri
      : (ref.location as { uri?: unknown } | undefined)?.uri;

    if (uri !== undefined && uri !== null) {
      const scheme = (uri as { scheme?: string }).scheme;
      if (scheme === 'untitled') continue; // AC-7: skip untitled files
    }

    // First readable non-untitled reference wins (AC-7).
    return { text: '', resource };
  }
  return null;
}

// ============================================================================
// AC-8 — matchesContextHints
// ============================================================================

/**
 * Returns `true` when `prompt` contains any of the CONTEXT_HINTS phrases
 * (case-insensitive substring match, ASSUME-REQ007-A3).
 */
export function matchesContextHints(prompt: string): boolean {
  const lower = prompt.toLowerCase();
  return CONTEXT_HINTS.some(hint => lower.includes(hint.toLowerCase()));
}

// ============================================================================
// AC-12 — truncateCode
// ============================================================================

/**
 * Truncates `text` to at most `limit` characters.
 * When truncation occurs, appends `… [truncated N characters]` where N is the
 * number of removed characters (AC-12).
 */
export function truncateCode(text: string, limit: number): string {
  if (text.length <= limit) return text;
  const removed = text.length - limit;
  return `${text.slice(0, limit)}… [truncated ${removed} characters]`;
}

// ============================================================================
// AC-11 — buildHistory
// ============================================================================

/**
 * Builds the @aig conversation history for inclusion in a backend request.
 *
 * Rules (AC-11):
 * 1. Filter to @aig participant turns only — no other participants.
 * 2. Take at most the last `limit` turns (e.g. 10).
 * 3. Trim oldest turns so the total history content fits within REQUEST_LIMIT
 *    (preliminary trim; assembleRequest() does the final overall truncation).
 * 4. Ensure the sequence starts with a user turn (drop leading assistant turns).
 *
 * Duck-typed input: history items are `unknown` to avoid VS Code API imports.
 * Expected shapes:
 * - Request/user turn:   `{ participant: string; prompt: string }`
 * - Response/asst turn:  `{ participant: string; response: Array<{ value: string | { value: string } }> }`
 */
export function buildHistory(
  history: readonly unknown[],
  limit: number,
): HistoryTurn[] {
  // Step 1: extract only @aig participant turns with their roles and content.
  const aigTurns: HistoryTurn[] = [];

  for (const item of history) {
    const turn = item as Record<string, unknown>;
    if (turn['participant'] !== AIG_PARTICIPANT_ID) continue;

    if (typeof turn['prompt'] === 'string') {
      // VS Code ChatRequestTurn — user's message
      aigTurns.push({ role: 'user', content: turn['prompt'] });
    } else if (Array.isArray(turn['response'])) {
      // VS Code ChatResponseTurn — assistant's message; assemble from parts
      const textParts: string[] = [];
      for (const part of turn['response'] as unknown[]) {
        const p = part as Record<string, unknown>;
        const val = p['value'];
        if (typeof val === 'string') {
          // Plain string part
          textParts.push(val);
        } else if (val !== null && typeof val === 'object') {
          // vscode.MarkdownString — its text is in .value
          const mdValue = (val as Record<string, unknown>)['value'];
          if (typeof mdValue === 'string') {
            textParts.push(mdValue);
          }
        }
      }
      aigTurns.push({ role: 'assistant', content: textParts.join('') });
    }
  }

  // Step 2: take at most the last `limit` turns.
  const recent = aigTurns.slice(-Math.max(0, limit));

  // Step 3: trim oldest turns so total fits within REQUEST_LIMIT.
  let total = recent.reduce((acc, t) => acc + t.content.length, 0);
  while (total > REQUEST_LIMIT && recent.length > 0) {
    const removed = recent.shift()!;
    total -= removed.content.length;
  }

  // Step 4: ensure the sequence starts with a user turn.
  while (recent.length > 0 && recent[0].role !== 'user') {
    recent.shift();
  }

  return recent;
}

// ============================================================================
// AC-14, AC-15 — remapLanguageId, safeFence
// ============================================================================

/**
 * Remaps VS Code language IDs to conventional Markdown fence identifiers (AC-15).
 *
 * Mappings: `typescriptreact` → `tsx`, `javascriptreact` → `jsx`,
 * `shellscript` → `bash`. All other IDs are returned unchanged.
 */
export function remapLanguageId(id: string): string {
  switch (id) {
    case 'typescriptreact': return 'tsx';
    case 'javascriptreact': return 'jsx';
    case 'shellscript': return 'bash';
    default: return id;
  }
}

/**
 * Wraps `content` in a Markdown code fence whose backtick count is one more
 * than the longest run of backticks found anywhere inside `content` (AC-14).
 * The language identifier is remapped via `remapLanguageId()` (AC-15).
 */
export function safeFence(content: string, lang: string): string {
  const maxRun = longestBacktickRun(content);
  const fence = '`'.repeat(Math.max(3, maxRun + 1));
  const mappedLang = remapLanguageId(lang);
  return `${fence}${mappedLang}\n${content}\n${fence}`;
}

/** Returns the length of the longest consecutive backtick run in `text`. */
function longestBacktickRun(text: string): number {
  let maxRun = 0;
  let current = 0;
  for (const ch of text) {
    if (ch === '`') {
      current += 1;
      if (current > maxRun) maxRun = current;
    } else {
      current = 0;
    }
  }
  return maxRun;
}

// ============================================================================
// AC-17, AC-18, AC-19, AC-20 — buildTaskPrompt
// ============================================================================

/**
 * Constructs the task-specific portion of the user message for the model.
 *
 * - `explain`: summary, how it works, edge cases, risks (AC-17)
 * - `fix`:     list problems then corrected code in one block (AC-18)
 * - `tests`:   pytest or vitest/jest covering normal/edge/error cases (AC-19)
 * - `null`:    freeform — returns userPrompt as-is
 *
 * When `userPrompt` is empty and a recognised command is given, the
 * DEFAULT_ASKS value is used as the effective ask (AC-20).
 *
 * @param languageId  Optional file language ID; used to infer the test
 *   framework for the `tests` command (ASSUME-REQ007-A4):
 *   Python → pytest; JavaScript/TypeScript → vitest/jest; other → vitest/jest.
 */
export function buildTaskPrompt(
  command: ChatCommand,
  userPrompt: string,
  languageId?: string,
): string {
  const effectivePrompt = userPrompt.trim();

  if (command === 'explain') {
    // AC-17: summary, how it works, edge cases, risks
    const ask = effectivePrompt.length > 0 ? effectivePrompt : DEFAULT_ASKS.explain;
    return (
      `${ask}\n\n` +
      'Provide:\n' +
      '1. A summary of what the code does.\n' +
      '2. An explanation of how it works step by step.\n' +
      '3. Edge cases to be aware of.\n' +
      '4. Risks or potential issues.'
    );
  }

  if (command === 'fix') {
    // AC-18: list problems, then corrected code in one fenced block
    const ask = effectivePrompt.length > 0 ? effectivePrompt : DEFAULT_ASKS.fix;
    return (
      `${ask}\n\n` +
      'First list the problems you identify, then provide the corrected code in one fenced code block.'
    );
  }

  if (command === 'tests') {
    // AC-19: pytest or vitest/jest covering normal, edge, error cases
    const ask = effectivePrompt.length > 0 ? effectivePrompt : DEFAULT_ASKS.tests;
    const framework = inferTestFramework(languageId);
    return (
      `${ask}\n\n` +
      `Write ${framework} tests covering normal cases, edge cases, and error cases, all in one fenced code block.`
    );
  }

  // command === null: freeform question — return prompt as-is
  return effectivePrompt;
}

/**
 * Infers the recommended test framework from a language ID (ASSUME-REQ007-A4).
 * Python → 'pytest'; JS/TS variants → 'vitest/jest'; anything else → 'vitest/jest'.
 */
function inferTestFramework(languageId?: string): string {
  if (languageId === 'python') return 'pytest';
  const jsTsLanguages = new Set([
    'javascript',
    'typescript',
    'javascriptreact',
    'typescriptreact',
    'jsx',
    'tsx',
  ]);
  if (languageId !== undefined && jsTsLanguages.has(languageId)) return 'vitest/jest';
  return 'vitest/jest';
}

// ============================================================================
// AC-29 — buildSelectionPrefill
// ============================================================================

/**
 * Builds the sidebar Chat composer prefill text for the FR-CHAT-2 editor
 * commands ('AIG: Explain Selection' / 'AIG: Fix Selection').
 *
 * Format (AC-29, Q-6 answer):
 *   `ask` + newline + safeFence(truncateCode(code, SELECTION_COMMAND_LIMIT), languageId)
 *
 * Code context is hard-capped at SELECTION_COMMAND_LIMIT (30,000 chars).
 */
export function buildSelectionPrefill(
  ask: string,
  code: string,
  languageId: string,
): string {
  const truncated = truncateCode(code, SELECTION_COMMAND_LIMIT);
  return `${ask}\n${safeFence(truncated, languageId)}`;
}

// ============================================================================
// AC-13 — assembleRequest
// ============================================================================

/**
 * Assembles the full request string from its parts and truncates the total
 * to REQUEST_LIMIT when it exceeds that cap (AC-13).
 *
 * Concatenation order:
 *   systemPrompt → history turns → codeContext → taskPrompt
 *   (empty parts are omitted; adjacent parts are separated by '\n\n')
 *
 * When the assembled total exceeds REQUEST_LIMIT, the string is truncated at
 * that limit and `… [truncated N characters]` is appended.
 */
export function assembleRequest(parts: {
  systemPrompt: string;
  history: HistoryTurn[];
  codeContext: string;
  taskPrompt: string;
}): string {
  const historyText = parts.history
    .map(t =>
      t.role === 'user'
        ? `User: ${t.content}`
        : `Assistant: ${t.content}`,
    )
    .join('\n');

  const segments = [
    parts.systemPrompt,
    historyText,
    parts.codeContext,
    parts.taskPrompt,
  ].filter(s => s.length > 0);

  const assembled = segments.join('\n\n');

  if (assembled.length <= REQUEST_LIMIT) return assembled;

  const removed = assembled.length - REQUEST_LIMIT;
  return `${assembled.slice(0, REQUEST_LIMIT)}… [truncated ${removed} characters]`;
}
