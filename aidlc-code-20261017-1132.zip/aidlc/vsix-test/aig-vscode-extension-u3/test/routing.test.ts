/**
 * NFR-designated routing unit test suite — test/routing.test.ts
 *
 * Tests the pure formatting and picker-helper functions exported from
 * `src/routingCommand.ts` (TASK-006).
 *
 * AC coverage:
 *   AC-37  buildProfilePickerItems — configured profile first in picker items
 *   AC-39  formatRoutingResult — result string template
 *   AC-40  formatRoutingResult — usage-state suffix when not normal
 *   AC-42  buildDetailsItems — always 13 rows, correct labels, null → em-dash
 *   AC-43  formatRoutingFields — [routing] key=value log format
 *   AC-44  pickProfileOrSkip — single profile bypasses picker; multiple returns null
 *
 * Runner: Vitest 2, environment: node.
 * No VS Code API mock required — all functions under test are pure.
 */

import { describe, it, expect, vi } from 'vitest';

// vi.mock calls are hoisted by Vitest before all imports, so this mock is
// resolved before routingCommand.ts attempts to load the vscode module.
// The pure formatting functions under test never invoke VS Code APIs, but
// the module-level `import * as vscode from 'vscode'` still requires a stub.
vi.mock('vscode', () => ({
  window: {
    showInformationMessage: vi.fn(),
    showErrorMessage: vi.fn(),
    showQuickPick: vi.fn(),
  },
  env: {
    clipboard: { writeText: vi.fn() },
  },
  commands: { executeCommand: vi.fn() },
}));

import {
  formatRoutingResult,
  formatRoutingFields,
  buildDetailsItems,
  buildProfilePickerItems,
  pickProfileOrSkip,
} from '../src/routingCommand.js';
import type { RoutingTestResult } from '../src/types.js';

// ---------------------------------------------------------------------------
// Shared base fixture
// AC-39 base: all required fields populated; usageState = 'normal'
// tokens is number | null — use integer literal 512 per task spec
// ---------------------------------------------------------------------------
const baseResult: RoutingTestResult = {
  result: 'ok',
  model: 'gpt-4o',
  provider: 'openai',
  tier: 'premium',
  costMode: 'standard',
  jobProfile: 'coding',
  usageState: 'normal',
  latencyMs: 142,
  tokens: 512,      // number | null — integer literal 512 per TASK-011 spec
  cache: null,
  answer: 'hello',
  error: null,
  traceId: 'trace-abc',
};

// ---------------------------------------------------------------------------
// formatRoutingResult — AC-39, AC-40
// ---------------------------------------------------------------------------

describe('formatRoutingResult', () => {
  it('AC-39: formats the result string with the exact template', () => {
    const text = formatRoutingResult(baseResult);
    expect(text).toBe(
      'Routing: gpt-4o · premium · standard · coding — 142 ms (openai)',
    );
  });

  it('AC-40: appends usage-state suffix when usageState is not normal', () => {
    const r: RoutingTestResult = {
      ...baseResult,
      usageState: 'soft',
      usageDescription: 'downgraded because daily requests 4 / 5',
    };
    const text = formatRoutingResult(r);
    expect(text).toContain(' · usage soft: downgraded because daily requests 4 / 5');
  });

  it('AC-40: does not append usage suffix when usageState is normal', () => {
    expect(formatRoutingResult(baseResult)).not.toContain(' · usage');
  });

  it('AC-40: still appends suffix for other non-normal states (e.g. hard)', () => {
    const r: RoutingTestResult = {
      ...baseResult,
      usageState: 'hard',
      usageDescription: 'blocked because monthly limit reached',
    };
    const text = formatRoutingResult(r);
    expect(text).toContain(' · usage hard: blocked because monthly limit reached');
  });

  it('AC-40: appends suffix with empty string when usageDescription is absent', () => {
    const r: RoutingTestResult = {
      ...baseResult,
      usageState: 'soft',
      // usageDescription intentionally omitted
    };
    const text = formatRoutingResult(r);
    // usageDescription ?? '' results in empty string; suffix still present
    expect(text).toContain(' · usage soft: ');
  });
});

// ---------------------------------------------------------------------------
// buildDetailsItems — AC-42
// ---------------------------------------------------------------------------

describe('buildDetailsItems', () => {
  it('AC-42: always returns exactly 13 rows', () => {
    const items = buildDetailsItems(baseResult);
    expect(items).toHaveLength(13);
  });

  it('AC-42: row labels are exactly the 13 specified names in order', () => {
    const labels = buildDetailsItems(baseResult).map(i => i.label);
    expect(labels).toEqual([
      'Result',
      'Model',
      'Provider',
      'Tier',
      'Cost mode',
      'Job profile',
      'Usage state',
      'Latency',
      'Tokens',
      'Cache',
      'Answer',
      'Error',
      'Trace id',
    ]);
  });

  it('AC-42 + ASSUME-REQ007-A6: null fields shown as em-dash, not omitted', () => {
    const r: RoutingTestResult = {
      ...baseResult,
      tokens: null,
      cache: null,
      answer: null,
      error: null,
    };
    const items = buildDetailsItems(r);
    // Still exactly 13 rows (ASSUME-REQ007-A6)
    expect(items).toHaveLength(13);
  });

  it('AC-42: null tokens field renders as em-dash in description', () => {
    const r: RoutingTestResult = { ...baseResult, tokens: null };
    const items = buildDetailsItems(r);
    const tokensRow = items.find(i => i.label === 'Tokens');
    expect(tokensRow).toBeDefined();
    expect(tokensRow!.description).toBe('—');
  });

  it('AC-42: non-null tokens field renders as its string value', () => {
    const items = buildDetailsItems(baseResult);
    const tokensRow = items.find(i => i.label === 'Tokens');
    expect(tokensRow).toBeDefined();
    expect(tokensRow!.description).toBe('512');
  });

  it('AC-42: traceId row contains the correct trace id value', () => {
    const items = buildDetailsItems(baseResult);
    const traceRow = items.find(i => i.label === 'Trace id');
    expect(traceRow).toBeDefined();
    expect(traceRow!.description).toBe('trace-abc');
  });
});

// ---------------------------------------------------------------------------
// formatRoutingFields — AC-43
// ---------------------------------------------------------------------------

describe('formatRoutingFields', () => {
  it('AC-43: log line starts with key=value pairs for result, model, provider', () => {
    const line = formatRoutingFields(baseResult);
    expect(line).toMatch(/^result=.+ model=.+ provider=.+/);
  });

  it('AC-43: log line contains traceId=trace-abc', () => {
    const line = formatRoutingFields(baseResult);
    expect(line).toContain('traceId=trace-abc');
  });

  it('AC-43: log line contains all 13 key=value fields', () => {
    const line = formatRoutingFields(baseResult);
    const expectedKeys = [
      'result=', 'model=', 'provider=', 'tier=', 'costMode=',
      'jobProfile=', 'usageState=', 'latencyMs=', 'tokens=',
      'cache=', 'answer=', 'error=', 'traceId=',
    ];
    for (const key of expectedKeys) {
      expect(line).toContain(key);
    }
  });

  it('AC-43: null field values are rendered as em-dash in log line', () => {
    const r: RoutingTestResult = { ...baseResult, cache: null, error: null };
    const line = formatRoutingFields(r);
    // cache and error are null → should render as '—'
    expect(line).toContain('cache=—');
    expect(line).toContain('error=—');
  });
});

// ---------------------------------------------------------------------------
// buildProfilePickerItems — AC-37
// ---------------------------------------------------------------------------

describe('buildProfilePickerItems', () => {
  it('AC-37: configured profile appears first when it is in the allowed list', () => {
    const items = buildProfilePickerItems(['premium', 'coding', 'standard'], 'coding');
    expect(items[0]).toBe('coding');
  });

  it('AC-37: all allowed profiles are included in picker items', () => {
    const items = buildProfilePickerItems(['premium', 'coding', 'standard'], 'coding');
    expect(items).toHaveLength(3);
    expect(items).toContain('premium');
    expect(items).toContain('coding');
    expect(items).toContain('standard');
  });

  it('AC-37: configured profile not duplicated in picker items', () => {
    const items = buildProfilePickerItems(['premium', 'coding', 'standard'], 'coding');
    const codingCount = items.filter(p => p === 'coding').length;
    expect(codingCount).toBe(1);
  });

  it('AC-37: when configured profile is not in allowed list, order is unchanged', () => {
    const items = buildProfilePickerItems(['premium', 'coding', 'standard'], 'other');
    expect(items).toEqual(['premium', 'coding', 'standard']);
  });

  it('AC-37: single allowed profile list returns that profile as sole item', () => {
    const items = buildProfilePickerItems(['solo'], 'solo');
    expect(items).toEqual(['solo']);
  });
});

// ---------------------------------------------------------------------------
// pickProfileOrSkip — AC-44
// ---------------------------------------------------------------------------

describe('pickProfileOrSkip', () => {
  it('AC-44: single profile returns that profile directly — skips picker', () => {
    expect(pickProfileOrSkip(['only-profile'], 'other')).toBe('only-profile');
  });

  it('AC-44: single profile returns it regardless of configured value', () => {
    expect(pickProfileOrSkip(['only-profile'], 'only-profile')).toBe('only-profile');
  });

  it('AC-44: multiple profiles returns null — picker must be shown', () => {
    expect(pickProfileOrSkip(['profile-a', 'profile-b'], 'profile-a')).toBeNull();
  });

  it('AC-44: three profiles returns null — picker must be shown', () => {
    expect(pickProfileOrSkip(['a', 'b', 'c'], 'a')).toBeNull();
  });
});
