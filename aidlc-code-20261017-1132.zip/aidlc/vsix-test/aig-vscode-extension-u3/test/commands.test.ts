/**
 * Command handler unit tests — test/commands.test.ts  (REQ-007, TASK-012)
 *
 * Covers AC-1..3, AC-9, AC-10, AC-21..28, AC-30, AC-32..36, AC-38, AC-41,
 * AC-45..49 plus the NFR pii:authentication-token security assertion.
 *
 * Pattern: Vitest 2, environment: node, vi.mock('vscode', ...) for VS Code APIs,
 * vi.stubGlobal for pre-existing dependency stubs declared in source files.
 * (storefront:web/tests/OrdersTable.test.tsx — describe/it, inline fixtures, vi.fn())
 *
 * Design note: The source modules (chatParticipant.ts, askCommand.ts, etc.) declare
 * their pre-existing dependencies with TypeScript `declare` statements that compile
 * to free-variable references resolved from the global scope at runtime.  Tests
 * inject those symbols via vi.stubGlobal so each module under test can be exercised
 * without the real extension host.
 */

import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest';
import type { MockInstance } from 'vitest';

// ---------------------------------------------------------------------------
// vscode module mock — hoisted before any imports
// ---------------------------------------------------------------------------
//
// The mock returns a plain object that mirrors the VS Code API surface used
// by the four command handler modules.  Per-test overrides are applied via
// vi.mocked() and mockImplementation/mockResolvedValue within each describe
// block.
//
// A mutable `_mockParticipant` object is shared so AC-2 tests can inspect
// the iconPath that activate() writes to it.

const _mockParticipant: {
  iconPath: unknown;
  followupProvider: unknown;
  dispose: ReturnType<typeof vi.fn>;
} = {
  iconPath: undefined,
  followupProvider: undefined,
  dispose: vi.fn(),
};

vi.mock('vscode', () => ({
  chat: {
    createChatParticipant: vi.fn(() => _mockParticipant),
  },
  window: {
    showInformationMessage: vi.fn(),
    showErrorMessage: vi.fn(),
    showWarningMessage: vi.fn(),
    showInputBox: vi.fn(),
    showQuickPick: vi.fn(),
    withProgress: vi.fn(),
    // VS Code API type is TextEditor | undefined; using undefined so that the
    // `editor !== undefined` guard in chatParticipant.ts correctly skips the
    // editor-context path when no editor is available.
    activeTextEditor: undefined as unknown,
  },
  commands: {
    registerCommand: vi.fn(() => ({ dispose: vi.fn() })),
    executeCommand: vi.fn(),
  },
  env: {
    clipboard: { writeText: vi.fn() },
  },
  // Uri: needs to be a class so extension code can call Uri.joinPath
  Uri: class MockUri {
    static joinPath(_base: unknown, ...segments: string[]) {
      return { fsPath: segments.join('/'), toString: () => segments.join('/') };
    }
  },
  // Location: needs to be a class for instanceof checks in chatParticipant.ts
  Location: class MockLocation {},
  ProgressLocation: { Notification: 15 },
  workspace: {
    openTextDocument: vi.fn(),
  },
  // CancellationToken type only (not used as a class at runtime in these tests)
}));

// ---------------------------------------------------------------------------
// Imports of modules under test (after vi.mock is hoisted)
// ---------------------------------------------------------------------------

import * as vscode from 'vscode';
import { activate } from '../src/extension.js';
import { handleChatRequest, chatFollowupProvider } from '../src/chatParticipant.js';
import { runSelectionCommand } from '../src/selectionCommands.js';
import { runAskCommand } from '../src/askCommand.js';
import { runRoutingCommand } from '../src/routingCommand.js';

// ---------------------------------------------------------------------------
// Helpers: async stream generators for backendClient mocks
// ---------------------------------------------------------------------------

async function* makeStream(...deltas: string[]): AsyncIterable<string> {
  for (const delta of deltas) {
    yield delta;
  }
}

// ---------------------------------------------------------------------------
// Helpers: VS Code request / context / stream / token stubs
// ---------------------------------------------------------------------------

function makeStream_chat(mockStream: unknown) {
  return vi.fn().mockReturnValue(mockStream);
}

function createMockChatStream() {
  return {
    markdown: vi.fn(),
    button: vi.fn(),
    reference: vi.fn(),
    progress: vi.fn(),
    anchor: vi.fn(),
  };
}

function createMockChatContext(history: unknown[] = []) {
  return { history };
}

function createMockCancellationToken(cancelled = false) {
  return {
    isCancellationRequested: cancelled,
    onCancellationRequested: vi.fn(),
  };
}

function createMockChatRequest(opts: {
  command?: string;
  prompt?: string;
  references?: unknown[];
} = {}) {
  return {
    command: opts.command,
    prompt: opts.prompt ?? '',
    references: opts.references ?? [],
  };
}

/** A mock ExtensionContext for activate() */
function createMockExtensionContext() {
  return {
    extensionUri: { fsPath: '/mock-extension' },
    subscriptions: [] as unknown[],
  };
}

/** Capture all calls to an output-channel appendLine / append mock */
function makeOutputChannel() {
  const lines: string[] = [];
  return {
    appendLine: vi.fn((s: string) => { lines.push(s); }),
    append: vi.fn((s: string) => { lines.push(s); }),
    _lines: lines,
  };
}

// ---------------------------------------------------------------------------
// describe: activate() — AC-1, AC-2
// ---------------------------------------------------------------------------

describe('activate() — AC-1 (no-op when chat API absent) / AC-2 (icon path)', () => {
  let ctx: ReturnType<typeof createMockExtensionContext>;

  beforeEach(() => {
    vi.clearAllMocks();
    _mockParticipant.iconPath = undefined;
    _mockParticipant.followupProvider = undefined;
    ctx = createMockExtensionContext();

    // Stub globals used transitively by extension.ts imports
    vi.stubGlobal('isSignedIn', vi.fn(() => true));
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'coding'));
    vi.stubGlobal('getBackendEnv', vi.fn(() => 'dev'));
    vi.stubGlobal('describeBackendError', vi.fn((e: unknown) => String(e)));
    vi.stubGlobal('outputChannel', makeOutputChannel());
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => makeStream()),
      streamSSE: vi.fn(() => makeStream('[DONE]')),
      post: vi.fn(),
    });
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding']));
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('AC-1: does NOT register chat participant when createChatParticipant is absent', () => {
    // Simulate older VS Code host by making createChatParticipant non-function
    const origFn = (vscode.chat as { createChatParticipant: unknown }).createChatParticipant;
    (vscode.chat as { createChatParticipant: unknown }).createChatParticipant = undefined;

    activate(ctx as unknown as vscode.ExtensionContext);

    // createChatParticipant was not present, so never invoked
    expect(origFn).not.toHaveBeenCalled();

    // Restore
    (vscode.chat as { createChatParticipant: unknown }).createChatParticipant = origFn;
  });

  it('AC-1: activation completes silently (no throw) when createChatParticipant is absent', () => {
    (vscode.chat as { createChatParticipant: unknown }).createChatParticipant = undefined;
    expect(() => activate(ctx as unknown as vscode.ExtensionContext)).not.toThrow();
    (vscode.chat as { createChatParticipant: unknown }).createChatParticipant = vi.fn(() => _mockParticipant);
  });

  it('AC-2: iconPath is set to media/aig-icon.png URI when participant is registered', () => {
    // Ensure createChatParticipant is a function (default mock state)
    (vscode.chat as { createChatParticipant: unknown }).createChatParticipant = vi.fn(() => _mockParticipant);

    activate(ctx as unknown as vscode.ExtensionContext);

    // The MockUri.joinPath static method returns an object with fsPath containing
    // the joined segments; verify the iconPath was set and points to the icon.
    // We cannot use vi.mocked() on a non-spy static class method, so we inspect
    // the participant directly.
    expect(_mockParticipant.iconPath).toBeDefined();
    // The path should contain the 'aig-icon.png' segment
    const iconPath = _mockParticipant.iconPath as { fsPath?: string } | string;
    const pathStr = typeof iconPath === 'string' ? iconPath : (iconPath as { fsPath?: string; toString?(): string }).toString?.() ?? '';
    // MockUri.joinPath joins segments with '/' → 'media/aig-icon.png'
    expect(pathStr).toContain('aig-icon.png');
  });

  it('AC-2: followupProvider is attached to the participant', () => {
    (vscode.chat as { createChatParticipant: unknown }).createChatParticipant = vi.fn(() => _mockParticipant);

    activate(ctx as unknown as vscode.ExtensionContext);

    expect(_mockParticipant.followupProvider).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// describe: handleChatRequest — AC-3, AC-9, AC-10, AC-21..25, AC-48
// ---------------------------------------------------------------------------

describe('handleChatRequest (FR-CHAT-1)', () => {
  let stream: ReturnType<typeof createMockChatStream>;
  let token: ReturnType<typeof createMockCancellationToken>;
  let outputCh: ReturnType<typeof makeOutputChannel>;

  beforeEach(() => {
    vi.clearAllMocks();
    stream = createMockChatStream();
    token = createMockCancellationToken();
    outputCh = makeOutputChannel();

    vi.stubGlobal('isSignedIn', vi.fn(() => true));
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'coding'));
    vi.stubGlobal('describeBackendError', vi.fn((e: unknown) => `ERR:${String(e)}`));
    vi.stubGlobal('outputChannel', outputCh);
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => makeStream('hello', ' world')),
    });

    // Default: withProgress executes the task callback
    vi.mocked(vscode.window.withProgress).mockImplementation(
      async (_opts: unknown, task: (...args: unknown[]) => Promise<unknown>) =>
        task({}, { isCancellationRequested: false, onCancellationRequested: vi.fn() }),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  // ── AC-3 ──────────────────────────────────────────────────────────────────

  it('AC-3: not signed in → stream.markdown with exact "You are not signed in..." text', async () => {
    vi.stubGlobal('isSignedIn', vi.fn(() => false));

    const req = createMockChatRequest({ prompt: 'explain this' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(stream.markdown).toHaveBeenCalledWith(
      'You are not signed in to the AIG platform.',
    );
  });

  it('AC-3: not signed in → stream.button with aig.signIn command and "AIG: Sign In" title', async () => {
    vi.stubGlobal('isSignedIn', vi.fn(() => false));

    const req = createMockChatRequest({ prompt: 'anything' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(stream.button).toHaveBeenCalledWith({
      command: 'aig.signIn',
      title: 'AIG: Sign In',
    });
  });

  it('AC-3: not signed in → no backend call (withProgress not called)', async () => {
    vi.stubGlobal('isSignedIn', vi.fn(() => false));

    const req = createMockChatRequest({ prompt: 'anything' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(vscode.window.withProgress).not.toHaveBeenCalled();
  });

  // ── AC-9 ──────────────────────────────────────────────────────────────────

  it('AC-9: empty prompt and no context → exact guidance message', async () => {
    // Ensure no active editor (default null in mock)
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = undefined;

    const req = createMockChatRequest({ prompt: '' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(stream.markdown).toHaveBeenCalledWith(
      'To use the AIG coding assistant, select some code and try /explain, /fix or /tests, or type your question directly.',
    );
  });

  it('AC-9: empty prompt and no context → withProgress NOT called (early return)', async () => {
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = undefined;

    const req = createMockChatRequest({ prompt: '' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(vscode.window.withProgress).not.toHaveBeenCalled();
  });

  // ── AC-10 ─────────────────────────────────────────────────────────────────

  it('AC-10: when active editor provides context, stream.reference is called', async () => {
    // Provide a mock active editor so context is resolved via AC-8 fallback
    const mockUri = { scheme: 'file', fsPath: '/test.ts', toString: () => 'file:///test.ts' };
    const mockDoc = {
      getText: vi.fn().mockReturnValue('function hello() {}'),
      languageId: 'typescript',
      uri: mockUri,
    };
    const mockEditor = {
      document: mockDoc,
      selection: { isEmpty: true },
    };
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = mockEditor;

    const req = createMockChatRequest({ command: 'explain', prompt: '' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(stream.reference).toHaveBeenCalledWith(mockUri);

    // Restore
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = undefined;
  });

  // ── AC-21 ─────────────────────────────────────────────────────────────────

  it('AC-21: withProgress called with title containing job profile', async () => {
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'my-profile'));
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => makeStream('[DONE]')),
    });

    const req = createMockChatRequest({ prompt: 'explain this function' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    const calls = vi.mocked(vscode.window.withProgress).mock.calls;
    expect(calls.length).toBeGreaterThan(0);
    const opts = calls[0][0] as { title: string };
    expect(opts.title).toContain('my-profile');
    expect(opts.title).toMatch(/Asking the AIG gateway/);
  });

  // ── AC-22 ─────────────────────────────────────────────────────────────────

  it('AC-22: each stream delta is forwarded to stream.markdown', async () => {
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => makeStream('delta-1', 'delta-2', 'delta-3')),
    });

    const req = createMockChatRequest({ prompt: 'explain this function' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(stream.markdown).toHaveBeenCalledWith('delta-1');
    expect(stream.markdown).toHaveBeenCalledWith('delta-2');
    expect(stream.markdown).toHaveBeenCalledWith('delta-3');
  });

  // ── AC-23 ─────────────────────────────────────────────────────────────────

  it('AC-23: cancellation token is passed to backendClient.streamChat', async () => {
    const capturedArgs: unknown[] = [];
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn((assembled: unknown, tok: unknown) => {
        capturedArgs.push(assembled, tok);
        return makeStream();
      }),
    });

    const req = createMockChatRequest({ prompt: 'explain this function' });
    const ctx = createMockChatContext();
    const cancellableToken = createMockCancellationToken();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      cancellableToken as unknown as vscode.CancellationToken,
    );

    // The outer token (from handleChatRequest params) is passed to streamChat
    // so the chat cancellation signal can abort the stream
    expect(capturedArgs[1]).toBe(cancellableToken);
  });

  // ── AC-24 ─────────────────────────────────────────────────────────────────

  it('AC-24: result.metadata contains command, traceId, tokens, model, route', async () => {
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => makeStream()),
    });

    const req = createMockChatRequest({ command: 'explain', prompt: 'anything' });
    const ctx = createMockChatContext();
    const result = await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(result.metadata).toBeDefined();
    expect(result.metadata).toHaveProperty('command');
    expect(result.metadata).toHaveProperty('traceId');
    expect(result.metadata).toHaveProperty('tokens');
    expect(result.metadata).toHaveProperty('model');
    expect(result.metadata).toHaveProperty('route');
  });

  it('AC-24: result.metadata.command matches the parsed slash command', async () => {
    vi.stubGlobal('backendClient', { streamChat: vi.fn(() => makeStream()) });

    const req = createMockChatRequest({ command: 'fix', prompt: '' });

    // Provide a mock editor so the request doesn't hit the AC-9 empty guard
    const mockDoc = {
      getText: vi.fn().mockReturnValue('const x = 1;'),
      languageId: 'typescript',
      uri: { scheme: 'file', fsPath: '/foo.ts', toString: () => 'file:///foo.ts' },
    };
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = {
      document: mockDoc,
      selection: { isEmpty: true },
    };

    const ctx = createMockChatContext();
    const result = await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect((result.metadata as Record<string, unknown>)?.['command']).toBe('fix');
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = undefined;
  });

  // ── AC-25 ─────────────────────────────────────────────────────────────────

  it('AC-25: portkey_key_not_configured error → exact error message in stream.markdown', async () => {
    const portKeyError = { code: 'portkey_key_not_configured', message: 'key missing' };
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => {
        throw portKeyError;
      }),
    });

    // withProgress still needs to run the task
    vi.mocked(vscode.window.withProgress).mockImplementation(
      async (_opts: unknown, task: (...args: unknown[]) => Promise<unknown>) =>
        task({}, { isCancellationRequested: false, onCancellationRequested: vi.fn() }),
    );

    const req = createMockChatRequest({ prompt: 'explain this' });
    const ctx = createMockChatContext();

    // Need non-empty prompt to bypass AC-9 guard; provide context hint
    const req2 = createMockChatRequest({ prompt: 'explain this function' });
    await handleChatRequest(
      req2 as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(stream.markdown).toHaveBeenCalledWith(
      'The Portkey gateway key is not configured on the AIG backend.',
    );
  });

  // ── AC-48 ─────────────────────────────────────────────────────────────────

  it('AC-48: non-portkey backend error → routed through describeBackendError → stream.markdown', async () => {
    const genericError = new Error('server error');
    vi.stubGlobal('backendClient', {
      streamChat: vi.fn(() => {
        throw genericError;
      }),
    });
    const mockDescribe = vi.fn(() => 'Backend Error: server error');
    vi.stubGlobal('describeBackendError', mockDescribe);

    const req = createMockChatRequest({ prompt: 'explain this function' });
    const ctx = createMockChatContext();
    await handleChatRequest(
      req as unknown as vscode.ChatRequest,
      ctx as unknown as vscode.ChatContext,
      stream as unknown as vscode.ChatResponseStream,
      token as unknown as vscode.CancellationToken,
    );

    expect(mockDescribe).toHaveBeenCalledWith(genericError);
    expect(stream.markdown).toHaveBeenCalledWith('Backend Error: server error');
  });
});

// ---------------------------------------------------------------------------
// describe: chatFollowupProvider — AC-26, AC-27
// ---------------------------------------------------------------------------

describe('chatFollowupProvider (AC-26, AC-27)', () => {
  const dummyContext = { history: [] } as unknown as vscode.ChatContext;
  const dummyToken = {
    isCancellationRequested: false,
    onCancellationRequested: vi.fn(),
  } as unknown as vscode.CancellationToken;

  it('AC-26: after /explain → follow-up "Write tests for it" with tests command', () => {
    const result: vscode.ChatResult = { metadata: { command: 'explain' } };
    const followups = chatFollowupProvider.provideFollowups(result, dummyContext, dummyToken);
    expect(followups).toHaveLength(1);
    // The implementation uses 'prompt' field per vscode.ChatFollowup API
    const fu = followups[0] as { prompt?: string; message?: string; command: string };
    const text = fu.prompt ?? fu.message ?? '';
    expect(text).toBe('Write tests for it');
    expect(fu.command).toBe('tests');
  });

  it('AC-27: after /fix → follow-up "Write tests for the fix" with tests command', () => {
    const result: vscode.ChatResult = { metadata: { command: 'fix' } };
    const followups = chatFollowupProvider.provideFollowups(result, dummyContext, dummyToken);
    expect(followups).toHaveLength(1);
    const fu = followups[0] as { prompt?: string; message?: string; command: string };
    const text = fu.prompt ?? fu.message ?? '';
    expect(text).toBe('Write tests for the fix');
    expect(fu.command).toBe('tests');
  });

  it('AC-26/AC-27: after /tests → no follow-up suggestions (ASSUME-REQ007-A8)', () => {
    const result: vscode.ChatResult = { metadata: { command: 'tests' } };
    const followups = chatFollowupProvider.provideFollowups(result, dummyContext, dummyToken);
    expect(followups).toHaveLength(0);
  });

  it('AC-26/AC-27: after freeform → no follow-up suggestions', () => {
    const result: vscode.ChatResult = { metadata: { command: null } };
    const followups = chatFollowupProvider.provideFollowups(result, dummyContext, dummyToken);
    expect(followups).toHaveLength(0);
  });
});

// ---------------------------------------------------------------------------
// describe: runSelectionCommand — AC-28
// ---------------------------------------------------------------------------

describe('runSelectionCommand (FR-CHAT-2 — AC-28)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubGlobal('isSignedIn', vi.fn(() => true));
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'coding'));
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding']));
    vi.stubGlobal('getBackendEnv', vi.fn(() => 'dev'));
    vi.stubGlobal('describeBackendError', vi.fn((e: unknown) => String(e)));
    vi.stubGlobal('outputChannel', makeOutputChannel());
    vi.stubGlobal('backendClient', { post: vi.fn() });
    // No active editor by default
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = undefined;
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = undefined;
  });

  it('AC-28: no active editor → showInformationMessage "AIG: open a file and select some code first."', async () => {
    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(undefined as unknown as string & vscode.MessageItem);
    await runSelectionCommand('explain');
    expect(vscode.window.showInformationMessage).toHaveBeenCalledWith(
      'AIG: open a file and select some code first.',
    );
  });

  it('AC-28: no active editor for "fix" → same guard message', async () => {
    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(undefined as unknown as string & vscode.MessageItem);
    await runSelectionCommand('fix');
    expect(vscode.window.showInformationMessage).toHaveBeenCalledWith(
      'AIG: open a file and select some code first.',
    );
  });

  it('AC-28: empty file content → showInformationMessage guard message', async () => {
    const mockDoc = {
      getText: vi.fn().mockReturnValue('   \n  '),
      languageId: 'typescript',
      uri: { scheme: 'file', fsPath: '/empty.ts' },
    };
    (vscode.window as { activeTextEditor: unknown }).activeTextEditor = {
      document: mockDoc,
      selection: { isEmpty: true },
    };

    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(undefined as unknown as string & vscode.MessageItem);
    await runSelectionCommand('explain');

    expect(vscode.window.showInformationMessage).toHaveBeenCalledWith(
      'AIG: open a file and select some code first.',
    );
  });
});

// ---------------------------------------------------------------------------
// describe: runAskCommand — AC-30, AC-32..35, AC-45, AC-47
// ---------------------------------------------------------------------------

describe('runAskCommand (FR-CHAT-3 — AC-30, AC-32..35, AC-45, AC-47)', () => {
  let outputCh: ReturnType<typeof makeOutputChannel>;

  beforeEach(() => {
    vi.clearAllMocks();
    outputCh = makeOutputChannel();
    vi.stubGlobal('isSignedIn', vi.fn(() => true));
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'coding'));
    vi.stubGlobal('getBackendEnv', vi.fn(() => 'dev'));
    vi.stubGlobal('describeBackendError', vi.fn((e: unknown) => `ERR:${String(e)}`));
    vi.stubGlobal('outputChannel', outputCh);
    vi.stubGlobal('backendClient', {
      streamSSE: vi.fn(() => makeStream('[DONE]')),
    });

    // Default: withProgress executes the task with a live token
    vi.mocked(vscode.window.withProgress).mockImplementation(
      async (_opts: unknown, task: (...args: unknown[]) => Promise<unknown>) =>
        task({}, { isCancellationRequested: false, onCancellationRequested: vi.fn() }),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  // ── AC-47 ─────────────────────────────────────────────────────────────────

  it('AC-47: not signed in → showInformationMessage "You are not signed in..." with AIG: Sign In', async () => {
    vi.stubGlobal('isSignedIn', vi.fn(() => false));
    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(undefined as unknown as string & vscode.MessageItem);

    await runAskCommand('hello');

    expect(vscode.window.showInformationMessage).toHaveBeenCalledWith(
      'You are not signed in to the AIG platform.',
      'AIG: Sign In',
    );
  });

  it('AC-47: not signed in → no backend request made', async () => {
    vi.stubGlobal('isSignedIn', vi.fn(() => false));
    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(undefined as unknown as string & vscode.MessageItem);
    const mockStreamSSE = vi.fn();
    vi.stubGlobal('backendClient', { streamSSE: mockStreamSSE });

    await runAskCommand('test prompt');

    expect(mockStreamSSE).not.toHaveBeenCalled();
  });

  // ── AC-30 ─────────────────────────────────────────────────────────────────

  it('AC-30: when no arg supplied, showInputBox is called to collect prompt', async () => {
    vi.mocked(vscode.window.showInputBox).mockResolvedValue('my question');

    await runAskCommand(undefined);

    expect(vscode.window.showInputBox).toHaveBeenCalled();
  });

  it('AC-30: when arg is supplied, showInputBox is NOT called', async () => {
    await runAskCommand('pre-supplied prompt');
    expect(vscode.window.showInputBox).not.toHaveBeenCalled();
  });

  // ── AC-45 ─────────────────────────────────────────────────────────────────

  it('AC-45: InputBox returns undefined (Escape) → silent cancel, no showErrorMessage', async () => {
    vi.mocked(vscode.window.showInputBox).mockResolvedValue(undefined);

    await runAskCommand(undefined);

    expect(vscode.window.showErrorMessage).not.toHaveBeenCalled();
    expect(vscode.window.withProgress).not.toHaveBeenCalled();
  });

  // ── AC-32 ─────────────────────────────────────────────────────────────────

  it('AC-32: first output channel line is "> <prompt>"', async () => {
    await runAskCommand('what is 2+2');

    expect(outputCh._lines[0]).toBe('> what is 2+2');
  });

  it('AC-32: second output channel line starts with "[ask] env=" and includes profile and trace', async () => {
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'my-profile'));
    vi.stubGlobal('getBackendEnv', vi.fn(() => 'prod'));

    await runAskCommand('test prompt');

    expect(outputCh._lines[1]).toMatch(/^\[ask\] env=prod profile=my-profile trace=/);
  });

  it('AC-32: completion line contains "[ask] done trace="', async () => {
    await runAskCommand('done test');

    const doneLine = outputCh._lines.find((l) => l.includes('[ask] done trace='));
    expect(doneLine).toBeDefined();
  });

  // ── AC-33 ─────────────────────────────────────────────────────────────────

  it('AC-33: stream that closes without [DONE] → showWarningMessage "response may be incomplete"', async () => {
    // Yield deltas but no [DONE]
    vi.stubGlobal('backendClient', {
      streamSSE: vi.fn(() => makeStream('partial', 'response')),
    });

    await runAskCommand('test without done');

    expect(vscode.window.showWarningMessage).toHaveBeenCalledWith(
      'response may be incomplete',
    );
  });

  it('AC-33: stream that includes [DONE] → no "response may be incomplete" warning', async () => {
    vi.stubGlobal('backendClient', {
      streamSSE: vi.fn(() => makeStream('delta', '[DONE]')),
    });

    await runAskCommand('complete test');

    expect(vscode.window.showWarningMessage).not.toHaveBeenCalledWith(
      'response may be incomplete',
    );
  });

  // ── AC-34 ─────────────────────────────────────────────────────────────────

  it('AC-34: withProgress is called with cancellable: true', async () => {
    await runAskCommand('cancellable test');

    const calls = vi.mocked(vscode.window.withProgress).mock.calls;
    expect(calls.length).toBeGreaterThan(0);
    const opts = calls[0][0] as { cancellable: boolean };
    expect(opts.cancellable).toBe(true);
  });

  // ── AC-35 ─────────────────────────────────────────────────────────────────

  it('AC-35: backend error → showErrorMessage called with describeBackendError result', async () => {
    const err = new Error('timeout');
    vi.stubGlobal('backendClient', {
      streamSSE: vi.fn(() => {
        throw err;
      }),
    });
    const mockDescribe = vi.fn(() => 'Request timed out');
    vi.stubGlobal('describeBackendError', mockDescribe);

    // withProgress re-throw mode: let the catch block run
    vi.mocked(vscode.window.withProgress).mockImplementation(
      async (_opts: unknown, task: (...args: unknown[]) => Promise<unknown>) => {
        try {
          return await task({}, { isCancellationRequested: false, onCancellationRequested: vi.fn() });
        } catch (e) {
          throw e;
        }
      },
    );

    await runAskCommand('error test');

    expect(mockDescribe).toHaveBeenCalledWith(err);
    expect(vscode.window.showErrorMessage).toHaveBeenCalledWith('Request timed out');
  });
});

// ---------------------------------------------------------------------------
// describe: runRoutingCommand — AC-36, AC-38, AC-41, AC-46, AC-49
// ---------------------------------------------------------------------------

describe('runRoutingCommand (FR-CHAT-4 — AC-36, AC-38, AC-41, AC-46, AC-49)', () => {
  const baseRoutingResult = {
    result: 'ok',
    model: 'gpt-4o',
    provider: 'openai',
    tier: 'premium',
    costMode: 'standard',
    jobProfile: 'coding',
    usageState: 'normal',
    latencyMs: 142,
    tokens: 512,
    cache: null,
    answer: 'hello',
    error: null,
    traceId: 'trace-abc-123',
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubGlobal('isSignedIn', vi.fn(() => true));
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'coding'));
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding', 'premium']));
    vi.stubGlobal('describeBackendError', vi.fn((e: unknown) => `ERR:${String(e)}`));
    vi.stubGlobal('outputChannel', makeOutputChannel());
    vi.stubGlobal('backendClient', {
      post: vi.fn().mockResolvedValue(baseRoutingResult),
    });

    // Default: showInformationMessage resolves without action
    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(
      undefined as unknown as string & vscode.MessageItem,
    );
    // Default: picker returns first item
    vi.mocked(vscode.window.showQuickPick).mockResolvedValue(
      'coding' as unknown as string & vscode.QuickPickItem,
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  // ── AC-36 ─────────────────────────────────────────────────────────────────

  it('AC-36: not signed in → showInformationMessage with sign-in prompt, no backend call', async () => {
    vi.stubGlobal('isSignedIn', vi.fn(() => false));
    const mockPost = vi.fn();
    vi.stubGlobal('backendClient', { post: mockPost });

    await runRoutingCommand();

    expect(vscode.window.showInformationMessage).toHaveBeenCalledWith(
      'You are not signed in to the AIG platform.',
      'AIG: Sign In',
    );
    expect(mockPost).not.toHaveBeenCalled();
  });

  // ── AC-46 ─────────────────────────────────────────────────────────────────

  it('AC-46: profile picker dismissed (undefined) → silent abort, no backend call', async () => {
    // More than one profile so picker is shown
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding', 'premium']));
    vi.mocked(vscode.window.showQuickPick).mockResolvedValue(
      undefined as unknown as string & vscode.QuickPickItem,
    );
    const mockPost = vi.fn();
    vi.stubGlobal('backendClient', { post: mockPost });

    await runRoutingCommand();

    expect(mockPost).not.toHaveBeenCalled();
    expect(vscode.window.showErrorMessage).not.toHaveBeenCalled();
  });

  // ── AC-38 ─────────────────────────────────────────────────────────────────

  it('AC-38: backendClient.post called with "/api/v1/routing/test" and { job_profile }', async () => {
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding'])); // single → skip picker
    const mockPost = vi.fn().mockResolvedValue(baseRoutingResult);
    vi.stubGlobal('backendClient', { post: mockPost });

    await runRoutingCommand();

    expect(mockPost).toHaveBeenCalledWith('/api/v1/routing/test', { job_profile: 'coding' });
  });

  it('AC-38: job_profile in POST body matches the selected profile from picker', async () => {
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding', 'premium']));
    vi.mocked(vscode.window.showQuickPick).mockResolvedValue(
      'premium' as unknown as string & vscode.QuickPickItem,
    );
    const mockPost = vi.fn().mockResolvedValue(baseRoutingResult);
    vi.stubGlobal('backendClient', { post: mockPost });

    await runRoutingCommand();

    expect(mockPost).toHaveBeenCalledWith('/api/v1/routing/test', { job_profile: 'premium' });
  });

  // ── AC-41 ─────────────────────────────────────────────────────────────────

  it('AC-41: "Copy trace id" button → clipboard.writeText called with traceId', async () => {
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding']));
    vi.stubGlobal('backendClient', {
      post: vi.fn().mockResolvedValue({ ...baseRoutingResult, traceId: 'my-trace-id' }),
    });
    // Simulate user clicking "Copy trace id"
    vi.mocked(vscode.window.showInformationMessage).mockResolvedValue(
      'Copy trace id' as unknown as string & vscode.MessageItem,
    );

    await runRoutingCommand();

    expect(vscode.env.clipboard.writeText).toHaveBeenCalledWith('my-trace-id');
  });

  // ── AC-49 ─────────────────────────────────────────────────────────────────

  it('AC-49: backend error → showErrorMessage called with describeBackendError result', async () => {
    vi.stubGlobal('getAllowedProfiles', vi.fn(() => ['coding']));
    const err = new Error('network failure');
    vi.stubGlobal('backendClient', {
      post: vi.fn().mockRejectedValue(err),
    });
    const mockDescribe = vi.fn(() => 'Network Failure Error');
    vi.stubGlobal('describeBackendError', mockDescribe);

    await runRoutingCommand();

    expect(mockDescribe).toHaveBeenCalledWith(err);
    expect(vscode.window.showErrorMessage).toHaveBeenCalledWith('Network Failure Error');
  });
});

// ---------------------------------------------------------------------------
// Security: NFR pii:authentication-token
// ---------------------------------------------------------------------------

describe('Security (NFR pii:authentication-token)', () => {
  let outputCh: ReturnType<typeof makeOutputChannel>;

  beforeEach(() => {
    vi.clearAllMocks();
    outputCh = makeOutputChannel();
    vi.stubGlobal('isSignedIn', vi.fn(() => true));
    vi.stubGlobal('getConfiguredProfile', vi.fn(() => 'coding'));
    vi.stubGlobal('getBackendEnv', vi.fn(() => 'dev'));
    vi.stubGlobal('describeBackendError', vi.fn((e: unknown) => String(e)));
    vi.stubGlobal('outputChannel', outputCh);
    vi.stubGlobal('backendClient', {
      streamSSE: vi.fn(() => makeStream('[DONE]')),
    });
    vi.mocked(vscode.window.withProgress).mockImplementation(
      async (_opts: unknown, task: (...args: unknown[]) => Promise<unknown>) =>
        task({}, { isCancellationRequested: false, onCancellationRequested: vi.fn() }),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('output channel log lines do not contain a Bearer token pattern (NFR pii:authentication-token)', async () => {
    // Simulate an ask command that would log to outputChannel
    await runAskCommand('what does this function do');

    // Assert no log line contains a Bearer token
    const allLog = outputCh._lines.join('\n');
    expect(allLog).not.toMatch(/Bearer\s+\S+/);
    // Also assert no Portkey key pattern (sk-... style)
    expect(allLog).not.toMatch(/sk-[a-z0-9]{20,}/i);
  });

  it('output channel only contains the AC-32 enumerated fields, not credential patterns', async () => {
    await runAskCommand('check my code');

    for (const line of outputCh._lines) {
      // No "Authorization:" header leakage
      expect(line).not.toMatch(/Authorization\s*:/i);
    }
  });
});
