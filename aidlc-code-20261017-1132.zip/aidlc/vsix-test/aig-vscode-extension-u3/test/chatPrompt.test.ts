/**
 * NFR-designated unit test suite for chatPrompt.ts pure functions.
 *
 * Runs under Vitest 2, environment: node — no VS Code extension host needed.
 * Pattern: storefront:web/tests/OrdersTable.test.tsx (describe/it, inline fixtures,
 * expect().toBe / .toContain / .not.toMatch)
 *
 * AC coverage: AC-4, AC-5, AC-6, AC-7, AC-8, AC-11, AC-12, AC-13, AC-14,
 *              AC-15, AC-16, AC-17, AC-18, AC-19, AC-20, AC-29
 */

import { describe, it, expect } from 'vitest';
import packageJson from '../package.json' assert { type: 'json' };
import {
  SYSTEM_PROMPT,
  CONTEXT_HINTS,
  CODE_CONTEXT_LIMIT,
  REQUEST_LIMIT,
  SELECTION_COMMAND_LIMIT,
  DEFAULT_ASKS,
  parseCommand,
  resolveContextFromReferences,
  matchesContextHints,
  truncateCode,
  buildHistory,
  buildTaskPrompt,
  safeFence,
  remapLanguageId,
  buildSelectionPrefill,
  assembleRequest,
} from '../src/chatPrompt.js';

// ============================================================================
// @types/vscode version lock (NFR)
// ============================================================================

describe('@types/vscode version lock (NFR)', () => {
  it('@types/vscode is ~1.90.0', () => {
    const deps = (packageJson as { devDependencies: Record<string, string> }).devDependencies;
    expect(deps['@types/vscode']).toBe('~1.90.0');
  });
});

// ============================================================================
// SYSTEM_PROMPT — AC-16 (security-critical)
// ============================================================================

describe('SYSTEM_PROMPT (AC-16)', () => {
  it('matches the exact AC-16 verbatim string', () => {
    expect(SYSTEM_PROMPT).toBe(
      'You are the AIG coding assistant inside VS Code, served through the AIG model gateway.' +
      ' Be concise and precise.' +
      ' Use Markdown; put code in fenced blocks with a language.' +
      ' Never ask for or reveal API keys or credentials.' +
      ' If code context is provided, base the answer on it and say when something cannot be determined from it.',
    );
  });

  it('does not contain any Portkey key pattern (NFR security)', () => {
    expect(SYSTEM_PROMPT).not.toMatch(/portkey|api\.key|sk-[a-z0-9]/i);
  });

  it('contains the credential non-disclosure clause (NFR prompt-injection resistance)', () => {
    expect(SYSTEM_PROMPT).toContain('Never ask for or reveal API keys or credentials');
  });
});

// ============================================================================
// parseCommand — AC-4, AC-5, AC-6
// ============================================================================

describe('parseCommand (AC-4, AC-5, AC-6)', () => {
  // AC-4: request.command field takes priority
  it('AC-4: uses request.command when it is a recognised command (fix)', () => {
    const result = parseCommand({ command: 'fix', prompt: 'handle nulls' });
    expect(result.command).toBe('fix');
    expect(result.promptText).toBe('handle nulls');
  });

  it('AC-4: uses request.command when it is a recognised command (explain)', () => {
    const result = parseCommand({ command: 'explain', prompt: 'what does this do?' });
    expect(result.command).toBe('explain');
    expect(result.promptText).toBe('what does this do?');
  });

  it('AC-4: uses request.command when it is a recognised command (tests)', () => {
    const result = parseCommand({ command: 'tests', prompt: '' });
    expect(result.command).toBe('tests');
    expect(result.promptText).toBe('');
  });

  it('AC-4: request.command is case-insensitive for recognised commands', () => {
    const result = parseCommand({ command: 'FIX', prompt: 'some text' });
    expect(result.command).toBe('fix');
  });

  // AC-5: parse /token prefix from prompt when request.command is absent
  it('AC-5: parses /fix prefix from prompt when no request.command', () => {
    const result = parseCommand({ prompt: '/fix handle nulls' });
    expect(result.command).toBe('fix');
    expect(result.promptText).toBe('handle nulls');
  });

  it('AC-5: parses /explain prefix from prompt', () => {
    const result = parseCommand({ prompt: '/explain this function' });
    expect(result.command).toBe('explain');
    expect(result.promptText).toBe('this function');
  });

  it('AC-5: parses /tests prefix from prompt', () => {
    const result = parseCommand({ prompt: '/tests add coverage' });
    expect(result.command).toBe('tests');
    expect(result.promptText).toBe('add coverage');
  });

  it('AC-5: strips /command prefix and trims leading whitespace from promptText', () => {
    const result = parseCommand({ prompt: '/fix   lots of leading spaces' });
    expect(result.command).toBe('fix');
    expect(result.promptText).toBe('lots of leading spaces');
  });

  it('AC-5: prompt is exactly the command with no trailing text — promptText is empty string', () => {
    const result = parseCommand({ prompt: '/explain' });
    expect(result.command).toBe('explain');
    expect(result.promptText).toBe('');
  });

  // AC-6: unknown /token stays as literal text
  it('AC-6: unknown /token prefix leaves prompt unchanged and returns null command', () => {
    const result = parseCommand({ prompt: '/unknown foo' });
    expect(result.command).toBeNull();
    expect(result.promptText).toBe('/unknown foo');
  });

  it('AC-6: unrecognised request.command returns null command, prompt unchanged', () => {
    const result = parseCommand({ command: 'summarize', prompt: 'hello' });
    expect(result.command).toBeNull();
    expect(result.promptText).toBe('hello');
  });

  it('AC-6: prompt with no slash and no command returns null command', () => {
    const result = parseCommand({ prompt: 'what does this code do?' });
    expect(result.command).toBeNull();
    expect(result.promptText).toBe('what does this code do?');
  });

  it('AC-6: empty prompt with no command returns null command', () => {
    const result = parseCommand({ prompt: '' });
    expect(result.command).toBeNull();
    expect(result.promptText).toBe('');
  });
});

// ============================================================================
// resolveContextFromReferences — AC-7
// ============================================================================

describe('resolveContextFromReferences (AC-7)', () => {
  it('AC-7: returns null for empty references array', () => {
    expect(resolveContextFromReferences([])).toBeNull();
  });

  it('AC-7: returns first non-untitled reference', () => {
    const refs = [
      { uri: { scheme: 'file', path: '/src/foo.ts' } },
    ];
    const result = resolveContextFromReferences(refs);
    expect(result).not.toBeNull();
    expect((result!.resource as { scheme: string; path: string }).path).toBe('/src/foo.ts');
  });

  it('AC-7: skips untitled scheme URIs', () => {
    const refs = [
      { uri: { scheme: 'untitled', path: 'Untitled-1' } },
      { uri: { scheme: 'file', path: '/src/bar.ts' } },
    ];
    const result = resolveContextFromReferences(refs);
    expect(result).not.toBeNull();
    expect((result!.resource as { scheme: string; path: string }).path).toBe('/src/bar.ts');
  });

  it('AC-7: only untitled references returns null', () => {
    const refs = [
      { uri: { scheme: 'untitled', path: 'Untitled-1' } },
      { uri: { scheme: 'untitled', path: 'Untitled-2' } },
    ];
    expect(resolveContextFromReferences(refs)).toBeNull();
  });

  it('AC-7: first readable non-untitled reference wins; subsequent are ignored', () => {
    const refs = [
      { uri: { scheme: 'file', path: '/first.ts' } },
      { uri: { scheme: 'file', path: '/second.ts' } },
    ];
    const result = resolveContextFromReferences(refs);
    expect((result!.resource as { path: string }).path).toBe('/first.ts');
  });

  it('AC-7: skips untitled first, returns second non-untitled', () => {
    const refs = [
      { uri: { scheme: 'untitled', path: 'U' } },
      { uri: { scheme: 'file', path: '/real.ts' } },
      { uri: { scheme: 'file', path: '/other.ts' } },
    ];
    const result = resolveContextFromReferences(refs);
    expect((result!.resource as { path: string }).path).toBe('/real.ts');
  });

  it('AC-7: location reference without untitled scheme is returned', () => {
    const refs = [
      { location: { uri: { scheme: 'file', path: '/loc.ts' }, range: {} } },
    ];
    const result = resolveContextFromReferences(refs);
    expect(result).not.toBeNull();
  });

  it('AC-7: location with untitled URI is skipped', () => {
    const refs = [
      { location: { uri: { scheme: 'untitled', path: 'U' }, range: {} } },
      { uri: { scheme: 'file', path: '/real.ts' } },
    ];
    const result = resolveContextFromReferences(refs);
    expect((result!.resource as { path: string }).path).toBe('/real.ts');
  });
});

// ============================================================================
// matchesContextHints — AC-8
// ============================================================================

describe('matchesContextHints (AC-8)', () => {
  it('AC-8: matches "this function" (case-insensitive)', () => {
    expect(matchesContextHints('explain this function please')).toBe(true);
  });

  it('AC-8: matches "EXPLAIN IT" (upper-case)', () => {
    expect(matchesContextHints('EXPLAIN IT')).toBe(true);
  });

  it('AC-8: matches "the selected code"', () => {
    expect(matchesContextHints('can you look at the selected code?')).toBe(true);
  });

  it('AC-8: matches "#selection"', () => {
    expect(matchesContextHints('fix the #selection')).toBe(true);
  });

  it('AC-8: matches "explain it" (exact lower)', () => {
    expect(matchesContextHints('please explain it for me')).toBe(true);
  });

  it('AC-8: returns false when no hint phrase is present', () => {
    expect(matchesContextHints('what does this code do')).toBe(false);
  });

  it('AC-8: returns false for empty prompt', () => {
    expect(matchesContextHints('')).toBe(false);
  });

  it('AC-8: matches "This Function" (mixed case)', () => {
    expect(matchesContextHints('Tell me about This Function')).toBe(true);
  });

  it('AC-8: CONTEXT_HINTS contains exactly the 4 required phrases', () => {
    expect(CONTEXT_HINTS).toContain('this function');
    expect(CONTEXT_HINTS).toContain('the selected code');
    expect(CONTEXT_HINTS).toContain('#selection');
    expect(CONTEXT_HINTS).toContain('explain it');
    expect(CONTEXT_HINTS).toHaveLength(4);
  });
});

// ============================================================================
// truncateCode — AC-12
// ============================================================================

describe('truncateCode (AC-12)', () => {
  it('AC-12: returns text unchanged when exactly at CODE_CONTEXT_LIMIT (24,000)', () => {
    const text = 'a'.repeat(CODE_CONTEXT_LIMIT);
    const result = truncateCode(text, CODE_CONTEXT_LIMIT);
    expect(result).toBe(text);
    expect(result).not.toContain('[truncated');
  });

  it('AC-12: truncates and appends marker when 1 char over CODE_CONTEXT_LIMIT', () => {
    const text = 'a'.repeat(CODE_CONTEXT_LIMIT + 1);
    const result = truncateCode(text, CODE_CONTEXT_LIMIT);
    expect(result).toContain('… [truncated 1 characters]');
    // The leading portion is exactly CODE_CONTEXT_LIMIT chars before the marker
    expect(result.startsWith('a'.repeat(CODE_CONTEXT_LIMIT))).toBe(true);
  });

  it('AC-12: truncation marker includes correct N characters count', () => {
    const overBy = 500;
    const text = 'x'.repeat(CODE_CONTEXT_LIMIT + overBy);
    const result = truncateCode(text, CODE_CONTEXT_LIMIT);
    expect(result).toContain(`… [truncated ${overBy} characters]`);
  });

  it('AC-12: text below limit is returned unchanged', () => {
    const text = 'short text';
    expect(truncateCode(text, CODE_CONTEXT_LIMIT)).toBe(text);
  });

  it('AC-29: truncates at SELECTION_COMMAND_LIMIT (30,000) with marker', () => {
    const text = 'b'.repeat(SELECTION_COMMAND_LIMIT + 1);
    const result = truncateCode(text, SELECTION_COMMAND_LIMIT);
    expect(result).toContain('… [truncated 1 characters]');
    expect(result.startsWith('b'.repeat(SELECTION_COMMAND_LIMIT))).toBe(true);
  });

  it('AC-29: SELECTION_COMMAND_LIMIT is 30,000', () => {
    expect(SELECTION_COMMAND_LIMIT).toBe(30_000);
  });

  it('AC-12: CODE_CONTEXT_LIMIT is 24,000', () => {
    expect(CODE_CONTEXT_LIMIT).toBe(24_000);
  });
});

// ============================================================================
// buildHistory — AC-11
// ============================================================================

describe('buildHistory (AC-11)', () => {
  // Helper to create a mock ChatRequestTurn (user turn for @aig)
  function userTurn(participant: string, prompt: string) {
    return { participant, prompt };
  }

  // Helper to create a mock ChatResponseTurn (assistant turn for @aig)
  function assistantTurn(participant: string, text: string) {
    return { participant, response: [{ value: text }] };
  }

  it('AC-11: filters to @aig participant turns only — excludes other participants', () => {
    const history = [
      userTurn('aig', 'first aig user message'),
      userTurn('github.copilot', 'copilot user message'),
      assistantTurn('aig', 'first aig response'),
    ];
    const result = buildHistory(history, 10);
    expect(result).toHaveLength(2);
    expect(result[0].content).toBe('first aig user message');
    expect(result[1].content).toBe('first aig response');
  });

  it('AC-11: returns at most 10 turns (limit enforcement)', () => {
    const history: unknown[] = [];
    // 12 user turns
    for (let i = 0; i < 12; i++) {
      history.push(userTurn('aig', `message ${i}`));
    }
    const result = buildHistory(history, 10);
    expect(result.length).toBeLessThanOrEqual(10);
  });

  it('AC-11: sequence starts with a user turn — drops leading assistant turns', () => {
    const history = [
      assistantTurn('aig', 'assistant opens conversation'),
      userTurn('aig', 'actual user question'),
      assistantTurn('aig', 'response'),
    ];
    const result = buildHistory(history, 10);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0].role).toBe('user');
  });

  it('AC-11: returns empty array when only non-aig participants in history', () => {
    const history = [
      userTurn('copilot', 'some copilot question'),
      assistantTurn('copilot', 'copilot response'),
    ];
    expect(buildHistory(history, 10)).toEqual([]);
  });

  it('AC-11: returns empty array for empty history', () => {
    expect(buildHistory([], 10)).toEqual([]);
  });

  it('AC-11: correctly extracts roles — user turns have role "user"', () => {
    const history = [userTurn('aig', 'hello')];
    const result = buildHistory(history, 10);
    expect(result[0].role).toBe('user');
  });

  it('AC-11: correctly extracts roles — assistant turns have role "assistant"', () => {
    const history = [
      userTurn('aig', 'hello'),
      assistantTurn('aig', 'world'),
    ];
    const result = buildHistory(history, 10);
    expect(result[1].role).toBe('assistant');
  });

  it('AC-11: budget trimming — drops oldest turns when total exceeds REQUEST_LIMIT', () => {
    // Each turn is slightly larger than REQUEST_LIMIT / 10 so two turns together exceed REQUEST_LIMIT
    const bigContent = 'x'.repeat(Math.floor(REQUEST_LIMIT / 2) + 1);
    const history = [
      userTurn('aig', bigContent),
      userTurn('aig', bigContent),
      userTurn('aig', bigContent),
    ];
    const result = buildHistory(history, 10);
    // Total of all 3 > REQUEST_LIMIT; oldest should be dropped
    const total = result.reduce((acc, t) => acc + t.content.length, 0);
    expect(total).toBeLessThanOrEqual(REQUEST_LIMIT);
  });

  it('AC-11: last 10 turns are kept, not the first 10', () => {
    const history: unknown[] = [];
    for (let i = 0; i < 12; i++) {
      history.push(userTurn('aig', `message-${i}`));
    }
    const result = buildHistory(history, 10);
    // The most recent turns should end with message-11
    expect(result[result.length - 1].content).toBe('message-11');
  });

  it('AC-11: REQUEST_LIMIT is 40,000', () => {
    expect(REQUEST_LIMIT).toBe(40_000);
  });

  it('AC-11: handles assistant turn with MarkdownString value (nested .value)', () => {
    const history = [
      userTurn('aig', 'question'),
      { participant: 'aig', response: [{ value: { value: 'markdown response' } }] },
    ];
    const result = buildHistory(history, 10);
    expect(result[1].content).toBe('markdown response');
  });
});

// ============================================================================
// assembleRequest — AC-13
// ============================================================================

describe('assembleRequest (AC-13)', () => {
  it('AC-13: returns assembled content unchanged when <= 40,000 chars', () => {
    const parts = {
      systemPrompt: 'System prompt.',
      history: [{ role: 'user' as const, content: 'Hello' }],
      codeContext: 'const x = 1;',
      taskPrompt: 'Explain this.',
    };
    const result = assembleRequest(parts);
    expect(result).not.toContain('[truncated');
    expect(result).toContain('System prompt.');
    expect(result).toContain('Explain this.');
  });

  it('AC-13: truncates with marker when assembled content exceeds REQUEST_LIMIT', () => {
    const bigPrompt = 'a'.repeat(REQUEST_LIMIT);
    const parts = {
      systemPrompt: bigPrompt,
      history: [],
      codeContext: 'const x = 1;',
      taskPrompt: 'Explain.',
    };
    const result = assembleRequest(parts);
    expect(result).toContain('… [truncated');
    // Content before marker must be <= REQUEST_LIMIT chars
    const markerIdx = result.indexOf('…');
    expect(markerIdx).toBeLessThanOrEqual(REQUEST_LIMIT);
  });

  it('AC-13: truncation marker contains correct N removed characters count', () => {
    // Assemble something exactly REQUEST_LIMIT + 100 chars
    const padding = '\n\n';
    const systemPrompt = 'SP';
    const codeContext = 'CC';
    const taskPrompt = 'TP';
    const baseLen = systemPrompt.length + padding.length + codeContext.length + padding.length + taskPrompt.length;
    const extra = REQUEST_LIMIT + 100 - baseLen;
    const bigCode = 'x'.repeat(extra > 0 ? extra : 0) + codeContext;

    const parts = {
      systemPrompt,
      history: [],
      codeContext: bigCode,
      taskPrompt,
    };
    const result = assembleRequest(parts);
    if (result.includes('… [truncated')) {
      // Verify marker is present and content was truncated
      expect(result).toMatch(/… \[truncated \d+ characters\]/);
    }
  });

  it('AC-13: assembled content <= 40,000 — no truncation marker', () => {
    const parts = {
      systemPrompt: 'short',
      history: [],
      codeContext: 'also short',
      taskPrompt: 'brief ask',
    };
    expect(assembleRequest(parts)).not.toContain('[truncated');
  });

  it('AC-13: empty parts produce minimal output without truncation', () => {
    const parts = {
      systemPrompt: '',
      history: [],
      codeContext: '',
      taskPrompt: '',
    };
    const result = assembleRequest(parts);
    expect(result).toBe('');
  });
});

// ============================================================================
// safeFence — AC-14
// ============================================================================

describe('safeFence (AC-14)', () => {
  it('AC-14: content with no backticks uses triple backticks (3)', () => {
    const result = safeFence('no backticks here', 'ts');
    expect(result.startsWith('```')).toBe(true);
    expect(result.endsWith('```')).toBe(true);
  });

  it('AC-14: content with a 3-backtick run uses 4 backticks for the fence', () => {
    const content = 'before ```code``` after';
    const result = safeFence(content, 'ts');
    expect(result.startsWith('````')).toBe(true);
    expect(result.endsWith('````')).toBe(true);
  });

  it('AC-14: content with a 5-backtick run uses 6 backticks for the fence', () => {
    const content = 'before `````code````` after';
    const result = safeFence(content, 'ts');
    expect(result.startsWith('``````')).toBe(true);
    expect(result.endsWith('``````')).toBe(true);
  });

  it('AC-14: fence count is always > longest run in content', () => {
    const content = '````` five backticks `````';
    const result = safeFence(content, 'py');
    const firstNewline = result.indexOf('\n');
    const openFence = result.slice(0, firstNewline).replace(/[^`]/g, '');
    expect(openFence.length).toBeGreaterThan(5);
  });

  it('AC-14: fence includes language after opening backticks', () => {
    const result = safeFence('code', 'python');
    expect(result.startsWith('```python\n')).toBe(true);
  });

  it('AC-14: content is between opening and closing fences', () => {
    const content = 'const x = 42;';
    const result = safeFence(content, 'ts');
    expect(result).toContain('\n' + content + '\n');
  });
});

// ============================================================================
// remapLanguageId — AC-15
// ============================================================================

describe('remapLanguageId (AC-15)', () => {
  it('AC-15: typescriptreact → tsx', () => {
    expect(remapLanguageId('typescriptreact')).toBe('tsx');
  });

  it('AC-15: javascriptreact → jsx', () => {
    expect(remapLanguageId('javascriptreact')).toBe('jsx');
  });

  it('AC-15: shellscript → bash', () => {
    expect(remapLanguageId('shellscript')).toBe('bash');
  });

  it('AC-15: python → python (unchanged)', () => {
    expect(remapLanguageId('python')).toBe('python');
  });

  it('AC-15: typescript → typescript (unchanged)', () => {
    expect(remapLanguageId('typescript')).toBe('typescript');
  });

  it('AC-15: javascript → javascript (unchanged)', () => {
    expect(remapLanguageId('javascript')).toBe('javascript');
  });

  it('AC-15: unknown language id passes through unchanged', () => {
    expect(remapLanguageId('rust')).toBe('rust');
  });

  it('AC-15: safeFence applies remapping for typescriptreact → tsx in fence header', () => {
    const result = safeFence('const x = 1;', 'typescriptreact');
    expect(result).toContain('```tsx');
  });
});

// ============================================================================
// buildTaskPrompt — AC-17, AC-18, AC-19, AC-20
// ============================================================================

describe('buildTaskPrompt (AC-17, AC-18, AC-19, AC-20)', () => {
  // AC-17: explain command
  it('AC-17: explain prompt contains "summary"', () => {
    const result = buildTaskPrompt('explain', 'explain this please');
    expect(result.toLowerCase()).toContain('summary');
  });

  it('AC-17: explain prompt mentions edge cases', () => {
    const result = buildTaskPrompt('explain', 'explain please');
    expect(result.toLowerCase()).toContain('edge case');
  });

  it('AC-17: explain prompt mentions risks', () => {
    const result = buildTaskPrompt('explain', 'explain please');
    expect(result.toLowerCase()).toContain('risk');
  });

  it('AC-17: explain prompt contains the user ask text', () => {
    const result = buildTaskPrompt('explain', 'what is this?');
    expect(result).toContain('what is this?');
  });

  // AC-18: fix command
  it('AC-18: fix prompt instructs to list problems', () => {
    const result = buildTaskPrompt('fix', 'fix this code');
    expect(result.toLowerCase()).toContain('list');
  });

  it('AC-18: fix prompt instructs to provide corrected code in one block', () => {
    const result = buildTaskPrompt('fix', 'fix this code');
    const lower = result.toLowerCase();
    expect(lower).toContain('corrected code');
    expect(lower).toContain('one');
  });

  it('AC-18: fix prompt contains the user ask text', () => {
    const result = buildTaskPrompt('fix', 'fix the null handling');
    expect(result).toContain('fix the null handling');
  });

  // AC-19: tests command
  it('AC-19: tests prompt with Python languageId mentions pytest', () => {
    const result = buildTaskPrompt('tests', 'write tests', 'python');
    expect(result.toLowerCase()).toContain('pytest');
  });

  it('AC-19: tests prompt with TypeScript languageId mentions vitest or jest', () => {
    const result = buildTaskPrompt('tests', 'write tests', 'typescript');
    const lower = result.toLowerCase();
    expect(lower.includes('vitest') || lower.includes('jest')).toBe(true);
  });

  it('AC-19: tests prompt with JavaScript languageId mentions vitest or jest', () => {
    const result = buildTaskPrompt('tests', 'write tests', 'javascript');
    const lower = result.toLowerCase();
    expect(lower.includes('vitest') || lower.includes('jest')).toBe(true);
  });

  it('AC-19: tests prompt mentions normal cases, edge cases, error cases', () => {
    const result = buildTaskPrompt('tests', 'add coverage', 'python');
    const lower = result.toLowerCase();
    expect(lower).toContain('normal');
    expect(lower).toContain('edge');
    expect(lower).toContain('error');
  });

  it('AC-19: tests prompt instructs to provide all tests in one fenced code block', () => {
    const result = buildTaskPrompt('tests', 'write tests', 'typescript');
    const lower = result.toLowerCase();
    expect(lower).toContain('one');
    expect(lower).toContain('block');
  });

  // AC-20: empty prompt uses DEFAULT_ASKS
  it('AC-20: empty userPrompt for explain uses DEFAULT_ASKS.explain', () => {
    const result = buildTaskPrompt('explain', '');
    expect(result).toContain(DEFAULT_ASKS.explain);
    expect(DEFAULT_ASKS.explain).toBe('Explain this code.');
  });

  it('AC-20: empty userPrompt for fix uses DEFAULT_ASKS.fix', () => {
    const result = buildTaskPrompt('fix', '');
    expect(result).toContain(DEFAULT_ASKS.fix);
    expect(DEFAULT_ASKS.fix).toBe('Fix the problems in this code.');
  });

  it('AC-20: empty userPrompt for tests uses DEFAULT_ASKS.tests', () => {
    const result = buildTaskPrompt('tests', '');
    expect(result).toContain(DEFAULT_ASKS.tests);
    expect(DEFAULT_ASKS.tests).toBe('Write unit tests for this code.');
  });

  it('AC-20: whitespace-only userPrompt falls back to DEFAULT_ASKS', () => {
    const result = buildTaskPrompt('explain', '   ');
    expect(result).toContain(DEFAULT_ASKS.explain);
  });

  it('AC-20: null command returns the userPrompt as-is', () => {
    const prompt = 'what is the purpose of this?';
    const result = buildTaskPrompt(null, prompt);
    expect(result).toBe(prompt);
  });
});

// ============================================================================
// buildSelectionPrefill — AC-29
// ============================================================================

describe('buildSelectionPrefill (AC-29)', () => {
  it('AC-29: result starts with the ask text', () => {
    const ask = 'Explain this code.';
    const result = buildSelectionPrefill(ask, 'const x = 1;', 'typescript');
    expect(result.startsWith(ask)).toBe(true);
  });

  it('AC-29: result contains a fenced code block after the ask text', () => {
    const ask = 'Explain this code.';
    const result = buildSelectionPrefill(ask, 'const x = 1;', 'typescript');
    expect(result).toContain('```');
    expect(result).toContain('const x = 1;');
  });

  it('AC-29: code is truncated to SELECTION_COMMAND_LIMIT (30,000) with marker', () => {
    const ask = 'Explain this code.';
    const bigCode = 'y'.repeat(SELECTION_COMMAND_LIMIT + 50);
    const result = buildSelectionPrefill(ask, bigCode, 'typescript');
    // Truncation marker must be present
    expect(result).toContain('… [truncated');
    // The 50-char overage must be reported in the marker
    expect(result).toContain('… [truncated 50 characters]');
    // The full big code string must NOT appear (it was truncated)
    expect(result).not.toContain(bigCode);
  });

  it('AC-29: code within SELECTION_COMMAND_LIMIT is not truncated', () => {
    const ask = 'Fix the problems in this code.';
    const code = 'function hello() { return 42; }';
    const result = buildSelectionPrefill(ask, code, 'javascript');
    expect(result).not.toContain('[truncated');
    expect(result).toContain(code);
  });

  it('AC-29: fence uses correct language id after remapping (typescriptreact → tsx)', () => {
    const result = buildSelectionPrefill('Explain this code.', 'const x = 1;', 'typescriptreact');
    expect(result).toContain('```tsx');
  });

  it('AC-29: fence uses shellscript → bash mapping', () => {
    const result = buildSelectionPrefill('Explain this code.', 'echo hello', 'shellscript');
    expect(result).toContain('```bash');
  });

  it('AC-29: "Fix the problems in this code." ask produces correct prefill format', () => {
    const ask = 'Fix the problems in this code.';
    const code = 'let x = null; x.toString();';
    const result = buildSelectionPrefill(ask, code, 'typescript');
    expect(result.startsWith(ask + '\n')).toBe(true);
    expect(result).toContain('```typescript');
    expect(result).toContain(code);
  });
});
