# AIG Coding Assistant (U3 preview)

Built by AIDLC run REQ-007 from unit U3 of the AIG AI Ecosystem VS Code extension specification:
the `@aig` chat participant, Explain/Fix Selection, AIG: Ask and AIG: Test model routing.
