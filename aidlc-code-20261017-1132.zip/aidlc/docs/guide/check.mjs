#!/usr/bin/env node
/**
 * Browser check of the built guide, using control-plane/web's Playwright and axe installs (no extra dependencies):
 *
 *   node docs/guide/check.mjs            (after `cd control-plane/web && npm ci && npx playwright install chromium`)
 *
 * Serves docs/guide from 127.0.0.1 with a strict CSP (script-src 'self'; style-src 'self', no 'unsafe-inline') and
 * fails on: any request that leaves that origin (offline), CSP violations or page errors, serious/critical axe
 * WCAG 2.x A/AA violations in light or dark, broken animation controls (Play, Pause, Step, Replay, Simulate failure
 * up to the LoopGuard escalation), the squad drawer, keyboard access to every diagram node, the ⌘K palette, the
 * agent filters, reduced motion (no moving pulse) and horizontal page overflow at phone width.
 * Screenshots go to docs/guide/screenshots/.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const WEB = path.resolve(HERE, '..', '..', 'control-plane', 'web');
const OUT = path.join(HERE, 'screenshots');
const require = createRequire(path.join(WEB, 'package.json'));
const { chromium } = require('@playwright/test');
const AxeBuilder = require('@axe-core/playwright').default;

const CSP = "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'";
const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.md': 'text/markdown; charset=utf-8', '.yaml': 'text/yaml', '.txt': 'text/plain' };

// Playwright's default screenshot options inject a <style> (caret hiding), which this page's CSP rightly blocks.
const SHOT = { caret: 'initial', animations: 'allow' };
const failures = [];
const passes = [];
const check = (ok, name, detail = '') => (ok ? passes : failures).push(detail ? `${name}: ${detail}` : name);

function serve() {
  const server = http.createServer((req, res) => {
    const rel = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
    const file = path.join(HERE, rel);
    if (!file.startsWith(HERE) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404).end();
      return;
    }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Content-Security-Policy': CSP });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

async function openPage(browser, origin, options = {}) {
  const context = await browser.newContext({ viewport: { width: 1360, height: 900 }, ...options });
  const page = await context.newPage();
  const outside = [];
  const errors = [];
  await page.route('**/*', (route) => {
    const url = route.request().url();
    if (url.startsWith(origin)) return route.continue();
    outside.push(url);
    return route.abort();
  });
  await page.addInitScript(() => {
    window.__csp = [];
    document.addEventListener('securitypolicyviolation', (e) => window.__csp.push(`${e.violatedDirective} ${e.blockedURI}`));
  });
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(`${origin}/index.html`);
  await page.waitForFunction(() => document.documentElement.classList.contains('js'));
  return { context, page, outside, errors };
}

async function axe(page, label, errors) {
  // axe-core's own probes inject inline styles that this CSP blocks; drop what it causes, keep the page's record.
  const cspBefore = await page.evaluate(() => window.__csp.length);
  const errorsBefore = errors.length;
  const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa']).analyze();
  await page.evaluate((n) => window.__csp.splice(n), cspBefore);
  errors.splice(errorsBefore);
  const bad = result.violations.filter((v) => v.impact === 'serious' || v.impact === 'critical');
  check(bad.length === 0, `axe ${label}: no serious/critical violations`, bad.map((v) => `${v.id} (${v.nodes.length}): ${v.nodes.slice(0, 3).map((n) => n.target.join(' ')).join(' | ')}`).join('; '));
  return result.violations;
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const server = await serve();
  const origin = `http://127.0.0.1:${server.address().port}`;
  const browser = await chromium.launch();
  try {
    // ---------------- light theme, desktop
    const { context, page, outside, errors } = await openPage(browser, origin);
    await page.click('[data-theme-choice="light"]');
    check((await page.getAttribute('html', 'data-theme')) === 'light', 'theme toggle: light');
    await page.screenshot({ path: path.join(OUT, 'overview-light.png'), ...SHOT });

    const counts = await page.evaluate(() => ({
      sections: document.querySelectorAll('section.gsec').length,
      flows: document.querySelectorAll('figure.flow svg title').length,
      agents: document.querySelectorAll('#agent-grid .agent').length,
      nodes: document.querySelectorAll('.flow-svg .fn').length,
      focusable: document.querySelectorAll('.flow-svg .fn[tabindex="0"]').length,
    }));
    check(counts.sections === 8 && counts.flows === 5 && counts.agents === 65, 'structure: 8 sections, 5 diagrams, 65 agents', JSON.stringify(counts));
    check(counts.nodes > 0 && counts.nodes === counts.focusable, 'every diagram node is keyboard-focusable', `${counts.focusable}/${counts.nodes}`);

    // feature flowchart: Step, Play, Pause, Replay
    const fig = page.locator('#flow-feature');
    await fig.scrollIntoViewIfNeeded();
    await page.waitForTimeout(400);
    await fig.locator('[data-act="replay"]').click();
    await fig.locator('[data-act="play"]').click();
    check((await fig.locator('[data-act="play"]').getAttribute('aria-pressed')) === 'false', 'Pause stops playback');
    await fig.locator('[data-act="replay"]').click();
    await page.waitForTimeout(150);
    check((await fig.locator('[data-act="play"]').getAttribute('aria-pressed')) === 'true', 'Replay restarts playback');
    await page.waitForTimeout(2600);
    const playing = await fig.locator('.fn.is-active').count();
    const done = await fig.locator('.fn.is-done').count();
    check(playing >= 1 && done >= 1, 'Play advances the stepper', `active ${playing}, done ${done}`);
    await shoot(fig, path.join(OUT, 'feature-playing-light.png'));
    await fig.locator('[data-act="play"]').click();
    for (let i = 0; i < 3; i += 1) await fig.locator('[data-act="step"]').click();
    const status = await fig.locator('[data-status]').textContent();
    check(/^Step \d+ of 19:/.test(status), 'Step advances one stage and narrates it', status.slice(0, 80));

    // Simulate failure through to the LoopGuard escalation
    await fig.locator('[data-act="fail"]').check({ force: true });
    for (let i = 0; i < 40; i += 1) await fig.locator('[data-act="step"]').click();
    const iter = await fig.locator('[data-iter] b').textContent();
    const escActive = await fig.locator('.fn[data-node="esc"]').evaluate((g) => g.classList.contains('is-active'));
    const failText = await fig.locator('[data-status]').textContent();
    check(iter === '5' && escActive && /Still failing after 5 iterations/.test(failText), 'Simulate failure: counter reaches 5 and LoopGuard escalates', `iteration ${iter}, esc ${escActive}`);
    await shoot(fig, path.join(OUT, 'feature-failure-escalation-light.png'));

    // squad drawer by mouse and keyboard
    await fig.locator('.fn[data-node="s7"]').click();
    const title = await page.locator('#drawer-title').textContent();
    const items = await page.locator('#drawer-body li').count();
    check(await page.locator('#drawer').isVisible() && title.startsWith('S7') && items === 8, 'squad node opens the drawer with its agents', `${title}, ${items} agents`);
    await page.waitForTimeout(450); // let the drawer finish sliding in
    await page.screenshot({ path: path.join(OUT, 'squad-drawer-light.png'), ...SHOT });
    await page.keyboard.press('Escape');
    check(!(await page.locator('#drawer').isVisible()), 'Esc closes the drawer');
    await fig.locator('.fn[data-node="s2"]').focus();
    await page.keyboard.press('Enter');
    check((await page.locator('#drawer-title').textContent()).startsWith('S2'), 'Enter on a focused squad node opens the drawer');
    await page.keyboard.press('Escape');
    const focusBack = await page.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-node'));
    check(focusBack === 's2', 'focus returns to the node after closing', String(focusBack));

    // ⌘K palette
    await page.keyboard.press('ControlOrMeta+k');
    check(await page.locator('#palette').isVisible(), '⌘K opens the palette');
    await page.keyboard.type('spec analyst');
    await page.waitForTimeout(350);
    await page.screenshot({ path: path.join(OUT, 'palette-light.png'), ...SHOT });
    await page.keyboard.press('Enter');
    await page.waitForTimeout(300);
    check(page.url().endsWith('#agent-spec-analyst'), 'palette Enter jumps to the result', page.url());

    // agent filters
    await page.selectOption('#agent-squad', 'S5');
    check((await page.locator('#agent-count').textContent()) === '5 of 65 agents', 'squad filter', await page.locator('#agent-count').textContent());
    await page.selectOption('#agent-squad', '');
    await page.selectOption('#agent-model', 'haiku');
    const haiku = await page.locator('#agent-count').textContent();
    await page.fill('#agent-q', 'zzzz-no-such-agent');
    check(/^\d+ of 65 agents$/.test(haiku) && (await page.locator('#agent-empty').isVisible()), 'model and text filters', haiku);
    await page.fill('#agent-q', '');
    await page.selectOption('#agent-model', '');
    await under(page.locator('#agents-list'));
    await page.screenshot({ path: path.join(OUT, 'agent-catalog-light.png'), ...SHOT });
    await under(page.locator('#samples-new'));
    await page.screenshot({ path: path.join(OUT, 'sample-spec-light.png'), ...SHOT });

    await axe(page, 'light', errors);

    // ---------------- dark theme
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.click('[data-theme-choice="dark"]');
    check((await page.getAttribute('html', 'data-theme')) === 'dark', 'theme toggle: dark');
    await page.waitForTimeout(200);
    await page.screenshot({ path: path.join(OUT, 'overview-dark.png'), ...SHOT });
    await page.locator('#flow-architecture').scrollIntoViewIfNeeded();
    await page.waitForTimeout(3200);
    await shoot(page.locator('#flow-architecture'), path.join(OUT, 'architecture-dark.png'));
    await page.locator('#flow-multirepo').scrollIntoViewIfNeeded();
    await page.waitForTimeout(4200);
    await shoot(page.locator('#flow-multirepo'), path.join(OUT, 'multirepo-dark.png'));
    await under(page.locator('#run-ui'));
    await page.screenshot({ path: path.join(OUT, 'web-ui-journey-dark.png'), ...SHOT });
    await axe(page, 'dark', errors);
    const csp = await page.evaluate(() => window.__csp);
    check(csp.length === 0, 'no CSP violations under script-src/style-src self', csp.join(', '));
    const stored = await page.evaluate(() => window.localStorage.getItem('aidlc.theme'));
    await page.reload();
    await page.waitForFunction(() => document.documentElement.classList.contains('js'));
    check(stored === 'dark' && (await page.getAttribute('html', 'data-theme')) === 'dark', 'theme persists across reloads');

    check(outside.length === 0, 'offline: no request leaves the guide', outside.join(', '));
    check(errors.length === 0, 'no page or console errors', errors.join(' | '));
    const inline = await page.evaluate(() => ({ styled: document.querySelectorAll('[style]').length, scripts: [...document.scripts].filter((s) => !s.src).length }));
    check(inline.styled === 0 && inline.scripts === 0, 'no style attributes or inline scripts in the live DOM', JSON.stringify(inline));
    await context.close();

    // ---------------- reduced motion
    const rm = await openPage(browser, origin, { reducedMotion: 'reduce' });
    const flow = rm.page.locator('#flow-bugfix');
    await flow.scrollIntoViewIfNeeded();
    await rm.page.waitForTimeout(1200);
    check((await flow.locator('[data-act="play"]').getAttribute('aria-pressed')) === 'false', 'reduced motion: no autoplay');
    for (let i = 0; i < 4; i += 1) await flow.locator('[data-act="step"]').click();
    await rm.page.waitForTimeout(120);
    const pulses = await rm.page.locator('.pulses circle').count();
    const current = await flow.locator('.flow-steps li.is-current').count();
    const anim = await flow.locator('.fe.is-on').first().evaluate((e) => getComputedStyle(e).animationName);
    check(pulses === 0 && current >= 1 && anim === 'none', 'reduced motion: static diagram, step highlighting only', `pulses ${pulses}, highlighted ${current}, animation ${anim}`);
    await shoot(flow, path.join(OUT, 'bugfix-reduced-motion-light.png'));
    await rm.context.close();

    // ---------------- phone width
    const phone = await openPage(browser, origin, { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
    const overflow = await phone.page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    check(overflow <= 0, 'no horizontal page scroll at 390px', `${overflow}px`);
    await phone.page.click('#menu-toggle');
    check(await phone.page.locator('#guide-nav').evaluate((n) => n.classList.contains('open')), 'mobile nav opens');
    await phone.page.waitForTimeout(450); // let the drawer nav finish sliding in
    await phone.page.screenshot({ path: path.join(OUT, 'mobile-nav-light.png'), ...SHOT });
    await phone.context.close();
  } finally {
    await browser.close();
    server.close();
  }
  for (const p of passes) console.log(`  ok    ${p}`);
  for (const f of failures) console.log(`  FAIL  ${f}`);
  console.log(`${passes.length} passed, ${failures.length} failed. Screenshots: ${path.relative(process.cwd(), OUT) || OUT}`);
  process.exit(failures.length ? 1 : 0);
}

/** Scroll so the element starts just below the sticky header. */
async function under(locator) {
  await locator.evaluate((el) => window.scrollTo(0, el.getBoundingClientRect().top + window.scrollY - 76));
}

/** Screenshot of one element below the sticky header: a viewport tall enough for it, scrolled just under the header. */
async function shoot(locator, file) {
  const page = locator.page();
  const size = page.viewportSize();
  const height = Math.ceil((await locator.boundingBox()).height) + 90;
  await page.setViewportSize({ width: size.width, height: Math.max(size.height, height) });
  await under(locator);
  const box = await locator.boundingBox();
  await page.screenshot({ path: file, ...SHOT, clip: { x: box.x - 8, y: box.y - 8, width: box.width + 16, height: box.height + 16 } });
  await page.setViewportSize(size);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
