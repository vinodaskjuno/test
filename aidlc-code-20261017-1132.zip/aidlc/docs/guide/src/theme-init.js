// Applies the cached theme before first paint, from an external file so the guide needs no inline code (CSP).
// Same storage key and rules as the control-plane UI (control-plane/web/public/theme-init.js).
(function () {
  var pref = 'system';
  try {
    var v = window.localStorage.getItem('aidlc.theme');
    if (v === 'light' || v === 'dark' || v === 'system') pref = v;
  } catch (e) {
    // storage disabled: follow the system preference
  }
  var dark = pref === 'dark' || (pref === 'system' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme-pref', pref);
})();
