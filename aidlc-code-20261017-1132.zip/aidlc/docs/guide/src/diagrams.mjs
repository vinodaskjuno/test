/**
 * The guide's five animated flowcharts, as data. `build.mjs` renders each to inline SVG ({{svg:<id>}}) with
 * <title>/<desc>, keyboard-focusable nodes and a text steps list; `guide.js` animates them.
 *
 * Node: {id, x, y, kind: box|gate|pill, t1, t2?, label? (steps list), labelPos?: right (gate caption), squad?, human?,
 *        tone?: ok|warn, w?, h?, lanes?: [..], step}
 * Edge: {from, to, d?, back?, label?, lx?, ly?} (label centred on lx). Edges without `d` are routed between facing sides.
 * seq: space-separated steps; `a+b` lights several nodes at once.
 * fail (FeatureWorkflow only): the fix loop played by "Simulate failure".
 */

const col = (i, start = 80, gap = 152) => start + (i - 1) * gap;
const A = 70;
const B = 250;
const C = 430;

export function diagrams({ fixMax }) {
  return {
    feature: {
      title: 'FeatureWorkflow end to end',
      desc: 'A spec moves through S1 discovery, the V1 spec gate, Gate A, an early draft PR, S2 planning, the V2 plan gate and an early trial merge, then S3 development, the S4 test, S5 code-issue and S6 validation fix loop, S7 review, knowledge capture, the final trial merge, S8 delivery, CI and Gate B, where a human merges.',
      width: 1240,
      height: 500,
      seq: 'upload s1 v1 gatea specpr s2 v2 tm1 s3 s4 s5 s6 s7 know tm2 s8 ci gateb done',
      fail: { after: 's6', loop: 'dbg dev s4 s5 s6', max: fixMax, end: 'esc', counter: 's4' },
      nodes: [
        { id: 'upload', x: col(1), y: A, t1: 'Upload spec', t2: 'UI · CLI · API · MCP', human: true,
          step: 'A spec arrives: uploaded in the UI, `aidlc run`, `POST /api/v1/runs`, MCP `start_run`, or a GitHub/Jira trigger. A central REQ id is allocated.' },
        { id: 's1', x: col(2), y: A, t1: 'S1 Discovery', t2: 'intake · spec · gaps', squad: 'S1',
          step: 'S1 Discovery: Intake (plus a deterministic prompt-injection scan), the Spec Analyst writes requirement.md with cited ACs, then Ambiguity & Conflict, Compliance & Policy and, with a Figma source, UX/Design run in parallel.' },
        { id: 'v1', x: col(3), y: A, kind: 'gate', t1: 'V1', t2: 'spec gate', label: 'V1 spec gate',
          step: 'V1 spec gate: Spec Validator + Adversary(spec) + a deterministic citation check. Failures go back to the Spec Analyst up to `v1_max_attempts` (3), then escalate.' },
        { id: 'gatea', x: col(4), y: A, kind: 'gate', t1: 'A', t2: 'Gate A · questions', label: 'Gate A', human: true,
          step: 'Gate A: open questions wait in the Inbox with no timeout; the Spec Analyst folds the answers into the spec. Skipped when nothing is open.' },
        { id: 'specpr', x: col(5), y: A, t1: 'Draft PR', t2: 'requirement.md', squad: 'S8',
          step: 'The validated spec is committed under `.adlc/specs/REQ-xxx-slug/` and the primary repo’s draft PR opens early.' },
        { id: 's2', x: col(6), y: A, t1: 'S2 Plan', t2: 'design · tasks', squad: 'S2',
          step: 'S2 Plan: Repository Discovery (baseline tests, integration branch), lessons search, Mapper + Tracer + Explorer in parallel, Solution Architect, API Contract + Data Modeler in parallel, Work Planner (tasks with `repo:`, `activation_set`) and the Overlap Analyst against the in-flight manifest.' },
        { id: 'v2', x: col(7), y: A, kind: 'gate', t1: 'V2', t2: 'plan gate', label: 'V2 plan gate',
          step: 'V2 plan gate: Plan Validator + Adversary(plan); up to `v2_max_attempts` (3) Work Planner fixes, then escalate. Architecture and tasks are committed.' },
        { id: 'tm1', x: col(8), y: A, kind: 'gate', t1: 'TM', t2: 'early merge', labelPos: 'right', label: 'Early trial merge',
          step: 'Early trial merge: `git merge-tree` against the integration branch and higher-ranked in-flight runs; it blocks only on a real conflict with a higher-ranked run.' },
        { id: 's3', x: col(8), y: B, t1: 'S3 Develop', squad: 'S3', h: 76, lanes: ['api', 'web', 'infra'],
          step: 'S3 Develop: tasks run by dependency tier, each owning dev agent in its own worktree and limited to its planned files; task branches merge into the run branch (`conflict_bound` decides what may auto-resolve). Draft PRs open for every touched repo.' },
        { id: 's4', x: col(7), y: B, t1: 'S4 Test', t2: 'write + run tests', squad: 'S4',
          step: 'S4 Test: the Test Strategist, Test Environment & Data and the activated test writers (first iteration only), then every repo’s test commands run deterministically; the Flaky-Test Analyst looks at failures.' },
        { id: 's5', x: col(6), y: B, t1: 'S5 Code issues', t2: 'diff scanners', squad: 'S5',
          step: 'S5 Code issues: the activated scanners (static analysis, runtime hazard, security, dependency & license, performance smell) on the diff.' },
        { id: 's6', x: col(5), y: B, t1: 'S6 Validate', t2: 'ACs + quality gate', squad: 'S6',
          step: 'S6 Validate: Spec Conformance (and Visual/UX for UI changes) verdicts, then the deterministic quality gate: tests, coverage, blocking severities, every AC, a11y, breaking API changes.' },
        { id: 'dbg', x: col(6), y: C, t1: 'Triage + Debug', t2: 'fix tickets', squad: 'S6', tone: 'warn',
          step: 'Fix loop: Triage groups the failures into fix tickets and the Debugger confirms each root cause, with a failing test where it can.' },
        { id: 'dev', x: col(7), y: C, t1: 'Owning dev', t2: 'applies the fix', squad: 'S3', tone: 'warn',
          step: 'The owning dev (or test) agent applies each fix ticket in its repo; then S4 → S5 → S6 run again.' },
        { id: 'esc', x: col(5), y: C, t1: 'Escalation', t2: 'LoopGuard → Inbox', human: true, tone: 'warn',
          step: `LoopGuard: a repeated failure signature, the run budget, or ${fixMax} failing iterations (\`fix_loop_max_iterations\`) escalate to the Inbox: retry, takeover or cancel.` },
        { id: 's7', x: col(4), y: B, t1: 'S7 Review', t2: 'reflect · panel · judge', squad: 'S7',
          step: 'S7 Review: the Reflector (may ask questions), then Adversary(diff) and the five specialist reviewers in parallel, then the Review Judge. Blocking findings go back into the S4–S6 loop.' },
        { id: 'know', x: col(3), y: B, t1: 'Knowledge', t2: 'lessons · assumptions', squad: 'S9',
          step: 'Knowledge Capture writes `LESSON-xxx` and `ASSUME-xxx` files that ship in the same PR.' },
        { id: 'tm2', x: col(2), y: B, kind: 'gate', t1: 'TM', t2: 'trial merge · final', label: 'Final trial merge',
          step: 'Final trial merge, authoritative: conflicting branches are merged in only when `conflict_bound` accepts every conflicted file, then the quality loop re-runs and the gate is checked again; anything else ends the run `blocked`.' },
        { id: 's8', x: col(1), y: B, t1: 'S8 Deliver', t2: 'commit · PRs ready', squad: 'S8',
          step: 'S8 Deliver: commit messages, release notes, the audit pack and PR bodies (traceability, merge order, resolved conflicts); PRs marked ready and `aidlc/gates` set to success.' },
        { id: 'ci', x: col(1), y: C, t1: 'CI watch', t2: 'fix red CI', squad: 'S8',
          step: 'CI watch: PR checks are polled; red CI goes to the CI Watcher and back through the quality loop (`ci_max_fix_attempts`, 3). Then the outcome is `pr-ready` and the preview environment starts.' },
        { id: 'gateb', x: col(2), y: C, kind: 'gate', t1: 'B', t2: 'Gate B · merge', label: 'Gate B', human: true,
          step: 'Gate B: humans review and merge. PR comments start PR Feedback rounds (`feedback_max_rounds`, 3); a PR closed without merging cancels the run.' },
        { id: 'done', x: col(3) + 4, y: C, kind: 'pill', t1: 'pr-ready', tone: 'ok',
          step: 'Every PR merged: the run finishes `pr-ready` and leaves the in-flight manifest.' },
      ],
      edges: [
        { from: 'upload', to: 's1' }, { from: 's1', to: 'v1' }, { from: 'v1', to: 'gatea' }, { from: 'gatea', to: 'specpr' },
        { from: 'specpr', to: 's2' }, { from: 's2', to: 'v2' }, { from: 'v2', to: 'tm1' }, { from: 'tm1', to: 's3' },
        { from: 's3', to: 's4' }, { from: 's4', to: 's5' }, { from: 's5', to: 's6' }, { from: 's6', to: 's7' },
        { from: 's7', to: 'know' }, { from: 'know', to: 'tm2' }, { from: 'tm2', to: 's8' }, { from: 's8', to: 'ci' },
        { from: 'ci', to: 'gateb' }, { from: 'gateb', to: 'done' },
        { from: 's6', to: 'dbg', d: 'M712 278 C712 352 840 330 840 402' },
        { from: 'dbg', to: 'dev' },
        { from: 'dev', to: 's4' },
        { from: 's6', to: 'esc', d: 'M664 278 V402' },
        { from: 'v1', to: 'v1', back: true, d: 'M372 40 C356 6 412 6 396 40', label: '≤3 fixes', lx: 446, ly: 24 },
        { from: 'v2', to: 'v2', back: true, d: 'M980 40 C964 6 1020 6 1004 40', label: '≤3 fixes', lx: 1054, ly: 24 },
        { from: 's7', to: 's4', back: true, d: 'M536 222 C536 168 992 168 992 222', label: 'blocking review findings → fix loop', lx: 764, ly: 160 },
      ],
    },

    architecture: {
      title: 'System architecture',
      desc: 'Clients (web UI, CLI, SDKs, the MCP server and GitHub or Jira webhooks) call the control-plane API, which scans uploads with CrowdStrike Falcon and starts and signals Temporal workflows. Workers run the workflows and activities: agents on Claude through the Claude Agent SDK and Amazon Bedrock, deterministic tools in a sandbox, git and PRs through the forge, MCP integrations, events in Postgres, notifications, webhooks, Prometheus metrics and Fiddler AI agent traces.',
      width: 1240,
      height: 500,
      nodeW: 150,
      seq: 'ui+cli+sdk+mcp+hooks api scan temporal worker claude+sandbox+mcpint github db+s3 notify+obs',
      lanesBg: [
        { x: 12, y: 30, w: 166, h: 446, label: 'Clients' },
        { x: 1050, y: 22, w: 178, h: 454, label: 'Integrations' },
      ],
      nodes: [
        { id: 'ui', x: 95, y: 75, t1: 'Web UI', t2: 'Next.js · AIG style', step: 'Clients: the web UI, the `aidlc` CLI, the SDKs, `aidlc-mcp` and GitHub/Jira webhooks all use the same REST API v1, with the same RBAC and audit trail.' },
        { id: 'cli', x: 95, y: 165, t1: 'aidlc CLI', t2: 'CI · local mode', step: 'The `aidlc` CLI (built on the Python SDK): login, run --watch, inbox, answer, escalation, doctor, local mode.' },
        { id: 'sdk', x: 95, y: 255, t1: 'SDKs', t2: 'TypeScript · Python', step: '`@aidlc/sdk` (TypeScript) and `aidlc-sdk` (Python), generated from `clients/openapi.json`, with SSE helpers that resume from the last event id.' },
        { id: 'mcp', x: 95, y: 345, t1: 'aidlc-mcp', t2: 'Claude Code · VS Code', step: '`aidlc-mcp` exposes start_run, get_run_status, list_inbox, answer_gate_question, act_on_escalation, get_preview_url, get_run_artifacts and search_knowledge, acting as the calling user.' },
        { id: 'hooks', x: 95, y: 435, t1: 'GitHub · Jira', t2: 'webhooks · HMAC', step: 'GitHub (label `aidlc`, `/aidlc run` comment, PR activity) and Jira (label `aidlc`) call `/api/v1/hooks/*`, verified by HMAC-SHA256.' },
        { id: 'api', x: 345, y: 255, t1: 'Control-plane API', t2: '/api/v1 · SSE · RBAC', h: 400,
          step: 'The control-plane API (FastAPI, `aidlc-api`) authenticates (OIDC JWT, `aidlc_` API token, or `dev:<email>` in dev mode), checks project roles, stores uploads and starts or signals workflows. It also serves `/metrics` and this guide at `/guide`.' },
        { id: 'scan', x: 600, y: 60, t1: 'CrowdStrike Falcon', t2: 'upload malware scan', step: 'Every upload is scanned through the CrowdStrike Falcon API (OAuth2 client credentials, sample upload, QuickScan, verdict) before it is stored: malicious or suspicious files are rejected with 422, and an unreachable scanner fails closed with 503.' },
        { id: 'temporal', x: 600, y: 150, t1: 'Temporal', t2: 'workflows · signals', step: 'Temporal holds every run durably: workflow state, timers and human signals (`answer_question`, `decide_escalation`, `pr_event`, `cancel_run`), plus the `state` query.' },
        { id: 'db', x: 600, y: 345, t1: 'Postgres', t2: 'runs · events · inbox', step: 'Every run event lands in the platform DB (runs, events, Inbox, manifest, knowledge full-text index, cost) and feeds the SSE stream.' },
        { id: 's3', x: 600, y: 435, t1: 'Artifacts', t2: 'S3 · MinIO · fs', step: 'Uploads, run requests, reports and audit packs are stored in the artifact store (`AIDLC_ARTIFACT_BACKEND` = `fs` or `s3`).' },
        { id: 'worker', x: 855, y: 150, t1: 'aidlc-worker', t2: 'workflows · activities', step: 'The worker runs workflow code and activities on task queue `aidlc-main`; one `agent_runner` activity serves all 65 agents.' },
        { id: 'sandbox', x: 855, y: 300, t1: 'Sandbox', t2: 'local or K8s Jobs', step: 'Deterministic work (tests, scanners, git) runs in the worktree as subprocesses (`AIDLC_EXECUTOR=local`) or as Kubernetes Jobs with default-deny networking (`k8s`).' },
        { id: 'claude', x: 1139, y: 70, t1: 'Claude on Bedrock', t2: 'Agent SDK · IAM role', step: 'Each agent is a Claude Agent SDK `query()` on Amazon Bedrock (`CLAUDE_CODE_USE_BEDROCK=1`, credentials from the worker’s IAM role, model names mapped to Bedrock ids by `AIDLC_BEDROCK_MODEL_MAP`) with the model, tools, MCP servers, budget and timeout of its `agent.yaml`; ETHOS is prepended and PreToolUse hooks enforce the policy.' },
        { id: 'github', x: 1139, y: 160, t1: 'Forge', t2: 'GitHub or local', step: 'The forge (GitHub REST/GraphQL, or the local forge) creates repos, protects branches, opens draft PRs, posts the `aidlc/gates` status and reads CI and comments.' },
        { id: 'mcpint', x: 1139, y: 250, t1: 'MCP servers', t2: 'knowledge · Jira · Figma', step: 'Agents may use the MCP servers in `mcp/servers.json`: the internal read-only knowledge server, Atlassian and Figma.' },
        { id: 'notify', x: 1139, y: 340, t1: 'Notifications', t2: 'email · Slack · Teams', step: 'Notifications (email, Slack, Teams) and signed outbound webhooks fire on questions, escalations, PRs ready and outcomes.' },
        { id: 'obs', x: 1139, y: 430, t1: 'Observability', t2: 'Prometheus · Fiddler AI', step: 'Prometheus scrapes the API `/metrics` and the worker on port 9464 and evaluates the recording and alert rules in `infra/prometheus/rules.yml`; the worker publishes one redacted Fiddler AI event per agent call; OpenTelemetry spans export over OTLP when configured.' },
      ],
      edges: [
        { from: 'ui', to: 'api', d: 'M170 75 H270' }, { from: 'cli', to: 'api', d: 'M170 165 H270' },
        { from: 'sdk', to: 'api', d: 'M170 255 H270' }, { from: 'mcp', to: 'api', d: 'M170 345 H270' },
        { from: 'hooks', to: 'api', d: 'M170 435 H270' },
        { from: 'api', to: 'scan', d: 'M420 60 H525' }, { from: 'api', to: 'temporal', d: 'M420 150 H525' }, { from: 'api', to: 'db', d: 'M420 345 H525' },
        { from: 'api', to: 's3', d: 'M420 435 H525' },
        { from: 'temporal', to: 'worker', d: 'M675 150 H780' },
        { from: 'worker', to: 'sandbox', d: 'M855 178 V272' },
        { from: 'worker', to: 'claude', d: 'M930 140 C990 140 1000 70 1064 70' },
        { from: 'worker', to: 'github', d: 'M930 150 C990 150 1000 160 1064 160' },
        { from: 'worker', to: 'mcpint', d: 'M930 160 C990 160 1000 250 1064 250' },
        { from: 'worker', to: 'db', d: 'M800 178 C800 300 720 345 675 345' },
        { from: 'worker', to: 's3', d: 'M790 178 C760 380 720 435 675 435' },
        { from: 'worker', to: 'notify', d: 'M920 178 C980 260 1000 340 1064 340' },
        { from: 'worker', to: 'obs', d: 'M910 178 C960 330 1000 430 1064 430' },
      ],
    },

    multirepo: {
      title: 'Multi-repo requirement and a sprint',
      desc: 'One requirement fans out to the api, web and infra worktrees on the same branch and produces three cross-linked PRs merged in merge_order. Two concurrent requirements meet at the in-flight manifest and the trial-merge gate; bounded conflict resolution either resolves the lower-ranked run’s conflict or blocks it.',
      width: 1240,
      height: 470,
      seq: 'req planner wt-infra+wt-api+wt-web pr-infra+pr-api+pr-web merge reqa+reqb manifest tm resolve+blocked',
      lanesBg: [
        { x: 12, y: 18, w: 1216, h: 222, label: 'One REQ, several repos' },
        { x: 12, y: 258, w: 1216, h: 200, label: 'Two REQs at once (sprint)' },
      ],
      nodes: [
        { id: 'req', x: 90, y: 135, t1: 'REQ-012', t2: 'feature flags', step: 'One requirement whose acceptance criteria span several repositories (sample: `brownfield-multi/feature-flags.md`).' },
        { id: 'planner', x: 280, y: 135, t1: 'Work Planner', t2: 'tasks with repo:', squad: 'S2', step: 'The Work Planner gives every task a `repo:`; the Plan Validator checks each one resolves and stays inside its repo; Architecture Conformance later checks contracts across repos.' },
        { id: 'wt-infra', x: 500, y: 65, t1: 'infra worktree', t2: 'aidlc/REQ-012-flags', squad: 'S3', step: 'One worktree and branch per touched repo, all with the same branch name `aidlc/REQ-xxx-slug`; dev agents run in parallel across repos.' },
        { id: 'wt-api', x: 500, y: 135, t1: 'api worktree', t2: 'aidlc/REQ-012-flags', squad: 'S3', step: 'The api worktree: contract and service changes by the owning dev agents.' },
        { id: 'wt-web', x: 500, y: 205, t1: 'web worktree', t2: 'aidlc/REQ-012-flags', squad: 'S3', step: 'The web worktree: UI changes that consume the new contract.' },
        { id: 'pr-infra', x: 730, y: 65, t1: 'PR infra#12', t2: 'cross-linked', squad: 'S8', step: 'One PR per touched repo. Each PR body links the others and lists the merge order, the traceability matrix and the audit pack.' },
        { id: 'pr-api', x: 730, y: 135, t1: 'PR api#41', t2: 'cross-linked', squad: 'S8', step: 'Gate B approves the whole set: the run stays at Gate B until every PR in the set is merged.' },
        { id: 'pr-web', x: 730, y: 205, t1: 'PR web#87', t2: 'cross-linked', squad: 'S8', step: 'A PR closed without merging cancels the run.' },
        { id: 'merge', x: 960, y: 135, t1: 'merge_order', t2: 'infra → api → web', human: true, step: 'Humans merge in `merge_order` from `.adlc/config.yml` (producers before consumers; the sample multi repos use infra → api → web).' },
        { id: 'reqa', x: 90, y: 315, t1: 'REQ-A', t2: 'rank 1', step: 'A sprint (`POST /api/v1/sprints`) starts one child run per item (FeatureWorkflow, or BugfixWorkflow for bug items), ranked after everything already in flight; lower rank merges first.' },
        { id: 'reqb', x: 90, y: 405, t1: 'REQ-B', t2: 'rank 2', step: 'REQ-B touches the same files as REQ-A (sample: `brownfield-multi/sprint-conflict/`).' },
        { id: 'manifest', x: 330, y: 360, t1: 'In-flight manifest', t2: 'repos · files · rank', squad: 'S2', step: 'Each run registers its repos, file footprint, components and rank in the in-flight manifest; the Overlap Analyst flags overlap with other runs.' },
        { id: 'tm', x: 560, y: 360, kind: 'gate', t1: 'TM', t2: 'git merge-tree', step: 'The trial-merge gate runs `git merge-tree` against the integration branch and higher-ranked in-flight branches, writing nothing: early (before S3, blocks only on a real conflict with a higher-ranked run) and final (authoritative, before PRs are marked ready).' },
        { id: 'resolve', x: 820, y: 315, t1: 'conflict_bound', t2: 'append-only → resolved', tone: 'ok', step: 'At the final gate the higher-ranked branch is merged in when `conflict_bound` accepts every conflicted file (both sides purely add lines at the same point, each side delimiter-balanced); the quality loop re-runs and each resolution is recorded in the run state and the PR body.' },
        { id: 'blocked', x: 820, y: 405, t1: 'blocked', t2: 'anything else', tone: 'warn', human: true, step: 'Any other conflict ends the lower-ranked run `blocked` for a human to rebase or resolve (sample: `seeded-defects/parallel-edit-conflict.md`).' },
      ],
      edges: [
        { from: 'req', to: 'planner' },
        { from: 'planner', to: 'wt-infra', d: 'M346 125 C400 125 380 65 434 65' }, { from: 'planner', to: 'wt-api' },
        { from: 'planner', to: 'wt-web', d: 'M346 145 C400 145 380 205 434 205' },
        { from: 'wt-infra', to: 'pr-infra' }, { from: 'wt-api', to: 'pr-api' }, { from: 'wt-web', to: 'pr-web' },
        { from: 'pr-infra', to: 'merge', d: 'M796 65 C850 65 840 125 894 125' }, { from: 'pr-api', to: 'merge' },
        { from: 'pr-web', to: 'merge', d: 'M796 205 C850 205 840 145 894 145' },
        { from: 'reqa', to: 'manifest', d: 'M156 315 C220 315 210 350 264 350' },
        { from: 'reqb', to: 'manifest', d: 'M156 405 C220 405 210 370 264 370' },
        { from: 'manifest', to: 'tm' },
        { from: 'tm', to: 'resolve', d: 'M594 360 C680 360 680 315 754 315' },
        { from: 'tm', to: 'blocked', d: 'M594 360 C680 360 680 405 754 405' },
      ],
    },

    bugfix: {
      title: 'BugfixWorkflow',
      desc: 'A bug report becomes a bug spec, passes Gate A, opens an early draft PR, then the Debugger reproduces the bug with a failing test, the owning dev agent fixes it, the quality loop and a lighter review run, and the PR is delivered through CI to Gate B.',
      width: 1240,
      height: 330,
      seq: 'bug s1 gatea specpr s2 repro red fix loop s7 know tm2 s8 ci gateb done',
      nodes: [
        { id: 'bug', x: col(1), y: A, t1: 'Bug report', t2: 'upload · issue · Jira', human: true, step: 'A bug arrives: an upload with kind `bug`, `aidlc run --type bug`, a GitHub issue labelled `bug` and `aidlc`, or a Jira issue of type Bug. A central BUG id is allocated.' },
        { id: 's1', x: col(2), y: A, t1: 'S1 Intake', t2: 'bug spec', squad: 'S1', step: 'S1: Intake and the Spec Analyst in bug mode write the bug report (no V1 gate in this workflow).' },
        { id: 'gatea', x: col(3), y: A, kind: 'gate', t1: 'A', t2: 'Gate A', human: true, step: 'Gate A asks open questions only when the bug spec has any.' },
        { id: 'specpr', x: col(4), y: A, t1: 'Draft PR', t2: '.adlc/bugs/BUG-…', squad: 'S8', step: 'The bug report is committed under `.adlc/bugs/` and the draft PR opens early.' },
        { id: 's2', x: col(5), y: A, t1: 'S2 Discover', t2: 'repo profile · lessons', squad: 'S2', step: 'S2: Repository Discovery profiles the repos (baseline tests) and relevant lessons are retrieved.' },
        { id: 'repro', x: col(6), y: A, t1: 'Reproduce', t2: 'Debugger', squad: 'S6', step: 'Reproduce: the Debugger writes a failing reproduction test and a root-cause fix ticket; if no test fails, Unit Test writes one. Not reproducible → escalation (`agent_error`).' },
        { id: 'red', x: col(7), y: A, kind: 'pill', t1: 'failing test', tone: 'warn', step: 'The bug is reproduced: a red regression test is committed (“test: reproduce bug”).' },
        { id: 'fix', x: col(8), y: A, t1: 'Owning dev', t2: 'applies the fix', squad: 'S3', step: 'The dev agent that owns the code applies the fix ticket.' },
        { id: 'loop', x: col(8), y: B, t1: 'S4–S6 loop', t2: 'tests · scans · gate', squad: 'S6', step: 'The S4 → S5 → S6 quality loop runs without writing new test suites (activation: Unit Test + the five S5 scanners), with the same LoopGuard.' },
        { id: 's7', x: col(7), y: B, t1: 'S7 light review', t2: 'correctness · security', squad: 'S7', step: 'A lighter review: Reflector, then the Correctness and Security reviewers (no Adversary), then the Review Judge.' },
        { id: 'know', x: col(6), y: B, t1: 'Knowledge', t2: 'lessons', squad: 'S9', step: 'Knowledge Capture records what the bug taught.' },
        { id: 'tm2', x: col(5), y: B, kind: 'gate', t1: 'TM', t2: 'trial merge', step: 'The final trial merge, as in FeatureWorkflow.' },
        { id: 's8', x: col(4), y: B, t1: 'S8 Deliver', t2: 'fix: … PR ready', squad: 'S8', step: 'S8 delivers a `fix:` commit and marks the PR ready with the regression test in the traceability evidence.' },
        { id: 'ci', x: col(3), y: B, t1: 'CI watch', t2: 'fix red CI', squad: 'S8', step: 'CI is watched and red CI is fixed through the quality loop.' },
        { id: 'gateb', x: col(2), y: B, kind: 'gate', t1: 'B', t2: 'Gate B', human: true, step: 'Gate B: a human reviews and merges.' },
        { id: 'done', x: col(1), y: B, kind: 'pill', t1: 'pr-ready', tone: 'ok', step: 'Merged: the run finishes `pr-ready`.' },
      ],
      edges: [
        { from: 'bug', to: 's1' }, { from: 's1', to: 'gatea' }, { from: 'gatea', to: 'specpr' }, { from: 'specpr', to: 's2' },
        { from: 's2', to: 'repro' }, { from: 'repro', to: 'red' }, { from: 'red', to: 'fix' }, { from: 'fix', to: 'loop' },
        { from: 'loop', to: 's7' }, { from: 's7', to: 'know' }, { from: 'know', to: 'tm2' }, { from: 'tm2', to: 's8' },
        { from: 's8', to: 'ci' }, { from: 'ci', to: 'gateb' }, { from: 'gateb', to: 'done' },
        { from: 'repro', to: 'repro', back: true, d: 'M820 42 C808 6 872 6 860 42', label: 'until a test fails', lx: 930, ly: 22 },
      ],
    },

    local: {
      title: 'Local dev mode and platform verification',
      desc: 'A developer exports the registry agents to Claude Code, runs the simplified pipeline locally on a branch, pushes it and submits it. The platform’s VerifyBranchWorkflow runs tests, scanners, validation and review and posts the aidlc/gates status that branch protection requires before a merge.',
      width: 1240,
      height: 340,
      seq: 'export l1 l2 l3 l4 l7 push submit api verify gates merge',
      lanesBg: [
        { x: 12, y: 16, w: 1216, h: 120, label: 'Developer machine · not platform-verified' },
        { x: 12, y: 190, w: 1216, h: 132, label: 'AIDLC platform · sandboxed, gated' },
      ],
      nodes: [
        { id: 'export', x: col(1), y: 80, t1: 'local export', t2: '.claude/ agents', step: '`aidlc local export` writes every registry agent as a Claude Code subagent under `.claude/agents/` plus the `aidlc-local-run` skill.' },
        { id: 'l1', x: col(2), y: 80, t1: 'S1 validate', t2: 'spec-validator', squad: 'S1', step: '`aidlc local run REQ-xxx` reads `.adlc/specs/REQ-xxx…/requirement.md`, checks out `aidlc/req-xxx-local` and runs the Spec Validator.' },
        { id: 'l2', x: col(3), y: 80, t1: 'S2 plan', t2: 'work-planner', squad: 'S2', step: 'The Work Planner writes `architecture.md` and `tasks/TASK-xxx.md` (committed).' },
        { id: 'l3', x: col(4), y: 80, t1: 'S3 implement', t2: 'task owners', squad: 'S3', step: 'Each task’s owning dev agent implements it; one commit per task.' },
        { id: 'l4', x: col(5), y: 80, t1: 'S4 tests', t2: 'unit-test', squad: 'S4', step: 'Unit Test writes and runs tests for the changed files.' },
        { id: 'l7', x: col(6), y: 80, t1: 'S7 review', t2: 'reflector · correctness', squad: 'S7', step: 'Reflector and Correctness Reviewer; high or critical findings block. State is kept in `run.json`; status ends `ready-to-submit`.' },
        { id: 'push', x: col(7), y: 80, t1: 'git push', t2: 'your credentials', human: true, step: 'You push the branch yourself; local mode never pushes.' },
        { id: 'submit', x: col(8), y: 80, t1: 'local submit', t2: 'POST /verify-branch', step: '`aidlc local submit --project P --repo R` asks the platform to verify the pushed branch.' },
        { id: 'api', x: col(8), y: 256, t1: 'Control plane', t2: 'contributor role', step: '`POST /api/v1/verify-branch` (contributor role) starts a `verify_branch` run.' },
        { id: 'verify', x: col(7) - 40, y: 256, w: 210, t1: 'VerifyBranchWorkflow', t2: 'S2 → S4 → S5 → S6 → S7', squad: 'S6', step: 'VerifyBranchWorkflow profiles the repo, runs its tests, the S5 scanners on the diff, validation (spec conformance when a requirement is supplied) and the review panel, in the platform sandbox.' },
        { id: 'gates', x: col(5) + 20, y: 256, kind: 'gate', t1: '✓', t2: 'aidlc/gates', step: 'The platform posts the `aidlc/gates` commit status: success, or failure with the issue count.' },
        { id: 'merge', x: col(3) + 40, y: 256, kind: 'pill', t1: 'merge allowed', tone: 'ok', human: true, step: 'Branch protection requires `aidlc/gates`, so only a platform-verified branch can merge (repos created by onboarding get this rule automatically).' },
      ],
      edges: [
        { from: 'export', to: 'l1' }, { from: 'l1', to: 'l2' }, { from: 'l2', to: 'l3' }, { from: 'l3', to: 'l4' }, { from: 'l4', to: 'l7' },
        { from: 'l7', to: 'push' }, { from: 'push', to: 'submit' }, { from: 'submit', to: 'api' },
        { from: 'api', to: 'verify' }, { from: 'verify', to: 'gates' }, { from: 'gates', to: 'merge' },
        { from: 'gates', to: 'l3', back: true, d: 'M708 222 C708 168 536 168 536 108', label: 'failure: fix locally, push, submit again', lx: 640, ly: 160 },
      ],
    },
  };
}

// ---------------------------------------------------------------- rendering

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const plain = (s) => String(s).replace(/`/g, '');

function geometry(node, def) {
  const kind = node.kind || 'box';
  if (kind === 'gate') return { kind, hw: 34, hh: 34 };
  if (kind === 'pill') return { kind, hw: 58, hh: 20 };
  return { kind, hw: (node.w || def.nodeW || 132) / 2, hh: (node.h || 56) / 2 };
}

function route(edge, nodes, def) {
  if (edge.d) return edge.d;
  const a = nodes[edge.from];
  const b = nodes[edge.to];
  const ga = geometry(a, def);
  const gb = geometry(b, def);
  if (a.y === b.y) {
    const dir = b.x > a.x ? 1 : -1;
    return `M${a.x + dir * ga.hw} ${a.y} H${b.x - dir * gb.hw}`;
  }
  if (a.x === b.x) {
    const dir = b.y > a.y ? 1 : -1;
    return `M${a.x} ${a.y + dir * ga.hh} V${b.y - dir * gb.hh}`;
  }
  throw new Error(`diagram ${def.id}: edge ${edge.from}→${edge.to} needs an explicit d`);
}

const PERSON = (x, y) => `<g class="person" transform="translate(${x} ${y})" aria-hidden="true"><circle r="10"/><circle cx="0" cy="-3" r="3.2" class="pg"/><path d="M-5.5 6.5a5.5 5 0 0 1 11 0" class="pg"/></g>`;

function renderNode(node, def) {
  const g = geometry(node, def);
  const cls = ['fn', g.kind, node.squad ? 'squad' : '', node.human ? 'human' : '', node.tone ? `tone-${node.tone}` : ''].filter(Boolean).join(' ');
  const label = `${plain(node.t1)}${node.t2 ? ` (${plain(node.t2)})` : ''}. ${plain(node.step)}${node.squad ? ` Press Enter to list the ${node.squad} agents.` : ''}`;
  const attrs = `class="${cls}" data-node="${node.id}"${node.squad ? ` data-squad="${node.squad}"` : ''} tabindex="0" role="button" aria-label="${esc(label)}"`;
  let shape;
  let text;
  if (g.kind === 'gate') {
    shape = `<polygon points="${node.x},${node.y - g.hh} ${node.x + g.hw},${node.y} ${node.x},${node.y + g.hh} ${node.x - g.hw},${node.y}"/>`;
    const sub = node.labelPos === 'right'
      ? `<text class="t2 side" x="${node.x + 10}" y="${node.y + g.hh + 14}">${esc(node.t2)}</text>`
      : `<text class="t2 below" x="${node.x}" y="${node.y + g.hh + 16}">${esc(node.t2)}</text>`;
    text = `<text class="t1" x="${node.x}" y="${node.y + 5}">${esc(node.t1)}</text>${node.t2 ? sub : ''}`;
  } else if (g.kind === 'pill') {
    shape = `<rect x="${node.x - g.hw}" y="${node.y - g.hh}" width="${g.hw * 2}" height="${g.hh * 2}" rx="${g.hh}"/>`;
    text = `<text class="t1" x="${node.x}" y="${node.y + 4.5}">${esc(node.t1)}</text>`;
  } else {
    shape = `<rect x="${node.x - g.hw}" y="${node.y - g.hh}" width="${g.hw * 2}" height="${g.hh * 2}" rx="10"/>`;
    if (node.lanes) {
      const bars = node.lanes.map((lane, i) => {
        const y = node.y - 8 + i * 14;
        return `<rect class="lanebar-bg" x="${node.x - g.hw + 40}" y="${y - 4}" width="${g.hw * 2 - 54}" height="8" rx="4"/><rect class="lanebar l${i}" x="${node.x - g.hw + 40}" y="${y - 4}" width="${g.hw * 2 - 54}" height="8" rx="4"/><text class="t3" x="${node.x - g.hw + 12}" y="${y + 3.5}">${esc(lane)}</text>`;
      }).join('');
      text = `<text class="t1" x="${node.x}" y="${node.y - g.hh + 20}">${esc(node.t1)}</text>${bars}`;
    } else if (g.hh * 2 > 120) {
      text = `<text class="t1" x="${node.x}" y="${node.y - 6}">${esc(node.t1)}</text><text class="t2" x="${node.x}" y="${node.y + 12}">${esc(node.t2)}</text>`;
    } else {
      text = node.t2
        ? `<text class="t1" x="${node.x}" y="${node.y - 3}">${esc(node.t1)}</text><text class="t2" x="${node.x}" y="${node.y + 14}">${esc(node.t2)}</text>`
        : `<text class="t1" x="${node.x}" y="${node.y + 5}">${esc(node.t1)}</text>`;
    }
  }
  const person = node.human ? PERSON(node.x + g.hw - (g.kind === 'gate' ? 14 : 4), node.y - g.hh + (g.kind === 'gate' ? 14 : 4)) : '';
  return `<g ${attrs}>${shape}${text}${person}</g>`;
}

export function renderDiagram(id, def, md) {
  const nodes = Object.fromEntries(def.nodes.map((n) => [n.id, n]));
  const seqIds = def.seq.split(/\s+/).flatMap((s) => s.split('+'));
  for (const n of seqIds) if (!nodes[n]) throw new Error(`diagram ${id}: seq names unknown node ${n}`);
  const P = `flow-${id}`;
  const lanes = (def.lanesBg || []).map((l) => `<rect class="lane" x="${l.x}" y="${l.y}" width="${l.w}" height="${l.h}" rx="14"/><text class="lane-label" x="${l.x + 14}" y="${l.y + 18}">${esc(l.label)}</text>`).join('');
  const edges = def.edges.map((e) => {
    const d = route(e, nodes, { ...def, id });
    const cls = e.back ? 'fe back' : 'fe';
    const path = `<path class="${cls}" d="${d}" data-from="${e.from}" data-to="${e.to}" marker-end="url(#${P}-arrow)"/>`;
    const label = e.label ? `<text class="fe-label" x="${e.lx}" y="${e.ly}">${esc(e.label)}</text>` : '';
    return path + label;
  }).join('');
  const marker = (suffix, cls) => `<marker id="${P}-arrow${suffix}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path class="${cls}" d="M0 0 L10 5 L0 10 z"/></marker>`;
  const svg = `<svg class="flow-svg" viewBox="0 0 ${def.width} ${def.height}" role="group" aria-labelledby="${P}-title" aria-describedby="${P}-desc">
<title id="${P}-title">${esc(def.title)}</title>
<desc id="${P}-desc">${esc(def.desc)}</desc>
<defs>${marker('', 'ah')}${marker('-on', 'ah on')}${marker('-done', 'ah done')}</defs>
<g class="lanes">${lanes}</g>
<g class="edges">${edges}</g>
<g class="nodes">${def.nodes.map((n) => renderNode(n, def)).join('')}</g>
<g class="pulses"></g>
</svg>`;
  const seen = new Set();
  const ordered = [...seqIds, ...def.nodes.map((n) => n.id)].filter((n) => (seen.has(n) ? false : seen.add(n)));
  const loopIds = new Set(def.fail ? [...def.fail.loop.split(' '), def.fail.end] : []);
  const steps = ordered.map((n) => {
    const node = nodes[n];
    const label = node.label || node.t1;
    const head = plain(node.step).toLowerCase().startsWith(label.toLowerCase()) ? '' : `<b>${esc(label)}</b> · `;
    return `<li data-node="${n}"${!seqIds.includes(n) && loopIds.has(n) ? ' class="loop-only"' : ''}>${head}${md(node.step)}</li>`;
  }).join('');
  const fail = def.fail
    ? ` data-fail-after="${def.fail.after}" data-fail-loop="${def.fail.loop}" data-fail-max="${def.fail.max}" data-fail-end="${def.fail.end}" data-counter="${def.fail.counter}"`
    : '';
  const failControls = def.fail
    ? `<label class="switch"><input type="checkbox" data-act="fail"><span class="sw-track" aria-hidden="true"></span><span>Simulate failure</span></label><span class="iter" data-iter aria-live="polite">Fix-loop iteration <b>0</b> / ${def.fail.max}</span>`
    : '';
  return `<figure class="flow" id="${P}" data-flow="${id}" data-seq="${def.seq}"${fail} data-arrow="${P}-arrow">
<div class="flow-bar" role="toolbar" aria-label="${esc(def.title)} controls">
<button type="button" class="btn sm" data-act="play" aria-pressed="false"><span class="ico-play" aria-hidden="true"></span><span class="lbl">Play</span></button>
<button type="button" class="btn sm secondary" data-act="step">Step</button>
<button type="button" class="btn sm secondary" data-act="replay">Replay</button>
${failControls}
<span class="grow"></span><span class="flow-hint">Click or press Enter on a squad to see its agents</span>
</div>
<div class="flow-canvas" tabindex="-1">${svg}</div>
<p class="flow-status" data-status aria-live="polite">Press Play to animate, or Step through it.</p>
<details class="flow-text" open><summary>Text steps (${ordered.length})</summary><ol class="flow-steps">${steps}</ol></details>
</figure>`;
}
