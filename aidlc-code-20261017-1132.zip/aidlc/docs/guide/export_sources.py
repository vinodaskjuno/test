"""Export the guide's Python-side sources of truth as one JSON document on stdout (used by ``build.mjs``).

Everything that only Python can read faithfully comes from here: the agent registry (``agents/**``), CLI help
(``aidlc.cli.main.build_parser``), MCP tool schemas (``aidlc.mcp_server``), gates and config models, settings,
contract literals, endpoint roles (from the routers' RBAC calls) and the sample-spec ``expected.yaml`` files.
Output is deterministic: no timestamps, stable ordering, a fixed help width.

    python docs/guide/export_sources.py > /tmp/sources.json
"""

from __future__ import annotations

import argparse
import ast
import asyncio
import inspect
import json
import os
import re
import sys
import textwrap
import typing
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
SPECS = ROOT / "evals" / "specs"
INPUT_KEYS = {
    "work_item", "sources", "requirement", "answers", "repo_profile", "analysis", "architecture", "openapi", "plan",
    "tasks", "task", "fix_ticket", "diff", "changed_files", "test_report", "findings", "verdicts", "lessons",
    "manifest", "gates_config", "conventions", "pr_comments", "ci_logs", "run_summary", "metrics", "eval_results",
    "mode",
}  # fmt: skip
RBAC_CALLS = {"require_project", "require_run", "_open_item", "require_any_team_role"}


def _section(markdown: str, heading: str) -> str:
    match = re.search(rf"^## {re.escape(heading)}\s*\n(.*?)(?=^## |\Z)", markdown, re.S | re.M)
    return match.group(1).strip() if match else ""


def _first_paragraph(text: str) -> str:
    return " ".join(text.strip().split("\n\n", 1)[0].split())


def agents() -> tuple[list[dict[str, Any]], dict[str, str], list[dict[str, Any]]]:
    from aidlc.names import SQUADS
    from aidlc.platform.registry import Registry

    registry = Registry(ROOT / "agents")
    orchestrator = "\n".join(
        f.read_text(encoding="utf-8") for f in sorted((ROOT / "src" / "aidlc" / "orchestrator").rglob("*.py"))
    )
    rows = []
    for spec in registry.all():
        inputs_md = _section(spec.prompt, "Inputs you receive")
        keys = sorted({k for k in re.findall(r"`([a-z_]+)`", inputs_md) if k in INPUT_KEYS})
        model = spec.output_model
        base = next((c.__name__ for c in model.__mro__[1:] if c.__module__ == "aidlc.agent_outputs"), model.__name__)
        rows.append(
            {
                "id": spec.id,
                "number": spec.number,
                "name": spec.name,
                "squad": spec.squad,
                "squad_name": SQUADS[spec.squad],
                "version": spec.version,
                "model": spec.model,
                "effort": spec.effort,
                "description": spec.description,
                "tools": spec.tools,
                "mcp_servers": spec.mcp_servers,
                "reads_untrusted": spec.reads_untrusted,
                "mutates": spec.mutates,
                "max_turns": spec.max_turns,
                "budget_usd": spec.budget_usd,
                "timeout_s": spec.timeout_s,
                "workflows": spec.workflows,
                "role": _first_paragraph(_section(spec.prompt, "Role")),
                "inputs": keys,
                "output_class": base,
                "output_fields": list(model.model_fields),
                "path": spec.path.relative_to(ROOT).as_posix() if spec.path else "",
                "invoked": f'"{spec.id}"' in orchestrator,
            }
        )
    ethos = []
    for match in re.finditer(r"^## (\d+)\. (.+?)\n(.*?)(?=^## |\Z)", registry.ethos, re.S | re.M):
        first = re.search(r"^- (.+?)(?=^- |\Z)", match.group(3), re.S | re.M)
        ethos.append(
            {"n": int(match.group(1)), "title": match.group(2).strip(), "point": " ".join(first.group(1).split())}
        )
    return rows, dict(SQUADS), ethos


def cli() -> dict[str, Any]:
    from aidlc.cli import main as cli_main

    # argparse wraps help at the terminal width; pin it so the generated guide does not depend on the shell.
    os.environ["COLUMNS"] = "88"
    parser = cli_main.build_parser()

    def sub_parsers(p: argparse.ArgumentParser) -> list[tuple[str, str, argparse.ArgumentParser]]:
        action = next(a for a in p._actions if isinstance(a, argparse._SubParsersAction))
        helps = {c.dest: c.help or "" for c in action._choices_actions}
        return [(name, helps.get(name, ""), sp) for name, sp in action.choices.items()]

    commands = []
    for name, help_text, sp in sub_parsers(parser):
        entry: dict[str, Any] = {"name": name, "help": help_text, "usage": sp.format_help().rstrip()}
        if name == "local":
            entry["actions"] = [
                {"name": n, "help": h, "usage": a.format_help().rstrip()} for n, h, a in sub_parsers(sp)
            ]
        commands.append(entry)
    from aidlc.names import EXIT_CODES

    return {
        "main": parser.format_help().rstrip(),
        "commands": commands,
        "exit_codes": EXIT_CODES,
        "exit_error": cli_main.ERROR,
        "exit_interrupted": cli_main.INTERRUPTED,
    }


def mcp() -> dict[str, Any]:
    from aidlc.mcp_server import server as mcp_server
    from aidlc.mcp_server.knowledge import build_knowledge_server

    async def tools(srv: Any) -> list[dict[str, Any]]:
        out = []
        for tool in await srv.list_tools():
            schema = tool.input_schema or {}
            required = set(schema.get("required", []))
            params = []
            for pname, prop in (schema.get("properties") or {}).items():
                if "enum" in prop:
                    kind = " | ".join(json.dumps(v) for v in prop["enum"])
                elif "anyOf" in prop:
                    kind = " | ".join(
                        f"{p.get('type')}[{p['items'].get('type')}]" if p.get("type") == "array" else str(p.get("type"))
                        for p in prop["anyOf"]
                    )
                elif prop.get("type") == "array":
                    kind = f"array[{prop.get('items', {}).get('type')}]"
                else:
                    kind = str(prop.get("type"))
                params.append(
                    {"name": pname, "type": kind, "required": pname in required, "default": prop.get("default")}
                )
            ann = tool.annotations
            out.append(
                {
                    "name": tool.name,
                    "description": inspect.cleandoc(tool.description or ""),
                    "params": params,
                    "read_only": bool(ann and ann.read_only_hint),
                }
            )
        return out

    api_tools = asyncio.run(tools(mcp_server.build_server("http://localhost:8000")))
    knowledge_tools = asyncio.run(tools(build_knowledge_server()))
    return {
        "tools": api_tools,
        "knowledge_tools": knowledge_tools,
        "instructions": mcp_server.INSTRUCTIONS,
        "default_port": mcp_server.DEFAULT_PORT,
        "path": mcp_server.MCP_PATH,
        "max_spec_bytes": mcp_server.MAX_SPEC_BYTES,
        "servers_json": (ROOT / "mcp" / "servers.json").read_text(encoding="utf-8"),
    }


def _type_name(annotation: Any) -> str:
    origin = typing.get_origin(annotation)
    if origin is typing.Literal:
        return " | ".join(str(a) for a in typing.get_args(annotation))
    if origin in (list, tuple):
        return f"list[{', '.join(_type_name(a) for a in typing.get_args(annotation))}]"
    if origin is dict:
        return f"dict[{', '.join(_type_name(a) for a in typing.get_args(annotation))}]"
    if origin in (typing.Union, getattr(__import__("types"), "UnionType", None)):
        return " | ".join(_type_name(a) for a in typing.get_args(annotation))
    if annotation is type(None):
        return "null"
    return getattr(annotation, "__name__", str(annotation))


def _fields(model: Any) -> list[dict[str, Any]]:
    rows = []
    for name, field in model.model_fields.items():
        default = field.get_default(call_default_factory=True) if not field.is_required() else None
        if hasattr(default, "model_dump"):
            default = default.model_dump()
        constraints = [str(m) for m in field.metadata]
        rows.append(
            {
                "name": name,
                "type": _type_name(field.annotation),
                "required": field.is_required(),
                "default": json.loads(json.dumps(default, default=str)),
                "constraints": constraints,
            }
        )
    return rows


def config_and_gates() -> dict[str, Any]:
    from aidlc.contracts import Budgets, ProjectConfig, RepoRef
    from aidlc.orchestrator.models import LoopLimits
    from aidlc.platform.gates import GatesConfig

    return {
        "gates_default": (ROOT / "presets" / "gates.default.yaml").read_text(encoding="utf-8"),
        "gates_template": (ROOT / "templates" / "gates.yaml").read_text(encoding="utf-8"),
        "gates_fields": _fields(GatesConfig),
        "config_template": (ROOT / "templates" / "config.yml").read_text(encoding="utf-8"),
        "project_config_fields": _fields(ProjectConfig),
        "repo_fields": _fields(RepoRef),
        "budget_fields": _fields(Budgets),
        "loop_limits": LoopLimits().model_dump(),
        "presets": sorted(p.stem for p in (ROOT / "presets").glob("*.yml")),
    }


def settings() -> dict[str, Any]:
    from aidlc.settings import Settings

    rows = []
    for name, field in Settings.model_fields.items():
        default = field.get_default(call_default_factory=True)
        if isinstance(default, Path):
            try:
                default = "<repo>/" + default.relative_to(ROOT).as_posix()
            except ValueError:
                default = str(default)
        elif isinstance(default, str) and str(ROOT) in default:
            default = default.replace(str(ROOT), "<repo>")
        rows.append({"env": f"AIDLC_{name.upper()}", "type": _type_name(field.annotation), "default": default})
    return {"fields": rows, "env_example": (ROOT / "infra" / ".env.example").read_text(encoding="utf-8")}


def literals() -> dict[str, Any]:
    from aidlc import contracts, names
    from aidlc.api import convert, schemas
    from aidlc.api.routers import specs as specs_router
    from aidlc.platform import events, notifications
    from aidlc.platform.tenancy import ROLE_ORDER

    def args(t: Any) -> list[str]:
        return list(typing.get_args(t))

    return {
        "outcomes": args(contracts.Outcome),
        "run_kinds": args(contracts.RunKind),
        "event_types": args(contracts.EventType),
        "escalation_reasons": args(contracts.EscalationReason),
        "escalation_decisions": args(schemas.EscalationDecision),
        "gate_names": args(contracts.GateName),
        "severities": args(contracts.Severity),
        "source_kinds": args(contracts.SourceKind),
        "models": args(contracts.ModelId),
        "efforts": args(contracts.Effort),
        "roles": sorted(ROLE_ORDER, key=ROLE_ORDER.__getitem__),
        "webhook_events": list(events.WEBHOOK_EVENTS),
        "webhook_max_attempts": events.MAX_ATTEMPTS,
        "notify_kinds": list(notifications.EVENT_KINDS),
        "workflows": names.WORKFLOW_BY_KIND,
        "task_queue": names.TASK_QUEUE,
        "signals": {
            "answer": names.SIG_ANSWER,
            "escalation": names.SIG_ESCALATION,
            "pr_event": names.SIG_PR_EVENT,
            "cancel": names.SIG_CANCEL,
        },
        "upload_ext": {ext: kind for ext, (kind, _) in sorted(convert.ALLOWED.items())},
        "upload_max_files": specs_router.MAX_FILES,
    }


def _route_role(fn: Any) -> str | None:
    try:
        tree = ast.parse(textwrap.dedent(inspect.getsource(fn)))
    except (OSError, TypeError):
        return None
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = getattr(node.func, "id", getattr(node.func, "attr", ""))
            if name == "require_admin":
                return "admin (org)"
            if name in RBAC_CALLS:
                literal = [a.value for a in node.args if isinstance(a, ast.Constant) and isinstance(a.value, str)]
                if literal:
                    return literal[-1] + (" (any team)" if name == "require_any_team_role" else "")
        if isinstance(node, ast.Subscript) and getattr(node.value, "id", "") == "RANK":
            key = node.slice
            if isinstance(key, ast.Constant):
                return f"{key.value} (team)"
    return None


def routes() -> dict[str, str]:
    from fastapi.routing import APIRoute

    from aidlc.api.routers import (
        admin,
        agents,
        config,
        hooks,
        inbox,
        projects,
        runs,
        schedules,
        session,
        spec_templates,
        specs,
        work,
    )

    public = {"GET /healthz", "GET /metrics", "GET /api/v1/config"}
    roles: dict[str, str] = dict.fromkeys(public, "public")
    modules = (session, config, projects, specs, spec_templates, runs, inbox, work, schedules, agents, admin, hooks)
    for route in (r for m in modules for r in m.router.routes):
        if not isinstance(route, APIRoute):
            continue
        role = _route_role(route.endpoint)
        if role is None:
            role = "HMAC signature" if route.path.startswith("/api/v1/hooks/") else "signed in"
        for method in sorted(route.methods):
            key = f"{method} {route.path.replace(':path}', '}')}"
            roles[key] = "public" if key in public else role
    return dict(sorted(roles.items()))


def specs() -> list[dict[str, Any]]:
    entries = []
    for expected_path in sorted(SPECS.rglob("*.yaml")):
        if not (expected_path.name == "expected.yaml" or expected_path.name.endswith(".expected.yaml")):
            continue
        data = yaml.safe_load(expected_path.read_text(encoding="utf-8"))
        base = expected_path.parent
        entries.append(
            {
                "expected_path": expected_path.relative_to(SPECS).as_posix(),
                "base": base.relative_to(SPECS).as_posix(),
                "data": json.loads(json.dumps(data, default=str)),
                "spec_paths": [(base / f).relative_to(SPECS).as_posix() for f in data.get("spec_files", [])],
                "attachment_paths": [
                    a if a.startswith("http") else (base / a).relative_to(SPECS).as_posix()
                    for a in data.get("attachments", [])
                ],
            }
        )
    return entries


def main() -> None:
    sys.path.insert(0, str(ROOT))
    try:
        import aidlc_sdk  # noqa: F401  (the CLI and MCP server import it)
    except ImportError:  # not installed (e.g. `pip install -e .` only): use the in-repo SDK sources
        sys.path.insert(0, str(ROOT / "clients" / "sdk-py" / "src"))
    agent_rows, squads, ethos = agents()
    doc = {
        "agents": agent_rows,
        "squads": squads,
        "ethos": ethos,
        "cli": cli(),
        "mcp": mcp(),
        "config": config_and_gates(),
        "settings": settings(),
        "literals": literals(),
        "routes": routes(),
        "specs": specs(),
    }
    json.dump(doc, sys.stdout, indent=1, sort_keys=True, ensure_ascii=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
