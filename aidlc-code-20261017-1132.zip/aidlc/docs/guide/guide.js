/* AIDLC project guide behaviour (vanilla, no dependencies, CSP-safe: no inline code, no style attributes).
 * Theme toggle, scroll-spy nav, ⌘K section search, copy buttons, agent catalog filters, squad drawer and the
 * flowchart engine (Play / Pause / Step / Replay, Simulate failure with the LoopGuard escalation). */
(function () {
  'use strict';

  var doc = document;
  var root = doc.documentElement;
  var reduceMotion = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  var live = doc.getElementById('live');

  root.classList.add('js');

  function announce(text) {
    if (!live) return;
    live.textContent = '';
    window.setTimeout(function () { live.textContent = text; }, 30);
  }

  function $all(sel, scope) {
    return Array.prototype.slice.call((scope || doc).querySelectorAll(sel));
  }

  // ------------------------------------------------------------------ theme (same key as the control-plane UI)
  var THEME_KEY = 'aidlc.theme';
  var darkQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function storedTheme() {
    try {
      var v = window.localStorage.getItem(THEME_KEY);
      return v === 'light' || v === 'dark' || v === 'system' ? v : 'system';
    } catch (e) {
      return 'system';
    }
  }

  function applyTheme(pref) {
    var dark = pref === 'dark' || (pref === 'system' && darkQuery && darkQuery.matches);
    root.setAttribute('data-theme', dark ? 'dark' : 'light');
    root.setAttribute('data-theme-pref', pref);
    $all('[data-theme-choice]').forEach(function (b) {
      var on = b.getAttribute('data-theme-choice') === pref;
      b.setAttribute('aria-checked', on ? 'true' : 'false');
      b.tabIndex = on ? 0 : -1;
    });
  }

  function setTheme(pref) {
    try {
      window.localStorage.setItem(THEME_KEY, pref);
    } catch (e) {
      /* storage disabled: the theme still applies to this page */
    }
    applyTheme(pref);
  }

  applyTheme(storedTheme());
  if (darkQuery && darkQuery.addEventListener) {
    darkQuery.addEventListener('change', function () {
      if (storedTheme() === 'system') applyTheme('system');
    });
  }
  var themeButtons = $all('[data-theme-choice]');
  themeButtons.forEach(function (b, i) {
    b.addEventListener('click', function () { setTheme(b.getAttribute('data-theme-choice')); });
    b.addEventListener('keydown', function (e) {
      var d = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
      if (!d) return;
      e.preventDefault();
      var next = themeButtons[(i + d + themeButtons.length) % themeButtons.length];
      setTheme(next.getAttribute('data-theme-choice'));
      next.focus();
    });
  });

  // ------------------------------------------------------------------ heading anchors
  $all('.gsec h3[id]').forEach(function (h) {
    var a = doc.createElement('a');
    a.className = 'anchor';
    a.href = '#' + h.id;
    a.setAttribute('aria-label', 'Link to ' + h.textContent.trim());
    a.textContent = '#';
    h.appendChild(a);
  });

  // ------------------------------------------------------------------ mobile nav
  var nav = doc.getElementById('guide-nav');
  var menu = doc.getElementById('menu-toggle');
  var scrim = doc.getElementById('nav-scrim');

  function setNav(open) {
    if (!nav || !menu) return;
    nav.classList.toggle('open', open);
    menu.setAttribute('aria-expanded', open ? 'true' : 'false');
    menu.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    if (scrim) scrim.hidden = !open;
  }
  if (menu) menu.addEventListener('click', function () { setNav(!nav.classList.contains('open')); });
  if (scrim) scrim.addEventListener('click', function () { setNav(false); });
  if (nav) {
    nav.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('a')) setNav(false);
    });
  }

  // ------------------------------------------------------------------ scroll-spy
  var secLinks = {};
  var subLinks = {};
  $all('.nav a.sec-link').forEach(function (a) { secLinks[a.getAttribute('data-sec')] = a; });
  $all('.nav a.sub-link').forEach(function (a) { subLinks[a.getAttribute('data-sub')] = a; });
  var subnavs = $all('.nav .subnav');
  var spyTargets = $all('section.gsec, .gsec h3[id]');
  var currentSec = null;
  var currentSub = null;

  function markNav(secId, subId) {
    if (secId !== currentSec) {
      Object.keys(secLinks).forEach(function (k) {
        if (k === secId) secLinks[k].setAttribute('aria-current', 'true');
        else secLinks[k].removeAttribute('aria-current');
      });
      subnavs.forEach(function (s) { s.classList.toggle('open', s.getAttribute('data-sec') === secId); });
      currentSec = secId;
    }
    if (subId !== currentSub) {
      Object.keys(subLinks).forEach(function (k) {
        if (k === subId) subLinks[k].setAttribute('aria-current', 'true');
        else subLinks[k].removeAttribute('aria-current');
      });
      currentSub = subId;
    }
  }

  function spy() {
    var line = 110;
    var sec = null;
    var sub = null;
    for (var i = 0; i < spyTargets.length; i++) {
      var el = spyTargets[i];
      if (el.getBoundingClientRect().top - line > 0) break;
      if (el.tagName === 'SECTION') { sec = el.id; sub = null; } else { sub = el.id; }
    }
    if (!sec && spyTargets.length) sec = spyTargets[0].id;
    markNav(sec, sub);
  }
  var spyQueued = false;
  window.addEventListener('scroll', function () {
    if (spyQueued) return;
    spyQueued = true;
    window.requestAnimationFrame(function () { spyQueued = false; spy(); });
  }, { passive: true });
  // Web fonts change line wrapping on this long page: once they are in, land on the linked heading again.
  if (doc.fonts && doc.fonts.ready) {
    doc.fonts.ready.then(function () {
      var target = window.location.hash ? doc.getElementById(window.location.hash.slice(1)) : null;
      if (target) target.scrollIntoView();
      spy();
    });
  }
  window.addEventListener('load', spy);
  window.addEventListener('resize', spy);
  window.addEventListener('hashchange', function () { window.setTimeout(spy, 60); });
  spy();

  // ------------------------------------------------------------------ copy buttons
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    return new Promise(function (resolve, reject) {
      var ta = doc.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.className = 'sr-only';
      doc.body.appendChild(ta);
      ta.select();
      try {
        var ok = doc.execCommand('copy');
        doc.body.removeChild(ta);
        if (ok) resolve(); else reject(new Error('copy failed'));
      } catch (err) {
        doc.body.removeChild(ta);
        reject(err);
      }
    });
  }
  $all('.codebox').forEach(function (box) {
    var pre = box.querySelector('pre');
    if (!pre) return;
    var btn = doc.createElement('button');
    btn.type = 'button';
    btn.className = 'copy';
    btn.textContent = 'Copy';
    btn.setAttribute('aria-label', 'Copy code to the clipboard');
    btn.addEventListener('click', function () {
      copyText(pre.innerText.replace(/\n$/, '')).then(function () {
        btn.textContent = 'Copied';
        btn.classList.add('done');
        announce('Copied to the clipboard');
        window.setTimeout(function () { btn.textContent = 'Copy'; btn.classList.remove('done'); }, 1600);
      }, function () {
        btn.textContent = 'Select and copy';
        announce('Copy failed; select the text and copy it');
      });
    });
    box.appendChild(btn);
  });

  // ------------------------------------------------------------------ agent catalog filters
  var q = doc.getElementById('agent-q');
  var squadSel = doc.getElementById('agent-squad');
  var modelSel = doc.getElementById('agent-model');
  var count = doc.getElementById('agent-count');
  var empty = doc.getElementById('agent-empty');
  var cards = $all('#agent-grid .agent');

  function filterAgents() {
    var words = (q ? q.value : '').toLowerCase().split(/\s+/).filter(Boolean);
    var squad = squadSel ? squadSel.value : '';
    var model = modelSel ? modelSel.value : '';
    var shown = 0;
    cards.forEach(function (c) {
      var text = c.getAttribute('data-text') || '';
      var ok = (!squad || c.getAttribute('data-squad') === squad) && (!model || c.getAttribute('data-model') === model) &&
        words.every(function (w) { return text.indexOf(w) !== -1; });
      c.hidden = !ok;
      if (ok) shown += 1;
    });
    if (count) count.textContent = shown + ' of ' + cards.length + ' agents';
    if (empty) empty.hidden = shown !== 0;
  }
  [q, squadSel, modelSel].forEach(function (el) { if (el) el.addEventListener('input', filterAgents); });
  $all('[data-squad-link]').forEach(function (a) {
    a.addEventListener('click', function () {
      if (!squadSel) return;
      squadSel.value = a.getAttribute('data-squad-link');
      if (q) q.value = '';
      if (modelSel) modelSel.value = '';
      filterAgents();
    });
  });

  function revealAgent(hash) {
    var target = hash && hash.indexOf('#agent-') === 0 ? doc.getElementById(hash.slice(1)) : null;
    if (target && target.hidden) {
      if (q) q.value = '';
      if (squadSel) squadSel.value = '';
      if (modelSel) modelSel.value = '';
      filterAgents();
    }
    if (target) {
      var det = target.querySelector('details');
      if (det) det.open = true;
    }
  }
  window.addEventListener('hashchange', function () { revealAgent(window.location.hash); });
  revealAgent(window.location.hash);

  // ------------------------------------------------------------------ ⌘K palette
  var overlay = doc.getElementById('palette');
  var pin = doc.getElementById('palette-input');
  var list = doc.getElementById('palette-list');
  var none = doc.getElementById('palette-none');
  var openBtn = doc.getElementById('open-palette');
  var options = list ? $all('li[role="option"]', list) : [];
  var visible = [];
  var active = -1;
  var returnFocus = null;
  var MAX_RESULTS = 60;

  function setActive(i) {
    if (active >= 0 && visible[active]) visible[active].setAttribute('aria-selected', 'false');
    active = visible.length ? (i + visible.length) % visible.length : -1;
    if (active >= 0) {
      visible[active].setAttribute('aria-selected', 'true');
      pin.setAttribute('aria-activedescendant', visible[active].id);
      visible[active].scrollIntoView({ block: 'nearest' });
    } else {
      pin.removeAttribute('aria-activedescendant');
    }
  }

  function filterPalette() {
    var words = pin.value.toLowerCase().split(/\s+/).filter(Boolean);
    visible = [];
    options.forEach(function (o) {
      o.setAttribute('aria-selected', 'false');
      var text = o.getAttribute('data-text');
      var match = words.every(function (w) { return text.indexOf(w) !== -1; });
      var show = match && (words.length > 0 || o.getAttribute('data-group') === 'Sections') && visible.length < MAX_RESULTS;
      o.hidden = !show;
      if (show) visible.push(o);
    });
    none.hidden = visible.length > 0;
    active = -1;
    setActive(0);
  }

  function openPalette() {
    if (!overlay) return;
    returnFocus = doc.activeElement;
    overlay.hidden = false;
    pin.value = '';
    filterPalette();
    pin.focus();
  }

  function closePalette() {
    if (!overlay || overlay.hidden) return;
    overlay.hidden = true;
    if (returnFocus && returnFocus.focus) returnFocus.focus();
  }

  function go(option) {
    var href = option.getAttribute('data-href');
    closePalette();
    var target = doc.getElementById(href.slice(1));
    if (target) {
      if (window.location.hash === href) revealAgent(href);
      window.location.hash = href;
      target.setAttribute('tabindex', target.getAttribute('tabindex') || '-1');
      target.focus({ preventScroll: true });
    }
  }

  if (overlay) {
    openBtn.addEventListener('click', openPalette);
    pin.addEventListener('input', filterPalette);
    pin.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
      else if (e.key === 'Enter') { e.preventDefault(); if (visible[active]) go(visible[active]); }
      else if (e.key === 'Escape') { e.preventDefault(); closePalette(); }
      else if (e.key === 'Tab') { e.preventDefault(); }
    });
    list.addEventListener('click', function (e) {
      var li = e.target.closest ? e.target.closest('li[role="option"]') : null;
      if (li) go(li);
    });
    list.addEventListener('mousemove', function (e) {
      var li = e.target.closest ? e.target.closest('li[role="option"]') : null;
      var i = li ? visible.indexOf(li) : -1;
      if (i >= 0 && i !== active) setActive(i);
    });
    overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) closePalette(); });
  }

  doc.addEventListener('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
      e.preventDefault();
      if (overlay && overlay.hidden) openPalette(); else closePalette();
    } else if (e.key === 'Escape') {
      if (overlay && !overlay.hidden) closePalette();
      else if (drawer && !drawer.hidden) closeDrawer();
      else setNav(false);
    }
  });

  // ------------------------------------------------------------------ squad drawer
  var drawer = doc.getElementById('drawer');
  var drawerBody = doc.getElementById('drawer-body');
  var drawerTitle = doc.getElementById('drawer-title');
  var drawerClose = doc.getElementById('drawer-close');
  var drawerReturn = null;

  function openDrawer(squad, from) {
    var tpl = doc.getElementById('squad-' + squad);
    if (!tpl || !drawer) return;
    drawerReturn = from || doc.activeElement;
    drawerBody.textContent = '';
    drawerBody.appendChild(tpl.content.cloneNode(true));
    drawerTitle.textContent = tpl.getAttribute('data-title');
    drawer.hidden = false;
    drawerClose.focus();
    announce(tpl.getAttribute('data-title') + ' agents shown');
  }

  function closeDrawer() {
    if (!drawer || drawer.hidden) return;
    drawer.hidden = true;
    if (drawerReturn && drawerReturn.focus) drawerReturn.focus();
  }
  if (drawer) {
    drawerClose.addEventListener('click', closeDrawer);
    drawer.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('[data-close-drawer]')) {
        drawer.hidden = true;
      }
    });
  }

  // ------------------------------------------------------------------ flowcharts
  var STEP_MS = 1150;
  var PULSE_MS = 650;
  var SVG_NS = 'http://www.w3.org/2000/svg';

  function Flow(fig) {
    var self = this;
    this.fig = fig;
    this.svg = fig.querySelector('svg');
    this.pulses = fig.querySelector('.pulses');
    this.status = fig.querySelector('[data-status]');
    this.iterEl = fig.querySelector('[data-iter]');
    this.playBtn = fig.querySelector('[data-act="play"]');
    this.failBox = fig.querySelector('[data-act="fail"]');
    this.arrow = fig.getAttribute('data-arrow');
    this.nodes = {};
    $all('.fn', this.svg).forEach(function (g) { self.nodes[g.getAttribute('data-node')] = g; });
    this.edges = $all('.fe:not(.back)', this.svg);
    this.items = {};
    $all('.flow-steps li', fig).forEach(function (li) { self.items[li.getAttribute('data-node')] = li; });
    this.base = fig.getAttribute('data-seq').split(/\s+/).map(function (s) { return s.split('+'); });
    this.fail = fig.hasAttribute('data-fail-after') ? {
      after: fig.getAttribute('data-fail-after'),
      loop: fig.getAttribute('data-fail-loop').split(/\s+/),
      max: parseInt(fig.getAttribute('data-fail-max'), 10),
      end: fig.getAttribute('data-fail-end'),
      counter: fig.getAttribute('data-counter'),
    } : null;
    this.failing = false;
    this.timer = null;
    this.playing = false;
    this.seq = this.base;
    this.idx = -1;
    this.iteration = 0;
    this.visited = {};

    fig.querySelector('[data-act="step"]').addEventListener('click', function () { self.pause(); self.step(); });
    fig.querySelector('[data-act="replay"]').addEventListener('click', function () { self.reset(); self.play(); });
    this.playBtn.addEventListener('click', function () { if (self.playing) self.pause(); else self.play(); });
    if (this.failBox) {
      this.failBox.addEventListener('change', function () {
        self.failing = self.failBox.checked;
        self.reset();
        self.say(self.failing ? 'Failure simulation on: the quality gate keeps failing until LoopGuard escalates. Press Play.' : 'Failure simulation off. Press Play.');
      });
    }
    Object.keys(this.nodes).forEach(function (id) {
      var g = self.nodes[id];
      var open = function () {
        var squad = g.getAttribute('data-squad');
        self.pick(id);
        if (squad) openDrawer(squad, g);
      };
      g.addEventListener('click', open);
      g.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
      });
    });
  }

  Flow.prototype.sequence = function () {
    if (!this.failing || !this.fail) return this.base;
    var out = [];
    for (var i = 0; i < this.base.length; i++) {
      out.push(this.base[i]);
      if (this.base[i].indexOf(this.fail.after) !== -1) break;
    }
    for (var k = 1; k < this.fail.max; k++) {
      for (var j = 0; j < this.fail.loop.length; j++) out.push([this.fail.loop[j]]);
    }
    out.push([this.fail.end]);
    return out;
  };

  Flow.prototype.say = function (html) {
    if (this.status) this.status.textContent = html;
  };

  Flow.prototype.reset = function () {
    this.pause();
    this.seq = this.sequence();
    this.idx = -1;
    this.iteration = 0;
    this.visited = {};
    var nodes = this.nodes;
    Object.keys(nodes).forEach(function (id) { nodes[id].classList.remove('is-active', 'is-done', 'is-fail', 'is-picked'); });
    var arrow = this.arrow;
    this.edges.forEach(function (e) {
      e.classList.remove('is-on', 'is-done', 'is-fail');
      e.setAttribute('marker-end', 'url(#' + arrow + ')');
    });
    var items = this.items;
    Object.keys(items).forEach(function (k) { items[k].classList.remove('is-current', 'is-done'); });
    while (this.pulses.firstChild) this.pulses.removeChild(this.pulses.firstChild);
    this.updateIter();
    this.say('Press Play to animate, or Step through it.');
  };

  Flow.prototype.updateIter = function () {
    if (!this.iterEl) return;
    this.iterEl.querySelector('b').textContent = String(this.iteration);
    this.iterEl.classList.toggle('hot', this.failing && this.iteration > 0);
  };

  Flow.prototype.edgesInto = function (cur, prev) {
    var self = this;
    var into = this.edges.filter(function (e) {
      return cur.indexOf(e.getAttribute('data-to')) !== -1 && prev.indexOf(e.getAttribute('data-from')) !== -1;
    });
    if (into.length) return into;
    return this.edges.filter(function (e) {
      return cur.indexOf(e.getAttribute('data-to')) !== -1 && self.visited[e.getAttribute('data-from')];
    });
  };

  Flow.prototype.pulse = function (edge) {
    var pulses = this.pulses;
    var len = edge.getTotalLength();
    var ring = doc.createElementNS(SVG_NS, 'circle');
    ring.setAttribute('r', '10');
    ring.setAttribute('class', 'pulse-ring');
    var dot = doc.createElementNS(SVG_NS, 'circle');
    dot.setAttribute('r', '5.5');
    dot.setAttribute('class', 'pulse');
    pulses.appendChild(ring);
    pulses.appendChild(dot);
    var start = null;
    function frame(t) {
      if (start === null) start = t;
      var k = Math.min(1, (t - start) / PULSE_MS);
      var eased = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      var p = edge.getPointAtLength(eased * len);
      dot.setAttribute('cx', p.x.toFixed(1));
      dot.setAttribute('cy', p.y.toFixed(1));
      ring.setAttribute('cx', p.x.toFixed(1));
      ring.setAttribute('cy', p.y.toFixed(1));
      if (k < 1) window.requestAnimationFrame(frame);
      else { if (dot.parentNode) pulses.removeChild(dot); if (ring.parentNode) pulses.removeChild(ring); }
    }
    window.requestAnimationFrame(frame);
  };

  Flow.prototype.apply = function (i) {
    var self = this;
    var cur = this.seq[i];
    var prev = i > 0 ? this.seq[i - 1] : [];
    var arrow = this.arrow;
    var failingStep = this.failing && this.fail && cur.indexOf(this.fail.after) !== -1 && i < this.seq.length - 1;
    var escalated = this.failing && this.fail && cur.indexOf(this.fail.end) !== -1;

    this.edges.forEach(function (e) {
      if (e.classList.contains('is-on')) {
        e.classList.remove('is-on');
        e.classList.add('is-done');
        e.setAttribute('marker-end', 'url(#' + arrow + '-done)');
      }
    });
    prev.forEach(function (id) {
      var g = self.nodes[id];
      g.classList.remove('is-active');
      if (!g.classList.contains('is-fail')) g.classList.add('is-done');
    });
    this.edgesInto(cur, prev).forEach(function (e) {
      var fromFail = self.nodes[e.getAttribute('data-from')].classList.contains('is-fail');
      e.classList.remove('is-done');
      e.classList.add(fromFail ? 'is-fail' : 'is-on');
      e.setAttribute('marker-end', 'url(#' + arrow + '-on)');
      if (!reduceMotion.matches) self.pulse(e);
    });
    cur.forEach(function (id) {
      var g = self.nodes[id];
      g.classList.remove('is-done', 'is-fail');
      g.classList.add('is-active');
      self.visited[id] = true;
    });
    if (this.fail && cur.indexOf(this.fail.counter) !== -1) {
      this.iteration += 1;
      this.updateIter();
    }
    if (failingStep) {
      cur.forEach(function (id) { self.nodes[id].classList.add('is-fail'); });
    }
    Object.keys(this.items).forEach(function (k) { self.items[k].classList.remove('is-current'); });
    prev.forEach(function (id) { if (self.items[id]) self.items[id].classList.add('is-done'); });
    var first = this.items[cur[0]];
    cur.forEach(function (id) { if (self.items[id]) self.items[id].classList.add('is-current'); });
    var text = first ? first.textContent.trim() : cur.join(', ');
    if (failingStep) {
      text = 'Iteration ' + this.iteration + ' of ' + this.fail.max + ' failed the quality gate. ' + text;
    } else if (escalated) {
      text = 'Still failing after ' + this.fail.max + ' iterations. ' + text;
    } else if (this.fail && this.failing && cur.indexOf(this.fail.counter) !== -1) {
      text = 'Fix-loop iteration ' + this.iteration + '. ' + text;
    }
    this.say('Step ' + (i + 1) + ' of ' + this.seq.length + ': ' + text);
  };

  Flow.prototype.step = function () {
    if (this.idx >= this.seq.length - 1) {
      this.pause();
      return false;
    }
    this.idx += 1;
    this.apply(this.idx);
    if (this.idx >= this.seq.length - 1) {
      var last = this.seq[this.idx];
      var self = this;
      window.setTimeout(function () {
        if (self.idx === self.seq.length - 1 && !(self.failing && self.fail)) {
          last.forEach(function (id) { self.nodes[id].classList.remove('is-active'); self.nodes[id].classList.add('is-done'); });
        }
      }, PULSE_MS);
      this.pause();
    }
    return true;
  };

  Flow.prototype.play = function () {
    var self = this;
    if (this.idx >= this.seq.length - 1) this.reset();
    this.playing = true;
    this.playBtn.setAttribute('aria-pressed', 'true');
    this.playBtn.querySelector('.lbl').textContent = 'Pause';
    var tick = function () {
      if (!self.playing) return;
      if (self.step()) self.timer = window.setTimeout(tick, reduceMotion.matches ? STEP_MS + 500 : STEP_MS);
    };
    tick();
  };

  Flow.prototype.pause = function () {
    this.playing = false;
    if (this.timer) window.clearTimeout(this.timer);
    this.timer = null;
    if (this.playBtn) {
      this.playBtn.setAttribute('aria-pressed', 'false');
      this.playBtn.querySelector('.lbl').textContent = this.idx >= this.seq.length - 1 && this.idx >= 0 ? 'Play again' : 'Play';
    }
  };

  Flow.prototype.pick = function (id) {
    var self = this;
    Object.keys(this.nodes).forEach(function (k) { self.nodes[k].classList.toggle('is-picked', k === id); });
    var li = this.items[id];
    if (li) {
      Object.keys(this.items).forEach(function (k) { self.items[k].classList.toggle('is-current', k === id); });
      this.say(li.textContent.trim());
    }
  };

  var flows = $all('figure.flow').map(function (fig) { return new Flow(fig); });

  // Autoplay each diagram once when it scrolls into view, unless the reader prefers reduced motion.
  if ('IntersectionObserver' in window && !reduceMotion.matches) {
    var seen = new WeakSet();
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting || seen.has(entry.target)) return;
        seen.add(entry.target);
        var flow = flows.filter(function (f) { return f.fig === entry.target; })[0];
        if (flow && flow.idx === -1 && !flow.playing) flow.play();
      });
    }, { threshold: 0.45 });
    flows.forEach(function (f) { io.observe(f.fig); });
  }
  if (reduceMotion.addEventListener) {
    reduceMotion.addEventListener('change', function () {
      flows.forEach(function (f) { if (f.playing) f.pause(); });
    });
  }
})();
