# BUG: POST /orders hangs forever when the inventory service keeps returning 503

| Field | Value |
|---|---|
| Type | Bug |
| Severity | High (worker threads exhausted; order intake stops) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Component | `api/app/retry.py` (`call_with_retry`), used by `api/app/inventory.py` |
| Reported by | On-call SRE, incident INC-4471 (2026-10-03) |

## Summary

During the inventory service maintenance window on 3 October, `POST /orders` requests never returned. All API
worker threads ended up blocked, so even `GET /orders` timed out at the load balancer. The incident started 4
minutes after the platform team raised `ORDERS_RETRY_ATTEMPTS` from 3 to 8 to "ride out" short inventory blips.

## Observed behaviour

With `ORDERS_RETRY_ATTEMPTS=8` and the inventory service answering `503 Service Unavailable` to every
`POST /reservations`, a `POST /orders` request never completes. Logs show reservation attempts continuing once
per second indefinitely (one attempt every `ORDERS_RETRY_MAX_DELAY_S`), long after the 8th attempt.

## Expected behaviour

`call_with_retry` makes at most `attempts` calls in total. With 8 attempts and the defaults
(`ORDERS_RETRY_BASE_DELAY_S=0.05`, `ORDERS_RETRY_MAX_DELAY_S=1.0`), the sleeps are 0.05, 0.1, 0.2, 0.4, 0.8, 1.0,
1.0 s (7 sleeps, ~3.55 s in total), after which the last `TransientError` propagates and `POST /orders` returns
`503 "inventory service unavailable"`.

## Steps to reproduce

1. Configure the API with `ORDERS_INVENTORY_URL=http://inventory.local`, `ORDERS_RETRY_ATTEMPTS=8` and default
   base/max delay.
2. Make the inventory service return `503` for every `POST /reservations` (in tests:
   `httpx.MockTransport(lambda request: httpx.Response(503))` passed to `InventoryClient(transport=...)`).
3. `POST /orders` with a valid body, e.g.
   `{"customer_name": "Ada", "customer_email": "ada@example.com", "sku": "SKU-1", "quantity": 1, "total_cents": 1999}`.
4. The request does not return. With an injected `sleep` that records delays, the recorded list grows without
   bound: `[0.05, 0.1, 0.2, 0.4, 0.8, 1.0, 1.0, 1.0, ...]`.

With the default `ORDERS_RETRY_ATTEMPTS=3` the bug does not show, because the delay never reaches the cap before
attempts run out. Any value ≥ 7 with the default delays triggers it.

## Environment

- Storefront orders API 0.4.0, Python 3.12, FastAPI; production and staging both affected once the setting changed.
- Settings: `ORDERS_RETRY_ATTEMPTS=8`, `ORDERS_RETRY_BASE_DELAY_S=0.05`, `ORDERS_RETRY_MAX_DELAY_S=1.0`.

## Impact

- Order intake stopped for 38 minutes; support agents could not place phone orders.
- Requests piled up until every worker thread was blocked, turning a downstream outage into a full API outage.

## Suspected area (from the on-call notes; to be confirmed by diagnosis)

The attempt counter in `call_with_retry` seems tied to the delay doubling. Once the delay reaches
`max_delay_s`, something stops counting.

## Acceptance criteria

- **AC-1** A regression test is added first and fails on the current code without hanging the test run: it calls
  `call_with_retry` with `attempts=8`, `base_delay_s=0.05`, `max_delay_s=1.0`, a function that always raises
  `TransientError`, and an injected `sleep` that raises after 50 calls (guard), then asserts that the function
  was called exactly 8 times.
- **AC-2** After the fix, the same test passes: exactly 8 calls, the recorded delays are
  `[0.05, 0.1, 0.2, 0.4, 0.8, 1.0, 1.0]`, and the final `TransientError` propagates.
- **AC-3** An API-level test with `ORDERS_RETRY_ATTEMPTS=8`, a `MockTransport` returning `503` and a no-op `sleep`
  shows `POST /orders` returns `503` with detail `inventory service unavailable` and makes exactly 8 reservation
  calls.
- **AC-4** For every `attempts` in 1–20 and `max_delay_s` in {0.05, 0.5, 1.0}, an always-failing function is
  called exactly `attempts` times (parametrised or property-based test).
- **AC-5** All existing tests in `api/tests/test_retry.py` and `api/tests/test_orders.py` pass unmodified.
- **AC-6** The delay sequence is unchanged for runs that do not reach the cap (the existing
  `test_retries_then_succeeds_with_doubling_delays` still expects `[0.05, 0.1]`).

## Non-functional requirements

- Tests never really sleep (inject `sleep=`, per `.adlc/context/conventions.md`) and finish in < 1 s.
- The fix is minimal and local to `api/app/retry.py`; no change to the public signature of `call_with_retry`.

## Out of scope

- A total-time budget or circuit breaker for inventory calls (raise separately if the Reflector recommends it).
- Changing the default retry settings.
