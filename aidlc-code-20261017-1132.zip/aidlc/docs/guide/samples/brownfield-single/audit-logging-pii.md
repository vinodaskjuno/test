# Audit log for order access, with PII redaction

| Field | Value |
|---|---|
| Type | Enhancement to an existing product (compliance) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Requested by | Sofia Brandt, Data Protection Officer; sponsor: Head of Customer Support |
| Priority | P1 (finding from the 2026 ISO 27001 surveillance audit, due within 60 days) |

## Context

The surveillance audit found that Storefront orders cannot answer "who looked at this customer's order, and
when?". Support agents can read any order including the customer's email address, and order creation by phone
leaves no trace of which agent placed it. We need an append-only audit trail of order creation and order reads.

The audit log itself must not become a second copy of customer personal data. `.adlc/context/conventions.md`
already states: *"Customer email is personal data: never log it and never return it from list endpoints added in
future."* The audit log must therefore identify the customer by a keyed hash of the email, never the email itself.

## Users

- **Data Protection Officer (DPO):** answers data-subject access requests ("who accessed my data?") and audit
  questions; needs to query the log by order id, actor and customer.
- **Support agent / fulfilment lead:** their actions are recorded; no change to their workflow.
- **Security engineer:** needs evidence that the log is tamper-evident and contains no plain PII.

## Functional requirements

1. Every successful `POST /orders` and `GET /orders/{order_id}` writes one audit event. `GET /orders` (list)
   writes one event per request with the number of orders returned, not one per order.
2. The actor is taken from the `X-Actor-Id` request header set by the internal gateway (e.g. `agent-1042`). A
   request without it is recorded with actor `unknown` (the gateway rollout is not finished in every
   environment); it is not rejected.
3. An audit event has: `id`, `occurred_at` (UTC), `actor_id`, `action` (`order.create`, `order.read`,
   `order.list`), `order_id` (null for list), `customer_ref`, `request_id`, `outcome` (`success` or the HTTP
   status for failures that reached the handler, e.g. `404`), `details` (small JSON object, e.g.
   `{"count": 37}` for a list; never PII).
4. `customer_ref` is `HMAC-SHA256(key, lowercase(trimmed customer_email))`, hex-encoded. The key comes from the
   `ORDERS_AUDIT_HMAC_KEY` environment variable (added to `app/settings.py` with `ORDERS_AUDIT_ENABLED`, default
   `true`); the service refuses to start when audit logging is enabled and the key is missing or shorter than
   32 bytes. Tests set a fixed test key through the `Settings` object.
5. Events are stored in a new `audit_events` table in the same SQLite database, written by a new
   `AuditRepository` in `app/repository.py` (SQL stays in that module). There is no API to update or delete
   audit events.
6. Tamper evidence: each row stores `prev_hash` and `row_hash = SHA-256(prev_hash || canonical JSON of the
   row)`. A function `verify_chain()` returns the first broken row id or `None`.
7. A read-only endpoint `GET /audit/events?order_id=&actor_id=&customer_email=&from=&to=` for the DPO. When
   `customer_email` is given, the service hashes it and filters by `customer_ref`; the email is never stored or
   logged. Access requires the header `X-Actor-Role: dpo` (set by the gateway); otherwise `403`.
8. Application logs (Python `logging`) must not contain the customer email for any order endpoint, including
   validation error paths.

## Acceptance criteria

- **AC-1** `POST /orders` writes exactly one `audit_events` row with `action = order.create`, the new `order_id`,
  the `X-Actor-Id` value and a 64-character hex `customer_ref`.
- **AC-2** `GET /orders/{id}` writes one `order.read` row; a `GET` for a missing id writes one row with
  `outcome = 404` and `order_id` set to the requested id.
- **AC-3** `GET /orders` writes one `order.list` row whose details record the number of orders returned.
- **AC-4** No column of any `audit_events` row, and no captured log record during the test suite, contains the
  substring of any customer email used in the tests.
- **AC-5** The same email with different case or surrounding spaces yields the same `customer_ref`; a different
  `ORDERS_AUDIT_HMAC_KEY` yields a different one.
- **AC-6** Starting the app with audit enabled and a missing or 16-byte key raises a configuration error.
- **AC-7** `GET /audit/events?customer_email=jane@example.com` with `X-Actor-Role: dpo` returns the events for
  that customer's orders; without the role header it returns `403`.
- **AC-8** `verify_chain()` returns `None` for an untouched log and the id of the first modified row after a row's
  `actor_id` is changed directly in SQLite.
- **AC-9** Requests without `X-Actor-Id` are served normally and audited with `actor_id = unknown`.
- **AC-10** The existing tests in `api/tests/` pass unchanged.

## Non-functional requirements

- Audit writes add < 5 ms p95 to `POST /orders` and `GET /orders/{id}`.
- If writing the audit event fails, the request fails with `500` (no unaudited reads). This is deliberate:
  the DPO prefers availability loss over unaudited access.
- Retention: 7 years; purge tooling is out of scope but the schema must allow deleting by `occurred_at` range.
- GDPR: `customer_ref` is pseudonymous data; document the key-rotation impact in `architecture.md`.

## Out of scope

- Shipping events to the SIEM, UI for browsing the audit log, auditing the web app's page views.
- Changing which fields existing endpoints return.

## Repo hints

- Repo `storefront`: `api/app/routes/orders.py`, `api/app/repository.py`, `api/app/settings.py`,
  `api/app/main.py`. Tests use the `client` fixture in `api/tests/conftest.py`.
