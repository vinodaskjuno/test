# Orders list: pagination, filters and sorting

| Field | Value |
|---|---|
| Type | Enhancement to an existing product |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Requested by | Dana Kowalski, Fulfilment Lead |
| Priority | P1 |

## Context

Storefront orders handles about 2,000 orders per day. `GET /orders` returns every order in the database, oldest
first, and `web/app/orders/page.tsx` renders all of them in `OrdersTable`. After eight months the table holds
~480,000 rows: the page takes over 9 seconds to render, and fulfilment leads scroll to the bottom to find today's
orders. Support agents also need to find "all pending orders from last week" without exporting to a spreadsheet.

## Users

- **Fulfilment lead:** watches what needs to ship; wants the newest `paid` orders first.
- **Support agent:** looks up orders for a customer complaint by status and date range.
- **Existing API consumers:** the nightly finance reconciliation script calls `GET /orders` with no parameters
  and expects a JSON array. It must keep working unchanged.

## Functional requirements

### API (`api/app/routes/orders.py`, `api/app/repository.py`)

`GET /orders` accepts these optional query parameters:

| Parameter | Type | Default | Rules |
|---|---|---|---|
| `page` | int | 1 | ≥ 1 |
| `page_size` | int | 50 | 1–200 |
| `status` | `pending` / `paid` / `shipped` / `cancelled`, repeatable | all | unknown value → 422 |
| `created_from` | ISO-8601 date | none | inclusive, UTC |
| `created_to` | ISO-8601 date | none | inclusive (whole day), UTC; must be ≥ `created_from` |
| `sort` | `created_at`, `-created_at`, `total_cents`, `-total_cents`, `id`, `-id` | `id` | `-` = descending |

- **Backward compatibility:** when *none* of these parameters is present the response is exactly today's: a JSON
  array of all orders ordered by `id`. When *any* is present the response body is the paged envelope:
  `{"items": [...], "page": 1, "page_size": 50, "total": 1234}`. A response header `X-Total-Count` is returned in
  both cases.
- Envelope `items` use a new `OrderSummary` model (every `Order` field except `customer_email`), because the
  conventions forbid returning customer email from new list responses. The legacy array keeps its current shape.
- Ties in the sort key are broken by `id` ascending so pages are stable.
- Filtering, sorting and paging happen in SQL (`LIMIT`/`OFFSET`, parameterised `WHERE`), never in Python over
  the full table. Sort columns come from an allow-list, never interpolated from user input.
- Add an index on `orders(created_at)` and `orders(status, created_at)` in the repository schema setup.

### Web (`web/`)

- `app/orders/page.tsx` reads `page`, `status`, `from`, `to` and `sort` from `searchParams`, calls a new
  `fetchOrdersPage(params)` in `lib/api.ts`, and passes the result to `OrdersTable`.
- Above the table: a status multi-select, two date inputs and an "Apply" button (a plain `GET` form, so filters
  are bookmarkable and work without client JavaScript).
- Column headers "#", "Total" and "Created" are sort links; the active column shows its direction and sets
  `aria-sort`.
- Below the table: "Previous" / "Next" links and "Showing 51–100 of 1,234 orders".
- `OrdersTable` stays presentational (props only) and keeps its `<caption>` and `scope` attributes.

## Acceptance criteria

- **AC-1** `GET /orders` with no query parameters returns the same JSON array as before this change (all orders,
  ordered by `id`); the existing `api/tests/test_orders.py` passes unmodified.
- **AC-2** `GET /orders?page=2&page_size=2` with 5 orders returns `items` with orders 3 and 4, `page: 2`,
  `page_size: 2`, `total: 5`.
- **AC-3** `GET /orders?status=paid&status=shipped` returns only paid and shipped orders, and `total` counts only
  those.
- **AC-4** `GET /orders?created_from=2026-09-01&created_to=2026-09-30` includes orders created at any time on
  30 September (UTC) and excludes 1 October 00:00:00.
- **AC-5** `GET /orders?sort=-total_cents` orders by total descending, ties broken by `id` ascending.
- **AC-6** `page_size=0`, `page_size=201`, `page=0`, an unknown `status`, an unknown `sort` key, or
  `created_to` earlier than `created_from` each return `422`.
- **AC-7** The orders page shows 50 rows by default with "Showing 1–50 of N orders" and working Previous/Next links.
- **AC-8** Choosing status "pending" and a date range and pressing "Apply" updates the URL query string and the
  table shows only matching orders.
- **AC-9** Clicking the "Total" header sorts by total; the header has `aria-sort="descending"` or `"ascending"`.
- **AC-10** With filters that match nothing, the table area shows "No orders match these filters." with
  `role="status"`.
- **AC-11** No item in a paged envelope response contains a `customer_email` key.

## Non-functional requirements

- `GET /orders?page=1&page_size=50&sort=-created_at` p95 < 200 ms with 500,000 orders in SQLite (indexed).
- No query in the request path scans the full table when a page is requested (verified with `EXPLAIN QUERY PLAN`
  in a test).
- Follow `.adlc/context/conventions.md`: SQL only in `app/repository.py`, parameterised; routes stay thin;
  no customer email in new list responses.
- WCAG 2.2 AA for the new controls (labels on the date inputs and the status select).

## Out of scope

- Cursor-based pagination, full-text search by customer name, CSV export, saved filter presets.

## Repo hints

- Repo `storefront`; API in `api/`, web in `web/`; baseline tests: `cd api && pytest -q`, `cd web && npm test`.
