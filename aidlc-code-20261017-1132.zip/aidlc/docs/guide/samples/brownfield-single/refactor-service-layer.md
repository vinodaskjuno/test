# Refactor: extract an orders service layer

| Field | Value |
|---|---|
| Type | Refactoring (no behaviour change) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Requested by | Tomás Reyes, Tech Lead, Storefront |
| Priority | P2 (unblocks the audit-log and pagination work planned next quarter) |

## Context

`.adlc/context/architecture.md` notes: *"Routes currently call the repository and the inventory client directly;
there is no service layer yet."* `create_order` in `api/app/routes/orders.py` reserves stock through
`InventoryClient.reserve`, maps `OutOfStockError` to `409` and `TransientError` to `503`, and then calls
`OrderRepository.create`. Upcoming features (audit logging, status transitions, notifications) would each add
more orchestration to the route functions, and the business rules are only testable through HTTP.

We want a thin service layer between the routes and the repository/inventory client so that business logic is
unit-testable without FastAPI, and routes only translate HTTP to service calls and domain errors to status codes.

## Users

- **Storefront developers:** get a single place for order business rules.
- **API consumers (web app, finance script):** must not notice any change.

## Requirements

1. Create `api/app/services/__init__.py` and `api/app/services/orders.py` with a class `OrderService` that takes an
   `OrderRepository` and an optional `InventoryClient` in its constructor and exposes:
   - `list_orders() -> list[Order]`
   - `get_order(order_id: int) -> Order` raising `OrderNotFoundError` when absent
   - `place_order(data: OrderCreate) -> Order` that reserves stock (when an inventory client is configured) and
     then persists the order.
2. Domain errors live in the service module: `OrderNotFoundError`, plus the existing `OutOfStockError` and
   `TransientError` propagate unchanged from `app.inventory` / `app.retry`.
3. `create_app` in `api/app/main.py` builds one `OrderService` and stores it on `app.state.order_service`.
   `app.state.repository` and `app.state.inventory` remain set (tests and the `create_app(..., inventory=...)`
   injection point rely on them).
4. `api/app/routes/orders.py` calls only `OrderService`; it no longer imports `OrderRepository` or
   `InventoryClient`. Status codes, error messages and response models are byte-for-byte the same as today:
   `404 "order {id} not found"`, `409` with the out-of-stock message, `503 "inventory service unavailable"`.
5. New unit tests for `OrderService` in `api/tests/test_order_service.py` use a temporary SQLite file and a fake
   inventory client; they do not use `TestClient`.
6. Update `.adlc/context/architecture.md` (API layers table) to describe the new layer.

## Acceptance criteria

- **AC-1** All existing tests in `api/tests/` (`test_orders.py`, `test_retry.py`) and `web/tests/` pass without
  any modification to those files.
- **AC-2** `api/app/routes/orders.py` imports nothing from `app.repository` or `app.inventory` except the error
  types it maps to status codes.
- **AC-3** `OrderService.place_order` calls `InventoryClient.reserve(sku, quantity)` before persisting, and does
  not persist the order when `reserve` raises `OutOfStockError` or `TransientError` (unit-tested with a fake).
- **AC-4** `OrderService.get_order` raises `OrderNotFoundError` for an unknown id; the route maps it to `404`
  with the message `order {id} not found`.
- **AC-5** With no inventory client configured, `place_order` persists without reserving (unit-tested).
- **AC-6** The served OpenAPI document (`/openapi.json`) is identical before and after the change.
- **AC-7** `architecture.md`'s API layers table lists `app/services/orders.py` and its responsibility.

## Non-functional requirements

- No behaviour change: identical HTTP status codes, bodies and headers for every existing endpoint.
- No new runtime dependencies; follow `.adlc/context/conventions.md` (type hints, `from __future__ import
  annotations`, SQL only in `app/repository.py`).
- Line coverage of `api/app/services/` ≥ 90%.

## Out of scope

- Changing `call_with_retry` or the retry settings (a separate bug is tracked for `app/retry.py`).
- Dependency-injection frameworks, async conversion, any web change.

## Repo hints

- Repo `storefront`. Baseline: `cd api && pytest -q` must be green before and after.
