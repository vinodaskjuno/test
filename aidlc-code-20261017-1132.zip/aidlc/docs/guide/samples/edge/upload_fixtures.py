"""Runtime generators for the upload edge-case evals.

Nothing harmful or huge is committed: the oversized file and the anti-malware test file are produced on demand by
the e2e tests (and by anyone following ``oversized-upload.md`` by hand).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

DEFAULT_UPLOAD_MAX_BYTES = 10 * 1024 * 1024  # mirrors AIDLC_UPLOAD_MAX_BYTES' default

# The industry-standard EICAR anti-malware test string (harmless by design), stored as short fragments so neither
# the full string nor a recognisable part of it exists in the repository and no scanner flags this source file.
_EICAR_PARTS = (r"X5O!P%@AP[4\PZX54(P^)7CC)7}$", "EIC", "AR-STAND", "ARD-ANTIV", "IRUS-TE", "ST-FI", "LE!$H+H*")


def eicar_bytes() -> bytes:
    return "".join(_EICAR_PARTS).encode("ascii")


def write_eicar(path: Path) -> Path:
    path.write_bytes(eicar_bytes())
    return path


def write_oversized(path: Path, limit_bytes: int = DEFAULT_UPLOAD_MAX_BYTES) -> Path:
    """Write a valid-looking Markdown spec exactly one byte larger than ``limit_bytes``.

    The body is plain text (not NUL padding) so the upload is rejected for its size, not for its content type.
    """
    header = b"# Oversized spec\n\nAC-1: this file exceeds the upload limit.\n\n"
    line = b"Filler line so the spec exceeds the configured upload limit.\n"
    size = limit_bytes + 1
    body = (line * (size // len(line) + 1))[: size - len(header)]
    path.write_bytes(header + body)
    return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate upload edge-case files at runtime.")
    parser.add_argument("kind", choices=["oversized", "eicar"])
    parser.add_argument("path", type=Path)
    parser.add_argument("--limit-bytes", type=int, default=DEFAULT_UPLOAD_MAX_BYTES)
    args = parser.parse_args(argv)
    if args.kind == "oversized":
        write_oversized(args.path, args.limit_bytes)
    else:
        write_eicar(args.path)
    print(args.path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
