# Better orders export

| Field | Value |
|---|---|
| Type | Feature request |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Requested by | Sales Operations (via the #storefront-requests channel) |
| Priority | High |

## Background

The orders export is too slow and looks bad. Our big customers complain about it all the time, and with the
enterprise deals coming in we need to support them properly. Please make the export faster and nicer.

## What we want

- Make the orders export much faster, especially for big customers.
- Make the file nicer — the current one is hard to work with.
- Big customers should be able to get all their data.
- It should work the way the other reports work.
- Should be done before the enterprise launch.

## Acceptance criteria

- **AC-1** The export is fast for big customers.
- **AC-2** The exported file looks nicer than today.
- **AC-3** Big customers can export all of their orders.
- **AC-4** The export works like the other reports.

## Notes

- Nobody has measured how slow it is today; people say "it takes forever".
- Not sure whether Finance also uses this export.
