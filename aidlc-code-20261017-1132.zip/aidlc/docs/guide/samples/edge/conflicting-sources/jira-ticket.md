# SUP-2318: Refund button on order page

| Field | Value |
|---|---|
| Source | Jira (project SUP) |
| Issue type | Story |
| Reporter | Hannah Lindqvist (Support Operations Manager) |
| Status | Ready for development |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Linked design | Figma "Storefront / Refunds" (see `figma-notes.md`) |

## Description

Support agents currently ask a supervisor in Slack to raise a refund in the payment provider's console, which
takes 20 minutes on average during peak hours. To cut handling time, **every support agent** should be able to
refund an order directly from the order page in the storefront back-office.

Refunds are allowed for **30 days** after the order was placed, matching the public returns policy on the
website. Partial refunds are allowed (e.g. one item of a multi-quantity order).

## Requirements

- Add a "Refund" button to the order view, visible to all users with the `support_agent` role.
- Refund window: up to 30 days after `created_at`.
- Full or partial refund amount, in cents, up to the order's `total_cents`.
- Only `paid` and `shipped` orders can be refunded.
- Record who refunded and why (free-text reason, required).

## Acceptance criteria

- AC-1: A user with the `support_agent` role sees a "Refund" button on a paid or shipped order placed 30 or fewer
  days ago.
- AC-2: Submitting a refund with an amount between 1 and `total_cents` and a reason creates a refund record and
  shows a confirmation.
- AC-3: Orders older than 30 days do not show the button, and the API rejects refunds for them with `422`.
- AC-4: Pending and cancelled orders cannot be refunded.

## Comments

- *Hannah Lindqvist:* The supervisor bottleneck is the whole point of this ticket — please don't gate it.
