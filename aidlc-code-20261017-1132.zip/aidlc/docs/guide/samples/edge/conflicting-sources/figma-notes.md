# Figma notes: Storefront / Refunds (frame "Order page – refund", node 88-120)

| Field | Value |
|---|---|
| Source | Figma design annotations, exported as text |
| File | https://www.figma.com/design/ZyXwVu987654/Storefront-Refunds?node-id=88-120 |
| Designer | Kenji Watanabe (Product Design) |
| Last edited | 2026-09-28 (after review with Finance and Risk) |

## Annotations on the frame

1. **Visibility:** The "Refund" button is shown **only to supervisors** (`support_supervisor` role). Agents see a
   disabled "Request refund" button with a tooltip: "A supervisor must approve refunds." (Risk asked for this
   after the August refund-fraud incident.)
2. **Refund window:** **14 days** from delivery confirmation, not from order date. Show the deadline under the
   button: "Refundable until 12 Oct 2026".
3. **Amount:** full refunds only in this release; the amount field is read-only and shows the order total.
4. **Reason:** required, choose from a list (Damaged, Not received, Wrong item, Other + text).
5. **Confirmation:** modal dialog with focus trapped; primary action "Refund $42.00".

## Acceptance criteria (from the design review checklist)

- AC-1: Only users with the `support_supervisor` role see an enabled "Refund" button.
- AC-2: The refund window is 14 days from delivery confirmation; after that the button is hidden.
- AC-3: Only full refunds are possible; the amount is not editable.
- AC-4: A reason from the list is mandatory; "Other" requires free text.
- AC-5: The confirmation dialog meets WCAG 2.2 AA (focus trap, Escape closes, focus returns to the button).
