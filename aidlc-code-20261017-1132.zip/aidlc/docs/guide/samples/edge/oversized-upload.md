# Upload limits: oversized, wrong-type and malware uploads are rejected

| Field | Value |
|---|---|
| Type | Platform edge case (upload validation), not a product spec |
| Endpoint | `POST /api/v1/projects/{id}/specs` (multipart: `files[]`, `kind`, `title?`, `repos[]`, `figma_url?`) |
| Setting | `AIDLC_UPLOAD_MAX_BYTES` (default `10485760` = 10 MiB) |
| Fixture generator | `evals/specs/edge/upload_fixtures.py` (owned by infra-evals) |

## Why this sample has no binary fixtures

The bad files are **generated at runtime** by the end-to-end test and are never committed:

- **Oversized file:** `upload_fixtures.py` writes a Markdown file of exactly `AIDLC_UPLOAD_MAX_BYTES + 1` bytes
  (10 MiB + 1 byte = 10,485,761 bytes with the default) into the test's temporary directory. Committing a 10 MiB
  file would bloat the repository for no benefit.
- **Wrong type:** a file named `spec.md` whose content starts with the ELF magic bytes (`\x7fELF`), and a
  `payload.exe`. Both are generated in the temporary directory.
- **Malware sample:** the industry-standard antivirus *test* string is assembled in memory from separate
  fragments by `upload_fixtures.py` and written to the temporary directory only for the duration of the test.
  **The complete test string must never appear in this repository** — not in specs, fixtures, tests or docs —
  because repository and endpoint scanners on developer machines and CI runners would quarantine the files.

The test deletes all generated files in teardown.

## Users

- **Spec author** using the Upload Spec page, CLI (`aidlc run <file>`) or REST API.
- **Platform operator** who needs evidence that uploads are validated before any agent sees them.

## Acceptance criteria

- **AC-1** Uploading a file of `AIDLC_UPLOAD_MAX_BYTES + 1` bytes returns `413 Payload Too Large` with a problem
  body naming the limit; no upload record, run, or work item is created.
- **AC-2** A file of exactly `AIDLC_UPLOAD_MAX_BYTES` bytes is accepted by the size check (boundary).
- **AC-3** Uploading `payload.exe`, or `spec.md` whose content is an ELF binary (content sniffing disagrees with
  the extension), returns `415 Unsupported Media Type`; nothing is stored.
- **AC-4** Uploading the runtime-generated antivirus test file returns `422 Unprocessable Entity` (a `400` is also
  accepted by the test) with reason `malware_detected`; the file is not persisted to the artifact store.
- **AC-5** Each rejection emits an audit event (`upload.rejected` with reason `size`, `type` or `malware`), and the
  Upload Spec page shows a human-readable error next to the file.
- **AC-6** No agent is invoked and no Temporal workflow is started for any rejected upload.
- **AC-7** The CLI exits non-zero with the API's error message for each case.

## Non-functional requirements

- Size is enforced while streaming (the server stops reading after the limit), not after buffering the whole body.
- Malware scanning happens before any conversion (PDF/DOCX → Markdown) or parsing.

## Out of scope

- Archive (zip) uploads, which are rejected as an unsupported type anyway.
