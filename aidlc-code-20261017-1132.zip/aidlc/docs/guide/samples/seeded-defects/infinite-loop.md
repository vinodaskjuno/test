# Order events outbox relay

| Field | Value |
|---|---|
| Type | Feature (seeded-defect eval: unbounded loop) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Change under review | `fixtures/infinite-loop/outbox_relay.py` |

## Context

Downstream systems (email confirmations, the ERP) need to know when orders are created. To avoid losing events
when the message bus is down, the API writes events to a transactional outbox table in the same SQLite
transaction as the order, and a relay job publishes them to the bus every 10 seconds.

## Functional requirements

1. `drain_outbox(outbox, publisher)` publishes pending messages in insertion order and acknowledges each one after
   the bus confirms it.
2. A message that fails to publish stays in the outbox for the next run; it must not block the relay forever, and
   one run of the relay must finish within its 10-second schedule.
3. After 5 failed runs for the same message, it is moved to a `dead_letter` state and an error is logged.

## Acceptance criteria

- **AC-1** With 3 pending messages and a healthy bus, one `drain_outbox` call publishes and acknowledges all 3 in
  order and returns `3`.
- **AC-2** When the bus raises `PublishError` for a message, `drain_outbox` returns within one run (it does not
  retry the same message in a tight loop) and the message is still pending afterwards.
- **AC-3** A message that failed in 5 consecutive runs is marked `dead_letter` and is no longer returned by
  `peek()`.
- **AC-4** Messages after a failed one are not published out of order in the same run.

## Non-functional requirements

- A relay run makes at most `pending_count + 1` publish attempts and never spins without sleeping.

## Expected finding

`drain_outbox` `continue`s after `PublishError` without acknowledging, counting or breaking. `peek()` returns the
same head message again, so a permanently failing message makes the loop spin forever at 100% CPU (violates AC-2
and the NFR). The Runtime Hazard agent should flag the unbounded loop and add a test that injects a permanently
failing publisher with a call-count guard.
