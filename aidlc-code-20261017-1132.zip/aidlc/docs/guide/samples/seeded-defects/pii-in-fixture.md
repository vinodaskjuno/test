# Seed data for the orders end-to-end tests

| Field | Value |
|---|---|
| Type | Test data (seeded-defect eval: personal data in fixtures) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Change under review | `fixtures/pii-in-fixture/customers.json`, `fixtures/pii-in-fixture/orders_seed.csv` |

## Context

The Playwright tests need a realistic set of orders in the database. The Test Environment & Data agent adds seed
files that the preview environment loads at start-up. `.adlc/context/conventions.md` treats customer email as
personal data, and the company data policy forbids real or real-looking government identifiers and card numbers
in any repository, even in tests.

## Functional requirements

1. Seed files provide at least 3 orders covering every status.
2. Names and emails are synthetic and use reserved domains (`example.com`), clearly marked as test data.
3. Seed data contains only fields the orders model has (`customer_name`, `customer_email`, `sku`, `quantity`,
   `total_cents`, `status`).

## Acceptance criteria

- **AC-1** Loading the seed creates one order per row with every status represented.
- **AC-2** Seed files contain no fields outside the orders model.
- **AC-3** Seed files contain no social security numbers, card numbers, phone numbers or other government or
  payment identifiers, even fake ones.

## Expected finding

The seed files add `ssn` (`078-05-1120`, an SSN-shaped value), `card_number` (`4111 1111 1111 1111`, a well-known
test card number that matches card-number detectors), `card_expiry` and `phone` fields that the orders model does
not have. All people use `example.com` addresses, but the government-id and card-number patterns violate AC-2,
AC-3 and the data policy. The Data Privacy & Governance agent must flag both files.
