# Orders summary endpoint

| Field | Value |
|---|---|
| Type | Cross-repo feature (seeded-defect eval: contract drift) |
| Repositories | `api` (`evals/repos/multi/api`), `web` (`evals/repos/multi/web`) |
| Change under review | `fixtures/contract-drift/openapi.snippet.yaml`, `fixtures/contract-drift/summary_route.py`, `fixtures/contract-drift/types.snippet.ts` |

## Context

The web dashboard wants a header strip with "N orders, $X total" without downloading every order. The API adds
`GET /orders/summary`; the web app reads it through `lib/api.ts` using the `OrderSummary` type that mirrors the
published contract in `api/openapi.yaml`.

## Functional requirements

1. `GET /orders/summary` returns `{"count": <int>, "total_cents": <int>}` over all orders.
2. `openapi.yaml` declares the path and an `OrderSummary` schema with both fields required; `web/lib/types.ts`
   mirrors it.

## Acceptance criteria

- **AC-1** `GET /orders/summary` with orders totalling 1,999 + 4,500 cents returns
  `{"count": 2, "total_cents": 6499}`.
- **AC-2** The served `/openapi.json` `OrderSummary` schema has exactly the properties and required fields declared
  in `openapi.yaml`.
- **AC-3** `web/lib/types.ts` `OrderSummary` matches the contract field for field.

## Expected finding

The contract snippet and the web type use `total_cents`, but the route's response model returns `total`. Every
web consumer reading `summary.total_cents` gets `undefined`. The Architecture Conformance agent must report the
cross-repo contract drift (route vs `openapi.yaml` vs `web/lib/types.ts`); `tests/test_contract.py` would also
fail once `OrderSummary` is added to its schema list.
