# Parallel edits to `list_orders` (two REQs in one sprint)

| Field | Value |
|---|---|
| Type | Sprint (seeded-defect eval: conflicting parallel edits) |
| Repository | `api` (`evals/repos/multi/api`) |
| Change under review | `fixtures/parallel-edit-conflict/a.diff` (REQ-A, rank 1), `fixtures/parallel-edit-conflict/b.diff` (REQ-B, rank 2) |

## Context

Two REQs in the same sprint both change `GET /orders` in `app/routes/orders.py`:

- **REQ-A "Newest orders first"** (rank 1): the dashboard should show today's orders at the top, so
  `list_orders` returns orders sorted by `created_at` descending.
- **REQ-B "Filter orders by status"** (rank 2): `GET /orders?status=paid` returns only orders with that status;
  `list_orders` gains a `status` query parameter.

Both diffs replace the same body line `return _store(request).list()` (REQ-B also rewrites the signature line and
the imports). Unlike the `sprint-conflict` sample, these are **edits of the same lines**, not pure additions at the
same point, so `conflict_bound` must refuse to auto-resolve them.

## Acceptance criteria

- **AC-1** REQ-A: `GET /orders` returns orders newest first.
- **AC-2** REQ-B: `GET /orders?status=paid` returns only paid orders; without the parameter all orders are returned.
- **AC-3** The platform detects the overlap before development: the Overlap Analyst flags both REQs touching
  `list_orders` in `app/routes/orders.py` and ranks REQ-A first.
- **AC-4** The final trial merge of REQ-B against REQ-A's branch reports a content conflict in
  `app/routes/orders.py`; `conflict_bound` refuses it (both sides change existing lines), REQ-B ends `blocked`
  for a human, and REQ-A's PR is unaffected.

## Expected finding

`git merge-tree --write-tree` of the two branches reports `CONFLICT (content)` in `app/routes/orders.py`. The
deterministic trial-merge gate catches it; the bounded resolver must not merge it because neither side is a pure
addition. The human resolution (sorted *and* filtered) is a follow-up, not something the platform guesses.
