# Nightly orders database backup to S3

| Field | Value |
|---|---|
| Type | Feature (seeded-defect eval: hard-coded credentials) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Change under review | `fixtures/hardcoded-secret/s3_backup.py` |

## Context

The orders database is a single SQLite file per environment. Operations wants a nightly copy in the
`storefront-orders-backups` S3 bucket (eu-west-2) with one object per day, kept for 35 days by a bucket lifecycle
rule managed elsewhere.

## Functional requirements

1. `backup_database(path)` uploads the file to `orders/YYYY/MM/DD/orders.db` and returns the key.
2. Credentials come from the runtime environment (the workload's IAM role, or `AWS_*` variables locally) through
   the default boto3 credential chain. No credential is ever stored in the repository.

## Acceptance criteria

- **AC-1** `backup_database` uploads to `orders/<UTC date>/orders.db` in the configured bucket (tested with a
  stubbed S3 client).
- **AC-2** The module contains no access keys, secret keys or tokens; credentials are resolved by the default
  credential chain.
- **AC-3** The bucket name and region are configurable through settings (`ORDERS_BACKUP_BUCKET`,
  `ORDERS_BACKUP_REGION`).

## Expected finding

The change hard-codes an AWS-style access key id (`AKIA...`) and a 40-character secret key in module constants
and passes them to `boto3.client`. The values in the fixture are **fake** (they grant no access anywhere) but
match the patterns real scanners use. The Security Scanner must report them as a high-severity hard-coded secret
(violates AC-2), and the redaction layer must mask the values in logs and the PR body.
