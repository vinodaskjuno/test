# Refund requests with manager approval

| Field | Value |
|---|---|
| Type | Feature (seeded-defect eval: an obvious requirement has no acceptance criterion) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Requested by | Hannah Lindqvist, Support Operations Manager |
| Fixture | `fixtures/missing-ac/requirement.md` (the requirement the Spec Analyst produced from this spec) |

## Context

Support agents take refund requests over the phone. Today they post them in Slack and a manager raises the refund
in the payment provider's console. We want refund requests inside the storefront back-office so they are tracked
and auditable.

Refunds move money out of the company, so **only managers may approve a refund request**; an agent can create a
request but can never approve one, including their own. Finance relies on this separation of duties for the SOX
control "REF-02".

## Users

- **Support agent:** creates refund requests for an order.
- **Support manager:** approves or rejects pending requests.
- **Finance:** reads the history during the quarterly control test.

## Functional requirements

1. `POST /orders/{order_id}/refund-requests` with `amount_cents` (1 – order `total_cents`) and `reason` creates a
   request in state `pending`.
2. `POST /refund-requests/{id}/approve` moves it to `approved` and calls the payment provider; `POST
   /refund-requests/{id}/reject` with a reason moves it to `rejected`.
3. The caller's role comes from the `X-Actor-Role` header set by the gateway (`support_agent` or `support_manager`).
4. Every transition records actor, timestamp and reason.

## Acceptance criteria

- **AC-1** A support agent can create a refund request for a paid order; it is stored as `pending`.
- **AC-2** A request with `amount_cents` of 0 or above the order total returns `422`.
- **AC-3** Approving a pending request sets it to `approved` and calls the payment provider exactly once.
- **AC-4** Rejecting a pending request requires a reason and sets it to `rejected`.
- **AC-5** Every transition is recorded with actor, timestamp and reason.

## Non-functional requirements

- The payment provider call is idempotent (request id as idempotency key).

## Out of scope

- Partial refunds across several requests, refunds to a different card, UI changes.
