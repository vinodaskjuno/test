# Fulfilment pick list

| Field | Value |
|---|---|
| Type | Feature (seeded-defect eval: N+1 query) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Change under review | `fixtures/n-plus-one/pick_list.py` |

## Context

Warehouse pickers print a pick list each morning: the oldest paid orders with the product name and bin location
for each SKU. Product details live in a `products` table (`sku`, `name`, `bin_location`) synced from the catalogue.
A busy morning has 500 paid orders over ~120 distinct SKUs.

## Functional requirements

1. `build_pick_list(conn, limit=500)` returns up to `limit` paid orders, oldest first, each with SKU, product
   name, bin location and quantity.
2. Orders whose SKU has no product row show `(unknown product)` and `UNASSIGNED`.
3. A new endpoint `GET /pick-list` returns the list as JSON (route not part of this eval).

## Acceptance criteria

- **AC-1** With 3 paid orders and 1 pending order, the pick list contains exactly the 3 paid orders, oldest first.
- **AC-2** Each line has the product name and bin location from `products`.
- **AC-3** An order for an unknown SKU shows `(unknown product)` / `UNASSIGNED`.
- **AC-4** Building the list for 500 orders executes a constant number of SQL statements (at most 2), regardless of
  the number of orders.

## Non-functional requirements

- `build_pick_list` for 500 orders completes in < 50 ms on SQLite.

## Expected finding

The function runs one `SELECT ... FROM products WHERE sku = ?` per order inside the loop: 1 + N queries
(501 for a busy morning), violating AC-4. The Performance Smell agent should flag the N+1 and suggest a `JOIN`
(or one `WHERE sku IN (...)` lookup).
