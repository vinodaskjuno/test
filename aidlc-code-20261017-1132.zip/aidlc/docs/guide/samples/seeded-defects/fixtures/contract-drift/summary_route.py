"""GET /orders/summary for the multi/api repo (change under review)."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/orders", tags=["orders"])


class OrderSummary(BaseModel):
    count: int
    total: int


@router.get("/summary", response_model=OrderSummary)
def order_summary(request: Request) -> OrderSummary:
    orders = request.app.state.store.list()
    return OrderSummary(count=len(orders), total=sum(order.total_cents for order in orders))
