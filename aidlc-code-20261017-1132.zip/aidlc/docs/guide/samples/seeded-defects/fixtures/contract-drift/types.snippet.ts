// Addition to multi/web/lib/types.ts in the change under review (generated from the openapi snippet).
export interface OrderSummary {
  count: number;
  total_cents: number;
}
