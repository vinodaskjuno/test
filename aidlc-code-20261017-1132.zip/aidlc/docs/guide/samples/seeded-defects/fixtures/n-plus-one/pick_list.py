"""Fulfilment pick list: paid orders with product name and bin location (change under review)."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class PickLine:
    order_id: int
    sku: str
    product_name: str
    bin_location: str
    quantity: int


def build_pick_list(conn: sqlite3.Connection, *, limit: int = 500) -> list[PickLine]:
    """Return the oldest paid orders with the product details pickers need."""
    orders = conn.execute(
        "SELECT id, sku, quantity FROM orders WHERE status = 'paid' ORDER BY created_at LIMIT ?",
        (limit,),
    ).fetchall()
    lines: list[PickLine] = []
    for order_id, sku, quantity in orders:
        product = conn.execute(
            "SELECT name, bin_location FROM products WHERE sku = ?",
            (sku,),
        ).fetchone()
        name, bin_location = product if product else ("(unknown product)", "UNASSIGNED")
        lines.append(PickLine(order_id, sku, name, bin_location, quantity))
    return lines
