---
id: REQ-034
title: Low-stock warning when placing an order
kind: feature
status: draft
repos: [storefront]
tags: [orders, inventory]
created: 2026-10-10
requested_by: dana.kowalski@example.com
sources: [uncited-ac.md]
---

# REQ-034: Low-stock warning when placing an order

## Summary
When an order's stock reservation leaves fewer than 10 units of a SKU, the API flags it so fulfilment can re-order
before orders start failing with out-of-stock errors.

## Acceptance criteria

### AC-1: When a reservation leaves fewer than 10 units, `POST /orders` returns `201` with header `X-Low-Stock` set to the SKU.
> "When a reservation leaves fewer than 10 units, `POST /orders` returns `201` with header" (source: uncited-ac.md)

### AC-2: When 10 or more units remain, the `X-Low-Stock` header is absent.
> "When 10 or more units remain, the header is absent." (source: uncited-ac.md)

### AC-3: Orders that would leave fewer than 3 units are rejected with `409` and must be approved by a supervisor.
> "Orders that drop stock below 3 units need supervisor sign-off before they are accepted." (source: uncited-ac.md)

### AC-4: At most one low-stock log line is written per SKU per hour.
> "At most one low-stock log line is written per SKU per hour." (source: uncited-ac.md)

## Non-functional requirements
- No extra call to the inventory service is made to obtain the remaining count.

## Out of scope
- Automatic re-ordering, email or Slack notifications, a dashboard.

## Assumptions
- The inventory service already returns `remaining` in its reservation response.

## Open questions
- None.
