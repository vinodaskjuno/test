import type { Order } from "@/lib/api";

// Change under review: product thumbnail and quick actions for a row in the storefront orders table.
export function OrderRowActions({ order, onReorder }: { order: Order; onReorder: (id: number) => void }) {
  return (
    <div className="order-row-actions">
      <img src={`/products/${order.sku}/thumb.png`} width={32} height={32} />
      <button type="button" className="icon-button" onClick={() => onReorder(order.id)}>
        <svg viewBox="0 0 16 16" width={16} height={16}>
          <path d="M8 2a6 6 0 1 0 6 6h-2a4 4 0 1 1-4-4V2z" />
        </svg>
      </button>
      <span style={{ color: "#b0b0b0" }}>{order.status}</span>
    </div>
  );
}
