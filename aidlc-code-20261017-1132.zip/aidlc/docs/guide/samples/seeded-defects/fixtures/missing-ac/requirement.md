---
id: REQ-031
title: Refund requests with manager approval
kind: feature
status: draft
repos: [storefront]
tags: [payments, orders]
created: 2026-10-09
requested_by: hannah.lindqvist@example.com
sources: [missing-ac.md]
---

# REQ-031: Refund requests with manager approval

## Summary
Support agents create refund requests for orders inside the storefront back-office instead of Slack. Managers
approve or reject them; approval triggers the refund at the payment provider. Every transition is recorded so
Finance can audit refunds.

## Acceptance criteria

### AC-1: A support agent can create a refund request for a paid order; it is stored as `pending`.
> "A support agent can create a refund request for a paid order; it is stored as `pending`." (source: missing-ac.md)

### AC-2: A request with `amount_cents` of 0 or above the order total returns `422`.
> "A request with `amount_cents` of 0 or above the order total returns `422`." (source: missing-ac.md)

### AC-3: Approving a pending request sets it to `approved` and calls the payment provider exactly once.
> "Approving a pending request sets it to `approved` and calls the payment provider exactly once." (source: missing-ac.md)

### AC-4: Rejecting a pending request requires a reason and sets it to `rejected`.
> "Rejecting a pending request requires a reason and sets it to `rejected`." (source: missing-ac.md)

### AC-5: Every transition is recorded with actor, timestamp and reason.
> "Every transition is recorded with actor, timestamp and reason." (source: missing-ac.md)

## Non-functional requirements
- The payment provider call is idempotent (request id as idempotency key).

## Out of scope
- Partial refunds across several requests, refunds to a different card, UI changes.

## Assumptions
- The gateway sets `X-Actor-Role` on every request.

## Open questions
- None.
