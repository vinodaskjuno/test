"""Relay order events from the transactional outbox to the message bus (change under review)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class OutboxMessage:
    id: int
    topic: str
    payload: bytes


class PublishError(Exception):
    """The bus rejected or failed to acknowledge the message."""


class Outbox(Protocol):
    def peek(self) -> OutboxMessage | None: ...

    def ack(self, message_id: int) -> None: ...


class Publisher(Protocol):
    def publish(self, message: OutboxMessage) -> None: ...


def drain_outbox(outbox: Outbox, publisher: Publisher) -> int:
    """Publish every pending outbox message in order; returns how many were sent."""
    sent = 0
    while (message := outbox.peek()) is not None:
        try:
            publisher.publish(message)
        except PublishError:
            # The message stays at the head of the outbox, so the next peek() returns it again.
            continue
        outbox.ack(message.id)
        sent += 1
    return sent
