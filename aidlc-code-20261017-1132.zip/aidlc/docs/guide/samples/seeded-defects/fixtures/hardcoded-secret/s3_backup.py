"""Nightly upload of the orders SQLite database to S3 (change under review)."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import boto3

# FAKE credentials for scanner evals only: they are not valid AWS keys and grant no access anywhere.
AWS_ACCESS_KEY_ID = "AKIAZ7FAKEFAKE2QWERT"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYFAKEFAKEKEY"
BUCKET = "storefront-orders-backups"


def backup_database(database_path: Path, *, region: str = "eu-west-2") -> str:
    """Upload ``database_path`` to the backup bucket and return the object key."""
    s3 = boto3.client(
        "s3",
        region_name=region,
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    )
    key = f"orders/{datetime.now(UTC):%Y/%m/%d}/orders.db"
    s3.upload_file(str(database_path), BUCKET, key)
    return key
