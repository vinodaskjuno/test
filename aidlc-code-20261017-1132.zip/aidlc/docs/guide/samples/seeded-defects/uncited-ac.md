# Low-stock warning when placing an order

| Field | Value |
|---|---|
| Type | Feature (seeded-defect eval: an acceptance criterion with an invalid citation) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Requested by | Dana Kowalski, Fulfilment Lead |
| Fixture | `fixtures/uncited-ac/requirement.md` (the requirement under V1 validation) |

## Context

When the inventory service reserves the last few units of a SKU, nobody notices until orders start failing with
`409` (out of stock). Fulfilment wants a warning when a reservation leaves fewer than 10 units, so they can
re-order in time.

## Users

- **Fulfilment lead:** receives low-stock warnings and re-orders stock.
- **Support agent:** sees a warning banner after placing an order that triggered low stock.

## Functional requirements

1. The inventory service's `POST /reservations` response includes `remaining` (units left after the reservation).
2. When `remaining` is below 10, `POST /orders` still returns `201`, and the response includes the header
   `X-Low-Stock: <sku>`.
3. A low-stock event is logged once per SKU per hour at `WARNING` level with the SKU and remaining count.

## Acceptance criteria

- **AC-1** When a reservation leaves fewer than 10 units, `POST /orders` returns `201` with header
  `X-Low-Stock` set to the SKU.
- **AC-2** When 10 or more units remain, the header is absent.
- **AC-3** At most one low-stock log line is written per SKU per hour.

## Non-functional requirements

- No extra call to the inventory service is made to obtain the remaining count.

## Out of scope

- Automatic re-ordering, email or Slack notifications, a dashboard.
