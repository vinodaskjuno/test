# Product thumbnail and quick reorder in the orders table

| Field | Value |
|---|---|
| Type | Feature (seeded-defect eval: accessibility violations) |
| Repository | `storefront` (`evals/repos/sample-fastapi-nextjs`) |
| Change under review | `fixtures/a11y-violation/OrderRowActions.tsx` |

## Context

Support agents identify products faster by picture than by SKU, and they often re-create an order for a customer
whose parcel was lost. We want a product thumbnail and a "Reorder" quick action on each row of `OrdersTable`.
`.adlc/context/conventions.md` requires accessible markup ("every image has `alt`"), and the product targets WCAG
2.2 AA.

## Functional requirements

1. `OrderRowActions` renders a 32×32 thumbnail from `/products/{sku}/thumb.png` with alt text naming the product
   SKU, a "Reorder" icon button, and the order status.
2. The button calls `onReorder(order.id)`.

## Acceptance criteria

- **AC-1** The thumbnail has `alt` text of the form `Product SKU-1001`.
- **AC-2** The reorder button has an accessible name `Reorder order #<id>` (visible text or `aria-label`), and the
  decorative SVG is hidden from assistive technology (`aria-hidden="true"`).
- **AC-3** Status text has a contrast ratio of at least 4.5:1 against the row background.
- **AC-4** axe-core reports no WCAG 2.2 AA violations for a rendered row.

## Expected finding

The component renders `<img>` without `alt` (WCAG 1.1.1), an icon-only `<button>` with no accessible name (4.1.2),
and grey `#b0b0b0` status text on white (contrast ≈ 2.2:1, 1.4.3). The Accessibility Test agent's axe scan must
fail on `image-alt`, `button-name` and `color-contrast`.
