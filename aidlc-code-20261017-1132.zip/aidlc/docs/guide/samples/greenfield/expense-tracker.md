# Expense tracker

| Field | Value |
|---|---|
| Type | New product (greenfield) |
| Target | New repository created from the `nextjs-fastapi` preset |
| Requested by | Marcus Oyelaran, Finance Operations Lead |
| Priority | P1 (replaces an email-based process before the Q1 audit) |

## Context

Employees currently claim expenses by emailing receipts and a spreadsheet to their manager, who forwards approved
claims to Finance. Claims get lost in inboxes, nobody can see the status of a claim, and the auditors flagged last
year that approvals cannot be traced to an approver. Finance reimburses about 1,200 claims a month across 400
employees.

We want a small internal web app where employees submit claims, managers approve or reject them, and Finance marks
them as paid and exports the month's paid claims to the payroll system as CSV.

## Users and roles

| Role | Who | Can |
|---|---|---|
| `employee` | Every staff member | Create, edit and submit their own claims; withdraw a submitted claim; see their own claims |
| `manager` | People leads (has direct reports in the directory) | Everything an employee can, plus approve or reject claims submitted by their direct reports |
| `finance` | Finance operations team | See all claims; mark approved claims as paid; export CSV |

Roles come from the identity provider's `groups` claim: `expenses-managers` → `manager`, `expenses-finance` →
`finance`; everyone else is `employee`. A user can hold several roles. The manager of a claimant is the
`manager_id` from the HR directory snapshot loaded nightly into the `people` table (loading it is a separate job;
this spec assumes the table exists and is populated).

## Functional requirements

### Sign-in
- OpenID Connect sign-in (Authorization Code + PKCE) against the company tenant of Microsoft Entra ID. Issuer,
  client id and client secret come from environment variables; nothing is hard-coded.
- The web app stores the session in an HTTP-only, `Secure`, `SameSite=Lax` cookie. The API accepts only
  `Authorization: Bearer <access token>` and validates signature, issuer, audience and expiry.

### Claims
- A claim has: `id`, `claimant_id`, `title`, `category` (`travel`, `meals`, `equipment`, `training`, `other`),
  `amount_cents` (> 0, ≤ 500,000), `currency` (`USD`, `EUR`, `GBP`), `incurred_on` (date, not in the future,
  not older than 90 days), `description` (≤ 1,000 chars), `receipt` (PDF/JPEG/PNG ≤ 5 MB), `status`, timestamps.
- State machine:

```
draft --submit--> submitted --approve--> approved --mark_paid--> paid
  ^                   |  \--reject (reason required)--> rejected
  |                   \--withdraw--> draft
  \------------------- edit (draft only)
```

- Only the claimant may edit, submit or withdraw. Only the claimant's manager may approve or reject; a manager can
  never approve their own claim (it goes to their own manager). Only `finance` may mark as paid.
- Every transition is recorded in a `claim_events` table (who, when, from, to, reason).

### Finance export
- `GET /exports/paid.csv?month=2026-09` (finance only) returns paid claims whose `paid_at` falls in that month,
  columns `claim_id,employee_id,employee_name,category,amount,currency,incurred_on,approved_by,paid_at`, amounts
  as decimals with two places, UTF-8 with a header row, RFC 4180 quoting.

### Web pages
- "My claims" (list + status chips), "New claim" form with receipt upload, "Approvals" (managers: claims awaiting
  my decision), "Finance" (approved claims, mark paid, monthly export button).

## Acceptance criteria

- **AC-1** An unauthenticated request to any API endpoint except `/health` returns `401`; a request with an expired
  or wrongly-signed token returns `401`.
- **AC-2** A signed-in employee can create a draft claim, attach a receipt and submit it; the claim's status becomes
  `submitted` and a `claim_events` row records the transition.
- **AC-3** Creating a claim with `amount_cents` ≤ 0 or > 500,000, a future `incurred_on`, or a receipt over 5 MB
  or of another type returns `422` and stores nothing.
- **AC-4** The claimant's manager can approve a submitted claim; anyone else (including finance and other
  managers) receives `403`.
- **AC-5** Rejecting requires a non-empty reason; the reason is shown to the claimant on the claim page.
- **AC-6** A manager's own claim is routed to their manager; the manager cannot approve it themselves (`403`).
- **AC-7** Only `finance` can move an `approved` claim to `paid`; transitions not in the state machine return `409`.
- **AC-8** The claimant can withdraw a `submitted` claim back to `draft`; approved, rejected and paid claims
  cannot be withdrawn (`409`).
- **AC-9** `GET /exports/paid.csv?month=2026-09` as finance returns a CSV with exactly the listed header and one row
  per claim paid in September 2026; as any other role it returns `403`.
- **AC-10** An employee sees only their own claims in "My claims" and receives `404` for another person's claim id.
- **AC-11** Every state change appears in the claim's history panel with actor and timestamp.

## Non-functional requirements

- **Security:** OWASP ASVS L2 for authentication and access control; authorisation is enforced in the API, not
  only hidden in the UI. Receipts are stored outside the web root with random object keys.
- **Audit:** `claim_events` rows are append-only (no update or delete endpoint) and retained for 7 years.
- **Privacy:** receipts and names are personal data; logs contain claim ids only, never names, emails or amounts.
- **Accessibility:** WCAG 2.2 AA; status chips do not rely on colour alone.
- **Performance:** the Approvals page loads in < 1 s p95 with 200 pending claims.

## Out of scope

- Multi-currency conversion, mileage calculators, corporate card feeds, OCR of receipts.
- Loading the HR directory into `people` (existing nightly job).
- Pushing the CSV to the payroll system (Finance uploads it manually).
