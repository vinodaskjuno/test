# Todo app

| Field | Value |
|---|---|
| Type | New product (greenfield) |
| Target | New repository created from the `nextjs-fastapi` preset |
| Requested by | Priya Natarajan, Product Manager, Internal Tools |
| Priority | P2 |

## Context

The Internal Tools team runs a weekly "tooling clinic" in which new joiners build a small product with the AIDLC
platform. The team wants a reference todo app that is small enough to review in one sitting, yet still exercises
every layer of the standard stack: a Next.js front end, a FastAPI service, PostgreSQL with migrations, and tests at
each layer. The app becomes the template that later clinic exercises extend (labels, sharing, reminders).

Today people track clinic tasks in a shared spreadsheet. Rows get overwritten, there is no history and nobody can
tell which items are finished.

## Users

- **Clinic participant:** creates, edits, completes and deletes their own todo items during the session.
- **Clinic facilitator:** opens the app on a projector to walk through the code and the running UI.

## Functional requirements

### Data model

A todo has: `id` (integer, server-assigned), `title` (1–200 characters, required, trimmed), `notes` (optional,
up to 2,000 characters), `due_date` (optional ISO-8601 date), `completed` (boolean, default `false`),
`created_at` and `updated_at` (UTC timestamps set by the server).

### API (FastAPI, `backend/`)

| Method | Path | Behaviour |
|---|---|---|
| `GET` | `/todos` | List todos. Optional `completed=true|false` filter. Sorted by `due_date` ascending (nulls last), then `created_at` |
| `POST` | `/todos` | Create a todo; returns `201` with the stored item |
| `GET` | `/todos/{id}` | Return one todo or `404` |
| `PATCH` | `/todos/{id}` | Partial update of `title`, `notes`, `due_date`, `completed`; returns the updated item |
| `DELETE` | `/todos/{id}` | Delete; returns `204`, or `404` when it does not exist |
| `GET` | `/health` | Liveness: `{"status": "ok"}` |

Validation errors return `422` with FastAPI's standard error body. The schema is created and evolved with Alembic
migrations; the service never creates tables at start-up.

### Web (Next.js App Router, `frontend/`)

- `/` shows the list: title, due date (formatted `12 Oct 2026`), and a checkbox that toggles `completed`.
  Overdue, incomplete items show an "Overdue" badge.
- A form above the list adds a todo (title required, due date optional). The new item appears without a full
  page reload.
- Each row has "Edit" (inline title/notes/due date editing) and "Delete" (with a confirmation dialog).
- Filter tabs: All / Active / Completed. The selected tab is reflected in the URL (`?filter=active`).
- Empty state: "Nothing to do yet. Add your first todo above."

## Acceptance criteria

- **AC-1** `POST /todos` with `{"title": "Buy milk"}` returns `201` and a body with an integer `id`,
  `completed: false` and server-set `created_at`/`updated_at`.
- **AC-2** `POST /todos` with an empty or whitespace-only title, or a title longer than 200 characters, returns
  `422` and stores nothing.
- **AC-3** `GET /todos?completed=false` returns only incomplete todos, ordered by `due_date` ascending with
  undated items last.
- **AC-4** `PATCH /todos/{id}` with `{"completed": true}` changes only `completed` and `updated_at`; other fields
  are unchanged.
- **AC-5** `DELETE /todos/{id}` returns `204`; a second `DELETE` or a `GET` of the same id returns `404`.
- **AC-6** Data survives an API restart (stored in PostgreSQL; schema created by an Alembic migration).
- **AC-7** On the web list, submitting the form with a title adds the item to the top of the "Active" tab
  without a full page reload.
- **AC-8** Ticking an item's checkbox moves it from "Active" to "Completed" and persists after a page reload.
- **AC-9** "Delete" asks for confirmation; cancelling keeps the item, confirming removes it.
- **AC-10** An incomplete todo whose due date is before today shows an "Overdue" badge; completed items never do.
- **AC-11** With no todos, the list shows the empty-state message.

## Non-functional requirements

- **Accessibility:** WCAG 2.2 AA. Every form control has a visible label; the checkbox is keyboard operable; the
  confirmation dialog traps focus and returns it to the "Delete" button when closed.
- **Performance:** `GET /todos` p95 < 150 ms with 1,000 todos on a developer laptop.
- **Testing:** pytest for the API (≥ 85% line coverage of `backend/`), vitest for components, one Playwright
  test covering add → complete → delete.
- **Security:** no secrets in the repository; database URL from the `DATABASE_URL` environment variable.

## Out of scope

- Sharing todos, labels, reminders, notifications, attachments.
- Mobile apps and offline support.
- Deployment to any shared environment (preview environments only).

## Open question

- Do todos belong to an individual signed-in user, or is there one shared list per clinic session? The
  spreadsheet is shared today, but participants have asked for "their own" list. Until this is decided the API has
  no notion of an owner.
