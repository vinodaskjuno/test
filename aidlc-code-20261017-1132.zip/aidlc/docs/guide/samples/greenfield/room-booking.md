# Meeting room booking

| Field | Value |
|---|---|
| Type | New product (greenfield) |
| Target | New repository created from the `nextjs-fastapi` preset |
| Requested by | Elena Varga, Workplace Experience |
| Attachments | `room-booking.openapi.yaml` (API contract), `room-booking-mockup.png` (booking grid wireframe) |
| Design | Figma: https://www.figma.com/design/AbCdEf123456/Room-Booking?node-id=12-34 |

## Context

The London and Lisbon offices have 46 bookable rooms between them. Rooms are booked today through calendar
resources, which do not show capacity or equipment, and people regularly book a 12-seat room for a one-to-one.
Workplace Experience wants a lightweight booking tool: find a free room that fits the meeting, book it in two
clicks, and cancel it if plans change. Peak usage is Monday 08:45–09:15 local time, when about 50 availability
searches per second arrive as people plan the week.

The API contract has been agreed with the Workplace team and is attached as `room-booking.openapi.yaml`; the
implementation must conform to it. The visual design is in Figma (link above); `room-booking-mockup.png` is a
static export of the booking grid for reviewers without Figma access.

## Users

- **Employee (booker):** searches for a room by time, size and equipment, books it, cancels their own bookings.
- **Workplace coordinator:** same as an employee, plus can cancel any booking (e.g. for building maintenance).
- **Assistive-technology users:** screen-reader and keyboard-only users must be able to complete every task.

## Functional requirements

### Rooms and availability
- A room has `id`, `name`, `site` (`london`, `lisbon`), `floor`, `capacity` (1–40), `equipment` (subset of
  `display`, `video`, `whiteboard`, `phone`) and `accessible` (step-free access).
- `GET /rooms` lists rooms, filterable by `site`, `min_capacity` and `equipment` (all listed items required).
- `GET /rooms/availability?site=&date=&start=&end=&min_capacity=&equipment=` returns, for each matching room,
  its free intervals between 07:00 and 20:00 local site time on that date, in 15-minute granularity.

### Bookings
- `POST /bookings` books a room for `start`/`end` (same local date, 15-minute boundaries, 15 min – 4 h, not in the
  past, at most 60 days ahead) with a `title` (1–120 chars) and `attendees` (1–capacity).
- Double booking is impossible, including under concurrent requests: an overlapping request returns `409` with the
  conflicting interval.
- `DELETE /bookings/{id}` cancels a booking (owner or coordinator only; `204`). Cancelled bookings free the slot
  immediately.
- `GET /bookings?mine=true` lists the caller's upcoming bookings.

### Web
- Booking grid as in the mockup: rows = rooms (name, capacity, equipment icons), columns = 30-minute slots,
  booked slots shaded and labelled "Booked", free slots are buttons. Filters for site, date, size and equipment
  sit above the grid.
- Selecting a free slot opens a booking dialog pre-filled with the time; confirming shows a success toast with
  the room and time.
- "My bookings" page lists upcoming bookings with a "Cancel" action and confirmation.

## Acceptance criteria

- **AC-1** `GET /rooms?site=london&min_capacity=6&equipment=video` returns only London rooms with capacity ≥ 6
  that have video equipment, matching the `Room` schema in `room-booking.openapi.yaml`.
- **AC-2** `GET /rooms/availability` for a date returns free intervals per room, excludes booked intervals, and
  aligns every interval to 15-minute boundaries within 07:00–20:00 site time.
- **AC-3** `POST /bookings` with a valid body returns `201` and a `Booking` whose `status` is `confirmed`.
- **AC-4** Two concurrent `POST /bookings` for overlapping intervals in the same room result in exactly one `201`
  and one `409`; the `409` body names the conflicting interval.
- **AC-5** Bookings that are in the past, longer than 4 h, not on 15-minute boundaries, more than 60 days ahead or
  with more attendees than the room's capacity return `422`.
- **AC-6** `DELETE /bookings/{id}` by the owner or a coordinator returns `204` and the slot appears free in the
  next availability response; by anyone else it returns `403`.
- **AC-7** The served OpenAPI document matches `room-booking.openapi.yaml` (paths, operation ids, schemas and
  required fields).
- **AC-8** In the web grid, a free slot can be booked with the keyboard alone (Tab to slot, Enter, fill title,
  Enter) and the success toast is announced by screen readers (`role="status"`).
- **AC-9** The grid, dialog and "My bookings" page have no WCAG 2.2 AA violations in an axe-core scan in light and
  dark themes.
- **AC-10** Booked slots are distinguishable without colour (text label "Booked" and pattern), per the Figma frame.

## Non-functional requirements

- **Performance:** availability search p95 < 300 ms and p99 < 800 ms at a sustained 50 requests/s for 5 minutes,
  with 46 rooms and 10,000 future bookings in the database; zero errors in the run.
- **Accessibility:** WCAG 2.2 AA, including 2.4.11 Focus Not Obscured, 2.5.8 Target Size (minimum 24×24 px) and
  visible focus on grid cells.
- **Correctness under concurrency:** overlap prevention enforced by the database (exclusion constraint on
  `tstzrange` per room), not only by application checks.
- **Time zones:** times stored in UTC; displayed and validated in the room's site time zone (Europe/London,
  Europe/Lisbon), including DST change days.

## Out of scope

- Recurring bookings, calendar (Exchange/Google) sync, catering, visitor passes, check-in sensors.
- Room administration UI (rooms are seeded by a migration from the Workplace inventory).

## Repo hints

- Preset layout: FastAPI in `backend/`, Next.js in `frontend/`, Alembic migrations in `backend/alembic`.
