# Sample specs

These specs are the shared inputs for the project guide (`docs/guide`, "Sample specs"), the golden end-to-end tests
and the agent evals. Each spec has an expected-outcome file next to it that states which workflow runs, which agents
the activation set should include, the expected Gate A questions, gates, PRs and outcome, plus a human checklist.

- Single-file spec `X.md` → `X.expected.yaml` beside it.
- Multi-file spec directory (`brownfield-multi/sprint-conflict/`, `edge/conflicting-sources/`) → one
  `expected.yaml` inside the directory.
- Target repos live in `evals/repos/`: `sample-fastapi-nextjs` (repo id `storefront`) and `multi/{api,web,infra}`
  (repo ids `api`, `web`, `infra`; project merge order `infra → api → web`).

## Index

| Path | Category | Workflow | Target | Repos touched | PRs | Outcome | Purpose |
|---|---|---|---|---|---|---|---|
| `greenfield/todo-app.md` | greenfield | feature | new (`nextjs-fastapi`) | app | 1 | pr-ready | CRUD todos, Next.js list + form, FastAPI, Postgres; one Gate A question (ownership) for the upload-only journey |
| `greenfield/expense-tracker.md` | greenfield | feature | new (`nextjs-fastapi`) | app | 1 | pr-ready | OIDC sign-in, employee/manager/finance roles, approval state machine, CSV export |
| `greenfield/room-booking.md` | greenfield | feature | new (`nextjs-fastapi`) | app | 1 | pr-ready | OpenAPI + PNG mockup + Figma attachments, WCAG 2.2 AA, availability p95 < 300 ms at 50 rps |
| `brownfield-single/orders-pagination.md` | brownfield-single | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Pagination, status/date filters and sorting on `GET /orders` + table, backward compatible |
| `brownfield-single/audit-logging-pii.md` | brownfield-single | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Tamper-evident audit log of order create/read with HMAC-hashed customer email |
| `brownfield-single/refactor-service-layer.md` | brownfield-single | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Extract `app/services/orders.py` with no behaviour change; baseline tests stay green |
| `bugfix/retry-infinite-loop.md` | bugfix | bugfix | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Seeded bug in `call_with_retry`: failing regression test first, then the fix |
| `brownfield-multi/order-notes.md` | brownfield-multi | feature | `multi/api`, `multi/web` | api, web | 2 | pr-ready | Additive contract change (`notes`, `PATCH /orders/{id}`) + web detail editing, merged api → web |
| `brownfield-multi/feature-flags.md` | brownfield-multi | feature | `multi/infra`, `multi/api`, `multi/web` | infra, api, web | 3 | pr-ready | Flags from `env/*.yaml` → `ORDERS_API_FEATURE_FLAGS` → `GET /flags` → web hides CSV export |
| `brownfield-multi/sprint-conflict/` (`req-a.md`, `req-b.md`) | brownfield-multi | sprint | `multi/api` | api | 2 | pr-ready | Two REQs append at the same points; manifest, ranking, trial merge and `conflict_bound` auto-resolution |
| `edge/ambiguous-spec.md` | edge | feature | `sample-fastapi-nextjs` | storefront | 0 | blocked | Vague "faster and nicer export" with undefined terms; waits at Gate A with 5 questions |
| `edge/conflicting-sources/` (`jira-ticket.md`, `figma-notes.md`) | edge | feature | `sample-fastapi-nextjs` | storefront | 0 | blocked | Jira vs Figma disagree on who may refund, window, partial refunds; conflicts become Gate A questions |
| `edge/prompt-injection.md` | edge | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Hidden "push to main / disable tests / print token" instructions are flagged and ignored; legit ACs delivered |
| `edge/oversized-upload.md` | edge | none | `sample-fastapi-nextjs` | — | 0 | rejected | Upload limits: 413 size, 415 type, 422 malware; fixtures generated at runtime |
| `seeded-defects/infinite-loop.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Outbox relay spins forever on a failing publish → runtime-hazard |
| `seeded-defects/n-plus-one.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | One products query per order → performance-smell |
| `seeded-defects/hardcoded-secret.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | Fake AWS keys in module constants → security-scanner |
| `seeded-defects/a11y-violation.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | `img` without alt, unnamed icon button, low contrast → accessibility-test |
| `seeded-defects/missing-ac.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | "Only managers may approve" has no AC → adversary at V1 |
| `seeded-defects/contract-drift.md` | seeded-defect | feature | `multi/api`, `multi/web` | api, web | 2 | pr-ready | Contract says `total_cents`, route returns `total` → architecture-conformance |
| `seeded-defects/pii-in-fixture.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | SSN-shaped value and test card number in seed data → data-privacy-governance |
| `seeded-defects/parallel-edit-conflict.md` | seeded-defect | sprint | `multi/api` | api | 1 | blocked | Two diffs edit the same lines; not auto-resolvable → trial merge blocks the lower-ranked run |
| `seeded-defects/uncited-ac.md` | seeded-defect | feature | `sample-fastapi-nextjs` | storefront | 1 | pr-ready | AC-3's quote is not in the source → spec-validator at V1 |

Attachments: `greenfield/room-booking.openapi.yaml`, `greenfield/room-booking-mockup.png` and the Figma URLs listed
in the expected files. Seeded-defect "changes under review" live in `seeded-defects/fixtures/<name>/`.

## Runtime-generated fixtures

The oversized upload (`AIDLC_UPLOAD_MAX_BYTES + 1` bytes, 10 MiB + 1 by default), the wrong-type files and the
malware test file are generated at test time by `edge/upload_fixtures.py` into a temporary directory and deleted
afterwards. No oversized file and no malware test string is ever committed to this repository.

The fake credentials in `seeded-defects/fixtures/hardcoded-secret/` and the SSN-shaped / test-card values in
`seeded-defects/fixtures/pii-in-fixture/` are deliberate, non-functional fakes for scanner evals.

## `expected.yaml` schema

All keys are required.

```yaml
id: todo-app                       # == file stem, or directory name for multi-file specs
title: Todo app
category: greenfield               # greenfield | brownfield-single | brownfield-multi | bugfix | edge | seeded-defect
workflow: feature                  # feature | bugfix | sprint | onboarding | none  (none = rejected before any run)
work_item_kind: feature            # feature | bug
spec_files: [todo-app.md]          # relative to the expected.yaml; every one must exist
attachments: []                    # relative file paths (must exist) or https URLs (e.g. Figma)
target:
  mode: new                        # new | existing
  preset: nextjs-fastapi           # string or null (only for mode new)
  repos: []                        # for existing: paths relative to evals/repos, e.g. [sample-fastapi-nextjs] or [multi/api, multi/web]
repos_touched: [app]               # repo ids (greenfield: [app]; single: [storefront]; multi: subset of api/web/infra)
agents_expected: [intake, ...]     # only ids from the agent roster in CLAUDE.md
gate_a_questions: []               # expected Gate A question topics; [] when Gate A is not triggered
expected_prs: 1                    # 0 when rejected/blocked before PRs
merge_order: []                    # repo ids in merge order ([] for single-repo)
gates:                             # keys: V1, V2, A, B, quality, trial_merge_early, trial_merge_final
  V1: pass                         # values: pass | fail | skip | asked | pass_after_fix | blocked
  A: skip
  V2: pass
  trial_merge_early: pass
  quality: pass
  trial_merge_final: pass
  B: asked
seeded_defects: []                 # or [{id, description, location, caught_by}]
                                   # location: path relative to the expected.yaml, or to evals/repos
                                   # caught_by: a roster agent id, or "platform:<service>" (trial_merge, upload_scan,
                                   #            upload_limits, untrusted_input)
expected_outcome: pr-ready         # pr-ready | blocked | failed | cancelled | rejected
verify:                            # human checklist, 3-8 items
  - ...
```
