# Update order status

| Field | Value |
|---|---|
| Type | Feature (sprint item 2 of 2, rank 2) |
| Repository | `api` (`evals/repos/multi/api`) |
| Requested by | Dana Kowalski, Fulfilment Lead |
| Sprint | Orders sprint 42 (runs together with "Cancel an order") |

## Context

The warehouse marks orders as paid and shipped in the ERP, and the orders API never learns about it: every order
stays `pending` in `GET /orders`, so the fulfilment dashboard is useless. The ERP integration team will call a
status endpoint whenever an order moves forward. Cancellation is handled by a separate endpoint in the same sprint
("Cancel an order"), so this endpoint must not cancel.

## Users

- **ERP integration (machine client):** pushes status changes.
- **Fulfilment lead:** sees accurate statuses on the dashboard.

## Functional requirements

1. New endpoint `PATCH /orders/{order_id}/status` with body `{"status": "paid" | "shipped"}`.
2. Allowed transitions: `pending → paid`, `paid → shipped`. Setting the current status again is a no-op `200`.
3. Any other transition (e.g. `pending → shipped`, `shipped → paid`, anything from `cancelled`) returns `409` with
   detail `cannot change order {id} from {current} to {requested}`.
4. `"status": "cancelled"` or `"pending"` in the body returns `422` (the schema only allows `paid` and `shipped`;
   cancellation uses `POST /orders/{id}/cancel`).
5. Unknown id: `404 order {id} not found`.
6. Implementation: append the route **at the end** of `app/routes/orders.py`; add `OrderStore.set_status(order_id,
   status)` at the end of `app/store.py`; add an `OrderStatusUpdate` model at the end of `app/models.py`.
7. CORS: add `PATCH` to `allow_methods` in `app/main.py`.
8. `openapi.yaml`: add the path `/orders/{order_id}/status` (`operationId: updateOrderStatus`) after
   `/orders/{order_id}` and the `OrderStatusUpdate` schema. `tests/test_contract.py` must pass.

## Acceptance criteria

- **AC-1** `PATCH /orders/{id}/status` with `{"status": "paid"}` on a `pending` order returns `200` with
  `"status": "paid"`.
- **AC-2** `{"status": "shipped"}` on a `paid` order returns `200` with `"status": "shipped"`.
- **AC-3** `{"status": "shipped"}` on a `pending` order returns `409` with detail
  `cannot change order {id} from pending to shipped`; the status is unchanged.
- **AC-4** `{"status": "cancelled"}` returns `422`.
- **AC-5** Repeating the current status returns `200` and changes nothing.
- **AC-6** An unknown id returns `404` with detail `order {id} not found`.
- **AC-7** `openapi.yaml` declares the new path and schema; `tests/test_contract.py` and all existing tests pass.

## Non-functional requirements

- Thread-safe store update (store lock).
- Contract updated in the same PR, additive only (conventions).

## Out of scope

- Authentication of the ERP client (handled by the gateway), status history, webhooks.

## Sprint note

"Cancel an order" (`req-a.md`) is ranked above this REQ and appends to the same files at the same points.
