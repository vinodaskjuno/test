# Cancel an order

| Field | Value |
|---|---|
| Type | Feature (sprint item 1 of 2, rank 1) |
| Repository | `api` (`evals/repos/multi/api`) |
| Requested by | Grace Mbeki, Customer Support Team Lead |
| Sprint | Orders sprint 42 (runs together with "Update order status") |

## Context

Customers regularly phone to cancel an order before it ships. Support agents currently ask the ERP team to cancel
by hand, which takes up to a day, and orders are sometimes shipped in the meantime. We want an explicit cancel
action in the orders API so agents (and later the web app) can cancel immediately.

## Users

- **Support agent:** cancels an order on the customer's request.
- **ERP sync job:** reads the new `cancelled` status from `GET /orders`.

## Functional requirements

1. New endpoint `POST /orders/{order_id}/cancel` with an optional body `{"reason": string}` (≤ 500 characters).
2. Allowed when the order's status is `pending` or `paid`; the status becomes `cancelled`.
3. Cancelling an already `cancelled` order is idempotent: `200` with the unchanged order.
4. A `shipped` order cannot be cancelled: `409` with detail `order {id} has shipped and cannot be cancelled`.
5. Unknown id: `404 order {id} not found` (same wording as `GET /orders/{order_id}`).
6. Implementation: append the route **at the end** of `app/routes/orders.py`; add `OrderStore.cancel(order_id)`
   at the end of `app/store.py`; add an `OrderCancel` request model at the end of `app/models.py`.
7. `openapi.yaml`: add the path `/orders/{order_id}/cancel` (`operationId: cancelOrder`) after
   `/orders/{order_id}`, and the `OrderCancel` schema. `tests/test_contract.py` must pass.
8. CORS already allows `POST`; no change needed.

## Acceptance criteria

- **AC-1** `POST /orders/{id}/cancel` on a `pending` order returns `200` and `"status": "cancelled"`; a following
  `GET /orders/{id}` shows `cancelled`.
- **AC-2** The same on a `paid` order succeeds.
- **AC-3** On a `shipped` order it returns `409` with detail `order {id} has shipped and cannot be cancelled`, and
  the status is unchanged.
- **AC-4** Cancelling an already cancelled order returns `200` and leaves it `cancelled`.
- **AC-5** An unknown id returns `404` with detail `order {id} not found`.
- **AC-6** A `reason` longer than 500 characters returns `422`.
- **AC-7** `openapi.yaml` declares the new path and schema; `tests/test_contract.py` and all existing tests pass.

## Non-functional requirements

- Thread-safe: `OrderStore.cancel` takes the store lock like the other methods.
- Follows `api/.adlc/context/conventions.md` (contract updated in the same PR, additive only).

## Out of scope

- Refunds, notifying the customer, a web UI button (separate REQ).

## Sprint note

"Update order status" (`req-b.md`) runs in the same sprint and also appends a route at the end of
`app/routes/orders.py`. This REQ is ranked first.
