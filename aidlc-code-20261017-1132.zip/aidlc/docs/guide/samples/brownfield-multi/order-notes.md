# Order notes

| Field | Value |
|---|---|
| Type | Cross-repo feature (API contract change + web UI) |
| Repositories | `api` (`evals/repos/multi/api`), `web` (`evals/repos/multi/web`) |
| Requested by | Grace Mbeki, Customer Support Team Lead |
| Priority | P2 |

## Context

Support agents handle delivery exceptions ("leave with neighbour at no. 12", "customer will collect on Friday")
by email and sticky notes, so the next agent who opens the order does not see them. We want a free-text `notes`
field on each order that agents can read and edit on the order detail page.

The orders API publishes its contract in `api/openapi.yaml`; the web repo mirrors it in `web/lib/types.ts` and is
built against it. `api/.adlc/context/conventions.md` requires every API change to update `openapi.yaml` in the same
PR, additive changes only, with new optional fields defaulting to `null` so existing clients keep working.

## Users

- **Support agent:** reads and edits notes on an order.
- **Fulfilment lead:** reads notes before dispatch.
- **Other API clients** (ERP sync, reporting): must keep working without changes.

## Functional requirements

### API (`api` repo)
1. `Order` gains an optional `notes: string | null` (max 2,000 characters), default `null`, returned by
   `GET /orders`, `GET /orders/{order_id}` and `POST /orders`.
2. `OrderCreate` accepts an optional `notes`.
3. New endpoint `PATCH /orders/{order_id}` with body `OrderUpdate {notes: string | null}` (only `notes` is
   updatable in this change). Sending `null` or an empty/whitespace-only string clears the notes (stored as
   `null`). Leading/trailing whitespace is trimmed. Returns the updated `Order`; `404` for an unknown id; `422` when
   `notes` exceeds 2,000 characters or unknown fields are sent.
4. The new route is appended at the end of `app/routes/orders.py`; `OrderStore` gains `update_notes(order_id,
   notes)`.
5. `openapi.yaml`: add `notes` to `Order` and `OrderCreate` (not required), add the `OrderUpdate` schema and the
   `patch` operation (`operationId: updateOrder`) under `/orders/{order_id}`; bump `info.version` to `1.9.0` (and
   the FastAPI app version in `app/main.py`). `tests/test_contract.py` must pass.
6. CORS: add `PATCH` to `allow_methods` in `app/main.py` so the browser can call it.

### Web (`web` repo)
1. `lib/types.ts`: add `notes: string | null` to `Order` (mirrors the contract).
2. `lib/api.ts`: add `updateOrderNotes(id, notes)` that `PATCH`es `/orders/{id}` and returns the `Order`.
3. `components/OrderDetail.tsx`: a "Notes" entry in the definition list showing the notes (preserving line
   breaks) or "No notes" in muted text.
4. On `app/orders/[id]/page.tsx`, an "Edit notes" control opens a labelled `<textarea>` (2,000-character limit
   with a live remaining-characters counter) with "Save" and "Cancel". Save calls the API through a server action
   and re-renders the detail; errors show an inline message with `role="alert"`.
5. `components/OrdersTable.tsx` shows a small "has notes" indicator (icon with visually hidden text "Has notes")
   in the Customer cell when `notes` is non-empty.

## Acceptance criteria

- **AC-1** `GET /orders/{id}` for an order created without notes returns `"notes": null`.
- **AC-2** `POST /orders` with `"notes": "Call before delivery"` returns `201` with that note stored.
- **AC-3** `PATCH /orders/{id}` with `{"notes": "  Leave with neighbour  "}` returns `200` and
  `"notes": "Leave with neighbour"`; a subsequent `GET` returns the same value.
- **AC-4** `PATCH /orders/{id}` with `{"notes": ""}` or `{"notes": null}` clears the notes to `null`.
- **AC-5** `PATCH` with 2,001 characters, or with an unknown field such as `{"status": "paid"}`, returns `422` and
  changes nothing; `PATCH` for an unknown id returns `404`.
- **AC-6** `openapi.yaml` declares `notes` on `Order` and `OrderCreate` (not required), the `OrderUpdate` schema
  and `PATCH /orders/{order_id}`; `tests/test_contract.py` passes; `info.version` is `1.9.0`.
- **AC-7** Existing API clients are unaffected: every pre-existing test in `api/tests/` passes, and `notes` is not
  in any `required` list.
- **AC-8** The order detail page shows the notes, or "No notes" when empty.
- **AC-9** Editing notes and pressing "Save" persists them and the page shows the new text; "Cancel" discards edits.
- **AC-10** The textarea has a visible label "Notes", the counter is announced politely (`aria-live="polite"`), and
  a failed save shows an error with `role="alert"`.
- **AC-11** The orders table shows the "Has notes" indicator only for orders with non-empty notes.
- **AC-12** `web/lib/types.ts` `Order` matches the `Order` schema in `api/openapi.yaml` field for field.

## Non-functional requirements

- Backward compatible, additive contract change only (no field renamed or removed, nothing newly required).
- Notes are rendered as text, never as HTML (no `dangerouslySetInnerHTML`), to prevent stored XSS.
- WCAG 2.2 AA on the detail page.
- Merge order: the `api` PR merges first, then `web` (the web build depends on the new contract).

## Out of scope

- Note history/audit, mentions, rich text, attachments, editing other order fields.
- The `infra` repo (no configuration change is needed).
