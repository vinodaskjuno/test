# Feature flag service for the orders platform

| Field | Value |
|---|---|
| Type | Cross-repo feature (infrastructure + API + web) |
| Repositories | `infra` (`evals/repos/multi/infra`), `api` (`evals/repos/multi/api`), `web` (`evals/repos/multi/web`) |
| Requested by | Arjun Mehta, Engineering Manager, Orders Platform |
| Priority | P1 (needed to release CSV export to staging without exposing it in prod) |

## Context

The `infra` repo already declares per-environment flags in `env/{dev,staging,prod}.yaml` under `feature_flags:`
(`orders_csv_export`, `orders_bulk_status`), and `tests/test_env_config.py` enforces that every environment declares
the same flags as booleans. Nothing reads them: they are documentation only, so features are released by
deploying or not deploying code. Product wants the CSV export (finished in the web app branch, not released) to be
switched on in dev and staging but stay off in prod until Finance signs off.

This change wires the existing flag map end to end: infra passes the flags to the API as an environment variable,
the API serves them, and the web app shows the CSV export only when its flag is on.

## Users

- **Release manager:** flips a flag per environment with a one-line infra PR, no application deploy.
- **Support agents in staging:** see and use "Export CSV" on the orders list.
- **Support agents in prod:** do not see it until the flag is enabled.

## Functional requirements

### infra
1. The Helm values for `orders-api` gain an environment variable `ORDERS_API_FEATURE_FLAGS` containing the
   environment's `feature_flags` map as compact JSON, e.g. `{"orders_csv_export":true,"orders_bulk_status":false}`.
   Each `env/<environment>.yaml` sets `api.env.ORDERS_API_FEATURE_FLAGS` to the JSON of its own `feature_flags`
   map (dev and staging `orders_csv_export: true`, prod `false`, as today).
2. `helm/orders-api/values.yaml` defaults `ORDERS_API_FEATURE_FLAGS` to `'{}'`.
3. `tests/test_env_config.py` gains a check that, for every environment, `api.env.ORDERS_API_FEATURE_FLAGS` parses
   as JSON and equals that file's `feature_flags` map (so the two can never drift).

### api
1. `app/settings.py`: `feature_flags: dict[str, bool] = {}` (read from `ORDERS_API_FEATURE_FLAGS`; pydantic-settings
   parses the JSON). Invalid JSON or non-boolean values fail start-up with a clear error.
2. New `GET /flags` returning `{"flags": {"orders_csv_export": true, ...}}` with
   `Cache-Control: max-age=30`. Implemented in a new `app/routes/flags.py` router registered in `app/main.py`.
3. `openapi.yaml`: add `/flags` (`operationId: listFlags`) and a `FeatureFlags` schema; bump `info.version` to
   `1.9.0`. `tests/test_contract.py` must pass.

### web
1. `lib/types.ts`: `FeatureFlags` type; `lib/api.ts`: `getFlags()` returning the map (an API error or timeout
   yields an empty map — flags fail closed).
2. `app/orders/page.tsx` fetches orders and flags in parallel and renders an "Export CSV" link above the table only
   when `flags.orders_csv_export === true`.
3. The export itself is a route handler `app/orders/export/route.ts` that returns `text/csv` with header
   `id,customer_name,total,status,created_at` built from `listOrders()`; when the flag is off it returns `404`.

## Acceptance criteria

- **AC-1** In each of `env/dev.yaml`, `env/staging.yaml` and `env/prod.yaml`, `api.env.ORDERS_API_FEATURE_FLAGS`
  is valid JSON equal to the file's `feature_flags` map; the new infra test enforces it and the existing infra tests
  still pass.
- **AC-2** `prod.yaml` keeps `orders_csv_export: false`; dev and staging keep `true`.
- **AC-3** With `ORDERS_API_FEATURE_FLAGS='{"orders_csv_export": true}'`, `GET /flags` returns
  `{"flags": {"orders_csv_export": true}}` and a `Cache-Control: max-age=30` header.
- **AC-4** With the variable unset, `GET /flags` returns `{"flags": {}}`.
- **AC-5** With `ORDERS_API_FEATURE_FLAGS='{"orders_csv_export": "yes"}'` or invalid JSON, `create_app()` raises a
  settings validation error.
- **AC-6** `api/openapi.yaml` declares `GET /flags` and the `FeatureFlags` schema; `tests/test_contract.py` passes.
- **AC-7** The orders page renders "Export CSV" when `orders_csv_export` is `true` and does not render it when the
  flag is `false`, missing, or the flags request fails.
- **AC-8** `GET /orders/export` in the web app returns `text/csv` with the documented header when the flag is on,
  and `404` when it is off.
- **AC-9** The PRs are merged in the order infra → api → web, and each PR description states that order.

## Non-functional requirements

- Fail closed: any error reading flags hides flagged features.
- No secrets in flags; flag names are `snake_case` (infra conventions); every flag exists in every environment.
- `GET /flags` p95 < 20 ms (served from settings, no I/O).
- Adding a flag later requires only an infra change plus the code that reads it.

## Out of scope

- Per-user or percentage rollouts, a flag admin UI, a third-party flag vendor.
- Using `orders_bulk_status` (it stays declared and unused).

## Repo hints

- Merge order from `.adlc/config.yml`: `[infra, api, web]`.
