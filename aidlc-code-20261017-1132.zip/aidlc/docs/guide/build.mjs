#!/usr/bin/env node
/**
 * Builds the AIDLC project guide (docs/guide) from its sources of truth.
 *
 *   node docs/guide/build.mjs           regenerate the guide in place
 *   node docs/guide/build.mjs --check   regenerate in memory; exit 1 if any committed output differs (CI drift check)
 *
 * Zero npm dependencies. Data that only Python can read faithfully (agent registry + schemas, `aidlc --help`,
 * MCP tool schemas, gates/config models, settings, endpoint roles, sample-spec expected.yaml files) comes from
 * `export_sources.py`, run with the first of: $AIDLC_PYTHON, <repo>/.venv/bin/python, python3, python (the
 * `aidlc` package must be importable). The REST reference comes from clients/openapi.json.
 *
 * Hand-authored inputs live in src/: layout.html, sections/*.html (with {{placeholders}} and
 * <!--code:lang--> … <!--/code--> raw code blocks), diagrams.mjs (the five flowcharts as data, rendered to
 * inline SVG), guide.css, guide.js, theme-init.js.
 * Generated outputs (do not edit): index.html, guide.css, guide.js, theme-init.js, assets/**, samples/**.
 * Output is deterministic (no timestamps, stable ordering), so the drift check is a byte comparison.
 */
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { diagrams, renderDiagram } from './src/diagrams.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const SRC = path.join(HERE, 'src');
const CHECK = process.argv.includes('--check');

/** Directories the build owns completely: files in them that the build does not produce are stale. */
const MANAGED_DIRS = ['assets', 'samples'];
const AIG_DIR = path.join(ROOT, 'control-plane', 'web', 'styles', 'aig');
const AIG_FILES = ['tokens.css', 'aig-base.css', 'aig-chrome.css', 'fonts.css', 'logo.svg', 'favicon.ico',
  'fonts/inter-var.woff2', 'fonts/jetbrains-mono-var.woff2', 'fonts/LICENSE-Inter.txt', 'fonts/LICENSE-JetBrainsMono.txt'];
const SHOTS_DIR = path.join(ROOT, 'control-plane', 'web', 'e2e', 'screenshots');
/** Curated UI screenshots for the Web UI journey (light + dark where both exist). */
const SHOTS = ['home-light', 'home-dark', 'upload-light', 'upload-dark', 'inbox-light', 'inbox-dark', 'run-detail-light',
  'run-detail-dark', 'run-detail-acs-light', 'run-detail-acs-dark', 'journey-pr-ready-light', 'project-new-light',
  'project-new-dark', 'agents-light', 'agents-dark', 'run-flow-present-light', 'run-flow-present-dark'];

// ---------------------------------------------------------------- helpers

const byStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const read = (p) => fs.readFileSync(p, 'utf8');
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
/** Inline Markdown subset used in registry and spec text: `code` and **bold**. */
const md = (s) => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const fail = (msg) => { throw new Error(msg); };

function listFiles(dir, base = dir) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => byStr(a.name, b.name))) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(full, base));
    else out.push(path.relative(base, full).split(path.sep).join('/'));
  }
  return out;
}

function dedent(text) {
  const lines = text.replace(/\t/g, '  ').split('\n');
  const indent = Math.min(...lines.filter((l) => l.trim()).map((l) => l.match(/^ */)[0].length));
  return lines.map((l) => l.slice(Number.isFinite(indent) ? indent : 0)).join('\n').replace(/^\n+|\s+$/g, '');
}

const COMMENT = { bash: /^\s*#/, yaml: /^\s*#/, python: /^\s*#/, toml: /^\s*#/, ts: /^\s*\/\//, js: /^\s*\/\//, http: /^\s*#/ };

/** A code block with a copy button (added by guide.js). Comment lines are dimmed; nothing else is highlighted. */
function code(text, lang = 'text', title = '') {
  const isComment = COMMENT[lang];
  const body = text.split('\n').map((line) => (isComment && isComment.test(line) ? `<span class="tok-c">${esc(line)}</span>` : esc(line))).join('\n');
  const head = title ? `<div class="code-title"><span>${esc(title)}</span><span class="code-lang">${esc(lang)}</span></div>` : '';
  return `<div class="codebox">${head}<pre class="code" data-lang="${esc(lang)}" tabindex="0"><code>${body}</code></pre></div>`;
}

const table = (head, rows, cls = 'ref') =>
  `<div class="tablewrap"><table class="${cls}"><thead><tr>${head.map((h) => `<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${rows
    .map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`)
    .join('')}</tbody></table></div>`;

// ---------------------------------------------------------------- sources

function python() {
  const candidates = [process.env.AIDLC_PYTHON, path.join(ROOT, '.venv', 'bin', 'python'), 'python3', 'python'].filter(Boolean);
  for (const candidate of candidates) {
    if (candidate.includes(path.sep) && !fs.existsSync(candidate)) continue;
    try {
      execFileSync(candidate, ['-c', 'import aidlc'], { cwd: ROOT, stdio: 'ignore' });
      return candidate;
    } catch {
      /* try the next interpreter */
    }
  }
  return fail('no Python interpreter can import the aidlc package (set AIDLC_PYTHON or run `pip install -e .`)');
}

function loadSources() {
  const py = python();
  const raw = execFileSync(py, [path.join(HERE, 'export_sources.py')], {
    cwd: ROOT,
    env: { ...process.env, COLUMNS: '88', PYTHONDONTWRITEBYTECODE: '1', PYTHONHASHSEED: '0' },
    maxBuffer: 64 * 1024 * 1024,
    encoding: 'utf8',
  });
  return { ...JSON.parse(raw), openapi: JSON.parse(read(path.join(ROOT, 'clients', 'openapi.json'))) };
}

// ---------------------------------------------------------------- vocabularies (fail when the code grows a value the guide does not explain)

const OUTCOME_INFO = {
  'pr-ready': ['ok', 'PRs are open, CI is green and the `aidlc/gates` check is success; the run waits at Gate B for a human merge. It stays `pr-ready` when every PR merges. Onboarding, health-audit (with a PR) and verify-branch runs also end here.'],
  completed: ['info', 'Finished without a PR, e.g. a health audit with `open_pr: false` or nothing to draft.'],
  blocked: ['warn', 'Stopped for a human: a real trial-merge or task-merge conflict, an escalation answered with takeover, or a branch that failed verification.'],
  failed: ['bad', 'Could not finish: invalid input (no work item, unknown repo), a failed onboarding doctor, or an unrecoverable error.'],
  cancelled: ['', 'Cancelled by a person (run cancel, or an escalation decided `cancel`) or a PR closed without merging at Gate B.'],
};
const ESCALATION_INFO = {
  loop_cap: 'The S4 → S5 → S6 fix loop is still failing after `fix_loop_max_iterations` (default 5).',
  repeated_signature: 'The same failure signature (failing tests, blocking rules, failed ACs; baseline failures excluded) came back after a fix.',
  budget: 'Run cost exceeds the run budget; deciding `retry` approves one more tranche of `budgets.run_usd`.',
  v1_exhausted: 'The spec still fails V1 after `v1_max_attempts`. Options include `edit_spec` (send a replacement spec).',
  v2_exhausted: 'The plan still fails V2 after `v2_max_attempts`.',
  conflict: 'Reserved for merge conflicts. Today a conflict `conflict_bound` refuses ends the run as `blocked` instead.',
  ci_failing: 'PR CI still red after `ci_max_fix_attempts` CI Watcher fixes, or CI did not finish within the CI timeout.',
  feedback_cap: 'More PR-comment rounds than `feedback_max_rounds`, or the PR Feedback agent asked for a human.',
  agent_error: 'An agent failed or returned invalid output after its retry, or a bug could not be reproduced with a failing test.',
};
const WEBHOOK_INFO = {
  'run.gate_waiting': 'A Gate A question or an escalation is waiting for a human (event types `question`, `escalation`).',
  'run.pr_ready': 'A PR was marked ready for review (`pr` event with `ready: true`).',
  'run.failed': 'The run ended `failed` or `blocked`.',
  'run.completed': 'The run ended with any other outcome (`pr-ready`, `completed`, `cancelled`).',
};
const WORKFLOW_INFO = {
  feature: ['Upload, `POST /runs`, `aidlc run`, MCP `start_run`, GitHub label/comment, Jira label', 'Spec → V1 → Gate A → draft PR → plan → V2 → trial merge → develop → test/scan/validate fix loop → review → knowledge → final trial merge → deliver → CI → Gate B.'],
  bugfix: ['Upload with kind `bug`, `aidlc run --type bug`, an issue labelled `bug`, a Jira Bug', 'Bug spec → Gate A → draft PR → repo discovery → Debugger writes a failing reproduction test → owning dev fixes → lighter review (correctness + security) → PR.'],
  sprint: ['`POST /sprints`', 'One child run per item (FeatureWorkflow, or BugfixWorkflow for bug items), started concurrently and ranked after everything in flight; the sprint’s outcome is the worst child outcome.'],
  health_audit: ['`POST /audits` (Health Audits page)', 'S10 auditors + the five S5 scanners in whole-repo mode → ranked findings → Backlog Writer drafts REQ/BUG specs → PR (or stored artifacts).'],
  onboarding: ['`POST /projects/{id}/onboard` (Projects → onboarding wizard)', 'Existing repo, or create a new one from a preset with `aidlc/gates` required → profile → `.adlc/` context and config → doctor → onboarding PR.'],
  preview: ['Started by a feature/bugfix run when PRs are ready', 'Per-PR preview environment: refreshed on push, torn down when the PR merges or closes, or after the TTL.'],
  verify_branch: ['`aidlc local submit`, `POST /verify-branch`', 'S4 tests, S5 scans, S6 validation and S7 review on an existing branch, then the `aidlc/gates` commit status.'],
};
const ROLE_INFO = {
  viewer: 'Read projects, runs, events, artifacts, gates and knowledge.',
  contributor: 'Everything a viewer can, plus upload specs, start/cancel/retry runs, sprints, audits and verify-branch, answer Gate A questions.',
  maintainer: 'Plus project settings (config, gates, notification channels), webhooks, onboarding, doctor refresh, escalation decisions and agent promotion/rollback.',
  admin: 'Plus integrations. Org admins (the first user to sign in to an org) also manage teams and members, and are admin on every project in their org.',
};
const MODEL_SHORT = { 'claude-opus-5-5': 'opus', 'claude-sonnet-5-5': 'sonnet', 'claude-haiku-5-5': 'haiku' };
/** Sample groups of section 7: [group, expected.yaml categories, preferred order (others follow by id)]. */
const SAMPLE_GROUPS = [
  ['greenfield', ['greenfield'], ['todo-app', 'expense-tracker', 'room-booking']],
  ['brownfield-single', ['brownfield-single', 'bugfix'], ['orders-pagination', 'audit-logging-pii', 'retry-infinite-loop', 'refactor-service-layer']],
  ['brownfield-multi', ['brownfield-multi'], ['order-notes', 'feature-flags', 'sprint-conflict']],
  ['edge', ['edge'], ['ambiguous-spec', 'conflicting-sources', 'prompt-injection', 'oversized-upload']],
  ['seeded-defect', ['seeded-defect'], []],
];

function checkVocabulary(src) {
  const missing = [
    ...src.literals.outcomes.filter((o) => !OUTCOME_INFO[o]).map((o) => `outcome ${o}`),
    ...src.literals.escalation_reasons.filter((r) => !ESCALATION_INFO[r]).map((r) => `escalation reason ${r}`),
    ...src.literals.webhook_events.filter((e) => !WEBHOOK_INFO[e]).map((e) => `webhook event ${e}`),
    ...Object.keys(src.literals.workflows).filter((k) => !WORKFLOW_INFO[k]).map((k) => `run kind ${k}`),
    ...src.literals.roles.filter((r) => !ROLE_INFO[r]).map((r) => `role ${r}`),
    ...src.literals.models.filter((m) => !MODEL_SHORT[m]).map((m) => `model ${m}`),
  ];
  if (missing.length) fail(`build.mjs does not describe: ${missing.join(', ')} (add them to the vocabulary tables)`);
}

// ---------------------------------------------------------------- generated fragments

/** pydantic constraint repr (`Ge(ge=0)`) → `≥ 0`. */
const constraint = (c) => {
  const m = /^(Ge|Gt|Le|Lt)\(\w+=(.+)\)$/.exec(c);
  return m ? `${{ Ge: '≥', Gt: '>', Le: '≤', Lt: '<' }[m[1]]} ${m[2]}` : c;
};
const chip = (cls, text) => `<span class="chip ${cls}">${esc(text)}</span>`;
const modelChip = (m) => `<span class="mchip ${MODEL_SHORT[m]}">${MODEL_SHORT[m]}</span>`;
const tags = (items, cls = 'tag') => (items.length ? items.map((t) => `<span class="${cls}">${esc(t)}</span>`).join(' ') : '<span class="muted">none</span>');
const methodChip = (m) => `<span class="method ${m.toLowerCase()}">${m}</span>`;

function apiOperations(src) {
  const ops = [];
  for (const [p, methods] of Object.entries(src.openapi.paths)) {
    for (const [method, op] of Object.entries(methods)) {
      const key = `${method.toUpperCase()} ${p}`;
      const reqRef = op.requestBody?.content && Object.values(op.requestBody.content)[0]?.schema?.$ref;
      const okResp = Object.entries(op.responses || {}).find(([code]) => code.startsWith('2'));
      const respSchema = okResp && okResp[1].content && Object.values(okResp[1].content)[0]?.schema;
      const respName = respSchema?.$ref ? respSchema.$ref.split('/').pop() : respSchema?.items?.$ref ? `${respSchema.items.$ref.split('/').pop()}[]` : '';
      const params = (op.parameters || []).filter((x) => x.in === 'query').map((x) => x.name);
      ops.push({ method: method.toUpperCase(), path: p, op, key, tag: (op.tags || ['other'])[0], summary: op.summary || '', role: src.routes[key] || fail(`no role for ${key}`),
        req: reqRef ? reqRef.split('/').pop() : op.requestBody ? Object.keys(op.requestBody.content)[0] : '', resp: respName, status: okResp ? okResp[0] : '', params });
    }
  }
  const order = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
  return ops.sort((a, b) => byStr(a.path, b.path) || order.indexOf(a.method) - order.indexOf(b.method));
}

function agentCard(a) {
  const io = `<dl class="dl compact"><dt>Inputs</dt><dd>${a.inputs.length ? a.inputs.map((k) => `<code>${k}</code>`).join(' ') : '<span class="muted">call payload only</span>'}</dd>
<dt>Output</dt><dd><code>${esc(a.output_class)}</code>: ${a.output_fields.map((f) => `<code>${esc(f)}</code>`).join(' ')}</dd>
<dt>Tools</dt><dd>${tags(a.tools)}${a.mcp_servers.length ? ` <span class="sep">MCP</span> ${tags(a.mcp_servers)}` : ''}</dd>
<dt>Workflows</dt><dd>${tags(a.workflows)}</dd>
<dt>Limits</dt><dd>${a.max_turns} turns · $${a.budget_usd.toFixed(2)} · ${Math.round(a.timeout_s / 60)} min · effort <code>${esc(a.effort)}</code></dd>
<dt>Source</dt><dd><code>${esc(a.path)}/</code> v${esc(a.version)}</dd></dl>`;
  const flags = [a.reads_untrusted ? '<span class="tag warn-tag" title="Reads external text; may not have write or exec tools">reads untrusted</span>' : '',
    a.mutates ? '<span class="tag" title="Has Write/Edit/Bash tools">changes code</span>' : '',
    a.invoked ? '' : '<span class="tag muted-tag" title="Defined in the registry; no workflow calls it yet">registry only</span>'].filter(Boolean).join(' ');
  return `<article class="agent card" id="agent-${a.id}" data-squad="${a.squad}" data-model="${MODEL_SHORT[a.model]}" data-text="${esc(`${a.number} ${a.id} ${a.name} ${a.description} ${a.squad_name} ${a.tools.join(' ')} ${a.output_class}`.toLowerCase())}">
<div class="agent-top"><span class="agent-num">#${a.number}</span><span class="squad-badge s-${a.squad.toLowerCase()}">${a.squad}</span>${modelChip(a.model)}</div>
<h4>${esc(a.name)}</h4><p class="agent-id"><code>${a.id}</code></p><p class="agent-desc">${md(a.description)}</p>
${flags ? `<p class="agent-flags">${flags}</p>` : ''}
<details><summary>Role, inputs and output</summary><p class="agent-role">${md(a.role)}</p>${io}</details></article>`;
}

function samplesById(src) {
  return Object.fromEntries(src.specs.map((s) => [s.data.id, s]));
}

function sampleCard(spec, src) {
  const d = spec.data;
  const id = `sample-${d.id}`;
  const outcomeCls = { 'pr-ready': 'ok', blocked: 'warn', failed: 'bad', rejected: 'bad', cancelled: '' }[d.expected_outcome] ?? 'info';
  const target = d.target.mode === 'new' ? `new repo from preset <code>${esc(d.target.preset)}</code>` : d.target.repos.map((r) => `<code>evals/repos/${esc(r)}</code>`).join(', ');
  const specs = spec.spec_paths.map((p) => {
    const text = read(path.join(ROOT, 'evals', 'specs', p));
    return `<div class="spec-file"><details class="spec-text"><summary><span>Full spec text: <code>${esc(path.basename(p))}</code></span></summary>${code(text.replace(/\s+$/, ''), 'markdown', p)}</details><a class="btn sm secondary spec-dl" href="samples/${esc(p)}" download aria-label="Download ${esc(path.basename(p))}">Download</a></div>`;
  }).join('');
  const attachments = spec.attachment_paths.length
    ? `<p class="meta-line"><b>Attachments</b> ${spec.attachment_paths.map((a) => (a.startsWith('http') ? `<code class="url">${esc(a)}</code>` : `<a href="samples/${esc(a)}" download><code>${esc(path.basename(a))}</code></a>`)).join(' ')}</p>`
    : '';
  const pipeline = ['V1', 'A', 'V2', 'trial_merge_early', 'quality', 'trial_merge_final', 'B'];
  const rank = (g) => (pipeline.indexOf(g) + 1) || 99;
  const gates = Object.entries(d.gates).sort((a, b) => rank(a[0]) - rank(b[0])).map(([g, v]) => `<span class="gate g-${esc(v)}"><b>${esc(g)}</b> ${esc(v)}</span>`).join('');
  const questions = d.gate_a_questions.length ? `<ol class="qlist">${d.gate_a_questions.map((q) => `<li>${md(q)}</li>`).join('')}</ol>` : '<p class="muted">Gate A is not triggered.</p>';
  const defects = d.seeded_defects.length
    ? table(['Defect', 'Where', 'Caught by'], d.seeded_defects.map((x) => [`<b>${esc(x.id)}</b><span class="sub">${md(x.description)}</span>`, `<code>${esc(x.location)}</code>`, `<code>${esc(x.caught_by)}</code>`]), 'ref tight')
    : '';
  const prs = d.expected_prs === 0 ? 'no PR' : `${d.expected_prs} PR${d.expected_prs > 1 ? 's' : ''}`;
  const merge = d.merge_order.length ? ` · merge order ${d.merge_order.map((r) => `<code>${esc(r)}</code>`).join(' → ')}` : '';
  const known = new Set(src.agents.map((a) => a.id));
  const agents = d.agents_expected.map((a) => (known.has(a) ? `<a class="tag agent-link" href="#agent-${a}">${esc(a)}</a>` : fail(`${spec.expected_path}: unknown agent ${a}`))).join(' ');
  return `<article class="sample card" id="${id}">
<div class="ch"><h4>${esc(d.title)}</h4><span class="aside">${chip('info', d.workflow === 'none' ? 'no run' : d.workflow)} ${chip(outcomeCls, d.expected_outcome)}</span></div>
<div class="cb">
<p class="meta-line"><b>Target</b> ${target} <span class="sep">·</span> <b>Repos touched</b> ${d.repos_touched.length ? d.repos_touched.map((r) => `<code>${esc(r)}</code>`).join(' ') : 'none'} <span class="sep">·</span> <b>Expected</b> ${prs}${merge}</p>
${attachments}${specs}
<div class="sample-grid"><div><h5>Agents it activates (${d.agents_expected.length})</h5><p class="tagcloud">${agents || '<span class="muted">none: rejected before a run starts</span>'}</p>
<h5>Expected Gate A questions</h5>${questions}<h5>Gates</h5><p class="gates">${gates}</p></div>
<div><h5>Verify</h5><ul class="verify-list">${d.verify.map((v) => `<li>${md(v)}</li>`).join('')}</ul></div></div>
${defects}
<p class="spec-src">Expected outcome file: <a href="samples/${esc(spec.expected_path)}" download><code>evals/specs/${esc(spec.expected_path)}</code></a></p>
</div></article>`;
}

function generators(src) {
  const agents = src.agents;
  const ops = apiOperations(src);
  const squads = Object.entries(src.squads);
  const byId = samplesById(src);
  const cliNames = src.cli.commands.map((c) => c.name);
  const counts = {
    agents: agents.length, squads: squads.length, workflows: Object.keys(src.literals.workflows).length, endpoints: ops.length,
    cli: cliNames.length + (src.cli.commands.find((c) => c.name === 'local')?.actions.length ?? 0) - 1, mcp: src.mcp.tools.length,
    'mcp-knowledge': src.mcp.knowledge_tools.length, samples: src.specs.length, untrusted: agents.filter((a) => a.reads_untrusted).length,
    mutating: agents.filter((a) => a.mutates).length,
    'upload-mib': (src.settings.fields.find((f) => f.env === 'AIDLC_UPLOAD_MAX_BYTES') || fail('no upload limit')).default / 1048576,
  };
  const flows = diagrams({ fixMax: Object.fromEntries(src.config.gates_fields.map((f) => [f.name, f.default])).fix_loop_max_iterations });
  const gatesDefault = Object.fromEntries(src.config.gates_fields.map((f) => [f.name, f.default]));
  const sampleGroup = (group) => {
    const [, cats, order] = SAMPLE_GROUPS.find((x) => x[0] === group) || fail(`unknown sample group ${group}`);
    const inGroup = src.specs.filter((s) => cats.includes(s.data.category));
    const ordered = [...order.map((id) => byId[id] || fail(`sample ${id} missing`)), ...inGroup.filter((s) => !order.includes(s.data.id)).sort((a, b) => byStr(a.data.id, b.data.id))];
    if (ordered.some((s) => !cats.includes(s.data.category))) fail(`sample group ${group} lists a spec from another category`);
    return ordered;
  };
  const grouped = new Set(SAMPLE_GROUPS.flatMap(([, cats]) => cats));
  const ungrouped = src.specs.filter((s) => !grouped.has(s.data.category)).map((s) => s.expected_path);
  if (ungrouped.length) fail(`samples in no group: ${ungrouped.join(', ')}`);

  const g = {
    n: (name) => String(counts[name] ?? fail(`unknown count ${name}`)),
    flow: (id) => renderDiagram(id, flows[id] || fail(`unknown diagram ${id}`), md),
    kpis: () => `<div class="kpis k4 guide-kpis">${[
      ['Agents', counts.agents, `${counts.squads} squads, data-only definitions`],
      ['Workflows', counts.workflows, 'durable Temporal workflows'],
      ['REST endpoints', counts.endpoints, 'OpenAPI 3 · bearer auth · SSE'],
      ['Sample specs', counts.samples, 'with expected outcomes'],
    ].map(([l, v, s]) => `<div class="kpi"><div class="top"><span class="lbl">${l}</span></div><div class="valrow"><span class="val">${v}</span></div><div class="sub">${s}</div></div>`).join('')}</div>`,
    ethos: () => `<ol class="ethos">${src.ethos.map((e) => `<li><b>${esc(e.title)}</b><span>${md(e.point)}</span></li>`).join('')}</ol>`,
    squads: () => `<div class="squads">${squads.map(([id, name]) => {
      const members = agents.filter((a) => a.squad === id);
      const mix = Object.entries(members.reduce((acc, a) => ({ ...acc, [MODEL_SHORT[a.model]]: (acc[MODEL_SHORT[a.model]] || 0) + 1 }), {})).sort((a, b) => byStr(a[0], b[0]));
      return `<a class="squad s-${id.toLowerCase()}" href="#agents" data-squad-link="${id}"><span class="squad-id">${id}</span><b>${esc(name)}</b><span class="squad-n">${members.length} agents</span><span class="squad-mix">${mix.map(([m, n]) => `<span class="mchip ${m}">${n} ${m}</span>`).join('')}</span></a>`;
    }).join('')}</div>`,
    outcomes: () => table(['Outcome', 'Meaning', 'CLI exit'], src.literals.outcomes.map((o) => [chip(OUTCOME_INFO[o][0], o), md(OUTCOME_INFO[o][1]), `<code>${src.cli.exit_codes[o]}</code>`])),
    'outcome-chips': () => src.literals.outcomes.map((o) => chip(OUTCOME_INFO[o][0], o)).join(' '),
    'agent-catalog': () => `<div class="card flush agent-catalog"><div class="toolbar" role="search" aria-label="Filter agents">
<label class="sr-only" for="agent-q">Search agents</label><input id="agent-q" class="input search" type="search" placeholder="Search agents, tools, outputs…" autocomplete="off">
<label class="sr-only" for="agent-squad">Squad</label><select id="agent-squad" class="input"><option value="">All squads</option>${squads.map(([id, name]) => `<option value="${id}">${id} · ${esc(name)}</option>`).join('')}</select>
<label class="sr-only" for="agent-model">Model</label><select id="agent-model" class="input"><option value="">All models</option>${src.literals.models.map((m) => `<option value="${MODEL_SHORT[m]}">${m}</option>`).join('')}</select>
<span class="grow"></span><span class="count" id="agent-count" aria-live="polite">${agents.length} of ${agents.length} agents</span></div>
<div class="agent-grid" id="agent-grid">${agents.map(agentCard).join('\n')}</div><p class="empty" id="agent-empty" hidden>No agent matches these filters.</p></div>`,
    'squad-templates': () => squads.map(([id, name]) => `<template id="squad-${id}" data-title="${id} · ${esc(name)}"><p class="muted">${agents.filter((a) => a.squad === id).length} agents. Inputs are <code>AgentCall.inputs</code> keys; outputs are typed JSON.</p><ul class="drawer-list">${agents.filter((a) => a.squad === id).map((a) => `<li><div class="dl-top"><b>#${a.number} ${esc(a.name)}</b>${modelChip(a.model)}</div><p>${md(a.description)}</p><p class="io"><span>in</span> ${a.inputs.map((k) => `<code>${k}</code>`).join(' ') || '—'}</p><p class="io"><span>out</span> <code>${esc(a.output_class)}</code></p><a href="#agent-${a.id}" data-close-drawer>Open in catalog</a></li>`).join('')}</ul></template>`).join('\n'),
    'workflows-table': () => table(['Kind', 'Temporal workflow', 'Started by', 'What it does'], Object.entries(src.literals.workflows).map(([k, w]) => [`<code>${k}</code>`, `<code>${w}</code>`, md(WORKFLOW_INFO[k][0]), md(WORKFLOW_INFO[k][1])])),
    'loop-limits': () => table(['Limit (gates key)', 'Default', 'When it is reached'], [
      ['<code>v1_max_attempts</code>', gatesDefault.v1_max_attempts, 'Spec Analyst fixes after a failed V1, then escalation <code>v1_exhausted</code>'],
      ['<code>v2_max_attempts</code>', gatesDefault.v2_max_attempts, 'Work Planner fixes after a failed V2, then escalation <code>v2_exhausted</code>'],
      ['<code>fix_loop_max_iterations</code>', gatesDefault.fix_loop_max_iterations, 'S4 → S5 → S6 iterations, then <code>loop_cap</code> (a repeated failure signature escalates earlier)'],
      ['<code>ci_max_fix_attempts</code>', gatesDefault.ci_max_fix_attempts, 'CI Watcher fix rounds after PRs open, then <code>ci_failing</code>'],
      ['<code>feedback_max_rounds</code>', gatesDefault.feedback_max_rounds, 'PR-comment rounds at Gate B, then <code>feedback_cap</code>'],
      ['<code>run_budget_usd</code>', `$${gatesDefault.run_budget_usd}`, 'Run spend across all agents, then <code>budget</code>'],
    ].map((r) => r.map(String))),
    'cli-commands': () => table(['Command', 'What it does'], src.cli.commands.flatMap((c) => (c.actions
      ? c.actions.map((a) => [`<a href="#cli-local-${a.name}"><code>aidlc local ${a.name}</code></a>`, md(a.help)])
      : [[`<a href="#cli-${c.name}"><code>aidlc ${c.name}</code></a>`, md(c.help)]]))),
    'cli-reference': () => [`<details class="help" id="cli-main" open><summary><code>aidlc --help</code></summary>${code(src.cli.main, 'text')}</details>`,
      ...src.cli.commands.flatMap((c) => (c.actions
        ? [`<details class="help" id="cli-local"><summary><code>aidlc local --help</code> <span class="muted">${esc(c.help)}</span></summary>${code(c.usage, 'text')}</details>`,
          ...c.actions.map((a) => `<details class="help" id="cli-local-${a.name}"><summary><code>aidlc local ${a.name}</code> <span class="muted">${esc(a.help)}</span></summary>${code(a.usage, 'text')}</details>`)]
        : [`<details class="help" id="cli-${c.name}"><summary><code>aidlc ${c.name}</code> <span class="muted">${esc(c.help)}</span></summary>${code(c.usage, 'text')}</details>`]))].join('\n'),
    'exit-codes': () => {
      const rows = Object.entries(src.cli.exit_codes).map(([o, n]) => [`<code>${n}</code>`, `outcome ${chip(OUTCOME_INFO[o][0], o)}`]);
      rows.splice(1, 0, [`<code>${src.cli.exit_error}</code>`, 'error: bad usage, API/auth error, failed <code>aidlc doctor</code>, or a run that has no outcome the CLI knows']);
      rows.push([`<code>${src.cli.exit_interrupted}</code>`, 'interrupted (Ctrl-C)']);
      return table(['Exit code', 'Meaning'], rows.sort((a, b) => Number(a[0].replace(/\D/g, '')) - Number(b[0].replace(/\D/g, ''))));
    },
    'api-reference': () => {
      const order = ['session', 'projects', 'specs', 'runs', 'inbox', 'work', 'agents', 'admin', 'hooks', 'ops'];
      const groups = [...new Set(ops.map((o) => o.tag))].sort((a, b) => (order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99) || byStr(a, b));
      return groups.map((t) => `<h4 class="api-group">${esc(t)}</h4>${table(['Endpoint', 'Summary', 'Minimum role', 'Body → response'], ops.filter((o) => o.tag === t).map((o) => [
        `<span class="ep">${methodChip(o.method)}<code>${esc(o.path)}</code></span>${o.params.length ? `<span class="sub">query: ${o.params.map((q) => `<code>${esc(q)}</code>`).join(' ')}</span>` : ''}`,
        esc(o.summary), `<span class="role">${esc(o.role)}</span>`, `${o.req ? `<code>${esc(o.req)}</code>` : '—'} → <code>${esc(o.status)}</code> ${o.resp ? `<code>${esc(o.resp)}</code>` : ''}`]), 'ref api')}`).join('\n');
    },
    'webhook-events': () => table(['Event', 'Sent when'], src.literals.webhook_events.map((e) => [`<code>${e}</code>`, md(WEBHOOK_INFO[e])])),
    'webhook-attempts': () => String(src.literals.webhook_max_attempts),
    'event-types': () => `<p class="tagcloud">${src.literals.event_types.map((e) => `<code class="tag">${e}</code>`).join(' ')}</p>`,
    'escalations': () => table(['Reason', 'Raised when'], src.literals.escalation_reasons.map((r) => [`<code>${r}</code>`, md(ESCALATION_INFO[r])])),
    'escalation-decisions': () => src.literals.escalation_decisions.map((d) => `<code>${d}</code>`).join(' · '),
    'mcp-tools': (anchors) => table(['Tool', 'Kind', 'Parameters', 'Description'], src.mcp.tools.map((t) => [`<code${anchors ? ` id="mcp-${t.name}"` : ''}>${t.name}</code>`, t.read_only ? chip('ok', 'read') : chip('warn', 'write · confirm'),
      t.params.map((p) => `<code>${esc(p.name)}</code>${p.required ? '<abbr title="required">*</abbr>' : ''} <span class="sub-inline">${esc(p.type)}${p.default !== null && p.default !== undefined ? ` = ${esc(JSON.stringify(p.default))}` : ''}</span>`).join('<br>'),
      md(t.description).replace(/\n\n/g, '<br>')]), 'ref mcp'),
    'mcp-knowledge-tools': () => table(['Tool', 'Parameters', 'Description'], src.mcp.knowledge_tools.map((t) => [`<code>${t.name}</code>`,
      t.params.map((p) => `<code>${esc(p.name)}</code>${p.required ? '<abbr title="required">*</abbr>' : ''} <span class="sub-inline">${esc(p.type)}</span>`).join('<br>'), md(t.description)])),
    'mcp-instructions': () => code(src.mcp.instructions.trim(), 'text', 'Server instructions sent to MCP clients'),
    'mcp-port': () => String(src.mcp.default_port),
    'mcp-path': () => esc(src.mcp.path),
    'mcp-servers-json': () => code(src.mcp.servers_json.trim(), 'json', 'mcp/servers.json'),
    'gates-default': () => code(src.config.gates_default.trim(), 'yaml', 'presets/gates.default.yaml'),
    'gates-fields': () => table(['Key', 'Type', 'Default', 'Constraints'], src.config.gates_fields.map((f) => [`<code>${f.name}</code>`, `<code>${esc(f.type)}</code>`, `<code>${esc(JSON.stringify(gatesDefault[f.name]))}</code>`, f.constraints.map((c) => `<code>${esc(constraint(c))}</code>`).join(' ') || '—'])),
    'config-template': () => code(src.config.config_template.trim(), 'yaml', 'templates/config.yml'),
    'config-fields': () => table(['Field', 'Type', 'Default'], [
      ...src.config.project_config_fields.map((f) => [`<code>${f.name}</code>`, `<code>${esc(f.type)}</code>`, f.required ? '<span class="muted">required</span>' : `<code>${esc(JSON.stringify(f.default))}</code>`]),
      ...src.config.repo_fields.map((f) => [`<code>repos[].${f.name}</code>`, `<code>${esc(f.type)}</code>`, f.required ? '<span class="muted">required</span>' : `<code>${esc(JSON.stringify(f.default))}</code>`]),
    ]),
    presets: () => src.config.presets.map((p) => `<code>${esc(p)}</code>`).join(', '),
    'env-example': () => code(src.settings.env_example.trim(), 'bash', 'infra/.env.example'),
    'settings-env': () => table(['Variable', 'Type', 'Default'], src.settings.fields.map((f) => [`<code>${f.env}</code>`, `<code>${esc(f.type)}</code>`, f.default === null ? '<span class="muted">unset</span>' : `<code>${esc(typeof f.default === 'string' ? f.default : JSON.stringify(f.default))}</code>`])),
    roles: () => table(['Role', 'Can', 'Endpoints that need at least this role'], src.literals.roles.map((r) => {
      const eps = ops.filter((o) => o.role.split(' ')[0] === r);
      return [`<b>${r}</b>`, md(ROLE_INFO[r]), eps.length ? `<details><summary>${eps.length} endpoints</summary><ul class="eplist">${eps.map((o) => `<li>${methodChip(o.method)}<code>${esc(o.path)}</code>${o.role.includes('(') ? ` <span class="muted">${esc(o.role.slice(o.role.indexOf('(')))}</span>` : ''}</li>`).join('')}</ul></details>` : '—'];
    })),
    'upload-types': () => Object.keys(src.literals.upload_ext).map((ext) => `<code>${ext}</code>`).join(' '),
    'upload-max-files': () => String(src.literals.upload_max_files),
    'source-kinds': () => src.literals.source_kinds.map((k) => `<code>${k}</code>`).join(' '),
    'gate-names': () => src.literals.gate_names.map((k) => `<code>${k}</code>`).join(' '),
    'run-kinds': () => src.literals.run_kinds.map((k) => `<code>${k}</code>`).join(' '),
    severities: () => src.literals.severities.map((k) => `<code>${k}</code>`).join(' '),
    'notify-kinds': () => src.literals.notify_kinds.map((k) => `<code>${k}</code>`).join(' '),
    'task-queue': () => `<code>${esc(src.literals.task_queue)}</code>`,
    signals: () => Object.values(src.literals.signals).map((s) => `<code>${esc(s)}</code>`).join(', '),
    samples: (group) => sampleGroup(group).map((s) => sampleCard(s, src)).join('\n'),
    'sample-index': () => table(['Spec', 'Workflow', 'Repos', 'PRs', 'Outcome'], SAMPLE_GROUPS.flatMap(([group]) => sampleGroup(group).map((s) => [
      `<a href="#sample-${s.data.id}">${esc(s.data.title)}</a><span class="sub">${esc(s.data.category)}</span>`, `<code>${esc(s.data.workflow)}</code>`,
      s.data.repos_touched.map((r) => `<code>${esc(r)}</code>`).join(' ') || '—', String(s.data.expected_prs), esc(s.data.expected_outcome)]))),
    'seeded-defects': () => table(['Spec', 'Seeded defect', 'Caught by'], src.specs.filter((s) => s.data.category === 'seeded-defect').flatMap((s) => s.data.seeded_defects.map((x) => [
      `<a href="#sample-${s.data.id}">${esc(s.data.id)}</a>`, md(x.description), `<code>${esc(x.caught_by)}</code>`]))),
  };
  return g;
}

// ---------------------------------------------------------------- assembly

const PLACEHOLDER = /\{\{([a-z0-9-]+)(?::([a-z0-9-]+))?\}\}/g;

function expand(html, gen, file) {
  html = html.replace(/<!--code:([a-z]+)(?: title="([^"]*)")?-->\n([\s\S]*?)\n\s*<!--\/code-->/g, (_, lang, title, body) => code(dedent(body), lang, title || ''));
  return html.replace(PLACEHOLDER, (_, name, arg) => {
    const fn = gen[name] || fail(`${file}: unknown placeholder {{${name}${arg ? `:${arg}` : ''}}}`);
    return fn(arg);
  });
}

function outline(body) {
  const sections = [];
  const re = /<section class="gsec[^"]*" id="([a-z0-9-]+)" data-title="([^"]+)" data-group="([^"]+)" data-num="([0-9]+)"[^>]*>([\s\S]*?)<\/section>/g;
  for (const m of body.matchAll(re)) {
    const subs = [...m[5].matchAll(/<h3 id="([a-z0-9-]+)"[^>]*>([\s\S]*?)<\/h3>/g)].map((h) => ({ id: h[1], title: h[2].replace(/<[^>]+>/g, '').trim() }));
    sections.push({ id: m[1], title: m[2], group: m[3], num: m[4], subs });
  }
  if (sections.length !== 8) fail(`expected 8 sections, found ${sections.length}`);
  return sections;
}

function navHtml(sections) {
  const groups = [...new Set(sections.map((s) => s.group))];
  return groups.map((g) => `<div role="group" aria-labelledby="nav-${slug(g)}"><div class="grp" id="nav-${slug(g)}">${esc(g)}</div>${sections.filter((s) => s.group === g).map((s) => `<a href="#${s.id}" class="sec-link" data-sec="${s.id}"><span class="num" aria-hidden="true">${s.num}</span><span class="lbl">${esc(s.title)}</span></a><div class="subnav" data-sec="${s.id}">${s.subs.map((h) => `<a href="#${h.id}" class="sub-link" data-sub="${h.id}">${esc(h.title)}</a>`).join('')}</div>`).join('')}</div>`).join('');
}

function paletteHtml(sections, src) {
  const items = [];
  for (const s of sections) {
    items.push(['Sections', s.title, `#${s.id}`, s.num]);
    for (const h of s.subs) items.push(['Sections', h.title, `#${h.id}`, s.title]);
  }
  for (const a of src.agents) items.push(['Agents', `${a.name} (${a.id})`, `#agent-${a.id}`, `${a.squad} · ${MODEL_SHORT[a.model]}`]);
  for (const c of src.cli.commands) {
    if (c.actions) for (const a of c.actions) items.push(['CLI', `aidlc local ${a.name}`, `#cli-local-${a.name}`, a.help]);
    else items.push(['CLI', `aidlc ${c.name}`, `#cli-${c.name}`, c.help]);
  }
  for (const t of src.mcp.tools) items.push(['MCP tools', t.name, `#mcp-${t.name}`, t.read_only ? 'read' : 'write']);
  for (const s of src.specs) items.push(['Sample specs', s.data.title, `#sample-${s.data.id}`, s.data.category]);
  return items.map(([grp, title, href, hint], i) => `<li role="option" id="pal-${i}" aria-selected="false" data-href="${esc(href)}" data-group="${esc(grp)}" data-text="${esc(`${grp} ${title} ${hint}`.toLowerCase())}"><span class="pal-kind">${esc(grp)}</span><span class="pal-title">${esc(title)}</span><span class="hint">${esc(hint)}</span></li>`).join('');
}

function checkLinks(html, outputs) {
  const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
  const dup = [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]).filter((id, i, all) => all.indexOf(id) !== i);
  if (dup.length) fail(`duplicate ids: ${[...new Set(dup)].join(', ')}`);
  const problems = [];
  for (const m of html.matchAll(/\s(?:href|src|data-href|xlink:href)="([^"]+)"/g)) {
    const url = m[1].replace(/&amp;/g, '&');
    if (/^(https?:|mailto:)/.test(url)) {
      if (m[0].includes('src=')) problems.push(`external asset ${url}`);
      continue;
    }
    if (url.startsWith('#')) {
      if (url.length > 1 && !ids.has(url.slice(1))) problems.push(`broken anchor ${url}`);
      continue;
    }
    const file = decodeURI(url.split('#')[0].split('?')[0]);
    if (!outputs.has(file) && !fs.existsSync(path.join(HERE, file))) problems.push(`broken link ${url}`);
  }
  if (problems.length) fail(`link check failed:\n  ${[...new Set(problems)].join('\n  ')}`);
}

function build() {
  const src = loadSources();
  checkVocabulary(src);
  const outputs = new Map();
  const put = (rel, data) => outputs.set(rel, Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8'));

  for (const f of ['guide.css', 'guide.js', 'theme-init.js']) put(f, fs.readFileSync(path.join(SRC, f)));
  for (const f of AIG_FILES) put(`assets/aig/${f}`, fs.readFileSync(path.join(AIG_DIR, f)));
  for (const s of SHOTS) put(`assets/screenshots/${s}.png`, fs.readFileSync(path.join(SHOTS_DIR, `${s}.png`)));
  const specsDir = path.join(ROOT, 'evals', 'specs');
  for (const f of listFiles(specsDir).filter((f) => !f.includes('__pycache__') && !f.endsWith('.pyc'))) put(`samples/${f}`, fs.readFileSync(path.join(specsDir, f)));

  const gen = generators(src);
  const sectionFiles = fs.readdirSync(path.join(SRC, 'sections')).filter((f) => f.endsWith('.html')).sort(byStr);
  const body = sectionFiles.map((f) => expand(read(path.join(SRC, 'sections', f)), gen, f)).join('\n');
  const sections = outline(body);
  const layout = read(path.join(SRC, 'layout.html'));
  const html = expand(layout, { ...gen, nav: () => navHtml(sections), palette: () => paletteHtml(sections, src), sections: () => body }, 'layout.html')
    .replace(/[ \t]+$/gm, '');
  checkLinks(html, outputs);
  put('index.html', html.endsWith('\n') ? html : `${html}\n`);
  return outputs;
}

function main() {
  const outputs = build();
  const stale = MANAGED_DIRS.flatMap((d) => listFiles(path.join(HERE, d)).map((f) => `${d}/${f}`)).filter((f) => !outputs.has(f));
  if (CHECK) {
    const changed = [...outputs].filter(([rel, data]) => {
      const file = path.join(HERE, rel);
      return !fs.existsSync(file) || !fs.readFileSync(file).equals(data);
    }).map(([rel]) => rel);
    if (changed.length || stale.length) {
      console.error('docs/guide is out of date with its sources. Run: node docs/guide/build.mjs');
      for (const f of changed) console.error(`  changed: docs/guide/${f}`);
      for (const f of stale) console.error(`  stale:   docs/guide/${f}`);
      process.exit(1);
    }
    console.log(`docs/guide is up to date (${outputs.size} files).`);
    return;
  }
  let written = 0;
  for (const [rel, data] of outputs) {
    const file = path.join(HERE, rel);
    if (fs.existsSync(file) && fs.readFileSync(file).equals(data)) continue;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, data);
    written += 1;
  }
  for (const f of stale) fs.rmSync(path.join(HERE, f));
  console.log(`docs/guide built: ${outputs.size} files (${written} written, ${stale.length} stale removed).`);
}

main();
