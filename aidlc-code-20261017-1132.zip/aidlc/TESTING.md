# Testing AIDLC Platform

Two scripts to test the platform: one for local development, one for CI.

## Local Development: `test-platform.sh`

Sets up the worker with model access and demonstrates CLI testing.

### Setup AWS Credentials (Option 1 - Recommended)

```bash
cd /Users/vinoth/github/aidlc
source .env.aws  # Load AWS credentials
./test-platform.sh
```

### Or Use Anthropic API (Option 2 - Dev Mode)

```bash
export ANTHROPIC_API_KEY=your_key_here
export AIDLC_BEDROCK_ENABLED=false
./test-platform.sh
```

**What it does:**
1. Sets up AWS credentials (from .env.aws or environment)
2. Validates credentials with AWS STS
3. Starts the worker with Bedrock or Anthropic API
4. Signs in via CLI
5. Runs `aidlc doctor` to verify setup
6. Shows how to upload and run a sample spec

**Output:**
- Shows worker PID and log path
- Lists available CLI commands
- Displays run statuses and exit codes
- Ready for interactive `aidlc run` commands

**Example workflow after the script runs:**
```bash
# In another terminal:
export AIDLC_API_URL=http://localhost:8000

# Run a feature spec and stream progress
aidlc run evals/specs/brownfield-single/orders-pagination.md \
  --project storefront --watch

# Check status
aidlc status [run_id]

# Answer Gate A questions (if any)
aidlc inbox --project storefront
aidlc answer '<run_id>:Q-1' "your answer"

# Get results
aidlc artifacts [run_id]
```

## CI Integration: `test-platform-ci.sh`

Machine-readable JSON output for CI pipelines.

```bash
cd /Users/vinoth/github/aidlc
export TEST_SPEC=evals/specs/brownfield-single/orders-pagination.md
export TEST_PROJECT=storefront
export TIMEOUT=600

./test-platform-ci.sh [repo_root]
```

**Environment variables:**
- `TEST_SPEC`: Path to the spec file to run (default: brownfield single-repo)
- `TEST_PROJECT`: Project ID (default: storefront)
- `TIMEOUT`: Max seconds to wait (default: 600)

**Exit codes:**
- `0`: All tests passed (outcome: pr-ready)
- `1`: Test failed (outcome: failed/blocked)
- `2`: Timeout

**JSON output to stderr:**
```json
{"test": "orders-pagination", "status": "running"}
{"test": "orders-pagination", "status": "passed", "exit_code": 0}
```

**GitHub Actions example:**
```yaml
- name: Test AIDLC platform
  run: |
    ./test-platform.sh
    export AIDLC_API_URL=http://localhost:8000
    ./test-platform-ci.sh . 2>&1 | jq .
    
- name: Check exit code
  run: |
    ./test-platform-ci.sh .
    EXIT_CODE=$?
    [ $EXIT_CODE -eq 0 ] && echo "PASSED" || echo "FAILED"
    exit $EXIT_CODE
```

## Manual CLI Testing

All commands work with `--json` for scripting:

```bash
export AIDLC_API_URL=http://localhost:8000
A=.venv/bin/aidlc

# Parse run ID from JSON
RUN_ID=$($A run spec.md --project P --json | jq -r '.run.id')

# Wait for outcome
while true; do
  STATUS=$($A status "$RUN_ID" --json)
  OUTCOME=$(echo "$STATUS" | jq -r '.outcome // empty')
  [ -n "$OUTCOME" ] && break
  sleep 5
done

# Report
echo "$STATUS" | jq .outcome
```

## Test Samples

Available sample specs:

```
# Single repo, brownfield
evals/specs/brownfield-single/orders-pagination.md
evals/specs/brownfield-single/audit-logging.md
evals/specs/brownfield-single/retry-infinite-loop-bugfix.md

# Multiple repos, brownfield
evals/specs/brownfield-multi/order-notes.md
evals/specs/brownfield-multi/sprint-conflict/

# Greenfield (create-new-repo)
evals/specs/greenfield/todo-app.md
evals/specs/greenfield/expense-tracker.md

# Edge cases
evals/specs/edge/ambiguous-spec.md
evals/specs/edge/prompt-injection.md
```

## Stopping the Worker

```bash
# Kill by PID (from test-platform.sh output)
kill $WORKER_PID

# Or stop all AIDLC services
lsof -tiTCP:7233,8233,8000,3100,8765,9464 -sTCP:LISTEN | xargs kill
```

## Logs

- Worker: `var/local/worker.log`
- API: `var/local/api.log`
- Web UI: `var/local/web.log`
- MCP: `var/local/mcp.log`
- Temporal: `var/local/temporal.log`
