# Agent/tool sandbox image

`sandbox/Dockerfile` builds the image the platform runs deterministic work in (tests, builds, scanners, git) when
`AIDLC_EXECUTOR=k8s`: each command is a Kubernetes Job in the sandbox namespace, with a default-deny network
policy plus the egress allowlist (`infra/helm/aidlc/templates/networkpolicy.yaml`).

| Area | Tools |
|---|---|
| Runtimes | Node 22, Python 3.12, git, git-lfs, build-essential |
| Package managers | npm, pnpm, pip, uv |
| Lint / types | ruff, mypy, ESLint |
| Tests | pytest, Playwright (Chromium + OS deps), k6 |
| Security | semgrep, gitleaks, trivy, osv-scanner |
| Accessibility | axe-core CLI |
| Forge | gh |

```bash
docker build -t ghcr.io/aidlc/sandbox:0.1.0 sandbox/
docker run --rm -it -v "$PWD:/workspace" ghcr.io/aidlc/sandbox:0.1.0 bash
```

- Runs as uid 10001 (`sandbox`), working directory `/workspace`; the root filesystem can be read-only.
- Tool versions are build args (`--build-arg TRIVY_VERSION=...`); multi-arch via `docker buildx --platform
  linux/amd64,linux/arm64`.
- Point the platform at it with `AIDLC_SANDBOX_IMAGE` (Helm: `sandbox.image`).
