# AIG AI Ecosystem VS Code Extension: Product and Technical Specification

| | |
|---|---|
| Component | `vscode-extension/` (VSIX `aig-ai-ecosystem-<version>.vsix`) |
| Baseline | Behaviour of the extension at version **0.16.0** (October 2026) |
| Extension id | `aig.aig-ai-ecosystem` (publisher `aig`, name `aig-ai-ecosystem`) |
| Purpose of this document | Input for AI-DLC agents that build or extend the VSIX. It is the contract the build must satisfy. |
| Related sources | `vscode-extension/README.md`, `vscode-extension/CHANGELOG.md`, `backend/contracts/`, `sdk/typescript/src/platform`, `web/packages/ui`, `docs/sdk-modes.md`, `docs/evals.md`, `docs/demo-data.md`, `docs/claude-code-gateway.md` |

Requirement ids (`FR-…`, `NFR-…`) are stable and are used by the acceptance criteria in section 18. Where the
spec says MUST, the build fails acceptance if the behaviour is missing. SHOULD marks a strong default that can
change with a recorded reason.

---

## 1. Product overview

### 1.1 What it is

The AIG AI Ecosystem extension connects VS Code to the AIG platform backend (`backend/platform-api`). From one
Activity Bar container it gives developers:

- sign-in (Microsoft Entra ID in dev/stage/prod; a browser or email sign-in against a local backend)
- their own live token usage, cost and usage limits (a sidebar tab and a full dashboard)
- a chat that streams model answers through the AIG gateway, plus the `@aig` participant in VS Code's Chat view
- the agent catalog: run agents (form or chat), background runs with notifications, and registering existing agents
- **AIG: New Agent**: scaffold a starter agent, register it as a draft, create its environment with the pinned AIG SDK
- local evals (`aig eval run`) with a report view
- Floci (local AWS services) start/stop, with terminal environment variables
- Claude Code configuration for the user's tier, with session sharing to the `aig` CLI
- connection status, model-routing test and diagnostics

### 1.2 Architecture principle: no keys in the extension

```
VS Code extension ──(user's own bearer token)──► AIG platform-api ──(server-held keys)──► Portkey gateway ──► model providers
        │                                               │
        └── never talks to Portkey or a provider        └── adds keys, routing config, metadata, trace id; reports to Fiddler
```

- The extension MUST NOT receive, store, log or send a model-gateway (Portkey) key, and MUST NOT use VS Code
  SecretStorage.
- Its only credential is the signed-in user's own token: an Entra ID access token, or `dev:<email>` against a
  local backend. That token goes only to the configured backend URL.
- The backend drops any `x-portkey-*` header a client sends.

### 1.3 Users

| Persona | Needs |
|---|---|
| AIG developer (laptop or VDI) | Sign in, chat and `@aig` help, see their usage, scaffold and run agents, run evals |
| Agent owner / team | Register an existing agent server, verify it, run dev/stage/local versions |
| Platform engineer (local backend) | Test as several users (tiers, cost modes, usage limits) against `AIG_ENV=local` |
| Platform admin | Claude Code gateway status for every tier |

### 1.4 Out of scope

- Talking to Portkey, Fiddler or any model provider directly.
- Managing keys or secrets (users get keys through the platform's key process).
- Admin portal features (model approval, MCP registry approval, workspace orchestration). These live in `web/`.
- Publishing to the public Marketplace (`private: true`, `license: UNLICENSED`). Distribution is a VSIX file.

---

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Language | TypeScript 5.5+, `strict`, `noUnusedLocals`, `noImplicitReturns`, `isolatedModules`; ES2022 modules, `moduleResolution: Bundler` |
| VS Code | `engines.vscode: ^1.90.0` (first version where the Chat participant API is stable). `@types/vscode` MUST be `~1.90.0` and match `engines` (enforced by a test) |
| Node | Node 22 / npm 10 for development (`.nvmrc` at the repo root). Extension host bundle targets `node18` |
| Bundler | esbuild 0.23. Two contexts: the extension host (`src/extension.ts` → `dist/extension.js`, CJS, platform node, externals `vscode`, `bufferutil`, `utf-8-validate`) and the webviews (IIFE, browser, `es2020`, entries `dashboard`, `sidebar`, `signin`, `agentrun` → `dist/webview/<app>.js`). Minified with no sourcemap in production; sourcemaps in watch/dev |
| Runtime dependencies | Only `ws` ^8. The VSIX is packaged with `--no-dependencies`, so everything else is bundled |
| Monorepo source bundled through aliases (`aliases.mjs`, mirrored in `tsconfig.json` `paths` and `vitest.config.mjs`) | `@aig/sdk/platform` → `../sdk/typescript/src/platform/index.ts` (backend mode of the AIG SDK); `@aig/ui` → `../web/packages/ui/src/index.ts` (widgets, message types, shell, CSS); `@aig/design-tokens` → `../web/packages/design-tokens/src/index.ts`; `@aig/demo-data` → `../web/packages/demo-data/src/index.ts` (temporary) |
| Tests | vitest 2, `environment: node`, `test/**/*.test.ts`. Logic that needs no `vscode` lives in modules that do not import `vscode` and is unit tested directly; `vscode` and `ws` are mocked for host tests |
| Packaging | `npx @vscode/vsce package --no-dependencies --skip-license` |
| Platforms | macOS, Linux and Windows. Paths, venv layouts (`bin` vs `Scripts`, `.exe`), PATHEXT and shell quoting MUST be handled per platform |

---

## 3. Extension manifest (`package.json`)

### 3.1 Identity and activation

- `name: aig-ai-ecosystem`, `displayName: AIG AI Ecosystem`, `publisher: aig`, `icon: media/aig-icon.png`,
  `categories: ["Other", "AI"]`, `main: ./dist/extension.js`.
- `repository.url` holds a placeholder (`https://__AIG_REPO_URL__/aiecosystem`).
- `activationEvents: ["onStartupFinished", "onUri"]`.

### 3.2 Untrusted workspaces (FR-MAN-1)

`capabilities.untrustedWorkspaces.supported = "limited"`. Its `restrictedConfigurations` MUST equal the
machine-scoped settings list in section 4.2 exactly (enforced by a test against `MACHINE_SCOPED_SETTINGS` in
`src/trustedSettings.ts`).

### 3.3 Views

| Container / view | Definition |
|---|---|
| Activity Bar container | id `aig`, title `AIG AI Ecosystem`, icon `media/aig-activitybar.svg` |
| `aig.signin` | webview view "Welcome", `when: !aig.signedIn` |
| `aig.main` | webview view "AIG", `when: aig.signedIn`, `retainContextWhenHidden: true` |

The context key `aig.signedIn` is set by the live service (section 7).

### 3.4 Menus

| Menu | Entries |
|---|---|
| `view/title` on `aig.main` | `navigation@0` New Agent, `@1` Open Dashboard, `@2` Refresh, `@3` Sign Out; `1_user@1` Switch user; `2_claudeCode@1` Configure Claude Code, `@2` Claude Code status |
| `view/title` on `aig.signin` | `1_user@1` Sign in as… |
| `commandPalette` | `aig.refresh` and `aig.flociStatus` hidden (`when: false`). Run Agent, Register Existing Agent, Open Agents, Test model routing, Switch user, Configure Claude Code and Claude Code status only `when: aig.signedIn` |
| `editor/context` | Explain Selection (`aig@1`) and Fix Selection (`aig@2`), `when: editorHasSelection` |
| `explorer/context` | Run Evals `when: resourceFilename == aig-eval.yaml`; Update SDK `when: resourceFilename == pyproject.toml \|\| resourceFilename == package.json` |
| `editor/title` | Run Evals (navigation) on `aig-eval.yaml` |

### 3.5 Task definitions

- `aig-eval`: required `mode` (`online` | `offline`), optional `config` (path to `aig-eval.yaml`).
- `aig-setup`: required `step` (a label such as create .venv, pip install, npm install or pipx install).

### 3.6 Chat participant

id `aig.assistant`, name `aig`, fullName `AIG Assistant`, `isSticky: true`, commands `explain`, `fix`, `tests`
(section 9).

---

## 4. Settings

### 4.1 Settings list

| Setting | Type / values | Scope | Default | Meaning |
|---|---|---|---|---|
| `aig.environment` | `local` \| `dev` \| `stage` \| `prod` | machine | `dev` | Backend environment |
| `aig.backendUrls` | object `{local, dev, stage, prod}` (no extra keys) | machine | `local: http://localhost:8080`; others `https://__AIG_BACKEND_URL_<ENV>__` | Backend base URL per environment |
| `aig.auth.scopes` | object `{local, dev, stage, prod}` | machine | `api://__AIG_API_CLIENT_ID_<ENV>__/.default` | Entra ID scope per environment |
| `aig.jobProfile` | `underwriting` \| `claims` \| `operations` \| `general` | resource | `general` | Sent as `x-aig-job-profile`; the backend checks it against the user's allowed profiles |
| `aig.devUser` | string (email) | machine | `""` | Local only: skip the browser and use `dev:<email>`. Ignored outside `local` |
| `aig.host` | `laptop` \| `vdi` | (default) | `laptop` | Written as `AIG_HOST` into the `.env` of new agents |
| `aig.cli.path` | string | machine | `aig` | `aig` CLI. `aig` means: the agent's `.venv` first, then `PATH`. An absolute path pins it |
| `aig.evals.loadDotenv` | boolean | (default) | `true` | Pass the agent folder's `.env` to `aig eval run`; variables already set win |
| `aig.sdk.source` | `registry` \| `bundled` \| `monorepo` | machine | `registry` | Where the SDK comes from (section 11) |
| `aig.sdk.indexUrl` | string | machine | `""` | pip `--index-url`. Ignored if it contains `__`, credentials, or a non-http(s) scheme |
| `aig.sdk.npmRegistry` | string | machine | `""` | `--@aig:registry`. Same rules as above |
| `aig.newAgent.setupEnvironment` | boolean | (default) | `true` | New Agent creates the environment and runs `aig doctor` |
| `aig.floci.command` | string | machine | `floci` | Floci executable |
| `aig.floci.startArgs` | string[] | machine | `["start"]` | Start arguments |
| `aig.floci.stopArgs` | string[] | machine | `["stop"]` | Stop arguments. Empty means close the Floci terminal |
| `aig.floci.endpoint` | string | machine | `http://localhost:4566` | Floci endpoint |
| `aig.floci.region` | string | (default) | `us-east-1` | `AWS_REGION` / `AWS_DEFAULT_REGION` for terminals, only when not already set |
| `aig.floci.showStatusBar` | boolean | (default) | `true` | Floci status bar item and endpoint probing |
| `aig.claudeCode.shareSession` | boolean | machine | `true` | Write `~/.aig/credentials` for the `aig` CLI (section 13.3) |
| `aig.demoData` | boolean | window | `false` | **Temporary.** Sample data from an in-memory backend (section 14) |

### 4.2 Trusted (machine-scoped) settings (FR-CFG-1)

These settings MUST be declared `"scope": "machine"` AND read through `trustedValue()`. Workspace and folder values
are ignored, so a cloned repository cannot redirect the token, the executables or the package index:

`aig.environment`, `aig.backendUrls`, `aig.auth.scopes`, `aig.devUser`, `aig.cli.path`, `aig.floci.command`,
`aig.floci.startArgs`, `aig.floci.stopArgs`, `aig.floci.endpoint`, `aig.sdk.source`, `aig.sdk.indexUrl`,
`aig.sdk.npmRegistry`, `aig.claudeCode.shareSession`.

`trustedValue(inspect)` returns policy value > global (user/machine/remote) value > default. An object value is
shallow-merged over the default object, so a partial user map still falls back to the defaults for the other
environments.

### 4.3 Configuration resolution (FR-CFG-2), in pure `src/config.ts`

1. `env` = the setting if it is a valid environment, otherwise `dev`.
2. Backend URL = `backendUrls[env]` (or the default), validated with `validatePlatformUrl` from
   `@aig/sdk/platform`:
   - A value containing `__` is a placeholder and counts as **not configured**.
   - `http://` is allowed only when `env == local` and the host is `localhost`, `127.0.0.1` or `[::1]`.
     dev/stage/prod always require `https`, loopback included.
   - The URL is normalised without a trailing slash.
3. Auth plan:
   - `local`: if `aig.devUser` is empty → `localBrowser`; if it is a valid email → `dev {email}`; otherwise
     `unconfigured` ("aig.devUser is not a valid email").
   - other envs: a non-placeholder scope → `microsoft {scope}`; a placeholder → `unconfigured`.
   - demo mode overrides everything with `demo` (section 14).
4. `jobProfile` = the setting if valid, otherwise `general`.
5. `configured` is true only when the URL and the auth plan are both usable. `problems[]` lists human-readable
   reasons.
6. The not-configured message is exactly `AIG backend not configured for <env>`. When the environment is not
   configured the extension MUST make no network calls.

Email validation: `^[^\s@:]+@[^\s@:]+\.[^\s@:]+$`. Local sign-in emails are trimmed and lowercased.

Any change to `aig.*` settings MUST reload the config and refresh the state. If demo mode was switched off, the
demo backend's timers stop.

---

## 5. Authentication (FR-AUTH)

### 5.1 dev / stage / prod: Microsoft Entra ID

- FR-AUTH-1: Use `vscode.authentication.getSession('microsoft', [scope])`. Interactive (`createIfNone`) only on
  **AIG: Sign In**. Background checks are always `silent`. Tokens are fetched per call and never persisted or logged.
- FR-AUTH-2: React to `authentication.onDidChangeSessions` for the `microsoft` provider by refreshing state.
- Sign Out and Switch user show: "AIG uses your VS Code Microsoft account. Sign out from (or switch accounts in)
  the Accounts menu (bottom left)…".

### 5.2 local: browser sign-in

- FR-AUTH-3: **AIG: Sign In** with the `localBrowser` plan:
  1. Issue a one-time state nonce: 24 random bytes, base64url, TTL 10 minutes, consumed on use, expired entries
     pruned.
  2. Callback URI `<uriScheme>://aig.aig-ai-ecosystem/auth-callback`, passed through `env.asExternalUri`.
  3. Open `<backend>/auth/local/signin?redirect_uri=<cb>&state=<nonce>[&login_hint=<last email>]` with
     `env.openExternal`. Pass the already-encoded URL **as a string**: wrapping it in `vscode.Uri` double-encodes
     the escapes.
  4. Show "AIG: complete sign-in in your browser…", or an error if the browser could not open.
- FR-AUTH-4: The URI handler accepts only path `/auth-callback`, a state that was issued and has not expired, and
  a valid `email`. Otherwise it shows `AIG sign-in failed: <reason>` ("sign-in link expired or was not started
  from this VS Code window", "sign-in returned an invalid email"). It also refuses when the current config is not
  `local` + `localBrowser`. On success it stores the email, refreshes, focuses the Token usage tab and shows
  `AIG: signed in as <email> (local)`.
- FR-AUTH-5: The local session is stored in `globalState`: key `aig.localSignIn` maps backend URL → email, and key
  `aig.localSignIn.last` keeps the last email after sign-out to prefill the field. Only the email is stored. The
  token is `dev:<email>`, which only an `AIG_ENV=local` + `AIG_AUTH_MODE=dev` backend accepts.

### 5.3 local: email sign-in and switching users

- FR-AUTH-6: `aig.signIn <email>` (posted by the sign-in widget's email field or persona picker) and
  **AIG: Sign in as…** sign in directly as that email, with no browser round trip.
- FR-AUTH-7: **AIG: Sign in as…** and **AIG: Switch user** show a QuickPick of `LOCAL_PERSONAS` (from `@aig/ui`)
  with the current user marked "(signed in)", plus "Enter another email…" (an InputBox prefilled with the last
  user and validated). Cancelling keeps the current user.
- FR-AUTH-8: Before an email sign-in:
  - if demo mode is on, offer "Turn off sample data"
  - if `env != local`, refuse ("only available in the local environment")
  - if `aig.devUser` is set, offer "Clear aig.devUser", because it always overrides the local session.
- Local personas (`web/packages/ui/src/messages.ts`): `premium.quality@`, `premium.balanced@`,
  `premium.economy@`, `standard.quality@`, `standard.balanced@`, `free.quality@`, `free.balanced@`,
  `finance.user@`, `routing.admin@`, `usage.limit@`, `usage.standard@`, `usage.tokens@` (all `@aig.example`).

### 5.4 Sign out (FR-AUTH-9)

- demo: end the demo session.
- localBrowser: clear the session for the backend URL and show "AIG: signed out (local)".
- microsoft: point the user to the Accounts menu.
- devUser: show "nothing to sign out of (aig.devUser is set in settings)".

---

## 6. Connection state, status bar and status panel

### 6.1 State refresh (FR-STATE-1)

`AigState.refresh()` never prompts. It calls `GET /healthz`. If that answers and a session exists, it also calls
`GET /api/v1/session`. Refreshes are numbered and only the newest result is published, so stale results are
dropped. Listeners receive a `Snapshot {config, status, health?, session?, checkedAt?}`.

`/api/v1/session` MUST contain `user.email` (string), `env` (string) and `llm.base_url` (string). Otherwise it is
treated as an `invalid_session` error. Optional fields (`user.name`, `team`, `user_tier`, `cost_mode`,
`allowed_job_profiles[]`, `llm.config_id`, `fiddler.url`) are dropped when they have the wrong type.
`llm.base_url` is informational only: model calls always go to the configured backend URL, never to a URL taken
from a response.

### 6.2 Connection states (FR-STATE-2), evaluated in this order

| State | Condition | Label | Detail |
|---|---|---|---|
| `not_configured` | config not configured | not configured | `AIG backend not configured for <env> (<problems>)` |
| `unreachable` | health error or no response | unreachable | `Backend health check failed[ (HTTP n)]: <msg>` |
| `error` | `health.status != "ok"` | error | `Backend reports status "<s>"` |
| `env_mismatch` | `health.env` differs from the configured env | environment mismatch | `Extension is set to X but backend reports Y` |
| `signed_out` | no session | signed out | `Backend reachable. Run "AIG: Sign In".` |
| `unauthenticated` | session 401/403 | not authorised | `Backend rejected your session (HTTP n)` |
| `error` / `unreachable` | other session errors | | `Session request failed…` |
| `degraded` | the required server secret is not `configured` in `health.secrets` | degraded | `Connected, but backend reports required server-side secret not configured: <names>` |
| `connected` | otherwise | connected | `Connected to <env> as <email>` |

The only required secret is the gateway key. Its name MUST be assembled from fragments (`['PORTKEY','API','KEY'].join('_')`)
so the no-secrets guard still forbids the literal anywhere in `src/`. Only names and status words are ever shown.
Optional secrets are informational and never cause `degraded`.

### 6.3 Status bar (FR-STATE-3)

- Item id `aig.status`, left-aligned, priority 100, command `aig.openDashboard`.
- Text: `$(pass-filled) AIG: <env> · connected` for connected and degraded. Otherwise `$(account)` (signed out),
  `$(warning)` (not configured, env mismatch) or `$(circle-slash)`, followed by `AIG: <env> · <label>`.
- Colour `#32c9a6` when connected and `#33b6ea` when signed out. Background `statusBarItem.warningBackground` for
  degraded and env mismatch, `statusBarItem.errorBackground` for unauthenticated and error.
- Tooltip: the detail text plus "Click to open the AIG dashboard."

### 6.4 Backend error messages (FR-STATE-4, `describeBackendError`)

| Condition | Message |
|---|---|
| `portkey_key_not_configured` | "The <env> backend is running but its model-gateway key has not been configured yet. Ask the platform team to load it on the backend." |
| `usage_not_configured` | "Usage reporting is not enabled on the <env> backend." |
| no status (network) | "Could not reach the AIG backend (…)." |
| 400 | "Request rejected by backend: …" |
| 401 | "Not signed in or session expired. Run "AIG: Sign In"." |
| 403 | "You are not authorised for this action on the AIG backend." |
| 429 | "Rate limited by the AIG platform. Try again shortly." |
| 504 | "The model gateway timed out. Try again." |
| 5xx | "AIG backend error (HTTP n)[: msg]" |

Messages never echo headers or tokens.

### 6.5 Status panel (FR-STATE-5): **AIG: Open Status Panel**

A single editor webview (`aig.status`), with a nonce CSP and server-rendered HTML themed from
`@aig/design-tokens`. Light, dark and high-contrast themes all work; high contrast defers to `--vscode-*`
variables. It has four cards:

- Connection: state dot, detail, problems, backend URL, job profile, last checked.
- Session: user, team, tier, job profiles, LLM endpoint (informational), routing config id, Fiddler URL.
- Backend secrets: name, required or optional, and status, with a note that keys live only on the backend.
- Actions: Dashboard, Refresh, Sign in, Switch environment, Ask.

Accepted messages are limited to `refresh`, `signIn`, `selectEnvironment`, `ask` and `openDashboard`.

---

## 7. Live connection service (FR-LIVE)

`LiveService` owns one WebSocket per signed-in session. The sidebar, the dashboard and the run panels share it.
It is built on `@aig/sdk/platform` (`createPlatformClient`, `client.live()`, `client.chat.stream()`,
`client.invoke.*`).

### 7.1 Client configuration (FR-LIVE-1)

| Option | Value |
|---|---|
| Base URL | validated backend URL |
| WebSocket | Node `ws` package. Bearer token in the **Authorization header of the upgrade request** (`wsAuth: 'header'`), never in the URL |
| WS URL | `ws(s)://<backend>/api/v1/ws` |
| WS options | `handshakeTimeout: 10_000`, `maxPayload: 4 MiB` |
| Timeouts | REST 15 s; stream start 120 s |
| Reconnect | exponential backoff from 1 s to 30 s (SDK default) |
| Close codes | `4401` unauthenticated, `4403` forbidden origin, `1008` policy |

### 7.2 Session lifecycle (FR-LIVE-2)

- `signedIn = configured && backendUrl && hasSession(cfg)`. When it changes, set the context key `aig.signedIn`,
  fire `onDidChangeSignedIn` and focus `aig.main` on sign-in.
- Session key = `env|backendUrl|authKind|localUser`. When it changes (sign-in, sign-out, environment, backend or
  local user switch), stop the old socket, clear usage, limits and ready info, start a new socket and fire
  `onDidChangeSession`.
- `scope` = `env|backendUrl[|localUser]` (empty when signed out). It scopes locally stored data such as tracked
  runs.

### 7.3 Usage loading (FR-LIVE-3): nothing polls

- Usage (`DashboardData` for a range of 7, 30 or 90 days; default 30) loads **once** at session start: over the
  socket (`usage.subscribe` answered by exactly one `usage` frame), or once over HTTP
  (`GET /api/v1/usage/dashboard?days=`) if the socket has not opened after **4 s**.
- After that it reloads only on user action: the refresh button/icon (`aig.refresh`) or a range change. Each sends
  one request over the socket, or one HTTP fetch right away if the socket is down.
- A reconnect does not refetch usage unless nothing has loaded yet. Chats do not refetch usage.
- Usage limits (`GET /api/v1/usage/limits`) follow the same rule: once at session start, then with `refresh=true`
  on refresh or range change. A 404 (other than `usage_not_configured`) means the endpoint does not exist on this
  backend: skip quietly and keep the card hidden. Network errors map to code `error`. Stale responses are dropped
  with a sequence number.
- Metrics the backend reports as `unavailable` show as **—** with a notice.

### 7.4 Chat streaming (FR-LIVE-4)

- `startChat(messages, jobProfile, handlers)` uses the WebSocket when it is open, otherwise HTTP SSE
  (`POST /api/v1/llm/chat/completions`). The backend attributes the traffic to agent `ide.vscode`.
- `chat.done` carries the trace id and, over the WebSocket, usage, plus `model` and `route`
  (`{user_tier, cost_mode, job_profile, usage_state}`) when reported.
- Errors are reported as `code` (or `http_<status>`) plus a message.
- The backend allows at most **4 concurrent streams per connection**, shared by chats and agent runs.
- Live `agent.invocation.status` pushes that belong to no run on this socket are re-emitted as `onAgentStatus`
  (used for background runs).

### 7.5 Webview bridge (FR-LIVE-5)

`bridgeWebview(webview, live)` forwards every live host message to the webview, and handles:

- `ready`: replay the snapshot (`init`, `live`, then `usage`, `usage.error` or `usage.loading`, then limits)
- `range`, `refresh`
- `signIn [email]`, `openDashboard`, `openPanel`, `signOut`, `selectEnvironment` (run as `aig.*` commands)
- `chat.send` and `chat.cancel`

Running chats are cancelled when the webview is disposed.

---

## 8. User interface surfaces

### 8.1 Webview rules (NFR-UI-1)

- Each client-rendered webview loads `dist/webview/<app>.js` inside the HTML shell from `@aig/ui renderShell`.
  The shell gets a fresh nonce, the `cspSource`, logo URIs (`media/aig-logo.svg`, `media/aig-logo-white.svg`),
  font URIs (`media/inter-var.woff2`, `media/jetbrains-mono-var.woff2`), header title and subtitle, the env, and
  the demo flag.
- `localResourceRoots` = `media/` and `dist/webview/` only. `enableScripts: true`. The CSP is `default-src 'none'`
  plus nonce scripts and styles.
- Webview entry files are thin. Each calls one `@aig/ui` mount function (`mountSidebar(…, {agents: true})`,
  `mountDashboard`, `mountSignin`, `mountAgentRun`) with a host from `postMessageHost(acquireVsCodeApi())`.
  `acquireVsCodeApi` is bound only in `src/webview/host.ts`.
- **Webviews never see a token or key.** Every inbound message goes through `parseWebviewMessage` (from
  `@aig/ui`), which validates ids, sizes and enums and requires exactly one of `input` or `messages`. Anything
  invalid is dropped.
- Views queue host messages until the widget posts `ready`, then flush them after the bridge's catch-up snapshot.
- When `aig.demoData` is toggled, every view re-renders its HTML so the gold **Sample data** badge follows the
  setting.

| App | Title | Header | Sub-header |
|---|---|---|---|
| `dashboard` | AIG Dashboard | Tokenomics | Token usage across the AIG model gateway |
| `sidebar` | AIG AI Ecosystem | AI Ecosystem | Token usage · Chat · Agents |
| `signin` | AIG AI Ecosystem | AI Ecosystem | Welcome |
| `agentrun` | AIG Run Agent | Run agent | Form or chat, streamed through the AIG platform |

### 8.2 Signed-out view `aig.signin` (FR-UI-1)

A welcome card with one **Sign In** button. It receives `{type:'status', env, tone, label, detail, method, user?}`:

- `method` is `browser` (local), `microsoft`, `devUser` (also demo) or `unconfigured`.
- In `browser` mode the widget adds an email field and a persona picker, prefilled with the last local user.
- `tone` is `ok` (connected, signed out), `warn` (degraded, env mismatch, not configured) or `bad`.
- On `ready` it sends the status and refreshes state. It accepts `signIn [email]` and `selectEnvironment`.

### 8.3 Signed-in sidebar `aig.main` (FR-UI-2)

Three tabs: **Token usage**, **Chat**, **Agents**.

- Token usage: the user's own usage for 7/30/90 days, plus the usage limits card. The limits card shows the state
  (Normal / Near limit (soft) / Limit reached (hard) / Can't check), one bar per daily or monthly limit (requests,
  tokens, cost) with the 80% soft threshold marked, unreadable limits greyed, or "No usage limits for your
  account".
- Chat: streams over the WebSocket and falls back to HTTP SSE. A route chip shows the model and route, with usage
  tags: `⚠ usage soft (downgraded)`, `⛔ usage limit reached → cheapest model`, `usage not checked`.
- Agents: section 10.1.
- Commands `aig.openTokenUsage`, `aig.openChat` and `aig.openAgents` focus the view and post `{type:'tab', tab}`.
  If signed out they run `aig.signIn` instead.
- `prefillChat(text)` (used by Explain/Fix Selection) reveals the Chat tab and posts `chat.prefill`. It does not
  send.

### 8.4 Dashboard (FR-UI-3): **AIG: Open Dashboard**

A single editor webview `aig.dashboard` titled "AIG Dashboard", `retainContextWhenHidden`. It shows requests,
tokens, cost, per-model token usage (prompt vs completion), the limits card, a 7/30/90 range picker and a refresh
button. Opening it when it is already open only reveals it and does not refetch. It closes on sign-out. If signed
out, the command runs Sign In instead.

### 8.5 Host → webview messages (`HostMessage`, `@aig/ui/messages.ts`)

`init {info: InitInfo}`, `live {status, detail?}` (`idle|connecting|open|reconnecting|unauthorized|closed`),
`usage.loading`, `usage {range, data}`, `usage.error {code, message}`, `usage.limits {data}`,
`usage.limits.error {code, message}`, `chat.prefill {text}`, `chat.delta {localId, text}`,
`chat.done {localId, usage?, traceId?, model?, route?}`, `chat.error {localId, code, message}`, `tab {tab}`,
`catalog.loading`, `catalog {items, teams, tags}`, `catalog.error`, `agent.runs {runs}`, `agent.target {target}`,
`agent.target.error`, `agent.status {...}`, `agent.delta`, `agent.output`, `agent.done`, `agent.error`,
`status {...}` (signed-out view).

`InitInfo` = `{env, user?, tier?, costMode?, team?, jobProfile, jobProfiles[], range}`. Values from the WebSocket
`ready` frame take precedence over `/api/v1/session`, which takes precedence over the local session email.

### 8.6 Webview → host messages (`WebviewMessage`)

`ready`, `range {days: 7|30|90}`, `refresh`, `openDashboard`, `openPanel`, `signOut`, `signIn {email?}`,
`selectEnvironment`, `chat.send {localId, messages, jobProfile}`, `chat.cancel {localId}`, `catalog.refresh`,
`agent.open {agentId, env?, version?}`, `agent.register`, `agent.run.show {invocationId}`, `agent.runs.refresh`,
`agent.invoke {localId, agentId, env?, version?, mode: stream|background, input? | messages?, sessionId?}`,
`agent.cancel {localId, invocationId?}`, `agent.poll {localId, invocationId}`, `clipboard.copy {text}`.

Validation regexes: agent id `^[A-Za-z0-9._-]{1,64}$`, version `^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$`, session id
`^[A-Za-z0-9._:-]{1,128}$`, invocation id `^[A-Za-z0-9_-]{1,64}$`, env `local|dev|stage|prod`.

---

## 9. Coding assistant

### 9.1 `@aig` chat participant (FR-CHAT-1)

- Register only when `vscode.chat.createChatParticipant` exists (older hosts: no-op). Icon `media/aig-icon.png`.
- Signed out: reply "You are not signed in to the AIG platform." with a **AIG: Sign In** button.
- Slash commands come from `request.command`, or are parsed from the prompt (`/fix handle nulls`). Unknown
  commands stay as text.
- Context order:
  1. explicit references (`#file`, `#selection`, a `Location` or `Uri`, not `untitled`); the first readable one wins
  2. otherwise the active editor's selection, or the whole file, but only when a slash command is used or the
     prompt matches the context hint (for example "this function", "the selected code", `#selection`, "explain it")
- With no prompt and no context, reply with guidance. When context is used, call `stream.reference()`.
- History: this participant's earlier turns only, the last 10, within budget, starting with a user turn.
- Limits: 24,000 characters of code context and about 40,000 characters per request, to stay under the backend's
  64 KiB WebSocket frame. Truncation is marked `… [truncated N characters]`.
- Code fences use more backticks than any run inside the code. Language ids are mapped (`typescriptreact`→`tsx`,
  `javascriptreact`→`jsx`, `shellscript`→`bash`).
- Base system prompt: "You are the AIG coding assistant inside VS Code, served through the AIG model gateway. Be
  concise and precise. Use Markdown; put code in fenced blocks with a language. Never ask for or reveal API keys
  or credentials. If code context is provided, base the answer on it and say when something cannot be determined
  from it."
- Per-command tasks:
  - `explain`: summary, how it works, edge cases, risks.
  - `fix`: list problems, then the corrected code in one block.
  - `tests`: pytest or vitest/jest, covering normal, edge and error cases, in one block.
- Default asks when the prompt is empty: "Explain this code." / "Fix the problems in this code." / "Write unit
  tests for this code."
- Progress text "Asking the AIG gateway (<jobProfile>)…". Stream deltas as markdown. Cancellation cancels the
  stream. The result metadata holds the command, trace id, tokens, model and route. `portkey_key_not_configured`
  maps to "The Portkey gateway key is not configured on the AIG backend."
- Follow-ups: after `explain` → "Write tests for it" (`tests`); after `fix` → "Write tests for the fix".

### 9.2 Explain / Fix Selection (FR-CHAT-2)

These editor context menu commands require a non-empty selection or file ("AIG: open a file and select some code
first."). They prefill the sidebar Chat composer with an ask plus the formatted context (up to 30,000 characters)
and do not send. The user reviews and presses Enter.

### 9.3 AIG: Ask (FR-CHAT-3)

Takes an InputBox prompt (or an argument). Streams over HTTP SSE with `x-aig-job-profile` and a new
`x-aig-trace-id` into the `AIG` output channel: `> prompt`, `[ask] env=… profile=… trace=…`, deltas, then
`[ask] done trace=…`. If the stream ended without `[DONE]` it warns "response may be incomplete". The notification
progress is cancellable. Errors go through `describeBackendError`.

### 9.4 AIG: Test model routing (FR-CHAT-4)

Requires sign-in. Picks a job profile: the configured one first if it is allowed, then the user's other allowed
profiles; skipped when only one profile exists. Calls `POST /api/v1/routing/test {job_profile}`. Shows
`Routing: <model> · <tier> · <cost mode> · <profile> — <ms> ms (<provider>)` and, when the usage state is not
normal, ` · usage soft: downgraded because daily requests 4 / 5` or similar.

Actions:

- **Copy trace id**.
- **Details**: a QuickPick of rows (Result, Model, Provider, Tier, Cost mode, Job profile, Usage state, Latency,
  Tokens, Cache, Answer, Error, Trace id). Selecting a row copies its value.

All rows are also logged to the output channel as `[routing] key=value …`.

---

## 10. Agents

### 10.1 Catalog and recent runs (FR-AG-1)

- `GET /api/v1/catalog` returns agents the user may run: active or deprecated, a verified version, and allowed by
  their access. Malformed items are dropped. Team and tag facets come from the response or are derived from the
  items.
- The Agents tab shows search, team and tag filters, and a card per agent (name, lifecycle, team, default version
  and env, **Run**). Below the cards: **+ Register existing agent** and **My recent runs**.
- Recent runs = `GET /api/v1/invocations?mine=true&limit=20`, merged with locally tracked background runs that the
  server list does not show yet. Newest first, at most 20. Clicking a run opens it.
- The catalog reloads on sign-in, sign-out and environment change. Signed out, it shows
  `catalog.error not_connected` "Sign in to the AIG backend to see agents."
- **AIG: Run Agent…**: a QuickPick over the catalog (label = name; description = team · v<version> · env;
  detail = description). The empty placeholder suggests Register Existing Agent. Picking opens the run panel. A
  failed load shows "Could not load the agent catalog…".

### 10.2 Run panel (FR-AG-2)

- One editor webview per agent (`aig.agentRun`), reused when it is open. Title
  `Run: <name> (<env> v<version>)`. `retainContextWhenHidden`. Icon `media/aig-icon.png`.
- **Form** mode is generated from the version's input JSON Schema. **Chat** mode keeps a session id.
- Users run the verified **prod** version. Owners and their team may also pick dev, stage or local versions.
- Streaming: `client.invoke.stream(agentId, body, {env, version, transport: 'auto'})` runs over the WebSocket when
  it is open, otherwise HTTP SSE. Run events (`status`, `delta`, `output`, `error`, `done`) map to `agent.*`
  messages with the trace id, usage and duration.
- **Cancel** stops the stream. For a background run it calls `POST /api/v1/invocations/{id}/cancel`.
  **Copy** copies the result.
- Closing the panel, or signing out, cancels running foreground runs. Background runs continue.
- `503 agent_invocation_disabled` is explained in the panel.
- An agent missing from the catalog shows "<id> is not in your agent catalog (not registered, not verified or not
  shared with you)."
- A past run opened from recent runs shows its stored status and output. If its agent is no longer in the catalog,
  the panel builds a target from the invocation record.

### 10.3 Background runs (FR-AG-3)

- Started with "Run in background": `client.invoke.background()` returns 202 `{invocation_id, version, env}`. The
  panel shows `queued`.
- Tracked runs are stored in `globalState` key `aig.agents.backgroundRuns`, scoped by `live.scope`. At most 25
  are kept, newest first. Each holds only the invocation id, agent id, name, env, version, createdAt, status,
  notified flag, duration and error code. Entries read back are validated.
- Completion is detected from:
  - live `agent.invocation.status` pushes; on a final status the extension fetches the record when possible
  - polling `GET /api/v1/invocations/{id}` with delays 3 s, 5 s, 10 s, 20 s, 30 s, then every 60 s, for at most
    **2 h** after creation
  - a server recent-runs list that already reports a final status.
- Polling resumes after a restart or sign-in. A 404 or 403 (`invocation_not_found`, `http_404`, `forbidden`,
  `http_403`) stops tracking.
- On completion, show `<name> finished: <status>`: an information message if it succeeded, a warning otherwise,
  with **Open result**, which opens the run panel showing that run. A user cancel marks the run notified, so no
  notification appears.
- While a panel shows a background run, the widget polls every 3 s through `agent.poll`.

### 10.4 Register Existing Agent (FR-AG-4)

A 10-step wizard (`AIG: Register Existing Agent (n/10)`, `ignoreFocusOut`). Cancelling at any step aborts.

| Step | Field | Validation |
|---|---|---|
| 1 | Agent id | `^[A-Za-z0-9._-]{1,64}$` |
| 2 | Display name | 1–200 characters (defaults to the id) |
| 3 | Description | ≤ 500 characters |
| 4 | Tags (comma-separated) | ≤ 20 unique tags, each `^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$` |
| 5 | Version env | dev/stage/prod, plus `local` when connected to the local backend |
| 6 | Endpoint | absolute URL, no credentials, no `#fragment`; `https`, or `http` only for loopback when env is `local` |
| 7 | Version | `AGENT_VERSION_RE` (default `1.0.0`) |
| 8 | Auth type | `none` \| `api_key` \| `oauth_client_credentials` |
| 9 | Secret **reference** (not for `none`) | Secrets Manager ARN `^arn:aws[a-z-]*:secretsmanager:[a-z0-9-]+:\d{12}:secret:[A-Za-z0-9/_+=.@-]{1,512}$`, or `local:[A-Z][A-Z0-9_]{0,63}` when env is local. The wizard never asks for a secret value |
| 10 | Input schema | None, or a JSON file (≤ 256 KiB, must be a JSON object; on error offer "Pick another file") |

Then:

1. Re-validate every answer.
2. `client.agents.ensureRegistered({agent_id, name, description?, tags?, lifecycle: 'draft'})`. An existing agent
   the user owns is reused.
3. `client.agents.versions.register(id, {version, env, kind: 'https', endpoint, protocol: 'aig-http/1', input_schema, auth: {type, secret_arn}})`.
4. Reload the catalog and offer **Verify now**. That calls
   `POST /api/v1/agents/{id}/versions/{v}/verify {env}`, which runs health, invocation, gateway and trace checks.
   Show `<id> v<v> verified[ and activated]: …` or `failed verification (code): …`, with **Show details** (one line
   per check in the output channel). Reload the catalog when verification passes.

Only error codes are logged, never inputs or outputs. Only verified versions appear in the catalog.

---

## 11. New Agent and SDK setup

### 11.1 AIG: New Agent (FR-NA-1)

The command is also the `+` in the sidebar title. Steps:

1. **Template**: from `dist/templates.json` (schema `aig-templates/v1`), ordered `langgraph-py`, `strands-py`,
   `langgraph-ts`. Show name, language · framework and description. If the file is missing: "starter templates
   are missing from this build".
2. **Agent id** `^[A-Za-z0-9._-]{1,64}$` (placeholder `uw-quote-assistant`).
3. **Display name** (≤ 200, defaults to the id).
4. **Team**: from the session or ready frame. If it is unknown or invalid, ask for a team slug
   (`^[A-Za-z0-9._-]{1,64}$`).
5. **Parent folder**: create `<parent>/<agentId>/`, which MUST be missing or empty.
6. **Scaffold**, byte-identical to `aig init` (`sdk/python/src/aig_sdk/cli.py`):
   - values: `agent_id`, `team`, `project` = slug of the folder basename, `package` = project with
     non-`[A-Za-z0-9_]` characters replaced by `_` and lowercased, `description` = `<template> agent <id>`
   - only placeholders the template declares are substituted, longest sample first, in file contents AND
     relative paths
   - excludes: the template's own excludes plus `.venv`, `node_modules`, `__pycache__`, `.pytest_cache`, `dist`,
     `.env`, `package-lock.json`, `*.egg-info`, `.aig-wheels`, `aig-template.json`, matched per path component
     with glob support
   - refuse any path that escapes the target. Write mode 0755 for executable files, 0644 otherwise
   - in `aig-agent.yaml`, set the top-level `name`, `display_name` and `description` lines to JSON-quoted values.
7. **Register** as a draft if signed in: `POST /api/v1/agents {agent_id, name≤200, description≤500, lifecycle: "draft"}`
   with the user's own token. The backend sets owner and team. `409 agent_exists` is reported with the existing
   team and owner and is not a failure. If not signed in, or registration fails, keep the scaffold and explain
   how to register later.
8. **`.env`** (mode 0600) from `.env.example`:
   - header `# Generated by AIG: New Agent (VS Code) from .env.example. Non-secret AIG_* values only; .env is gitignored.`
   - set `AIG_AGENT_ID`, `AIG_TEAM` (the registered team if valid), `AIG_ENV`, `AIG_HOST`,
     `AIG_PLATFORM_API_URL` (never the demo URL), `AIG_USER_TIER` (premium/standard/free only),
     `AIG_JOB_PROFILE`, and `AIG_FIDDLER_APPLICATION_ID` when registration returned one (also written to
     `.env.example`)
   - MUST refuse to write any variable matching `(_KEY|_SECRET|_TOKEN|_PASSWORD)$`. Key fields keep their
     `__REPLACE_ME_` placeholders, with a comment above the first key field: "Keys are NOT filled in by the AIG
     extension: get them through the platform's key process…"
   - values containing newlines are rejected. Missing keys are appended.
9. **Environment**, if `aig.newAgent.setupEnvironment` is on: section 11.2.
10. **Summary** notification: registered / already registered (with the owning team if it differs) / NOT
    registered, plus environment ready (source, doctor result) or not, plus "Fill in the key placeholders in .env
    through the platform's key process." Actions: **Open Folder**, **Open in New Window**, **Add to Workspace**.

All progress shows in one notification. Details go to the `AIG` output channel with the `[new-agent]` prefix.

### 11.2 Project environment and SDK install (FR-SDK-1)

- Requires a **trusted workspace**. Otherwise: "environment not created: trust the workspace first…".
- Language detection: `pyproject.toml` means python (wins); `package.json` means node.
- SDK pins `{python, typescript}` come from `dist/templates.json` `sdk`. The bundled artifacts come from
  `dist/sdk/manifest.json`. Templates depend on the SDK **by version**, never on repo paths.
- Python interpreter search: POSIX `python3.12`, `python3.13`, `python3.11`, `python3.10`, `python3`, `python`;
  Windows `py -3`, `python`, `python3`. If none is found, show the guidance text (Python 3.10+ needed).
- Sources:

| Source | Python | Node |
|---|---|---|
| `registry` (default) | rewrite every `aig-sdk[...]<op><v>` in `pyproject.toml` to `==<pin>`; `<py> -m venv .venv`; `.venv/bin/python -m pip install [--index-url U] -e .[dev]` | `@aig/sdk: <pin>` in `package.json`; `npm install --no-audit --no-fund [--@aig:registry=U]` |
| `bundled` | copy the wheel to `.aig-wheels/`, pin it to the bundled version, add `--find-links .aig-wheels` | copy the tarball to `.aig-wheels/`; `@aig/sdk: file:.aig-wheels/<file>` |
| `monorepo` (development only, the platform repo must be open) | also `pip install -e <repo>/sdk/python` | `@aig/sdk: file:<relative path to repo>/sdk/typescript` |

- Fallbacks:
  - `registry` falls back to `bundled` when the install fails and the VSIX carries artifacts. The retry skips
    creating `.venv`.
  - `monorepo` without the repo falls back to `registry`.
  - `bundled` without artifacts falls back to `registry`.
- Each step runs as a VS Code `ProcessExecution` task (type `aig-setup`, source `aig`) in a dedicated terminal
  panel (reveal always, no focus). Steps run in order and stop at the first non-zero exit. Cancellation terminates
  the task.
- Then run `aig doctor --json`: the venv's `aig` for python; the resolved CLI for node. The environment is
  `.env.example` + `.env` + `process.env`, with a 60 s timeout. Parse `{ok, checks:[{name, ok, code, field, remediation}]}`
  into `OK` / `FAIL` / `SKIP` lines with `fix:` hints in the output channel, and note that key checks fail until
  the placeholders are filled in.

### 11.3 AIG: Update SDK in this project (FR-SDK-2)

- Requires a trusted workspace.
- Folder: the Explorer argument, else the nearest project folder of the active file, else the single workspace
  project folder, else an open dialog.
- Applies the pin rewrite for the effective source, reinstalls (skipping venv creation when `.venv` exists) and
  runs doctor. Reports "SDK updated to `aig-sdk==X` / `@aig/sdk@X`" or the failing exit code.

### 11.4 AIG: Install / Update aig CLI (FR-SDK-3)

- Requires a trusted workspace.
- With `pipx`: `pipx install --force [--pip-args="--index-url U --find-links D"] aig-sdk[evals]==<pin>`.
- Without pipx but with Python: create a venv in `~/.aig/cli`, run `pip install --upgrade aig-sdk[evals]==<pin>`,
  then set `aig.cli.path` (Global) to `~/.aig/cli/bin/aig` (or `Scripts\aig.exe`).
- Without Python: show the guidance with **Open python.org**.
- If the registry install fails and a bundled wheel exists, retry with `--find-links <dist/sdk>`.

---

## 12. Local evals and Floci

### 12.1 AIG: Run Evals (FR-EV-1)

- Entry points: the command, the Explorer and editor-title menus on `aig-eval.yaml`, and two CodeLenses at line 0
  of `aig-eval.yaml`: `$(beaker) Run evals (offline)` and `Run evals (Fiddler)`.
- Requires a trusted workspace ("running evals executes the agent's code").
- Config: the argument (a file, or a folder containing the file), else the active editor, else a workspace search
  (`**/aig-eval.yaml`, excluding `node_modules`, `.venv` and `dist`, up to 50 results) with a QuickPick when there
  are several. None found: suggest `aig eval init`.
- Mode QuickPick: **Offline (local evaluators only)**, or **Online (Fiddler)**.
- CLI resolution (`resolveAigCli`): an absolute `aig.cli.path` if it exists, else `<folder>/.venv/bin/aig` (Windows
  `Scripts\aig.exe|.cmd`), else `PATH`. Not found: show install guidance with **Open Settings**.
- Run `aig eval run --md <tmp>/report.md --out <tmp>/report.json [--offline]` as task type `aig-eval` in the agent
  folder, in a dedicated cleared terminal panel. When `aig.evals.loadDotenv` is on, the environment is the folder's
  `.env` parsed with `load_dotenv` semantics (variables already set win; values are never logged).
- Report: validate `aig-eval-report/v1` and render it in a single scriptless webview `aig.evalReport`
  (`enableScripts: false`, nonce style CSP), styled with the `@aig/ui` CSS. It shows the verdict, meta (generated
  time, commit, SDK versions, exit code), an offline notice, warnings, and per dataset a score table (value,
  baseline, delta, threshold, max regression, status with reason), the baseline source, task failures and the
  **Fiddler experiment** link (http(s) URLs only; all report text HTML-escaped). Then notify
  `AIG evals passed/FAILED for <agent> (<mode>).`
- Fallback when there is no JSON: show the Markdown summary and the exit-code meaning (0 passed; 1 below threshold
  or regressed; 2 could not judge; 127 CLI not found).
- Offline runs are labelled as such and never reach Fiddler or platform-api.

### 12.2 Floci (FR-FL-1)

- **AIG: Start Floci**: requires a trusted workspace. If the endpoint already answers, report it. Otherwise send
  `<command> <startArgs>` to a terminal named `AIG: Floci` (icon `cloud`) and set state to `starting`. Arguments
  are quoted for POSIX shells or PowerShell (`& 'path'` for quoted commands).
- **AIG: Stop Floci**: send the stop arguments, or dispose the terminal when `stopArgs` is empty. Clear the
  environment variables.
- Status bar item `aig.floci` (left, priority 99) opens a menu (Start / Stop / Floci settings). Text:
  `$(cloud) Floci` (running), `$(sync~spin) Floci` (starting), `$(cloud-download) Floci off`, `$(cloud) Floci ?`.
  Hidden when `aig.floci.showStatusBar` is false.
- Probe: any HTTP response within 1.5 s means running. Poll every 2 s while starting (up to a 90 s timeout), every
  10 s while running or while the terminal exists, every 30 s otherwise. Stop polling when the item is hidden,
  Floci is stopped and there is no terminal.
- While running, set `AWS_ENDPOINT_URL`, and `AWS_REGION` / `AWS_DEFAULT_REGION` when not already set, through
  `context.environmentVariableCollection` (`persistent = false`, with a description). It MUST never set AWS
  credentials.
- The endpoint must be an http(s) URL without credentials, query or fragment. The region must match
  `^[a-z]{2}(-[a-z]+)+-\d$`. Floci's CLI is unverified, so everything is configurable.

---

## 13. Claude Code integration

### 13.1 AIG: Configure Claude Code (FR-CC-1)

1. Requires sign-in and live data (demo mode: "needs the live backend. Turn off sample data first").
2. `GET /api/v1/claude-code/settings`. Parse it strictly: `settings.env` MUST be a string map. Optional fields:
   `apiKeyHelper`, `model`, `availableModels[]`, `enforceAvailableModels`, `tier`, `mode`, `config_id`,
   `allowed_models[]`, `managed_only.allowedProviders`, `vscode['claudeCode.environmentVariables'|'claudeCode.disableLoginPrompt']`,
   `warning`, `downgraded {since, reason}`.
3. Modal confirmation "Configure Claude Code to use the AIG gateway (<tier> tier)?". It is a warning when there is
   a warning or a downgrade. Detail lines: tier, allowed models (short names such as `claude-sonnet-4.5`), default
   model, key mode, routing (normal / downgraded since …: reason), the warning, and what will be written.
4. Merge into `~/.claude/settings.json`:
   - refuse invalid JSON or a non-object ("fix it first, it was not changed")
   - back up first to `settings.json.aig-backup-<YYYYMMDDTHHMMSSZ>`, never overwriting an earlier backup (suffix
     `-2`, `-3`, …, using `COPYFILE_EXCL`)
   - `env` = `{...existing.env, ...ours}`; set `apiKeyHelper`, `model`, `availableModels` and
     `enforceAvailableModels` when present; keep every other key
   - **never write `allowedProviders`**, which is managed-only
   - write 2-space JSON with a trailing newline.
5. Set the user (Global) settings `claudeCode.environmentVariables` (merged by name; ours replace same-name
   entries) and `claudeCode.disableLoginPrompt`. If that fails, note that the Claude Code extension may not be
   installed.
6. If session sharing is on, re-sync credentials. If it is off, note "run `aig login`".
7. Check the CLI: is `aig` on PATH, and does `aig claude-code --help` succeed (15 s timeout)? If not, offer
   **Install/Update aig CLI**.
8. Final message: "Claude Code configured for the <tier> tier (<models>)", the backup path or "Created …", notes,
   and the managed-only note. Actions: **Install/Update aig CLI** (when needed) and **Open settings.json**. Log
   names only, never values.

### 13.2 AIG: Claude Code status (FR-CC-2)

Calls `GET /api/v1/claude-code/settings` and `GET /api/v1/claude-code/status`. The status endpoint is admin only:
403 or 503 means "not available" and is not an error.

Output channel lines:

- for every user: tier, allowed models, default model, key mode (and config id), routing, warning
- for admins: gateway enabled at the base URL, soft threshold %, check interval, and per tier the mode, pin,
  since, key mode, config, models, reason, budget state and checks (`<period> <metric>: used / limit (pct%) status`),
  note and error.

Then a summary notification with **Configure Claude Code**.

Error mapping:

- `claude_code_not_configured`: "Claude Code is not set up on the <env> backend yet…"
- 401: "Your AIG session has expired… Sign in again", with **Sign In**
- anything else: `describeBackendError`.

### 13.3 Session sharing with the `aig` CLI (FR-CC-3)

- File `~/.aig/credentials`, a spec shared with the Python CLI and the Eclipse plugin:
  `{"platform_url", "token", "env", "user", "written_at"}` in that key order, 2-space JSON plus a newline,
  `written_at` as ISO-8601 UTC to the second.
- Directory `~/.aig` mode 0700. The file is written to a 0600 temp file (`flag: 'wx'`) in the same directory,
  renamed atomically, and chmod 0600 again.
- Written on sign-in (any method except demo). Rewritten when the token, user, env or backend changes: on state
  changes and on a silent token check every **5 minutes** (the timer is `unref`'d). The write is skipped when
  nothing changed.
- Deleted on a signed-in → signed-out transition seen by this window, and when `aig.claudeCode.shareSession` is
  turned off.
- Operations are serialized and never throw into sign-in. Failures are logged with the `[claude-code]` prefix. The
  token is never logged.
- The user email comes from the session, then devUser, then the local session, then the Microsoft account label.

---

## 14. Temporary demo-data mode (FR-DEMO-1)

- `aig.demoData` (default **false**) swaps the backend for the in-memory emulation from `@aig/demo-data`
  (`createDemoBackend({env})`, which supplies `fetch` and `createSocket`).
- The config resolves to `{backendUrl: DEMO_BASE_URL, configured: true, auth: {kind:'demo'}}`. Status reports
  connected. Sign In starts a demo session immediately; only a boolean `aig.demoSignedIn` is stored in
  `globalState`.
- Every webview shows the **Sample data** badge. Test routing returns a sample result. New Agent never writes the
  demo URL. Session sharing and Claude Code are disabled.
- `@aig/demo-data` MUST be imported only by `src/demo.ts` (guard test). Removing the feature means deleting
  `src/demo.ts`, its call sites and the guard.

---

## 15. Non-functional requirements

### 15.1 Security (NFR-SEC)

| Id | Requirement |
|---|---|
| NFR-SEC-1 | No gateway keys. `src/`, `web/packages/ui/src`, `sdk/typescript/src/platform` and `sdk/typescript/src/core` MUST NOT contain: the `x-portkey-api-key` header, any `x-portkey-` header, the `PORTKEY_API_KEY` or `PORTKEY_ADMIN_API_KEY` names, `SecretStorage`, or `.secrets.store/get/delete`. Enforced by `test/no-secrets.guard.test.ts`, whose patterns are assembled from fragments |
| NFR-SEC-2 | The bearer token goes only to the configured backend: in the HTTP `Authorization` header and on the WebSocket upgrade, never in a URL, a log or a webview |
| NFR-SEC-3 | Security-sensitive settings come from user, machine or policy scope only (section 4.2) |
| NFR-SEC-4 | Running code (evals, environment setup, CLI install, SDK update, Floci) requires `workspace.isTrusted` |
| NFR-SEC-5 | Every webview has a CSP with `default-src 'none'`, nonce scripts and styles, and `localResourceRoots` limited to `media/` and `dist/webview/`. All inbound messages are validated |
| NFR-SEC-6 | Rendered untrusted data (eval reports, backend strings) is HTML-escaped. Only http(s) links are rendered |
| NFR-SEC-7 | Generated `.env` files never contain secret-looking variables. Agent credentials are referenced (an ARN or `local:NAME`), never entered |
| NFR-SEC-8 | URL settings with credentials or `__` placeholders are ignored. Plain http only for loopback in `local` |
| NFR-SEC-9 | Local browser sign-in uses a one-time, expiring state nonce |
| NFR-SEC-10 | The `AIG` output channel logs error codes, ids and names only, never prompts, outputs, `.env` values or tokens |
| NFR-SEC-11 | `~/.aig/credentials` is 0600 in a 0700 directory, written atomically and deleted on sign-out. `~/.claude/settings.json` is backed up before every change |

### 15.2 Performance and resource use (NFR-PERF)

- NFR-PERF-1: No background polling of usage or limits. Polling exists only for background runs (with backoff,
  capped at 2 h), Floci (10–30 s, only while visible or running) and the 5-minute silent token check.
- NFR-PERF-2: One WebSocket per window and session, shared by all views.
- NFR-PERF-3: Activation (`onStartupFinished`) MUST NOT block. Network work is async and fire-and-forget.
- NFR-PERF-4: VSIX size: SDK artifacts ≤ 2 MiB each and ≤ 4 MiB total (enforced at build). About 1.2 MB for the
  whole VSIX at 0.16.0.

### 15.3 Reliability (NFR-REL)

- Stale async results (state refresh, catalog, runs, limits) are dropped with sequence numbers.
- Reconnect uses backoff. Chats and foreground runs are cancelled when their view is disposed.
- Sign-in never fails because of session sharing, `.env` or doctor errors.

### 15.4 UX and accessibility (NFR-UX)

- AIG branding from `@aig/design-tokens`: light, dark and high-contrast themes. High contrast uses `--vscode-*`
  variables. Square corners. Fonts Inter and JetBrains Mono (bundled woff2), falling back to Futura PT / Century
  Gothic and Source Sans.
- Brand assets are copied from `web/packages/brand-assets` into `media/` before every build, typecheck and test.
  Do not edit `media/` directly; it is gitignored.
- Every long operation shows notification progress, cancellable where it can be cancelled. Every failure gives an
  actionable message.

---

## 16. Backend contract consumed

All calls go through `@aig/sdk/platform` with the signed-in user's token. Headers: `Authorization: Bearer <token>`,
`x-aig-job-profile`, `x-aig-trace-id`, and `x-aig-agent-id` where applicable (see `backend/contracts/headers.md`).

| Method and path | Used by |
|---|---|
| `GET /healthz` | state refresh (`status`, `env`, `secrets{name: configured\|placeholder\|missing}`) |
| `GET /api/v1/session` | state refresh, InitInfo |
| `GET /api/v1/ws` (WebSocket) | live service |
| `GET /api/v1/usage/dashboard?days=` | HTTP usage fallback |
| `GET /api/v1/usage/limits[?refresh=true]` | usage limits card |
| `POST /api/v1/llm/chat/completions` (SSE) | Ask, HTTP chat fallback |
| `POST /api/v1/routing/test` | Test model routing |
| `GET /api/v1/catalog` | Agents tab, Run Agent |
| `GET /api/v1/invocations?mine=true&limit=20` | recent runs |
| `GET /api/v1/invocations/{id}`, `POST …/{id}/cancel` | background runs, run panel |
| `POST /api/v1/agents/{id}/invoke` (stream / background) | run panel |
| `POST /api/v1/agents` | New Agent, Register Existing Agent (`409 agent_exists` handled) |
| `POST /api/v1/agents/{id}/versions` | Register Existing Agent |
| `POST /api/v1/agents/{id}/versions/{v}/verify` | Verify now |
| `GET /api/v1/claude-code/settings`, `GET /api/v1/claude-code/status` | Claude Code commands |
| `GET <backend>/auth/local/signin` (browser) | local sign-in |

WebSocket frames:

- Client: `ping`, `pong`, `chat {id, messages, job_profile, agent_id?, model?, temperature?, max_tokens?}`,
  `cancel {id}`, `usage.subscribe {days}`, `usage.unsubscribe`, and the agent frames `agent.invoke` and
  `agent.cancel`.
- Server: `ready {user, team, env, user_tier, cost_mode, allowed_job_profiles}`, `ping`, `pong`,
  `chat.delta {id, text}`, `chat.done {id, traceId, usage, model, route}`,
  `chat.error {id, code, message, traceId, status}`, `usage {days, data}`, `usage.error`, `error`, and the agent
  frames `agent.delta`, `agent.output`, `agent.error`, `agent.done` and `agent.invocation.status`.

Chat and cancel ids match `^[A-Za-z0-9_-]{1,64}$`. Frames are JSON text and stay under the backend's 64 KiB frame
limit.

Error codes the UI handles specially: `portkey_key_not_configured` (503), `usage_not_configured`,
`agent_invocation_disabled` (503), `agent_exists` (409), `invocation_not_found`, `claude_code_not_configured`
(503), `invalid_session`, `not_connected`, `cancelled`, `network_error`, `timeout`.

---

## 17. Build, packaging and CI

### 17.1 Scripts (`vscode-extension/package.json`)

| Script | Does |
|---|---|
| `prepare:assets` | `node scripts/prepare.mjs` |
| `build` | `prepare.mjs --sdk-artifacts && esbuild.mjs --production` |
| `watch` | prepare + esbuild watch |
| `typecheck` | prepare + `tsc --noEmit -p .` |
| `test` | prepare + `vitest run` |
| `package` | `npx @vscode/vsce package --no-dependencies --skip-license` |
| `vscode:prepublish` | `npm run build` |

### 17.2 `scripts/prepare.mjs` (FR-BUILD-1)

Runs before build, typecheck and test:

1. Copy the brand assets from `web/packages/brand-assets` into `media/`: `svg/aig-logo.svg`, `aig-logo-white.svg`,
   `aig-activitybar.svg`, `aig-icon.svg`, `png/aig-icon-128.png` → `aig-icon.png`, `fonts/inter-var.woff2`,
   `fonts/jetbrains-mono-var.woff2`. Skip an asset when a packaged copy already exists and the monorepo is absent.
2. Bundle `sdk/templates/*` (each template has an `aig-template.json`) into `dist/templates.json`:
   `{schema: "aig-templates/v1", templates: [{name, description, language, framework, placeholders, sdk_paths, exclude, files: [{path, text|base64, executable}]}], sdk: {python, typescript}}`.
   Exclude `.venv`, `node_modules`, `__pycache__`, `.aig-eval-report*`, caches, `.env` and lock files. Fail if
   there are no templates.
3. With `--sdk-artifacts`: the repo's `scripts/sdk-artifacts.mjs` builds the aig-sdk wheel
   (`pip wheel --no-deps sdk/python`) and the `@aig/sdk` tarball (`npm pack sdk/typescript`) into `dist/sdk/` with
   `manifest.json` `{python: {version, file}, typescript: {version, file}}`, and fails over the size budget.
   `AIG_SKIP_SDK_ARTIFACTS=1` skips this (registry source only).

### 17.3 VSIX content

`.vscodeignore` excludes `src/`, `test/`, `node_modules/`, maps, `*.ts`, config files, `scripts/`, `aliases.*`,
`**/.env*` and `*.vsix`.

The VSIX ships:

- `dist/extension.js`
- `dist/webview/{dashboard,sidebar,signin,agentrun}.js`
- `dist/templates.json`
- `dist/sdk/*`
- `media/*`
- `package.json`, `README.md`, `CHANGELOG.md`

### 17.4 Repo integration

- `make vsix-package` builds and packages `vscode-extension/aig-ai-ecosystem-<version>.vsix`. `make vsix-test` runs
  the suite.
- Install with `code --install-extension vscode-extension/aig-ai-ecosystem-<version>.vsix`.
- Installs inside the project use `npm ci --workspaces=false`, because the root declares npm workspaces.
- CI (`.github/workflows/ci.yml`, extension job) runs typecheck, tests and packaging, and uploads the VSIX as the
  artifact `aig-vsix`. `*.vsix` files are gitignored.
- Versioning: bump `package.json` and `package-lock.json` together (a test checks the version), and add a
  `CHANGELOG.md` entry.

---

## 18. Verification and acceptance

### 18.1 Automated tests (MUST pass; about 304 tests at 0.16.0)

| Area | Test file(s) |
|---|---|
| Config, placeholders, URL rules | `config.test.ts` |
| Machine scope and untrusted-workspace list | `settings-scope.test.ts` |
| Manifest: every command registered, menus valid, engines matches `@types/vscode`, task types, palette `when` clauses, version, demo off by default | `manifest.test.ts` |
| No gateway keys | `no-secrets.guard.test.ts` |
| Demo data only via `src/demo.ts` | `demo-data.guard.test.ts`, `demo.test.ts` |
| Status mapping and messages | `status.test.ts` |
| Local sign-in, Sign in as… | `localSignIn.test.ts`, `signInAs.test.ts` |
| Platform client as configured, live mapping | `platformClient.test.ts`, `live.test.ts`, `liveService.test.ts` (`vscode` and `ws` mocked, end to end) |
| Chat prompt building | `chatPrompt.test.ts` |
| Routing test formatting | `routing.test.ts` |
| Agents mapping, wizard, bridge and background tracking | `agentsMapping.test.ts`, `agentsHost.test.ts` |
| Scaffold parity with `aig init` (byte for byte when `sdk/python/.venv` exists) | `scaffold.test.ts` |
| SDK setup plans | `sdkSetup.test.ts` |
| Eval report parse and render (matches the CLI renderer when available) | `evalReport.test.ts` |
| Floci helpers | `floci.test.ts` |
| Claude Code settings merge, credentials, session sync | `claudeCode.test.ts`, `claudeCodeFiles.test.ts` |
| Status panel HTML | `panel.test.ts` |

`npm run typecheck` MUST be clean.

### 18.2 Acceptance scenarios

| # | Scenario | Expected |
|---|---|---|
| A1 | Fresh install with default settings (`dev`, placeholder URL) | Status bar `$(warning) AIG: dev · not configured`; Sign In shows "AIG backend not configured for dev: …"; no network calls |
| A2 | Workspace `.vscode/settings.json` sets `aig.backendUrls.dev` to another host | Ignored; the user-scope value is used |
| A3 | `local` env, backend `AIG_ENV=local AIG_AUTH_MODE=dev`, Sign In | Browser opens `/auth/local/signin` with state; after submit, VS Code shows "signed in as …", the sidebar shows the tabs, usage loads once |
| A4 | Callback with an unknown or expired state | "AIG sign-in failed: sign-in link expired or was not started from this VS Code window" |
| A5 | Switch user to `usage.limit@aig.example` | Socket reconnects; usage, limits and recent runs show only that user's data |
| A6 | Leave the sidebar open for 10 minutes | No usage or limits requests after the first load (checked in the backend log) |
| A7 | Chat with the socket down | Answer streams over HTTP SSE; route chip shows the model |
| A8 | `@aig /explain` with a selection | Reference to the selection shown; streamed explanation; follow-up "Write tests for it" |
| A9 | Backend gateway key is a placeholder | Status `degraded`; Ask shows the "model-gateway key has not been configured" message |
| A10 | Register Existing Agent with an `http://` endpoint in dev | Step 6 rejects it; with a secret value instead of an ARN, step 9 rejects it |
| A11 | Background run, then reload the window | Polling resumes; notification "<agent> finished: succeeded" with Open result |
| A12 | New Agent `langgraph-py`, signed in, trusted workspace | Folder created, files identical to `aig init`, draft registered, `.env` 0600 with no secrets, `.venv` created, doctor summary logged |
| A13 | New Agent in an untrusted workspace | Scaffold and registration done; environment not created, with the trust message |
| A14 | Run Evals offline on a starter agent | Task runs `aig eval run … --offline`; report webview shows the verdict and the offline notice |
| A15 | Start Floci with the endpoint up | Status bar `$(cloud) Floci`; new terminals have `AWS_ENDPOINT_URL`; no AWS credentials set |
| A16 | Configure Claude Code with an existing `~/.claude/settings.json` | Backup created; `env` merged; other keys kept; no `allowedProviders`; VS Code `claudeCode.*` set |
| A17 | Sign out (local) with session sharing on | `~/.aig/credentials` deleted |
| A18 | `grep` the built `dist/` and `src/` for gateway-key names | No matches (guard test) |
| A19 | Package | `aig-ai-ecosystem-<version>.vsix` is produced and installs in VS Code 1.90+ |

### 18.3 Definition of done for a change

1. Requirements in this spec are met, or the spec is updated in the same change.
2. Typecheck clean; all tests pass; new logic sits in a module with no `vscode` import, with unit tests.
3. No-secrets and manifest guards pass.
4. `package.json`, `package-lock.json` and `CHANGELOG.md` are updated, and the README is updated for any
   user-visible change.
5. The VSIX builds with `make vsix-package` and installs.

---

## 19. Suggested units of work (for AI-DLC construction)

The units are ordered by dependency. Each can be built and tested on its own once its dependencies exist.

| Unit | Scope | Depends on | Requirements |
|---|---|---|---|
| U1 Foundation | manifest, settings, trusted settings, config resolver, auth (Microsoft, local browser, dev user, Sign in as), state refresh, status bar, status panel, Select Environment, Show Status, output channel, build scripts, guards | `@aig/sdk/platform`, `@aig/design-tokens` | FR-MAN, FR-CFG, FR-AUTH, FR-STATE, FR-BUILD, NFR-SEC-1..3, 8, 9 |
| U2 Live and webviews | LiveService, webview shell and bridge, signed-out view, sidebar (usage and chat tabs), dashboard, usage limits, Refresh, Open Chat / Token Usage | U1, `@aig/ui` | FR-LIVE, FR-UI, NFR-PERF-1..2, NFR-SEC-5 |
| U3 Coding assistant | `@aig` participant, Explain/Fix Selection, Ask, Test model routing | U2 | FR-CHAT |
| U4 Agents | catalog tab, Run Agent, run panel, background runs, Register Existing Agent, verify | U2 | FR-AG |
| U5 New Agent and SDK | templates bundle, scaffold, `.env`, registration, environment setup, doctor, Update SDK, Install CLI | U1 (U2 for team and tier) | FR-NA, FR-SDK, NFR-SEC-4, 7 |
| U6 Evals | Run Evals, CodeLens, report webview | U5 (CLI resolution) | FR-EV, NFR-SEC-6 |
| U7 Floci | service, status bar, terminal environment variables | U1 | FR-FL |
| U8 Claude Code | Configure, status, credentials file, session sync | U1, U5 (Install CLI) | FR-CC, NFR-SEC-11 |
| U9 Demo mode (optional, temporary) | `@aig/demo-data` switch | U2 | FR-DEMO |
| U10 Packaging and release | SDK artifacts, VSIX, CI artifact, changelog | all | section 17 |

---

## 20. Open items and known limits

- **Floci's CLI is not verified.** The defaults assume `floci start` / `floci stop` on port 4566, and everything is
  configurable.
- **Placeholders.** Backend URLs, Entra scopes and the repository URL ship as `__…__` tokens. Real values come from
  user settings, VS Code policy or a settings profile.
- **Brand.** The SVGs and the dark palette await brand sign-off. The licensed AIG Futura webfont is not available
  yet.
- **Demo mode is temporary.** See `docs/demo-data.md` and remove it when it is no longer needed.
- **`allowedProviders: ["customEndpoint"]`** for Claude Code must be set by an admin in managed settings. The
  extension never writes it.
- **Eclipse parity.** The Eclipse plugin (planned) shares the credentials file spec, the Claude settings merge
  spec, the SDK install plan and the `@aig/ui` widgets. Keep those specs in sync.
