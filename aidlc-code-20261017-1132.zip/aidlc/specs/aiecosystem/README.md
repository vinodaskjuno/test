# AIG AI Ecosystem specs

Four specs written from the AIDLC spec templates (`aidlc-spec/1`). Each passes `aidlc spec check` with no errors,
warnings or open gaps.

| # | Spec | Template | Project | Kind |
|---|---|---|---|---|
| 1 | [01-vscode-extension-dashboard-chat.md](01-vscode-extension-dashboard-chat.md) | vsix (surfaces vsix, ui) | `aig-ecosystem-vscode` (new) | VS Code extension: Activity Bar dashboard and `@aig` chat |
| 2 | [02-portal-dashboard-ui-backend.md](02-portal-dashboard-ui-backend.md) | ui-backend (ui, backend, data) | `aig-ecosystem-portal` (new) | Portal API and dashboard screen |
| 3 | [03-portal-agent-registry-enhancement.md](03-portal-agent-registry-enhancement.md) | ui-backend (ui, backend, data) | `aig-ecosystem-portal` (existing) | Agent registry added to the portal from spec 2 |
| 4 | [04-model-catalogue-ui.md](04-model-catalogue-ui.md) | ui-only (ui) | `aig-model-catalogue` (new) | Model catalogue page |

Specs 1, 2 and 3 share one API contract and one set of seed data, so the numbers they show agree (8 agents,
4 MCP servers, 4 approved models, $887.50 spend this month).

## Run order

Run one at a time: every run draws on the same Bedrock token quota.

1. **Spec 4** first: the smallest, and the quickest end-to-end check.
2. **Spec 2**, then merge its pull request into `main`.
3. **Spec 1** (its dashboard reads the portal API from spec 2).
4. **Spec 3** after spec 2 has merged: it enhances that code.

## Commands

```bash
specs/aiecosystem/create-projects.sh        # once, with the platform running

A=.venv/bin/aidlc
$A spec check specs/aiecosystem/04-model-catalogue-ui.md
$A run specs/aiecosystem/04-model-catalogue-ui.md --project aig-model-catalogue --economy --watch
$A run specs/aiecosystem/02-portal-dashboard-ui-backend.md --project aig-ecosystem-portal --economy --watch
$A run specs/aiecosystem/01-vscode-extension-dashboard-chat.md --project aig-ecosystem-vscode --economy --watch
$A run specs/aiecosystem/03-portal-agent-registry-enhancement.md --project aig-ecosystem-portal --economy --watch
```

The title comes from each spec's Title row; the run budget, risk tier and surfaces come from its Spec details.
