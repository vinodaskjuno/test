# AI Ecosystem Portal: agent registry

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · ui-backend |
| Title | Agent registry for the AI Ecosystem Portal: register agents, list, search, filter and pause them |
| Project | existing |
| Project id | aig-ecosystem-portal |
| Repositories | app |
| Surfaces | ui, backend, data |
| Stack preset | nextjs-fastapi |
| Stack exceptions | SQLite instead of the preset's Postgres — single-node pilot with no database server, and SQLAlchemy keeps a later move to Postgres a configuration change — Vinod Kumar |
| Jira | AIGAE-103 |
| Priority | P2 |
| Target release | 2026.12 |
| Business sponsor | Sarah Mitchell |
| Product owner | Raj Patel |
| Tech lead | Vinod Kumar |
| Architecture | Vinod Kumar | 17 Oct 2026 |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | NAIC AI bulletin |
| Risk tier | medium |
| Run budget (USD) | 40 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

The portal dashboard counts agents, but teams cannot add their agents to the inventory themselves: platform engineers
insert rows by hand from e-mail requests, which takes days and leaves the AI inventory incomplete. With a self-service
registry, an agent owner registers an agent with its owner team, approved model and HTTPS endpoint in a minute, and
anyone can find an agent, see who owns it and pause it, so the AI inventory stays complete and current.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Agent owner | AIG engineer whose team builds or runs an agent | Register an agent; pause or activate it |
| Platform viewer | Any AIG staff member on the AIG network | Browse, search, filter, sort and open agents |
| API client | The portal web app and the VS Code extension (AIGAE-101) | Call the endpoints in B1 |

### 3. Scope

**In scope**

- POST /api/agents and PATCH /api/agents/{id}/status, three new agent columns and their migration.
- A "Register agent" form, a "Registered agents" page with search, filters and sorting, and an agent detail drawer.

**Out of scope**

- No sign-in in this release: anyone on the AIG network may register, pause or activate agents.
- Editing or deleting agents, owner names or e-mail addresses (owners are teams), endpoint health checks, exports.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | POST /api/agents stores a valid agent with the trimmed name and returns 201 with the agent item, requests_7d 0 and cost_7d_usd 0.0 | Must |
| FR-2 | POST /api/agents returns 409 with `An agent named "<name>" already exists.`, <name> being the submitted trimmed name, when it matches an existing name ignoring case | Must |
| FR-3 | POST /api/agents returns 422 with the field messages of section 6 for any field that breaks a section 6 rule | Must |
| FR-4 | PATCH /api/agents/{id}/status with `{"status": "active"}` or `{"status": "paused"}` sets the status, refreshes updated_at and returns 200 with the agent item | Must |
| FR-5 | The Register agent form at /agents/new checks every field against the section 6 rules on submit, shows each message under its field, moves focus to the first invalid field and sends nothing while a field is invalid | Must |
| FR-6 | After a 201 the form opens /agents and shows the toast `Agent "<name>" registered.` for 5 seconds | Must |
| FR-7 | When the API rejects a submission the form keeps every value and shows the 409 message under Name, each 422 message under its field, or the U3 error text above the form for any other failure | Must |
| FR-8 | The Registered agents page at /agents, linked from the sidebar under Dashboard, lists every agent in a table sorted by name A–Z ignoring case | Must |
| FR-9 | A name search (contains, ignoring case), a Status filter and a Model filter narrow the table together, as each value changes | Must |
| FR-10 | Pressing the Name, Requests (7 days) or Created column header sorts by it (Name A–Z first, the other two highest or newest first) and pressing it again reverses the order | Should |
| FR-11 | Clicking a row, or pressing Enter on a focused row, opens a detail drawer with every field of the agent and adds ?agent=<id> to the URL | Must |
| FR-12 | The drawer's "Pause agent" button (for an active agent) or "Activate agent" button (for a paused one) calls the PATCH endpoint and on 200 updates the drawer and the table row | Must |

### 5. Acceptance scenarios

All scenarios start from spec AIGAE-102's seed data (end date 2026-10-17); "Claims Letter Drafter" is the new agent of section 6.

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the seed data | a client posts Claims Letter Drafter | 201 with id 9, status active, requests_7d 0 and endpoint_url `https://claims-letter-drafter.example.com/invoke`; GET /api/agents returns total 9 |
| AS-2 | FR-1 | Claims Letter Drafter is registered | a viewer opens / | the Registered agents card reads 9 and the other cards are unchanged (4, 4, 10,450, $887.50) |
| AS-3 | FR-2 | the seed data | a client posts the name "  policy q&a ASSISTANT " | 409 `{"detail": "An agent named \"policy q&a ASSISTANT\" already exists."}` and the total stays 8 |
| AS-4 | FR-3 | the seed data | a client posts the new agent with name "AB", model_id "llama-3-3-70b" and endpoint_url `http://claims.example.com` | 422 with "Name must be 3–60 characters.", "Choose an approved model." and "Endpoint URL must start with https://." |
| AS-5 | FR-4 | agent 1 is active | a client patches /api/agents/1/status with paused | 200 with status paused; GET /api/agents shows Claims Intake Assistant as paused |
| AS-6 | FR-4 | the seed data | a client patches /api/agents/999/status | 404 `{"detail": "Agent 999 not found."}` |
| AS-7 | FR-4 | the seed data | a client patches /api/agents/1/status with `{"status": "retired"}` | 422 with "Status must be active or paused." |
| AS-8 | FR-5 | the empty form | the user presses Register agent | Name, Owner team, Model and Endpoint URL show their required messages, focus is on Name and no request is sent |
| AS-9 | FR-6 | the form holds Claims Letter Drafter | the user presses Register agent | /agents opens, the toast `Agent "Claims Letter Drafter" registered.` is announced and the row shows between Claims Intake Assistant and Code Review Helper |
| AS-10 | FR-7 | the form holds the name "Code Review Helper" | the user presses Register agent | the API returns 409, `An agent named "Code Review Helper" already exists.` shows under Name and every value stays |
| AS-11 | FR-7 | the API is stopped | the user submits a valid form | "Couldn't reach the AI Ecosystem Portal API." shows above the form and every value stays |
| AS-12 | FR-8 | the seed data | a viewer opens /agents | 8 rows from Broker Email Triage to Underwriting Risk Summariser and the subtitle "8 agents" |
| AS-13 | FR-8 | an empty database | a viewer opens /agents | "No agents registered yet." with a Register agent button |
| AS-14 | FR-9 | the seed data | the viewer types "summ" and chooses Status Active | only Underwriting Risk Summariser remains and the URL reads /agents?q=summ&status=active |
| AS-15 | FR-9 | the seed data | the viewer chooses Model Claude Sonnet 4.5 | Claims Intake Assistant, Reinsurance Treaty Summariser and Underwriting Risk Summariser remain |
| AS-16 | FR-9 | the seed data | the viewer types "zzz" | `No agents match these filters.` with a Clear filters button that restores all 8 rows and a bare /agents URL |
| AS-17 | FR-10 | the seed data | the viewer presses Requests (7 days) | Policy Q&A Assistant (37,500) is first, the header has aria-sort="descending" and the URL has sort=-requests |
| AS-18 | FR-11 | the seed data | the viewer presses Enter on Broker Email Triage | the drawer shows Distribution Operations, GPT-4o, Active, "No description", "Not recorded", 12,500, $125.00 and the URL has ?agent=4 |
| AS-19 | FR-11 | the seed data | a viewer opens /agents?agent=999 | no drawer opens and the status text "Agent 999 was not found." is announced |
| AS-20 | FR-12 | the drawer of Fraud Signal Reviewer is open | the viewer presses Pause agent | the badge reads Paused in the drawer and the row, the button reads Activate agent and the toast `Agent "Fraud Signal Reviewer" paused.` shows |
| AS-21 | FR-12 | the PATCH call returns HTTP 500 | the viewer presses Pause agent | the toast "Couldn't update the agent's status. Try again." shows and the status stays Active |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| name | required; trimmed; 3–60 characters; unique ignoring case. Messages: "Enter a name." / "Name must be 3–60 characters." |
| owner_team | required; trimmed; 2–60 characters; a team name, never a person. Messages: "Enter the owner team." / "Owner team must be 2–60 characters." |
| model_id | required; the id of a model whose status is approved (4 in the seed). Messages: "Choose a model." / "Choose an approved model." |
| description | optional; trimmed; at most 280 characters; the form shows a "<n>/280" counter. Message: "Description must be at most 280 characters." |
| endpoint_url | required; an absolute URL with the https scheme and a host, at most 2,048 characters. Messages: "Enter the endpoint URL." / "Endpoint URL must start with https://." |
| status | active or paused; the form defaults to Active. Message: "Status must be active or paused." |
| 422 body | FastAPI's list `{"detail": [{"loc": ["body", "<field>"], "msg": "<message>", "type": "value_error"}]}` with the messages above |
| Agent item | spec AIGAE-102's item plus description (string, "" when none), endpoint_url (string or null) and updated_at (ISO 8601 UTC) |
| Table | columns Name, Owner team, Model (name), Status (badge), Requests (7 days), Created; the subtitle reads "<n> agents" ("1 agent" for one) for the rows shown |
| Filters | search box labelled "Search by name"; Status: All statuses, Active, Paused; Model: All models plus every model from GET /api/models by name; Clear filters empties all three |
| URL state | ?q= (search text), ?status=active or paused, ?model=<model id>, ?sort=name, -name, -requests, requests, -created or created, ?agent=<id>; defaults are left out; unknown values are ignored; changes replace the history entry |
| Drawer fields | Owner team, Model (name), Status, Description ("No description" when empty), Endpoint URL ("Not recorded" when null), Requests (7 days), Cost (7 days), Created and Last updated as 17 Oct 2026, 09:42 |
| Toasts | `Agent "<name>" registered.`, `Agent "<name>" paused.`, `Agent "<name>" activated.`, "Couldn't update the agent's status. Try again."; each 5 seconds in a `role="status"` region |

| New agent used in the scenarios | Value |
|---|---|
| name, owner_team | Claims Letter Drafter, Claims Operations |
| model_id, status | claude-sonnet-4-5, active |
| description | Drafts claim acknowledgement letters for adjuster review. |
| endpoint_url | https://claims-letter-drafter.example.com/invoke |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Time from request to agent in the inventory | 3 working days | under 5 minutes | created_at against the request date in the registration log |
| Agents registered by their own teams | 0 | 25 in the first quarter | count of agents created through POST /api/agents |

## Part B — Technical (owner: Tech lead)

### 8. Current system

The portal built by AIGAE-102 (nextjs-fastapi preset). API in `api/`: `app/main.py` (create_app, CORS from
`APP_CORS_ORIGINS`, GET only today), `app/routes/dashboard.py` (GET /api/dashboard/summary), `app/routes/usage.py`
(GET /api/usage?days=), `app/routes/agents.py` (GET /api/agents, items with requests_7d and cost_7d_usd),
`app/routes/models.py` (GET /api/models), GET /health, `app/models.py` (tables agents, models, mcp_servers,
usage_daily), `app/schemas.py`, `app/clock.py`, `app/seed.py` (8 agents, 5 models, 4 MCP servers, 42 usage rows) and
Alembic revision `0001_initial`. Web in `web/`: `app/layout.tsx` (navy header, sidebar with Dashboard),
`app/page.tsx` (Dashboard: KPI cards, 7-day chart, top agents), `components/{Header,Sidebar,KpiCard,UsageChart,
TopAgentsTable,StateMessage}.tsx`, `lib/api.ts` (every fetch, `cache: "no-store"`) and `lib/format.ts`. Must not
change: every existing endpoint's fields and values, the seed data and its numbers, the dashboard fetching the summary
on every load (so a registration shows at once), and the extension of AIGAE-101 reading GET /api/agents.

### 9. New project setup

N/A — existing project.

## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

| Item | Value |
|---|---|
| Design system | the portal's AIG tokens from AIGAE-102 (header #001871, primary #1352de, danger #c8352b on #fdecea, active badge #0a7458 on #e3f5ef, paused badge #b26b00 on #fff3dc) |
| Figma | none: the layout is specified in U2 to U4 |
| Screenshots | none |
| New tokens or components | AgentForm, AgentsTable, AgentDrawer, StatusBadge, Toast |

### U2. Screens

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| Registered agents | /agents | Find agents | search, filter, sort, open, Register agent |
| Register agent | /agents/new | Add an agent | fill in, Register agent, Cancel (back to /agents) |
| Agent drawer | /agents?agent=<id>, 480 px panel on the right | See one agent | Pause agent or Activate agent, Close |
| Sidebar | every route | Dashboard and Registered agents links | navigate |

### U3. States

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| Registered agents | five skeleton rows | "No agents registered yet." with Register agent; `No agents match these filters.` with Clear filters | "Couldn't reach the AI Ecosystem Portal API." or "The AI Ecosystem Portal API returned HTTP <status>." with Retry | not applicable: no sign-in in this release |
| Register agent | Model select shows "Loading models…"; the submit button reads "Registering…" and is disabled while sending | not applicable | the same two texts above the form; the form keeps its values | not applicable: no sign-in in this release |
| Agent drawer | the action button reads "Saving…" and is disabled | not applicable | "Couldn't update the agent's status. Try again." toast | not applicable: no sign-in in this release |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | 1280 px and up: full table; 768–1279 px: the Created column is hidden; below 768 px: rows become stacked cards, filters stack and the drawer fills the screen |
| Accessibility level | WCAG 2.2 AA |
| Keyboard and screen reader | every field has a visible label and its message linked by aria-describedby with aria-invalid; sort headers are buttons with aria-sort; rows are focusable and open with Enter; the drawer is role="dialog" with aria-modal, traps focus, closes with Escape and returns focus to its row; toasts and "<n> agents" counts use role="status" |
| Browsers | latest Chrome, Edge, Safari and Firefox |

### U5. Content and localisation

| Item | Value |
|---|---|
| Languages | English (US) |
| Formats | 12,500; $125.00 (rounded half up); Created as 4 Sep 2026; Last updated as 17 Oct 2026, 09:42 in local time |

### U6. Analytics

N/A — no analytics in this release.

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| POST | /api/agents | anyone on the network | name, owner_team, model_id, description, endpoint_url, status (section 6 rules) | 201 the agent item with a Location header /api/agents/<id> |
| PATCH | /api/agents/{id}/status | anyone on the network | status: active or paused | 200 the agent item |
| GET | /api/agents | anyone on the network | none (changed: items gain description, endpoint_url and updated_at) | 200 `{items, total}` |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| a field breaks a section 6 rule | 422 | FastAPI list with the section 6 message for each field |
| duplicate name, ignoring case and outer spaces | 409 | An agent named "<name>" already exists. |
| unknown agent id in PATCH | 404 | Agent <id> not found. |
| non-integer id in PATCH | 422 | FastAPI validation error list for `id` |
| body larger than 16 KB | 413 | Request body too large. |

### B3. Authorisation

None in this release: the API is reachable only on the AIG network. CORS keeps `APP_CORS_ORIGINS` and now allows
GET, POST and PATCH with the Content-Type header.

### B4. Compatibility and versioning

Additive only: GET /api/agents gains three fields and keeps every existing field, value and order, so the VS Code
extension (AIGAE-101) and the dashboard keep working unchanged. No version change.

### B5. Limits and performance

| Item | Value |
|---|---|
| Rate limit | none in this release: internal network, under 50 registrations a day expected |
| Pagination | none: the page filters and sorts the full list client-side (under 500 agents expected) |
| Payload size | 16 KB per request |

### B6. Events and messages

N/A — no events or queues.

## Data add-on (owner: Tech lead with the data owner)

### D1. Entities and schema changes

| Table or entity | Change | Columns (type, null, default) | Indexes and constraints |
|---|---|---|---|
| agents | add columns | description TEXT not null default ''; endpoint_url TEXT null; updated_at TIMESTAMP not null | new unique index ux_agents_name_nocase on name COLLATE NOCASE; existing constraints kept |

### D2. Migration and backfill

Alembic revision `0002_agent_registry` (down revision `0001_initial`) uses batch mode for SQLite: it adds the three
columns, backfills updated_at = created_at for existing rows, then creates the index. It runs before the new API
starts and takes under 1 second for 500 rows. The 8 seed agents keep their ids, names and values; `app/seed.py`
writes description '' and endpoint_url null for them, so AIGAE-102's seed numbers and tests are unchanged.

### D3. Rollback

`alembic downgrade 0001_initial` drops the index and the three columns; agents registered after the upgrade keep
their rows but lose description and endpoint_url. The SQLite file is copied to backup storage right before the
upgrade and nightly, so those values can be restored from the copy.

### D4. Retention and volumes

| Item | Value |
|---|---|
| Rows today and growth | 8 agents; about 20 new agents a month |
| Retention | agents are kept while the inventory needs them; nothing is deleted in this release |
| Deletion or archival | none in this release: pausing replaces deletion so the AI inventory keeps its history |
| Personal data columns | none: owner_team holds team names; the form says not to enter personal names |

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | POST and PATCH response time | p95 at most 200 ms with 500 agents |
| NFR-2 | Performance | Search, filter and sort on /agents | table updated within 100 ms of a keystroke with 500 agents |
| NFR-3 | Accessibility | Registered agents, Register agent and the drawer | WCAG 2.2 AA, 0 axe violations in every U3 state |
| NFR-4 | Observability | Registry changes | one JSON log line per POST and PATCH with agent id, status code and duration in ms |
| NFR-5 | Security | Endpoint URLs | stored and shown as text only; the portal never calls them |

### 11. Data and privacy

The registry stores agent names, owner team names, model ids, descriptions and HTTPS endpoint URLs, all Internal.
No personal data is collected: owners are teams, and the Description field's hint reads "Describe what the agent
does. Do not include personal or customer data." Logs carry ids and status codes, never request bodies.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NAIC AI bulletin | Maintain an inventory of AI systems with documented ownership and controls over their use | each agent is recorded with its owner team, approved model and endpoint; only approved models are accepted; pausing an agent is recorded with updated_at and the change log line |

### 13. Rollout and compatibility

No feature flag. Deployment order: back up the SQLite file, run `alembic upgrade head`, deploy the API, then the web
app. Existing dashboard and extension users see no change except the count after new registrations. Rollback is the
previous build plus `alembic downgrade 0001_initial`. Agent owners are told through the AI Ecosystem pilot channel.

### 14. Test expectations

API: pytest (`cd api && pytest -q`) on a fresh migrated and seeded SQLite file per test with the clock at 2026-10-17
09:42 UTC; covers AS-1 to AS-7, every section 6 message, the 413 case, the case-insensitive unique index under two
concurrent posts, the 0002 upgrade on a seeded 0001 database (seed values unchanged) and its downgrade. Web: vitest
with Testing Library (`cd web && npm test`) with `lib/api.ts` mocked for form validation, URL state, filters, sorting,
the drawer and every U3 state; Playwright (`cd web && npx playwright test`) against the seeded API for AS-2, AS-9,
AS-14, AS-17, AS-18 and AS-20 with an axe check on each screen. Test URLs use example.com; test data is the seed data
plus Claims Letter Drafter.

### 15. Increments

N/A — one increment of 12 requirements.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | AIGAE-102 deployed with its seed data and Alembic revision 0001_initial | Vinod Kumar |
| Assumption | Registration stays open to the AIG network until sign-in arrives in a later release | Raj Patel |
| Question | Whether paused agents should be blocked at the AI gateway, not only marked in the inventory | Sarah Mitchell |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Raj Patel | 17 Oct 2026 |
| Tech lead | Vinod Kumar | 17 Oct 2026 |
