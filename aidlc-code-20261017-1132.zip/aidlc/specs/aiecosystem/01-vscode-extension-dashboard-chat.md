# AIG AI Ecosystem for VS Code: dashboard and @aig chat

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · vsix |
| Title | AIG AI Ecosystem VS Code extension with a platform dashboard and the @aig chat participant |
| Project | new |
| Project id | aig-ecosystem-vscode |
| Repositories | app |
| Surfaces | vsix, ui |
| Stack preset | vscode-extension |
| Stack exceptions | none |
| Jira | AIGAE-101 |
| Priority | P2 |
| Target release | 2026.12 |
| Business sponsor | Sarah Mitchell |
| Product owner | Raj Patel |
| Tech lead | Vinod Kumar |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | none |
| Risk tier | medium |
| Run budget (USD) | 45 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Engineers who build agents on the AIG AI Ecosystem leave VS Code to open the AI Ecosystem Portal whenever they need
to know how many agents and MCP servers are registered, which models are approved or what the platform spent this
month. This extension puts those platform figures in a VS Code sidebar and answers the same questions in VS Code
Chat through `@aig`, so engineers stay in the editor and use the same numbers the portal shows.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Engineer | AIG engineer with VS Code and network access to the AI Ecosystem Portal API | Open the dashboard, refresh it, ask `@aig /agents`, `/models` and `/usage` |
| AI Ecosystem Portal API | The portal's read-only HTTP API at `aig.apiUrl` | Answers the four GET endpoints in section 6 |

### 3. Scope

**In scope**

- An "AIG AI Ecosystem" Activity Bar container holding a Dashboard webview view with five platform KPIs.
- The `@aig` chat participant with `/agents`, `/models` and `/usage`, answered from the portal API without any AI model.
- The `aig.apiUrl` setting, the Refresh and Open Dashboard commands and a status bar item.

**Out of scope**

- No sign-in in this release: the portal API is read-only on the AIG network; no tokens or secrets are stored.
- Calling any AI model, free-text questions, writing to the portal, telemetry, the public Marketplace.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | The Activity Bar shows an "AIG AI Ecosystem" container (icon in V2) holding one webview view titled "Dashboard" | Must |
| FR-2 | The Dashboard shows five KPI cards in this order: Registered agents, MCP servers, Approved models, Requests today, Spend month to date, filled from GET /api/dashboard/summary with the formats in section 6 | Must |
| FR-3 | While a summary request is in flight the Dashboard shows five skeleton cards and the status text "Loading platform summary…" | Must |
| FR-4 | When the summary request fails the Dashboard replaces the cards with the matching error message from section 6 and a "Retry" button that repeats the request | Must |
| FR-5 | When all five summary values are 0 the Dashboard shows "No platform activity yet." instead of the cards | Must |
| FR-6 | The command "AIG: Refresh Dashboard" (`aig.refreshDashboard`), also a $(refresh) button in the view title, fetches the summary again | Must |
| FR-7 | The status bar item reads "$(hubot) AIG <n> agents" ("AIG 1 agent" for one) after a successful fetch and "$(warning) AIG offline" after a failed one, and clicking it runs `aig.openDashboard` | Should |
| FR-8 | `@aig /agents` replies with a heading "<n> registered agents (<a> active, <p> paused)" and a Markdown table of every agent from GET /api/agents sorted by name A–Z, or "No agents are registered yet." when the list is empty | Must |
| FR-9 | `@aig /models` replies with a heading "<n> models (<a> approved, <p> preview)" and a Markdown table of every model from GET /api/models sorted by name A–Z | Must |
| FR-10 | `@aig /usage` replies with a heading "Last 7 days: <requests> requests, <cost>" and a Markdown table of the seven days from GET /api/usage?days=7, oldest first | Must |
| FR-11 | `@aig` with no slash command, or with any other text, replies exactly "I can answer /agents, /models and /usage from the AI Ecosystem Portal. Try @aig /usage." and calls no endpoint | Must |
| FR-12 | When a chat command's request fails, `@aig` replies with the matching error message from section 6 followed by "Check the aig.apiUrl setting and try again." | Must |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the extension is installed | VS Code starts | the Activity Bar shows the AIG AI Ecosystem icon and selecting it shows the Dashboard view |
| AS-2 | FR-2 | the portal returns the summary example in section 6 | the Dashboard opens | the cards read 8, 4, 4, 10,450 and $887.50 in the FR-2 order and the footer reads "Updated 17 Oct 2026, 09:42" |
| AS-3 | FR-3 | the Dashboard is open and the portal answers after 2 seconds | the user presses the view title Refresh button | five skeleton cards and "Loading platform summary…" show until the answer arrives |
| AS-4 | FR-4 | nothing listens on http://localhost:8000 | the Dashboard opens | "Couldn't reach the AI Ecosystem Portal at http://localhost:8000." and a Retry button show |
| AS-5 | FR-4 | the portal returns HTTP 500 | the user presses Retry | "The AI Ecosystem Portal returned HTTP 500." and a Retry button show |
| AS-6 | FR-4 | the portal returns `{"registered_agents": "eight"}` | the Dashboard opens | "The AI Ecosystem Portal sent a response this extension doesn't understand." shows |
| AS-7 | FR-4 | `aig.apiUrl` is set to `ftp://example.com` | the Dashboard opens | "aig.apiUrl must be an http or https URL." shows and no request is sent |
| AS-8 | FR-5 | the portal returns every value as 0 | the Dashboard opens | "No platform activity yet." shows and no cards are drawn |
| AS-9 | FR-6 | the Dashboard shows 8 registered agents and the portal now returns 9 | the user runs AIG: Refresh Dashboard | the first card reads 9 |
| AS-10 | FR-7 | the last fetch succeeded with 8 agents | the user clicks the status bar item | the item reads "$(hubot) AIG 8 agents" and the Dashboard view is revealed and focused |
| AS-11 | FR-7 | the portal is unreachable | a refresh finishes | the status bar item reads "$(warning) AIG offline" |
| AS-12 | FR-8 | the portal returns the 8 agents of section 6 | the user sends `@aig /agents` | the reply starts "8 registered agents (6 active, 2 paused)" and the first table row is Broker Email Triage |
| AS-13 | FR-8 | the portal returns `{"items": [], "total": 0}` | the user sends `@aig /agents` | the reply is "No agents are registered yet." |
| AS-14 | FR-9 | the portal returns the 5 models of section 6 | the user sends `@aig /models` | the reply starts "5 models (4 approved, 1 preview)" and lists Claude Haiku 4.5 first |
| AS-15 | FR-10 | the portal returns the 7 days of section 6 | the user sends `@aig /usage` | the reply starts "Last 7 days: 118,750 requests, $887.50" and the first row reads 11 Oct 2026, 11,400, $85.20 |
| AS-16 | FR-11 | the extension is active | the user sends `@aig what is our budget?` | the fallback text of FR-11 is the whole reply and no HTTP request is made |
| AS-17 | FR-12 | the portal returns HTTP 503 to GET /api/models | the user sends `@aig /models` | the reply is "The AI Ecosystem Portal returned HTTP 503. Check the aig.apiUrl setting and try again." |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Endpoints | GET `<aig.apiUrl>/api/dashboard/summary`, `/api/agents`, `/api/models`, `/api/usage?days=7`; a trailing `/` on `aig.apiUrl` is removed before joining |
| Summary shape | `registered_agents` int ≥ 0, `mcp_servers` int ≥ 0, `approved_models` int ≥ 0, `requests_today` int ≥ 0, `spend_mtd_usd` number ≥ 0 with 2 decimals, `generated_at` ISO 8601 UTC string |
| Agents shape | `{items: [{id int, name string, owner_team string, model_id string, model_name string, status "active" or "paused", requests_7d int, cost_7d_usd number, created_at ISO 8601 string}], total int}`; extra fields are ignored |
| Models shape | `{items: [{id string, name string, provider string, status "approved" or "preview"}]}`; extra fields are ignored |
| Usage shape | `{days: [{date "YYYY-MM-DD", requests int, cost_usd number}], total_requests int, total_cost_usd number}` |
| Validation | A response missing a field, or with a field of the wrong type, counts as "doesn't understand" |
| Timeout | 5 seconds per request; a timeout counts as unreachable |
| Error messages | unreachable: "Couldn't reach the AI Ecosystem Portal at <aig.apiUrl>."; status ≥ 400: "The AI Ecosystem Portal returned HTTP <status>."; bad shape: "The AI Ecosystem Portal sent a response this extension doesn't understand."; bad setting: "aig.apiUrl must be an http or https URL." |
| Number formats | integers with en-US grouping (10,450); money as US dollars with 2 decimals, rounded half up ($887.50, $0.00); dates as 11 Oct 2026; the Updated time is the fetch time in local time, 24-hour (17 Oct 2026, 09:42) |
| Chat tables | /agents: Name, Owner team, Model (model_name), Status, Requests (7 days); /models: Name, Provider, Status; /usage: Date, Requests, Cost; Status is shown capitalised (Active, Paused, Approved, Preview) |
| Refetch triggers | One fetch at activation (shared by the view and the status bar), then only Refresh, Retry and a change to `aig.apiUrl`; there is no polling |

Summary example (the same numbers the portal's seed data produces):

```json
{"registered_agents": 8, "mcp_servers": 4, "approved_models": 4, "requests_today": 10450, "spend_mtd_usd": 887.50, "generated_at": "2026-10-17T09:42:00Z"}
```

| Fixture | Values used by the tests |
|---|---|
| Agents (8) | Broker Email Triage (active, 12,500), Claims Intake Assistant (active, 25,000), Code Review Helper (active, 15,000), Contract Clause Extractor (paused, 0), Fraud Signal Reviewer (active, 10,000), Policy Q&A Assistant (active, 37,500), Reinsurance Treaty Summariser (paused, 0), Underwriting Risk Summariser (active, 18,750) |
| Models (5) | Claude Haiku 4.5, Claude Sonnet 4.5, Gemini 2.5 Pro, GPT-4o (approved); Llama 3.3 70B (preview) |
| Usage (7 days) | 11–17 Oct 2026 requests 11,400; 19,000; 19,950; 20,900; 19,000; 18,050; 10,450 and cost $85.20; $142.00; $149.10; $156.20; $142.00; $134.90; $78.10 |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Engineers with the extension installed | 0 | 400 within 60 days of release | private gallery install count |
| Portal visits for KPI look-ups | about 1,100 a week | 50 % fewer | portal access logs before and after release |

## Part B — Technical (owner: Tech lead)

### 8. Current system

N/A — new project.

### 9. New project setup

The vscode-extension preset layout with the scaffold's `app.helloWorld` command removed and every id prefixed `aig.`:
`src/extension.ts` (activate wiring only), `src/config.ts` (reads and validates `aig.apiUrl`), `src/api.ts` (fetch,
timeout and shape checks), `src/format.ts` (number, money and date formats), `src/dashboardView.ts` (webview view
provider), `src/statusBar.ts`, `src/chat.ts` (participant handler), `webview/dashboard.ts` bundled to
`dist/webview/dashboard.js`, `media/aig-ecosystem.svg` and `media/dashboard.css`. Scripts: build, watch, typecheck,
test, test:integration and package. The README explains installing the .vsix and setting `aig.apiUrl`.

## VS Code extension add-on (owner: Tech lead)

### V1. Compatibility

| Item | Value |
|---|---|
| VS Code engine | ^1.90.0 (stable chat participant API) |
| Where it runs | desktop on Windows, macOS and Linux, and the local side of Remote SSH, WSL and Dev Containers |
| Workspace trust | works in untrusted workspaces: it reads no workspace files and `aig.apiUrl` has application scope, so a workspace cannot redirect it |
| Extension kind | ui (it calls the portal from the engineer's machine) |

### V2. Contributions

| Contribution | Id | Title or label | Details |
|---|---|---|---|
| Activity Bar container | aig-ecosystem | AIG AI Ecosystem | icon media/aig-ecosystem.svg (below) |
| View | aig.dashboard | Dashboard | webview view in aig-ecosystem |
| Command | aig.refreshDashboard | AIG: Refresh Dashboard | Command Palette and view title icon $(refresh) |
| Command | aig.openDashboard | AIG: Open Dashboard | Command Palette and status bar item; reveals and focuses aig.dashboard |
| Chat participant | aig.ecosystem | name `aig`, full name "AIG AI Ecosystem" | commands agents ("List registered agents"), models ("List models"), usage ("Requests and cost, last 7 days"); icon media/aig-ecosystem.svg |
| Status bar item | aig.status | AIG | left side, priority 100, tooltip "AIG AI Ecosystem: open the dashboard"; "$(sync~spin) AIG" while loading |
| Setting | aig.apiUrl | Base URL of the AI Ecosystem Portal API | string, default `http://localhost:8000`, scope application |

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="4" r="2"/><circle cx="19" cy="17" r="2"/><circle cx="5" cy="17" r="2"/><path d="M12 6v3"/><path d="M14.4 13.7l3 2.1"/><path d="M9.6 13.7l-3 2.1"/></svg>
```

### V3. Activation and performance

Activates on onStartupFinished (so the status bar item appears), onView:aig.dashboard, onChatParticipant:aig.ecosystem
and the two commands. Activation under 50 ms: it registers providers and starts one summary fetch without awaiting it.
All HTTP calls are asynchronous `fetch` with an AbortController timeout; nothing blocks the extension host.

### V4. Webviews

One webview view, aig.dashboard, with `enableScripts: true` and `localResourceRoots` limited to `media/` and
`dist/webview/`. CSP: `default-src 'none'; img-src ${webview.cspSource}; style-src ${webview.cspSource}; script-src
'nonce-<fresh nonce per render>';`. The webview makes no network calls: the extension host fetches and posts
messages. Host → webview: `{type: "loading"}`, `{type: "summary", data, updatedAt}`, `{type: "empty"}`,
`{type: "error", message}`. Webview → host: `{type: "ready"}`, `{type: "retry"}`; any other message is dropped. The
last summary is kept with `setState` so the view redraws at once when it becomes visible again.

### V5. Telemetry and data

No telemetry. No secrets and no SecretStorage use. The only network calls are the four GET requests to `aig.apiUrl`
in section 6, without credentials or cookies. Nothing is written to disk.

### V6. Packaging and distribution

| Item | Value |
|---|---|
| Extension id | aig.aig-ai-ecosystem |
| Version | 0.1.0 |
| Distribution | AIG private extension gallery; not the public Marketplace |
| Signing | signed with the AIG enterprise code-signing certificate in the release pipeline |
| Package command | npm run package writes dist/aig-ai-ecosystem.vsix |

### V7. Extension tests

Unit tests (vitest, `test/__mocks__/vscode.ts` extended with `chat`, `window.createStatusBarItem`,
`window.registerWebviewViewProvider` and `workspace.getConfiguration`) cover config validation, every format rule,
the API client with `fetch` stubbed (success, timeout, HTTP 500, bad shape), the chat handler for every command and
the fallback, the status bar texts, and the webview messages. Integration tests with @vscode/test-electron, headless
in CI, start a local Node HTTP stub that serves the section 6 fixtures and check activation, that both commands and
the chat participant are registered, that aig.dashboard resolves, and AS-9 and AS-11.

## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

| Item | Value |
|---|---|
| Design system | VS Code theme variables (`--vscode-foreground`, `--vscode-sideBar-background`, `--vscode-editorWidget-background`, `--vscode-focusBorder`) with the AIG accent for the card top border: #1352de in light themes, #6e9bff in dark and high-contrast themes |
| Figma | none: the layout is specified in U2 to U4 |
| Screenshots | none |
| New tokens or components | KPI card: 3 px accent top border, label in 12 px `--vscode-descriptionForeground`, value in 24 px semibold |

### U2. Screens

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| Dashboard | AIG AI Ecosystem container, view aig.dashboard | See the five platform KPIs | refresh, retry |
| @aig replies | VS Code Chat view | Answer /agents, /models and /usage | read the table |

### U3. States

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| Dashboard | five skeleton cards and "Loading platform summary…" | "No platform activity yet." | the section 6 message and a Retry button | not applicable: no sign-in in this release |
| @aig replies | chat progress "Asking the AI Ecosystem Portal…" | "No agents are registered yet." for /agents | the section 6 message with "Check the aig.apiUrl setting and try again." | not applicable: no sign-in in this release |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | one card per row below 400 px view width, two per row from 400 px, five in one row from 900 px (view moved to the panel) |
| Accessibility level | WCAG 2.2 AA in light, dark and high-contrast themes |
| Keyboard and screen reader | Retry is a native button reachable with Tab and shows `--vscode-focusBorder`; loading, empty and error texts sit in one `role="status"` `aria-live="polite"` region; each card is a `group` with aria-label "<label>: <value>" |
| Browsers | the VS Code webview (Electron Chromium) only |

### U5. Content and localisation

| Item | Value |
|---|---|
| Languages | English (US) |
| Formats | 10,450; $887.50; 11 Oct 2026; 17 Oct 2026, 09:42 |

### U6. Analytics

N/A — the extension records no telemetry or analytics.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | Activation time | under 50 ms on a developer laptop |
| NFR-2 | Performance | Dashboard render after the summary arrives | under 100 ms |
| NFR-3 | Security | Webview content security policy | exactly the V4 CSP; no inline script without the nonce; no remote resources |
| NFR-4 | Accessibility | Dashboard webview | 0 axe violations in light and dark themes |
| NFR-5 | Usability | Keyboard use | every command reachable from the Command Palette; Retry reachable with Tab |

### 11. Data and privacy

The extension reads aggregate platform figures (counts, agent and model names, owner team names, requests and cost)
classified Internal. It holds no personal data, stores nothing on disk and sends nothing except the GET requests in
section 6. No prompt or code from the editor is sent anywhere; chat input is matched locally against the three commands.

### 12. Compliance

N/A — no regime applies: the extension shows Internal aggregate figures, stores no data and calls no AI model.

### 13. Rollout and compatibility

No feature flag. 0.1.0 goes to the AIG AI Ecosystem pilot group (about 40 engineers) in the private gallery for two
weeks, then to all engineers. The extension needs the portal API of AIGAE-102 at `aig.apiUrl`; with it missing, the
error state shows. Rollback is unpublishing the version in the private gallery; there is no stored data to migrate.
The AI Ecosystem Portal team and the pilot channel are told before each stage.

### 14. Test expectations

`npm test` runs the vitest unit suite (coverage at least 80 % of lines in `src/`); `npm run test:integration` runs
the @vscode/test-electron suite under `xvfb-run -a` in CI against the local HTTP stub; `npm run typecheck` and
`npm run package` must succeed and produce dist/aig-ai-ecosystem.vsix. Test data is the section 6 fixtures only; no
test reaches a real portal. Test names carry the scenario id, e.g. it("AC-12: lists agents A–Z", …).

### 15. Increments

N/A — one increment of 12 requirements.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | The portal API of AIGAE-102 serving the section 6 shapes | Vinod Kumar |
| Dependency | Publish token for the AIG private extension gallery in CI | Vinod Kumar |
| Assumption | Engineers reach the portal API from their machines without a proxy login | Raj Patel |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Raj Patel | 17 Oct 2026 |
| Tech lead | Vinod Kumar | 17 Oct 2026 |
