# AIG Model catalogue

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · ui-only |
| Title | AIG Model catalogue page listing the approved and preview AI models |
| Project | new |
| Project id | aig-model-catalogue |
| Repositories | app |
| Surfaces | ui |
| Stack preset | vite-react |
| Stack exceptions | none |
| Jira | AIGAE-104 |
| Priority | P3 |
| Target release | 2026.12 |
| Business sponsor | Sarah Mitchell |
| Product owner | Raj Patel |
| Tech lead | Vinod Kumar |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | none |
| Risk tier | low |
| Run budget (USD) | 20 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

Engineers choosing a model for a new agent ask the AI platform team which models AIG allows, how large their context
windows are and what they cost, about 30 times a week. A single Model catalogue page lists the AI models available on
the AIG AI Ecosystem with their provider, context window, prices and status, so engineers can answer the question
themselves and pick an approved model.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Engineer | AIG engineer or architect choosing a model | Browse, search and open the details of each model |

### 3. Scope

**In scope**

- One "Model catalogue" page: a table of the 6 models in section 6, a search box and a detail panel.

**Out of scope**

- No sign-in in this release, and no backend: the model list is built into the app.
- Requesting, approving or comparing models, price calculators, dark theme, analytics, languages other than English.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | The page lists the 6 models of section 6 in a table sorted by name A–Z ignoring case, with the columns Name, Provider, Context window, Input price, Output price and Status | Must |
| FR-2 | A search box labelled "Search models" keeps only the rows whose name or provider contains the trimmed text, ignoring case, as each character is typed, and the count line reads "Showing <n> of 6 models" | Must |
| FR-3 | When no model matches, the table is replaced by `No models match "<text>".` and a "Clear search" button that empties the search box, shows all 6 rows and moves focus to the search box | Must |
| FR-4 | Clicking a row, or pressing Enter or Space on a focused row, shows that model in the detail panel and marks the row with aria-selected="true" | Must |
| FR-5 | Until the model list has loaded the table shows six skeleton rows and the status text "Loading models…" | Must |
| FR-6 | Pressing Escape, or the panel's "Close" button, clears the selection, shows "Select a model to see its details." in the panel and returns focus to the row | Should |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the page has loaded | the user looks at the table | 6 rows from Claude Haiku 4.5 to Llama 3.3 70B; the Claude Sonnet 4.5 row reads Anthropic, 200,000, $3.00, $15.00, Approved; no row is selected and the panel reads "Select a model to see its details." |
| AS-2 | FR-2 | the page has loaded | the user types "gpt" | only GPT-4o and GPT-4o mini remain and the count line reads "Showing 2 of 6 models" |
| AS-3 | FR-2 | the page has loaded | the user types "  ANTHROPIC " | only Claude Haiku 4.5 and Claude Sonnet 4.5 remain |
| AS-4 | FR-3 | the page has loaded | the user types "zzz", then presses Clear search | first `No models match "zzz".`, then all 6 rows with an empty search box that has focus |
| AS-5 | FR-4 | the page has loaded | the user clicks Gemini 2.5 Pro | the panel shows Gemini 2.5 Pro, Google, Approved, 1,048,576 tokens, $1.25, $10.00 and "Long-document review and summarisation" |
| AS-6 | FR-4 | the page has loaded | the user tabs to the Llama 3.3 70B row and presses Enter | the panel shows Llama 3.3 70B with the Preview badge and the row has aria-selected="true" |
| AS-7 | FR-4 | GPT-4o is selected | the user types "claude" | GPT-4o leaves the table and the panel returns to "Select a model to see its details." |
| AS-8 | FR-5 | the model list has not resolved yet | the page opens | six skeleton rows show and a screen reader hears "Loading models…" |
| AS-9 | FR-6 | Claude Haiku 4.5 is shown in the panel | the user presses Escape | the panel reads "Select a model to see its details." and focus is on the Claude Haiku 4.5 row |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Model list | exactly the 6 models below, from `src/data/models.ts`, read through `listModels()` in `src/api/models.ts`, which returns a Promise so a catalogue API can replace it later without UI changes |
| Formats | context window with en-US grouping and "tokens" in the panel (1,048,576 tokens); prices in US dollars per 1 million tokens with 2 decimals ($0.15); column headers "Input ($ / 1M tokens)" and "Output ($ / 1M tokens)" |
| Status badges | Approved: text #0a7458 on #e3f5ef; Preview: text #b26b00 on #fff3dc |
| Search state | kept in the page only: the URL does not change and a reload starts with an empty search |
| Selection | one model at a time; a selected model that the search hides is deselected |

| Name | Provider | Context window | Input $ / 1M | Output $ / 1M | Status | Recommended use (panel) |
|---|---|---|---|---|---|---|
| Claude Haiku 4.5 | Anthropic | 200,000 | $1.00 | $5.00 | Approved | High-volume classification and triage |
| Claude Sonnet 4.5 | Anthropic | 200,000 | $3.00 | $15.00 | Approved | Complex reasoning, coding and document analysis |
| Gemini 2.5 Pro | Google | 1,048,576 | $1.25 | $10.00 | Approved | Long-document review and summarisation |
| GPT-4o | OpenAI | 128,000 | $2.50 | $10.00 | Approved | General drafting and summarisation |
| GPT-4o mini | OpenAI | 128,000 | $0.15 | $0.60 | Preview | Low-cost extraction, under evaluation |
| Llama 3.3 70B | Meta | 128,000 | $0.72 | $0.72 | Preview | Self-hosted workloads, under evaluation |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| "Which models can I use?" questions to the AI platform team | about 30 a week | 10 a week within 2 months | tagged requests in the AI platform support channel |

## Part B — Technical (owner: Tech lead)

### 8. Current system

N/A — new project.

### 9. New project setup

One Vite React app at the repository root from the vite-react preset: `src/App.tsx` (header and page),
`src/components/{ModelTable,ModelDetail,SearchBox,StatusBadge}.tsx`, `src/data/models.ts` (the section 6 list),
`src/api/models.ts` (`listModels()`), `src/format.ts` and `src/styles.css` (tokens). Scripts: dev, build, preview,
test, typecheck and lint. The README explains how to install, run, test and update the model list.

## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

| Item | Value |
|---|---|
| Design system | AIG AI Ecosystem tokens (light): header #001871 with white text, primary #1352de, page #f3f5fa, surface #ffffff, line #e4e9f2, text #0b1533, muted #56637e, selected row #e8effd with a 3 px #1352de left border |
| Figma | none: the layout is specified in U2 to U4 |
| Screenshots | none |
| New tokens or components | ModelTable, ModelDetail, SearchBox, StatusBadge |

### U2. Screens

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| Model catalogue | / (64 px navy header with "AIG" bold and "Model catalogue", then the title "Model catalogue" and the subtitle "AI models available on the AIG AI Ecosystem") | Find a model and read its details | search, select a row, close the panel, clear search |

### U3. States

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| Model catalogue | six skeleton rows with the status text "Loading models…" | `No models match "<text>".` with Clear search | not applicable: built-in data cannot fail | not applicable: no sign-in in this release |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | 1024 px and up: table two thirds and panel one third side by side; 640–1023 px: panel below the table; below 640 px: the table shows Name, Provider and Status only and the panel shows the rest |
| Accessibility level | WCAG 2.2 AA |
| Keyboard and screen reader | Tab order: search box, rows, panel Close; rows have tabindex 0 and aria-selected; the panel is a region labelled by the model name; the count line and "Loading models…" are in a `role="status"` `aria-live="polite"` region; 2 px #1352de focus ring |
| Browsers | latest Chrome, Edge, Safari and Firefox |

### U5. Content and localisation

| Item | Value |
|---|---|
| Languages | English (US) |
| Formats | 200,000; 1,048,576 tokens; $3.00; $0.15 |

### U6. Analytics

N/A — no analytics in this release.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Accessibility | Model catalogue in the loaded, empty and selected states | WCAG 2.2 AA, 0 axe violations |
| NFR-2 | Performance | First load of the production build | under 1.5 seconds on the AIG network |
| NFR-3 | Usability | Keyboard use | every action in FR-2 to FR-6 works without a mouse |

### 11. Data and privacy

The app holds only the built-in list of 6 models and their published list prices, classified Internal. It collects
nothing, stores nothing in the browser and makes no network requests after loading.

### 12. Compliance

N/A — no regime applies: a read-only list of models and prices with no personal or customer data.

### 13. Rollout and compatibility

No feature flag. The static build is published to the AIG internal static web hosting and linked from the AI platform
support channel. Model list changes ship as a new build after the AI platform team approves them. Rollback is
republishing the previous build.

### 14. Test expectations

vitest with Testing Library (`npm test`): unit tests for the search filter and the formats, and component tests for
AS-1 to AS-9, holding the `listModels()` promise open for AS-8. Playwright (`npx playwright test`) against `vite
preview` of the production build for AS-1, AS-2, AS-4 and AS-6 with an axe check in each state. `npm run typecheck`,
`npm run lint` and `npm run build` must pass. Test data is the section 6 list only.

### 15. Increments

N/A — small enough to ship in one increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Assumption | The section 6 prices are the AI platform team's list prices for 2026.12 | Raj Patel |
| Dependency | A path on the AIG internal static web hosting | Vinod Kumar |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Raj Patel | 17 Oct 2026 |
| Tech lead | Vinod Kumar | 17 Oct 2026 |
