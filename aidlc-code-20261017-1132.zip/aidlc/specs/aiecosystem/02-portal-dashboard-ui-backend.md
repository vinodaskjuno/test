# AI Ecosystem Portal: platform dashboard

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · ui-backend |
| Title | AI Ecosystem Portal platform dashboard with its read API and SQLite store |
| Project | new |
| Project id | aig-ecosystem-portal |
| Repositories | app |
| Surfaces | ui, backend, data |
| Stack preset | nextjs-fastapi |
| Stack exceptions | SQLite instead of the preset's Postgres — single-node pilot with no database server, and SQLAlchemy keeps a later move to Postgres a configuration change — Vinod Kumar |
| Jira | AIGAE-102 |
| Priority | P2 |
| Target release | 2026.12 |
| Business sponsor | Sarah Mitchell |
| Product owner | Raj Patel |
| Tech lead | Vinod Kumar |
| Architecture | Vinod Kumar | 17 Oct 2026 |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | NAIC AI bulletin |
| Risk tier | medium |
| Run budget (USD) | 45 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

AIG's AI governance group and platform owners have no single place that shows how many AI agents, MCP servers and
approved models the AIG AI Ecosystem has, or what the agents cost. Figures are collected by hand from several tools
each month. The AI Ecosystem Portal dashboard shows these KPIs, the last 7 days of requests and cost, and the busiest
agents from one API, which the VS Code extension (AIGAE-101) also reads.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Platform viewer | AIG engineer, platform owner or AI governance member on the AIG network | Open the dashboard and retry after an error |
| API client | The portal web app and the AIG AI Ecosystem VS Code extension | Call the GET endpoints in B1 |
| Platform engineer | Runs the service | Run the migration and the seed script |

### 3. Scope

**In scope**

- A FastAPI service with SQLite, an Alembic migration, a deterministic seed script and five GET endpoints.
- A Next.js app with the AIG header and sidebar shell and a Dashboard page: KPI cards, a 7-day bar chart, top agents.

**Out of scope**

- No sign-in in this release: the portal runs on the AIG network only.
- Registering or editing agents (AIGAE-103), MCP and model management pages, exports, analytics, dark theme.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | GET /api/dashboard/summary returns registered_agents, mcp_servers, approved_models, requests_today, spend_mtd_usd and generated_at, computed as defined in section 6 | Must |
| FR-2 | GET /api/usage?days=<n> returns exactly n daily entries ending today (UTC), oldest first, with 0 for days without usage, where n is 1–30 and defaults to 7 | Must |
| FR-3 | GET /api/agents returns every agent sorted by name A–Z ignoring case, each with requests_7d and cost_7d_usd for the 7 days ending today | Must |
| FR-4 | GET /api/models returns every model sorted by name A–Z ignoring case | Must |
| FR-5 | `python -m app.seed --end-date YYYY-MM-DD` (default today UTC) empties the four tables and writes exactly the seed data in section 6 | Must |
| FR-6 | Every page shows the AIG header with the wordmark "AIG AI Ecosystem Portal" and a sidebar whose "Dashboard" link carries aria-current="page" on / | Must |
| FR-7 | The Dashboard at / shows five KPI cards in this order: Registered agents, MCP servers, Approved models, Requests today, Spend month to date, with the formats in U5 | Must |
| FR-8 | A "Requests, last 7 days" card shows an inline SVG bar chart with one bar per day from GET /api/usage?days=7, each labelled with its date and request count, and the line "7-day cost: <total>" below it | Must |
| FR-9 | A "Top agents by requests" table lists the 5 agents with the most requests_7d (ties by name A–Z, agents with 0 requests left out) with the columns Rank, Agent, Owner team, Model, Requests (7 days) and Cost (7 days) | Must |
| FR-10 | While the dashboard's three requests are in flight it shows five skeleton cards, a 200 px skeleton chart and five skeleton table rows | Must |
| FR-11 | When any of the three requests fails the dashboard shows the matching message from U3 and a "Retry" button that repeats all three requests | Must |
| FR-12 | When all 7 days have 0 requests the chart card shows "No usage recorded in the last 7 days." and the table card shows "No agent activity in the last 7 days." | Must |

### 5. Acceptance scenarios

All scenarios run on the seed data (end date 2026-10-17) with the clock at 2026-10-17 09:42 UTC unless they say otherwise.

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | the seed data | a client calls GET /api/dashboard/summary | 200 `{"registered_agents": 8, "mcp_servers": 4, "approved_models": 4, "requests_today": 10450, "spend_mtd_usd": 887.5, "generated_at": "2026-10-17T09:42:00Z"}` |
| AS-2 | FR-1 | an empty database after the migration | a client calls GET /api/dashboard/summary | 200 with every count 0 and spend_mtd_usd 0.0 |
| AS-3 | FR-2 | the seed data | a client calls GET /api/usage?days=7 | 200 with 7 entries 2026-10-11 to 2026-10-17 matching the daily totals table, total_requests 118750 and total_cost_usd 887.5 |
| AS-4 | FR-2 | the seed data | a client calls GET /api/usage?days=10 | 10 entries; 2026-10-08 to 2026-10-10 have requests 0 and cost_usd 0.0; the totals stay 118750 and 887.5 |
| AS-5 | FR-2 | the API | a client calls GET /api/usage with days=0, days=31 or days=abc | 422 with FastAPI's validation error list naming `days` |
| AS-6 | FR-3 | the seed data | a client calls GET /api/agents | 8 items, total 8; the first is Broker Email Triage with requests_7d 12500 and cost_7d_usd 125.0; Contract Clause Extractor has 0 and 0.0 |
| AS-7 | FR-4 | the seed data | a client calls GET /api/models | 5 items, Claude Haiku 4.5 first and Llama 3.3 70B last with status preview |
| AS-8 | FR-5 | the seed has already run | the seed runs again with the same end date | the tables hold exactly 8 agents, 4 MCP servers, 5 models and 42 usage rows |
| AS-9 | FR-6 | the web app is running | a viewer opens / | the navy header shows "AIG AI Ecosystem Portal" and the sidebar's Dashboard link has aria-current="page" |
| AS-10 | FR-7 | the seed data | a viewer opens / | the cards read 8, 4, 4, 10,450 and $887.50 in the FR-7 order |
| AS-11 | FR-8 | the seed data | a viewer opens / | 7 bars labelled 11 Oct to 17 Oct; the 14 Oct bar is the tallest (20,900) and the line reads "7-day cost: $887.50" |
| AS-12 | FR-9 | the seed data | a viewer opens / | rows in order Policy Q&A Assistant 37,500 $112.50; Claims Intake Assistant 25,000 $300.00; Underwriting Risk Summariser 18,750 $225.00; Code Review Helper 15,000 $45.00; Broker Email Triage 12,500 $125.00 |
| AS-13 | FR-10 | the API answers after 2 seconds | a viewer opens / | the skeletons show and a screen reader hears "Loading dashboard…" until the data arrives |
| AS-14 | FR-11 | the API is stopped | a viewer opens / and then starts the API and presses Retry | first "Couldn't reach the AI Ecosystem Portal API." with Retry, then the seeded dashboard |
| AS-15 | FR-11 | GET /api/usage returns HTTP 500 | a viewer opens / | "The AI Ecosystem Portal API returned HTTP 500." with Retry |
| AS-16 | FR-12 | an empty database | a viewer opens / | the cards read 0, 0, 0, 0 and $0.00 and both empty messages of FR-12 show |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Today | the API's current UTC date, read through one injectable clock dependency |
| registered_agents | count of all agents rows |
| mcp_servers | count of all mcp_servers rows |
| approved_models | count of models with status approved |
| requests_today | sum of usage_daily.requests for today |
| spend_mtd_usd | sum of usage_daily.cost_cents from the 1st of today's month to today, divided by 100 |
| generated_at | the clock's current UTC time to the second, ISO 8601 with Z |
| Money | stored as integer cents; returned as a number with 2 decimals |
| Usage response | `{days: [{date "YYYY-MM-DD", requests int, cost_usd number}], total_requests int, total_cost_usd number}` |
| Agent item | `{id int, name, owner_team, model_id, model_name, status "active" or "paused", requests_7d int, cost_7d_usd number, created_at ISO 8601}`; list response `{items, total}` |
| Model item | `{id, name, provider, status "approved" or "preview"}`; list response `{items}` |
| Seed usage | for each agent with a base above 0 and day d = 0 (end date − 6) to 6 (end date): requests = base × M[d] ÷ 100 with M = 60, 100, 105, 110, 100, 95, 55; cost = requests × the model's cost per request, rounded half up to cents |

| Seed agent (id) | Owner team | Model | Status | Created (UTC) | Base | Requests 7 days | Cost 7 days |
|---|---|---|---|---|---|---|---|
| Claims Intake Assistant (1) | Claims Operations | claude-sonnet-4-5 | active | 2026-09-01 09:00 | 4,000 | 25,000 | $300.00 |
| Underwriting Risk Summariser (2) | Commercial Underwriting | claude-sonnet-4-5 | active | 2026-09-02 09:00 | 3,000 | 18,750 | $225.00 |
| Policy Q&A Assistant (3) | Customer Service | claude-haiku-4-5 | active | 2026-09-03 09:00 | 6,000 | 37,500 | $112.50 |
| Broker Email Triage (4) | Distribution Operations | gpt-4o | active | 2026-09-04 09:00 | 2,000 | 12,500 | $125.00 |
| Fraud Signal Reviewer (5) | Special Investigations | gemini-2-5-pro | active | 2026-09-05 09:00 | 1,600 | 10,000 | $80.00 |
| Code Review Helper (6) | Engineering Enablement | claude-haiku-4-5 | active | 2026-09-06 09:00 | 2,400 | 15,000 | $45.00 |
| Contract Clause Extractor (7) | Legal Operations | gpt-4o | paused | 2026-09-07 09:00 | 0 | 0 | $0.00 |
| Reinsurance Treaty Summariser (8) | Reinsurance | claude-sonnet-4-5 | paused | 2026-09-08 09:00 | 0 | 0 | $0.00 |

| Seed model id | Name | Provider | Status | Cost per request |
|---|---|---|---|---|
| claude-haiku-4-5 | Claude Haiku 4.5 | Anthropic | approved | $0.003 |
| claude-sonnet-4-5 | Claude Sonnet 4.5 | Anthropic | approved | $0.012 |
| gemini-2-5-pro | Gemini 2.5 Pro | Google | approved | $0.008 |
| gpt-4o | GPT-4o | OpenAI | approved | $0.010 |
| llama-3-3-70b | Llama 3.3 70B | Meta | preview | $0.001 |

| Seed MCP servers | Owner team |
|---|---|
| Jira MCP (1), Confluence MCP (2), GitHub Enterprise MCP (3), Snowflake Claims Data MCP (4) | Engineering Enablement for 1–3, Claims Data Platform for 4 |

| Daily totals (end date 2026-10-17) | 11 Oct | 12 Oct | 13 Oct | 14 Oct | 15 Oct | 16 Oct | 17 Oct | Total |
|---|---|---|---|---|---|---|---|---|
| Requests | 11,400 | 19,000 | 19,950 | 20,900 | 19,000 | 18,050 | 10,450 | 118,750 |
| Cost | $85.20 | $142.00 | $149.10 | $156.20 | $142.00 | $134.90 | $78.10 | $887.50 |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Time to produce the monthly AI inventory figures | about 2 days by hand | under 5 minutes | AI governance group's monthly reporting log |
| Dashboard loads per week | 0 | 600 by the end of the first month | count of GET /api/dashboard/summary lines in the API request log |

## Part B — Technical (owner: Tech lead)

### 8. Current system

N/A — new project.

### 9. New project setup

The nextjs-fastapi preset scaffold: the FastAPI service in `api/` and the Next.js app in `web/`. API files:
`app/main.py` (create_app, CORS), `app/settings.py` (`APP_DATABASE_URL`, default `sqlite:///./data/portal.db`;
`APP_CORS_ORIGINS`, default `["http://localhost:3000"]`), `app/db.py`, `app/clock.py`, `app/models.py` (SQLAlchemy:
Agent, McpServer, Model, UsageDaily), `app/schemas.py` (Pydantic), `app/routes/{dashboard,usage,agents,models}.py`,
`app/seed.py`, and `alembic/versions/0001_initial.py`. Web files: `app/layout.tsx` (shell), `app/page.tsx`
(Dashboard, client component), `components/{Header,Sidebar,KpiCard,UsageChart,TopAgentsTable,StateMessage}.tsx`,
`lib/api.ts` (every fetch, base `NEXT_PUBLIC_API_URL`, default `http://localhost:8000`, `cache: "no-store"`),
`lib/format.ts` and `app/globals.css` (tokens). Scripts as in the scaffold plus `cd api && alembic upgrade head`
and `cd api && python -m app.seed`. The README explains running the API on :8000 and the web app on :3000.

## UI add-on (owner: Tech lead with UX)

### U1. Design system and assets

| Item | Value |
|---|---|
| Design system | AIG AI Ecosystem tokens (light): header #001871, header text #ffffff, primary and bars #1352de, page #f3f5fa, surface #ffffff, line #e4e9f2, text #0b1533, muted #56637e, active nav #e8effd, danger #c8352b on #fdecea |
| Figma | none: the layout is specified in U2 to U4 |
| Screenshots | none |
| New tokens or components | KpiCard, UsageChart (inline SVG, no chart library), TopAgentsTable, StateMessage |

### U2. Screens

| Screen | Route or location | Purpose | Main actions |
|---|---|---|---|
| Shell | every route | 64 px navy header with the wordmark ("AIG" bold 22 px, "AI Ecosystem Portal" 15 px) and a 240 px sidebar | navigate |
| Dashboard | / | Title "Dashboard", subtitle "Platform activity across the AIG AI Ecosystem", KPI row, chart card, top agents card | read, retry |

### U3. States

| Screen | Loading | Empty | Error | No permission |
|---|---|---|---|---|
| Dashboard | skeletons of FR-10 and the visually hidden status text "Loading dashboard…" | the two FR-12 messages; KPI cards still show 0 and $0.00 | unreachable or timeout after 10 s: "Couldn't reach the AI Ecosystem Portal API."; status ≥ 400: "The AI Ecosystem Portal API returned HTTP <status>."; both with Retry | not applicable: no sign-in in this release |

### U4. Responsive layout and accessibility

| Item | Value |
|---|---|
| Breakpoints | 1280 px and up: five KPI cards in one row; 768–1279 px: three per row; below 768 px: one per row and the sidebar becomes a row of links under the header; the chart scales with its viewBox and the table scrolls sideways inside its card |
| Accessibility level | WCAG 2.2 AA |
| Keyboard and screen reader | skip link "Skip to content"; landmarks header, nav (aria-label "Main"), main; status and error text in a `role="status"` `aria-live="polite"` region; the chart SVG has role="img" and aria-label "Requests, last 7 days: highest 20,900 on 14 Oct" built from the data, plus a visually hidden table of Date, Requests and Cost; 2 px #1352de focus ring |
| Browsers | latest Chrome, Edge, Safari and Firefox |

### U5. Content and localisation

| Item | Value |
|---|---|
| Languages | English (US) |
| Formats | counts with en-US grouping (10,450); money in US dollars with 2 decimals, rounded half up ($887.50); chart dates as 11 Oct |

### U6. Analytics

N/A — no analytics in this release.

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| GET | /health | anyone on the network | none | 200 `{"status": "ok", "environment": "<APP_ENVIRONMENT>"}` |
| GET | /api/dashboard/summary | anyone on the network | none | 200 the six fields of FR-1 |
| GET | /api/usage | anyone on the network | days int 1–30, default 7 | 200 the usage response of section 6 |
| GET | /api/agents | anyone on the network | none | 200 `{items, total}` of agent items |
| GET | /api/models | anyone on the network | none | 200 `{items}` of model items |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| days missing a number, below 1 or above 30 | 422 | FastAPI validation error list for `days` |
| unknown path | 404 | `{"detail": "Not Found"}` |
| database file missing or locked | 503 | `{"detail": "database unavailable"}` |

### B3. Authorisation

None in this release: the API is reachable only on the AIG network and all endpoints are read-only. CORS allows only
the origins in `APP_CORS_ORIGINS` (default `http://localhost:3000`) and only the GET method.

### B4. Compatibility and versioning

N/A — new API with two consumers from launch: the portal web app and the VS Code extension of AIGAE-101. From this
release fields are only added, never renamed or removed, without a new path.

### B5. Limits and performance

| Item | Value |
|---|---|
| Rate limit | none in this release: internal read-only API |
| Pagination | none: GET /api/agents returns every agent (expected under 500) |
| Payload size | GET only; responses under 200 KB with 500 agents |

### B6. Events and messages

N/A — no events or queues.

## Data add-on (owner: Tech lead with the data owner)

### D1. Entities and schema changes

| Table or entity | Change | Columns (type, null, default) | Indexes and constraints |
|---|---|---|---|
| models | add | id TEXT not null; name TEXT not null; provider TEXT not null; status TEXT not null; cost_per_request_usd NUMERIC(10,4) not null | primary key id; unique name; check status in (approved, preview) |
| agents | add | id INTEGER not null autoincrement; name TEXT not null; owner_team TEXT not null; model_id TEXT not null; status TEXT not null; created_at TIMESTAMP not null | primary key id; unique name; foreign key model_id → models.id; check status in (active, paused) |
| mcp_servers | add | id INTEGER not null autoincrement; name TEXT not null; owner_team TEXT not null; created_at TIMESTAMP not null | primary key id; unique name |
| usage_daily | add | day DATE not null; agent_id INTEGER not null; requests INTEGER not null default 0; cost_cents INTEGER not null default 0 | primary key (day, agent_id); foreign key agent_id → agents.id; index on day; check requests ≥ 0 and cost_cents ≥ 0 |

### D2. Migration and backfill

Alembic revision 0001_initial creates the four tables; `alembic upgrade head` runs before the API starts in every
environment and takes under 1 second. There is no backfill: the seed script (FR-5) fills the pilot environment once
and every test database; production usage rows come from the platform's usage feed in a later change.

### D3. Rollback

`alembic downgrade base` drops the four tables. No production data exists before this release; seed data is
recreated with `python -m app.seed`. The SQLite file is copied to backup storage nightly.

### D4. Retention and volumes

| Item | Value |
|---|---|
| Rows today and growth | 17 seed rows plus 42 usage rows; about one usage row per active agent per day (+200 a month) |
| Retention | usage rows kept 13 months for year-over-year AI inventory reporting |
| Deletion or archival | none in this release: volumes stay under 3,000 usage rows in 13 months; a pruning job is planned with the usage feed |
| Personal data columns | none: owner_team holds team names, not people |

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | Each GET endpoint | p95 at most 200 ms with 500 agents and 13 months of usage rows |
| NFR-2 | Performance | Dashboard fully rendered after opening / | under 2 seconds on the AIG network |
| NFR-3 | Accessibility | Dashboard in every state | WCAG 2.2 AA, 0 axe violations |
| NFR-4 | Observability | Request logging | one JSON log line per request with method, path, status and duration in ms |
| NFR-5 | Availability | Pilot service | 99.5 % monthly during business hours (07:00–19:00 ET) |

### 11. Data and privacy

The store holds agent, model and MCP server names, owner team names, and daily request and cost totals, all Internal.
There is no personal data: owners are recorded as teams, and no prompts or model outputs are stored. Logs carry no
request bodies. The SQLite file sits on the service's encrypted volume.

### 12. Compliance

| Regime | Obligation | How this change meets it |
|---|---|---|
| NAIC AI bulletin | Insurers maintain an inventory of AI systems in use and monitor their use as part of their AI governance program | the agents, models and MCP servers tables form the inventory; the dashboard and GET endpoints give the governance group current counts and 7-day usage and cost per agent |

### 13. Rollout and compatibility

No feature flag. Deployment order: run the migration, start the API, then the web app; the seed runs once in the
pilot environment. Released to the AI governance group and platform owners first, then announced to all engineers
with the VS Code extension (AIGAE-101). Rollback is redeploying the previous build and `alembic downgrade base`. The
VS Code extension team is told of any response change.

### 14. Test expectations

API: pytest (`cd api && pytest -q`) with FastAPI's TestClient on a fresh temporary SQLite file per test, migrated,
seeded with `--end-date 2026-10-17` and the clock overridden to 2026-10-17 09:42 UTC; covers every endpoint, AS-1 to
AS-8, /health, the 422 cases and a CORS preflight from http://localhost:3000 (allowed) and https://example.com
(refused). Web: vitest with Testing Library (`cd web && npm test`) with `lib/api.ts` mocked for the formats, chart
bars, table order and every U3 state; Playwright (`cd web && npx playwright test`) against the built app and the
seeded API for AS-9 to AS-14 with an axe check on the loaded, empty and error states. Test data is the seed data only.

### 15. Increments

N/A — one increment of 12 requirements.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Dependency | Pilot environment with a persistent encrypted volume for the SQLite file | Vinod Kumar |
| Assumption | SQLite is enough for the pilot; SQLAlchemy keeps a later move to the preset's Postgres a configuration change | Vinod Kumar |
| Question | When the platform usage feed replaces seeded usage rows in production | Raj Patel |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Raj Patel | 17 Oct 2026 |
| Tech lead | Vinod Kumar | 17 Oct 2026 |
