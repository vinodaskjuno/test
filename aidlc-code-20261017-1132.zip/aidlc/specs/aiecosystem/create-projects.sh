#!/usr/bin/env bash
# Creates the empty repositories and AIDLC projects the AI Ecosystem specs need: specs 1, 2 and 4 start new projects;
# spec 3 enhances the portal spec 2 builds, so it needs no project of its own.
# Safe to re-run: existing repositories and projects are skipped. Needs the API on :8000 (./test-platform.sh starts it).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
REMOTES="$ROOT/var/local/repos/remotes"
API="${AIDLC_API_URL:-http://localhost:8000}"
AUTH="Authorization: Bearer dev:admin@acme.test"
TEAM_ID="${TEAM_ID:-487136a3b95c}"

create() {
  local project="$1" name="$2" repo="$3" preset="$4" title="$5" budget="$6"
  local bare="$REMOTES/$repo.git"
  if [[ -e "$bare" ]]; then
    echo "repo exists: $bare"
  else
    local seed
    seed="$(mktemp -d)"
    git -C "$seed" init -q -b main
    printf '# %s\n\nBuilt by AIDLC.\n' "$title" > "$seed/README.md"
    printf 'node_modules/\ndist/\ncoverage/\n*.tsbuildinfo\n.venv/\n__pycache__/\n*.egg-info/\n*.db\n*.vsix\n.next/\n.DS_Store\n' \
      > "$seed/.gitignore"
    git -C "$seed" add -A
    git -C "$seed" -c user.name=AIDLC -c user.email=aidlc@local commit -qm "Initial commit"
    git clone -q --bare "$seed" "$bare"
    echo "created repo: $bare"
  fi

  local code
  code=$(curl -s -o /dev/null -w '%{http_code}' "$API/api/v1/projects/$project" -H "$AUTH")
  if [[ "$code" == "200" ]]; then
    echo "project exists: $project"
    return
  fi
  curl -sf -X POST "$API/api/v1/projects" -H "$AUTH" -H "Content-Type: application/json" -d @- >/dev/null <<JSON
{"id": "$project", "name": "$name", "team_id": "$TEAM_ID",
 "config": {"stack_preset": "$preset",
            "repos": [{"id": "app", "url": "$bare", "primary": true, "integration_branch": "main"}],
            "budgets": {"run_usd": $budget, "agent_usd_default": 3.0}}}
JSON
  echo "created project: $project"
}

create aig-ecosystem-vscode "AIG AI Ecosystem VS Code extension" aig-ecosystem-vscode vscode-extension \
  "AIG AI Ecosystem for VS Code" 45
create aig-ecosystem-portal "AIG AI Ecosystem Portal" aig-ecosystem-portal nextjs-fastapi "AIG AI Ecosystem Portal" 45
create aig-model-catalogue "AIG Model Catalogue" aig-model-catalogue vite-react "AIG Model Catalogue" 20
