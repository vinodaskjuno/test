# AIG AI Ecosystem Console: UI prototype with mock data

| | |
|---|---|
| Component | `aiecosystem-ui` (a standalone React single-page app) |
| Purpose | A clickable prototype of the AIG AI Ecosystem web console: header, sidebar and seven screens with animations, running entirely on mock data |
| Audience | AIG product owners and developers reviewing the console's layout, navigation and motion before the backend is wired in |
| Requirement ids | `FR-…` and `NFR-…` ids are stable and are used by the acceptance scenarios in section 10 |

Where the spec says MUST, the build fails acceptance if the behaviour is missing.

## 1. Goals and non-goals

Goals:

- One shell (header, sidebar, content area) shared by every screen, in the AIG visual style (section 3).
- Seven screens reachable from the sidebar: Overview, Usage & Cost, Agents, Runs, Evals, Model Routing and Settings, plus an agent detail drawer, a run detail page and a not-found page.
- Purposeful motion: page transitions, staggered lists, animated KPI numbers, a chart that draws in, a sliding drawer and a collapsing sidebar.
- Every screen loads its data from an in-app mock service with simulated latency, so loading, empty and error states can be shown.

Non-goals (out of scope):

- No backend, no network calls, no authentication. "Sign out" only shows a confirmation toast.
- No real-time updates other than the simulated run progress described in FR-RUNS-2.
- No internationalisation: all copy is English.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Language | TypeScript 5.5+ with `strict: true` |
| Framework | React 18.3, built with Vite 5 (`npm create vite` React + TypeScript layout) |
| Routing | `react-router-dom` 6 with browser history; the routes are listed in FR-NAV-1 |
| Animation | `framer-motion` 11. No other animation library |
| Styling | Plain CSS files with CSS custom properties for every token in section 3. No CSS framework and no component library |
| Charts | Hand-written inline SVG. No chart library |
| Icons | Inline SVG components in `src/components/icons/`, 20×20, `stroke="currentColor"`, stroke width 1.75 |
| Runtime dependencies | Only `react`, `react-dom`, `react-router-dom` and `framer-motion` |
| Tests | `vitest` 2 with `jsdom`, `@testing-library/react` and `@testing-library/user-event`; test files in `src/**/*.test.tsx` |
| Scripts | `npm run dev`, `npm run build` (type-check then Vite build), `npm run preview`, `npm test` (`vitest run`), `npm run typecheck` (`tsc --noEmit`) |
| Node | Node 22 / npm 10; `package-lock.json` committed |

## 3. AIG visual style (FR-STYLE)

FR-STYLE-1. The app MUST define these tokens as CSS custom properties on `:root` (light theme) and on `[data-theme="dark"]`, and use them for every colour, font, radius, spacing, shadow and duration. Solid colours only: no gradients anywhere.

| Token | Light | Dark |
|---|---|---|
| `--bg` | `#f3f5fa` | `#000000` |
| `--surface` | `#ffffff` | `#0e0e11` |
| `--surface-2` | `#f5f7fc` | `#16161b` |
| `--line` | `#e4e9f2` | `#24242b` |
| `--ink` | `#0b1533` | `#f2f3f7` |
| `--muted` | `#56637e` | `#a3a6b3` |
| `--header` | `#001871` | `#000000` |
| `--header-ink` | `#ffffff` | `#ffffff` |
| `--nav-bg` | `#ffffff` | `#07070a` |
| `--nav-active` | `#e8effd` | `#15192a` |
| `--primary` | `#1352de` | `#6e9bff` |
| `--primary-ink` | `#ffffff` | `#000000` |
| `--primary-hover` | `#0d3fb0` | `#9bb8ff` |
| `--focus` | `#1352de` | `#6e9bff` |
| `--ok` / `--ok-bg` | `#0a7458` / `#e3f5ef` | `#4dd29a` / `#0b2219` |
| `--warn` / `--warn-bg` | `#b26b00` / `#fff3dc` | `#f5c451` / `#2a210a` |
| `--danger` / `--danger-bg` | `#c8352b` / `#fdecea` | `#ff6b5e` / `#2a0f0d` |
| `--c1` … `--c6` (chart series) | `#1352de` `#00a4e4` `#14a37f` `#f2a900` `#e5484d` `#7c5cff` | `#6e9bff` `#33b6ea` `#4dd29a` `#f5c451` `#fd838e` `#a894ff` |

FR-STYLE-2. Fonts: headings `"AIG Futura","Futura PT","Inter Variable",Inter,system-ui,sans-serif`; body `"Inter Variable",Inter,"Source Sans 3",system-ui,sans-serif`; numbers and ids `"JetBrains Mono Variable","JetBrains Mono",ui-monospace,Menlo,monospace`. No web fonts are downloaded; the stacks fall back to installed fonts.

FR-STYLE-3. Radius `6px` for buttons and inputs, `10px` for cards, `999px` for pills. Spacing scale 4, 8, 12, 16, 20, 24, 32 and 40 px. Card shadow `0 1px 2px rgba(11,21,51,.06),0 1px 3px rgba(11,21,51,.04)`; card hover shadow `0 14px 32px -12px rgba(11,21,51,.22),0 2px 6px rgba(11,21,51,.06)`.

FR-STYLE-4. Motion tokens: easing `cubic-bezier(.2,.8,.2,1)`, fast `150ms`, base `300ms`, slow `900ms`, list stagger `50ms`.

FR-STYLE-5. Layout: header height `60px`, sidebar width `248px` expanded and `68px` collapsed, page content max width `1360px`.

## 4. App shell (FR-SHELL)

FR-SHELL-1. Header (fixed, full width, background `--header`, text `--header-ink`), left to right:
1. The wordmark: "AIG" in the heading font, bold, 22px, followed by "AI Ecosystem" in the body font, 15px. Clicking it navigates to `/`.
2. An environment pill with the text `DEV` (background `--warn-bg`, text `--warn`).
3. A search field with the placeholder "Search agents" (width 320px). Pressing Enter navigates to `/agents?q=<text>`.
4. A notifications button (bell icon, `aria-label="Notifications"`) with a badge showing the number of unread notifications (3 in the mock data). Clicking it opens a panel listing the 5 notifications of section 7 (newest first); opening the panel marks all as read and the badge disappears. Escape or a click outside closes it.
5. A theme toggle button (`aria-label="Toggle theme"`) that switches between light and dark (FR-SET-1).
6. The user menu: a 32px round avatar showing the initials "AM". Clicking it opens a menu with the name "Alex Morgan", the role "Platform engineer" and the items "Settings" (navigates to `/settings`) and "Sign out" (shows the toast "Signed out (prototype only)" for 3 seconds).

FR-SHELL-2. Sidebar (background `--nav-bg`, right border `--line`), with one item per route of FR-NAV-1 (icon and label), in that order. The item for the current route has background `--nav-active`, text `--primary` and a 3px left bar in `--primary`. At the bottom, a collapse button (`aria-label="Collapse sidebar"` / `"Expand sidebar"`) toggles between 248px (icons and labels) and 68px (icons only, the label shown as a tooltip on hover and focus). The collapsed state is stored in `localStorage` under `aig.sidebar.collapsed` and restored on load.

FR-SHELL-3. Content area: the current screen's title (heading font, 28px) and a one-line subtitle (muted), then the screen content, centred with max width 1360px and 24px padding.

FR-SHELL-4. Responsive: below 1024px wide the sidebar is always collapsed (68px). Below 640px it is hidden and a menu button (`aria-label="Open navigation"`) appears at the left of the header; it opens the sidebar as an overlay drawer that closes on navigation, on Escape and on a click on the backdrop.

FR-SHELL-5. A toast area at the bottom right shows one toast at a time; a toast disappears after 3 seconds or when its close button is pressed.

## 5. Navigation (FR-NAV)

FR-NAV-1. Routes, in sidebar order:

| Route | Sidebar label | Screen title | Subtitle |
|---|---|---|---|
| `/` | Overview | Overview | Your AI platform at a glance |
| `/usage` | Usage & Cost | Usage & Cost | Tokens and spend by model and team |
| `/agents` | Agents | Agents | Registered agents and their status |
| `/runs` | Runs | Runs | Agent invocations across the platform |
| `/evals` | Evals | Evals | Evaluation suites and their latest results |
| `/routing` | Model Routing | Model Routing | Which model serves each tier and job profile |
| `/settings` | Settings | Settings | Appearance and profile |

Detail routes: `/agents/:agentId` (the Agents screen with the agent drawer open) and `/runs/:runId` (run detail). Any other path shows the not-found screen (FR-NAV-3).

FR-NAV-2. Page transitions: when the route changes, the outgoing screen fades out (opacity 1 → 0, 150ms) and the incoming screen fades in and rises (opacity 0 → 1 and translateY 8px → 0, 300ms, the AIG easing).

FR-NAV-3. Not-found screen: title "Page not found", the text "We couldn't find `<path>`." with the requested path, and a primary button "Back to Overview" that navigates to `/`.

## 6. Screens

### 6.1 Overview (FR-OVR)

FR-OVR-1. Four KPI cards in one row (two per row below 1024px, one below 640px): "Tokens today" `1,284,500`; "Cost month to date" `$4,812.40`; "Active agents" `6`; "Run success rate (7 days)" `96.4%`. Each value counts up from 0 to its final value over 900ms when the screen first shows its data; the formatted final value matches the text above exactly.

FR-OVR-2. A "Token usage, last 30 days" card with an SVG line chart of the 30 daily totals of section 7 (series colour `--c1`, a light area fill of the same colour at 12% opacity, horizontal grid lines in `--line`, x-axis labels every 5 days in the format `14 Oct`, y-axis labels in millions with one decimal followed by `M`, the format `1.2M`). The line draws in from left to right over 900ms (SVG `pathLength` 0 → 1). Hovering or focusing a point shows a tooltip with the date (`14 Oct`) and the value with thousands separators.

FR-OVR-3. A "Recent runs" card listing the 5 most recent runs of section 7 (agent name, status pill, duration, relative start time computed from the mock "now" of section 7: `<n> min ago` below 60 minutes, `<n> h ago` from 60 minutes to below 48 hours). Rows enter with a 50ms stagger. Clicking a row navigates to `/runs/:runId`. A "View all runs" link navigates to `/runs`.

### 6.2 Usage & Cost (FR-USE)

FR-USE-1. A range selector with three segments "7 days", "30 days" (default) and "90 days". Changing it reloads the screen's data (with the loading state of FR-DATA-3) for that range.

FR-USE-2. A stacked bar chart of daily cost by model for the selected range, one bar per day, the four models of section 7 stacked in their series colours `--c1` to `--c4`, with a legend. Bars grow upward from 0 over 300ms with a 50ms stagger.

FR-USE-3. A budget meter: "Monthly budget" `$4,812.40 of $8,000.00` with a horizontal bar filled to 60.2% in `--primary` (fill animates from 0 over 900ms); the bar turns `--warn` at 80% and above and `--danger` at 100% and above.

FR-USE-4. A table "Spend by team" with the columns Team, Tokens, Cost and Share, one row per team of section 7, sorted by Cost descending. Clicking a column header sorts by that column; clicking it again reverses the order; the active column shows an arrow.

### 6.3 Agents (FR-AGT)

FR-AGT-1. A filter bar: a search field (placeholder "Filter by name or owner", pre-filled from `?q=`), a "Framework" select (All, LangGraph, CrewAI, Custom) and a "Status" select (All, Active, Draft, Deprecated). Filters combine; the search matches name or owner, case-insensitive, as a substring.

FR-AGT-2. A responsive grid of agent cards (3 columns, 2 below 1024px, 1 below 640px), one per agent of section 7: name, one-line description, framework, owner, a status pill (Active `--ok`, Draft `--warn`, Deprecated `--muted`) and "Runs (7 days)". Cards enter with a 50ms stagger and lift on hover (translateY −2px and the hover shadow, 150ms).

FR-AGT-3. When no agent matches the filters, the grid is replaced by the empty state "No agents match these filters" with a "Clear filters" button that resets all three filters.

FR-AGT-4. Clicking a card navigates to `/agents/:agentId` and opens a drawer that slides in from the right (width 480px, full width below 640px, 300ms, over a backdrop that fades to 40% black). The drawer shows the agent's name, status, framework, owner, version, created date, description and its 5 most recent runs (each linking to `/runs/:runId`). Escape, the close button (`aria-label="Close"`) or a click on the backdrop closes it and navigates back to `/agents` (keeping the query string). Focus moves into the drawer when it opens and returns to the card when it closes.

FR-AGT-5. `/agents/:agentId` with an id not in the mock data opens the drawer with the text "Agent not found" and a "Back to Agents" button.

### 6.4 Runs (FR-RUNS)

FR-RUNS-1. A table of all 12 runs of section 7 with the columns Run (id in mono font), Agent, Status (pill), Started (relative), Duration and Tokens, newest first, and status filter chips "All", "Running", "Succeeded", "Failed" above it. Clicking a row navigates to `/runs/:runId`.

FR-RUNS-2. The run with status Running shows a progress bar in its Status cell that advances from its mock progress (35%) by 5 percentage points every 2 seconds while the Runs screen is open, stopping at 95%. Its status pill pulses (opacity 1 → 0.6 → 1, 1.2s loop).

FR-RUNS-3. Run detail (`/runs/:runId`): a header with the run id, agent name, status pill and a "Back to Runs" link; a summary row (Started, Duration, Tokens, Cost, Model); and a vertical timeline of the run's steps of section 7 (step name, duration, status dot), the steps revealing top to bottom with a 50ms stagger. A failed run shows its error message in a `--danger-bg` box above the timeline.

FR-RUNS-4. `/runs/:runId` with an unknown id shows "Run not found" and a "Back to Runs" button.

### 6.5 Evals (FR-EVAL)

FR-EVAL-1. A list of the 4 eval suites of section 7, each a card with the suite name, the agent it evaluates, the last run date, the number of cases, and a pass-rate bar (fill animates from 0 over 900ms; `--ok` at 90% and above, `--warn` from 70% to below 90%, `--danger` below 70%) with the percentage to one decimal.

FR-EVAL-2. Clicking a suite card expands it in place (height animates over 300ms) to show its 5 most recent results (case name and pass or fail); clicking it again collapses it. Only one card is expanded at a time.

### 6.6 Model Routing (FR-RTE)

FR-RTE-1. A table with the columns Tier, Job profile, Model and Fallback model, one row per route of section 7.

FR-RTE-2. A "Test routing" card with a "Job profile" select (the job profiles of section 7) and a primary button "Test". Pressing Test shows a spinner on the button for 600ms, then the result line `Routing: <model> · <tier> · <job profile> — <latency> ms` for the selected profile's route, using the mock latency of section 7. The result line fades in over 150ms.

### 6.7 Settings (FR-SET)

FR-SET-1. Appearance: a segmented control "Light", "Dark", "System" (default "System"). Light and Dark set `data-theme` on the root element; System follows `prefers-color-scheme`. The choice is stored in `localStorage` under `aig.theme` and restored on load. The header toggle (FR-SHELL-1) switches between Light and Dark and updates this control.

FR-SET-2. Motion: a switch "Reduce motion" (default off). When on, or when the operating system reports `prefers-reduced-motion: reduce`, every animation in this spec is replaced by an instant change (no transforms; opacity changes only, at 0ms). Stored in `localStorage` under `aig.reduceMotion`.

FR-SET-3. Profile: read-only fields Name "Alex Morgan", Email "alex.morgan@aig.example", Team "Platform", Role "Platform engineer".

## 7. Mock data and service (FR-DATA)

FR-DATA-1. All data comes from `src/mocks/` through an async service module `src/mocks/service.ts` (one function per screen) that resolves after 400ms. The mock "now" is `2026-10-15T10:00:00Z`; relative times are computed from it, never from the system clock.

FR-DATA-2. Data set:
- Daily token totals for the last 90 days, day `d` = 0 for the oldest: `tokens(d) = 900000 + 6000·d + 40000·(d mod 7)`. The Overview chart shows the last 30 values. Daily cost by model: `cost(d) = tokens(d) / 1000 × 0.0036`, split 45% GPT-4o, 30% Claude Sonnet, 15% Gemini Pro and 10% Llama 3, rounded to cents.
- Teams (tokens, cost): Platform (14,200,000, $1,840.20), Claims (9,800,000, $1,270.10), Underwriting (7,400,000, $958.30), Finance (5,700,000, $743.80).
- Agents (name, framework, status, owner, runs in 7 days): Claims Triage (LangGraph, Active, Priya Shah, 412); Policy Q&A (LangGraph, Active, Alex Morgan, 1,208); Underwriting Assistant (CrewAI, Active, Daniel Kim, 336); Fraud Signals (Custom, Active, Maria Lopez, 97); Broker Email Drafts (CrewAI, Active, Tom Becker, 254); Risk Summary (LangGraph, Active, Priya Shah, 61); Renewal Nudges (Custom, Draft, Daniel Kim, 0); Legacy FAQ Bot (Custom, Deprecated, Tom Becker, 3). Each has id `agt-01` … `agt-08` in this order and version `1.<n>.0` with n its position. Its created date (a date in 2026) and one-line description are free text chosen by the implementer; tests assert only that they are shown.
- Runs: 12 runs `run-1001` … `run-1012` spread over the agents above with start times within the 48 hours before the mock now; `run-1012` (Policy Q&A) is Running at 35% progress, `run-1009` and `run-1004` are Failed (errors "Tool timeout after 30s" and "Model returned an invalid JSON response"), all others Succeeded. The other runs' agents and start times, and every run's steps (3 to 6, each with a name, duration and status), tokens, cost and model are chosen by the implementer within these rules; tests assert the ids, statuses, counts and the values named here.
- Eval suites (agent, cases, pass rate): Claims triage regression (Claims Triage, 120, 95.8%); Policy answers golden set (Policy Q&A, 250, 91.2%); Underwriting extraction (Underwriting Assistant, 80, 76.3%); Fraud signal precision (Fraud Signals, 60, 63.3%).
- Routes (tier, job profile, model, fallback, latency ms): Premium / `analysis` / GPT-4o / Claude Sonnet / 820; Standard / `chat` / Claude Sonnet / GPT-4o mini / 540; Standard / `summarise` / Gemini Pro / Claude Sonnet / 610; Economy / `classify` / Llama 3 / GPT-4o mini / 230.
- Notifications (5, the newest 3 unread): "run-1009 failed: Tool timeout after 30s"; "Monthly spend passed 60% of budget"; "Renewal Nudges saved as draft"; "Eval Fraud signal precision dropped below 70%"; "New model available: GPT-4o mini".

FR-DATA-3. Loading state: while a service call is pending, each card or table shows skeleton blocks of its final size with a shimmer (a lighter band moving left to right, 1.2s loop; a static block when motion is reduced).

FR-DATA-4. Error state: when the page URL has `?mock=error`, the first service call of each card or table rejects. That card or table then shows "Couldn't load this data." and a "Retry" button; Retry calls the service again, and that second call resolves with the normal data.

FR-DATA-5. Empty state: when the page URL has `?mock=empty`, every list and table resolves with no items and shows its empty message: Overview recent runs "No runs yet"; Agents FR-AGT-3; Runs "No runs match this filter"; Evals "No eval suites yet"; Usage "No usage for this period"; Routing "No routes configured".

## 8. Accessibility (NFR-A11Y)

- NFR-A11Y-1. WCAG 2.2 AA contrast for all text in both themes (the token pairs of section 3 meet it).
- NFR-A11Y-2. Every interactive element is reachable and operable by keyboard in visual order, with a visible focus ring (2px `--focus` outline, 2px offset).
- NFR-A11Y-3. Landmarks: `header`, `nav` (labelled "Main"), `main`; the sidebar items are links with `aria-current="page"` on the active one; the drawer and menus are dialogs or menus with the matching ARIA roles and trap focus while open.
- NFR-A11Y-4. Charts have a text alternative: a visually hidden table of the plotted values.

## 9. Performance (NFR-PERF)

- NFR-PERF-1. `npm run build` output: the main JavaScript bundle is at most 250 KB gzipped.
- NFR-PERF-2. Animations use only `transform` and `opacity` (plus SVG `pathLength` and the bar/meter widths of FR-USE-3 and FR-EVAL-1).

## 10. Verification

### 10.1 Automated tests (MUST pass)

| Area | Test file |
|---|---|
| Shell: header items, sidebar items and active state, collapse persisted, notifications badge and panel, user menu and sign-out toast | `src/shell/Shell.test.tsx` |
| Routing: each route renders its title, unknown path shows the not-found screen | `src/routes.test.tsx` |
| Overview KPIs and recent runs | `src/screens/Overview.test.tsx` |
| Usage range, budget meter colours, team table sorting | `src/screens/Usage.test.tsx` |
| Agents filters, empty state, drawer open/close, unknown agent | `src/screens/Agents.test.tsx` |
| Runs table, filter chips, run detail, unknown run | `src/screens/Runs.test.tsx` |
| Evals pass-rate colours and expand/collapse | `src/screens/Evals.test.tsx` |
| Routing table and Test result line | `src/screens/Routing.test.tsx` |
| Theme and reduce-motion persistence | `src/screens/Settings.test.tsx` |
| Mock service: formulas, counts, latency, `?mock=error` and `?mock=empty` | `src/mocks/service.test.ts` |

`npm run typecheck` MUST be clean and `npm run build` MUST succeed.

### 10.2 Acceptance scenarios

| # | Scenario | Expected |
|---|---|---|
| S1 | Open `/` | Header, sidebar with Overview active, four KPI cards counting up to the values of FR-OVR-1, the chart drawing in, five recent runs |
| S2 | Collapse the sidebar and reload | Sidebar stays at 68px with icons only |
| S3 | Search "claims" in the header | `/agents?q=claims` shows only Claims Triage |
| S4 | Open Policy Q&A, press Escape | Drawer slides in with its details, then closes back to `/agents` |
| S5 | Open `/runs` and wait 4 seconds | `run-1012` progress moves from 35% to 45% |
| S6 | Toggle the theme | Colours switch to the dark tokens; the choice survives a reload |
| S7 | Open `/usage?mock=error`, press Retry on the chart | The error message shows, then the chart loads |
| S8 | Open `/nowhere` | "Page not found" with "Back to Overview" |
| S9 | Turn on Reduce motion and change page | The new screen appears without a transition |
