# Storefront: order count by status

## Spec details

| Field | Value |
|---|---|
| Template | aidlc-spec/1 · backend |
| Title | Orders API order count by status |
| Project | existing |
| Project id | storefront |
| Repositories | storefront |
| Surfaces | backend |
| Stack preset | nextjs-fastapi |
| Stack exceptions | none |
| Jira | SHOP-301 |
| Priority | P3 |
| Target release | 2026.11 |
| Business sponsor | Grace Lin |
| Product owner | Tom Hale |
| Tech lead | Ana Costa |
| Data classification | Internal |
| PII categories | none |
| Compliance regimes | none |
| Risk tier | low |
| Run budget (USD) | 10 |

## Part A — Business (owner: Product / BA)

### 1. Problem and outcome

The fulfilment dashboard needs to know how many orders are in each status. Today it downloads every order with
GET /orders and counts them itself, which gets slower as orders grow. A small endpoint that returns the counts
directly lets the dashboard show them with one cheap call.

### 2. Users and roles

| Role | Who they are | What they can do in this change |
|---|---|---|
| Fulfilment dashboard | The internal service that shows order counts | Read the order count by status |

### 3. Scope

**In scope**

- GET /orders/summary returning the number of orders in each status and the total.

**Out of scope**

- Filtering by date or customer, caching, and any change to the web app.

### 4. Functional requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-1 | GET /orders/summary returns 200 with {"total": <n>, "by_status": {"pending": <n>, "paid": <n>, "shipped": <n>, "cancelled": <n>}} counting every stored order | Must |
| FR-2 | Every one of the four statuses is always present in by_status, with 0 when no order has that status | Must |

### 5. Acceptance scenarios

| ID | FR | Given | When | Then |
|---|---|---|---|---|
| AS-1 | FR-1 | 3 pending orders and 1 paid order are stored | a client calls GET /orders/summary | 200 with {"total": 4, "by_status": {"pending": 3, "paid": 1, "shipped": 0, "cancelled": 0}} |
| AS-2 | FR-2 | no orders are stored | a client calls GET /orders/summary | 200 with {"total": 0, "by_status": {"pending": 0, "paid": 0, "shipped": 0, "cancelled": 0}} |
| AS-3 | FR-1 | the summary route is added | a client calls GET /orders/1 for an existing order | the order is still returned: /orders/summary does not shadow /orders/{order_id} |

### 6. Business rules and data

| Rule | Detail |
|---|---|
| Statuses | pending, paid, shipped and cancelled, in that order in the response |

### 7. Success metrics

| Metric | Today | Target | How it is measured |
|---|---|---|---|
| Dashboard calls to load the counts | 1 call returning every order | 1 call returning 5 numbers | dashboard request log |

## Part B — Technical (owner: Tech lead)

### 8. Current system

The FastAPI service in api/: api/app/routes/orders.py has GET /orders, GET /orders/{order_id} and POST /orders;
api/app/repository.py stores orders in SQLite through sqlite3 behind a lock; api/app/models.py defines
OrderStatus as pending, paid, shipped or cancelled. Tests live in api/tests/test_orders.py. Existing endpoints and
their tests must keep passing unchanged.

### 9. New project setup

N/A — existing project.

## Backend / API add-on (owner: Tech lead)

### B1. Endpoints

| Method | Path | Who can call it | Request | Response |
|---|---|---|---|---|
| GET | /orders/summary | internal services | none | 200 {"total": integer, "by_status": {"pending": integer, "paid": integer, "shipped": integer, "cancelled": integer}} |

### B2. Validation and errors

| Case | Status | Message |
|---|---|---|
| any request | 200 | the endpoint takes no input, so it has no validation errors |

### B3. Authorisation

Unchanged: the service is reachable only from the internal network through the existing gateway.

### B4. Compatibility and versioning

Additive: a new endpoint; no existing response changes.

### B5. Limits and performance

| Item | Value |
|---|---|
| Query | one GROUP BY query on the orders table, not one query per status |

### B6. Events and messages

N/A — the endpoint publishes no events.

### 10. Non-functional requirements

| ID | Category | Requirement | Target |
|---|---|---|---|
| NFR-1 | Performance | Summary response time | p95 at most 50 ms with 10,000 stored orders |

### 11. Data and privacy

The endpoint returns counts only; no customer name or e-mail is read into the response or written to logs.

### 12. Compliance

N/A — no regime applies: the response holds counts only, with no personal data.

### 13. Rollout and compatibility

No flag: the endpoint is new and additive. Rollback is redeploying the previous image.

### 14. Test expectations

API tests in api/tests/test_orders.py for AS-1, AS-2 and AS-3, run with `cd api && pytest -q`, each on a fresh
temporary database.

### 15. Increments

N/A — one small increment.

### 16. Dependencies, assumptions and open questions

| Type | Item | Owner |
|---|---|---|
| Assumption | The dashboard team switches to the new endpoint in its next release | Tom Hale |

### 17. Approvals

| Role | Name | Date |
|---|---|---|
| Product owner | Tom Hale | 17 Oct 2026 |
| Tech lead | Ana Costa | 17 Oct 2026 |
