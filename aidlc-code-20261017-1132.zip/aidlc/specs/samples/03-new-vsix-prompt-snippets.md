# AIG Prompt Snippets: VS Code extension with an Activity Bar sidebar

| | |
|---|---|
| Type | New project, VS Code extension (VSIX) |
| Repository | `prompt-snippets-vscode` (empty; this work creates the extension) |
| Purpose | Keep reusable AI prompt snippets in a VS Code sidebar: add, insert at the cursor, copy and delete them |
| Requirement ids | `FR-…` and `NFR-…` ids are used by the acceptance scenarios in section 8 |

Where the spec says MUST, the build fails acceptance if the behaviour is missing.

## 1. Scope

In scope: one VS Code extension with its own Activity Bar icon, a sidebar tree view, commands, a status bar item, one setting, tests and a packaged `.vsix`. Out of scope: syncing snippets between machines, a webview, telemetry, publishing to the Marketplace.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Language | TypeScript 5.5, `strict: true` |
| VS Code | `engines.vscode` `^1.90.0`; `@types/vscode` `~1.90.0` |
| Bundle | `esbuild` 0.23: `src/extension.ts` → `dist/extension.js`, CommonJS, platform node, external `vscode` |
| Tests | `vitest` 2 with a hand-written `vscode` mock in `test/__mocks__/vscode.ts` (aliased in `vitest.config.ts`); `@types/node` 22 |
| Packaging | `@vscode/vsce` 3 in devDependencies |
| Scripts | `build` (esbuild production bundle), `watch`, `typecheck` (`tsc --noEmit`), `test` (`vitest run`), `package` (`npm run build && vsce package --no-dependencies --out dist/aig-prompt-snippets.vsix`) |
| Runtime dependencies | None |

## 3. Manifest (FR-MAN)

FR-MAN-1. `package.json`: `name` `aig-prompt-snippets`, `displayName` "AIG Prompt Snippets", `description` "Reusable AI prompt snippets in a sidebar", `publisher` `aig`, `version` `0.1.0`, `license` `UNLICENSED`, `repository` `{"type": "git", "url": "https://git.example/aig/prompt-snippets-vscode"}`, `categories` `["Snippets", "Other"]`, `main` `./dist/extension.js`.

FR-MAN-2. Activity Bar: `contributes.viewsContainers.activitybar` has one container, id `aig-snippets`, title "AIG Snippets", icon `media/aig-snippets.svg`. That file is exactly:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v11H8l-4 4z"/><path d="M8 9h8"/><path d="M8 12h5"/></svg>
```

FR-MAN-3. `contributes.views["aig-snippets"]` has one tree view, id `aigSnippets.list`, name "Prompt snippets". `contributes.viewsWelcome` for that view shows "No snippets yet." and a link "[Add snippet](command:aigSnippets.add)" when the context key `aigSnippets.empty` is true.

FR-MAN-4. Commands (titles in the Command Palette, category "AIG Snippets"): `aigSnippets.add` "Add snippet" (icon `$(add)`), `aigSnippets.insert` "Insert at cursor" (icon `$(insert)`), `aigSnippets.copy` "Copy", `aigSnippets.delete` "Delete", `aigSnippets.refresh` "Refresh" (icon `$(refresh)`). Menus: `view/title` for the view shows Add and Refresh as navigation icons; `view/item/context` shows Insert inline, and Copy and Delete in the context menu; Insert, Copy and Delete are hidden from the Command Palette (`"when": "false"` under `commandPalette`).

FR-MAN-5. Setting `aigSnippets.insertTrailingNewline` (boolean, default `false`, description "Add a new line after an inserted snippet").

FR-MAN-6. `.vscodeignore` excludes `src/**`, `test/**`, `node_modules/**`, `**/*.map`, `tsconfig.json`, `esbuild.mjs` and `vitest.config.ts`. `README.md` describes the features and the commands; `CHANGELOG.md` has a `0.1.0` entry.

## 4. Behaviour (FR-SNIP)

FR-SNIP-1. Storage: snippets live in `context.globalState` under `aigSnippets.items` as `{id, title, body, createdAt}` objects (`id` from `crypto.randomUUID()`, `createdAt` ISO 8601). On first activation (no stored value) the extension stores these three snippets:

| Title | Body |
|---|---|
| Explain this code | `Explain what this code does, step by step, and point out any risks.` |
| Write unit tests | `Write unit tests for this code covering normal, edge and error cases.` |
| Summarise for a ticket | `Summarise this change in three sentences for a ticket description.` |

FR-SNIP-2. Tree view: one item per snippet, sorted by title case-insensitive. Label = title; description = the body's first 40 characters on one line (line breaks as spaces), followed by `…` when longer; tooltip = the full body in a Markdown code block; icon = the codicon `symbol-snippet`. The context key `aigSnippets.empty` is true when there are no snippets.

FR-SNIP-3. Add: an input box for the title ("Snippet title", required, 1–80 characters, validation message "Enter 1 to 80 characters"), then one for the body ("Snippet text", required, 1–10,000 characters, validation message "Enter 1 to 10,000 characters"). Pressing Escape in either box cancels without saving. On success the tree refreshes and the information message `Added "<title>"` appears.

FR-SNIP-4. Insert at cursor: replaces the selection (or inserts at the cursor) in the active text editor with the body, followed by a new line when `aigSnippets.insertTrailingNewline` is true. With no active text editor it shows the error message "Open a file to insert a snippet."

FR-SNIP-5. Copy: writes the body to the clipboard and shows `Copied "<title>"`.

FR-SNIP-6. Delete: a modal warning `Delete "<title>"?` with the button "Delete"; choosing Delete removes it and refreshes the tree; dismissing keeps it.

FR-SNIP-7. Status bar: a left-aligned item with the text `$(symbol-snippet) <n> snippets` (`1 snippet` when n is 1), tooltip "Show AIG Snippets", whose command is `workbench.view.extension.aig-snippets`. It updates after every change.

FR-SNIP-8. The extension activates when the view opens or a command runs (`onView:aigSnippets.list` and the command activation events VS Code infers) and registers every disposable on `context.subscriptions`.

## 5. Code layout

`src/extension.ts` (activation and wiring), `src/store.ts` (snippet storage, no `vscode` import besides the `Memento` type), `src/tree.ts` (the tree data provider), `src/commands.ts` (command handlers), `src/format.ts` (pure helpers: description text, status bar text, validation).

## 6. Non-functional (NFR)

- NFR-1. Unit tests cover `format.ts` (truncation, plural text, validation), `store.ts` (seeding once, add, delete, sort) and each command handler with the `vscode` mock (insert with and without an editor, the trailing newline setting, delete confirmed and dismissed, add cancelled).
- NFR-2. `npm run typecheck`, `npm test` and `npm run package` succeed; `npm run package` writes `dist/aig-prompt-snippets.vsix`.
- NFR-3. A manifest test checks that every command in `contributes.commands` is registered in `extension.ts` and that `engines.vscode` matches `@types/vscode`.

## 7. Installing

`code --install-extension dist/aig-prompt-snippets.vsix` installs it; the "AIG Snippets" icon then appears in the Activity Bar.

## 8. Acceptance scenarios

| # | Scenario | Expected |
|---|---|---|
| S1 | Install the VSIX and open the AIG Snippets view | The icon is in the Activity Bar; the view lists the three seeded snippets A–Z; the status bar shows `3 snippets` |
| S2 | Add snippet "Review SQL" with a body | It appears in sorted position; `Added "Review SQL"`; status bar `4 snippets` |
| S3 | Add snippet, press Escape at the title | Nothing is added |
| S4 | Insert "Write unit tests" into an open file with text selected | The selection is replaced by the snippet body |
| S5 | Insert with no editor open | "Open a file to insert a snippet." |
| S6 | Delete a snippet and confirm | It disappears and the count drops by one |
| S7 | Delete every snippet | The welcome text "No snippets yet." with the Add snippet link |
| S8 | `npm run package` | `dist/aig-prompt-snippets.vsix` exists and installs in VS Code 1.90 or later |
