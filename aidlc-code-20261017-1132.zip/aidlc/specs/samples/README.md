# Sample specs

Five specs that exercise different AIDLC paths. Three start new projects and two change the existing `storefront`
project.

| # | Spec | Kind | Project | Run type |
|---|---|---|---|---|
| 1 | [01-new-ui-prompt-library.md](01-new-ui-prompt-library.md) | New project, React UI only (mock data) | `prompt-library` | feature |
| 2 | [02-new-ui-backend-feedback-hub.md](02-new-ui-backend-feedback-hub.md) | New project, FastAPI + React | `feedback-hub` | feature |
| 3 | [03-new-vsix-prompt-snippets.md](03-new-vsix-prompt-snippets.md) | New project, VS Code extension with an Activity Bar icon | `prompt-snippets` | feature |
| 4 | [04-existing-storefront-order-status.md](04-existing-storefront-order-status.md) | Existing project, enhancement (API + web) | `storefront` | feature |
| 5 | [05-existing-storefront-order-hang-bug.md](05-existing-storefront-order-hang-bug.md) | Existing project, bug fix (API) | `storefront` | bug |
| 6 | [06-quick-orders-summary.md](06-quick-orders-summary.md) | Existing project, small backend change (template `backend`); the quickest end-to-end check | `storefront` | feature |

## 1. Start the platform

`./test-platform.sh` starts Temporal, the API and the worker, then runs `SPEC_FILE`. Section 3 shows how to point it
at one of these specs. If the stack is already up, use the `aidlc run` commands instead.

## 2. Create the three new projects (once)

```bash
specs/samples/create-projects.sh
```

It creates an empty bare repository under `var/local/repos/remotes/` and a project for each new-project spec. It
skips anything that already exists.

## 3. Run a spec

Each command runs one spec in economy mode and streams progress.

```bash
source var/local/env.sh && export AIDLC_API_URL=http://localhost:8000
A=.venv/bin/aidlc

$A run specs/samples/01-new-ui-prompt-library.md        -p prompt-library  --title "AIG Prompt Library"   --economy --watch
$A run specs/samples/02-new-ui-backend-feedback-hub.md  -p feedback-hub    --title "AIG Feedback Hub"     --economy --watch
$A run specs/samples/03-new-vsix-prompt-snippets.md     -p prompt-snippets --title "AIG Prompt Snippets"  --economy --watch
$A run specs/samples/04-existing-storefront-order-status.md -p storefront  --title "Order status updates" --economy --watch
$A run specs/samples/05-existing-storefront-order-hang-bug.md -p storefront --type bug --title "Order request hangs when inventory is down" --economy --watch
$A run specs/samples/06-quick-orders-summary.md -p storefront --economy --watch
```

Or use the test script, which runs with economy mode on by default:

```bash
SPEC_FILE=specs/samples/03-new-vsix-prompt-snippets.md SPEC_PROJECT=prompt-snippets SPEC_TITLE="AIG Prompt Snippets" ./test-platform.sh
```

## 4. While it runs

- Gate A questions: `$A inbox -p <project>`, or the Temporal UI (http://localhost:8233): the run's **Queries →
  `open_questions`**, then **Send Signal → `answer_questions`** with the filled-in template.
- Status: `$A status -p <project>`; output: `$A artifacts <run_id>`.

## Notes

- **Run the specs one at a time.** Each new-project run uses several million input tokens, and the Bedrock daily
  quota (429 errors) is shared by all runs.
- **Specs 4 and 5 both change `storefront`'s `api/`.** If both runs are active at once, the second is ranked behind
  the first in the manifest, and the overlap analyst flags the shared files.
- **Spec 5 is a bug run** (`--type bug`), so it takes the bugfix workflow: reproduce, then fix, then verify. The bug
  is real on `storefront` `main`. In `api/app/retry.py`, the attempt counter only increases while the delay is below
  the maximum delay.
- **Spec 3 says to build the VSIX** with `npm run package` and write it to `dist/aig-prompt-snippets.vsix`. After the
  run, build it from the run's worktree and install it with `code --install-extension`.
