#!/usr/bin/env bash
# Creates the empty repositories and AIDLC projects for the three new-project sample specs.
# Safe to re-run: existing repositories and projects are skipped. Needs the API on :8000 (./test-platform.sh starts it).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
REMOTES="$ROOT/var/local/repos/remotes"
API="${AIDLC_API_URL:-http://localhost:8000}"
AUTH="Authorization: Bearer dev:admin@acme.test"
TEAM_ID="${TEAM_ID:-487136a3b95c}"

create() {
  local project="$1" name="$2" repo="$3" preset="$4" title="$5"
  local bare="$REMOTES/$repo.git"
  if [[ -e "$bare" ]]; then
    echo "repo exists: $bare"
  else
    local seed
    seed="$(mktemp -d)"
    git -C "$seed" init -q -b main
    printf '# %s\n\nBuilt by AIDLC from `specs/samples`.\n' "$title" > "$seed/README.md"
    printf 'node_modules/\ndist/\ncoverage/\n*.tsbuildinfo\n.venv/\n__pycache__/\n*.egg-info/\n*.db\n*.vsix\n.DS_Store\n' > "$seed/.gitignore"
    git -C "$seed" add -A
    git -C "$seed" -c user.name=AIDLC -c user.email=aidlc@local commit -qm "Initial commit"
    git clone -q --bare "$seed" "$bare"
    echo "created repo: $bare"
  fi

  local code
  code=$(curl -s -o /dev/null -w '%{http_code}' "$API/api/v1/projects/$project" -H "$AUTH")
  if [[ "$code" == "200" ]]; then
    echo "project exists: $project"
    return
  fi
  curl -sf -X POST "$API/api/v1/projects" -H "$AUTH" -H "Content-Type: application/json" -d @- >/dev/null <<JSON
{"id": "$project", "name": "$name", "team_id": "$TEAM_ID",
 "config": {"stack_preset": "$preset",
            "repos": [{"id": "app", "url": "$bare", "primary": true, "integration_branch": "main"}],
            "budgets": {"run_usd": 60.0, "agent_usd_default": 3.0}}}
JSON
  echo "created project: $project"
}

create prompt-library   "AIG Prompt Library"  prompt-library         generic-node    "AIG Prompt Library"
create feedback-hub     "AIG Feedback Hub"    feedback-hub           nextjs-fastapi  "AIG Feedback Hub"
create prompt-snippets  "AIG Prompt Snippets" prompt-snippets-vscode generic-node    "AIG Prompt Snippets"
