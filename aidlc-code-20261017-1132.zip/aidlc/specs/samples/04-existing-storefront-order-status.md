# Storefront: change an order's status (enhancement)

| Field | Value |
|---|---|
| Type | Enhancement to an existing product |
| Repository | `storefront` (FastAPI in `api/`, Next.js in `web/`) |
| Requested by | Fulfilment team |
| Priority | P2 |

## Context

Orders are created as `pending` and never change: there is no endpoint to update an order's status, so the
fulfilment team edits the SQLite database by hand to mark orders paid, shipped or cancelled. The orders page shows
the status as plain text. This change adds a status-update endpoint with the allowed transitions and buttons in the
orders table.

## Functional requirements

### API (`api/app/routes/orders.py`, `api/app/repository.py`, `api/app/models.py`)

1. `PATCH /orders/{order_id}/status` with the JSON body `{"status": "<new status>"}` changes the order's status and
   returns `200` with the updated order.
2. Allowed transitions only:

   | From | To |
   |---|---|
   | `pending` | `paid`, `cancelled` |
   | `paid` | `shipped`, `cancelled` |

   `shipped` and `cancelled` are final. Any other change returns `409` with
   `{"detail": "cannot change order <id> from <current> to <new>"}`; the order is unchanged.
3. An order id that does not exist returns `404` with `{"detail": "order <id> not found"}` (the existing message).
4. A `status` that is not one of `pending`, `paid`, `shipped`, `cancelled` returns `422`.
5. Orders gain a field `status_changed_at`: `null` until the first status change, then the ISO 8601 UTC time of the
   latest change. `GET /orders` and `GET /orders/{id}` return it. Existing databases created before this change keep
   working: on startup the repository adds the column when it is missing.
6. The update is atomic: two concurrent requests that both try to move the same `pending` order end with exactly one
   success; the other receives the `409` of requirement 2 based on the status it lost to.

### Web (`web/components/OrdersTable.tsx`, `web/lib/api.ts`)

7. The Status column shows the status as a pill (pending grey `#56637e`, paid blue `#1352de`, shipped green
   `#0a7458`, cancelled red `#c8352b`, white text) followed by one button per allowed next status:
   "Mark paid", "Mark shipped", "Cancel". Final statuses show no buttons.
8. Pressing a button calls the new endpoint from the browser (the API URL comes from `NEXT_PUBLIC_ORDERS_API_URL`,
   default `http://localhost:8000`; the server-side `fetchOrders` keeps using `ORDERS_API_URL`). While the request runs, that row's buttons are disabled. On success the row
   shows the new status and its buttons. On `409` the row shows "This order changed elsewhere. Refresh the page." On
   any other failure it shows "Couldn't update the order. Try again."
9. "Cancel" asks for confirmation inside the row ("Cancel order <id>?" with "Yes, cancel" and "Keep order") before
   calling the API.
10. The API allows browser calls from `http://localhost:3000` (CORS for `PATCH` and `GET`), configurable through the
    environment variable `ORDERS_CORS_ORIGINS` (comma-separated).

## Non-functional requirements

- The orders table still never shows customer e-mail addresses (existing test `does not show customer emails`).
- Existing endpoints and their tests keep passing unchanged.
- New API tests cover every allowed transition, a rejected transition per final status, the `404`, the `422`, the
  concurrent update of requirement 6, and the column migration of requirement 5 on a database created without it.
- New web tests cover the buttons shown per status, the disabled state while a request runs, the cancel confirmation
  and both error messages.

## Out of scope

- Who changed the status (no audit trail) and e-mail notifications to customers.
- Refunds or stock release when an order is cancelled.

## Acceptance scenarios

| # | Scenario | Expected |
|---|---|---|
| A1 | `PATCH /orders/1/status {"status": "paid"}` on a pending order | `200`, status `paid`, `status_changed_at` set |
| A2 | Then `{"status": "pending"}` | `409` "cannot change order 1 from paid to pending" |
| A3 | `PATCH /orders/999/status` | `404` "order 999 not found" |
| A4 | `{"status": "lost"}` | `422` |
| A5 | Start the API on a database created before this change | It starts; existing orders return `status_changed_at: null` |
| A6 | On the orders page press "Mark paid" | The pill turns blue "paid" and the row shows "Mark shipped" and "Cancel" |
| A7 | Press "Cancel", then "Keep order" | No request is sent; the order is unchanged |
