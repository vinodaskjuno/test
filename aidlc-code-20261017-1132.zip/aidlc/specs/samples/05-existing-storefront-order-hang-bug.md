# Bug: placing an order hangs forever when the inventory service is down

| Field | Value |
|---|---|
| Type | Bug |
| Repository | `storefront` (`api/`) |
| Severity | High: request threads stay busy until the API stops responding |
| Reported by | On-call SRE |
| Environment | Orders API 0.4.0 with `ORDERS_INVENTORY_URL` set |

## Summary

When the inventory service is unavailable, `POST /orders` sometimes never returns. The client times out (our load
balancer gives up after 60 seconds), the API keeps working on the request in the background, and the inventory
service's access log shows a new reservation request from the API about every half second for as long as the API
process runs. With enough of these requests the
API runs out of worker threads and stops answering every endpoint, including `/health`.

With the default settings we see the expected behaviour: three attempts, then `503` with
`{"detail": "inventory service unavailable"}`. The hang appears with our production retry settings.

## Steps to reproduce

1. Start an inventory stub that answers every request with `503`, or point `ORDERS_INVENTORY_URL` at a closed port.
2. Start the API with:
   ```
   ORDERS_INVENTORY_URL=http://localhost:9999
   ORDERS_RETRY_ATTEMPTS=10
   ORDERS_RETRY_BASE_DELAY_S=0.05
   ORDERS_RETRY_MAX_DELAY_S=0.5
   ```
3. `POST /orders` with a valid body, for example
   `{"customer_name": "Ada", "customer_email": "ada@shop.example", "sku": "BOOK-001", "quantity": 1, "total_cents": 2299}`.

## Expected

After `ORDERS_RETRY_ATTEMPTS` failed attempts in total (10 here), the request returns `503` with
`{"detail": "inventory service unavailable"}`. The waits between attempts double from the base delay and never exceed
the maximum delay, so the request finishes in well under 10 seconds with these settings. No order is stored.

## Actual

The request never returns. The inventory stub keeps receiving `POST /reservations` every 0.5 seconds with no end.

## Notes

- Also reproducible with `ORDERS_RETRY_BASE_DELAY_S=1.0` and `ORDERS_RETRY_MAX_DELAY_S=1.0` and the default 3
  attempts.
- An out-of-stock answer (`409` from inventory) still returns `409` immediately, as it should.

## Acceptance

- A regression test reproduces the hang with the settings above (using a fake sleep, so the test is fast) and passes
  after the fix: exactly 10 attempts, then the `503`.
- The number of attempts never exceeds `ORDERS_RETRY_ATTEMPTS` for any combination of base and maximum delay,
  including a base delay equal to or greater than the maximum.
- Existing tests keep passing; the default-settings behaviour (3 attempts, then `503`) is unchanged.
