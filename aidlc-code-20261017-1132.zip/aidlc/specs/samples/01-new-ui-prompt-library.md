# AIG Prompt Library: React UI with mock data

| | |
|---|---|
| Type | New project, UI only |
| Repository | `prompt-library` (empty; this work creates the app) |
| Purpose | A browsable library of reusable AI prompt templates: search, categories, a prompt editor with a live preview, favourites |
| Requirement ids | Every requirement below is one testable behaviour with its own id; the scenarios in section 10 name the ids they prove |

Where the spec says MUST, the build fails acceptance if the behaviour is missing.

## 1. Scope

In scope: one React single-page app with a header, a category sidebar and three screens, running entirely on built-in sample data. Out of scope: a backend, authentication, editing or creating templates, internationalisation, analytics.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Stack | React 18.3, TypeScript 5.5 (`strict: true`), Vite 5 |
| Routing | `react-router-dom` 6, browser history; routes in section 5 |
| Animation | `framer-motion` 11 only |
| Styling | Plain CSS with the CSS custom properties of section 3; no CSS framework, no component library |
| Runtime dependencies | Only `react`, `react-dom`, `react-router-dom`, `framer-motion` |
| Tests | `vitest` 2 with `jsdom`, `@testing-library/react`, `@testing-library/user-event`, `@testing-library/jest-dom` registered for Vitest (`import "@testing-library/jest-dom/vitest"` in the setup file); `@types/node` 22 in devDependencies |
| Scripts | `dev`, `build` (`tsc --noEmit && vite build`), `preview`, `test` (`vitest run`), `typecheck` (`tsc --noEmit`) |
| Node | Node 22 / npm 10; `package-lock.json` committed |

## 3. AIG style

| ID | Requirement |
|---|---|
| FR-STYLE-1 | Every colour in the UI is one of the tokens in the table below, defined as a CSS custom property on `:root` (light values) and on `[data-theme="dark"]` (dark values). No other colour value appears in the CSS. |
| FR-STYLE-1b | Each token holds exactly the light and dark hex values given for it in the table below. |
| FR-STYLE-2 | Colours are solid: no gradients. |
| FR-STYLE-3 | Headings use the font stack `"AIG Futura","Futura PT",Inter,system-ui,sans-serif`. |
| FR-STYLE-4 | Body text uses the font stack `Inter,"Source Sans 3",system-ui,sans-serif`. |
| FR-STYLE-5 | Template text and variable chips use the font stack `"JetBrains Mono",ui-monospace,Menlo,monospace`. |
| FR-STYLE-6 | No web fonts are downloaded. |
| FR-STYLE-7 | Corner radius is 6px on buttons and inputs, 10px on cards and 999px on pills. |
| FR-STYLE-8 | The header is 60px high. |
| FR-STYLE-9 | The sidebar is 240px wide at 768px and wider. |
| FR-STYLE-10 | Every animation in this spec uses the easing `cubic-bezier(.2,.8,.2,1)`. |

| Token | Light | Dark |
|---|---|---|
| `--bg` | `#f3f5fa` | `#000000` |
| `--surface` | `#ffffff` | `#0e0e11` |
| `--line` | `#e4e9f2` | `#24242b` |
| `--ink` | `#0b1533` | `#f2f3f7` |
| `--muted` | `#56637e` | `#a3a6b3` |
| `--header` | `#001871` | `#000000` |
| `--header-ink` | `#ffffff` | `#ffffff` |
| `--primary` | `#1352de` | `#6e9bff` |
| `--primary-ink` | `#ffffff` | `#000000` |
| `--gold` (favourite star) | `#ffbf3f` | `#f5c451` |
| `--ok-bg` | `#e3f5ef` | `#0b2219` |
| `--ok` | `#0a7458` | `#4dd29a` |
| `--danger-bg` | `#fdecea` | `#2a0f0d` |
| `--danger` | `#c8352b` | `#ff6b5e` |
| `--selected-bg` (selected sidebar item) | `#e8effd` | `#15192a` |
| `--slot-bg` (empty variable in the preview) | `#fff3dc` | `#2a210a` |

## 4. Shell

| ID | Requirement |
|---|---|
| FR-SHELL-1 | The header has background `--header` and text colour `--header-ink`. |
| FR-SHELL-2 | The header shows the wordmark "AIG Prompt Library", which links to `/`. |
| FR-SHELL-3 | The header has a search field 300px wide with the placeholder "Search prompts" and a visually hidden label "Search prompts". |
| FR-THEME-1 | A theme toggle button in the header (`aria-label="Toggle theme"`) switches between the light and dark tokens by setting `data-theme` on the `html` element. |
| FR-THEME-2 | The toggle stores the chosen theme in `localStorage` under `aig.theme` (`light` or `dark`); on load, a stored theme is applied before the first paint. |
| FR-THEME-3 | With no stored theme, the app uses dark when `prefers-color-scheme: dark` matches and light otherwise. |
| FR-SIDE-1 | The sidebar lists "All", "Claims", "Underwriting", "Customer service" and "Engineering", each with the number of prompts it holds, then "Favourites" with the number of favourites. |
| FR-SIDE-2 | The sidebar counts are totals: a search does not change them. |
| FR-SIDE-3 | The item for the current route has background `--selected-bg` and text colour `--primary`. |
| FR-SIDE-4 | Below 768px wide, the sidebar becomes one horizontal row of pills under the header that scrolls sideways. |
| FR-SIDE-5 | Each sidebar item is a link: clicking it, or pressing Enter while it has focus, opens its route (All `/`, a category `/category/<slug>`, Favourites `/favourites`). |
| FR-TOAST-1 | Toasts appear at the bottom centre and disappear after 3 seconds. |
| FR-TOAST-2 | Only one toast shows at a time: a new toast replaces the one showing and restarts the 3-second timer. |
| FR-TOAST-3 | Toasts render in a live region with `role="status"` and `aria-live="polite"`, so screen readers announce them without moving focus. |

## 5. Navigation

| ID | Requirement |
|---|---|
| FR-NAV-1 | `/` shows the Library with every prompt. |
| FR-NAV-2 | `/category/<slug>` shows the Library with only that category's prompts, for the slugs `claims`, `underwriting`, `customer-service` and `engineering`. |
| FR-NAV-3 | `/prompts/<id>` shows the Prompt detail screen for that prompt. |
| FR-NAV-4 | `/favourites` shows the Favourites screen. |
| FR-NAV-5 | Any other path, including `/category/<slug>` with a slug not listed in FR-NAV-2, shows "Page not found" and a "Back to the library" button that opens `/`. |
| FR-NAV-6 | On a route change the old screen fades out over 150ms, then the new screen fades in while rising from translateY 8px to 0 over 300ms. |

## 6. Library screen

| ID | Requirement |
|---|---|
| FR-LIB-1 | Prompts show as cards sorted by title A–Z. |
| FR-LIB-2 | The card grid has 3 columns from 1024px wide, 2 columns from 640px to 1023px, and 1 column below 640px. |
| FR-LIB-3 | Each card shows the title, a category pill, the description and each variable as a monospace chip such as `{{customer_name}}`. |
| FR-LIB-4 | When a list of cards appears, the cards enter one after another, 50ms apart. |
| FR-LIB-5 | On hover a card rises by 2px over 150ms. |
| FR-LIB-6 | Clicking a card, or pressing Enter while it has focus, opens `/prompts/<id>`; clicking its star does not open the prompt. |
| FR-SEARCH-1 | Typing in the search field filters the list on `/`, `/category/<slug>` and `/favourites` as each character is typed: a prompt stays when its title or its description contains the text, ignoring case. |
| FR-SEARCH-2 | While the search field holds text, the URL carries it as `?q=<text>`; when the field is emptied, `?q=` is removed from the URL. |
| FR-SEARCH-3 | Opening or reloading a Library or Favourites URL that has `?q=<text>` fills the search field with the text and applies the filter. |
| FR-SEARCH-4 | Typing in the search field on a Prompt detail or Page not found screen opens `/?q=<text>`. |
| FR-SEARCH-5 | When nothing matches, the list area shows `No prompts match "<text>"` and a "Clear search" button. |
| FR-SEARCH-6 | "Clear search" empties the search field, removes `?q=` from the URL and shows the unfiltered list. |

## 7. Prompt detail screen

| ID | Requirement |
|---|---|
| FR-DET-1 | The screen shows the prompt's title, category, description and star button. |
| FR-DET-2 | The screen has one text field per variable, labelled with the variable name with underscores as spaces and its first letter upper case (`customer_name` becomes "Customer name"). |
| FR-DET-3 | A preview below the fields shows the template with each `{{variable}}` replaced by its field's value, updated on every keystroke. |
| FR-DET-4 | In the preview, a variable whose field is empty stays as `{{variable}}` with background `--slot-bg`. |
| FR-DET-5 | "Copy prompt" writes the preview text to the clipboard and shows the toast "Copied to clipboard". |
| FR-DET-6 | When the browser rejects the clipboard write, "Copy prompt" shows the toast "Couldn't copy. Select the text and copy it manually." |
| FR-DET-7 | "Reset" empties every field. |
| FR-DET-8 | Leaving the Prompt detail screen empties every field: opening the prompt again, or reloading, shows every field empty. |
| FR-DET-9 | `/prompts/<id>` for an id that does not exist shows "Prompt not found" and a "Back to the library" button that opens `/`. |

## 8. Favourites

| ID | Requirement |
|---|---|
| FR-FAV-1 | Each card and the Prompt detail screen have a star button with `aria-pressed`, labelled "Add to favourites" when off and "Remove from favourites" when on. |
| FR-FAV-2 | Pressing a star toggles that prompt's favourite state, and the change shows at once on every card of that prompt, on its Prompt detail screen and in the sidebar's Favourites count. |
| FR-FAV-3 | Favourites are stored in `localStorage` under `aig.favourites` as an array of prompt ids and restored on load. |
| FR-FAV-4 | A star that is on is filled with `--gold`. |
| FR-FAV-5 | On toggle the star scales from 1 to 1.25 and back to 1 over 300ms. |
| FR-FAV-6 | `/favourites` shows the favourite prompts as cards sorted by title A–Z. |
| FR-FAV-7 | With no favourites, `/favourites` shows "No favourites yet. Star a prompt to keep it here." |

## 9. Sample data and quality

| ID | Requirement |
|---|---|
| FR-DATA-1 | The prompts come from `src/mocks/prompts.ts` through the functions of `src/mocks/service.ts`, which resolve after 300ms. |
| FR-DATA-2 | While the prompts load, each card position shows a card-sized skeleton block with a shimmer. |
| FR-DATA-3 | The app holds exactly the 12 prompts in the table below, with these ids, titles, categories, descriptions and variables. |
| FR-DATA-4 | Each prompt's template text is chosen by the implementer and contains each of its variables as `{{variable}}` at least once. |
| NFR-1 | Contrast meets WCAG 2.2 AA in both themes. |
| NFR-2 | Every control can be reached and used with the keyboard and shows a visible 2px `--primary` focus ring. |
| NFR-3 | The page has the landmarks `header`, `nav` labelled "Categories" and `main`. |
| NFR-4 | With `prefers-reduced-motion: reduce`, every animation and the skeleton shimmer are replaced by an instant change. |
| NFR-5 | `npm run typecheck`, `npm test` and `npm run build` succeed. |
| NFR-6 | Text typed into the variable fields may include customer details, such as names and incident notes. It stays in page memory only: it is never written to `localStorage`, `sessionStorage`, cookies, the URL or the console, and never sent over the network. The only data that leaves the page is what the user copies with "Copy prompt". |
| NFR-7 | `localStorage` holds only `aig.theme` and `aig.favourites`. |
| NFR-8 | The app makes no network requests after it has loaded. |

| id | Title | Category | Description | Variables |
|---|---|---|---|---|
| `p01` | Claim summary | Claims | Summarises a claim file for the adjuster | `claim_id`, `policy_number`, `incident_notes` |
| `p02` | Claim denial letter | Claims | Drafts a denial letter that states the reason | `customer_name`, `claim_id`, `denial_reason` |
| `p03` | Fraud red flags | Claims | Lists warning signs found in incident notes | `incident_notes` |
| `p04` | Risk assessment | Underwriting | Rates a business's exposure by type, location and revenue | `business_type`, `location`, `revenue` |
| `p05` | Quote explanation | Underwriting | Explains a premium and its coverage to a customer | `customer_name`, `premium`, `coverage` |
| `p06` | Policy comparison | Underwriting | Compares two policies side by side | `policy_a`, `policy_b` |
| `p07` | Complaint reply | Customer service | Drafts an apologetic reply to a complaint | `customer_name`, `complaint` |
| `p08` | Renewal reminder | Customer service | Reminds a customer of an upcoming renewal | `customer_name`, `renewal_date` |
| `p09` | Call summary | Customer service | Summarises a call transcript in five bullets | `transcript` |
| `p10` | Code review | Engineering | Reviews code for bugs and risky patterns | `language`, `code` |
| `p11` | Unit test writer | Engineering | Writes unit tests for a piece of code | `language`, `code` |
| `p12` | Incident postmortem | Engineering | Writes a blameless postmortem from notes and a timeline | `incident_notes`, `timeline` |

Because titles and descriptions are fixed, search results are fixed too: "claim" matches only p01 and p02, and "code" matches only p10 and p11.

## 10. Acceptance scenarios

| # | Proves | Scenario | Expected |
|---|---|---|---|
| S1 | FR-NAV-1, FR-LIB-1, FR-SIDE-1 | Open `/` | 12 cards sorted A–Z; the sidebar shows All 12, Claims 3, Underwriting 3, Customer service 3, Engineering 3, Favourites 0 |
| S2 | FR-SEARCH-1, FR-SEARCH-2 | On `/`, type "claim" in the search | Only Claim summary and Claim denial letter remain and the URL ends with `?q=claim` |
| S3 | FR-SIDE-2 | With "claim" in the search | The sidebar still shows All 12 and Claims 3 |
| S4 | FR-SEARCH-5 | On `/`, type "zzz" | `No prompts match "zzz"` and a "Clear search" button |
| S5 | FR-SEARCH-6 | Press "Clear search" | The field is empty, the URL has no `?q=` and 12 cards show |
| S6 | FR-SEARCH-3 | Open `/?q=claim` directly | The search field shows "claim" and only the two Claim prompts are listed |
| S7 | FR-SEARCH-4 | On `/prompts/p07`, type "code" in the search | `/?q=code` opens with Code review and Unit test writer |
| S8 | FR-NAV-2 | Open `/category/claims` | Only the 3 Claims prompts; the Claims item has background `--selected-bg` |
| S8b | FR-SIDE-5 | On `/`, click Engineering in the sidebar | `/category/engineering` opens with the 3 Engineering prompts |
| S9 | FR-NAV-5 | Open `/category/marketing` | "Page not found" and "Back to the library" |
| S10 | FR-DET-3, FR-DET-4 | On Complaint reply, type "Ada" in Customer name | The preview shows "Ada" in place of `{{customer_name}}`; `{{complaint}}` stays with background `--slot-bg` |
| S11 | FR-DET-5, FR-TOAST-3 | Press "Copy prompt" | The clipboard holds the preview text and the toast "Copied to clipboard" shows for 3 seconds inside the `role="status"` region |
| S12 | FR-DET-6 | Press "Copy prompt" with clipboard access refused | The toast "Couldn't copy. Select the text and copy it manually." |
| S13 | FR-TOAST-2 | Press "Copy prompt" twice within 1 second | One toast shows, and it disappears 3 seconds after the second press |
| S14 | FR-DET-7 | Fill in both fields of Complaint reply, press "Reset" | Both fields are empty |
| S15 | FR-DET-8 | Fill in Complaint reply, open Favourites, open Complaint reply again | Every field is empty |
| S16 | FR-DET-9 | Open `/prompts/p99` | "Prompt not found" and "Back to the library" |
| S17 | FR-FAV-2, FR-FAV-3 | Star Code review on its card, reload, open Favourites | Code review is listed, its star is on, and the Favourites count is 1 |
| S18 | FR-FAV-7 | Open `/favourites` with no favourites | "No favourites yet. Star a prompt to keep it here." |
| S19 | FR-THEME-1, FR-THEME-2 | Toggle the theme to dark and reload | The dark tokens apply after the reload |
| S20 | FR-THEME-3 | First visit with no stored theme and the system set to dark | The dark tokens apply |
| S21 | NFR-6, NFR-7 | Fill in a prompt's fields, then inspect storage and the URL | Neither `localStorage` nor the URL contains the typed text |
