# AIG Feedback Hub: FastAPI backend and React UI

| | |
|---|---|
| Type | New project, UI and backend |
| Repository | `feedback-hub` (empty; this work creates `api/` and `web/`) |
| Purpose | Collect and review user feedback on AI answers: submit a rating and comment for a model, browse and filter feedback, see per-model statistics |
| Requirement ids | `FR-…` and `NFR-…` ids are used by the acceptance scenarios in section 8 |

Where the spec says MUST, the build fails acceptance if the behaviour is missing.

## 1. Scope

In scope: a REST API with SQLite storage (`api/`) and a React single-page app that uses it (`web/`). Out of scope: authentication (every request is anonymous), editing feedback, deployment, internationalisation.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| API stack | Python 3.12, FastAPI 0.115, Pydantic 2, `uvicorn`; storage with the standard library `sqlite3` |
| API packaging | `api/pyproject.toml` with a `dev` extra (`pytest`, `httpx`). Install and test from a virtual environment: `cd api && python3 -m venv .venv && .venv/bin/pip install -e ".[dev]"`, then `cd api && .venv/bin/pytest -q`. Never install into the system Python |
| API config | Environment variables `FEEDBACK_DB_PATH` (default `feedback.db`) and `FEEDBACK_CORS_ORIGINS` (default `http://localhost:5173`) |
| Web stack | React 18.3, TypeScript 5.5 (`strict`), Vite 5, `react-router-dom` 6; no CSS framework; inline SVG chart (no chart library) |
| Web config | `VITE_API_URL` (default `http://localhost:8000`) |
| Web tests | `vitest` 2, `jsdom`, `@testing-library/react`, `@testing-library/jest-dom` registered for Vitest (`import "@testing-library/jest-dom/vitest"`), `@types/node` 22; `fetch` is mocked in tests |
| Web scripts | `dev`, `build` (`tsc --noEmit && vite build`), `test` (`vitest run`), `typecheck` (`tsc --noEmit`) |

## 3. Domain

A feedback item has:

| Field | Type | Rules |
|---|---|---|
| `id` | integer | assigned by the API, increasing |
| `model` | string | one of `gpt-4o`, `claude-sonnet`, `gemini-pro`, `llama-3` |
| `rating` | integer | 1 to 5 |
| `comment` | string | 0 to 2,000 characters after trimming whitespace |
| `tags` | list of strings | 0 to 5 tags; each 1 to 24 characters of `a-z`, `0-9` and `-`; duplicates removed, order kept |
| `author_email` | string | a valid e-mail address, at most 254 characters |
| `created_at` | string | ISO 8601 UTC with `Z`, set by the API |

## 4. API (FR-API)

FR-API-1. `POST /api/feedback` with the fields above except `id` and `created_at` → `201` and the stored item. Invalid input → `422` (FastAPI's validation error body).

FR-API-2. `GET /api/feedback` → `{"items": [...], "next_cursor": <id or null>}`, newest first. Query parameters: `model` (one of the four), `min_rating` (1–5), `tag` (one tag), `limit` (1–100, default 20) and `cursor` (return items with `id` lower than the cursor). `next_cursor` is the last item's id when more items exist, otherwise `null`. An invalid parameter → `422`.

FR-API-3. `GET /api/feedback/{id}` → the item, or `404` with `{"detail": "feedback <id> not found"}`.

FR-API-4. `DELETE /api/feedback/{id}` → `204`, or `404` with the same detail.

FR-API-5. `GET /api/feedback/stats` → `{"total": n, "by_model": [{"model", "count", "average_rating"}], "distribution": {"1": n, …, "5": n}}`. `by_model` lists all four models in the order of section 3, with `count` 0 and `average_rating` `null` for a model without feedback; averages are rounded to 2 decimals.

FR-API-6. `GET /health` → `{"status": "ok"}`. CORS allows the origins in `FEEDBACK_CORS_ORIGINS` (comma-separated) for GET, POST and DELETE.

## 5. Web app (FR-WEB)

FR-WEB-1. Shell: a header (background `#001871`, white text) with the title "AIG Feedback Hub" and navigation links "Feedback" (`/`), "New feedback" (`/new`) and "Statistics" (`/stats`). The active link is underlined. Page background `#f3f5fa`, cards white with radius 10px, primary colour `#1352de`, text `#0b1533`, muted text `#56637e`. Fonts: `Inter, system-ui, sans-serif`.

FR-WEB-2. Feedback list (`/`): a filter bar (Model select with "All models" and the four models; Minimum rating select "Any", 1–5; Tag text field) and a list of cards (model pill, rating as 1–5 filled stars with `aria-label="<n> out of 5"`, comment, tag chips, author e-mail, date as `15 Oct 2026, 10:00`). Changing a filter reloads from the first page. A "Load more" button appears while `next_cursor` is not null and appends the next page. With no items: "No feedback matches these filters."

FR-WEB-3. Each card has a Delete button. It opens an inline confirmation in the card ("Delete this feedback?" with "Delete" and "Cancel"); Delete calls the API and removes the card. A failed delete shows "Couldn't delete. Try again." in the card.

FR-WEB-4. New feedback (`/new`): fields Model (select, required), Rating (five radio buttons, required), Comment (textarea with a live counter `n / 2000`), Tags (comma-separated text) and E-mail. Submit validates in the browser with the rules of section 3 and shows a message under each invalid field ("Choose a model", "Choose a rating", "Comment is too long", "Use up to 5 tags of a-z, 0-9 and -", "Enter a valid e-mail address"). A successful submit navigates to `/` and shows the banner "Thanks, your feedback was saved." for 3 seconds. A `422` from the API shows its first error message above the form.

FR-WEB-5. Statistics (`/stats`): the total count, a horizontal bar chart of the average rating per model (scale 0–5, bar colours `#1352de`, `#00a4e4`, `#14a37f`, `#f2a900` in model order, value label at the end of each bar, "No data" for a model without feedback), and a table of the rating distribution 1–5.

FR-WEB-6. When the API cannot be reached, each page shows "Couldn't reach the Feedback API." with a Retry button that repeats the request. While a request is pending, a loading state ("Loading…") replaces the content.

## 6. Non-functional (NFR)

- NFR-1. API tests cover every endpoint, each validation rule, pagination with `cursor`, and the statistics arithmetic; they use a temporary database per test.
- NFR-2. Web tests cover the form validation messages, filter changes, Load more, delete confirmation and the API-unreachable state.
- NFR-3. Accessibility: labels on every field, keyboard-operable controls with a visible focus ring, WCAG 2.2 AA contrast.
- NFR-4. `api/README.md` and `web/README.md` state how to install, run and test each part.

## 7. Seed data

`api/scripts/seed.py` inserts 12 feedback items (3 per model) with ratings and tags chosen by the implementer and author e-mails at `feedback.example` (for example `ada@feedback.example`), when run as `cd api && .venv/bin/python scripts/seed.py`.

## 8. Acceptance scenarios

| # | Scenario | Expected |
|---|---|---|
| S1 | `POST /api/feedback` with rating 6 | `422` |
| S2 | Create 25 items, `GET /api/feedback` | 20 items newest first and a `next_cursor`; the next page returns 5 items and `next_cursor` `null` |
| S3 | `GET /api/feedback?model=llama-3&min_rating=4` | Only llama-3 items rated 4 or 5 |
| S4 | `GET /api/feedback/stats` after seeding | Total 12, four models with counts 3 and averages to 2 decimals |
| S5 | Submit the web form without a rating | "Choose a rating" under Rating; no request is sent |
| S6 | Submit a valid form | Back on `/` with the thanks banner and the new card first |
| S7 | Delete a card and confirm | The card disappears; `GET /api/feedback/{id}` returns `404` |
| S8 | Stop the API and open `/stats` | "Couldn't reach the Feedback API." with Retry |
