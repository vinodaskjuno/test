# AIG AI Ecosystem VS Code Extension, unit U2: Live connection and webviews

This is an excerpt of the full extension specification (baseline 0.16.0) for one unit of work: **U2 Live and webviews**
(FR-LIVE, FR-UI; NFR-PERF-1..2, NFR-SEC-5). The other units (foundation (manifest, settings, sign-in, connection state); coding assistant; agents; New Agent and SDK; evals; Floci; Claude Code; demo mode; packaging) are separate work items and are out of scope here.
This unit uses U1 as an existing dependency: the configuration resolver, the signed-in session and token, the connection state and `describeBackendError`. The webview widgets and message types come from `@aig/ui`.

### 1.2 Architecture principle: no keys in the extension

```
VS Code extension ──(user's own bearer token)──► AIG platform-api ──(server-held keys)──► Portkey gateway ──► model providers
        │                                               │
        └── never talks to Portkey or a provider        └── adds keys, routing config, metadata, trace id; reports to Fiddler
```

- The extension MUST NOT receive, store, log or send a model-gateway (Portkey) key, and MUST NOT use VS Code
  SecretStorage.
- Its only credential is the signed-in user's own token: an Entra ID access token, or `dev:<email>` against a
  local backend. That token goes only to the configured backend URL.
- The backend drops any `x-portkey-*` header a client sends.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Language | TypeScript 5.5+, `strict`, `noUnusedLocals`, `noImplicitReturns`, `isolatedModules`; ES2022 modules, `moduleResolution: Bundler` |
| VS Code | `engines.vscode: ^1.90.0` (first version where the Chat participant API is stable). `@types/vscode` MUST be `~1.90.0` and match `engines` (enforced by a test) |
| Node | Node 22 / npm 10 for development (`.nvmrc` at the repo root). Extension host bundle targets `node18` |
| Bundler | esbuild 0.23. Two contexts: the extension host (`src/extension.ts` → `dist/extension.js`, CJS, platform node, externals `vscode`, `bufferutil`, `utf-8-validate`) and the webviews (IIFE, browser, `es2020`, entries `dashboard`, `sidebar`, `signin`, `agentrun` → `dist/webview/<app>.js`). Minified with no sourcemap in production; sourcemaps in watch/dev |
| Runtime dependencies | Only `ws` ^8. The VSIX is packaged with `--no-dependencies`, so everything else is bundled |
| Monorepo source bundled through aliases (`aliases.mjs`, mirrored in `tsconfig.json` `paths` and `vitest.config.mjs`) | `@aig/sdk/platform` → `../sdk/typescript/src/platform/index.ts` (backend mode of the AIG SDK); `@aig/ui` → `../web/packages/ui/src/index.ts` (widgets, message types, shell, CSS); `@aig/design-tokens` → `../web/packages/design-tokens/src/index.ts`; `@aig/demo-data` → `../web/packages/demo-data/src/index.ts` (temporary) |
| Tests | vitest 2, `environment: node`, `test/**/*.test.ts`. Logic that needs no `vscode` lives in modules that do not import `vscode` and is unit tested directly; `vscode` and `ws` are mocked for host tests |
| Packaging | `npx @vscode/vsce package --no-dependencies --skip-license` |
| Platforms | macOS, Linux and Windows. Paths, venv layouts (`bin` vs `Scripts`, `.exe`), PATHEXT and shell quoting MUST be handled per platform |

## 7. Live connection service (FR-LIVE)

`LiveService` owns one WebSocket per signed-in session. The sidebar, the dashboard and the run panels share it.
It is built on `@aig/sdk/platform` (`createPlatformClient`, `client.live()`, `client.chat.stream()`,
`client.invoke.*`).

### 7.1 Client configuration (FR-LIVE-1)

| Option | Value |
|---|---|
| Base URL | validated backend URL |
| WebSocket | Node `ws` package. Bearer token in the **Authorization header of the upgrade request** (`wsAuth: 'header'`), never in the URL |
| WS URL | `ws(s)://<backend>/api/v1/ws` |
| WS options | `handshakeTimeout: 10_000`, `maxPayload: 4 MiB` |
| Timeouts | REST 15 s; stream start 120 s |
| Reconnect | exponential backoff from 1 s to 30 s (SDK default) |
| Close codes | `4401` unauthenticated, `4403` forbidden origin, `1008` policy |

### 7.2 Session lifecycle (FR-LIVE-2)

- `signedIn = configured && backendUrl && hasSession(cfg)`. When it changes, set the context key `aig.signedIn`,
  fire `onDidChangeSignedIn` and focus `aig.main` on sign-in.
- Session key = `env|backendUrl|authKind|localUser`. When it changes (sign-in, sign-out, environment, backend or
  local user switch), stop the old socket, clear usage, limits and ready info, start a new socket and fire
  `onDidChangeSession`.
- `scope` = `env|backendUrl[|localUser]` (empty when signed out). It scopes locally stored data such as tracked
  runs.

### 7.3 Usage loading (FR-LIVE-3): nothing polls

- Usage (`DashboardData` for a range of 7, 30 or 90 days; default 30) loads **once** at session start: over the
  socket (`usage.subscribe` answered by exactly one `usage` frame), or once over HTTP
  (`GET /api/v1/usage/dashboard?days=`) if the socket has not opened after **4 s**.
- After that it reloads only on user action: the refresh button/icon (`aig.refresh`) or a range change. Each sends
  one request over the socket, or one HTTP fetch right away if the socket is down.
- A reconnect does not refetch usage unless nothing has loaded yet. Chats do not refetch usage.
- Usage limits (`GET /api/v1/usage/limits`) follow the same rule: once at session start, then with `refresh=true`
  on refresh or range change. A 404 (other than `usage_not_configured`) means the endpoint does not exist on this
  backend: skip quietly and keep the card hidden. Network errors map to code `error`. Stale responses are dropped
  with a sequence number.
- Metrics the backend reports as `unavailable` show as **—** with a notice.

### 7.4 Chat streaming (FR-LIVE-4)

- `startChat(messages, jobProfile, handlers)` uses the WebSocket when it is open, otherwise HTTP SSE
  (`POST /api/v1/llm/chat/completions`). The backend attributes the traffic to agent `ide.vscode`.
- `chat.done` carries the trace id and, over the WebSocket, usage, plus `model` and `route`
  (`{user_tier, cost_mode, job_profile, usage_state}`) when reported.
- Errors are reported as `code` (or `http_<status>`) plus a message.
- The backend allows at most **4 concurrent streams per connection**, shared by chats and agent runs.
- Live `agent.invocation.status` pushes that belong to no run on this socket are re-emitted as `onAgentStatus`
  (used for background runs).

### 7.5 Webview bridge (FR-LIVE-5)

`bridgeWebview(webview, live)` forwards every live host message to the webview, and handles:

- `ready`: replay the snapshot (`init`, `live`, then `usage`, `usage.error` or `usage.loading`, then limits)
- `range`, `refresh`
- `signIn [email]`, `openDashboard`, `openPanel`, `signOut`, `selectEnvironment` (run as `aig.*` commands)
- `chat.send` and `chat.cancel`

Running chats are cancelled when the webview is disposed.

## 8. User interface surfaces

### 8.1 Webview rules (NFR-UI-1)

- Each client-rendered webview loads `dist/webview/<app>.js` inside the HTML shell from `@aig/ui renderShell`.
  The shell gets a fresh nonce, the `cspSource`, logo URIs (`media/aig-logo.svg`, `media/aig-logo-white.svg`),
  font URIs (`media/inter-var.woff2`, `media/jetbrains-mono-var.woff2`), header title and subtitle, the env, and
  the demo flag.
- `localResourceRoots` = `media/` and `dist/webview/` only. `enableScripts: true`. The CSP is `default-src 'none'`
  plus nonce scripts and styles.
- Webview entry files are thin. Each calls one `@aig/ui` mount function (`mountSidebar(…, {agents: true})`,
  `mountDashboard`, `mountSignin`, `mountAgentRun`) with a host from `postMessageHost(acquireVsCodeApi())`.
  `acquireVsCodeApi` is bound only in `src/webview/host.ts`.
- **Webviews never see a token or key.** Every inbound message goes through `parseWebviewMessage` (from
  `@aig/ui`), which validates ids, sizes and enums and requires exactly one of `input` or `messages`. Anything
  invalid is dropped.
- Views queue host messages until the widget posts `ready`, then flush them after the bridge's catch-up snapshot.
- When `aig.demoData` is toggled, every view re-renders its HTML so the gold **Sample data** badge follows the
  setting.

| App | Title | Header | Sub-header |
|---|---|---|---|
| `dashboard` | AIG Dashboard | Tokenomics | Token usage across the AIG model gateway |
| `sidebar` | AIG AI Ecosystem | AI Ecosystem | Token usage · Chat · Agents |
| `signin` | AIG AI Ecosystem | AI Ecosystem | Welcome |
| `agentrun` | AIG Run Agent | Run agent | Form or chat, streamed through the AIG platform |

### 8.2 Signed-out view `aig.signin` (FR-UI-1)

A welcome card with one **Sign In** button. It receives `{type:'status', env, tone, label, detail, method, user?}`:

- `method` is `browser` (local), `microsoft`, `devUser` (also demo) or `unconfigured`.
- In `browser` mode the widget adds an email field and a persona picker, prefilled with the last local user.
- `tone` is `ok` (connected, signed out), `warn` (degraded, env mismatch, not configured) or `bad`.
- On `ready` it sends the status and refreshes state. It accepts `signIn [email]` and `selectEnvironment`.

### 8.3 Signed-in sidebar `aig.main` (FR-UI-2)

Three tabs: **Token usage**, **Chat**, **Agents**.

- Token usage: the user's own usage for 7/30/90 days, plus the usage limits card. The limits card shows the state
  (Normal / Near limit (soft) / Limit reached (hard) / Can't check), one bar per daily or monthly limit (requests,
  tokens, cost) with the 80% soft threshold marked, unreadable limits greyed, or "No usage limits for your
  account".
- Chat: streams over the WebSocket and falls back to HTTP SSE. A route chip shows the model and route, with usage
  tags: `⚠ usage soft (downgraded)`, `⛔ usage limit reached → cheapest model`, `usage not checked`.
- Agents: section 10.1.
- Commands `aig.openTokenUsage`, `aig.openChat` and `aig.openAgents` focus the view and post `{type:'tab', tab}`.
  If signed out they run `aig.signIn` instead.
- `prefillChat(text)` (used by Explain/Fix Selection) reveals the Chat tab and posts `chat.prefill`. It does not
  send.

### 8.4 Dashboard (FR-UI-3): **AIG: Open Dashboard**

A single editor webview `aig.dashboard` titled "AIG Dashboard", `retainContextWhenHidden`. It shows requests,
tokens, cost, per-model token usage (prompt vs completion), the limits card, a 7/30/90 range picker and a refresh
button. Opening it when it is already open only reveals it and does not refetch. It closes on sign-out. If signed
out, the command runs Sign In instead.

### 8.5 Host → webview messages (`HostMessage`, `@aig/ui/messages.ts`)

`init {info: InitInfo}`, `live {status, detail?}` (`idle|connecting|open|reconnecting|unauthorized|closed`),
`usage.loading`, `usage {range, data}`, `usage.error {code, message}`, `usage.limits {data}`,
`usage.limits.error {code, message}`, `chat.prefill {text}`, `chat.delta {localId, text}`,
`chat.done {localId, usage?, traceId?, model?, route?}`, `chat.error {localId, code, message}`, `tab {tab}`,
`catalog.loading`, `catalog {items, teams, tags}`, `catalog.error`, `agent.runs {runs}`, `agent.target {target}`,
`agent.target.error`, `agent.status {...}`, `agent.delta`, `agent.output`, `agent.done`, `agent.error`,
`status {...}` (signed-out view).

`InitInfo` = `{env, user?, tier?, costMode?, team?, jobProfile, jobProfiles[], range}`. Values from the WebSocket
`ready` frame take precedence over `/api/v1/session`, which takes precedence over the local session email.

### 8.6 Webview → host messages (`WebviewMessage`)

`ready`, `range {days: 7|30|90}`, `refresh`, `openDashboard`, `openPanel`, `signOut`, `signIn {email?}`,
`selectEnvironment`, `chat.send {localId, messages, jobProfile}`, `chat.cancel {localId}`, `catalog.refresh`,
`agent.open {agentId, env?, version?}`, `agent.register`, `agent.run.show {invocationId}`, `agent.runs.refresh`,
`agent.invoke {localId, agentId, env?, version?, mode: stream|background, input? | messages?, sessionId?}`,
`agent.cancel {localId, invocationId?}`, `agent.poll {localId, invocationId}`, `clipboard.copy {text}`.

Validation regexes: agent id `^[A-Za-z0-9._-]{1,64}$`, version `^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$`, session id
`^[A-Za-z0-9._:-]{1,128}$`, invocation id `^[A-Za-z0-9_-]{1,64}$`, env `local|dev|stage|prod`.

## Non-functional requirements for this unit

- NFR-PERF-1: No background polling of usage or limits. Polling exists only for background runs (with backoff,
  capped at 2 h), Floci (10–30 s, only while visible or running) and the 5-minute silent token check.
- NFR-PERF-2: One WebSocket per window and session, shared by all views.

| Id | Requirement |
|---|---|
| NFR-SEC-5 | Every webview has a CSP with `default-src 'none'`, nonce scripts and styles, and `localResourceRoots` limited to `media/` and `dist/webview/`. All inbound messages are validated |

## 16. Backend contract consumed

All calls go through `@aig/sdk/platform` with the signed-in user's token. Headers: `Authorization: Bearer <token>`,
`x-aig-job-profile`, `x-aig-trace-id`, and `x-aig-agent-id` where applicable (see `backend/contracts/headers.md`).

| Method and path | Used by |
|---|---|
| `GET /api/v1/ws` (WebSocket) | live service |
| `GET /api/v1/usage/dashboard?days=` | HTTP usage fallback |
| `GET /api/v1/usage/limits[?refresh=true]` | usage limits card |
| `POST /api/v1/llm/chat/completions` (SSE) | Ask, HTTP chat fallback |

WebSocket frames:

- Client: `ping`, `pong`, `chat {id, messages, job_profile, agent_id?, model?, temperature?, max_tokens?}`,
  `cancel {id}`, `usage.subscribe {days}`, `usage.unsubscribe`, and the agent frames `agent.invoke` and
  `agent.cancel`.
- Server: `ready {user, team, env, user_tier, cost_mode, allowed_job_profiles}`, `ping`, `pong`,
  `chat.delta {id, text}`, `chat.done {id, traceId, usage, model, route}`,
  `chat.error {id, code, message, traceId, status}`, `usage {days, data}`, `usage.error`, `error`, and the agent
  frames `agent.delta`, `agent.output`, `agent.error`, `agent.done` and `agent.invocation.status`.

Chat and cancel ids match `^[A-Za-z0-9_-]{1,64}$`. Frames are JSON text and stay under the backend's 64 KiB frame
limit.

Error codes the UI handles specially: `portkey_key_not_configured` (503), `usage_not_configured`,
`agent_invocation_disabled` (503), `agent_exists` (409), `invocation_not_found`, `claude_code_not_configured`
(503), `invalid_session`, `not_connected`, `cancelled`, `network_error`, `timeout`.

## Verification for this unit

| Area | Test file(s) |
|---|---|
| Platform client as configured, live mapping | `platformClient.test.ts`, `live.test.ts`, `liveService.test.ts` (`vscode` and `ws` mocked, end to end) |

| # | Scenario | Expected |
|---|---|---|
| A5 | Switch user to `usage.limit@aig.example` | Socket reconnects; usage, limits and recent runs show only that user's data |
| A6 | Leave the sidebar open for 10 minutes | No usage or limits requests after the first load (checked in the backend log) |
| A7 | Chat with the socket down | Answer streams over HTTP SSE; route chip shows the model |
