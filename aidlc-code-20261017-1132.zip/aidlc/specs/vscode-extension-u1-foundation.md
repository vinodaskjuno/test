# AIG AI Ecosystem VS Code Extension, unit U1: Foundation

This is an excerpt of the full extension specification (baseline 0.16.0) for one unit of work: **U1 Foundation**
(FR-MAN, FR-CFG, FR-AUTH, FR-STATE, FR-BUILD; NFR-SEC-1..3, 8, 9). The other units (live connection, webviews and sidebar; coding assistant; agents; New Agent and SDK; evals; Floci; Claude Code; demo mode; packaging) are separate work items and are out of scope here.
The manifest lists every command and view of the whole extension; this unit registers the commands it implements and leaves the others to their units.

### 1.2 Architecture principle: no keys in the extension

```
VS Code extension ──(user's own bearer token)──► AIG platform-api ──(server-held keys)──► Portkey gateway ──► model providers
        │                                               │
        └── never talks to Portkey or a provider        └── adds keys, routing config, metadata, trace id; reports to Fiddler
```

- The extension MUST NOT receive, store, log or send a model-gateway (Portkey) key, and MUST NOT use VS Code
  SecretStorage.
- Its only credential is the signed-in user's own token: an Entra ID access token, or `dev:<email>` against a
  local backend. That token goes only to the configured backend URL.
- The backend drops any `x-portkey-*` header a client sends.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Language | TypeScript 5.5+, `strict`, `noUnusedLocals`, `noImplicitReturns`, `isolatedModules`; ES2022 modules, `moduleResolution: Bundler` |
| VS Code | `engines.vscode: ^1.90.0` (first version where the Chat participant API is stable). `@types/vscode` MUST be `~1.90.0` and match `engines` (enforced by a test) |
| Node | Node 22 / npm 10 for development (`.nvmrc` at the repo root). Extension host bundle targets `node18` |
| Bundler | esbuild 0.23. Two contexts: the extension host (`src/extension.ts` → `dist/extension.js`, CJS, platform node, externals `vscode`, `bufferutil`, `utf-8-validate`) and the webviews (IIFE, browser, `es2020`, entries `dashboard`, `sidebar`, `signin`, `agentrun` → `dist/webview/<app>.js`). Minified with no sourcemap in production; sourcemaps in watch/dev |
| Runtime dependencies | Only `ws` ^8. The VSIX is packaged with `--no-dependencies`, so everything else is bundled |
| Monorepo source bundled through aliases (`aliases.mjs`, mirrored in `tsconfig.json` `paths` and `vitest.config.mjs`) | `@aig/sdk/platform` → `../sdk/typescript/src/platform/index.ts` (backend mode of the AIG SDK); `@aig/ui` → `../web/packages/ui/src/index.ts` (widgets, message types, shell, CSS); `@aig/design-tokens` → `../web/packages/design-tokens/src/index.ts`; `@aig/demo-data` → `../web/packages/demo-data/src/index.ts` (temporary) |
| Tests | vitest 2, `environment: node`, `test/**/*.test.ts`. Logic that needs no `vscode` lives in modules that do not import `vscode` and is unit tested directly; `vscode` and `ws` are mocked for host tests |
| Packaging | `npx @vscode/vsce package --no-dependencies --skip-license` |
| Platforms | macOS, Linux and Windows. Paths, venv layouts (`bin` vs `Scripts`, `.exe`), PATHEXT and shell quoting MUST be handled per platform |

## 3. Extension manifest (`package.json`)

### 3.1 Identity and activation

- `name: aig-ai-ecosystem`, `displayName: AIG AI Ecosystem`, `publisher: aig`, `icon: media/aig-icon.png`,
  `categories: ["Other", "AI"]`, `main: ./dist/extension.js`.
- `repository.url` holds a placeholder (`https://__AIG_REPO_URL__/aiecosystem`).
- `activationEvents: ["onStartupFinished", "onUri"]`.

### 3.2 Untrusted workspaces (FR-MAN-1)

`capabilities.untrustedWorkspaces.supported = "limited"`. Its `restrictedConfigurations` MUST equal the
machine-scoped settings list in section 4.2 exactly (enforced by a test against `MACHINE_SCOPED_SETTINGS` in
`src/trustedSettings.ts`).

### 3.3 Views

| Container / view | Definition |
|---|---|
| Activity Bar container | id `aig`, title `AIG AI Ecosystem`, icon `media/aig-activitybar.svg` |
| `aig.signin` | webview view "Welcome", `when: !aig.signedIn` |
| `aig.main` | webview view "AIG", `when: aig.signedIn`, `retainContextWhenHidden: true` |

The context key `aig.signedIn` is set by the live service (section 7).

### 3.4 Menus

| Menu | Entries |
|---|---|
| `view/title` on `aig.main` | `navigation@0` New Agent, `@1` Open Dashboard, `@2` Refresh, `@3` Sign Out; `1_user@1` Switch user; `2_claudeCode@1` Configure Claude Code, `@2` Claude Code status |
| `view/title` on `aig.signin` | `1_user@1` Sign in as… |
| `commandPalette` | `aig.refresh` and `aig.flociStatus` hidden (`when: false`). Run Agent, Register Existing Agent, Open Agents, Test model routing, Switch user, Configure Claude Code and Claude Code status only `when: aig.signedIn` |
| `editor/context` | Explain Selection (`aig@1`) and Fix Selection (`aig@2`), `when: editorHasSelection` |
| `explorer/context` | Run Evals `when: resourceFilename == aig-eval.yaml`; Update SDK `when: resourceFilename == pyproject.toml \|\| resourceFilename == package.json` |
| `editor/title` | Run Evals (navigation) on `aig-eval.yaml` |

### 3.5 Task definitions

- `aig-eval`: required `mode` (`online` | `offline`), optional `config` (path to `aig-eval.yaml`).
- `aig-setup`: required `step` (a label such as create .venv, pip install, npm install or pipx install).

### 3.6 Chat participant

id `aig.assistant`, name `aig`, fullName `AIG Assistant`, `isSticky: true`, commands `explain`, `fix`, `tests`
(section 9).

## 4. Settings

### 4.1 Settings list

| Setting | Type / values | Scope | Default | Meaning |
|---|---|---|---|---|
| `aig.environment` | `local` \| `dev` \| `stage` \| `prod` | machine | `dev` | Backend environment |
| `aig.backendUrls` | object `{local, dev, stage, prod}` (no extra keys) | machine | `local: http://localhost:8080`; others `https://__AIG_BACKEND_URL_<ENV>__` | Backend base URL per environment |
| `aig.auth.scopes` | object `{local, dev, stage, prod}` | machine | `api://__AIG_API_CLIENT_ID_<ENV>__/.default` | Entra ID scope per environment |
| `aig.jobProfile` | `underwriting` \| `claims` \| `operations` \| `general` | resource | `general` | Sent as `x-aig-job-profile`; the backend checks it against the user's allowed profiles |
| `aig.devUser` | string (email) | machine | `""` | Local only: skip the browser and use `dev:<email>`. Ignored outside `local` |
| `aig.host` | `laptop` \| `vdi` | (default) | `laptop` | Written as `AIG_HOST` into the `.env` of new agents |
| `aig.cli.path` | string | machine | `aig` | `aig` CLI. `aig` means: the agent's `.venv` first, then `PATH`. An absolute path pins it |
| `aig.evals.loadDotenv` | boolean | (default) | `true` | Pass the agent folder's `.env` to `aig eval run`; variables already set win |
| `aig.sdk.source` | `registry` \| `bundled` \| `monorepo` | machine | `registry` | Where the SDK comes from (section 11) |
| `aig.sdk.indexUrl` | string | machine | `""` | pip `--index-url`. Ignored if it contains `__`, credentials, or a non-http(s) scheme |
| `aig.sdk.npmRegistry` | string | machine | `""` | `--@aig:registry`. Same rules as above |
| `aig.newAgent.setupEnvironment` | boolean | (default) | `true` | New Agent creates the environment and runs `aig doctor` |
| `aig.floci.command` | string | machine | `floci` | Floci executable |
| `aig.floci.startArgs` | string[] | machine | `["start"]` | Start arguments |
| `aig.floci.stopArgs` | string[] | machine | `["stop"]` | Stop arguments. Empty means close the Floci terminal |
| `aig.floci.endpoint` | string | machine | `http://localhost:4566` | Floci endpoint |
| `aig.floci.region` | string | (default) | `us-east-1` | `AWS_REGION` / `AWS_DEFAULT_REGION` for terminals, only when not already set |
| `aig.floci.showStatusBar` | boolean | (default) | `true` | Floci status bar item and endpoint probing |
| `aig.claudeCode.shareSession` | boolean | machine | `true` | Write `~/.aig/credentials` for the `aig` CLI (section 13.3) |
| `aig.demoData` | boolean | window | `false` | **Temporary.** Sample data from an in-memory backend (section 14) |

### 4.2 Trusted (machine-scoped) settings (FR-CFG-1)

These settings MUST be declared `"scope": "machine"` AND read through `trustedValue()`. Workspace and folder values
are ignored, so a cloned repository cannot redirect the token, the executables or the package index:

`aig.environment`, `aig.backendUrls`, `aig.auth.scopes`, `aig.devUser`, `aig.cli.path`, `aig.floci.command`,
`aig.floci.startArgs`, `aig.floci.stopArgs`, `aig.floci.endpoint`, `aig.sdk.source`, `aig.sdk.indexUrl`,
`aig.sdk.npmRegistry`, `aig.claudeCode.shareSession`.

`trustedValue(inspect)` returns policy value > global (user/machine/remote) value > default. An object value is
shallow-merged over the default object, so a partial user map still falls back to the defaults for the other
environments.

### 4.3 Configuration resolution (FR-CFG-2), in pure `src/config.ts`

1. `env` = the setting if it is a valid environment, otherwise `dev`.
2. Backend URL = `backendUrls[env]` (or the default), validated with `validatePlatformUrl` from
   `@aig/sdk/platform`:
   - A value containing `__` is a placeholder and counts as **not configured**.
   - `http://` is allowed only when `env == local` and the host is `localhost`, `127.0.0.1` or `[::1]`.
     dev/stage/prod always require `https`, loopback included.
   - The URL is normalised without a trailing slash.
3. Auth plan:
   - `local`: if `aig.devUser` is empty → `localBrowser`; if it is a valid email → `dev {email}`; otherwise
     `unconfigured` ("aig.devUser is not a valid email").
   - other envs: a non-placeholder scope → `microsoft {scope}`; a placeholder → `unconfigured`.
   - demo mode overrides everything with `demo` (section 14).
4. `jobProfile` = the setting if valid, otherwise `general`.
5. `configured` is true only when the URL and the auth plan are both usable. `problems[]` lists human-readable
   reasons.
6. The not-configured message is exactly `AIG backend not configured for <env>`. When the environment is not
   configured the extension MUST make no network calls.

Email validation: `^[^\s@:]+@[^\s@:]+\.[^\s@:]+$`. Local sign-in emails are trimmed and lowercased.

Any change to `aig.*` settings MUST reload the config and refresh the state. If demo mode was switched off, the
demo backend's timers stop.

## 5. Authentication (FR-AUTH)

### 5.1 dev / stage / prod: Microsoft Entra ID

- FR-AUTH-1: Use `vscode.authentication.getSession('microsoft', [scope])`. Interactive (`createIfNone`) only on
  **AIG: Sign In**. Background checks are always `silent`. Tokens are fetched per call and never persisted or logged.
- FR-AUTH-2: React to `authentication.onDidChangeSessions` for the `microsoft` provider by refreshing state.
- Sign Out and Switch user show: "AIG uses your VS Code Microsoft account. Sign out from (or switch accounts in)
  the Accounts menu (bottom left)…".

### 5.2 local: browser sign-in

- FR-AUTH-3: **AIG: Sign In** with the `localBrowser` plan:
  1. Issue a one-time state nonce: 24 random bytes, base64url, TTL 10 minutes, consumed on use, expired entries
     pruned.
  2. Callback URI `<uriScheme>://aig.aig-ai-ecosystem/auth-callback`, passed through `env.asExternalUri`.
  3. Open `<backend>/auth/local/signin?redirect_uri=<cb>&state=<nonce>[&login_hint=<last email>]` with
     `env.openExternal`. Pass the already-encoded URL **as a string**: wrapping it in `vscode.Uri` double-encodes
     the escapes.
  4. Show "AIG: complete sign-in in your browser…", or an error if the browser could not open.
- FR-AUTH-4: The URI handler accepts only path `/auth-callback`, a state that was issued and has not expired, and
  a valid `email`. Otherwise it shows `AIG sign-in failed: <reason>` ("sign-in link expired or was not started
  from this VS Code window", "sign-in returned an invalid email"). It also refuses when the current config is not
  `local` + `localBrowser`. On success it stores the email, refreshes, focuses the Token usage tab and shows
  `AIG: signed in as <email> (local)`.
- FR-AUTH-5: The local session is stored in `globalState`: key `aig.localSignIn` maps backend URL → email, and key
  `aig.localSignIn.last` keeps the last email after sign-out to prefill the field. Only the email is stored. The
  token is `dev:<email>`, which only an `AIG_ENV=local` + `AIG_AUTH_MODE=dev` backend accepts.

### 5.3 local: email sign-in and switching users

- FR-AUTH-6: `aig.signIn <email>` (posted by the sign-in widget's email field or persona picker) and
  **AIG: Sign in as…** sign in directly as that email, with no browser round trip.
- FR-AUTH-7: **AIG: Sign in as…** and **AIG: Switch user** show a QuickPick of `LOCAL_PERSONAS` (from `@aig/ui`)
  with the current user marked "(signed in)", plus "Enter another email…" (an InputBox prefilled with the last
  user and validated). Cancelling keeps the current user.
- FR-AUTH-8: Before an email sign-in:
  - if demo mode is on, offer "Turn off sample data"
  - if `env != local`, refuse ("only available in the local environment")
  - if `aig.devUser` is set, offer "Clear aig.devUser", because it always overrides the local session.
- Local personas (`web/packages/ui/src/messages.ts`): `premium.quality@`, `premium.balanced@`,
  `premium.economy@`, `standard.quality@`, `standard.balanced@`, `free.quality@`, `free.balanced@`,
  `finance.user@`, `routing.admin@`, `usage.limit@`, `usage.standard@`, `usage.tokens@` (all `@aig.example`).

### 5.4 Sign out (FR-AUTH-9)

- demo: end the demo session.
- localBrowser: clear the session for the backend URL and show "AIG: signed out (local)".
- microsoft: point the user to the Accounts menu.
- devUser: show "nothing to sign out of (aig.devUser is set in settings)".

## 6. Connection state, status bar and status panel

### 6.1 State refresh (FR-STATE-1)

`AigState.refresh()` never prompts. It calls `GET /healthz`. If that answers and a session exists, it also calls
`GET /api/v1/session`. Refreshes are numbered and only the newest result is published, so stale results are
dropped. Listeners receive a `Snapshot {config, status, health?, session?, checkedAt?}`.

`/api/v1/session` MUST contain `user.email` (string), `env` (string) and `llm.base_url` (string). Otherwise it is
treated as an `invalid_session` error. Optional fields (`user.name`, `team`, `user_tier`, `cost_mode`,
`allowed_job_profiles[]`, `llm.config_id`, `fiddler.url`) are dropped when they have the wrong type.
`llm.base_url` is informational only: model calls always go to the configured backend URL, never to a URL taken
from a response.

### 6.2 Connection states (FR-STATE-2), evaluated in this order

| State | Condition | Label | Detail |
|---|---|---|---|
| `not_configured` | config not configured | not configured | `AIG backend not configured for <env> (<problems>)` |
| `unreachable` | health error or no response | unreachable | `Backend health check failed[ (HTTP n)]: <msg>` |
| `error` | `health.status != "ok"` | error | `Backend reports status "<s>"` |
| `env_mismatch` | `health.env` differs from the configured env | environment mismatch | `Extension is set to X but backend reports Y` |
| `signed_out` | no session | signed out | `Backend reachable. Run "AIG: Sign In".` |
| `unauthenticated` | session 401/403 | not authorised | `Backend rejected your session (HTTP n)` |
| `error` / `unreachable` | other session errors | | `Session request failed…` |
| `degraded` | the required server secret is not `configured` in `health.secrets` | degraded | `Connected, but backend reports required server-side secret not configured: <names>` |
| `connected` | otherwise | connected | `Connected to <env> as <email>` |

The only required secret is the gateway key. Its name MUST be assembled from fragments (`['PORTKEY','API','KEY'].join('_')`)
so the no-secrets guard still forbids the literal anywhere in `src/`. Only names and status words are ever shown.
Optional secrets are informational and never cause `degraded`.

### 6.3 Status bar (FR-STATE-3)

- Item id `aig.status`, left-aligned, priority 100, command `aig.openDashboard`.
- Text: `$(pass-filled) AIG: <env> · connected` for connected and degraded. Otherwise `$(account)` (signed out),
  `$(warning)` (not configured, env mismatch) or `$(circle-slash)`, followed by `AIG: <env> · <label>`.
- Colour `#32c9a6` when connected and `#33b6ea` when signed out. Background `statusBarItem.warningBackground` for
  degraded and env mismatch, `statusBarItem.errorBackground` for unauthenticated and error.
- Tooltip: the detail text plus "Click to open the AIG dashboard."

### 6.4 Backend error messages (FR-STATE-4, `describeBackendError`)

| Condition | Message |
|---|---|
| `portkey_key_not_configured` | "The <env> backend is running but its model-gateway key has not been configured yet. Ask the platform team to load it on the backend." |
| `usage_not_configured` | "Usage reporting is not enabled on the <env> backend." |
| no status (network) | "Could not reach the AIG backend (…)." |
| 400 | "Request rejected by backend: …" |
| 401 | "Not signed in or session expired. Run "AIG: Sign In"." |
| 403 | "You are not authorised for this action on the AIG backend." |
| 429 | "Rate limited by the AIG platform. Try again shortly." |
| 504 | "The model gateway timed out. Try again." |
| 5xx | "AIG backend error (HTTP n)[: msg]" |

Messages never echo headers or tokens.

### 6.5 Status panel (FR-STATE-5): **AIG: Open Status Panel**

A single editor webview (`aig.status`), with a nonce CSP and server-rendered HTML themed from
`@aig/design-tokens`. Light, dark and high-contrast themes all work; high contrast defers to `--vscode-*`
variables. It has four cards:

- Connection: state dot, detail, problems, backend URL, job profile, last checked.
- Session: user, team, tier, job profiles, LLM endpoint (informational), routing config id, Fiddler URL.
- Backend secrets: name, required or optional, and status, with a note that keys live only on the backend.
- Actions: Dashboard, Refresh, Sign in, Switch environment, Ask.

Accepted messages are limited to `refresh`, `signIn`, `selectEnvironment`, `ask` and `openDashboard`.

## Non-functional requirements for this unit

| Id | Requirement |
|---|---|
| NFR-SEC-1 | No gateway keys. `src/`, `web/packages/ui/src`, `sdk/typescript/src/platform` and `sdk/typescript/src/core` MUST NOT contain: the `x-portkey-api-key` header, any `x-portkey-` header, the `PORTKEY_API_KEY` or `PORTKEY_ADMIN_API_KEY` names, `SecretStorage`, or `.secrets.store/get/delete`. Enforced by `test/no-secrets.guard.test.ts`, whose patterns are assembled from fragments |
| NFR-SEC-2 | The bearer token goes only to the configured backend: in the HTTP `Authorization` header and on the WebSocket upgrade, never in a URL, a log or a webview |
| NFR-SEC-3 | Security-sensitive settings come from user, machine or policy scope only (section 4.2) |
| NFR-SEC-8 | URL settings with credentials or `__` placeholders are ignored. Plain http only for loopback in `local` |
| NFR-SEC-9 | Local browser sign-in uses a one-time, expiring state nonce |

## 16. Backend contract consumed

All calls go through `@aig/sdk/platform` with the signed-in user's token. Headers: `Authorization: Bearer <token>`,
`x-aig-job-profile`, `x-aig-trace-id`, and `x-aig-agent-id` where applicable (see `backend/contracts/headers.md`).

| Method and path | Used by |
|---|---|
| `GET /healthz` | state refresh (`status`, `env`, `secrets{name: configured\|placeholder\|missing}`) |
| `GET /api/v1/session` | state refresh, InitInfo |
| `GET <backend>/auth/local/signin` (browser) | local sign-in |

Error codes the UI handles specially: `portkey_key_not_configured` (503), `usage_not_configured`,
`agent_invocation_disabled` (503), `agent_exists` (409), `invocation_not_found`, `claude_code_not_configured`
(503), `invalid_session`, `not_connected`, `cancelled`, `network_error`, `timeout`.

### 17.1 Scripts (`vscode-extension/package.json`)

| Script | Does |
|---|---|
| `prepare:assets` | `node scripts/prepare.mjs` |
| `build` | `prepare.mjs --sdk-artifacts && esbuild.mjs --production` |
| `watch` | prepare + esbuild watch |
| `typecheck` | prepare + `tsc --noEmit -p .` |
| `test` | prepare + `vitest run` |
| `package` | `npx @vscode/vsce package --no-dependencies --skip-license` |
| `vscode:prepublish` | `npm run build` |

### 17.2 `scripts/prepare.mjs` (FR-BUILD-1)

Runs before build, typecheck and test:

1. Copy the brand assets from `web/packages/brand-assets` into `media/`: `svg/aig-logo.svg`, `aig-logo-white.svg`,
   `aig-activitybar.svg`, `aig-icon.svg`, `png/aig-icon-128.png` → `aig-icon.png`, `fonts/inter-var.woff2`,
   `fonts/jetbrains-mono-var.woff2`. Skip an asset when a packaged copy already exists and the monorepo is absent.
2. Bundle `sdk/templates/*` (each template has an `aig-template.json`) into `dist/templates.json`:
   `{schema: "aig-templates/v1", templates: [{name, description, language, framework, placeholders, sdk_paths, exclude, files: [{path, text|base64, executable}]}], sdk: {python, typescript}}`.
   Exclude `.venv`, `node_modules`, `__pycache__`, `.aig-eval-report*`, caches, `.env` and lock files. Fail if
   there are no templates.
3. With `--sdk-artifacts`: the repo's `scripts/sdk-artifacts.mjs` builds the aig-sdk wheel
   (`pip wheel --no-deps sdk/python`) and the `@aig/sdk` tarball (`npm pack sdk/typescript`) into `dist/sdk/` with
   `manifest.json` `{python: {version, file}, typescript: {version, file}}`, and fails over the size budget.
   `AIG_SKIP_SDK_ARTIFACTS=1` skips this (registry source only).

## Verification for this unit

| Area | Test file(s) |
|---|---|
| Config, placeholders, URL rules | `config.test.ts` |
| Machine scope and untrusted-workspace list | `settings-scope.test.ts` |
| Manifest: every command registered, menus valid, engines matches `@types/vscode`, task types, palette `when` clauses, version, demo off by default | `manifest.test.ts` |
| No gateway keys | `no-secrets.guard.test.ts` |
| Status mapping and messages | `status.test.ts` |
| Local sign-in, Sign in as… | `localSignIn.test.ts`, `signInAs.test.ts` |
| Status panel HTML | `panel.test.ts` |

| # | Scenario | Expected |
|---|---|---|
| A1 | Fresh install with default settings (`dev`, placeholder URL) | Status bar `$(warning) AIG: dev · not configured`; Sign In shows "AIG backend not configured for dev: …"; no network calls |
| A2 | Workspace `.vscode/settings.json` sets `aig.backendUrls.dev` to another host | Ignored; the user-scope value is used |
| A3 | `local` env, backend `AIG_ENV=local AIG_AUTH_MODE=dev`, Sign In | Browser opens `/auth/local/signin` with state; after submit, VS Code shows "signed in as …", the sidebar shows the tabs, usage loads once |
| A4 | Callback with an unknown or expired state | "AIG sign-in failed: sign-in link expired or was not started from this VS Code window" |
| A18 | `grep` the built `dist/` and `src/` for gateway-key names | No matches (guard test) |
