# AIG AI Ecosystem VS Code Extension, unit U3: Coding assistant

This is an excerpt of the full extension specification (baseline 0.16.0) for one unit of work: **U3 Coding
assistant** (FR-CHAT-1..4). The other units (manifest, settings and sign-in; live connection, sidebar and
dashboard; agents; New Agent and SDK; evals; Floci; Claude Code; demo mode; packaging) are separate work items
and are out of scope here. This unit uses them as existing dependencies: sign-in state and the `aig.signIn`
command, the backend client and chat streaming, the sidebar Chat composer, the `AIG` output channel and
`describeBackendError`.

### 1.2 Architecture principle: no keys in the extension

```
VS Code extension ──(user's own bearer token)──► AIG platform-api ──(server-held keys)──► Portkey gateway ──► model providers
        │                                               │
        └── never talks to Portkey or a provider        └── adds keys, routing config, metadata, trace id; reports to Fiddler
```

- The extension MUST NOT receive, store, log or send a model-gateway (Portkey) key, and MUST NOT use VS Code
  SecretStorage.
- Its only credential is the signed-in user's own token: an Entra ID access token, or `dev:<email>` against a
  local backend. That token goes only to the configured backend URL.
- The backend drops any `x-portkey-*` header a client sends.

## 2. Technical constraints

| Area | Requirement |
|---|---|
| Language | TypeScript 5.5+, `strict`, `noUnusedLocals`, `noImplicitReturns`, `isolatedModules`; ES2022 modules, `moduleResolution: Bundler` |
| VS Code | `engines.vscode: ^1.90.0` (first version where the Chat participant API is stable). `@types/vscode` MUST be `~1.90.0` and match `engines` (enforced by a test) |
| Node | Node 22 / npm 10 for development (`.nvmrc` at the repo root). Extension host bundle targets `node18` |
| Bundler | esbuild 0.23. Two contexts: the extension host (`src/extension.ts` → `dist/extension.js`, CJS, platform node, externals `vscode`, `bufferutil`, `utf-8-validate`) and the webviews (IIFE, browser, `es2020`, entries `dashboard`, `sidebar`, `signin`, `agentrun` → `dist/webview/<app>.js`). Minified with no sourcemap in production; sourcemaps in watch/dev |
| Runtime dependencies | Only `ws` ^8. The VSIX is packaged with `--no-dependencies`, so everything else is bundled |
| Monorepo source bundled through aliases (`aliases.mjs`, mirrored in `tsconfig.json` `paths` and `vitest.config.mjs`) | `@aig/sdk/platform` → `../sdk/typescript/src/platform/index.ts` (backend mode of the AIG SDK); `@aig/ui` → `../web/packages/ui/src/index.ts` (widgets, message types, shell, CSS); `@aig/design-tokens` → `../web/packages/design-tokens/src/index.ts`; `@aig/demo-data` → `../web/packages/demo-data/src/index.ts` (temporary) |
| Tests | vitest 2, `environment: node`, `test/**/*.test.ts`. Logic that needs no `vscode` lives in modules that do not import `vscode` and is unit tested directly; `vscode` and `ws` are mocked for host tests |
| Packaging | `npx @vscode/vsce package --no-dependencies --skip-license` |
| Platforms | macOS, Linux and Windows. Paths, venv layouts (`bin` vs `Scripts`, `.exe`), PATHEXT and shell quoting MUST be handled per platform |


## 9. Coding assistant

### 9.1 `@aig` chat participant (FR-CHAT-1)

- Register only when `vscode.chat.createChatParticipant` exists (older hosts: no-op). Icon `media/aig-icon.png`.
- Signed out: reply "You are not signed in to the AIG platform." with a **AIG: Sign In** button.
- Slash commands come from `request.command`, or are parsed from the prompt (`/fix handle nulls`). Unknown
  commands stay as text.
- Context order:
  1. explicit references (`#file`, `#selection`, a `Location` or `Uri`, not `untitled`); the first readable one wins
  2. otherwise the active editor's selection, or the whole file, but only when a slash command is used or the
     prompt matches the context hint (for example "this function", "the selected code", `#selection`, "explain it")
- With no prompt and no context, reply with guidance. When context is used, call `stream.reference()`.
- History: this participant's earlier turns only, the last 10, within budget, starting with a user turn.
- Limits: 24,000 characters of code context and about 40,000 characters per request, to stay under the backend's
  64 KiB WebSocket frame. Truncation is marked `… [truncated N characters]`.
- Code fences use more backticks than any run inside the code. Language ids are mapped (`typescriptreact`→`tsx`,
  `javascriptreact`→`jsx`, `shellscript`→`bash`).
- Base system prompt: "You are the AIG coding assistant inside VS Code, served through the AIG model gateway. Be
  concise and precise. Use Markdown; put code in fenced blocks with a language. Never ask for or reveal API keys
  or credentials. If code context is provided, base the answer on it and say when something cannot be determined
  from it."
- Per-command tasks:
  - `explain`: summary, how it works, edge cases, risks.
  - `fix`: list problems, then the corrected code in one block.
  - `tests`: pytest or vitest/jest, covering normal, edge and error cases, in one block.
- Default asks when the prompt is empty: "Explain this code." / "Fix the problems in this code." / "Write unit
  tests for this code."
- Progress text "Asking the AIG gateway (<jobProfile>)…". Stream deltas as markdown. Cancellation cancels the
  stream. The result metadata holds the command, trace id, tokens, model and route. `portkey_key_not_configured`
  maps to "The Portkey gateway key is not configured on the AIG backend."
- Follow-ups: after `explain` → "Write tests for it" (`tests`); after `fix` → "Write tests for the fix".

### 9.2 Explain / Fix Selection (FR-CHAT-2)

These editor context menu commands require a non-empty selection or file ("AIG: open a file and select some code
first."). They prefill the sidebar Chat composer with an ask plus the formatted context (up to 30,000 characters)
and do not send. The user reviews and presses Enter.

### 9.3 AIG: Ask (FR-CHAT-3)

Takes an InputBox prompt (or an argument). Streams over HTTP SSE with `x-aig-job-profile` and a new
`x-aig-trace-id` into the `AIG` output channel: `> prompt`, `[ask] env=… profile=… trace=…`, deltas, then
`[ask] done trace=…`. If the stream ended without `[DONE]` it warns "response may be incomplete". The notification
progress is cancellable. Errors go through `describeBackendError`.

### 9.4 AIG: Test model routing (FR-CHAT-4)

Requires sign-in. Picks a job profile: the configured one first if it is allowed, then the user's other allowed
profiles; skipped when only one profile exists. Calls `POST /api/v1/routing/test {job_profile}`. Shows
`Routing: <model> · <tier> · <cost mode> · <profile> — <ms> ms (<provider>)` and, when the usage state is not
normal, ` · usage soft: downgraded because daily requests 4 / 5` or similar.

Actions:

- **Copy trace id**.
- **Details**: a QuickPick of rows (Result, Model, Provider, Tier, Cost mode, Job profile, Usage state, Latency,
  Tokens, Cache, Answer, Error, Trace id). Selecting a row copies its value.

All rows are also logged to the output channel as `[routing] key=value …`.

## Verification for this unit

| Area | Test file(s) |
|---|---|
| Chat prompt building | `chatPrompt.test.ts` |
| Routing test formatting | `routing.test.ts` |

| # | Scenario | Expected |
|---|---|---|
| A8 | `@aig /explain` with a selection | Reference to the selection shown; streamed explanation; follow-up "Write tests for it" |
| A9 | Backend gateway key is a placeholder | Status `degraded`; Ask shows the "model-gateway key has not been configured" message |
