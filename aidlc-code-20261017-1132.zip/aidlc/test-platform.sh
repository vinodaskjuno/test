#!/bin/bash
set -euo pipefail

AIDLC_ROOT="/Users/vinoth/github/aidlc"
cd "$AIDLC_ROOT"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() { echo -e "${BLUE}▸${NC} $*"; }
log_ok() { echo -e "${GREEN}✓${NC} $*"; }
log_warn() { echo -e "${YELLOW}⚠${NC} $*"; }
log_error() { echo -e "${RED}✗${NC} $*"; }

log_header() {
  echo ""
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${BLUE}$*${NC}"
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Step 0: Setup worker model access
log_header "STEP 0: Setup Worker Model Access"

if ! command -v aws &> /dev/null; then
  log_error "AWS CLI not found. Install it first: brew install awscli"
  exit 1
fi

# Agents run on Claude through Amazon Bedrock with the AWS default credential chain:
# `aws login`, an SSO profile (AWS_PROFILE) or exported access keys. There is no Anthropic API fallback.
export AWS_REGION="${AWS_REGION:-us-east-1}"
export AWS_DEFAULT_REGION="$AWS_REGION"
# Every agent runs on Sonnet for testing. Set SONNET_MODEL_ID to the account's inference-profile id
# (Bedrock console → Cross-region inference, or: aws bedrock list-inference-profiles).
SONNET_MODEL_ID="${SONNET_MODEL_ID:-us.anthropic.claude-sonnet-4-6}"  # newest Sonnet this account can invoke

if env | grep -q '^AWS_ENDPOINT_URL'; then
  log_error "An AWS_ENDPOINT_URL* variable is set, so AWS calls go to a local emulator instead of Bedrock:"
  env | grep '^AWS_ENDPOINT_URL' | cut -d= -f1 | sed 's/^/    /'
  log_info "Unset them first, e.g.: unset AWS_ENDPOINT_URL"
  exit 1
fi

log_info "Checking AWS credentials..."
if ! AWS_ACCOUNT=$(aws sts get-caller-identity --query Account --output text 2>/dev/null); then
  log_error "No valid AWS credentials. Sign in first:"
  log_info "  aws login                                   # browser sign-in with your console user"
  log_info "  or: aws sso login --profile <p> && export AWS_PROFILE=<p>"
  exit 1
fi
if [ "$AWS_ACCOUNT" = "000000000000" ]; then
  log_error "AWS account 000000000000 belongs to a local AWS emulator, not real AWS"
  log_info "Unset the emulator's keys (unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN) and run: aws login"
  exit 1
fi
log_ok "AWS account: $AWS_ACCOUNT ($AWS_REGION)"

log_info "Checking Bedrock access to $SONNET_MODEL_ID..."
if ! BEDROCK_ERR=$(aws bedrock-runtime converse --region "$AWS_REGION" --model-id "$SONNET_MODEL_ID" \
  --messages '[{"role":"user","content":[{"text":"ping"}]}]' --inference-config maxTokens=1 2>&1 >/dev/null); then
  log_error "Bedrock call failed: $BEDROCK_ERR"
  log_info "Use an inference-profile id: SONNET_MODEL_ID=<id> ./test-platform.sh"
  log_info "List them: aws bedrock list-inference-profiles --region $AWS_REGION --query \"inferenceProfileSummaries[?contains(inferenceProfileId,'sonnet')].inferenceProfileId\""
  exit 1
fi
log_ok "Bedrock answers on $SONNET_MODEL_ID"

source var/local/env.sh

# Temporal must be reachable before the worker starts (the worker exits if it cannot connect)
TEMPORAL_HOST="${AIDLC_TEMPORAL_ADDRESS%:*}"
TEMPORAL_PORT="${AIDLC_TEMPORAL_ADDRESS##*:}"
port_listening() { lsof -nP -iTCP:"$1" -sTCP:LISTEN -t &>/dev/null; }

if port_listening "$TEMPORAL_PORT"; then
  log_ok "Temporal is running on $AIDLC_TEMPORAL_ADDRESS"
else
  # No `temporal` on PATH: fall back to the dev server the Temporal Python SDK downloads into $TMPDIR
  TEMPORAL_BIN="${TEMPORAL_BIN:-$(command -v temporal || true)}"
  if [ -z "$TEMPORAL_BIN" ]; then
    TEMPORAL_BIN=$(ls "${TMPDIR:-/tmp}"/temporal-sdk-python-* 2>/dev/null | sort | tail -1 || true)
  fi
  if [ -z "$TEMPORAL_BIN" ] || [ ! -x "$TEMPORAL_BIN" ]; then
    log_error "Temporal is not running and no Temporal CLI was found"
    log_info "Install it (brew install temporal) or set TEMPORAL_BIN to the CLI binary"
    exit 1
  fi
  log_info "Starting Temporal dev server ($TEMPORAL_BIN)..."
  nohup "$TEMPORAL_BIN" server start-dev --ip "$TEMPORAL_HOST" --port "$TEMPORAL_PORT" \
    --db-filename var/local/temporal.db >> var/local/temporal.log 2>&1 &
  TEMPORAL_PID=$!
  for _ in $(seq 1 30); do
    port_listening "$TEMPORAL_PORT" && break
    if ! kill -0 "$TEMPORAL_PID" 2>/dev/null; then
      log_error "Temporal exited during startup. Last log lines:"
      tail -20 var/local/temporal.log
      exit 1
    fi
    sleep 1
  done
  if ! port_listening "$TEMPORAL_PORT"; then
    log_error "Temporal did not start listening on $AIDLC_TEMPORAL_ADDRESS within 30s (see var/local/temporal.log)"
    exit 1
  fi
  log_ok "Temporal started (PID: $TEMPORAL_PID, UI: http://localhost:8233, logs: var/local/temporal.log)"
fi

# Restart the API so it serves the current code (a long-running API silently ignores newer request fields,
# such as the economy flag)
API_PORT="${AIDLC_API_PORT:-8000}"
if port_listening "$API_PORT"; then
  log_info "Restarting the API..."
  lsof -tiTCP:"$API_PORT" -sTCP:LISTEN | xargs kill 2>/dev/null || true
  sleep 1
fi
nohup .venv/bin/aidlc-api >> var/local/api.log 2>&1 &
for _ in $(seq 1 30); do
  curl -sf -o /dev/null "http://localhost:$API_PORT/api/v1/config" && break
  sleep 1
done
if ! curl -sf -o /dev/null "http://localhost:$API_PORT/api/v1/config"; then
  log_error "API did not start on :$API_PORT (see var/local/api.log)"
  exit 1
fi
log_ok "API is running on :$API_PORT"

# Kill any running worker on port 9464
if lsof -i :9464 -sTCP:LISTEN -t &>/dev/null; then
  log_info "Stopping existing worker..."
  lsof -tiTCP:9464 -sTCP:LISTEN | xargs kill 2>/dev/null || true
  sleep 1
fi

# Worker environment: Claude on Bedrock, every agent.yaml model name mapped to the one Sonnet id
unset ANTHROPIC_API_KEY
export AIDLC_BEDROCK_ENABLED=true
export AIDLC_AWS_REGION="$AWS_REGION"
export AIDLC_BEDROCK_MODEL_MAP="{\"claude-opus-5-5\":\"$SONNET_MODEL_ID\",\"claude-sonnet-5-5\":\"$SONNET_MODEL_ID\",\"claude-haiku-5-5\":\"$SONNET_MODEL_ID\"}"
log_ok "Using Amazon Bedrock in $AWS_REGION; all agents use Sonnet ($SONNET_MODEL_ID)"

# Start the worker
log_info "Starting worker..."
.venv/bin/aidlc-worker > var/local/worker.log 2>&1 &
WORKER_PID=$!
log_ok "Worker started (PID: $WORKER_PID)"
# Agent calls stream from Bedrock for many minutes; a sleeping Mac drops them. Stay awake while the worker runs
# (idle sleep always; system sleep too when on power — closing the lid on battery still sleeps).
caffeinate -is -w "$WORKER_PID" &
log_ok "Keeping the Mac awake while the worker runs (caffeinate)"
log_info "Logs: tail -f var/local/worker.log"

# Wait for worker to be ready. It binds the metrics port before connecting to Temporal, so it must also
# stay alive for a few seconds after that (a failed connect makes it exit).
log_info "Waiting for worker to initialize..."
ALIVE_SINCE_READY=0
for _ in $(seq 1 30); do
  if ! kill -0 "$WORKER_PID" 2>/dev/null; then
    log_error "Worker exited during startup. Last log lines:"
    tail -20 var/local/worker.log
    exit 1
  fi
  if port_listening "$AIDLC_WORKER_METRICS_PORT"; then
    ALIVE_SINCE_READY=$((ALIVE_SINCE_READY + 1))
    [ "$ALIVE_SINCE_READY" -ge 5 ] && break
  fi
  sleep 1
done
if [ "$ALIVE_SINCE_READY" -lt 5 ]; then
  log_error "Worker did not become ready within 30s (see var/local/worker.log)"
  exit 1
fi
log_ok "Worker is ready (metrics on :$AIDLC_WORKER_METRICS_PORT)"

# AIDLC web console (control-plane/web). Reuse one already serving; never fight another app for the port.
WEB_PORT="${AIDLC_WEB_PORT:-3000}"
if curl -s "http://localhost:$WEB_PORT/signin" 2>/dev/null | grep -q "<title>AIDLC"; then
  log_ok "Web console already running on :$WEB_PORT"
elif port_listening "$WEB_PORT"; then
  OTHER_PID=$(lsof -nP -iTCP:"$WEB_PORT" -sTCP:LISTEN -t | head -1)
  log_warn "Port $WEB_PORT is used by another app (PID $OTHER_PID: $(ps -o command= -p "$OTHER_PID" | cut -c1-80))"
  log_info "Stop it (kill $OTHER_PID) or set AIDLC_WEB_PORT; continuing without the web console"
else
  log_info "Starting the web console on :$WEB_PORT..."
  (cd control-plane/web && nohup npx next dev -p "$WEB_PORT" >> ../../var/local/web-ui.log 2>&1 &)
  for _ in $(seq 1 60); do
    curl -s "http://localhost:$WEB_PORT/signin" 2>/dev/null | grep -q "<title>AIDLC" && break
    sleep 1
  done
  if curl -s "http://localhost:$WEB_PORT/signin" 2>/dev/null | grep -q "<title>AIDLC"; then
    log_ok "Web console running on :$WEB_PORT"
  else
    log_warn "Web console did not start (see var/local/web-ui.log)"
  fi
fi

# Step 1: Use aidlc CLI
log_header "STEP 1: CLI Testing (scriptable, works in CI)"

export AIDLC_API_URL=http://localhost:8000
A=.venv/bin/aidlc

# Sign in (dev mode doesn't require a password)
log_info "Signing in as admin@acme.test..."
$A login --dev admin@acme.test > /dev/null 2>&1 || true
log_ok "Signed in"

# Verify identity
log_info "Checking current user..."
USER_INFO=$($A whoami --json)
USER_EMAIL=$(echo "$USER_INFO" | .venv/bin/python -c "import sys, json; print(json.load(sys.stdin)['user']['id'])")
log_ok "User: $USER_EMAIL"

# List projects
log_info "Listing projects..."
PROJECTS=$($A projects --json)
PROJECT_COUNT=$(echo "$PROJECTS" | .venv/bin/python -c "import sys, json; print(len(json.load(sys.stdin)))")
log_ok "Found $PROJECT_COUNT projects"

# Run doctor check
log_info "Running doctor for storefront project..."
set +e
DOCTOR=$($A doctor --project storefront --json 2>/dev/null)
DOCTOR_EXIT=$?
set -e
DOCTOR_FAILS=$(echo "$DOCTOR" | .venv/bin/python -c "
import sys, json
for c in json.load(sys.stdin).get('checks', []):
    if c.get('status') == 'fail':
        print(f\"  {c['name']}: {c.get('detail', '')}\" + (f\"\n    fix: {c['fix']}\" if c.get('fix') else ''))
" 2>/dev/null || true)
if [ "$DOCTOR_EXIT" -eq 0 ]; then
  log_ok "Doctor: all checks passed"
elif [ -n "$DOCTOR_FAILS" ]; then
  log_error "Doctor found problems:"
  echo "$DOCTOR_FAILS"
  exit 1
else
  log_error "Doctor could not run (exit $DOCTOR_EXIT). Is the API up at $AIDLC_API_URL? Run: $A doctor --project storefront"
  exit 1
fi

# Upload and run the spec under test
log_header "STEP 2: Run Feature Spec"

# Unit U3 (coding assistant) of /Users/vinoth/github/aiecosystem/docs/vscode-extension-spec.md.
# The full spec is too large for one run; it is kept at specs/vscode-extension-spec.md.
SPEC_FILE="${SPEC_FILE:-specs/vscode-extension-u3-coding-assistant.md}"
SPEC_PROJECT="${SPEC_PROJECT:-storefront}"
SPEC_TITLE="${SPEC_TITLE:-AIG VS Code extension: coding assistant}"
if [ ! -f "$SPEC_FILE" ]; then
  log_error "Spec not found: $SPEC_FILE"
  exit 1
fi

RUN_CMD=("$A" run "$SPEC_FILE" --project "$SPEC_PROJECT" --title "$SPEC_TITLE" --watch)
# Economy mode caps every agent's thinking effort and turns; ECONOMY=false runs with the agent.yaml values.
if [ "${ECONOMY:-true}" = "true" ]; then
  RUN_CMD+=(--economy)
fi
log_info "Command: ${RUN_CMD[*]}"

if [ "${RUN_SPEC:-true}" = "true" ]; then
  log_info "Uploading $SPEC_FILE to project $SPEC_PROJECT and watching the run..."
  set +e
  "${RUN_CMD[@]}"
  RUN_EXIT=$?
  set -e
  case $RUN_EXIT in
    0) log_ok "Run finished: pr-ready" ;;
    2) log_warn "Run blocked: answer Gate A questions with 'aidlc inbox --project $SPEC_PROJECT'" ;;
    3) log_error "Run failed (tests/checks)" ;;
    4) log_warn "Run cancelled" ;;
    *) log_error "Run exited with code $RUN_EXIT" ;;
  esac
  log_info "Inspect output: $A status --project $SPEC_PROJECT, then $A artifacts <run_id>"
else
  log_info "RUN_SPEC=false: not starting the run. To run it, execute:"
  echo "  cd $AIDLC_ROOT"
  echo "  source var/local/env.sh"
  echo "  export AIDLC_API_URL=http://localhost:8000"
  echo "  ${RUN_CMD[*]}"
  echo ""
fi
log_ok "Worker is ready for CLI commands"

# Show additional commands
log_header "Additional CLI Commands"
cat << 'EOF'
# Check run status
aidlc status [run_id]

# List inbox items (Gate A questions, escalations)
aidlc inbox --project storefront

# Answer a Gate A question
aidlc answer '<run_id>:Q-1' "your answer"

# View all runs
aidlc status --project storefront

# Get run artifacts
aidlc artifacts <run_id>

# Use --json for CI integration
aidlc run spec.md --project storefront --json

# Expected exit codes:
#   0 = pr-ready (success)
#   2 = blocked (human action needed)
#   3 = failed (tests/checks failed)
#   4 = cancelled (user cancelled)
EOF

echo ""
log_ok "Platform is ready for testing!"
log_info "Worker PID: $WORKER_PID (kill with: kill $WORKER_PID)"
log_info "API: http://localhost:8000"
log_info "Web console: http://localhost:$WEB_PORT (sign in as admin@acme.test)"
log_info "Temporal UI: http://localhost:8233"

# Optional: Keep the script running and show logs
if [ "${WATCH_LOGS:-false}" = "true" ]; then
  log_info "Watching worker logs (Ctrl+C to stop)..."
  trap "kill $WORKER_PID 2>/dev/null || true; exit 0" INT
  tail -f var/local/worker.log
fi
