"""Streamlit chat UI for the underwriting agent. Run: streamlit run ui.py --server.port 8502"""

import os
import uuid

import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8002")

st.set_page_config(page_title="Underwriting Assistant", page_icon="🏠")
st.title("🏠 Underwriting Assistant (Strands)")

if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())
    st.session_state.history = []

with st.sidebar:
    try:
        st.json(requests.get(f"{API_URL}/health", timeout=5).json())
    except requests.RequestException:
        st.error(f"API not reachable at {API_URL}")
    st.caption(f"Session: {st.session_state.session_id}")
    st.markdown("Try: *Quote APP-1001*, *Can we write APP-1002?*, *Assess APP-1003*")
    if st.button("New session"):
        requests.delete(f"{API_URL}/sessions/{st.session_state.session_id}", timeout=5)
        st.session_state.session_id = str(uuid.uuid4())
        st.session_state.history = []
        st.rerun()

for role, text in st.session_state.history:
    st.chat_message(role).markdown(text)

if prompt := st.chat_input("Ask about an applicant, e.g. 'Quote APP-1001 with a 2500 deductible'"):
    st.chat_message("user").markdown(prompt)
    st.session_state.history.append(("user", prompt))
    with st.chat_message("assistant"), st.spinner("Underwriting..."):
        r = requests.post(f"{API_URL}/invoke", json={"message": prompt, "session_id": st.session_state.session_id}, timeout=300)
        if r.ok:
            body = r.json()
            text = body["reply"] + (f"\n\n_Tools: {', '.join(body['tools_used'])}_" if body["tools_used"] else "")
        else:
            text = f"**Error {r.status_code}:** {r.text}"
        st.markdown(text)
    st.session_state.history.append(("assistant", text))
