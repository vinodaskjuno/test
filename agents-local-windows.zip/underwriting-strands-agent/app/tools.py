"""Homeowners underwriting tools over local mock data (app/data/*.json)."""

import json
from pathlib import Path

from strands import tool

DATA = Path(__file__).parent / "data"
APPLICANTS = json.loads((DATA / "applicants.json").read_text(encoding="utf-8"))
PROPERTIES = json.loads((DATA / "property_risk.json").read_text(encoding="utf-8"))
RATES = json.loads((DATA / "rate_table.json").read_text(encoding="utf-8"))
GUIDELINES = json.loads((DATA / "guidelines.json").read_text(encoding="utf-8"))


def _lookup(table, key, kind):
    if key not in table:
        raise ValueError(f"Unknown {kind} '{key}'. Known: {', '.join(table)}")
    return table[key]


def _risk_score(applicant, prop):
    factors = {
        "base": 10,
        "credit_tier": {"A": 0, "B": 5, "C": 15, "D": 25}[applicant["credit_tier"]],
        "prior_claims": 8 * applicant["prior_claims_5yr"],
        "flood_zone": {"X": 0, "AE": 20, "VE": 30}[prop["flood_zone"]],
        "wildfire": {"low": 0, "moderate": 10, "extreme": 30}[prop["wildfire_risk"]],
        "roof_age": 10 if prop["roof_age_years"] > 20 else 0,
        "fire_protection": 10 if prop["miles_to_fire_station"] > 5 else 0,
        "construction": 5 if prop["construction"] == "frame" else 0,
    }
    return min(sum(factors.values()), 100), factors


def _guideline_decision(applicant, prop):
    score, _ = _risk_score(applicant, prop)
    decline, refer = GUIDELINES["decline"], GUIDELINES["refer"]
    reasons = []
    if score >= decline["risk_score_at_or_above"]:
        reasons.append(f"risk score {score} >= {decline['risk_score_at_or_above']}")
    if applicant["prior_claims_5yr"] >= decline["prior_claims_5yr_at_or_above"]:
        reasons.append(f"{applicant['prior_claims_5yr']} prior claims in 5 years")
    if prop["wildfire_risk"] == "extreme" and prop["roof_age_years"] > decline["roof_age_over_with_extreme_wildfire"]:
        reasons.append(f"roof {prop['roof_age_years']} years old in extreme wildfire zone")
    if reasons:
        return {"decision": "decline", "risk_score": score, "reasons": reasons}

    if score >= refer["risk_score_at_or_above"]:
        reasons.append(f"risk score {score} >= {refer['risk_score_at_or_above']}")
    if prop["flood_zone"] in refer["flood_zones"]:
        reasons.append(f"property in flood zone {prop['flood_zone']}")
    if prop["replacement_cost"] > refer["replacement_cost_above"]:
        reasons.append(f"replacement cost ${prop['replacement_cost']:,} above ${refer['replacement_cost_above']:,}")
    if reasons:
        return {"decision": "refer", "risk_score": score, "reasons": reasons}
    return {"decision": "eligible", "risk_score": score, "reasons": []}


@tool
def get_applicant_profile(applicant_id: str) -> dict:
    """Get an applicant's profile: age, credit tier, prior claims, linked property and requested coverage.

    Args:
        applicant_id: Applicant ID, e.g. APP-1001.
    """
    return {"applicant_id": applicant_id, **_lookup(APPLICANTS, applicant_id, "applicant")}


@tool
def get_property_risk(property_id: str) -> dict:
    """Get a property's risk attributes: construction, roof age, flood zone, wildfire risk, replacement cost.

    Args:
        property_id: Property ID, e.g. PROP-2001.
    """
    return {"property_id": property_id, **_lookup(PROPERTIES, property_id, "property")}


@tool
def calculate_risk_score(applicant_id: str) -> dict:
    """Calculate the 0-100 risk score (higher is riskier) for an applicant and their property, with factor breakdown.

    Args:
        applicant_id: Applicant ID, e.g. APP-1001.
    """
    applicant = _lookup(APPLICANTS, applicant_id, "applicant")
    score, factors = _risk_score(applicant, _lookup(PROPERTIES, applicant["property_id"], "property"))
    return {"applicant_id": applicant_id, "risk_score": score, "factors": factors}


@tool
def check_guidelines(applicant_id: str) -> dict:
    """Check underwriting guidelines. Returns decision 'eligible', 'refer' (needs senior underwriter) or 'decline', with reasons.

    Args:
        applicant_id: Applicant ID, e.g. APP-1001.
    """
    applicant = _lookup(APPLICANTS, applicant_id, "applicant")
    prop = _lookup(PROPERTIES, applicant["property_id"], "property")
    return {"applicant_id": applicant_id, **_guideline_decision(applicant, prop)}


@tool
def lookup_rate(applicant_id: str) -> dict:
    """Look up the base rate per $1,000 of coverage and the rating modifiers that apply to this applicant.

    Args:
        applicant_id: Applicant ID, e.g. APP-1001.
    """
    applicant = _lookup(APPLICANTS, applicant_id, "applicant")
    prop = _lookup(PROPERTIES, applicant["property_id"], "property")
    mods = RATES["modifiers"]
    modifiers = {
        "flood_zone": mods["flood_zone"][prop["flood_zone"]],
        "wildfire_risk": mods["wildfire_risk"][prop["wildfire_risk"]],
        "credit_tier": mods["credit_tier"][applicant["credit_tier"]],
        "prior_claims": mods["per_prior_claim"] * applicant["prior_claims_5yr"],
        "roof_age": mods["roof_over_20_years"] if prop["roof_age_years"] > 20 else 0.0,
    }
    return {
        "base_rate_per_1000": RATES["base_rate_per_1000"][prop["construction"]],
        "modifiers": modifiers,
        "total_modifier": round(sum(modifiers.values()), 2),
        "deductible_options": list(RATES["deductible_factor"]),
    }


@tool
def generate_quote(applicant_id: str, deductible: int = 1000) -> dict:
    """Generate a homeowners quote. Only issues a premium when guidelines say 'eligible'; otherwise returns the refer/decline outcome.

    Args:
        applicant_id: Applicant ID, e.g. APP-1001.
        deductible: Deductible in dollars: 1000, 2500 or 5000.
    """
    applicant = _lookup(APPLICANTS, applicant_id, "applicant")
    prop = _lookup(PROPERTIES, applicant["property_id"], "property")
    decision = _guideline_decision(applicant, prop)
    if decision["decision"] != "eligible":
        return {"applicant_id": applicant_id, "quote_issued": False, **decision}

    factor = RATES["deductible_factor"].get(str(deductible))
    if factor is None:
        raise ValueError(f"Deductible must be one of {list(RATES['deductible_factor'])}")
    rate = lookup_rate(applicant_id)
    premium = applicant["requested_coverage"] / 1000 * rate["base_rate_per_1000"] * (1 + rate["total_modifier"]) * factor
    return {
        "applicant_id": applicant_id,
        "quote_issued": True,
        "coverage": applicant["requested_coverage"],
        "deductible": deductible,
        "annual_premium": round(max(premium, RATES["minimum_premium"]), 2),
        "risk_score": decision["risk_score"],
        "conditions": GUIDELINES["standard_conditions"],
    }


ALL_TOOLS = [get_applicant_profile, get_property_risk, calculate_risk_score, check_guidelines, lookup_rate, generate_quote]
