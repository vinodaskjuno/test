"""Homeowners underwriting assistant built with Strands Agents."""

from strands import Agent

from app.integrations import get_model, tag_session
from app.tools import ALL_TOOLS

SYSTEM_PROMPT = """You are a homeowners insurance underwriting assistant.
For any quote or risk question about an applicant:
1. Get the applicant profile and their property risk.
2. Calculate the risk score and check underwriting guidelines.
3. If eligible, look up the rate and generate a quote (default deductible 1000 unless asked).
   If 'refer', explain why it needs a senior underwriter. If 'decline', explain the reasons.
Only use facts returned by the tools; never invent applicants, rates or premiums.
Finish with a short summary: decision, risk score, premium (if any) and key reasons."""

_sessions: dict[str, Agent] = {}


def get_agent(session_id: str) -> Agent:
    if session_id not in _sessions:
        agent = Agent(model=get_model(), tools=ALL_TOOLS, system_prompt=SYSTEM_PROMPT, callback_handler=None)
        tag_session(agent, session_id)
        _sessions[session_id] = agent
    return _sessions[session_id]


def run(message: str, session_id: str) -> dict:
    agent = get_agent(session_id)
    start = len(agent.messages)
    result = agent(message)
    tools_used = [
        block["toolUse"]["name"]
        for msg in agent.messages[start:]
        for block in msg.get("content", [])
        if "toolUse" in block
    ]
    return {"session_id": session_id, "reply": str(result).strip(), "tools_used": tools_used}


def reset(session_id: str) -> None:
    _sessions.pop(session_id, None)
