"""FastAPI server for the underwriting agent. Swagger UI at /docs."""

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from app import agent, integrations


@asynccontextmanager
async def lifespan(_: FastAPI):
    integrations.init_observability()
    yield


app = FastAPI(title="Underwriting Assistant (Strands)", lifespan=lifespan)


class InvokeRequest(BaseModel):
    message: str
    session_id: str = "default"


@app.get("/health")
def health():
    return integrations.status()


@app.post("/invoke")
def invoke(req: InvokeRequest):
    try:
        return agent.run(req.message, req.session_id)
    except Exception as e:  # surface LLM/credential errors to the caller
        raise HTTPException(status_code=500, detail=f"{type(e).__name__}: {e}")


@app.delete("/sessions/{session_id}")
def reset_session(session_id: str):
    agent.reset(session_id)
    return {"reset": session_id}
