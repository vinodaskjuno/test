"""Portkey (AI gateway) and Fiddler (observability) wiring.

This is the only module that knows about Portkey or Fiddler. Agent code just calls
get_model(); the server calls init_observability() once at startup.
"""

import os

import boto3

from app.config import CONFIG

APP, LLM, AWS = CONFIG["app"], CONFIG["llm"], CONFIG["aws"]
PORTKEY, FIDDLER = CONFIG["portkey"], CONFIG["fiddler"]


def _require(name, section, *keys):
    missing = [k for k in keys if not section.get(k)]
    if missing:
        hint = "" if name == "llm" else f" or set {name}.enabled: false in config.yaml"
        raise RuntimeError(f"{name}: {missing} empty: set them in .env{hint}")


def get_model():
    """Claude on Bedrock: through the Portkey gateway when enabled, otherwise direct."""
    _require("llm", LLM, "model_id")
    if PORTKEY["enabled"]:
        _require("portkey", PORTKEY, "api_key")
        from portkey_ai import createHeaders
        from strands.models.openai import OpenAIModel

        headers = createHeaders(
            api_key=PORTKEY["api_key"],
            provider="bedrock",
            aws_access_key_id=AWS["access_key_id"],
            aws_secret_access_key=AWS["secret_access_key"],
            aws_session_token=AWS["session_token"],
            aws_region=AWS["region"],
            metadata={"project": APP["name"]},
        )
        return OpenAIModel(
            client_args={"api_key": PORTKEY["api_key"], "base_url": PORTKEY["base_url"], "default_headers": headers},
            model_id=LLM["model_id"],
            params={"temperature": LLM["temperature"], "max_tokens": LLM["max_tokens"]},
        )

    from strands.models import BedrockModel

    session = boto3.Session(
        aws_access_key_id=AWS["access_key_id"] or None,
        aws_secret_access_key=AWS["secret_access_key"] or None,
        aws_session_token=AWS["session_token"] or None,
        region_name=AWS["region"] or None,
    )
    return BedrockModel(
        boto_session=session,
        model_id=LLM["model_id"],
        temperature=LLM["temperature"],
        max_tokens=LLM["max_tokens"],
    )


def init_observability():
    """Export Strands agent traces to Fiddler over OTLP. No-op when disabled."""
    if not FIDDLER["enabled"]:
        return
    _require("fiddler", FIDDLER, "url", "api_key", "application_id")

    # Fiddler routes spans by the application.id resource attribute.
    os.environ["OTEL_SERVICE_NAME"] = APP["name"]
    os.environ["OTEL_RESOURCE_ATTRIBUTES"] = f"application.id={FIDDLER['application_id']}"

    from fiddler_strandsagents import StrandsAgentInstrumentor
    from strands.telemetry import StrandsTelemetry

    telemetry = StrandsTelemetry().setup_otlp_exporter(
        endpoint=f"{FIDDLER['url'].rstrip('/')}/v1/traces",
        headers={
            "authorization": f"Bearer {FIDDLER['api_key']}",
            "fiddler-application-id": FIDDLER["application_id"],
        },
    )
    StrandsAgentInstrumentor(telemetry).instrument()


def tag_session(agent, session_id):
    """Group an agent's invocations into one Fiddler conversation. No-op when disabled."""
    if FIDDLER["enabled"]:
        from fiddler_strandsagents import set_conversation_id

        set_conversation_id(agent, session_id)


def status():
    return {
        "app": APP["name"],
        "portkey": "on" if PORTKEY["enabled"] else "off",
        "fiddler": "on" if FIDDLER["enabled"] else "off",
        "model_id": LLM["model_id"],
    }
