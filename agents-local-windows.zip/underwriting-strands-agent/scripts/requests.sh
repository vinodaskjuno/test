#!/usr/bin/env bash
# Sample calls against the running server. Usage: ./scripts/requests.sh [base_url]
BASE=${1:-http://localhost:8002}
post() { curl -s -X POST "$BASE/invoke" -H 'Content-Type: application/json' -d "$1"; echo; echo; }

echo "== health";               curl -s "$BASE/health"; echo; echo
echo "== standard quote";       post '{"message": "Quote APP-1001 with a 2500 deductible", "session_id": "uw-demo-1"}'
echo "== follow-up (same session)"; post '{"message": "What would it be with a 5000 deductible?", "session_id": "uw-demo-1"}'
echo "== flood-zone referral";  post '{"message": "Can we write a policy for APP-1002?", "session_id": "uw-demo-2"}'
echo "== decline case";         post '{"message": "Assess APP-1003 for homeowners cover", "session_id": "uw-demo-3"}'
