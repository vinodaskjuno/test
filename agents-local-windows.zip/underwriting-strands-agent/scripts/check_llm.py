"""Verifies credentials and shows which LLM path is active. Run: python scripts/check_llm.py"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from strands import Agent  # noqa: E402

from app import integrations  # noqa: E402

print("Config:", integrations.status())
integrations.init_observability()
agent = Agent(model=integrations.get_model(), callback_handler=None)
print("LLM reply:", str(agent("Reply with exactly: OK")).strip())
