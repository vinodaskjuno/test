# Sample calls against the running server. Usage: .\scripts\requests.ps1 [-Base http://localhost:8002]
param([string]$Base = "http://localhost:8002")

function Post($Body) {
    try { Invoke-RestMethod -Method Post -Uri "$Base/invoke" -ContentType "application/json" -Body ($Body | ConvertTo-Json) -TimeoutSec 300 | ConvertTo-Json -Depth 10 }
    catch { "ERROR: $($_.ErrorDetails.Message)" }
    ""
}

"== health"; Invoke-RestMethod "$Base/health" | ConvertTo-Json; ""
"== standard quote";              Post @{ message = 'Quote APP-1001 with a 2500 deductible'; session_id = 'uw-demo-1' }
"== follow-up (same session)";    Post @{ message = 'What would it be with a 5000 deductible?'; session_id = 'uw-demo-1' }
"== flood-zone referral";         Post @{ message = 'Can we write a policy for APP-1002?'; session_id = 'uw-demo-2' }
"== decline case";                Post @{ message = 'Assess APP-1003 for homeowners cover'; session_id = 'uw-demo-3' }
