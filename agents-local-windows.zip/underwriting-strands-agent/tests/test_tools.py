"""Deterministic tool tests: no LLM, no keys needed."""

from app import tools


def test_eligible_applicant_gets_quote():
    quote = tools.generate_quote("APP-1001", deductible=2500)
    assert quote["quote_issued"] and quote["annual_premium"] > 0


def test_flood_zone_is_referred():
    assert tools.check_guidelines("APP-1002")["decision"] == "refer"


def test_high_risk_is_declined():
    result = tools.generate_quote("APP-1003")
    assert not result["quote_issued"] and result["decision"] == "decline"
