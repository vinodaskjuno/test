"""Smoke tests against the running server (needs keys). Skipped if the server is down.
Run: pytest tests/test_smoke.py   (BASE_URL defaults to http://localhost:8002)"""

import os
import uuid

import pytest
import requests

BASE = os.getenv("BASE_URL", "http://localhost:8002")

try:
    requests.get(f"{BASE}/health", timeout=3)
except requests.RequestException:
    pytest.skip(f"server not running at {BASE}", allow_module_level=True)


def invoke(message):
    r = requests.post(f"{BASE}/invoke", json={"message": message, "session_id": str(uuid.uuid4())}, timeout=300)
    assert r.status_code == 200, r.text
    return r.json()


def test_health_reports_flags():
    body = requests.get(f"{BASE}/health", timeout=5).json()
    assert body["portkey"] in ("on", "off") and body["fiddler"] in ("on", "off")


def test_quote_uses_tools():
    body = invoke("Quote APP-1001")
    assert "check_guidelines" in body["tools_used"] or "generate_quote" in body["tools_used"]
    assert body["reply"]


def test_decline_case():
    body = invoke("Assess APP-1003")
    assert "declin" in body["reply"].lower()
