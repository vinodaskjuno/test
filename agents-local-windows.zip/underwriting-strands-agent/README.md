# Underwriting Assistant — Strands Agents

A homeowners underwriting agent built with **Strands Agents** and Claude on Bedrock. It is used to validate **Portkey** (AI gateway) and **Fiddler** (observability).

The agent uses 6 tools that read local mock data in `app/data/`:
- `get_applicant_profile`
- `get_property_risk`
- `calculate_risk_score`
- `check_guidelines`
- `lookup_rate`
- `generate_quote`

| Applicant | Expected outcome |
|---|---|
| APP-1001 | Eligible → quote issued |
| APP-1002 | Refer (flood zone AE) |
| APP-1003 | Decline (claims history, roof age, wildfire) |
| APP-1004 | Refer (risk score, high replacement cost) |

## Where Portkey and Fiddler live
Only two files know about them:
- `config.yaml` holds the `portkey.enabled` and `fiddler.enabled` flags.
- `app/integrations.py` (about 100 lines) contains all the Portkey and Fiddler code:
  - `get_model()`: Portkey ON uses `OpenAIModel` → Portkey gateway (provider `bedrock`, AWS creds sent in headers). Portkey OFF uses `BedrockModel` directly.
  - `init_observability()`: Fiddler ON runs `StrandsTelemetry` OTLP → Fiddler, plus `StrandsAgentInstrumentor`.
  - `tag_session()`: Fiddler conversation ID = API `session_id`.

## Setup
```bash
cd underwriting-strands-agent
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill in AWS / Bedrock model ID / Portkey / Fiddler values
python scripts/check_llm.py # prints active path + a test completion
```

## Run
```bash
uvicorn app.server:app --port 8002 --reload       # API + Swagger at http://localhost:8002/docs
streamlit run ui.py --server.port 8502            # chat UI at http://localhost:8502
./scripts/requests.sh                             # sample curl calls
pytest tests/                                     # tool tests + smoke tests (smoke needs server)
```

Endpoints:
- `GET /health` returns the flag status.
- `POST /invoke {message, session_id}` returns `{reply, tools_used}`.
- `DELETE /sessions/{id}` resets a session.

## Validation matrix
Edit the flags in `config.yaml`, restart uvicorn, then run `./scripts/requests.sh`.

| portkey | fiddler | Check |
|---|---|---|
| off | off | Replies come straight from Bedrock |
| on | off | Portkey logs show the requests (metadata `project=underwriting-strands-agent`) |
| off | on | Fiddler app shows agent → LLM → tool spans; `uw-demo-1` calls grouped as one conversation |
| on | on | Both of the above |
