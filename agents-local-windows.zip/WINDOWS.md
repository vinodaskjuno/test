# Running the 3 agents on Windows

Tested on macOS with Python 3.12, using Claude Sonnet 4.6 (`us.anthropic.claude-sonnet-4-6`) and Titan Embed v2 in us-east-1. Portkey and Fiddler are **off** in all three `config.yaml` files.

## 0. Prerequisites
- **Python 3.12** from python.org. Tick "Add python.exe to PATH". The `py` launcher is used when available.
- **AWS access to Bedrock** in us-east-1 for the Claude model and Titan Embed v2. Use either option:
  - **AWS CLI profile:** run `aws configure` once (key, secret, region `us-east-1`). Then no `.env` is needed.
  - **`.env` per project:** copy `.env.example` to `.env` and set `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` (and `AWS_SESSION_TOKEN` if you use temporary creds).
- If you use a different AWS account, its Claude model may differ. Set `BEDROCK_MODEL_ID` in each project's `.env`.

## 1. Unzip and set up (once)
Open **PowerShell** in the unzipped folder:
```powershell
Set-ExecutionPolicy -Scope Process Bypass    # allow the .ps1 scripts in this window only
.\setup_windows.ps1                          # creates .venv + installs pinned deps in all 3 projects (~5-10 min)
```

## 2. Check credentials (optional but recommended)
```powershell
cd claims-langgraph-agent;     .\.venv\Scripts\python.exe scripts\check_llm.py; cd ..
cd underwriting-strands-agent; .\.venv\Scripts\python.exe scripts\check_llm.py; cd ..
cd rag-multiagent-strands;     .\.venv\Scripts\python.exe scripts\check_llm.py; cd ..
```
Each should print `portkey: off, fiddler: off` and `LLM reply: OK`. The RAG one also prints `Embedding dims: 1024`.

## 3. Start all 3 agents
```powershell
.\start_all_windows.ps1     # opens 6 PowerShell windows (3 APIs + 3 UIs)
```
| Agent | API (Swagger) | Chat UI |
|---|---|---|
| Claims (LangGraph) | http://localhost:8001/docs | http://localhost:8501 |
| Underwriting (Strands) | http://localhost:8002/docs | http://localhost:8502 |
| RAG (multi-agent Strands) | http://localhost:8003/docs | http://localhost:8503 |

To stop them, run `.\stop_all_windows.ps1`, or close the windows.

**To start one agent by hand instead** (two windows per agent):
```powershell
cd claims-langgraph-agent
.\.venv\Scripts\Activate.ps1
uvicorn app.server:app --port 8001                          # window 1
streamlit run ui.py --server.port 8501 --server.headless true   # window 2 (same folder, activate first)
```
For the other two agents, use ports 8002/8502 and 8003/8503.

## 4. Test
In a new PowerShell window, from each project folder:
```powershell
.\scripts\requests.ps1                  # sample requests (PowerShell version of requests.sh)
.\.venv\Scripts\python.exe -m pytest tests   # unit tests + live smoke tests
```
Expected results:
- **Claims:**
  - Alice → `approved`, payout 2700.
  - Ben → `pending_review`, then `approved_after_review`.
  - Chen → `denied` ("Policy is lapsed").
- **Underwriting:**
  - APP-1001 → quote with premium; the follow-up re-quotes at a $5,000 deductible.
  - APP-1002 → refer (flood zone).
  - APP-1003 → decline.
- **RAG:**
  - 3 answers with `[doc#Section]` citations and `grounding: PASS`.
  - "Capital of Australia" → "I could not find this in the knowledge base."

The RAG knowledge base (`rag-multiagent-strands\.chroma`) is included in the zip. If `/ask` errors about the collection, rebuild it with `.\.venv\Scripts\python.exe -m app.kb` from that folder, or use the UI's "Re-ingest" button.

## 5. Turn on Portkey / Fiddler later
In a project's `config.yaml`, set `portkey.enabled` and/or `fiddler.enabled` to `true`. Then fill those keys in its `.env` and restart that agent:
- Portkey needs `PORTKEY_API_KEY` **plus explicit AWS keys**.
- Fiddler needs `FIDDLER_URL`, `FIDDLER_API_KEY` and `FIDDLER_APPLICATION_ID`.

## Troubleshooting
| Symptom | Fix |
|---|---|
| `running scripts is disabled on this system` | Run `Set-ExecutionPolicy -Scope Process Bypass` first |
| `py` / `python` not found | Install Python 3.12 from python.org with "Add to PATH" |
| `Unable to locate credentials` / `AccessDeniedException` | Run `aws configure` or fill the AWS keys in `.env`; check Bedrock model access in us-east-1 |
| `Invalid length for parameter modelId` | Set `BEDROCK_MODEL_ID` in `.env` |
| Port already in use | Run `.\stop_all_windows.ps1`, or change the `--port` |
