"""Streamlit UI for the claims triage graph. Run: streamlit run ui.py --server.port 8501"""

import os

import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8001")
SAMPLES = {
    "Clean auto claim": "Hi, this is Alice Brown, policy POL-AUTO-1001. On 2026-10-03 I was rear-ended at a stop light. The body shop estimate for the bumper and trunk is $3,200.",
    "High-value home claim": "Ben Carter here, policy POL-HOME-2001. A kitchen fire on 2026-10-01 destroyed the cabinets and appliances. Contractor estimate is $48,000.",
    "Lapsed policy": "My name is Chen Wu, policy POL-HOME-2002. A pipe burst in my bathroom on 2026-09-20 and the repair estimate is $6,500.",
}

st.set_page_config(page_title="Claims Triage", page_icon="🧾", layout="wide")
st.title("🧾 Claims FNOL Triage (LangGraph)")

with st.sidebar:
    try:
        st.json(requests.get(f"{API_URL}/health", timeout=5).json())
    except requests.RequestException:
        st.error(f"API not reachable at {API_URL}")

sample = st.selectbox("Sample claim", ["(write your own)", *SAMPLES])
message = st.text_area("First notice of loss", SAMPLES.get(sample, ""), height=120)

if st.button("Submit claim", type="primary") and message.strip():
    with st.spinner("Running intake → policy → fraud → coverage..."):
        r = requests.post(f"{API_URL}/invoke", json={"message": message}, timeout=300)
    st.session_state.result = r.json() if r.ok else {"error": r.text}

result = st.session_state.get("result")
if result:
    if "error" in result:
        st.error(result["error"])
    else:
        st.subheader(f"Decision: {result['decision']}  ·  session {result['session_id']}")
        if result["status"] == "pending_review":
            st.warning("Paused for human review")
            st.json(result["review_request"])
            note = st.text_input("Reviewer note")
            approve, reject = st.columns(2)
            for col, ok, label in ((approve, True, "Approve"), (reject, False, "Reject")):
                if col.button(label):
                    r = requests.post(f"{API_URL}/claims/{result['session_id']}/review", json={"approve": ok, "note": note}, timeout=300)
                    st.session_state.result = r.json() if r.ok else {"error": r.text}
                    st.rerun()
        if result.get("summary"):
            st.markdown("**Adjuster note**")
            st.markdown(result["summary"])
        with st.expander("Full graph state"):
            st.json(result)
