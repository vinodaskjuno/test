# Sample calls against the running server. Usage: .\scripts\requests.ps1 [-Base http://localhost:8001]
param([string]$Base = "http://localhost:8001")

function Post($Path, $Body) {
    try { Invoke-RestMethod -Method Post -Uri "$Base$Path" -ContentType "application/json" -Body ($Body | ConvertTo-Json) -TimeoutSec 300 | ConvertTo-Json -Depth 10 }
    catch { "ERROR: $($_.ErrorDetails.Message)" }
    ""
}

"== health"; Invoke-RestMethod "$Base/health" | ConvertTo-Json; ""
"== clean auto claim -> approved"
Post "/invoke" @{ session_id = "claim-demo-1"; message = 'Hi, this is Alice Brown, policy POL-AUTO-1001. On 2026-10-03 I was rear-ended at a stop light. The body shop estimate for the bumper and trunk is $3,200.' }
"== high-value home claim -> pending_review"
Post "/invoke" @{ session_id = "claim-demo-2"; message = 'Ben Carter here, policy POL-HOME-2001. A kitchen fire on 2026-10-01 destroyed the cabinets and appliances. Contractor estimate is $48,000.' }
"== reviewer approves claim-demo-2 (resumes the graph)"
Post "/claims/claim-demo-2/review" @{ approve = $true; note = 'Fire report verified with local fire department' }
"== lapsed policy -> denied"
Post "/invoke" @{ session_id = "claim-demo-3"; message = 'My name is Chen Wu, policy POL-HOME-2002. A pipe burst in my bathroom on 2026-09-20 and the repair estimate is $6,500.' }
