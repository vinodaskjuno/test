#!/usr/bin/env bash
# Sample calls against the running server. Usage: ./scripts/requests.sh [base_url]
BASE=${1:-http://localhost:8001}
post() { curl -s -X POST "$BASE$1" -H 'Content-Type: application/json' -d "$2"; echo; echo; }

echo "== health"; curl -s "$BASE/health"; echo; echo
echo "== clean auto claim -> approved"
post /invoke '{"session_id": "claim-demo-1", "message": "Hi, this is Alice Brown, policy POL-AUTO-1001. On 2026-10-03 I was rear-ended at a stop light. The body shop estimate for the bumper and trunk is $3,200."}'
echo "== high-value home claim -> pending_review"
post /invoke '{"session_id": "claim-demo-2", "message": "Ben Carter here, policy POL-HOME-2001. A kitchen fire on 2026-10-01 destroyed the cabinets and appliances. Contractor estimate is $48,000."}'
echo "== reviewer approves claim-demo-2 (resumes the graph)"
post /claims/claim-demo-2/review '{"approve": true, "note": "Fire report verified with local fire department"}'
echo "== lapsed policy -> denied"
post /invoke '{"session_id": "claim-demo-3", "message": "My name is Chen Wu, policy POL-HOME-2002. A pipe burst in my bathroom on 2026-09-20 and the repair estimate is $6,500."}'
