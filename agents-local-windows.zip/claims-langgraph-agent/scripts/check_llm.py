"""Verifies credentials and shows which LLM path is active. Run: python scripts/check_llm.py"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import integrations  # noqa: E402

print("Config:", integrations.status())
integrations.init_observability()
print("LLM reply:", integrations.get_model().invoke("Reply with exactly: OK").content)
