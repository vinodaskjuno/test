"""FastAPI server for the claims triage graph. Swagger UI at /docs."""

import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from langgraph.types import Command
from pydantic import BaseModel, Field

from app import integrations
from app.graph import get_graph


@asynccontextmanager
async def lifespan(_: FastAPI):
    integrations.init_observability()
    get_graph()
    yield


app = FastAPI(title="Claims FNOL Triage (LangGraph)", lifespan=lifespan)


class InvokeRequest(BaseModel):
    message: str
    session_id: str = Field(default_factory=lambda: f"claim-{uuid.uuid4().hex[:8]}")


class ReviewRequest(BaseModel):
    approve: bool
    note: str = ""


def _config(session_id):
    return {"configurable": {"thread_id": session_id}}


def _result(session_id):
    snapshot = get_graph().get_state(_config(session_id))
    if not snapshot.values:
        raise HTTPException(status_code=404, detail=f"No claim for session {session_id}")
    pending = [i.value for i in snapshot.interrupts]
    state = snapshot.values
    return {
        "session_id": session_id,
        "status": "pending_review" if pending else "completed",
        "decision": state.get("decision", "pending_review" if pending else None),
        "review_request": pending[0] if pending else None,
        **{k: state.get(k) for k in ("claim", "validation", "fraud", "coverage", "denial_reason", "review", "summary")},
    }


def _run(graph_input, session_id):
    integrations.tag_session(session_id)
    try:
        get_graph().invoke(graph_input, _config(session_id))
    except Exception as e:  # surface LLM/credential errors to the caller
        raise HTTPException(status_code=500, detail=f"{type(e).__name__}: {e}")
    return _result(session_id)


@app.get("/health")
def health():
    return integrations.status()


@app.post("/invoke")
def invoke(req: InvokeRequest):
    """Submit a new claim (free-text FNOL). Returns the decision, or status=pending_review."""
    return _run({"message": req.message}, req.session_id)


@app.get("/claims/{session_id}")
def get_claim(session_id: str):
    return _result(session_id)


@app.post("/claims/{session_id}/review")
def review(session_id: str, req: ReviewRequest):
    """Resume a claim paused for human review."""
    if _result(session_id)["status"] != "pending_review":
        raise HTTPException(status_code=409, detail="Claim is not waiting for review")
    return _run(Command(resume=req.model_dump()), session_id)
