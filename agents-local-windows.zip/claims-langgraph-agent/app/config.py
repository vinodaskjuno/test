"""Loads config.yaml and expands ${ENV_VAR} / ${ENV_VAR:-default} placeholders from the environment / .env."""

import os
import re
from pathlib import Path

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

_ENV_VAR = re.compile(r"\$\{(\w+)(?::-([^}]*))?\}")


def _expand(value):
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand(v) for v in value]
    if isinstance(value, str):
        return _ENV_VAR.sub(lambda m: os.getenv(m.group(1)) or m.group(2) or "", value)
    return value


CONFIG = _expand(yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8")))
