"""Portkey (AI gateway) and Fiddler (observability) wiring.

This is the only module that knows about Portkey or Fiddler. Graph code just calls
get_model(); the server calls init_observability() once at startup.
"""

from app.config import CONFIG

APP, LLM, AWS = CONFIG["app"], CONFIG["llm"], CONFIG["aws"]
PORTKEY, FIDDLER = CONFIG["portkey"], CONFIG["fiddler"]


def _require(name, section, *keys):
    missing = [k for k in keys if not section.get(k)]
    if missing:
        hint = "" if name == "llm" else f" or set {name}.enabled: false in config.yaml"
        raise RuntimeError(f"{name}: {missing} empty: set them in .env{hint}")


def get_model():
    """Claude on Bedrock as a LangChain chat model: via the Portkey gateway when enabled, otherwise direct."""
    _require("llm", LLM, "model_id")
    if PORTKEY["enabled"]:
        _require("portkey", PORTKEY, "api_key")
        from langchain_openai import ChatOpenAI
        from portkey_ai import createHeaders

        headers = createHeaders(
            api_key=PORTKEY["api_key"],
            provider="bedrock",
            aws_access_key_id=AWS["access_key_id"],
            aws_secret_access_key=AWS["secret_access_key"],
            aws_session_token=AWS["session_token"],
            aws_region=AWS["region"],
            metadata={"project": APP["name"]},
        )
        return ChatOpenAI(
            api_key="dummy",  # Portkey authenticates via the x-portkey-api-key header
            base_url=PORTKEY["base_url"],
            default_headers=headers,
            model=LLM["model_id"],
            temperature=LLM["temperature"],
            max_tokens=LLM["max_tokens"],
        )

    from langchain_aws import ChatBedrockConverse

    return ChatBedrockConverse(
        model=LLM["model_id"],
        region_name=AWS["region"] or None,
        aws_access_key_id=AWS["access_key_id"] or None,
        aws_secret_access_key=AWS["secret_access_key"] or None,
        aws_session_token=AWS["session_token"] or None,
        temperature=LLM["temperature"],
        max_tokens=LLM["max_tokens"],
    )


def init_observability():
    """Auto-instrument LangGraph/LangChain and export traces to Fiddler. No-op when disabled."""
    if not FIDDLER["enabled"]:
        return
    _require("fiddler", FIDDLER, "url", "api_key", "application_id")
    from fiddler_langgraph import FiddlerClient, LangGraphInstrumentor

    client = FiddlerClient(application_id=FIDDLER["application_id"], api_key=FIDDLER["api_key"], url=FIDDLER["url"].rstrip("/"))
    LangGraphInstrumentor(client).instrument()


def tag_session(session_id):
    """Group the spans of the current request into one Fiddler conversation. No-op when disabled."""
    if FIDDLER["enabled"]:
        from fiddler_langgraph import set_conversation_id

        set_conversation_id(session_id)


def status():
    return {
        "app": APP["name"],
        "portkey": "on" if PORTKEY["enabled"] else "off",
        "fiddler": "on" if FIDDLER["enabled"] else "off",
        "model_id": LLM["model_id"],
    }
