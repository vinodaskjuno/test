"""Claims tools over local mock data (app/data/*.json).

Defined as LangChain tools and called with .invoke(), so each call shows up as a tool span in traces.
"""

import json
from datetime import date
from pathlib import Path

from langchain_core.tools import tool

DATA = Path(__file__).parent / "data"
POLICIES = json.loads((DATA / "policies.json").read_text(encoding="utf-8"))
HISTORY = json.loads((DATA / "claims_history.json").read_text(encoding="utf-8"))


@tool
def lookup_policy(policy_no: str) -> dict:
    """Look up a policy by number: holder, line, status, effective/expiry dates, coverages and exclusions."""
    policy = POLICIES.get(policy_no.strip().upper())
    return {"found": False, "policy_no": policy_no} if policy is None else {"found": True, "policy_no": policy_no, **policy}


@tool
def get_claim_history(customer_id: str) -> list:
    """List a customer's prior claims (date, type, amount)."""
    return HISTORY.get(customer_id, [])


@tool
def fraud_signals(loss_date: str, amount: float, policy_no: str) -> list:
    """Rule-based fraud indicators for a claim (inception timing, claim frequency, amount vs limit, late reporting)."""
    policy = POLICIES[policy_no]
    loss = date.fromisoformat(loss_date)
    signals = []
    if (loss - date.fromisoformat(policy["effective"])).days <= 60:
        signals.append("loss within 60 days of policy inception")
    recent = [c for c in HISTORY.get(policy["customer_id"], []) if (loss - date.fromisoformat(c["date"])).days <= 5 * 365]
    if len(recent) >= 3:
        signals.append(f"{len(recent)} prior claims in the last 5 years")
    if amount >= 0.9 * max(c["limit"] for c in policy["coverages"].values()):
        signals.append("claimed amount at or near the policy limit")
    if (date.today() - loss).days > 30:
        signals.append("reported more than 30 days after the loss")
    return signals
