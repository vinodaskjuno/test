"""Claims FNOL triage as a LangGraph StateGraph.

intake → validate_policy ─(invalid)──────────────────────────────► deny ─┐
                         └► fraud_check → coverage_assessment ─(not covered)► deny
                                                     ├─(high value / fraud)► human_review (interrupt) ─┤
                                                     └─(otherwise)────────► auto_approve ─────────────┴► summarize → END
"""

from datetime import date
from typing import Literal, TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt
from pydantic import BaseModel, Field

from app import tools
from app.config import CONFIG
from app.integrations import get_model

RULES = CONFIG["claims"]


class ClaimDetails(BaseModel):
    """Structured first notice of loss."""

    policy_no: str = Field(description="Policy number, e.g. POL-AUTO-1001")
    claimant_name: str
    loss_date: str = Field(description="Date of loss as YYYY-MM-DD")
    loss_type: Literal["auto_collision", "theft", "fire", "water", "weather", "vandalism", "liability", "other"]
    amount: float = Field(description="Estimated loss amount in dollars (0 if not given)")
    description: str = Field(description="One-sentence description of what happened")


class CoverageDecision(BaseModel):
    """Whether the loss is covered under the policy."""

    covered: bool
    coverage: str = Field(description="Which coverage applies, exactly as named in the policy's coverages")
    reason: str = Field(description="One or two sentences citing the coverage or exclusion")


class ClaimState(TypedDict, total=False):
    message: str
    claim: dict
    policy: dict
    validation: dict
    fraud: dict
    coverage: dict
    decision: str
    denial_reason: str
    review: dict
    summary: str


def intake(state: ClaimState) -> ClaimState:
    llm = get_model().with_structured_output(ClaimDetails, method="function_calling")
    claim = llm.invoke(
        f"Today is {date.today().isoformat()}. Extract the first notice of loss details from this message:\n\n{state['message']}"
    )
    return {"claim": claim.model_dump()}


def validate_policy(state: ClaimState) -> ClaimState:
    claim = state["claim"]
    policy = tools.lookup_policy.invoke({"policy_no": claim["policy_no"]})
    if not policy["found"]:
        return {"policy": policy, "validation": {"valid": False, "reason": f"Policy {claim['policy_no']} not found"}}
    if policy["status"] != "active":
        return {"policy": policy, "validation": {"valid": False, "reason": f"Policy is {policy['status']}"}}
    if not policy["effective"] <= claim["loss_date"] <= policy["expires"]:
        return {"policy": policy, "validation": {"valid": False, "reason": "Loss date is outside the policy period"}}
    return {"policy": policy, "validation": {"valid": True, "reason": "Policy active on the date of loss"}}


def fraud_check(state: ClaimState) -> ClaimState:
    claim, policy = state["claim"], state["policy"]
    signals = tools.fraud_signals.invoke({"loss_date": claim["loss_date"], "amount": claim["amount"], "policy_no": claim["policy_no"]})
    history = tools.get_claim_history.invoke({"customer_id": policy["customer_id"]})
    rationale = get_model().invoke(
        "You are a claims fraud analyst. In two sentences, assess the fraud risk of this claim. Do not accuse the claimant.\n"
        f"Claim: {claim}\nRule-based signals: {signals or 'none'}\nPrior claims: {history or 'none'}"
    ).content
    return {"fraud": {"signals": signals, "prior_claims": len(history), "rationale": rationale}}


def coverage_assessment(state: ClaimState) -> ClaimState:
    claim, policy = state["claim"], state["policy"]
    llm = get_model().with_structured_output(CoverageDecision, method="function_calling")
    decision = llm.invoke(
        "You are a claims coverage analyst. Decide whether this loss is covered.\n"
        f"Claim: {claim}\nPolicy line: {policy['line']}\nCoverages: {policy['coverages']}\nExclusions: {policy['exclusions']}"
    ).model_dump()
    terms = policy["coverages"].get(decision["coverage"])
    if decision["covered"] and terms:
        decision["estimated_payout"] = max(min(claim["amount"], terms["limit"]) - terms["deductible"], 0)
    return {"coverage": decision}


def route(state: ClaimState) -> str:
    if not state["validation"]["valid"] or not state["coverage"]["covered"]:
        return "deny"
    if state["claim"]["amount"] > RULES["review_threshold"] or len(state["fraud"]["signals"]) >= RULES["fraud_flags_for_review"]:
        return "human_review"
    return "auto_approve"


def human_review(state: ClaimState) -> ClaimState:
    review = interrupt(
        {
            "question": "Approve this claim?",
            "claim": state["claim"],
            "fraud_signals": state["fraud"]["signals"],
            "coverage": state["coverage"],
        }
    )
    return {"review": review, "decision": "approved_after_review" if review.get("approve") else "rejected_after_review"}


def auto_approve(state: ClaimState) -> ClaimState:
    return {"decision": "approved"}


def deny(state: ClaimState) -> ClaimState:
    validation = state["validation"]
    reason = validation["reason"] if not validation["valid"] else state["coverage"]["reason"]
    return {"decision": "denied", "denial_reason": reason}


def summarize(state: ClaimState) -> ClaimState:
    facts = {k: state.get(k) for k in ("claim", "validation", "fraud", "coverage", "decision", "denial_reason", "review")}
    summary = get_model().invoke(
        "Write a concise adjuster file note (4-6 lines) for this claim: decision, reason, payout if any, and next steps.\n"
        f"{facts}"
    ).content
    return {"summary": summary}


def _build():
    g = StateGraph(ClaimState)
    for node in (intake, validate_policy, fraud_check, coverage_assessment, human_review, auto_approve, deny, summarize):
        g.add_node(node.__name__, node)
    g.add_edge(START, "intake")
    g.add_edge("intake", "validate_policy")
    g.add_conditional_edges("validate_policy", lambda s: "fraud_check" if s["validation"]["valid"] else "deny")
    g.add_edge("fraud_check", "coverage_assessment")
    g.add_conditional_edges("coverage_assessment", route)
    for node in ("human_review", "auto_approve", "deny"):
        g.add_edge(node, "summarize")
    g.add_edge("summarize", END)
    return g.compile(checkpointer=MemorySaver())


_graph = None


def get_graph():
    """Compiled lazily so observability is initialised before the graph is built."""
    global _graph
    if _graph is None:
        _graph = _build()
    return _graph
