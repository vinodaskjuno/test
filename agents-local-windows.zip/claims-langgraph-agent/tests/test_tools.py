"""Deterministic tool and routing tests: no LLM, no keys needed."""

from app import tools
from app.graph import route


def test_lookup_policy():
    assert tools.lookup_policy.invoke({"policy_no": "pol-auto-1001"})["status"] == "active"
    assert not tools.lookup_policy.invoke({"policy_no": "POL-NOPE"})["found"]


def test_fraud_signals_for_new_policy_with_history():
    signals = tools.fraud_signals.invoke({"loss_date": "2026-10-01", "amount": 48000, "policy_no": "POL-HOME-2001"})
    assert any("inception" in s for s in signals) and any("prior claims" in s for s in signals)


def _state(valid=True, covered=True, amount=1000, signals=()):
    return {"validation": {"valid": valid}, "coverage": {"covered": covered}, "claim": {"amount": amount}, "fraud": {"signals": list(signals)}}


def test_routing():
    assert route(_state()) == "auto_approve"
    assert route(_state(amount=48000)) == "human_review"
    assert route(_state(signals=["a", "b"])) == "human_review"
    assert route(_state(covered=False)) == "deny"
