"""Smoke tests against the running server (needs keys). Skipped if the server is down.
Run: pytest tests/test_smoke.py   (BASE_URL defaults to http://localhost:8001)"""

import os

import pytest
import requests

BASE = os.getenv("BASE_URL", "http://localhost:8001")

try:
    requests.get(f"{BASE}/health", timeout=3)
except requests.RequestException:
    pytest.skip(f"server not running at {BASE}", allow_module_level=True)


def invoke(message):
    r = requests.post(f"{BASE}/invoke", json={"message": message}, timeout=300)
    assert r.status_code == 200, r.text
    return r.json()


def test_health_reports_flags():
    body = requests.get(f"{BASE}/health", timeout=5).json()
    assert body["portkey"] in ("on", "off") and body["fiddler"] in ("on", "off")


def test_clean_claim_is_approved():
    body = invoke("Alice Brown, policy POL-AUTO-1001. Rear-ended on 2026-10-03, repair estimate $3,200.")
    assert body["decision"] == "approved" and body["summary"]


def test_high_value_claim_pauses_then_resumes():
    body = invoke("Ben Carter, policy POL-HOME-2001. Kitchen fire on 2026-10-01, estimate $48,000.")
    assert body["status"] == "pending_review"
    r = requests.post(f"{BASE}/claims/{body['session_id']}/review", json={"approve": False, "note": "test"}, timeout=300)
    assert r.json()["decision"] == "rejected_after_review"


def test_lapsed_policy_is_denied():
    body = invoke("Chen Wu, policy POL-HOME-2002. Burst pipe on 2026-09-20, estimate $6,500.")
    assert body["decision"] == "denied"
