# Claims FNOL Triage — LangGraph

A first-notice-of-loss triage graph built with **LangGraph** and Claude on Bedrock. It is used to validate **Portkey** (AI gateway) and **Fiddler** (observability).

```
intake (LLM, structured) → validate_policy ─(invalid)──────────────► deny ──────────┐
                                └► fraud_check (rules + LLM) → coverage_assessment (LLM, structured)
                                        ├─(not covered)────────────► deny ──────────┤
                                        ├─(> $10k or ≥2 fraud flags)► human_review ─┤  interrupt → POST /claims/{id}/review
                                        └─(otherwise)──────────────► auto_approve ──┴► summarize (LLM) → END
```

The mock data is in `app/data/` (6 policies plus claims history). The thresholds are in `config.yaml` under `claims:`.

| Sample | Expected |
|---|---|
| Alice Brown, POL-AUTO-1001, $3,200 rear-end | `approved`, payout $2,700 |
| Ben Carter, POL-HOME-2001, $48,000 fire | `pending_review` (high value, new policy, 3 prior claims), then resume |
| Chen Wu, POL-HOME-2002, $6,500 burst pipe | `denied` (policy lapsed) |

## Where Portkey and Fiddler live
Only two files know about them:
- `config.yaml` holds the `portkey.enabled` and `fiddler.enabled` flags.
- `app/integrations.py` contains all the Portkey and Fiddler code:
  - `get_model()`: Portkey ON uses `ChatOpenAI` → Portkey gateway (provider `bedrock`, AWS creds sent in headers). Portkey OFF uses `ChatBedrockConverse` directly.
  - `init_observability()`: Fiddler ON runs `FiddlerClient` + `LangGraphInstrumentor().instrument()` (auto-instruments nodes, LLM calls and tools).
  - `tag_session()`: Fiddler conversation ID = claim `session_id`, so a paused claim and its resume end up in one conversation.

## Setup
```bash
cd claims-langgraph-agent
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill in AWS / Bedrock model ID / Portkey / Fiddler values
python scripts/check_llm.py # prints active path + a test completion
```

## Run
```bash
uvicorn app.server:app --port 8001 --reload       # API + Swagger at http://localhost:8001/docs
streamlit run ui.py --server.port 8501            # UI at http://localhost:8501 (sample claims + approve/reject)
./scripts/requests.sh                             # the 3 sample claims + a review resume
pytest tests/                                     # tool/routing tests + smoke tests (smoke needs server)
```

Endpoints:
- `GET /health`
- `POST /invoke {message, session_id?}`
- `GET /claims/{id}`
- `POST /claims/{id}/review {approve, note}`

Claim state is kept in memory (`MemorySaver`), so it is lost when the server restarts.

## Validation matrix
Edit the flags in `config.yaml`, restart uvicorn, then run `./scripts/requests.sh`.

| portkey | fiddler | Check |
|---|---|---|
| off | off | Decisions come back straight from Bedrock |
| on | off | Portkey logs show 4 LLM calls per claim: intake, fraud, coverage, summary (metadata `project=claims-langgraph-agent`) |
| off | on | Fiddler shows graph → node → LLM/tool spans; `claim-demo-2` and its review resume share one conversation |
| on | on | Both of the above |

## Known issue (found during build)
With `langgraph` 1.2.x and `fiddler-langgraph` 1.7.0, interrupt and resume log this:
```
Error in _CallbackHandler.on_interrupt callback: AttributeError(...)
```
LangGraph now sends interrupt and resume callback events, and the Fiddler handler doesn't implement them yet. The warning is harmless: the graph and all other spans work. The interrupt and resume events themselves probably won't appear as separate spans. Raise this with Fiddler if you need them.
