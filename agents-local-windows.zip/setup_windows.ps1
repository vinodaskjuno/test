# One-time setup: creates a Python 3.12 venv and installs pinned requirements for all 3 projects.
# Usage (PowerShell, from this folder):  .\setup_windows.ps1
$projects = "claims-langgraph-agent", "underwriting-strands-agent", "rag-multiagent-strands"

foreach ($p in $projects) {
    Write-Host "== $p" -ForegroundColor Cyan
    Push-Location (Join-Path $PSScriptRoot $p)
    if (Get-Command py -ErrorAction SilentlyContinue) { py -3.12 -m venv .venv } else { python -m venv .venv }
    if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Could not create venv for $p (is Python 3.12 installed?)" }
    .\.venv\Scripts\python.exe -m pip install --upgrade pip
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { Pop-Location; throw "pip install failed for $p" }
    Pop-Location
}
Write-Host "Setup complete. Next: .\start_all_windows.ps1" -ForegroundColor Green
