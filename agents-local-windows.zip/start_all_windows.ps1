# Starts the 3 APIs and 3 Streamlit UIs, each in its own PowerShell window.
# Usage:  .\start_all_windows.ps1      (stop with .\stop_all_windows.ps1 or close the windows)
$apps = @(
    @{ Dir = "claims-langgraph-agent";     Api = 8001; Ui = 8501 },
    @{ Dir = "underwriting-strands-agent"; Api = 8002; Ui = 8502 },
    @{ Dir = "rag-multiagent-strands";     Api = 8003; Ui = 8503 }
)

foreach ($a in $apps) {
    $dir = Join-Path $PSScriptRoot $a.Dir
    $py = ".\.venv\Scripts\python.exe"
    Start-Process powershell -WorkingDirectory $dir -ArgumentList "-NoExit", "-Command",
        "`$host.UI.RawUI.WindowTitle='$($a.Dir) API :$($a.Api)'; $py -m uvicorn app.server:app --port $($a.Api)"
    Start-Process powershell -WorkingDirectory $dir -ArgumentList "-NoExit", "-Command",
        "`$host.UI.RawUI.WindowTitle='$($a.Dir) UI :$($a.Ui)'; $py -m streamlit run ui.py --server.port $($a.Ui) --server.headless true"
}

Write-Host "Starting... give it ~15 seconds, then open:" -ForegroundColor Green
foreach ($a in $apps) { Write-Host ("  {0,-28} API http://localhost:{1}/docs   UI http://localhost:{2}" -f $a.Dir, $a.Api, $a.Ui) }
