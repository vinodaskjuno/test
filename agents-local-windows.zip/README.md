# Local agent projects: Portkey + Fiddler validation

Three standalone projects. Each has its own venv, `config.yaml`, `.env` and README.

| Project | Framework | Use case | API | UI |
|---|---|---|---|---|
| [claims-langgraph-agent](claims-langgraph-agent/) | LangGraph | Claims FNOL triage with human review | :8001 | :8501 |
| [underwriting-strands-agent](underwriting-strands-agent/) | Strands | Homeowners underwriting assistant (6 tools) | :8002 | :8502 |
| [rag-multiagent-strands](rag-multiagent-strands/) | Strands (agents as tools) | Multi-agent RAG over a local Chroma KB | :8003 | :8503 |

All three use Claude on Bedrock. In every project, Portkey and Fiddler code lives only in `app/integrations.py`, and both are switched on or off in `config.yaml`:

```yaml
portkey:
  enabled: true   # false → direct Bedrock
fiddler:
  enabled: true   # false → no tracing
```

## Before the first run (each project)
1. With Portkey and Fiddler off, no `.env` is needed. The model defaults to `us.anthropic.claude-sonnet-4-6` and the region to `us-east-1`, and AWS credentials come from your `~/.aws` default profile. To enable Portkey or Fiddler, `cp .env.example .env` and fill in `AWS_*` (Portkey needs explicit keys), `PORTKEY_API_KEY`, `FIDDLER_URL`, `FIDDLER_API_KEY` and `FIDDLER_APPLICATION_ID`. Use one Fiddler application per project.
2. In the Bedrock console, enable model access for your Claude model. The RAG project also needs Titan Text Embeddings V2.
3. `python3.12 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
4. Run `python scripts/check_llm.py`, then follow that project's README.

If a flag is on but its keys are empty, the server stops at startup with a message naming the missing fields.
