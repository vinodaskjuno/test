"""Smoke tests against the running server (needs keys + ingested KB). Skipped if the server is down.
Run: pytest tests/test_smoke.py   (BASE_URL defaults to http://localhost:8003)"""

import os

import pytest
import requests

BASE = os.getenv("BASE_URL", "http://localhost:8003")

try:
    requests.get(f"{BASE}/health", timeout=3)
except requests.RequestException:
    pytest.skip(f"server not running at {BASE}", allow_module_level=True)


def ask(question):
    r = requests.post(f"{BASE}/ask", json={"question": question}, timeout=600)
    assert r.status_code == 200, r.text
    return r.json()


def test_health_reports_flags():
    body = requests.get(f"{BASE}/health", timeout=5).json()
    assert body["portkey"] in ("on", "off") and body["fiddler"] in ("on", "off")


def test_answer_is_cited():
    body = ask("Is sewer backup covered under the homeowners policy?")
    assert body["retrieved"] > 0 and body["citations"]


def test_out_of_kb_question_is_not_answered():
    body = ask("What is the capital of Australia?")
    assert "could not find" in body["answer"].lower()
