"""Deterministic chunking tests: no LLM, no keys needed."""

from app.config import ROOT
from app.kb import KB, chunk_markdown


def test_every_doc_chunks_by_section():
    docs = sorted((ROOT / KB["docs_dir"]).glob("*.md"))
    assert len(docs) >= 8
    for path in docs:
        chunks = list(chunk_markdown(path.read_text(encoding="utf-8"), path.stem))
        assert chunks and all(c["source"].startswith(f"{path.stem}#") for c in chunks)
        assert all(len(c["text"]) <= KB["chunk_size"] + 100 for c in chunks)


def test_long_section_is_windowed():
    body = "x" * 2000
    chunks = list(chunk_markdown(f"# T\n\n## Big\n{body}", "doc"))
    assert len(chunks) > 1 and len({c["id"] for c in chunks}) == len(chunks)
