"""Multi-agent RAG with Strands "agents as tools".

orchestrator ──► query_planner      (splits the question into search queries)
             ──► retriever          (runs search_kb against the local Chroma KB)
             ──► answer_writer      (answers only from retrieved passages, with citations)
             ──► grounding_checker  (verifies every statement against the passages)

Specialists are built per request so retrieved passages stay request-scoped.
"""

from strands import Agent, tool

from app import kb
from app.integrations import get_model, tag_session

NOT_FOUND = "I could not find this in the knowledge base."

ORCHESTRATOR_PROMPT = f"""You coordinate a team of specialist agents to answer insurance questions from a knowledge base.
Always follow these steps:
1. Call query_planner with the user's question.
2. Call retriever with the planned queries.
3. Call answer_writer with the user's question.
4. Call grounding_checker with the drafted answer.
5. If grounding_checker reports ISSUES, call answer_writer once more with the issues as feedback.
Then reply with the final answer exactly as answer_writer wrote it. Never answer from your own knowledge.
If nothing relevant was retrieved, reply: "{NOT_FOUND}" """

PLANNER_PROMPT = """You turn a user question about insurance into 1-3 short, focused search queries for a vector search.
Split multi-part questions. Reply with one query per line and nothing else."""

RETRIEVER_PROMPT = """You retrieve passages from an insurance knowledge base.
Call search_kb once for each query you are given (rephrase a query and search again if results look irrelevant).
When done, reply with a one-line summary of what you found."""

WRITER_PROMPT = f"""You answer insurance questions using ONLY the passages provided.
Cite every fact with its source id in square brackets, e.g. [home_policy_wording#Water Damage].
Be concise and specific (amounts, limits, time frames). If the passages do not answer the question,
reply exactly: "{NOT_FOUND}" """

CHECKER_PROMPT = """You check whether an answer is fully supported by the passages provided.
If every statement is supported, reply with exactly: PASS
Otherwise reply with: ISSUES: followed by a short list of unsupported or wrong statements."""


def _format(passages):
    return "\n\n".join(f"[{p['source']}] (score {p['score']})\n{p['text']}" for p in passages) or "(no passages)"


def answer_question(question: str, session_id: str) -> dict:
    run = {"passages": {}, "answer": None, "grounding": None}

    def specialist(name, prompt, tools=()):
        agent = Agent(name=name, model=get_model(), system_prompt=prompt, tools=list(tools), callback_handler=None)
        tag_session(agent, session_id)
        return agent

    @tool
    def search_kb(query: str) -> str:
        """Vector-search the insurance knowledge base and return the top matching passages.

        Args:
            query: A focused search query.
        """
        hits = kb.search(query)
        for hit in hits:
            run["passages"].setdefault(hit["id"], hit)
        return _format(hits)

    @tool
    def query_planner(question: str) -> str:
        """Break the user's question into 1-3 focused search queries, one per line.

        Args:
            question: The user's question.
        """
        return str(specialist("query_planner", PLANNER_PROMPT)(question)).strip()

    @tool
    def retriever(queries: str) -> str:
        """Retrieve knowledge base passages for the given search queries and return them with source ids.

        Args:
            queries: Search queries, one per line.
        """
        specialist("retriever", RETRIEVER_PROMPT, [search_kb])(queries)
        return _format(run["passages"].values())

    @tool
    def answer_writer(question: str, feedback: str = "") -> str:
        """Draft a cited answer to the question using only the retrieved passages.

        Args:
            question: The user's question.
            feedback: Optional grounding issues to fix from a previous draft.
        """
        prompt = f"Question: {question}\n\nPassages:\n{_format(run['passages'].values())}"
        if feedback:
            prompt += f"\n\nFix these issues from your previous draft:\n{feedback}"
        run["answer"] = str(specialist("answer_writer", WRITER_PROMPT)(prompt)).strip()
        return run["answer"]

    @tool
    def grounding_checker(answer: str) -> str:
        """Check that every statement in the answer is supported by the retrieved passages. Returns PASS or ISSUES.

        Args:
            answer: The drafted answer to verify.
        """
        prompt = f"Answer:\n{answer}\n\nPassages:\n{_format(run['passages'].values())}"
        run["grounding"] = str(specialist("grounding_checker", CHECKER_PROMPT)(prompt)).strip()
        return run["grounding"]

    orchestrator = specialist("orchestrator", ORCHESTRATOR_PROMPT, [query_planner, retriever, answer_writer, grounding_checker])
    final = str(orchestrator(question)).strip()
    answer = run["answer"] or final

    cited = {p["source"]: p for p in run["passages"].values() if f"[{p['source']}]" in answer}.values()
    return {
        "session_id": session_id,
        "answer": answer,
        "citations": [{"source": p["source"], "score": p["score"], "text": p["text"]} for p in cited],
        "grounding": run["grounding"] or "not checked",
        "retrieved": len(run["passages"]),
    }
