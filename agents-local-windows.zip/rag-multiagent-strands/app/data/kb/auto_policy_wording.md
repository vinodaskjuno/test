# Personal Auto Policy Wording (Northstar Mutual, synthetic)

## Coverage A - Liability
We pay damages for bodily injury or property damage for which an insured becomes legally responsible because of an auto accident. Standard limits are 100/300/100: $100,000 per person, $300,000 per accident for bodily injury and $100,000 for property damage. Defense costs are paid in addition to the limit.

## Coverage B - Medical Payments
We pay reasonable medical expenses up to $5,000 per person for injuries sustained while occupying a covered auto, regardless of fault. Expenses must be incurred within 3 years of the accident.

## Coverage C - Collision
We pay for direct and accidental loss to a covered auto caused by collision with another object or by upset, minus the collision deductible. The standard collision deductible is $500.

## Coverage D - Comprehensive (Other Than Collision)
Covers theft, fire, flood, hail, vandalism, falling objects and contact with animals. The standard comprehensive deductible is $250. Glass damage is covered with no deductible when the glass is repaired rather than replaced.

## Rental Reimbursement
When a covered auto is out of service due to a covered loss, we pay up to $40 per day for a rental car, to a maximum of 30 days.

## Who Is Insured
The named insured, resident relatives, and anyone using a covered auto with permission. Rideshare driving (while logged into a transportation network app) is NOT covered unless the Rideshare Endorsement is attached.
