# Homeowners Policy Wording HO-3 (Northstar Mutual, synthetic)

## Coverage A - Dwelling
Covers the dwelling on an open-perils basis at replacement cost, up to the Coverage A limit. Coverage A is typically set at 100% of the estimated replacement cost.

## Coverage B - Other Structures
Covers detached structures such as fences and sheds at 10% of the Coverage A limit.

## Coverage C - Personal Property
Covers contents at 50% of Coverage A on a named-perils basis. Contents are settled at actual cash value unless the Replacement Cost Contents Endorsement is attached. Special limits apply: jewelry theft $1,500, firearms theft $2,500, cash $200.

## Coverage D - Loss of Use
Pays additional living expenses at 20% of Coverage A while the home is uninhabitable due to a covered loss.

## Coverage E - Personal Liability
$300,000 per occurrence for bodily injury or property damage to others.

## Water Damage
Sudden and accidental discharge of water from plumbing or appliances is covered. Gradual leaks, seepage over 14 days or more, and surface water flooding are excluded. Sewer backup is excluded unless the Water Backup Endorsement is purchased.
