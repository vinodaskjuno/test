# Deductibles and Limits Explainer (synthetic)

## What is a deductible?
The deductible is the amount the insured pays on each covered claim before the policy pays. It is applied once per occurrence.

## Homeowners deductible options
All-peril deductibles of $1,000, $2,500 or $5,000. Choosing $2,500 reduces the premium by about 10%, and $5,000 by about 18%.

## Wind and hail deductible
In coastal states a separate wind/hail deductible of 2% of Coverage A applies. For a $400,000 dwelling limit that is $8,000.

## Auto deductibles
Collision deductibles of $250, $500 or $1,000; comprehensive deductibles of $0, $250 or $500.

## Limits
A limit is the most the policy will pay. Sub-limits cap specific property types, for example $1,500 for jewelry theft on the HO-3 policy.
