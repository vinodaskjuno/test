# Commercial Property Policy Wording (Northstar Mutual, synthetic)

## Covered Property
Building, business personal property, and personal property of others in the insured's care, at the described premises.

## Causes of Loss
Written on a Special Form (open perils) basis. Earthquake and flood are excluded unless scheduled by endorsement.

## Business Income
Business income and extra expense are covered for up to 12 months following a covered direct physical loss. A 72-hour waiting period applies before business income loss is payable.

## Coinsurance
A 90% coinsurance clause applies. If the building is insured for less than 90% of its value at the time of loss, the claim payment is reduced proportionally.

## Vacancy
If the building has been vacant for more than 60 consecutive days, we do not pay for vandalism, glass breakage or water damage, and other losses are reduced by 15%.
