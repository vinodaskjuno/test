# Endorsements Guide (synthetic)

## Water Backup Endorsement
Adds cover for water backing up through sewers or drains, with a limit of $10,000 or $25,000. Not available in flood zones VE.

## Scheduled Personal Property
Schedules high-value items such as jewelry, art and instruments at an agreed value with no deductible. Requires an appraisal dated within 3 years for items over $5,000.

## Replacement Cost Contents
Changes Coverage C settlement from actual cash value to replacement cost. Adds about 10% to the homeowners premium.

## Rideshare Endorsement
Extends the personal auto policy to cover driving while logged into a rideshare app and waiting for a ride request (Period 1). Periods 2 and 3 are covered by the rideshare company's policy.

## Home Business Endorsement
Raises business property in the home to $10,000 and adds liability for home-business activities with no more than 2 employees.
