# Claims Handling SOP (synthetic)

## First Notice of Loss (FNOL)
Every claim must be acknowledged within 24 hours of FNOL. The adjuster records the policy number, date and location of loss, cause of loss, estimated amount and contact details.

## Assignment
Claims under $10,000 are handled by the fast-track desk. Claims from $10,000 to $100,000 go to a field adjuster. Claims above $100,000, or any bodily injury claim, go to a senior adjuster.

## Investigation and Inspection
Property claims above $5,000 require an inspection within 5 business days. Photos, repair estimates and, for theft, a police report are required.

## Decision Timelines
A coverage decision must be communicated within 30 days of receiving a complete proof of loss. If more time is needed, the insured must be notified in writing with the reason.

## Payment
Undisputed amounts are paid within 10 business days of agreement. Payments above $50,000 need manager approval.

## Escalation
Any claim showing two or more fraud indicators must be referred to the Special Investigations Unit (SIU) before payment.
