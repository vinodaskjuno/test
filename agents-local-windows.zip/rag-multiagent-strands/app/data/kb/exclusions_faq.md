# Common Exclusions FAQ (synthetic)

## Is flood covered under a homeowners policy?
No. Surface water, storm surge and rising water are excluded from the HO-3 policy. Flood cover requires a separate flood policy. Water damage from a burst pipe inside the home is covered because it is sudden and accidental.

## Is mold covered?
Mold is excluded unless it results directly from a covered water loss, in which case remediation is limited to $10,000 per policy term.

## Is wear and tear covered?
No. Wear and tear, deterioration, rust, and mechanical breakdown are excluded on all property forms.

## Is earthquake covered?
Earthquake and earth movement are excluded on homeowners and commercial forms unless added by an Earthquake Endorsement, which carries a separate deductible of 10% of Coverage A.

## Are intentional acts covered?
No. Loss intentionally caused by or at the direction of an insured is excluded under all forms.

## Is business use of a home covered?
Business property in the home is limited to $2,500. Liability from home-business activities is excluded without a Home Business Endorsement.
