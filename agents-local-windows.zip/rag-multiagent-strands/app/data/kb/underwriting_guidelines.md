# Homeowners Underwriting Guidelines (synthetic)

## Eligibility
Owner-occupied single-family homes, townhomes and condos. Properties under renovation, vacant for over 30 days, or used for short-term rentals over 90 days a year are ineligible.

## Roof Requirements
Roofs older than 20 years need an inspection report. Roofs older than 25 years in extreme wildfire areas are declined.

## Protection Class
Homes more than 5 miles from a fire station receive a surcharge and must have a monitored fire alarm.

## Referral Triggers
Refer to a senior underwriter when: the home is in flood zone AE or VE, the replacement cost exceeds $1,000,000, or the risk score is 55 or higher.

## Decline Triggers
Decline when: the risk score is 80 or higher, the applicant has 4 or more claims in 5 years, or the home has an unrepaired prior loss.
