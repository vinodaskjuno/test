# Fraud Indicators Guide (synthetic)

## Timing Indicators
- Loss occurs within 60 days of policy inception or a coverage increase.
- Claim reported more than 30 days after the date of loss without a reasonable explanation.

## Claimant Behaviour
- Pressure for a quick settlement or unusual familiarity with claims terms.
- Reluctance to provide documentation or to allow an inspection.
- Prior claims: three or more claims in the last 5 years.

## Documentation Indicators
- Receipts or estimates that appear altered or come from the same vendor for unrelated items.
- Claimed amount close to or exactly at the policy limit.

## SIU Referral
Two or more indicators require referral to the Special Investigations Unit. The adjuster must not tell the claimant that a referral has been made. A referral is not an accusation; payment of undisputed amounts may continue with SIU approval.
