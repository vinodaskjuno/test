"""FastAPI server for the multi-agent RAG app. Swagger UI at /docs."""

import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from app import agents, integrations, kb


@asynccontextmanager
async def lifespan(_: FastAPI):
    integrations.init_observability()
    yield


app = FastAPI(title="Multi-agent RAG (Strands)", lifespan=lifespan)


class AskRequest(BaseModel):
    question: str
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()))


def _call(fn, *args):
    try:
        return fn(*args)
    except Exception as e:  # surface LLM/credential/KB errors to the caller
        raise HTTPException(status_code=500, detail=f"{type(e).__name__}: {e}")


@app.get("/health")
def health():
    return integrations.status()


@app.post("/ingest")
def ingest():
    return _call(kb.ingest)


@app.post("/ask")
def ask(req: AskRequest):
    return _call(agents.answer_question, req.question, req.session_id)
