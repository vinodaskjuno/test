"""Portkey (AI gateway) and Fiddler (observability) wiring.

This is the only module that knows about Portkey or Fiddler. Agent code calls
get_model() / embed(); the server calls init_observability() once at startup.
"""

import json
import os
from functools import lru_cache

import boto3

from app.config import CONFIG

APP, LLM, AWS = CONFIG["app"], CONFIG["llm"], CONFIG["aws"]
PORTKEY, FIDDLER = CONFIG["portkey"], CONFIG["fiddler"]
EMBED_MODEL_ID = CONFIG["embeddings"]["model_id"]


def _require(name, section, *keys):
    missing = [k for k in keys if not section.get(k)]
    if missing:
        hint = "" if name == "llm" else f" or set {name}.enabled: false in config.yaml"
        raise RuntimeError(f"{name}: {missing} empty: set them in .env{hint}")


def _portkey_headers():
    from portkey_ai import createHeaders

    _require("portkey", PORTKEY, "api_key")
    return createHeaders(
        api_key=PORTKEY["api_key"],
        provider="bedrock",
        aws_access_key_id=AWS["access_key_id"],
        aws_secret_access_key=AWS["secret_access_key"],
        aws_session_token=AWS["session_token"],
        aws_region=AWS["region"],
        metadata={"project": APP["name"]},
    )


def _boto_session():
    return boto3.Session(
        aws_access_key_id=AWS["access_key_id"] or None,
        aws_secret_access_key=AWS["secret_access_key"] or None,
        aws_session_token=AWS["session_token"] or None,
        region_name=AWS["region"] or None,
    )


def get_model():
    """Claude on Bedrock: through the Portkey gateway when enabled, otherwise direct."""
    _require("llm", LLM, "model_id")
    if PORTKEY["enabled"]:
        from strands.models.openai import OpenAIModel

        return OpenAIModel(
            client_args={"api_key": PORTKEY["api_key"], "base_url": PORTKEY["base_url"], "default_headers": _portkey_headers()},
            model_id=LLM["model_id"],
            params={"temperature": LLM["temperature"], "max_tokens": LLM["max_tokens"]},
        )

    from strands.models import BedrockModel

    return BedrockModel(
        boto_session=_boto_session(),
        model_id=LLM["model_id"],
        temperature=LLM["temperature"],
        max_tokens=LLM["max_tokens"],
    )


@lru_cache
def _embed_client():
    if PORTKEY["enabled"]:
        from openai import OpenAI

        return OpenAI(api_key=PORTKEY["api_key"], base_url=PORTKEY["base_url"], default_headers=_portkey_headers())
    return _boto_session().client("bedrock-runtime")


def embed(texts):
    """Titan embeddings, one call per text: through Portkey when enabled, otherwise direct Bedrock."""
    client = _embed_client()
    if PORTKEY["enabled"]:
        return [client.embeddings.create(model=EMBED_MODEL_ID, input=t).data[0].embedding for t in texts]
    return [
        json.loads(client.invoke_model(modelId=EMBED_MODEL_ID, body=json.dumps({"inputText": t}))["body"].read())["embedding"]
        for t in texts
    ]


def init_observability():
    """Export Strands agent traces to Fiddler over OTLP. No-op when disabled."""
    if not FIDDLER["enabled"]:
        return
    _require("fiddler", FIDDLER, "url", "api_key", "application_id")

    # Fiddler routes spans by the application.id resource attribute.
    os.environ["OTEL_SERVICE_NAME"] = APP["name"]
    os.environ["OTEL_RESOURCE_ATTRIBUTES"] = f"application.id={FIDDLER['application_id']}"

    from fiddler_strandsagents import StrandsAgentInstrumentor
    from strands.telemetry import StrandsTelemetry

    telemetry = StrandsTelemetry().setup_otlp_exporter(
        endpoint=f"{FIDDLER['url'].rstrip('/')}/v1/traces",
        headers={
            "authorization": f"Bearer {FIDDLER['api_key']}",
            "fiddler-application-id": FIDDLER["application_id"],
        },
    )
    StrandsAgentInstrumentor(telemetry).instrument()


def tag_session(agent, session_id):
    """Group an agent's invocations into one Fiddler conversation. No-op when disabled."""
    if FIDDLER["enabled"]:
        from fiddler_strandsagents import set_conversation_id

        set_conversation_id(agent, session_id)


def status():
    return {
        "app": APP["name"],
        "portkey": "on" if PORTKEY["enabled"] else "off",
        "fiddler": "on" if FIDDLER["enabled"] else "off",
        "model_id": LLM["model_id"],
        "embedding_model_id": EMBED_MODEL_ID,
    }
