"""Local knowledge base: markdown docs -> section chunks -> Chroma (on disk)."""

import re

import chromadb

from app.config import CONFIG, ROOT
from app.integrations import embed

KB = CONFIG["kb"]
COLLECTION = "insurance_kb"


def _client():
    return chromadb.PersistentClient(path=str(ROOT / KB["chroma_dir"]))


def chunk_markdown(text, doc):
    """Split on '## ' sections, then window long sections. Source id = 'doc#Section'."""
    size, overlap = KB["chunk_size"], KB["chunk_overlap"]
    for section in re.split(r"^## ", text, flags=re.M)[1:]:
        heading, _, body = section.partition("\n")
        heading, body = heading.strip(), body.strip()
        for i, start in enumerate(range(0, max(len(body), 1), size - overlap)):
            yield {
                "id": f"{doc}#{heading}#{i}",
                "source": f"{doc}#{heading}",
                "text": f"{heading}\n{body[start:start + size]}",
            }


def ingest():
    """(Re)build the Chroma collection from the markdown docs. Returns counts."""
    chunks = [
        chunk
        for path in sorted((ROOT / KB["docs_dir"]).glob("*.md"))
        for chunk in chunk_markdown(path.read_text(encoding="utf-8"), path.stem)
    ]
    client = _client()
    if COLLECTION in [c.name for c in client.list_collections()]:
        client.delete_collection(COLLECTION)
    collection = client.create_collection(COLLECTION, embedding_function=None, metadata={"hnsw:space": "cosine"})
    collection.add(
        ids=[c["id"] for c in chunks],
        documents=[c["text"] for c in chunks],
        metadatas=[{"source": c["source"]} for c in chunks],
        embeddings=embed([c["text"] for c in chunks]),
    )
    return {"docs": len({c["source"].split("#")[0] for c in chunks}), "chunks": len(chunks)}


def search(query, k=None):
    collection = _client().get_collection(COLLECTION, embedding_function=None)
    res = collection.query(query_embeddings=embed([query]), n_results=k or KB["top_k"])
    return [
        {"id": id_, "source": meta["source"], "score": round(1 - dist, 3), "text": text}
        for id_, meta, dist, text in zip(res["ids"][0], res["metadatas"][0], res["distances"][0], res["documents"][0])
    ]


if __name__ == "__main__":
    print(ingest())
