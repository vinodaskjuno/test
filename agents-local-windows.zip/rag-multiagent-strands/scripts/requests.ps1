# Sample calls against the running server. Usage: .\scripts\requests.ps1 [-Base http://localhost:8003]
param([string]$Base = "http://localhost:8003")

function Ask($Question) {
    try { Invoke-RestMethod -Method Post -Uri "$Base/ask" -ContentType "application/json" -Body (@{ question = $Question; session_id = 'rag-demo' } | ConvertTo-Json) -TimeoutSec 600 | ConvertTo-Json -Depth 10 }
    catch { "ERROR: $($_.ErrorDetails.Message)" }
    ""
}

"== health"; Invoke-RestMethod "$Base/health" | ConvertTo-Json; ""
"== ingest"; Invoke-RestMethod -Method Post "$Base/ingest" -TimeoutSec 600 | ConvertTo-Json; ""
"== single doc";     Ask 'How long is rental reimbursement paid under the auto policy and at what daily rate?'
"== cross doc";      Ask 'A claimant reports a theft 45 days after buying the policy and has 3 prior claims. What should the adjuster do?'
"== exclusion edge"; Ask 'My basement flooded from a sewer backup. Am I covered, and what can I add to my policy?'
"== out of KB";      Ask 'What is the capital of Australia?'
