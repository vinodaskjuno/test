#!/usr/bin/env bash
# Sample calls against the running server. Usage: ./scripts/requests.sh [base_url]
BASE=${1:-http://localhost:8003}
ask() { curl -s -X POST "$BASE/ask" -H 'Content-Type: application/json' -d "{\"question\": \"$1\", \"session_id\": \"rag-demo\"}"; echo; echo; }

echo "== health";          curl -s "$BASE/health"; echo; echo
echo "== ingest";          curl -s -X POST "$BASE/ingest"; echo; echo
echo "== single doc";      ask "How long is rental reimbursement paid under the auto policy and at what daily rate?"
echo "== cross doc";       ask "A claimant reports a theft 45 days after buying the policy and has 3 prior claims. What should the adjuster do?"
echo "== exclusion edge";  ask "My basement flooded from a sewer backup. Am I covered, and what can I add to my policy?"
echo "== out of KB";       ask "What is the capital of Australia?"
