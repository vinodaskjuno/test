"""Streamlit chat UI for the multi-agent RAG app. Run: streamlit run ui.py --server.port 8503"""

import os
import uuid

import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8003")

st.set_page_config(page_title="Insurance KB Assistant", page_icon="📚")
st.title("📚 Insurance KB Assistant (multi-agent RAG)")

if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())
    st.session_state.history = []

with st.sidebar:
    try:
        st.json(requests.get(f"{API_URL}/health", timeout=5).json())
    except requests.RequestException:
        st.error(f"API not reachable at {API_URL}")
    if st.button("Re-ingest knowledge base"):
        with st.spinner("Embedding docs..."):
            r = requests.post(f"{API_URL}/ingest", timeout=600)
        st.success(r.json()) if r.ok else st.error(r.text)
    st.caption(f"Session: {st.session_state.session_id}")
    st.markdown("Try: *Is sewer backup covered?*, *What deductible applies to a wind claim on a $400k home?*")


def render(body):
    st.markdown(body["answer"])
    st.caption(f"Grounding: {body['grounding']} · passages retrieved: {body['retrieved']}")
    for c in body["citations"]:
        with st.expander(f"📄 {c['source']} (score {c['score']})"):
            st.text(c["text"])


for role, content in st.session_state.history:
    with st.chat_message(role):
        render(content) if role == "assistant" else st.markdown(content)

if question := st.chat_input("Ask about policies, exclusions, claims or underwriting"):
    st.chat_message("user").markdown(question)
    st.session_state.history.append(("user", question))
    with st.chat_message("assistant"), st.spinner("Planning → retrieving → writing → checking..."):
        r = requests.post(f"{API_URL}/ask", json={"question": question, "session_id": st.session_state.session_id}, timeout=600)
        if not r.ok:
            st.error(f"Error {r.status_code}: {r.text}")
        else:
            render(r.json())
            st.session_state.history.append(("assistant", r.json()))
