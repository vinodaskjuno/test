# Multi-agent RAG — Strands Agents (agents as tools)

A multi-agent RAG app over a **local knowledge base**: 9 synthetic insurance docs in `app/data/kb/`, embedded with Bedrock Titan v2 and stored in Chroma on disk (`.chroma/`). It is used to validate **Portkey** and **Fiddler**.

```
orchestrator ──► query_planner      splits the question into search queries
             ──► retriever          calls search_kb (Chroma) for each query
             ──► answer_writer      answers only from passages, cites [doc#Section]
             ──► grounding_checker  PASS / ISSUES  (one rewrite if issues)
```

## Where Portkey and Fiddler live
Only two files know about them:
- `config.yaml` holds the `portkey.enabled` and `fiddler.enabled` flags.
- `app/integrations.py` contains all the Portkey and Fiddler code:
  - `get_model()`: Portkey ON uses `OpenAIModel` → Portkey (provider `bedrock`, AWS creds sent in headers). Portkey OFF uses `BedrockModel`.
  - `embed()`: Titan embeddings. Portkey ON uses the OpenAI-compatible `/embeddings` call through Portkey. Portkey OFF uses boto3 `invoke_model`.
  - `init_observability()`: Fiddler ON runs `StrandsTelemetry` OTLP → Fiddler, plus `StrandsAgentInstrumentor`. All 5 agents are traced.

## Setup
```bash
cd rag-multiagent-strands
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill in values; enable Claude + Titan Embed v2 in the Bedrock console
python scripts/check_llm.py # checks embeddings + LLM on the active path
python -m app.kb            # build the local KB (re-run after editing docs or switching embedding path)
```

## Run
```bash
uvicorn app.server:app --port 8003 --reload       # API + Swagger at http://localhost:8003/docs
streamlit run ui.py --server.port 8503            # chat UI at http://localhost:8503
./scripts/requests.sh                             # ingest + 4 sample questions
pytest tests/                                     # chunking tests + smoke tests (smoke needs server)
```

Endpoints:
- `GET /health`
- `POST /ingest`
- `POST /ask {question, session_id?}` returns `{answer, citations, grounding, retrieved}`

## Validation matrix
Edit the flags in `config.yaml`, restart uvicorn, then run `./scripts/requests.sh`.

| portkey | fiddler | Check |
|---|---|---|
| off | off | Answers come back with citations, straight from Bedrock |
| on | off | Portkey logs show Claude chat calls **and** Titan embedding calls (metadata `project=rag-multiagent-strands`) |
| off | on | Fiddler shows orchestrator → sub-agent → `search_kb` spans, grouped by `session_id` |
| on | on | Both of the above |

Extra check: the out-of-KB question ("capital of Australia") must return "I could not find this in the knowledge base."
