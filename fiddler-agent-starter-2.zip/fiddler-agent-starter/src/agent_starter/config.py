"""Reads Fiddler settings from environment variables."""

import os
from dataclasses import dataclass

REQUIRED_VARS = ("FIDDLER_API_KEY", "FIDDLER_APPLICATION_ID", "FIDDLER_URL")


@dataclass(frozen=True)
class FiddlerSettings:
    api_key: str
    application_id: str
    url: str
    console_tracer: bool


def _truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in ("1", "true", "yes", "on")


def tracing_disabled() -> bool:
    return _truthy(os.getenv("AGENT_STARTER_DISABLE"))


def load_settings() -> tuple[FiddlerSettings | None, list[str]]:
    """Returns (settings, missing_vars). settings is None if anything is missing."""
    missing = [name for name in REQUIRED_VARS if not os.getenv(name, "").strip()]
    if missing:
        return None, missing
    return (
        FiddlerSettings(
            api_key=os.environ["FIDDLER_API_KEY"].strip(),
            application_id=os.environ["FIDDLER_APPLICATION_ID"].strip(),
            url=os.environ["FIDDLER_URL"].strip().rstrip("/"),
            console_tracer=_truthy(os.getenv("FIDDLER_CONSOLE_TRACER")),
        ),
        [],
    )
