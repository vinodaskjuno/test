"""Importing this module turns on Fiddler tracing.

One-line alternative to the launcher:  import agent_starter.auto
"""

from agent_starter.bootstrap import init_fiddler

init_fiddler()
