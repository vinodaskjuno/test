"""agent-starter-run: runs any Python agent with Fiddler tracing turned on.

    agent-starter-run python app.py [args...]
    agent-starter-run app.py [args...]
    agent-starter-run python -m my_package.main [args...]
    agent-starter-run --check
"""

import os
import runpy
import sys

from agent_starter.bootstrap import init_fiddler

USAGE = (
    "usage: agent-starter-run [python] SCRIPT.py [args...]\n"
    "       agent-starter-run [python] -m MODULE [args...]\n"
    "       agent-starter-run --check"
)


def _check() -> int:
    from dotenv import load_dotenv

    from agent_starter.config import REQUIRED_VARS

    load_dotenv(os.path.join(os.getcwd(), ".env"), override=False)
    ok = True
    print(f"Python: {sys.version.split()[0]}")
    try:
        import fiddler_langgraph

        print(f"fiddler-langgraph: {fiddler_langgraph.__version__}")
    except ImportError:
        print("fiddler-langgraph: NOT INSTALLED")
        ok = False
    for name in REQUIRED_VARS:
        present = bool(os.getenv(name, "").strip())
        print(f"{name}: {'set' if present else 'MISSING'}")
        ok = ok and present
    print("Ready" if ok else "Not ready: fix the items above")
    return 0 if ok else 1


def main() -> None:
    args = sys.argv[1:]
    if args and args[0] == "--check":
        sys.exit(_check())
    if args and os.path.basename(args[0]).startswith("python"):
        args = args[1:]  # allow "agent-starter-run python app.py"
    if not args or args[0] in ("-h", "--help"):
        print(USAGE)
        sys.exit(0 if args else 2)

    # Tracing must be on before the agent's code is imported.
    init_fiddler()

    if args[0] == "-m":
        if len(args) < 2:
            print(USAGE)
            sys.exit(2)
        module = args[1]
        sys.argv = [module] + args[2:]
        sys.path.insert(0, os.getcwd())
        runpy.run_module(module, run_name="__main__", alter_sys=True)
    else:
        script = args[0]
        if not os.path.isfile(script):
            print(f"agent-starter-run: file not found: {script}")
            sys.exit(2)
        sys.argv = args
        sys.path.insert(0, os.path.dirname(os.path.abspath(script)))
        runpy.run_path(script, run_name="__main__")


if __name__ == "__main__":
    main()
