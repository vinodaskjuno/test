"""Turns on Fiddler tracing for LangGraph. Safe to call more than once."""

import atexit
import os
import sys

from dotenv import load_dotenv

from agent_starter.config import load_settings, tracing_disabled

_initialized = False
_client = None


def _say(message: str) -> None:
    print(f"[agent-starter] {message}", file=sys.stderr, flush=True)


def _flush_on_exit() -> None:
    if _client is None:
        return
    try:
        _client.force_flush()
    except Exception as exc:  # never crash the agent because of tracing
        _say(f"Could not flush traces on exit: {exc}")


def init_fiddler(env_file: str | None = None):
    """Loads .env, creates the Fiddler client and instruments LangGraph.

    Returns the FiddlerClient, or None when tracing is off. The agent keeps
    running either way: missing settings only turn tracing off.
    """
    global _initialized, _client
    if _initialized:
        return _client
    _initialized = True

    # Values already set in the shell win over the .env file.
    load_dotenv(env_file or os.path.join(os.getcwd(), ".env"), override=False)

    if tracing_disabled():
        _say("Fiddler tracing is OFF (AGENT_STARTER_DISABLE is set).")
        return None

    settings, missing = load_settings()
    if settings is None:
        _say("Fiddler tracing is OFF. Missing: " + ", ".join(missing))
        _say("Set them in .env or your shell to turn tracing on.")
        return None

    try:
        from fiddler_langgraph import FiddlerClient, LangGraphInstrumentor
    except ImportError as exc:
        _say(f"Fiddler tracing is OFF. fiddler-langgraph is not installed ({exc}).")
        return None

    try:
        _client = FiddlerClient(
            application_id=settings.application_id,
            api_key=settings.api_key,
            url=settings.url,
            console_tracer=settings.console_tracer,
        )
        LangGraphInstrumentor(_client).instrument()
    except Exception as exc:
        _client = None
        _say(f"Fiddler tracing is OFF. Setup failed: {exc}")
        return None

    atexit.register(_flush_on_exit)
    _say(f"Fiddler tracing is ON -> {settings.url} (app {settings.application_id})")
    return _client
