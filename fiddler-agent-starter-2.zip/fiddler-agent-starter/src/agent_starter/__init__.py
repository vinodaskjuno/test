"""Starter pack: turns on Fiddler tracing for any LangGraph agent."""

from agent_starter.bootstrap import init_fiddler

__all__ = ["init_fiddler"]
__version__ = "0.1.0"
