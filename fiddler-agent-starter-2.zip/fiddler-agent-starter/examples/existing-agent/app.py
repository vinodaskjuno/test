"""An EXISTING agent with no Fiddler code in it.

Ticket triage: classifies a support ticket, then drafts a reply.
Used to show that the starter pack can trace an agent without editing it.
"""

import os
import sys
from typing import TypedDict

from langchain_aws import ChatBedrockConverse
from langgraph.graph import END, START, StateGraph

llm = ChatBedrockConverse(
    model=os.getenv("BEDROCK_MODEL_ID", "us.anthropic.claude-haiku-4-5-20251001-v1:0"),
    region_name=os.getenv("AWS_REGION", "us-east-1"),
    temperature=0,
)


class TicketState(TypedDict):
    ticket: str
    category: str
    reply: str


def classify(state: TicketState):
    response = llm.invoke(
        "Classify this support ticket with one word: billing, technical or general.\n\n"
        f"Ticket: {state['ticket']}"
    )
    return {"category": response.text.strip().lower()}


def draft_reply(state: TicketState):
    response = llm.invoke(
        f"Write a short, friendly reply to this {state['category']} support ticket.\n\n"
        f"Ticket: {state['ticket']}"
    )
    return {"reply": response.text}


graph = StateGraph(TicketState)
graph.add_node("classify", classify)
graph.add_node("draft_reply", draft_reply)
graph.add_edge(START, "classify")
graph.add_edge("classify", "draft_reply")
graph.add_edge("draft_reply", END)
app = graph.compile()


if __name__ == "__main__":
    ticket = " ".join(sys.argv[1:]) or "I was charged twice for my subscription this month."
    result = app.invoke({"ticket": ticket})
    print(f"Category: {result['category']}\n\nReply:\n{result['reply']}")
