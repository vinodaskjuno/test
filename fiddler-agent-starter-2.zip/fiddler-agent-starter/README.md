# Fiddler agent starter pack

LangGraph agents with Fiddler tracing built in. Requires Python 3.11+.

## New agent
1. Create a repo from this template (or copy the `template/` folder).
2. `cd template && python -m venv .venv && source .venv/bin/activate`
3. `pip install -e .. && pip install -r requirements.txt`
4. `cp .env.example .env` and fill in the Fiddler and AWS Bedrock values.
5. `agent-starter-run --check`, then `python run.py`.
6. Build your agent in `agent/graph.py` (keep `build_agent()`).

## Existing agent (no code changes)
1. In your agent's environment: `pip install "agent-starter @ git+https://github.com/YOUR_ORG/fiddler-agent-starter.git@v0.1.0"`
2. Set `FIDDLER_API_KEY`, `FIDDLER_APPLICATION_ID`, `FIDDLER_URL` (shell or `.env` in the working folder).
3. Run `agent-starter-run python app.py` instead of `python app.py`.

Alternative: add `import agent_starter.auto` as the first line of your entry file.

Turn tracing off: `AGENT_STARTER_DISABLE=1`. Print spans locally: `FIDDLER_CONSOLE_TRACER=true`.
