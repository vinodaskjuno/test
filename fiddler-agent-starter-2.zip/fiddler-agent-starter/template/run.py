"""Runs the agent with Fiddler tracing. Part of the starter pack: no need to edit.

    python run.py                          # runs two demo questions
    python run.py "Where is order A200?"   # asks your own question
"""

import sys
import uuid

from agent_starter import init_fiddler

init_fiddler()  # must run before the agent is built

from fiddler_langgraph import set_conversation_id  # noqa: E402

from agent.graph import build_agent  # noqa: E402

DEMO_QUESTIONS = [
    "What is the status of order A100?",
    "What is 21.5 plus 20.5?",
]


def main() -> None:
    agent = build_agent()
    set_conversation_id(str(uuid.uuid4()))  # groups this run's questions in Fiddler
    for question in sys.argv[1:] or DEMO_QUESTIONS:
        result = agent.invoke({"messages": [("user", question)]})
        print(f"\nQ: {question}\nA: {result['messages'][-1].text}")


if __name__ == "__main__":
    main()
