"""YOUR AGENT GOES HERE. This is the only file you need to edit.

Demo: a support assistant that can look up orders and do simple math.
Replace the tools, prompt and graph with your own. Keep a build_agent()
function that returns a compiled LangGraph graph.
"""

import os
from typing import Annotated, TypedDict

from langchain_core.messages import SystemMessage
from langchain_core.tools import tool
from langchain_aws import ChatBedrockConverse
from langgraph.graph import START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

SYSTEM_PROMPT = SystemMessage(
    "You are a friendly support assistant. Use the tools when they help. "
    "Keep answers short."
)

# Any Bedrock model that supports tool use. Copy the ID from the Bedrock console.
DEFAULT_MODEL_ID = "us.anthropic.claude-haiku-4-5-20251001-v1:0"

FAKE_ORDERS = {"A100": "shipped", "A200": "processing", "A300": "delivered"}


@tool
def get_order_status(order_id: str) -> str:
    """Look up the status of an order by its ID, for example A100."""
    return FAKE_ORDERS.get(order_id.strip().upper(), "not found")


@tool
def add_numbers(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b


TOOLS = [get_order_status, add_numbers]


class State(TypedDict):
    messages: Annotated[list, add_messages]


def build_agent():
    # AWS credentials come from the standard chain: env vars, AWS_PROFILE, SSO or an IAM role.
    llm = ChatBedrockConverse(
        model=os.getenv("BEDROCK_MODEL_ID", DEFAULT_MODEL_ID),
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        temperature=0,
    )
    llm_with_tools = llm.bind_tools(TOOLS)

    def call_model(state: State):
        return {"messages": [llm_with_tools.invoke([SYSTEM_PROMPT] + state["messages"])]}

    graph = StateGraph(State)
    graph.add_node("agent", call_model)
    graph.add_node("tools", ToolNode(TOOLS))
    graph.add_edge(START, "agent")
    graph.add_conditional_edges("agent", tools_condition)  # tool call? -> tools, else end
    graph.add_edge("tools", "agent")
    return graph.compile()
