"""Runtime configuration, read from environment variables only.

The same container image runs on AgentCore, ECS and EKS; only these env vars change.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from functools import lru_cache

DEFAULT_BEDROCK_MODEL_ID = "us.anthropic.claude-opus-5-5"


class ConfigError(RuntimeError):
    """Raised when required configuration is missing or invalid."""


def _env(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name, default)
    if value is None:
        return None
    value = value.strip()
    return value or default


@dataclass(frozen=True)
class Settings:
    llm_provider: str  # "portkey" (default) or "bedrock"
    model_id: str
    deploy_platform: str  # local | agentcore | ecs | eks
    aws_region: str | None
    max_tokens: int
    # Portkey
    portkey_base_url: str | None = None
    portkey_api_key: str | None = field(default=None, repr=False)
    portkey_provider: str | None = None
    portkey_virtual_key: str | None = None
    portkey_config: str | None = None
    portkey_trace_id_prefix: str = "triage"


def _resolve_portkey_api_key() -> str | None:
    """PORTKEY_API_KEY wins; otherwise read it from Secrets Manager.

    The secret can be a plain string, or JSON with a "PORTKEY_API_KEY" / "api_key" field.
    """
    key = _env("PORTKEY_API_KEY")
    if key:
        return key

    secret_arn = _env("PORTKEY_API_KEY_SECRET_ARN")
    if not secret_arn:
        return None

    import boto3  # imported lazily so local runs without AWS creds don't need it

    client = boto3.client("secretsmanager", region_name=_env("AWS_REGION") or _env("AWS_DEFAULT_REGION"))
    raw = client.get_secret_value(SecretId=secret_arn)["SecretString"].strip()
    if raw.startswith("{"):
        data = json.loads(raw)
        return data.get("PORTKEY_API_KEY") or data.get("api_key")
    return raw


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    provider = (_env("LLM_PROVIDER", "portkey") or "portkey").lower()
    if provider not in {"portkey", "bedrock"}:
        raise ConfigError(f"LLM_PROVIDER must be 'portkey' or 'bedrock', got {provider!r}")

    model_id = _env("MODEL_ID")
    if provider == "bedrock" and not model_id:
        model_id = DEFAULT_BEDROCK_MODEL_ID
    if not model_id:
        raise ConfigError(
            "MODEL_ID is required with LLM_PROVIDER=portkey, e.g. "
            "'@<your-bedrock-provider-slug>/us.anthropic.claude-opus-5-5'"
        )

    settings = Settings(
        llm_provider=provider,
        model_id=model_id,
        deploy_platform=(_env("DEPLOY_PLATFORM", "local") or "local").lower(),
        aws_region=_env("AWS_REGION") or _env("AWS_DEFAULT_REGION"),
        max_tokens=int(_env("MAX_TOKENS", "4096") or "4096"),
        portkey_base_url=_env("PORTKEY_BASE_URL"),
        portkey_api_key=_resolve_portkey_api_key() if provider == "portkey" else None,
        portkey_provider=_env("PORTKEY_PROVIDER"),
        portkey_virtual_key=_env("PORTKEY_VIRTUAL_KEY"),
        portkey_config=_env("PORTKEY_CONFIG"),
        portkey_trace_id_prefix=_env("PORTKEY_TRACE_ID_PREFIX", "triage") or "triage",
    )

    if provider == "portkey" and not settings.portkey_api_key:
        raise ConfigError(
            "Portkey API key not found. Set PORTKEY_API_KEY, or PORTKEY_API_KEY_SECRET_ARN "
            "(Secrets Manager). To bypass Portkey for debugging, set LLM_PROVIDER=bedrock."
        )
    return settings
