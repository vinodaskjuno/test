"""Ticket triage agent: one codebase that runs on AgentCore Runtime, ECS and EKS."""

__version__ = "1.0.0"
