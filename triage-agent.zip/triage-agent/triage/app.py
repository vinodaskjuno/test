"""HTTP entrypoint, the same on every platform.

BedrockAgentCoreApp serves:
  POST /invocations  -> handle()
  GET  /ping         -> health check
on port 8080. That is the AgentCore Runtime contract, and ECS/EKS use the same container
behind an ALB / Ingress.

Run locally:  python -m triage.app
"""

from __future__ import annotations

import logging
import os

from bedrock_agentcore.runtime import BedrockAgentCoreApp
from pydantic import ValidationError

from .config import ConfigError
from .schemas import TriageRequest
from .triage_agent import triage

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
log = logging.getLogger("triage")

app = BedrockAgentCoreApp()


@app.entrypoint
def handle(payload: dict, context=None) -> dict:
    """Triage one ticket. Session id comes from the X-Amzn-Bedrock-AgentCore-Runtime-Session-Id header."""
    session_id = getattr(context, "session_id", None) or payload.get("session_id")
    try:
        request = TriageRequest.from_payload(payload or {})
    except ValidationError as exc:
        return {"error": "invalid_request", "details": exc.errors(include_url=False)}

    try:
        result = triage(request, session_id=session_id)
    except ConfigError as exc:
        log.error("Configuration error: %s", exc)
        return {"error": "configuration_error", "details": str(exc)}

    log.info(
        "triaged ticket=%s category=%s priority=%s platform=%s fallback=%s",
        result.ticket_id, result.category, result.priority, result.platform, result.fallback,
    )
    return result.model_dump()


def main() -> None:
    try:  # optional: load .env for local runs (python-dotenv is a dev dependency)
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass
    app.run(port=int(os.environ.get("PORT", "8080")), host=os.environ.get("HOST", "0.0.0.0"))


if __name__ == "__main__":
    main()
