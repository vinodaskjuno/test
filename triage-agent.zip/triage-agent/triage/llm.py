"""The only place an LLM client is built.

Default path: Strands OpenAIModel -> Portkey AI gateway -> (your Portkey provider, e.g. Bedrock Claude).
The Portkey SDK (`portkey_ai`) supplies the gateway URL and builds the x-portkey-* headers.

Escape hatch: LLM_PROVIDER=bedrock calls Amazon Bedrock directly (no gateway), for debugging.
"""

from __future__ import annotations

from typing import Any

from .config import Settings


def portkey_headers(settings: Settings, *, trace_id: str, metadata: dict[str, str]) -> dict[str, str]:
    """Build Portkey request headers with the official SDK helper."""
    from portkey_ai import createHeaders

    kwargs: dict[str, Any] = {
        "api_key": settings.portkey_api_key,
        "trace_id": trace_id,
        "metadata": metadata,
    }
    if settings.portkey_provider:
        kwargs["provider"] = settings.portkey_provider
    if settings.portkey_virtual_key:
        kwargs["virtual_key"] = settings.portkey_virtual_key
    if settings.portkey_config:
        kwargs["config"] = settings.portkey_config
    return createHeaders(**kwargs)


def portkey_client_args(settings: Settings, *, trace_id: str, metadata: dict[str, str]) -> dict[str, Any]:
    """OpenAI-client arguments that point at the Portkey gateway."""
    from portkey_ai import PORTKEY_GATEWAY_URL

    return {
        "base_url": settings.portkey_base_url or PORTKEY_GATEWAY_URL,
        # The OpenAI client requires an api_key; Portkey authenticates via x-portkey-api-key.
        "api_key": settings.portkey_api_key,
        "default_headers": portkey_headers(settings, trace_id=trace_id, metadata=metadata),
        "max_retries": 2,
        "timeout": 120.0,
    }


def build_model(settings: Settings, *, session_id: str, ticket_id: str):
    """Return a Strands model for one request (headers carry a per-request trace id)."""
    if settings.llm_provider == "bedrock":
        from strands.models.bedrock import BedrockModel

        return BedrockModel(
            model_id=settings.model_id,
            region_name=settings.aws_region,
            max_tokens=settings.max_tokens,
        )

    from strands.models.openai import OpenAIModel

    trace_id = f"{settings.portkey_trace_id_prefix}-{settings.deploy_platform}-{session_id}"
    metadata = {
        "platform": settings.deploy_platform,
        "ticket_id": ticket_id,
        "session_id": session_id,
        "agent": "triage-agent",
    }
    return OpenAIModel(
        client_args=portkey_client_args(settings, trace_id=trace_id, metadata=metadata),
        model_id=settings.model_id,
        params={"max_tokens": settings.max_tokens},
    )
