"""Agent tools. Mock in-memory data so the sample runs anywhere with no external systems.

Replace the dicts with calls to your CRM / knowledge base (or an AgentCore Gateway MCP tool).
"""

from __future__ import annotations

from strands import tool

CUSTOMERS: dict[str, dict] = {
    "alice@acme.com": {"name": "Alice Chen", "tier": "enterprise", "plan": "Enterprise Annual", "open_tickets": 1},
    "bob@startup.io": {"name": "Bob Patel", "tier": "pro", "plan": "Pro Monthly", "open_tickets": 0},
    "carol@gmail.com": {"name": "Carol Diaz", "tier": "free", "plan": "Free", "open_tickets": 3},
    "dan@bigbank.com": {"name": "Dan Okafor", "tier": "enterprise", "plan": "Enterprise Annual", "open_tickets": 0},
}

KNOWLEDGE_BASE: list[dict] = [
    {"id": "KB-101", "title": "Why was my card declined?", "tags": ["payment", "card", "declined", "billing", "charge"]},
    {"id": "KB-102", "title": "Requesting a refund", "tags": ["refund", "billing", "charge", "money", "invoice"]},
    {"id": "KB-201", "title": "Resetting your password", "tags": ["password", "reset", "login", "account"]},
    {"id": "KB-202", "title": "Two-factor authentication issues", "tags": ["2fa", "mfa", "login", "locked", "account"]},
    {"id": "KB-301", "title": "API returns 500 errors", "tags": ["api", "500", "error", "outage", "down", "timeout"]},
    {"id": "KB-302", "title": "Dashboard is slow or not loading", "tags": ["slow", "dashboard", "loading", "performance"]},
    {"id": "KB-303", "title": "Data export fails", "tags": ["export", "csv", "data", "download"]},
    {"id": "KB-401", "title": "How to submit a feature request", "tags": ["feature", "request", "idea", "roadmap"]},
]


@tool
def lookup_customer(email: str) -> dict:
    """Look up a customer by email address and return their name, tier, plan and open ticket count.

    Args:
        email: The customer's email address.
    """
    record = CUSTOMERS.get(email.strip().lower())
    if record is None:
        return {"found": False, "email": email, "tier": "unknown"}
    return {"found": True, "email": email, **record}


@tool
def search_knowledge_base(query: str, max_results: int = 3) -> list[dict]:
    """Search help-center articles relevant to a support problem.

    Args:
        query: Short description of the customer's problem, e.g. "card declined on renewal".
        max_results: Maximum number of articles to return (1-5).
    """
    words = {w.strip(".,!?\"'").lower() for w in query.split()}
    scored = [(len(words & set(article["tags"])), article) for article in KNOWLEDGE_BASE]
    hits = [a for score, a in sorted(scored, key=lambda s: -s[0]) if score > 0]
    return hits[: max(1, min(max_results, 5))]


ALL_TOOLS = [lookup_customer, search_knowledge_base]
