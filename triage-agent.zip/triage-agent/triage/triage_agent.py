"""Core agent logic: no HTTP and no platform specifics, so it's easy to test and reuse."""

from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Callable

from pydantic import ValidationError
from strands import Agent

from .config import Settings, get_settings
from .llm import build_model
from .prompts import RETRY_PROMPT, SYSTEM_PROMPT, ticket_prompt
from .schemas import TriageDecision, TriageRequest, TriageResult
from .tools import ALL_TOOLS

log = logging.getLogger(__name__)

# The model is told to answer with a bare JSON object; this also tolerates ```json fences.
_JSON_OBJECT = re.compile(r"\{.*\}", re.DOTALL)


def parse_decision(text: str) -> TriageDecision | None:
    """Extract and validate the JSON decision from the model's final message."""
    match = _JSON_OBJECT.search(text or "")
    if not match:
        return None
    try:
        return TriageDecision.model_validate(json.loads(match.group(0)))
    except (json.JSONDecodeError, ValidationError) as exc:
        log.warning("Invalid triage JSON from model: %s", exc)
        return None


def fallback_decision(reason: str) -> TriageDecision:
    """Safe default when the model output can't be trusted: route to a human."""
    return TriageDecision(
        category="other",
        priority="medium",
        sentiment="neutral",
        summary="Automatic triage failed; routed for manual review.",
        suggested_team="tier1-support",
        needs_human=True,
        reasoning=reason[:1000],
    )


def build_agent(settings: Settings, *, session_id: str, ticket_id: str) -> Agent:
    return Agent(
        model=build_model(settings, session_id=session_id, ticket_id=ticket_id),
        tools=ALL_TOOLS,
        system_prompt=SYSTEM_PROMPT,
        callback_handler=None,  # no streaming to stdout inside a server
        trace_attributes={"platform": settings.deploy_platform, "ticket_id": ticket_id, "session.id": session_id},
    )


AgentFactory = Callable[..., Agent]


def triage(
    request: TriageRequest,
    *,
    session_id: str | None = None,
    settings: Settings | None = None,
    agent_factory: AgentFactory = build_agent,
) -> TriageResult:
    settings = settings or get_settings()
    session_id = session_id or f"local-{uuid.uuid4()}"
    agent = agent_factory(settings, session_id=session_id, ticket_id=request.ticket_id)

    reply = str(agent(ticket_prompt(request.ticket_id, request.subject, request.body, request.customer_email)))
    decision = parse_decision(reply)
    if decision is None:  # one corrective retry in the same conversation
        decision = parse_decision(str(agent(RETRY_PROMPT)))

    used_fallback = decision is None
    if decision is None:
        decision = fallback_decision("Model did not return valid triage JSON after one retry.")

    return TriageResult(
        **decision.model_dump(),
        ticket_id=request.ticket_id,
        platform=settings.deploy_platform,
        model_id=settings.model_id,
        llm_provider=settings.llm_provider,
        session_id=session_id,
        fallback=used_fallback,
    )
