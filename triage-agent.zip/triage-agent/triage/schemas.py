"""Request / response contracts (identical on every platform)."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Category = Literal["billing", "technical", "account", "feature_request", "other"]
Priority = Literal["low", "medium", "high", "urgent"]
Sentiment = Literal["positive", "neutral", "negative", "angry"]
Team = Literal["billing-team", "tier1-support", "tier2-engineering", "account-security", "product"]


class TriageRequest(BaseModel):
    """Body of POST /invocations. A bare {"prompt": "..."} also works."""

    ticket_id: str = Field(default="T-UNKNOWN", max_length=64)
    subject: str = Field(default="", max_length=500)
    body: str = Field(min_length=1, max_length=20_000)
    customer_email: str | None = Field(default=None, max_length=320)

    @classmethod
    def from_payload(cls, payload: dict) -> "TriageRequest":
        if "body" not in payload and "prompt" in payload:
            payload = {**payload, "body": payload["prompt"]}
        return cls.model_validate({k: v for k, v in payload.items() if k in cls.model_fields})


class TriageDecision(BaseModel):
    """What the model must return (validated before we trust it)."""

    category: Category
    priority: Priority
    sentiment: Sentiment
    summary: str = Field(max_length=500)
    suggested_team: Team
    customer_tier: str = "unknown"
    kb_articles: list[str] = Field(default_factory=list)
    needs_human: bool = False
    reasoning: str = Field(default="", max_length=1000)


class TriageResult(TriageDecision):
    """Full response returned by the service."""

    ticket_id: str
    platform: str
    model_id: str
    llm_provider: str
    session_id: str | None = None
    fallback: bool = False
