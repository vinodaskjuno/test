"""Portkey wiring tests. No network calls are made."""

import pytest

from triage.config import ConfigError, get_settings
from triage.llm import build_model, portkey_client_args


def test_portkey_client_args_use_gateway_and_headers(portkey_env, monkeypatch):
    monkeypatch.setenv("PORTKEY_CONFIG", "pc-retry-123")
    settings = get_settings()

    args = portkey_client_args(settings, trace_id="triage-local-s1", metadata={"platform": "local", "ticket_id": "T-1"})

    assert args["base_url"] == "https://api.portkey.ai/v1"  # SDK default gateway
    headers = args["default_headers"]
    assert headers["x-portkey-api-key"] == "pk-test-123"
    assert headers["x-portkey-trace-id"] == "triage-local-s1"
    assert headers["x-portkey-config"] == "pc-retry-123"
    assert '"platform": "local"' in headers["x-portkey-metadata"]


def test_custom_portkey_base_url(portkey_env, monkeypatch):
    monkeypatch.setenv("PORTKEY_BASE_URL", "http://portkey-gateway.internal:8787/v1")
    args = portkey_client_args(get_settings(), trace_id="t", metadata={})
    assert args["base_url"] == "http://portkey-gateway.internal:8787/v1"


def test_build_model_returns_openai_model_pointed_at_portkey(portkey_env):
    from strands.models.openai import OpenAIModel

    model = build_model(get_settings(), session_id="sess-1", ticket_id="T-9")

    assert isinstance(model, OpenAIModel)
    assert model.get_config()["model_id"] == "@bedrock/us.anthropic.claude-opus-5-5"
    assert model.client_args["default_headers"]["x-portkey-trace-id"] == "triage-local-sess-1"


def test_missing_portkey_key_fails_fast(portkey_env, monkeypatch):
    monkeypatch.delenv("PORTKEY_API_KEY")
    with pytest.raises(ConfigError, match="Portkey API key not found"):
        get_settings()


def test_missing_model_id_fails_fast(portkey_env, monkeypatch):
    monkeypatch.delenv("MODEL_ID")
    with pytest.raises(ConfigError, match="MODEL_ID is required"):
        get_settings()


def test_bedrock_escape_hatch_needs_no_portkey(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "bedrock")
    monkeypatch.delenv("PORTKEY_API_KEY", raising=False)
    monkeypatch.delenv("PORTKEY_API_KEY_SECRET_ARN", raising=False)
    monkeypatch.delenv("MODEL_ID", raising=False)
    monkeypatch.setenv("AWS_REGION", "us-east-1")

    settings = get_settings()
    from strands.models.bedrock import BedrockModel

    model = build_model(settings, session_id="s", ticket_id="t")
    assert isinstance(model, BedrockModel)
    assert settings.model_id == "us.anthropic.claude-opus-5-5"


def test_api_key_from_secrets_manager(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "portkey")
    monkeypatch.setenv("MODEL_ID", "@bedrock/x")
    monkeypatch.delenv("PORTKEY_API_KEY", raising=False)
    monkeypatch.setenv("PORTKEY_API_KEY_SECRET_ARN", "arn:aws:secretsmanager:us-east-1:111:secret:pk")

    class FakeSM:
        def get_secret_value(self, SecretId):
            assert SecretId.endswith(":secret:pk")
            return {"SecretString": '{"PORTKEY_API_KEY": "pk-from-sm"}'}

    import boto3

    monkeypatch.setattr(boto3, "client", lambda *a, **k: FakeSM())
    assert get_settings().portkey_api_key == "pk-from-sm"
