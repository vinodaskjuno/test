"""Unit tests with the LLM stubbed out: no AWS, no Portkey, no network."""

import json

from triage.schemas import TriageRequest
from triage.tools import lookup_customer, search_knowledge_base
from triage.triage_agent import parse_decision, triage

GOOD_JSON = json.dumps({
    "category": "billing", "priority": "high", "sentiment": "angry",
    "summary": "Card declined twice on renewal.", "suggested_team": "billing-team",
    "customer_tier": "pro", "kb_articles": ["KB-101"], "needs_human": False, "reasoning": "Payment failure.",
})


class FakeAgent:
    """Mimics strands.Agent: callable, returns objects whose str() is the model's reply."""

    def __init__(self, replies):
        self.replies = list(replies)
        self.prompts = []

    def __call__(self, prompt):
        self.prompts.append(prompt)
        return self.replies.pop(0)


def factory_for(agent):
    return lambda settings, **kwargs: agent


# ---- tools -----------------------------------------------------------------

def test_lookup_customer_known_and_unknown():
    assert lookup_customer(email="Alice@Acme.com")["tier"] == "enterprise"
    assert lookup_customer(email="nobody@x.com") == {"found": False, "email": "nobody@x.com", "tier": "unknown"}


def test_search_knowledge_base_ranks_by_tags():
    hits = search_knowledge_base(query="card declined on billing", max_results=2)
    assert hits[0]["id"] == "KB-101"
    assert len(hits) <= 2


# ---- parsing -----------------------------------------------------------------

def test_parse_decision_accepts_fenced_json():
    assert parse_decision(f"```json\n{GOOD_JSON}\n```").category == "billing"


def test_parse_decision_rejects_invalid_values():
    bad = json.loads(GOOD_JSON) | {"priority": "super-high"}
    assert parse_decision(json.dumps(bad)) is None
    assert parse_decision("no json here") is None


# ---- request parsing --------------------------------------------------------

def test_request_accepts_prompt_alias():
    req = TriageRequest.from_payload({"prompt": "help", "unknown_field": 1})
    assert req.body == "help" and req.ticket_id == "T-UNKNOWN"


# ---- triage flow ------------------------------------------------------------

def test_triage_happy_path(portkey_env):
    agent = FakeAgent([GOOD_JSON])
    req = TriageRequest(ticket_id="T-1", body="card declined", customer_email="bob@startup.io")

    result = triage(req, session_id="s-1", agent_factory=factory_for(agent))

    assert result.category == "billing" and result.priority == "high"
    assert result.platform == "local" and result.llm_provider == "portkey"
    assert result.session_id == "s-1" and result.fallback is False
    assert "bob@startup.io" in agent.prompts[0]


def test_triage_retries_once_then_succeeds(portkey_env):
    agent = FakeAgent(["Sure! Here's my analysis...", GOOD_JSON])
    result = triage(TriageRequest(body="x"), agent_factory=factory_for(agent))
    assert result.fallback is False and len(agent.prompts) == 2


def test_triage_falls_back_to_human(portkey_env):
    agent = FakeAgent(["nope", "still nope"])
    result = triage(TriageRequest(body="x"), agent_factory=factory_for(agent))
    assert result.fallback is True and result.needs_human is True and result.category == "other"


# ---- HTTP entrypoint --------------------------------------------------------

def test_entrypoint_validation_error(portkey_env):
    from triage.app import handle

    out = handle({"ticket_id": "T-1"})  # no body/prompt
    assert out["error"] == "invalid_request"


def test_entrypoint_config_error(monkeypatch):
    from triage.app import handle

    monkeypatch.setenv("LLM_PROVIDER", "portkey")
    monkeypatch.delenv("PORTKEY_API_KEY", raising=False)
    monkeypatch.delenv("PORTKEY_API_KEY_SECRET_ARN", raising=False)
    monkeypatch.setenv("MODEL_ID", "@bedrock/x")
    out = handle({"prompt": "hi"})
    assert out["error"] == "configuration_error"


def test_entrypoint_uses_session_from_context(portkey_env, monkeypatch):
    import triage.app as app_module

    captured = {}

    def fake_triage(request, session_id=None):
        captured["session_id"] = session_id
        return triage(request, session_id=session_id, agent_factory=factory_for(FakeAgent([GOOD_JSON])))

    monkeypatch.setattr(app_module, "triage", fake_triage)

    class Ctx:
        session_id = "agentcore-session-0123456789-0123456789"

    out = app_module.handle({"prompt": "card declined"}, Ctx())
    assert captured["session_id"] == Ctx.session_id and out["session_id"] == Ctx.session_id


def test_http_ping_and_invocations(portkey_env, monkeypatch):
    """Exercise the real Starlette app (same routes AgentCore/ECS/EKS hit)."""
    from starlette.testclient import TestClient

    import triage.app as app_module

    monkeypatch.setattr(
        app_module, "triage",
        lambda request, session_id=None: triage(request, session_id=session_id, agent_factory=factory_for(FakeAgent([GOOD_JSON]))),
    )
    client = TestClient(app_module.app)

    assert client.get("/ping").status_code == 200
    r = client.post(
        "/invocations",
        json={"ticket_id": "T-7", "body": "card declined"},
        headers={"X-Amzn-Bedrock-AgentCore-Runtime-Session-Id": "http-session-0123456789-0123456789"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["ticket_id"] == "T-7" and body["category"] == "billing"
    assert body["session_id"] == "http-session-0123456789-0123456789"
