import json
import pathlib
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


@pytest.fixture(autouse=True)
def _clean_settings_cache():
    from triage.config import get_settings

    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def golden_tickets():
    return json.loads((ROOT / "tests" / "golden_tickets.json").read_text())


@pytest.fixture
def portkey_env(monkeypatch):
    for var in ("PORTKEY_API_KEY_SECRET_ARN", "PORTKEY_CONFIG", "PORTKEY_PROVIDER", "PORTKEY_VIRTUAL_KEY", "PORTKEY_BASE_URL"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("LLM_PROVIDER", "portkey")
    monkeypatch.setenv("PORTKEY_API_KEY", "pk-test-123")
    monkeypatch.setenv("MODEL_ID", "@bedrock/us.anthropic.claude-opus-5-5")
    monkeypatch.setenv("DEPLOY_PLATFORM", "local")
