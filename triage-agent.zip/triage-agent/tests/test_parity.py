"""Parity tests: the SAME golden tickets against every deployed target.

These make real LLM calls through Portkey (they cost money), so they're opt-in.
A target runs only when its env var is set:
    LOCAL_URL=http://localhost:8080                       (python -m triage.app)
    ECS_URL=http://<alb-dns>                              (ECS service ALB)
    EKS_URL=http://<ingress-alb-dns>                      (EKS Ingress)
    AGENTCORE_ARN=arn:aws:bedrock-agentcore:...:runtime/triage_agent-XXXX

Run:  pytest tests/test_parity.py -v
      pytest tests/test_parity.py -v -k "ecs or eks"
"""

from __future__ import annotations

import json
import os
import uuid

import pytest

GOLDEN = json.loads(open(os.path.join(os.path.dirname(__file__), "golden_tickets.json")).read())
TARGETS = {
    "local": "LOCAL_URL",
    "ecs": "ECS_URL",
    "eks": "EKS_URL",
    "agentcore": "AGENTCORE_ARN",
}
SESSION_HEADER = "X-Amzn-Bedrock-AgentCore-Runtime-Session-Id"


def new_session_id(target: str) -> str:
    return f"parity-{target}-{uuid.uuid4()}"  # AgentCore requires 33+ chars


def invoke(target: str, payload: dict, session_id: str) -> dict:
    if target == "agentcore":
        import boto3

        client = boto3.client("bedrock-agentcore", region_name=os.environ.get("AWS_REGION", "us-east-1"))
        resp = client.invoke_agent_runtime(
            agentRuntimeArn=os.environ["AGENTCORE_ARN"],
            runtimeSessionId=session_id,
            payload=json.dumps(payload).encode(),
            qualifier=os.environ.get("AGENTCORE_QUALIFIER", "DEFAULT"),
        )
        return json.loads(resp["response"].read())

    import requests

    url = os.environ[TARGETS[target]].rstrip("/")
    r = requests.post(f"{url}/invocations", json=payload, headers={SESSION_HEADER: session_id}, timeout=180)
    r.raise_for_status()
    return r.json()


def _targets():
    return [pytest.param(t, marks=pytest.mark.skipif(not os.environ.get(v), reason=f"{v} not set")) for t, v in TARGETS.items()]


@pytest.mark.parametrize("target", _targets())
def test_ping(target):
    if target == "agentcore":
        pytest.skip("AgentCore manages /ping itself")
    import requests

    r = requests.get(os.environ[TARGETS[target]].rstrip("/") + "/ping", timeout=10)
    assert r.status_code == 200


@pytest.mark.parametrize("target", _targets())
@pytest.mark.parametrize("ticket", GOLDEN, ids=[t["ticket_id"] for t in GOLDEN])
def test_golden_ticket(target, ticket):
    payload = {k: ticket[k] for k in ("ticket_id", "customer_email", "subject", "body")}
    session_id = new_session_id(target)

    out = invoke(target, payload, session_id)

    assert "error" not in out, out
    assert out["ticket_id"] == ticket["ticket_id"]
    assert out["fallback"] is False, "model output failed validation"
    for field, allowed in ticket["expect"].items():
        assert out[field] in allowed, f"{target}: {field}={out[field]!r} not in {allowed}"
    if target != "local":
        assert out["platform"] == target, "response came from an unexpected runtime"
