#!/usr/bin/env bash
# Smoke-test any HTTP target (local, ECS ALB, EKS Ingress).
# Usage: scripts/smoke_test.sh [base_url]     default: http://localhost:8080
set -euo pipefail
URL="${1:-http://localhost:8080}"
SESSION="smoke-$(date +%s)-$(uuidgen 2>/dev/null || echo 0123456789abcdef0123456789)"

echo "== GET $URL/ping"
curl -fsS "$URL/ping"; echo

echo "== POST $URL/invocations"
curl -fsS -X POST "$URL/invocations" \
  -H "Content-Type: application/json" \
  -H "X-Amzn-Bedrock-AgentCore-Runtime-Session-Id: $SESSION" \
  -d '{
        "ticket_id": "T-SMOKE-1",
        "customer_email": "alice@acme.com",
        "subject": "Production API down",
        "body": "Our production integration gets 500 errors from your API for 30 minutes. All orders failing!"
      }' | python3 -m json.tool
