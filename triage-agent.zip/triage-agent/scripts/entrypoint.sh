#!/bin/sh
# Container entrypoint. AgentCore collects OpenTelemetry automatically when the app runs
# under opentelemetry-instrument. On ECS/EKS, set ENABLE_OTEL=false unless you run an ADOT collector.
set -e
if [ "${ENABLE_OTEL:-true}" = "true" ]; then
  exec opentelemetry-instrument python -m triage.app
fi
exec python -m triage.app
