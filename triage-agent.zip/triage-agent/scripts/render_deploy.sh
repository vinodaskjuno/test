#!/usr/bin/env bash
# Fill the __PLACEHOLDERS__ in deploy/ and write the results to deploy/rendered/ (git-ignored).
# Required env vars:
#   ACCOUNT_ID        e.g. 123456789012
#   REGION            e.g. us-east-1
#   IMAGE_URI         e.g. 123456789012.dkr.ecr.us-east-1.amazonaws.com/triage-agent:1.0.0
#   SECRET_ARN        Secrets Manager ARN holding the Portkey API key
#   PORTKEY_MODEL_ID  e.g. @bedrock/us.anthropic.claude-opus-5-5
set -euo pipefail
cd "$(dirname "$0")/.."

for v in ACCOUNT_ID REGION IMAGE_URI SECRET_ARN PORTKEY_MODEL_ID; do
  [ -n "${!v:-}" ] || { echo "Missing env var: $v" >&2; exit 1; }
done

rm -rf deploy/rendered
for src in $(find deploy -type f \( -name '*.json' -o -name '*.yaml' \) -not -path 'deploy/rendered/*'); do
  dst="deploy/rendered/${src#deploy/}"
  mkdir -p "$(dirname "$dst")"
  sed -e "s|__ACCOUNT_ID__|${ACCOUNT_ID}|g" \
      -e "s|__REGION__|${REGION}|g" \
      -e "s|__IMAGE_URI__|${IMAGE_URI}|g" \
      -e "s|__SECRET_ARN__|${SECRET_ARN}|g" \
      -e "s|__PORTKEY_MODEL_ID__|${PORTKEY_MODEL_ID}|g" \
      "$src" > "$dst"
done

if grep -rn "__[A-Z_]*__" deploy/rendered >/dev/null; then
  echo "Unfilled placeholders remain:" >&2; grep -rn "__[A-Z_]*__" deploy/rendered >&2; exit 1
fi
echo "Rendered files in deploy/rendered/:"
find deploy/rendered -type f | sort
