"""Invoke the deployed AgentCore runtime with boto3.

Usage:
  python scripts/invoke_agentcore.py --arn arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/triage_agent-AbC123 \
      --body "My card was declined twice" --email bob@startup.io
"""

import argparse
import json
import uuid

import boto3


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--arn", required=True, help="Agent runtime ARN")
    p.add_argument("--region", default="us-east-1")
    p.add_argument("--body", default="My card was declined twice when renewing. Please fix today!")
    p.add_argument("--subject", default="Payment failed")
    p.add_argument("--email", default="bob@startup.io")
    p.add_argument("--ticket-id", default="T-CLI-1")
    p.add_argument("--session-id", default=None, help="33+ characters; generated if omitted")
    p.add_argument("--qualifier", default="DEFAULT")
    args = p.parse_args()

    session_id = args.session_id or f"cli-{uuid.uuid4()}"
    payload = {"ticket_id": args.ticket_id, "subject": args.subject, "body": args.body, "customer_email": args.email}

    client = boto3.client("bedrock-agentcore", region_name=args.region)
    resp = client.invoke_agent_runtime(
        agentRuntimeArn=args.arn,
        runtimeSessionId=session_id,
        payload=json.dumps(payload).encode(),
        qualifier=args.qualifier,
    )
    print(json.dumps(json.loads(resp["response"].read()), indent=2))


if __name__ == "__main__":
    main()
