# Ticket Triage Agent: one agent for AgentCore, ECS and EKS

This is a portable support-ticket triage agent. It is built with **Strands Agents** and sends every model call through the **Portkey AI gateway** to Claude on Amazon Bedrock. The **same container image** runs unchanged on Amazon Bedrock AgentCore Runtime, Amazon ECS (Fargate) and Amazon EKS.

```
client ──► triage agent (POST /invocations, GET /ping :8080) ──► Portkey gateway ──► Claude (Bedrock)
                │ tools: lookup_customer, search_knowledge_base
```

## Guides
| Guide | What it covers |
|---|---|
| [docs/local-run.html](docs/local-run.html) | Run on your laptop with plain Python (no Docker), then deploy to AgentCore with the `agentcore` CLI (the image builds in CodeBuild) |
| [docs/aws-deploy.html](docs/aws-deploy.html) | Manual, step-by-step deployment of the same image to AgentCore, ECS and EKS, plus parity testing |

## Quick start (local)
```bash
cd triage-agent
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env              # set PORTKEY_API_KEY, PORTKEY_BASE_URL, MODEL_ID
pytest                            # unit tests, no network
python -m triage.app              # serves http://localhost:8080
scripts/smoke_test.sh             # /ping + a sample ticket
```

## API
`POST /invocations`
```json
{"ticket_id": "T-1001", "customer_email": "alice@acme.com", "subject": "API down", "body": "500 errors for 30 min"}
```
Response:
```json
{"category": "technical", "priority": "urgent", "sentiment": "negative", "summary": "...",
 "suggested_team": "tier2-engineering", "customer_tier": "enterprise", "kb_articles": ["KB-301"],
 "needs_human": false, "reasoning": "...", "ticket_id": "T-1001", "platform": "local",
 "model_id": "@bedrock/us.anthropic.claude-opus-5-5", "llm_provider": "portkey",
 "session_id": "...", "fallback": false}
```
The session ID is read from the `X-Amzn-Bedrock-AgentCore-Runtime-Session-Id` header on every platform. It also becomes the Portkey trace ID: `triage-<platform>-<session>`.

## Layout
```
triage/            agent package (app.py = HTTP entrypoint, llm.py = Portkey wiring)
tests/             unit tests (stubbed LLM) + parity tests (real targets, opt-in)
scripts/           entrypoint.sh, smoke_test.sh, invoke_agentcore.py, render_deploy.sh
deploy/            IAM policies, AgentCore runtime JSON, ECS task definition, EKS manifests (__PLACEHOLDERS__)
buildspec.yml      CodeBuild: build the image in AWS and push to ECR (no local Docker)
Dockerfile         one image for all three platforms (linux/arm64)
```

## Configuration
| Variable | Purpose |
|---|---|
| `LLM_PROVIDER` | `portkey` (default) or `bedrock` (direct Bedrock, for debugging) |
| `PORTKEY_BASE_URL` | Portkey gateway URL (default `https://api.portkey.ai/v1`, or your self-hosted gateway) |
| `PORTKEY_API_KEY` / `PORTKEY_API_KEY_SECRET_ARN` | Portkey key, given directly or read from Secrets Manager |
| `MODEL_ID` | Portkey model, e.g. `@bedrock/us.anthropic.claude-opus-5-5` |
| `PORTKEY_CONFIG`, `PORTKEY_PROVIDER`, `PORTKEY_VIRTUAL_KEY` | Optional Portkey routing settings |
| `DEPLOY_PLATFORM` | `local` / `agentcore` / `ecs` / `eks`; echoed in responses and in Portkey metadata |
| `ENABLE_OTEL` | `true` runs the app under `opentelemetry-instrument` (keep it on for AgentCore) |
